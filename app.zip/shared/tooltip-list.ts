import * as $ from 'jquery';

export class TooltiptList {
  public placement: string = 'right'; 

  /**car insurance messages */
  public chassis_no: string = 'Enter the chassis number of your car which is available on the back of your registration card'
  public make: string = 'Mention the brand name of your car';
  public vehicle_type: string = 'Mention the body type of your car';
  public model: string = 'Mention the model of your car';
  public model_year: string = 'Enter the year of manufacture for your car model which is available on your registration card';
  public vehicle_value: string = 'Enter the amount that you would like to insure your car for';
  public gcc_specification: string = 'Mention if your vehicle is purchased from the GCC or is imported from elsewhere';
  public first_Reg_year: string = 'Enter the year of registration as mentioned on your vehicle registration card';
  public registration_location: string = 'In which Emirate will the car be registered?';
  public insured_name: string = 'Enter the name of the person under whose name the car must be insured';
  public date_of_birth: string = 'Enter your age';
  public nationality: string = 'Enter your nationality';
  public driving_experience: string = 'Enter your UAE driving experience';
  public mobile_number: string = 'Ensure mobile number begins with 0 or 5';
  public promo_code: string = 'Enter the promotional code, if received, here ';
  public start_date: string = 'Choose the date from when your insurance should start';
  public bank_of_finance: string = 'Enter the bank from which you have received your car loan';
  public color: string = 'Mention your vehicle color';
  public vehicle_usage: string = 'Enter if the usage of your vehicle is for commercial or personal purposes';

  /**home insurance messages */
  public home_insured_name: string = 'Enter the name of the person under whose name the home must be insured';
  public home_insured_value: string = 'Enter the value of Home Contents Insured';
  public app_value: string = 'Enter the approximate value of your home contents you want to insure in local currency';
  public personal_belongings: string = 'Enter the valuable items you have that can be carried out of the house, eg: jewellery, mobile phone, laptop, etc';
  public domestic_helpers: string = 'Enter the number of people (your domestic servants or/and drivers) whom you would like to insure  for personal accident through Home Contents Insurance';
  public bulding_address: string = 'Enter the exact address of where you stay currently';
  public bulding_value: string = 'Enter the building sum insured value';

  /** Travel Insurance messages */
  public travel_insured_name: string = 'Enter the name of the person under whose name the travel must be insured';
  public trip_type = 'Enter how many trips you want to insure for a year, single or multiple?';
  public travel_days = 'Enter the number of days you will be travelling';

  /** PAB Insurance messages */
  public pab_insured_name: string = 'Enter the name of the person under whose name the personal accidental must be insured';
  public monthly_salary = 'Enter your average monthly salary here';
  public geographical_limit = 'Coverage will be within UAE only';
  /**
   * messages which require images
   * listed below
   */
  public registration_no: string = 'Enter your vehicle plate number. If it’s a brand new car enter "NEW"';
  public driving_license_no: string = '';
  public tcf_no: string = '';
  public engine_no: string = 'Enter the engine number mentioned on your vehicle registration card';
  public passwordRequirement: string = 'Password must contain at least one of lower case, upper case, number or special characters(@,#,_,$) and must contain 8 characters';
  /** check if it is desktop or mobile */
  /* returns mobile top or desktop right*/
  getPlacementAlignment() {
    let winWidth = $(window).width();
    if (winWidth < 767) {
      return 'top';
    }
    else {
      return 'right';
    }
  }

  /* returns mobile bottom or desktop right*/
  imageTooltip() {
    let winWidth = $(window).width();
    if (winWidth < 767) {
      return 'bottom';
    }
    else {
      return 'right';
    }
  }
  homeTooltip() {
    let winWidth = $(window).width();
    if (winWidth < 767) {
      if (winWidth > 412) {
        return 'left';
      } else if (winWidth > 350) {
        return 'left';
      }
      else {
        return 'right';
      }
    }
    else {
      return 'left';
    }
  }
}
