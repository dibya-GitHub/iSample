import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public subject = new Subject<any>();
  constructor() { }
  alert(alertType: string, objData: boolean) {
    this.subject.next({ type: alertType, data: objData });
  }
  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }
}
