import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApiConstants } from '../../shared/api-constants';
import { ApiHeadersService } from '../../shared/api-headers.service';
import { ApiUrls } from '../api-urls';
import { NewPayment } from '../interfaces/new-payment';
import { Payment } from '../interfaces/payment';
@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  requestOption;
  baseUrl = environment.baseUrl;
  payment: Payment;
  newPayment: NewPayment;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }


  initPayment(quoteInfo: any, regPaymentInfo: any, totPremium: any): Payment {
    const signedFieldNames = 'access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency,override_custom_receipt_page,override_custom_cancel_page,device_fingerprint_id,merchantID,merchant_defined_data1,merchant_defined_data3,merchant_defined_data4,merchant_defined_data8,merchant_defined_data9,merchant_defined_data10,merchant_defined_data11,merchant_defined_data21,merchant_defined_data25,ccAuthService_run,ccCaptureService_run,merchantReferenceCode,purchaseTotals_currency,customer_ip_address,merchant_secure_data1,merchant_secure_data2,merchant_secure_data3';
    const payment: Payment = {
      access_key: regPaymentInfo.access_key,
      profile_id: regPaymentInfo.profile_id,
      transaction_uuid: regPaymentInfo.transaction_uuid,
      signed_field_names: signedFieldNames,
      unsigned_field_names: 'bill_to_forename,bill_to_surname,bill_to_email,bill_to_phone,bill_to_address_line1,bill_to_address_city,bill_to_address_state,bill_to_address_country',
      signed_date_time: this.getUTCDate(),
      locale: 'en-US',
      transaction_type: 'sale',
      reference_number: regPaymentInfo.qicPaymtId,
      amount: totPremium,
      currency: ApiConstants.CURRENCY,
      override_custom_receipt_page: regPaymentInfo.pgRespUrl,
      override_custom_cancel_page: regPaymentInfo.pgRespUrl,
      device_fingerprint_id: regPaymentInfo.qicPaymtId,
      merchantID: regPaymentInfo.merchantID,
      merchant_defined_data1: '1',
      merchant_defined_data3: 'WC',
      merchant_defined_data4: 'NO',
      merchant_defined_data8: quoteInfo.lobDesc,
      merchant_defined_data9: quoteInfo.prodDesc,
      merchant_defined_data10: 'Customer',
      merchant_defined_data11: 'Print',
      merchant_defined_data21: '1',
      merchant_defined_data25: 'UAE',
      ccAuthService_run: 'true',
      ccCaptureService_run: 'true',
      merchantReferenceCode: regPaymentInfo.qicPaymtId,
      purchaseTotals_currency: ApiConstants.CURRENCY,
      customer_ip_address: localStorage.getItem('ip'),
      merchant_secure_data1: ApiConstants.COMPANY,
      merchant_secure_data2: ApiConstants.PORTAL,
      merchant_secure_data3: '003'
    };

    return payment;
  }
  newInitPayment(quoteInfo: any, regPaymentInfo: any, totPremium: any): NewPayment {

    const newPayment: NewPayment = {

      merchant_id: regPaymentInfo.merchantID,
      access_code: regPaymentInfo.access_key,
      enc_key: regPaymentInfo.secret_key,
      order_id: regPaymentInfo.qicPaymtId,
      currency: ApiConstants.CURRENCY,
      amount: totPremium,
      pgReqUrl: regPaymentInfo.pgReqUrl,
      redirect_url: regPaymentInfo.pgRespUrl,
      cancel_url: regPaymentInfo.pgRespUrl,
      language: 'EN',
      merchant_param2: quoteInfo.lobDesc,
      merchant_param3: quoteInfo.prodDesc,
      merchant_param4: regPaymentInfo.transaction_uuid,
    };

    return newPayment;
  }
  /* newInitPayment(quoteInfo: any, regPaymentInfo: any, totPremium: any): NewPayment {
     const newPayment: NewPayment = {
       
       merchant_id: 43560,//regPaymentInfo.merchantID,
       access_code: "AVUR02CK31AH26RUHA",//regPaymentInfo.access_key,
       enc_key: "BBA2DEA88F89BED736DACD26FB237170",//regPaymentInfo.secret_key,
       order_id: regPaymentInfo.qicPaymtId,
       currency: ApiConstants.CURRENCY,
       amount: totPremium,
       redirect_url: "https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction",//regPaymentInfo.pgReqUrl,
       cancel_url: regPaymentInfo.pgRespUrl,
       language: 'EN',
       merchant_param1: '1',
       merchant_param2: 'WC',
       merchant_param3: 'NO',
       merchant_param4: quoteInfo.lobDesc,
       merchant_param5: quoteInfo.prodDesc,
       //tid: regPaymentInfo.qicPaymtId,
     };
     return newPayment;
   }*/



  public getUTCDate(): string {
    const now = new Date();
    const now_utc = now.getUTCFullYear() + '-' + this.appendZero(now.getUTCMonth() + 1) + '-' + this.appendZero(now.getUTCDate()) + 'T' + this.appendZero(now.getUTCHours()) + ':' + this.appendZero(now.getUTCMinutes()) + ':' + this.appendZero(now.getUTCSeconds()) + 'Z';
    return now_utc;
  }

  public appendZero(digit): string {
    if (digit < 10) {
      return '0' + digit;
    } else {
      return digit;
    }
  }

  registerPayment(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.REGISTER_PAYMENT, body, this.requestOption);
  }

  checkBundledProduct(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.CHECK_BUNDLED_PRODUCT, body, this.requestOption);
  }

  getBundledProductDetails(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_BUNDLED_PRODUCT_DETAILS, body, this.requestOption);
  }

  updateBundlSel(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_BUNDL_SEL, body, this.requestOption);
  }
}
