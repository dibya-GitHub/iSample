import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApiHeadersService } from '../api-headers.service';
import { ApiUrls } from '../api-urls';
import { LoaderService } from '../loader-service/loader.service';
import { map } from "rxjs/operators"; 

@Injectable({
  providedIn: 'root'
})
export class InsuranceService {
  isCovidSelected;
  requestOption;
  baseUrl = environment.baseUrl;
  url = "https://api.cognitive.microsoft.com/bingcustomsearch/v7.0/search?";
  accessControl = new Headers({ 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' })
  searchHeaders = new Headers({ 'Ocp-Apim-Subscription-Key': '13c6459b308a4125b9792aacb7d678fc' })
  // searchOption = new RequestOptions({ headers: this.searchHeaders })
  blogUrl = 'https://www.blog.qic-insured.com/?json=get_posts';
  insValidYN: any = [{ id: "1", text: "Yes" }, { id: "0", text: "No" }, { id: "2", text: "Brand New" }];

  constructor(
    private http: HttpClient,
    private loaderService: LoaderService,
    private apiHeadersService: ApiHeadersService,
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  // This service method is used to create quotation for the respective insurance type.
  createQuote(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.CREATE_QUOTE_URL, body, this.requestOption);
  }
  // This service method is used to update the user information.
  updateInsuredInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSURED_INFO_URL, body, this.requestOption);
  }

  // This service method is used to get the list of products on insurance plan page.
  getProducts(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_PRODUCTS_URL, body, this.requestOption);
  }

  // This service method is used to get the schemes on insurance plan page.
  getSchemes(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_SCHEMES_URL, body, this.requestOption);
  }

  getSchemeCovers(body: any): Observable<any> {
    // this.quotationService.prepareInputJson(body);
    return this.http.post(this.baseUrl + ApiUrls.GET_SCHEMECOVERS_URL, body, this.requestOption);
  }

  getInsuranceValid() {
    return this.insValidYN;
  }

  getAllCovers(body: any): Observable<any> {
    // this.quotationService.prepareInputJson(body);
    return this.http.post(this.baseUrl + ApiUrls.GET_ALLCOVERS_URL, body, this.requestOption);
  }

  // This service method is used to get the mandatory/optional/inclusive covers on insurance plan page.
  getCovers(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_COVERS_URL, body, this.requestOption);
  }

  // This service method is used to update the optional cover selected as a part of insurance.
  updateOptionalCover(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_OPTIONAL_COVER_URL, body, this.requestOption);
  }

  // This method is used to update the Product scheme information selected on plan page.
  updateProductScheme(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_PRODUCT_SCHEME_URL, body, this.requestOption);
  }

  // This method is used to get the premium of the scheme on insurance plan page.
  getSchemeNetPremium(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_SCHEME_NET_PREMIUM_URL, body, this.requestOption);
  }

  // This method is used to get the summary of the covers selected
  getCoverSummary(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_COVER_SUMMARY_URL, body, this.requestOption);
  }

  // This method is used to get the summary of discounts/deductibles
  getDiscDedLoadFeesSumm(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_DISC_DED_LOAD_FEES_SUMMARY_URL, body, this.requestOption);
  }

  // This method is used to get the premium summary information
  getNetPremSumm(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_NET_PREMIUM_SUMMARY_URL, body, this.requestOption);
  }

  // This method is used to get the payment options on summary page
  getPaymentOptions(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_PAYMENT_OPTIONS_URL, body, this.requestOption);
  }

  getGenderList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_GENDER_LIST_URL, body, this.requestOption);
  }

  getNationalityList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_NATIONALITY_LIST_URL, body, this.requestOption);
  }

  getImportCountryList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_COUNTRY_LIST_URL, body, this.requestOption);
  }

  getRelationList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_RELATION_LIST_URL, body, this.requestOption);
  }

  // method to provide IP address
  getIPAddress(): Observable<any> {
    return this.http.get('https://api.ipify.org/?format=json').pipe(map((response: Response) => {
      const ipJson = JSON.parse(response['_body']);
      return ipJson;
    }));

  }

  // This method is used to validate if we need to proceed further to get the prodcuts and scheme details on insurance plan page
  calculatePricing(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CALCULATE_PRICING_URL, body, this.requestOption);
  }

  insertErrorMsg(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_ERROR_MSG, body, this.requestOption);

  }

  uploadPolicyDocument(formData: any) {
    this.loaderService.display(true);
    let that = this;
    const xhr: XMLHttpRequest = new XMLHttpRequest();
    return new Promise((resolve, reject) => {

      const xhr = new XMLHttpRequest();
      xhr.open('POST', this.baseUrl + ApiUrls.UPLOAD_POLICY_DOCUMENT_URL, true);
      let key = this.apiHeadersService.encodedKey;
      xhr.setRequestHeader("Authorization", "Basic " + key);
      xhr.setRequestHeader("company", '002');
      xhr.onreadystatechange = function () {
        that.loaderService.display(false);
        if (xhr.readyState === 4) {
          if (xhr.status === 202) {
            resolve(JSON.parse(xhr.response));
          } else {
            reject(xhr.response);
          }
        }
      };
      xhr.send(formData);

    });
  }

  uploadClaimDocument(formData: any) {
    this.loaderService.display(true);
    let that = this;
    const xhr: XMLHttpRequest = new XMLHttpRequest();
    return new Promise((resolve, reject) => {

      const xhr = new XMLHttpRequest();
      xhr.open('POST', this.baseUrl + ApiUrls.UPLOAD_CLAIM_DOCUMENT_URL, true);
      let key = this.apiHeadersService.encodedKey;
      xhr.setRequestHeader("Authorization", "Basic " + key);
      xhr.setRequestHeader("company", '002');
      xhr.onreadystatechange = function () {
        that.loaderService.display(false);
        if (xhr.readyState === 4) {
          if (xhr.status === 202) {
            resolve(JSON.parse(xhr.response));
          } else {
            reject(xhr.response);
          }
        }
      };
      xhr.send(formData);

    });
  }

  setUploadDocument(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GETUPLDDOCLIST, body, this.requestOption);
  }
  getUploadDocument(body: any) {
    let baseUrl = this.baseUrl + "/showDmsdoc?docNo=" + body;
    return this.http.get(baseUrl, this.requestOption);
  }

  getInstallationApplicable(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSTALLATION_APPLICABLE_URL, body, this.requestOption);
  }

  getCountryList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_COUNTRY_LIST_URL, body, this.requestOption);

  }
  // This method is used to display the installments options
  displayInstallments(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.DISPLAY_INSTALLMENTS_URL, body, this.requestOption);
  }

  emailQuote(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.EMAIL_QUOTE, body, this.requestOption);
  }

  getApplicationCodes(refType: any): Observable<any> {
    const postData = {
      type: refType
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_CODES, postData, this.requestOption);
  }
  getPlateCharactors(countryCode): Observable<any> {
    return this.http.post(this.baseUrl + 'getPlateCharacter?company=002', { regnLoc: countryCode }, this.requestOption);
  }
  // getInsuranceValid(){
  //    return this.insValidYN;
  // }

  getApplicationRefCodes(refType: any, referenceCode: any): Observable<any> {
    const postData = {
      type: refType,
      refCode: referenceCode
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_REF_CODES, postData, this.requestOption);
  }

  getActivePolList(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_ACTIVE_POL_LIST, body, this.requestOption);
  }

  getPolInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_INFO, body, this.requestOption);
  }

  getQuoteInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_INFO, body, this.requestOption);
  }

  /*getQuoteRiskDetails(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_RISK_DETAILS+"?agentId=online&company=002", body, this.requestOption);
  }*/


  getQuoteVehInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_VEHICLE_INFO, body, this.requestOption);
  }

  getOptionalCoverDiscDedLoad(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_COVERS_DISC_DED_URL, body, this.requestOption);
  }


  // this service is used to get all the installments for all the schemes
  getInstallments(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_INSTALLMENTS_URL, body, this.requestOption);
  }

  getQuotInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_INFO, body, this.requestOption);
  }

  getperBelongings(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_PERSONAL_BELONGINGS_INFO, body, this.requestOption);
  }

  // used to update if user has selected installments or not
  updateInstallmentFlag(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSTALLMENT_FLAG_URL, body, this.requestOption);

  }

  updatePABDropdown(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_PAB_DROPDOWN_URL, body, this.requestOption);

  }
  confirmPolicy(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CONFIRM_POLICY, body, this.requestOption);

  }

  //method is used to get cover conditions
  getCoverConditions(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_COVER_CONDITION, body, this.requestOption);
  }

  validatePayLink(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.VALIDATE_PAY_LINK, body, this.requestOption);
  }
  validateInstLink(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.VALIDATE_INST_LINK, body, this.requestOption);
  }
  validateRenLink(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.VALIDATE_REN_LINK, body, this.requestOption);
  }
  //method is used to get installment details
  getInstallmentDetails(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_INSTALLMENTS_DETAILS_URL, body, this.requestOption);
  }

  registerPayment(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.REGISTER_PAYMENT_URL, body, this.requestOption);
  }

  //This method is used to submit information on insurance call page
  submitInsuranceCallDetails(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSURANCE_ON_CALL_URL, body, this.requestOption);
  }

  //This method is used to submit information on contact us page
  submitContactUsInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CONTACT_US_URL, body, this.requestOption);
  }

  //This method is used to get Application parameters
  getApplicationParameters(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_PARAM, body, this.requestOption);
  }

  getSearchData(body: any) {
    let searchUrl = this.url + "q=" + body + "&customconfig=4195696862&responseFilter=Webpages&mkt=en-US&safesearch=Moderate&count=50"
    return this.http.get(searchUrl, this.requestOption);
  }

  getPolVehInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_VEHICLE_INFO, body, this.requestOption);
  }

  getPolCovers(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_COVERS, body, this.requestOption);
  }

  getPolicyHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_HOME_INFO, body, this.requestOption);
  }

  getPolTravelInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_TRAVEL_INFO, body, this.requestOption);
  }

  getCovDoc(body: any) {
    return this.http.get(this.baseUrl + ApiUrls.GET_COVER_DOC, this.requestOption)
  }


  getCoverDocUrl(body: any) {

    var url = this.baseUrl + ApiUrls.GET_COVER_DOC + '&coverCode=' + body.coverCode;
    this.downloadFile(url, body, function (res) {
      const blob = new Blob([res], { type: 'application/pdf' });
      var url = URL.createObjectURL(blob);
      window.open(url);
    });
    const context = this;



  }

  downloadFile(url, data, success) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    let key = this.apiHeadersService.encodedKey;
    xhr.setRequestHeader("Authorization", "Basic " + key);
    xhr.setRequestHeader("company", '002');
    //xhr.setRequestHeader("Authorization", "Bearer " + sessionStorage.getItem('access_token'));
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.responseType = "arraybuffer";
    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4) {
        if (success) success(xhr.response);
      }
    };
    xhr.send(JSON.stringify(data));
  }

  custFeedback(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CUSTOMER_FEEDBACK, body, this.requestOption);
  }

  getNativeWindow() {
    return window;
  }

  getBlogFeeds() {
    return this.http.get(this.blogUrl, this.requestOption);
  }
  tellUsWhen(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.TELLUSWHEN, body, this.requestOption);
  }
}
