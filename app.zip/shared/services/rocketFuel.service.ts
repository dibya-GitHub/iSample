import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class RocketFuelService {
    public pixelFire = new Subject();

    pixelFireValue(value: any) {
        //console.log(this.pixelFire);
        this.pixelFire.next(value);
    }
}