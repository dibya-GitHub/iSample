import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LoaderService } from './loader-service/loader.service';

@Injectable({
  providedIn: 'root'
})
export class ApiHeadersService {
  public headers;
  public requestHeaders;
  public encodedKey = 'MzJjZDgwNmYtNjExYy00YzMxLWEyNjEtNDhlNmZiOTMwZDI1OmJjM2Q4M2U5LWY4YzAtNDE4YS05MjA2LTgyNGMzNGRlYzM3Nw==';
  constructor(public http: HttpClient, private loaderService: LoaderService) {
    this.requestHeaders = { headers: { "Authorization": "Basic " + this.encodedKey, 'company': '002', 'Content-Type': 'application/json' } };
  }
  openPdf(url: any) {
    let that = this;
    that.loaderService.display(true);
    downloadFile(url, function (blob) {
      var url = URL.createObjectURL(blob);
      that.loaderService.display(false);
      window.open(url);
    });
    function downloadFile(url, success) {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      let key = this.apiHeadersService.encodedKey;
      xhr.setRequestHeader("Authorization", "Basic " + key);
      xhr.setRequestHeader("company", '002');
      xhr.responseType = "blob";
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          if (success) success(xhr.response);
        }
      };
      xhr.send(null);

    }
  }
}
