import { Gender } from '../classes/gender'
import { Nationality } from '../classes/nationality'
import { Relation } from '../classes/relation'

export interface GenderList {
  errMessage: string;
  respCode: string;
  appParamsArray: Array<Gender>
}

export interface NationalityList {
  errMessage: string;
  respCode: string;
  appCodesArray: Array<Nationality>
}

export interface RelationList {
  errMessage: string;
  respCode: string;
  appCodesArray: Array<Relation>
}
