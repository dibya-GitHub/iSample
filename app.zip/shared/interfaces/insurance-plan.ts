import { Product } from '../classes/product';
import { Scheme } from '../classes/scheme';
import { Cover } from '../classes/cover';
export interface CreateQuotation {
  respCode: number;
  quoteNo: string;
  errMessage: string;
  tranSrNo: string;
  transId: string;
}

export interface Products {
  respCode: number;
  errMessage: string;
  prodArray: Array<Product>;
}

export interface Schemes {
  respCode: number;
  errMessage: string;
  schemesArray: Array<Scheme>;
}

export interface Covers {
  respCode: number;
  errMessage: string;
  coversArray: Array<Cover>;
}
