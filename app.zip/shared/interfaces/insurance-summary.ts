export interface CoverSummary {
  transId: string;
  tranSrNo: string;
  coverCode: string;
  coverDesc: string;
  coverDocYN: string;
  helptext: string;
  premium: string;
  errMessage: string;
}

export interface DiscountDeductibleSummary {
  code: string;
  desc: string;
  helptext: string;
  value: string;
  errMessage: string;
}

export interface NetPremiumSummary {
  totalPrem: string;
  firstInstPrem: string;
  errMessage: string;
}
