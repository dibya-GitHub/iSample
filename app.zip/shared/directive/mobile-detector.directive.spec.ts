import { MobileDetectorDirective } from './mobile-detector.directive';

describe('MobileDetectorDirective', () => {
  it('should create an instance', () => {
    const directive = new MobileDetectorDirective();
    expect(directive).toBeTruthy();
  });
});
