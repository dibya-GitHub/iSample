import { TestBed, inject } from '@angular/core/testing';

import { ApiHeadersService } from './api-headers.service';

describe('ApiHeadersService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiHeadersService]
    });
  });

  it('should be created', inject([ApiHeadersService], (service: ApiHeadersService) => {
    expect(service).toBeTruthy();
  }));
});
