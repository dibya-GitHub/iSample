export class RegistrationLocation {
  code: string;
  desc: string;
  value: string;
  descAr?: string;
}
