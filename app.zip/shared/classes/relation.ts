export class Relation {
  code: string;
  desc: string;
  value: string;
  descAr?: string;
}
