export class VehicleModel {
  code: string;
  desc: string;
  value?: string;
  descAr: string;
}
