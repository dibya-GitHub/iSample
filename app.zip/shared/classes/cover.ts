export class Cover {
  type: string;
  prodCode: string;
  schCode: string;
  coverCode: string;
  coverDesc: string;
  helpText: string;
  fldType: string;
  inclYN: string;
  rate: string;
  sumAssured: string;
  premium: string;
  coverDocYN: string;
  errorMessage: string;
}
