export class PabPolicyType {
  code: string;
  desc: string;
  value: string;
  descAr: string;
}
