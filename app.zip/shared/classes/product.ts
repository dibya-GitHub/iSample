export class Product {
  prodCode: string;
  prodDesc: string;
  errMessage: string;
}
