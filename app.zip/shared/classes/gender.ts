export class Gender {
  code: string;
  desc: string;
  value: string;
  descAr?: string;
}
