export class Scheme {
  schCode: string;
  schDesc: string;
  helpText: string;
  schColor: string;
  errMessage: string;
}
