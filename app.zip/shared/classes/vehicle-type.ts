export class VehicleType {
  VEHTYPECODE: string;
  VEHTYPEDESC: string;
  VEHTYPEDESCAR?: string;
}
