export class MonthlySalary {
  code: string;
  desc: string;
  value: string;
  descAr: string;
}
