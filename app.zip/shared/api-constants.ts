export class ApiConstants {
  public static CAR_INSURANCE_LOBCODE = '01';
  public static HOME_INSURANCE_LOBCODE = '04';
  public static CYCLE_INSURANCE_LOBCODE = '04';
  public static TRAVEL_INSURANCE_LOBCODE = '08';
  public static PAB_INSURANCE_LOBCODE = '08';
  public static USER_ID = 'online';
  public static PORTAL = 'D';
  public static LOCATION = 'D';
  public static VEH_USAGE = '1001';
  public static COMPANY = '002';
  public static CURRENCY = 'AED';
}
