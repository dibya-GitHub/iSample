import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutQicComponent } from './about-qic.component';

describe('AboutQicComponent', () => {
  let component: AboutQicComponent;
  let fixture: ComponentFixture<AboutQicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutQicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutQicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
