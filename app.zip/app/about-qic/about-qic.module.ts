import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from './../shared.module';
import { AboutQicRoutingModule } from './about-qic-routing.module';
import { AboutQicComponent } from './about-qic.component';

@NgModule({
    declarations: [
        AboutQicComponent,
    ],
    imports: [
        AboutQicRoutingModule,
        CommonModule,
        SharedModule,
        SlickCarouselModule
    ],
})

export class AboutQicModule { }