import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutQicComponent } from './about-qic.component';

const aboutRoutes: Routes = [
  { path: '', component: AboutQicComponent },
];
@NgModule({
  imports: [
    RouterModule.forChild(aboutRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AboutQicRoutingModule { }
