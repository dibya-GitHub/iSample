import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import * as $ from 'jquery';

@Component({
  selector: 'app-about-qic',
  templateUrl: './about-qic.component.html',
  styleUrls: ['./about-qic.component.scss']
})
export class AboutQicComponent implements OnInit {

  constructor(
    private meta: Meta,
    private titleService: Title
    ) {
    this.titleService.setTitle('About i-Insured | Best Insurance Company in Dubai, UAE');
    this.meta.addTag({ name: 'description', content: 'i-Insured best insurance company in Dubai, UAE provides insurance for individuals, families and businesses. Get a quote online today!' });
    this.meta.addTag({ name: 'keywords', content: 'health insurance companies, dubai insurance company, car insurance companies in dubai, insurance companies dubai, car insurance renewal online, Get House Insurance, dubai qic Travel Insurance' });
  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  slideAbout = {
    "slidesToShow": 2,
    "slidesToScroll": 2,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 736,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  };

  ngOnInit() {
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }

}
