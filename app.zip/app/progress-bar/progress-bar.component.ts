import { Component, Input, OnInit } from '@angular/core';
import { AppUtil } from "src/shared/app-util";

@Component({
  selector: 'progress-bar',
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.scss']
})
export class ProgressBarComponent implements OnInit {
  //startDateShow: string;
  //endDateShow: string;
  renewDateShow: string;
  numberOfdays: number;
  todayDate = new Date();
  constructor() { }
  @Input('startDate') startDateShow: string;
  set startDate(startDate: string) {
    this.startDateShow = startDate;

  }
  @Input('endDate') endDateShow: string;
  set endDate(endDate: string) {
    this.endDateShow = endDate;

  }
  appUtilObj: AppUtil = new AppUtil();
  ngOnChanges(changes) {
    this.changed()

    console.log(this.startDateShow + " this is start date");
    console.log(this.endDateShow + " this is end date");

    //let arr=document.getElementsByClassName("glyphicon-triangle-bottom");
    //let elem: HTMLElement = <HTMLElement>document.getElementsByClassName('glyphicon-triangle-bottom');
    let getstartDate = this.startDateShow;
    console.log(" getstartDate>>>>>>>>>>>>>>>>>>>>>", getstartDate)
    let startDate = new Date(getstartDate);
    this.startDateShow = this.GetFormattedDate(startDate);

    let getEndDate = this.endDateShow;
    let endDate = new Date(getEndDate);
    this.endDateShow = this.GetFormattedDate(endDate);

    //console.log((endDate.getTime()-startDate.getTime()))
    let renew = endDate.getTime() - startDate.getTime();
    let aa = (renew * 30) / 100;
    //console.log( startDate.getDate() + 20);
    this.numberOfdays = ((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
    //var dateofRenew = new Date(a);
    console.log(this.numberOfdays + " number of days difference")
    let getRenewalday: number = Math.round(this.numberOfdays - 90);
    console.log(getRenewalday + " number of days difference")

    let getRenewDate = (startDate.getTime() + getRenewalday * 1000 * 60 * 60 * 24);
    let renewDate = new Date(getRenewDate);
    this.renewDateShow = this.GetFormattedDate(renewDate);
    //console.log((endDate.getTime()-startDate.getTime()))



    console.log(this.startDateShow)
    console.log(this.endDateShow)
    console.log(this.renewDateShow);
    this.policyTenureStatus(startDate);
  }

  public changed() {
    console.log("Data changed")
  }

  ngOnInit() {
    this.ngOnChanges;
    console.log("ngOnInit");

  }

  GetFormattedDate(date) {
    let todayTime = new Date();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let year = date.getFullYear();
    return day + "/" + month + "/" + year;
  }

  policyTenureStatus(startdate) {
    //let todayDate = new Date("2018-09-18T09:00:00");
    let todayDate = new Date(this.todayDate);
    //console.log(todayDate+" Todays Date");
    let completedDays: number = ((todayDate.getTime() - startdate.getTime()) / (1000 * 60 * 60 * 24));
    let onePercent: number = (this.numberOfdays * 1) / 100;
    //console.log(completedDays);
    let totalCompletedDuration: number = Math.round(completedDays / onePercent);
    //console.log("total complted "+ totalCompletedDuration +"%");

    if (totalCompletedDuration < 0) {

    } else {
      let moveSmiley = totalCompletedDuration * .53;
      console.log("moveSmiley " + moveSmiley)

      if (moveSmiley < 26) {
        let el = <HTMLElement>document.querySelector(".moversmiley");
        let smiley: number = 22.3 + moveSmiley;
        el.style.left = smiley + '%';
        //console.log(smiley+" less than 42")


      } else {
        let el = <HTMLElement>document.querySelector(".moversmiley");
        let smileygreater: number = 22.3 + moveSmiley;
        el.style.left = smileygreater + '%';
        //console.log(smileygreater+" greater than 42");

      }

    }



  }


  changeStartDate() {
    let getstart = '2017-09-18T09:00:00';

    let startDate = new Date(getstart);
    this.policyTenureStatus(startDate);
  }



}
