import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { PolicyWordingsComponent } from './policy-wordings.component';

const polWord: Routes = [
  { path: '', component: PolicyWordingsComponent },
];
@NgModule({
  imports: [
    RouterModule.forChild(polWord)
  ],
  exports: [
    RouterModule
  ]
})
export class PolicyWordingsRoutingModule { }
