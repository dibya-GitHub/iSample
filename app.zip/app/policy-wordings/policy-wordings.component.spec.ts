import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyWordingsComponent } from './policy-wordings.component';

describe('PolicyWordingsComponent', () => {
  let component: PolicyWordingsComponent;
  let fixture: ComponentFixture<PolicyWordingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolicyWordingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyWordingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
