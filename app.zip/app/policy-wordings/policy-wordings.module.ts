import { SharedModule } from './../shared.module';
import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { PolicyWordingsComponent } from './policy-wordings.component';
import { PolicyWordingsRoutingModule } from './policy-wordings-routing.module';


@NgModule({
    declarations: [
        PolicyWordingsComponent,
    ],
    imports: [
        PolicyWordingsRoutingModule,
        CommonModule,
        SharedModule,
    ],
})

export class PolicyWordingsModule { }