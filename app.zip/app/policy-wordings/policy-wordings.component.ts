import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import * as $ from 'jquery';

@Component({
  selector: 'app-policy-wordings',
  templateUrl: './policy-wordings.component.html',
  styleUrls: ['./policy-wordings.component.scss']
})
export class PolicyWordingsComponent implements OnInit {

  constructor(
    private router: Router,
    private meta: Meta,
    private titleService: Title
  ) {
    this.titleService.setTitle('Download Insurance Policy Wording | Insurance Documents | i-Insured');
    this.meta.addTag({ name: 'description', content: 'Check your policy information for the full list of your insurance covers. See your insurance policy wording for the terms and conditions regarding your cover.' });
    this.meta.addTag({ name: 'keywords', content: 'insurance covers, insurance policy wording, compare home contents insurance, dubai insurance company, insurance companies dubai, life insurance' });
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  scrollDown() {
    console.log('inside scrollDown function');
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }
}
