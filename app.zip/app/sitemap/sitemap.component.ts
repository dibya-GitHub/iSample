import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'app-sitemap',
    templateUrl: './sitemap.component.html',
    styleUrls: ['./sitemap.component.scss']
  })
  export class SitemapComponent {

    constructor() {

    }
  }