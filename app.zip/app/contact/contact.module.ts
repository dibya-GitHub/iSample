import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SharedModule } from './../shared.module';
import { ContactRoutingModule } from './contact-routing.module';
import { ContactComponent } from './contact.component';
import { RecaptchaFormsModule, RecaptchaModule, RecaptchaSettings, RECAPTCHA_SETTINGS } from 'ng-recaptcha';

@NgModule({
    declarations: [
        ContactComponent,
    ],
    imports: [
        ContactRoutingModule,
        CommonModule,
        SharedModule,
        RecaptchaModule,
        RecaptchaFormsModule,
    ],
})

export class ContactModule { }