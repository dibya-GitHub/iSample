import { Component, OnInit, ViewChild } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import * as $ from 'jquery';
import { RecaptchaComponent } from 'ng-recaptcha';
import { environment } from 'src/environments/environment';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { InsuranceService } from '../../shared/services/insurance.service';
import { ContactInformation } from './classes/contact-information';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  siteKey: any = environment.siteKey;
  @ViewChild('captcha') captcha: RecaptchaComponent;
  set: boolean = true;
  public contactInfo = new ContactInformation();
  location: string = "dubai";
  showModal: boolean = false;
  visibleAnimate: boolean = false;
  captchaErr: any;
  showCaptchaErr = false;
  constructor(
    private router: Router,
    private insuranceService: InsuranceService,
    private loaderService: LoaderService,
    private meta: Meta,
    private titleService: Title
  ) {
    this.titleService.setTitle('Contact | Best Insurance Company in UAE | i-Insured');
    this.meta.addTag({ name: 'description', content: 'If you have a question or want to find out which policies are best for you. Contact i-Insured the best insurance company in UAE.' });
    this.meta.addTag({ name: 'keywords', content: 'insurance brokers in dubai, health insurance in dubai, travel insurance dubai, list of insurance companies in dubai, insurance companies dubai, dubai insurance company,best cycle insurance company' });
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  ngOnInit() {
    this.siteKey = environment.siteKey;
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }

  submitContactInfo(contactInfo) {
    // if (this.captcha.execute) {
    //   this.captchaErr = 'Please Validate Captcha';
    //   this.showCaptchaErr = true;
    //   return false;
    // } else {
    //   this.showCaptchaErr = false;
    // }
    this.loaderService.display(true);
    console.log('contactInfo---');
    console.log(contactInfo);
    contactInfo["formType"] = "CUST_CARE";
    //update vehicle info
    this.insuranceService.submitContactUsInfo(contactInfo).subscribe((response: any) => {
      this.loaderService.display(false);
      console.log(response);
      if (response.respCode == "2000") {
        this.showModal = true;
        setTimeout(() => this.visibleAnimate = true, 100);
      }
    }, error => {

    });
  }

  hideModal() {
    var resetForm = <HTMLFormElement>document.getElementById("contactUsForm");
    //  console.log(resetForm);
    resetForm.reset();
    this.visibleAnimate = false;
    setTimeout(() => this.showModal = false, 300);
  }

  setLocation(temp) {
    this.set = (temp == 'Dubai') ? true : false;
  }
}
