import { ContactComponent } from './contact.component';

import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

const contactRoutes: Routes = [
    { path: '', component: ContactComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(contactRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class ContactRoutingModule { }
