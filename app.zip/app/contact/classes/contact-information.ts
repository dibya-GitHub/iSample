export class ContactInformation {
  name: string;
  emailId: string;
  suggestion: string;
}
