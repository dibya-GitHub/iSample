import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { DataService } from 'src/shared/services/data.service';
import { InsuranceService } from "src/shared/services/insurance.service";
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  url = "https://api.cognitive.microsoft.com/bingcustomsearch/v7.0/search?";
  status: boolean = false
  userLogin: boolean;
  disaplySearch = false;

  constructor(
    public router: Router,
    private data: DataService,
    private insuranceService: InsuranceService,
  ) { }

  ngOnInit() {
    let details = window.localStorage.getItem("userDetails");
    if (details) {
      this.userLogin = true;
      this.status = true;
    } else {
      this.userLogin = false;
      this.status = false;
    }
    this.data.getMessage().subscribe(data => {
      this.alertReceived(data)
    })
    // jQuery(document).on('click','html :not(.dropdown-toggle,.caret)',function(e) {

    //   jQuery('.navbar-collapse.in').collapse('hide');

    //   });

    $(document).on('click', 'body :not(.dropdown-toggle,.caret)', function () {
      // $('.navbar-collapse.in').collapse('hide');
    })
    $('body').on('click', 'input', function (e) {
      e.stopPropagation();
    })
    $(document).on('click', '.navbar-collapse.in', function (e) {
      if ($(e.target).is('a') && $(e.target).attr('class') != 'dropdown-toggle') {
        // $(this).collapse('hide');
      }

    });
    // jQuery(document).on('click','.navbar-collapse.in',function(e) {
    //   if( jQuery(e.target).is('a') && jQuery(e.target).attr('class') != 'dropdown-toggle' ) {
    //       jQuery(this).collapse('hide');

    //   }
    // });


  }
  closeMenu() {
    // jQuery('.navbar-collapse.in').collapse('hide');
  }
  public alertReceived(data: any) {
    if (data.type == "login") {
      this.status = data.data
    } else if (data.type == "userLogin") {
      this.userLogin = data.data
    }
  }

  checkLogin() {
    let details = window.localStorage.getItem("userDetails");
    setTimeout(() => {
      $('.addCustomColor').parent('#myPages').addClass('active');
    }, 100);
    if (this.userLogin && details) {
      this.router.navigate(["my-qic"]);
    } else {
      this.status = false;
      this.router.navigate(["login"])
    }
  }

  logoutUser() {
    window.localStorage.removeItem('userDetails');
    this.data.alert("login", false);
    this.data.alert("userLogin", false);
    if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == "/my-qic") {
      this.router.navigate(["/home"])
    }
  }

  search(value) {
    let val = { q: value };
    this.router.navigate(['/search'], { queryParams: val, skipLocationChange: true })
    // let params = {q: value, customconfig: 4195696862, responseFilter: 'Webpages', mkt: 'en-US', safesearch: 'Moderate'}
    // let searchUrl = this.url+"q={{value}}&customconfig=4195696862&responseFilter=Webpages&mkt=en-US&safesearch=Moderate"
  }
  searchFromDesk() {
    let val = $('#searchDeskTop').val();
    // if (val.trim().length > 0) {
    //   let value = { q: val };
    //   this.router.navigate(['/search'], { queryParams: value, skipLocationChange: true });
    //   $('#searchDeskTop').val('');
    //   $('#search').val('');
    //   this.disaplySearch = false;
    // }
  }
  searchByClick() {
    // if ($('#search').val().trim().length > 0) {
    //   this.search($('#search').val());
    // }
  }
  showHide(val) {
    if (val.trim().length > 0) {
      this.disaplySearch = true;
    }
  }
}
