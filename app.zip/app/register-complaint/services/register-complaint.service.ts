import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';

@Injectable({
  providedIn: 'root'
})
export class RegisterComplaintService {

  requestOption:any;
  baseUrl:any = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }


  registerComplaint(body: any, url: any) {
    return this.http.post(this.baseUrl + url, body, this.requestOption);
  }

  uploadComplaintDocument(formData: any) {
    // this.loaderService.display(true);
    let that = this;
    const xhr: XMLHttpRequest = new XMLHttpRequest();
    return new Promise((resolve, reject) => {

      const xhr = new XMLHttpRequest();
      xhr.open('POST', this.baseUrl + ApiUrls.UPLOAD_OTHER_DOC, true);
      let key = this.apiHeadersService.encodedKey;
      xhr.setRequestHeader("Authorization", "Basic " + key);
      xhr.setRequestHeader("company", '002');
      xhr.onreadystatechange = function () {
        // that.loaderService.display(false);
        if (xhr.readyState === 4) {
          console.log(xhr);
          if (xhr.status === 202) {
            resolve(JSON.parse(xhr.response));
          } else {
            reject(xhr.response);
          }
        }
      };
      xhr.send(formData);

    });
  }

}



