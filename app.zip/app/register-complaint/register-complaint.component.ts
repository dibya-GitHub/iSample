import { Component, OnInit, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterComplaintService } from './services/register-complaint.service';
import { InsuranceService } from '../../shared/services/insurance.service';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { ApiUrls } from '../../shared/api-urls';
import { Meta, Title } from '@angular/platform-browser';

@Component({
  selector: 'app-register-complaint',
  templateUrl: './register-complaint.component.html',
  styleUrls: ['./register-complaint.component.scss'],
})
export class RegisterComplaintComponent implements OnInit {
  personName: any;
  personEmail: any;
  personMobile: any;
  policy_number: number;
  contactMode = [{ id: "01", text: " Email" }, { id: "02", text: "Phone/Mobile" }, { id: "03", text: "Post" }];
  contactType: any = "";
  complainAbout: any = "";
  errorMsg: string = '';
  transId: string;
  totalWords = 3000;
  suggestion: any;
  claimYn: number = 0;
  custTypeYN: number = 1;
  otherComplain: string;
  public InformationForComplain: any;
  setFieldDisabled = false;
  setFieldDisabled2 = false;
  // declarations for upload docs start
  docCodeValue: string = '';
  photoName: any;
  allowedExtensions: any = [];
  fileExtension: any;
  fileExtensionError: boolean = false;
  fileExtensionMessage: any;
  imageURL: any = "";
  // transId: string;
  tranSrNo: string;
  driverLicenseImageURL: string = "";
  fileOneImageURL: string = "";
  fileTwoImageURL: string = "";
  fileThreeImageURL: string = "";
  uploadedDocumentsLength: number = 0;
  totalNumberOfDocuments: number = 3;
  errorMessage: string;
  checkboxValue: boolean = false;
  uploadCall: boolean = false;
  totalUplploadedDocuments: any = 0;
  totalApiCall: any = 0;
  CClaim: any;
  qCustomer: any;
  uploadDriversDivClass: string = "";

  // declarations for upload docs end
  //complaintAbout=['Car Insurance','Travel Insurance','Home Insurance','Personal Accident Insurance','Website','Claim Experience with us','Customer Support Query',' Other (specify below)'];
  complaintAbout = [{ id: "01", text: "Car Insurance" }, { id: "02", text: "Travel Insurance" }, { id: "03", text: "Home Insurance" }, { id: "04", text: "Personal Accident Insurance" }, { id: "05", text: "Website" }, { id: "06", text: "Claim Experience with us" }, { id: "07", text: "Customer Support Query" }, { id: "08", text: "Other (specify below)" }];
  imageInfoArray = [];
  constructor(
    private meta: Meta,
    private zone: NgZone,
    private router: Router,
    private titleService: Title,
    private loaderService: LoaderService,
    private registerComplaintService: RegisterComplaintService,
    private insurancePlanService: InsuranceService,
  ) {
    this.titleService.setTitle('Register Complaint | i-Insured Insurance Dubai');
    this.meta.addTag({ name: 'description', content: 'If you have a complaint please fill in the form. Attach the documents and pictures which you would like to share with us here.' });
    this.meta.addTag({ name: 'keywords', content: 'register complaints' });
  }

  ngOnInit() {
  }
  claiming(num: any) {
    this.claimYn = num;
  };

  custType(num: any) {
    this.custTypeYN = num;
  };

  // functions for upload document start
  getDocumentCodeBeforeUpload(event) {
    if (event == "fileOne") {
      this.docCodeValue = "001";
    } else if (event == "fileTwo") {
      this.docCodeValue = "001";
    } else if (event == "fileThree") {
      this.docCodeValue = "001";
    }
  }

  getBase64(file) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      console.log("onSuccess", reader.result);
    };
    reader.onerror = function (error) {
      console.log('Error: ', error);
    };
  }



  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    console.log("ImageURL");
    console.log(this.imageURL);
    console.log("file--------", file);



    this.getBase64(file);
    console.log(file.name);
    console.log("FUNCTION IS WORKING");

    if (file.type == 'application/pdf') {
      this.imageURL = './assets/images/Pdf-File-icon.png'
    }


    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    console.log("transId ===========", this.transId);

    formData.append('tranSrNo', '0');
    formData.append('docCode', this.docCodeValue);
    console.log("docCode=========", this.docCodeValue);

    formData.append('docType', "FEEDBACK")
    formData.append('userId', "online")

    console.log("formData", JSON.stringify(formData));
    if (this.uploadCall) {
      var uploadDocumentReponse = this.registerComplaintService.uploadComplaintDocument(formData);

      // return this.uploadCall=false;
      this.totalApiCall++;
      if (this.totalApiCall == this.totalUplploadedDocuments) {
        let obj = {
          "Is_complaint": true,
        }
        this.router.navigate(['thankyou'], { queryParams: obj, skipLocationChange: true });
      }

    }

    if (!this.uploadCall) {


      if (event.target.id == "fileOne" || doc == "fileOne") {
        if (this.fileOneImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.fileOneImageURL = this.imageURL;
      } else if (event.target.id == "fileTwo" || doc == "fileTwo") {
        if (this.fileTwoImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.fileTwoImageURL = this.imageURL;
      } else if (event.target.id == "fileThree" || doc == "fileThree") {
        if (this.fileThreeImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.fileThreeImageURL = this.imageURL;
      }

    }


  }


  // old code 

  onFilesChange(fileList) {
    let doc = fileList.evt.target.parentElement.parentElement.getElementsByTagName("input")[0].id;
    this.getDocumentCodeBeforeUpload(doc);
    this.fileExtensionError = false;
    this.fileExtensionMessage = "";
    let files = fileList.valid_files
    this.zone.run(() => {
      console.log("Upload Pictures");
      console.log(this.docCodeValue);
      if (files.length > 0) {
        let file: File = files[0];

        var reader = new FileReader();
        var that = this;
        if (doc == "fileOne") {
          this.imageInfoArray.splice(0, 1, { event: event, files: files, doc: doc });
        } else if (doc == "fileTwo") {
          this.imageInfoArray.splice(1, 1, { event: event, files: files, doc: doc });
        } else {
          this.imageInfoArray.splice(2, 1, { event: event, files: files, doc: doc });
        }

        this.totalUplploadedDocuments = this.imageInfoArray.length;
        console.log("this.totalUplploadedDocuments on fileChange", this.totalUplploadedDocuments);

        reader.onload = function () {
          that.imageURL = reader.result;
          that.upload(event, files, doc);
        }
        reader.readAsDataURL(files[0]);
      }

    });

  }

  invalidFiles(files) {
    if (files && files.length > 0) {
      this.fileExtensionMessage = "Only .png, .jpg, .jpeg, .bmp, .pdf, .docx,.png, .doc, .xlsx, .xls,.jfif allowed!!"
      this.fileExtensionError = true;
    }
  }

  /*- checks if word exists in array -*/
  isInArray(array, word) {
    console.log('inside in array function call');
    return array.indexOf(word.toLowerCase()) > -1;
  }

  uploadPicture(event: any) {
    console.log("inside upload picture function");
    //console.log("event target id ---");
    console.log("Id is -->", event.target.id);
    let Id = event.target.id;
    console.log("Event is====>", event);


    this.getDocumentCodeBeforeUpload(event.target.id);

    var fileDetail = event.target.files[0];
    this.photoName = fileDetail.name;

    this.allowedExtensions = ["png", "jpg", "jpeg", "bmp", "pdf", "docx", "png", "doc", "xlsx", "xls", "jfif"];
    this.fileExtension = this.photoName.split('.').pop();
    console.log(this.fileExtension);

    if (this.isInArray(this.allowedExtensions, this.fileExtension)) {
      console.log('inside if');
      this.fileExtensionError = false;
      this.fileExtensionMessage = "";
    } else {
      console.log('inside else');
      this.fileExtensionMessage = "Only .png, .jpg, .jpeg, .bmp, .pdf, .docx,.png, .doc, .xlsx, .xls,.jfif allowed!!"
      this.fileExtensionError = true;
      console.log(this.fileExtensionError);
      return;
    }

    this.zone.run(() => {
      console.log("Upload Pictures");
      console.log(this.docCodeValue);
      let fileList: FileList = event.target.files;
      if (fileList.length > 0) {
        let file: File = fileList[0];

        var reader = new FileReader();
        var that = this;
        if (Id == "fileOne") {
          this.imageInfoArray.splice(0, 1, { event: event, fileList: fileList, id: Id });
        } else if (Id == "fileTwo") {
          this.imageInfoArray.splice(1, 1, { event: event, fileList: fileList, id: Id });
        } else {
          this.imageInfoArray.splice(2, 1, { event: event, fileList: fileList, id: Id });
        }


        this.totalUplploadedDocuments = this.imageInfoArray.length;
        console.log("this.totalUplploadedDocuments on fileChange", this.totalUplploadedDocuments);
        reader.onload = function () {
          that.imageURL = reader.result;
          that.upload(event);
        }
        reader.readAsDataURL(fileList[0]);
      }
    });
  }


  changeCheckboxStatus(event) {
    console.log(event.target);
    if (event.target.checked) {
      this.errorMessage = "";
      this.checkboxValue = true;
    } else {
      this.checkboxValue = false;
    }
  }

  // functions for upload document end








  registerComplaint() {
    console.log("submit function is called");
    console.log("imageInfoArray", this.imageInfoArray);

    // this.router.navigate(['upload-claim-docs'], { skipLocationChange: true });

    // let postData = {
    //   name:this.personName,
    //   emailId:this.personEmail,
    //   mobileNo:this.personMobile,
    //   contactMode:this.contactType,
    //   custType:'1',
    //   claimYn:'1',
    //   fdbkCategory:this.complainAbout,
    //   otherCategory:'',
    //   remarks:'NA',
    //   userId:'online'
    // }


    let postData = {
      name: this.personName,
      contactMode: this.contactType,
      custType: this.custTypeYN,
      claimYn: this.claimYn,
      fdbkCategory: this.complainAbout,
      otherCategory: this.otherComplain,
      remarks: this.suggestion,
      emailId: this.personEmail,
      mobileNo: this.personMobile,
      policyNo: this.policy_number,
      userId: "online"
    }


    console.log("Post data", postData);
    this.loaderService.display(true);
    this.registerComplaintService.registerComplaint(postData, ApiUrls.COMPLAINT_LOG).subscribe((data: any) => {
      this.loaderService.display(false);
      let obj = {
        transId: data.transId
      }
      if (data.respCode == 2000) {
        this.transId = data.transId
        //  this.docCodeValue="001"

        // this.InformationForComplain=data
        //  
        this.uploadCall = true;
        console.log("this.imageInfoArray", this.imageInfoArray);


        if (this.imageInfoArray.length > 0) {

          for (i = 0; i < this.imageInfoArray.length; i++) {
            console.log("ankit-----");
            let event = this.imageInfoArray[i].event;
            let files = this.imageInfoArray[i].files;
            let doc = this.imageInfoArray[i].doc;

            this.upload(event, files, doc);
            this.getDocumentCodeBeforeUpload(doc);

            //this.upload();
          }
        } else {
          let obj = {
            "Is_complaint": true,
          }
          this.router.navigate(['thankyou'], { queryParams: obj, skipLocationChange: true });
        }




      } else {
        alert('error');
      }
    }, error => {
      let err = error.json();
      console.log(JSON.stringify(err));
      this.errorMsg = err.errMessage;
      this.loaderService.display(false);
    });
    // let doc="file three"
    let i;
    //console.log("length",this.imageInfoArray.length);


  }


}
