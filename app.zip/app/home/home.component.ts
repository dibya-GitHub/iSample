
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import * as $ from 'jquery';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, AfterViewInit {
  showModal: boolean = true;
  visibleAnimate: boolean = true;
  
  constructor(
    private meta: Meta,
    private titleService: Title
  ) {
    this.titleService.setTitle('i-Insured | Dubai Insurance Company - Car, Home, Travel & PAB');
    this.meta.addTag({ name: 'description', content: 'i-Insured, a leading insurance company in Dubai provides solutions for Car Insurance, Home Contents Insurance, Travel Insurance and Personal Accident Insurance.' });
    this.meta.addTag({ name: 'keywords', content: 'motor insurance, dubai home contents insurance, home contents insurance companies, insurance brokers in dubai, cycle insurance in UAE, health insurance in dubai, travel insurance dubai, compare insurance in uae' });
  }
  currentIndex: any = 1;
  buttonName: any = 'Check Home Offer';
  url: any = '/campaigns/home';
  selectedImageSrc = './assets/images/qic_campaign_home.png';
  title = 'Installment Campaign';
  subtitle = 'Dropped your phone in the middle of the road? Clumsy houseguest knock your vase down? Pesky and unexpected water damage with the pipe that burst? Insure your home content & personal possession and save yourself from the aftermath stress of dealing with these financial stresses';

  hideModal() {
    this.showModal = false;
    this.visibleAnimate = false;
  }

  ngOnInit() {

    this.initSlider();
    this.initSliderForMobile();
    this.showModal = false;

  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  afterChange(event) {
    this.currentIndex = $('.insta-wp.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }

  slideNews = {
    "slidesToShow": 3,
    "slidesToScroll": 3,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 736,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  };

  slideHighlights = {
    "slidesToShow": 5,
    "slidesToScroll": 5,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 3,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 2,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  };

  slideConfig = {
    "slidesToShow": 3,
    "slidesToScroll": 1,
    lazyLoad: 'ondemand',
    "dots": true,
    "infinite": true,
    "draggable": true,
    "responsive": [
      {
        breakpoint: 736,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": false,
          "prevArrow": false,
          "nextArrow": false,
          "centerMode": true,
          "centerPadding": '30px'
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": false,
          "nextArrow": false,
          "centerMode": true,
          "centerPadding": '30px'
        }
      }
    ]
  };




  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);
    });
  }
  initSlider() {
    var self = this;
    $(function () {
      $(".slick-dots button, .slick-next, .slick-prev, .triger-box").on("click", function () {
        setTimeout(function () {
          var title = $(".slick-current").find("h4").attr("id")
          switch (title) {
            case "first":
              self.subtitle = 'Dropped your phone in the middle of the road? Clumsy houseguest knock your vase down? Pesky and unexpected water damage with the pipe that burst? Insure your home content & personal possession and save yourself from the aftermath stress of dealing with these financial stresses';
              self.buttonName = 'Check Home Offer';
              self.url = '/campaigns/home';
              break;
            case "second":
              self.subtitle = 'Want to get the best insurance for your car? Is the premium feeling too much to pay in one shot? That’s fine. i-Insured have got your back! You can now get the very best, but pay for it in 4 monthly installments';
              self.buttonName = 'Check Car Offer';
              self.url = '/campaigns/car';
              break;
            case "third":
              self.subtitle = 'Lost your baggage? Fallen sick while traveling or even when your trip gets canceled. It is quite frustrating to deal with the fall out of these events when on holiday. We can’t change that experience, but we can make sure that you are compensated';
              self.buttonName = 'Check Travel Offer';
              self.url = '/campaigns/travel';
              break;
            default:
              self.subtitle = 'Accidents are unfortunate occasions that can drain you financially. We can’t save you but we can make dealing with that stress slightly easier with our personal accident insurance. Use this as an alternative source of income to take care of any need you may have after the accident';
              self.buttonName = 'Check PAB Offer';
              self.url = '/campaigns/pab';
              break;
          }
        }, 500);
      });
    })
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
  }

}
