import { NgModule } from '@angular/core';
import {
  RouterModule,
  Routes
} from '@angular/router';
import { AdvantageClubComponent } from '../app/advantage-club/advantage-club.component';
import { HomeInsuranceComponent } from '../app/home-insurance/home-insurance/home-insurance.component';
import { HomeComponent } from '../app/home/home.component';
import { PayInstallmentsComponent } from '../app/pay-installments/pay-installments.component';
import { SessionTimeoutComponent } from '../app/session-timeout/session-timeout.component';
import { AdditionalCarInfoComponent } from './car-insurance/additional-car-info/additional-car-info.component';
import { CarThankYouComponent } from './car-insurance/car-thank-you/car-thank-you.component';
import { FirstScreenMotorComponent } from './car-insurance/chassi-entry-and-details-form/first-screen-motor/first-screen-motor.component';
import { FirstScreenComponent } from './car-insurance/chassi-entry-and-details-form/first-screen/first-screen.component';
import { SecondScreenComponent } from './car-insurance/chassi-entry-and-details-form/second-screen/second-screen.component';
import { NiceCarProductComponent } from './car-insurance/nice-car-product/nice-car-product.component';
import { PersonalAndVehicleInfoComponent } from './car-insurance/personal-and-vehicle-info/personal-and-vehicle-info.component';
import { UploadDocumentsComponent } from './car-insurance/upload-documents/upload-documents.component';
import { TpclaimComponent } from './claims/non-qic/tpclaim/tpclaim.component';
import { FindActivePolicyComponent } from './claims/qic/find-active-policy/find-active-policy.component';
import { ReportclaimComponent } from './claims/qic/report-claim/reportclaim.component';
import { SubmitClaimComponent } from './claims/qic/submit-claim/submit-claim.component';
import { ThankyouComponent } from './claims/thankyou/thankyou.component';
import { AdditionalHomeInfoComponent } from './home-insurance/additional-home-info/additional-home-info.component';
import { BlogDetailsComponent } from './my-blog/blog-details/blog-details.component';
import { MyQicComponent } from './my-qic/my-qic/my-qic.component';
import { AdditionalPabInfoComponent } from './pab-insuarance/additional-pab-info/additional-pab-info.component';
import { PersonalAndFamilyInfoComponent } from './pab-insuarance/personal-and-family-info/personal-and-family-info.component';
import { ReferralComponent } from './referral/referral.component';
import { RetrieveCustInsuranceInfoComponent } from './renew-policy/retrieve-cust-insurance-info/retrieve-cust-insurance-info.component';
import { RetrieveCustInsurancePageComponent } from './renew-policy/retrieve-cust-insurance-page/retrieve-cust-insurance-page.component';
import { RetrieveCustInfoComponent } from './retrieve-quote/retrieve-cust-info/retrieve-cust-info.component';
import { SelectPlanComponent } from './select-plan/select-plan.component';
import { PersonalAndTravelInfoComponent } from './travel-insuarance/personal-and-travel-info/personal-and-travel-info.component';
import { UploadClaimsDocumentsComponent } from './claims/upload-claims-documents/upload-claims-documents.component';
import { PaymentSummaryComponent } from './payment-summary/payment-summary.component';
import { PolicyThankYouComponent } from './policy-thank-you/policy-thank-you.component';
import { ProgressBarComponent } from './progress-bar/progress-bar.component';
import { RegisterComplaintComponent } from './register-complaint/register-complaint.component';
import { SitemapComponent } from './sitemap/sitemap.component';
import { TelematicProductComponent } from './telematic/telematic-product/telematic-product.component';
import { AdditionalTravelInfoComponent } from './travel-insuarance/additional-travel-info/additional-travel-info.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent
  },
  { path: 'home-insurance', component: HomeInsuranceComponent },
  { path: 'additional-home-info', component: AdditionalHomeInfoComponent },
  { path: 'additional-travel-info', component: AdditionalTravelInfoComponent },
  { path: 'summary', component: PaymentSummaryComponent },
  { path: 'thank-you', component: CarThankYouComponent },
  { path: 'report-claim', component: ReportclaimComponent },
  { path: 'find-active-policy', component: FindActivePolicyComponent },
  { path: 'tp-claim', component: TpclaimComponent },
  { path: 'submit-claim', component: SubmitClaimComponent },
  { path: 'thankyou', component: ThankyouComponent },
  { path: 'policythankyou', component: PolicyThankYouComponent },
  { path: 'travel-insurance', component: PersonalAndTravelInfoComponent },
  { path: 'pab-insurance', component: PersonalAndFamilyInfoComponent },
  { path: 'additional-pab-info', component: AdditionalPabInfoComponent },
  { path: 'progressbar', component: ProgressBarComponent },
  { path: 'retrieve-cust-info', component: RetrieveCustInfoComponent },
  { path: 'retrieve-cust-insurance-info', component: RetrieveCustInsuranceInfoComponent },
  { path: 'retrieve-cust-insurance-page', component: RetrieveCustInsurancePageComponent },
  { path: 'select-plan', component: SelectPlanComponent },
  { path: 'upload-document', component: UploadDocumentsComponent },
  { path: 'my-qic', component: MyQicComponent },
  { path: 'session-timeout', component: SessionTimeoutComponent },
  { path: 'blog/:title', component: BlogDetailsComponent },
  { path: 'pay-installment', component: PayInstallmentsComponent },
  { path: 'advantage-club', component: AdvantageClubComponent },

  { path: 'referral', component: ReferralComponent },
  {
    path: 'car-insurance-product',
    loadChildren: () => import('./car-insurance/car-product/car-product.module').then((module) => module.CarProductModule),
  },

  {
    path: 'campaigns',
    loadChildren: () => import('./campaigns/campaigns.module').then((module) => module.CampaignsModule),
    data: { preload: true }
  },
  {
    path: 'home-insurance-product',
    loadChildren: () => import('./home-insurance/home-product/home-product.module').then((module) => module.HomeProductModule),
    data: { preload: true }

  },

  {
    path: 'travel-insurance-product',
    loadChildren: () => import('./travel-insuarance/travel-product/travel-product.module').then((module) => module.TravelProductModule),
    data: { preload: true }
  },
  {
    path: 'pab-insurance-product',
    loadChildren: () => import('./pab-insuarance/pab-product/pab-product.module').then((module) => module.PabProductModule),
    data: { preload: true }
  },

  {
    path: 'insurance-products',
    loadChildren: () => import('./product/product.module').then((module) => module.ProductModule),
    data: { preload: true }
  },
  {
    path: 'insurance-claims',
    loadChildren: () => import('./claims/claims.module').then((module) => module.ClaimsModule),
    data: { preload: true }
  },
  {
    path: 'blog',
    loadChildren: () => import('./my-blog/my-blog.module').then((module) => module.MyBlogModule),
    data: { preload: true }
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then((module) => module.LoginModule),
    data: { preload: true }
  },
  {
    path: 'contact-us',
    loadChildren: () => import('./contact/contact.module').then((module) => module.ContactModule),
    data: { preload: true }
  },
  {
    path: 'insurance-on-call',
    loadChildren: () => import('./insurance-on-call/insurance-on-call.module').then((module) => module.InsuranceOnCallModule),
    data: { preload: true }
  },
  {
    path: 'faq',
    loadChildren: () => import('./faq/faq.module').then((module) => module.FaqModule),
    data: { preload: true }
  },
  {
    path: 'policy-wordings',
    loadChildren: () => import('./policy-wordings/policy-wordings.module').then((module) => module.PolicyWordingsModule),
    data: { preload: true }
  },
  {
    path: 'easy-way',
    loadChildren: () => import('./easy-way/easy-way.module').then((module) => module.EasyWayModule),
    data: { preload: true }
  },
  {
    path: 'renew-policy',
    loadChildren: () => import('./renew-policy/renew-policy.module').then((module) => module.RenewPolicyModule),
    data: { preload: true }
  },
  {
    path: 'retrieve-quote',
    loadChildren: () => import('./retrieve-quote/retrieve-quote.module').then((module) => module.RetrieveQuoteModule),
    data: { preload: true }
  },
  {
    path: 'about-qic',
    loadChildren: () => import('./easy-way/easy-way.module').then((module) => module.EasyWayModule),
    data: { preload: true }
  },
  {
    path: 'carDetails',
    component: AdditionalCarInfoComponent
  },
  {
    path: 'car-insurance',
    component: FirstScreenMotorComponent
  },
  {
    path: 'chassi-second-screen',
    component: SecondScreenComponent
  },
  {
    path: 'safe-driver-product',
    component: TelematicProductComponent
  },
  {
    path: 'safe-driver',
    component: FirstScreenComponent
  },
  {
    path: 'car-insurance-without-chassi',
    component: PersonalAndVehicleInfoComponent
  },
  {
    path: 'register-complaint',
    component: RegisterComplaintComponent
  },

  {
    path: 'upload-claim-docs',
    component: UploadClaimsDocumentsComponent
  },
  {
    path: 'nicecar',
    component: NiceCarProductComponent
  },
  {
    path: 'sitemap',
    component: SitemapComponent
  },
  // {
  //   path: '**',
  //   redirectTo: '/home',
  //   pathMatch: 'full'
  // }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  providers: []

})
export class AppRoutingModule { }

