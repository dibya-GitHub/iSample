import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuranceOnCallComponent } from './insurance-on-call.component';

describe('InsuranceOnCallComponent', () => {
  let component: InsuranceOnCallComponent;
  let fixture: ComponentFixture<InsuranceOnCallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsuranceOnCallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsuranceOnCallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
