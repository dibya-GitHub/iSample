export class InsuranceInfo {
  name: string = "";
  emailId: string = "";
  mobileNo: string = "";
  callType: string = "";
  callFor: string = "";
  visitDate: any;
  visitFmTime: any;
  policyNo: string = "";
  visitToTime: string = "";
  address: string = "";
}
