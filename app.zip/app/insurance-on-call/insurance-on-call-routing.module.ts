import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { InsuranceOnCallComponent } from './insurance-on-call.component';

const insOnCall: Routes = [
    { path: '', component: InsuranceOnCallComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(insOnCall)
     ],
     exports: [
         RouterModule
     ]
})
export class InsuranceOnCallRoutingModule { }
