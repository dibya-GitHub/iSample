import { AfterViewChecked, Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as $ from 'jquery';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { InsuranceService } from '../../shared/services/insurance.service';
import { InsuranceInfo } from './classes/insurance-info';

@Component({
  selector: 'app-insurance-on-call',
  templateUrl: './insurance-on-call.component.html',
  styleUrls: ['./insurance-on-call.component.scss']
})
export class InsuranceOnCallComponent implements OnInit, AfterViewChecked {
  showMsg: boolean = false;
  public insuranceInfo: InsuranceInfo = new InsuranceInfo();
  showModal: boolean = false;
  visibleAnimate: boolean = false;
  isNewInsurance: boolean = true;
  discountJSONFileValue: any = {
    "car": 10,
    "home": 30,
    "pab": 10,
    "travel": 10
  };
  date: Date = new Date();
  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));
  public startDateOptions: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };
  constructor(
    private meta: Meta,
    private router: Router,
    private insuranceService: InsuranceService,
    private loaderService: LoaderService,
    private titleService: Title
  ) {
    this.titleService.setTitle('Insurance on Call | Arrange a Call Back | i-Insured');
    this.meta.addTag({ name: 'description', content: 'Insurance on call from i-Insured. Share your contact details with us and our expert advisers will assist you with all your insurance needs.' });
    this.meta.addTag({ name: 'keywords', content: 'insurance on call, one call insurance, qic home contents insurance, insurance purchase in dubai, motor insurance, dubai home contents insurance, home contents insurance companies' });
  }
  currentIndex: any = 1;

  ngOnInit() {
    window.scrollTo(0, 0);
  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  ngAfterViewChecked() {
  }
  afterChange(event) {
    this.currentIndex = $('.for-count.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  slideThreeItems = {
    "slidesToShow": 3,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }

  slideConfig = {
    "slidesToShow": 3,
    "dots": true,
    "infinite": true,
    "centerMode": true,
    "centerPadding": '0px',
    "variableWidth": true
  };
  insuranceOnCallSave(personInfo) {
    this.loaderService.display(true);
    if (this.isNewInsurance) {
      personInfo["callType"] = "001";
      personInfo["policyNo"] = "";
    } else {
      personInfo["callType"] = "002";
    }
    personInfo["callFor"] = "001";
    if (this.insuranceInfo.visitDate != null) {
      if (this.insuranceInfo.visitDate.epoc == undefined) {
        let temp = this.insuranceInfo.visitDate.split("/");
        let stringDate = temp[1] + "/" + temp[0] + "/" + temp[2];
        let date = new Date(stringDate).getTime();
        console.log(date);
        personInfo["visitDate"] = date;
      } else {
        personInfo["visitDate"] = this.insuranceInfo.visitDate.epoc * 1000;
      }
    }

    console.log('personInfo---');
    console.log(personInfo);
    this.insuranceService.submitInsuranceCallDetails(personInfo).subscribe((response: any) => {
      this.loaderService.display(false);
      console.log(response);
      if (response.respCode == "2000") {
        this.showModal = true;
        setTimeout(() => this.visibleAnimate = true, 100);
      }
    }, error => {

    });
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({ left: 0, top: 600, behavior: 'smooth' });
  }

  hideModal() {
    this.visibleAnimate = false;
    setTimeout(() => this.showModal = false, 300);
  }

  addButtonType() {
    $("button.owl-meridian-btn").prop("type", "button");
  }

  changeInsuranceType(event) {
    //console.log(event);

    if (event.target.id == "newInsurance") {
      this.isNewInsurance = true;
    } else if (event.target.id == "renewInsurance") {
      this.isNewInsurance = false;
    }
  }

  setLocalVal(val: any) {
    window.localStorage.setItem('type', val);
    this.router.navigate(['car-insurance']);
  }
  onDateInput(event) {

    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.insuranceInfo.visitDate = event.target.value;
        }
      }
    }

  }

  onDateChanged(event) {

    if (this.insuranceInfo.visitDate != undefined || this.insuranceInfo.visitDate == null) {
      this.showMsg = false;
      console.log(this.insuranceInfo.visitDate)
    }
    console.log(this.insuranceInfo.visitDate)
  }

}
