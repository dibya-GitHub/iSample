import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { AngularMyDatePickerModule } from 'angular-mydatepicker';
// import { OwlDateTimeModule } from 'ng-pick-datetime';
// import { OwlNativeDateTimeModule } from 'ng-pick-datetime/date-time';
import { SlickCarouselModule } from 'ngx-slick-carousel';

import { SharedModule } from './../shared.module';
import { InsuranceOnCallRoutingModule } from './insurance-on-call-routing.module';
import { InsuranceOnCallComponent } from './insurance-on-call.component';

@NgModule({
    declarations: [
        InsuranceOnCallComponent,
    ],
    imports: [
        InsuranceOnCallRoutingModule,
        AngularMyDatePickerModule,
        // DateTimePickerModule,
        CommonModule,
        SharedModule,
        SlickCarouselModule,
        // OwlDateTimeModule,
        // OwlNativeDateTimeModule,
    ],
})

export class InsuranceOnCallModule { }