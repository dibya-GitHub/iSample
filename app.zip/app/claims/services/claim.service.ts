import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';
import { RegistrationLocationList } from '../../car-insurance/interfaces/vehicle-details';

@Injectable({
  providedIn: 'root'
})
export class ClaimService {

  requestOption:any;
  baseUrl:any = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  getActivePolList(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_ACTIVE_POL_LIST, body, this.requestOption);
  }
  getPolicyVehicleInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_VEHICLE_INFO, body, this.requestOption);
  }
  registerClaim(body: any, url: any) {
    //console.log(url);
    return this.http.post(this.baseUrl + url, body, this.requestOption);
  }
  getRegistrationLocationList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_REGISTRATION_LIST_URL, body, this.requestOption);
  }

}
