import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from './../shared.module';
import { ClaimsRoutingModule } from './claims-routing.module';
import { ClaimsComponent } from './claims/claims.component';


@NgModule({
    declarations: [
        ClaimsComponent,
    ],
    imports: [
        ClaimsRoutingModule,
        CommonModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule
    ],
})

export class ClaimsModule { }