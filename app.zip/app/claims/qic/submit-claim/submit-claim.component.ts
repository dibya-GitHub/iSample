import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as $ from 'jquery';
import { RegistrationLocation } from "src/shared/classes/registration-location";
import { AppUtil } from '../../../../shared/app-util';
import { LoaderService } from '../../../../shared/loader-service/loader.service';
import { InsuranceService as CommonService } from '../../../../shared/services/insurance.service';
import { ClaimService } from '../../services/claim.service';

@Component({
  selector: 'app-submit-claim',
  templateUrl: './submit-claim.component.html',
  styleUrls: ['./submit-claim.component.scss']
})
export class SubmitClaimComponent implements OnInit {
  showMsg: boolean = false;
  txnId: any;
  srNo: any;
  polNo: any;
  startDate: any;
  postDate: any;
  insuredData: any;
  registrationNo: any;
  placeOfAccdnt: any;
  mobile: any;
  email: any;
  policeRefNo: any;
  towingYN: number = 0;
  clmRefNo: any;
  appUtilObj: AppUtil = new AppUtil();
  routeData: any;
  date: Date = new Date();
  transId: any;
  tranSrNo: any;
  anyDate: any;
  searchBy: any;
  registration_locations: RegistrationLocation[];
  public startDateOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    },
    disableUntil: {
      year: new Date().getFullYear() - 3,
      month: this.date.getMonth() + 1,
      day: this.date.getDate()
    }
  };
  errorMsg: string = '';
  anyLoc: string = "";
  testRegisterationNo: string = "";
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private claimService: ClaimService,
    private loaderService: LoaderService,
    private commonService: CommonService
  ) {
    this.route.queryParams.subscribe(params => {
      this.routeData = params
      //this.searchBy=params["searchBy"];
      this.txnId = params["id"];
      this.srNo = params["srNo"];
      this.polNo = params["polNo"];
      // code to show info after back
      this.policeRefNo = params["policeRefNo"];
      //this.startDate = params["acciDate"];
      if (params["acciDate"] != undefined) {
        this.anyDate = new Date(params["acciDate"]);
        // this.postDate= this.anyDate;
        this.postDate = params["acciDate"];
        this.startDate = {
          "day": this.anyDate.getDate(),
          "month": (this.anyDate.getMonth() + 1),
          "year": this.anyDate.getFullYear(),
          "formatted": this.appUtilObj.appendZero(this.anyDate.getDate()) + '/' + this.appUtilObj.appendZero((this.anyDate.getMonth() + 1)) + '/' + this.anyDate.getFullYear(),
        };
        //, "formatted": "05.01.2017", "momentObj": "2017-01-04T23:00:00.000Z"
      }
      //this.placeOfAccdnt = params["accidentLoc"];
      if (params["accidentLoc"] != undefined) {
        this.anyLoc = params["accidentLoc"];
      }
      if (params["towingYN"] != undefined) {
        this.towingYN = params["towingYN"];
      }
      this.email = params["emailId"];
      this.mobile = params["mobileNo"];
      this.testRegisterationNo = params["vehRegnNo"];
      //this.towingYN = params["towingYN"];
      //this.transId = params["txnId"];
      //this.tranSrNo = params["srNo"];
      //this.polNo = params["polNo"];
    });
  }

  ngOnInit() {
    this.loaderService.display(true);
    $('.container').hide();
    let date: Date = new Date();
    window.scrollTo(0, 0);
    this.getPolicyVehicleInfo();
    this.setRegLocationList();
  }
  getPolicyVehicleInfo() {
    let postData = {
      transId: this.txnId,
      tranSrNo: this.srNo
    }
    //this.loaderService.display(true);
    //console.log(JSON.stringify(postData));
    this.claimService.getPolicyVehicleInfo(postData).subscribe((data: any) => {
      this.loaderService.display(false);
      $('.container').show();
      if (this.testRegisterationNo != undefined || this.testRegisterationNo != null) {
        this.registrationNo = this.testRegisterationNo;
      }
      else {
        this.registrationNo = data.regnNo;
      }

    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
      $('.container').show();
    });
  }
  changeAccidentDate(event: any) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsg = false;
      //console.log(this.startDate)
    }
    this.startDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
    this.postDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
  }

  insuredClaimData() {
    let insuredData = {
      policyNo: this.polNo,
      acciDate: this.postDate,
      policeRefNo: this.policeRefNo,
      emailId: this.email,
      mobileNo: this.mobile,
      vehRegnNo: this.registrationNo,
      accidentLoc: this.placeOfAccdnt,
      towingYN: this.towingYN,
      txnId: this.txnId,
      srNo: this.srNo,
      searchBy: this.routeData["searchBy"],
      value: this.routeData["value"],
      Is_I_Insured: true
    }
    this.router.navigate(['upload-claim-docs'], { queryParams: insuredData, skipLocationChange: true });
  }

  towing() {
    //this.towingYN = num;
    this.towingYN = this.towingYN;
  }
  goToPreviousPage() {
    this.router.navigate(['find-active-policy'], { queryParams: this.routeData, skipLocationChange: true });
  }
  /*setting registration locations*/
  setRegLocationList() {
    let location = { "type": "REGN_LOC" }
    this.claimService.getRegistrationLocationList(location)
      .subscribe(result => {
        this.registration_locations = result.appCodesArray;
        this.placeOfAccdnt = this.anyLoc;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  onDateInput(event) {

    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.startDate = event.target.value;
        }
      }
    }
  }
}
