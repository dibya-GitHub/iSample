import { Component, OnInit } from '@angular/core';
import { ClaimService } from '../../services/claim.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../../../shared/loader-service/loader.service';
import { AppUtil } from '../../../../shared/app-util';
import { DatePipe } from "@angular/common";
import * as $ from 'jquery';
import { AnyMxRecord } from 'dns';

@Component({
  selector: 'app-find-active-policy',
  templateUrl: './find-active-policy.component.html',
  styleUrls: ['./find-active-policy.component.scss']
})
export class FindActivePolicyComponent implements OnInit {

  activePolicyArray: any[];
  txnNo: any;
  srNo: any;
  polNo: any;
  selectOrConfirm: string;
  errorMessage: string = '';
  showDiv: boolean = false;
  errorMsg: string = '';
  appUtilObj: AppUtil = new AppUtil();
  routeData: any;
  datePipe:DatePipe;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private claimService: ClaimService,
    private loaderService: LoaderService
  ) {
    this.datePipe = new DatePipe('en-US');
    this.route.queryParams.subscribe(params => {
      this.routeData = params;
      if (params['searchBy'] == 'TPI_CIVIL_ID') {
        this.selectOrConfirm = 'Select your policy';
      }
      else {
        this.selectOrConfirm = 'Confirm your policy';
      }
      this.claimService.getActivePolList(params).subscribe((data:any) => {
        if (data.errMessage == "No Records Found") {
          this.errorMessage = data.errMessage;
          this.showDiv = true;
        } else {
          this.activePolicyArray = this.appUtilObj.sortArrayByPolicyStartDateDesc(data.activePolicyArray);           
          console.log(JSON.stringify(this.activePolicyArray));
          this.errorMessage = '';
        }
        this.showDiv = true;
        this.loaderService.display(false);
        $('.container').show();
      }, error => {
        this.errorMessage = "No Records Found";
        this.showDiv = true;
        this.loaderService.display(false);
        $('.container').show();
      });
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  ngOnInit() {
    window.scrollTo(0, 0);
    this.loaderService.display(true);
    $('.container').hide();
  }
  setSrAndTxn(txn_id: any, sr_no: any, polNo: any) {
    this.txnNo = txn_id;
    this.srNo = sr_no;
    this.polNo = polNo;
  }
  getClaim(txn_id: any, sr_no: any, polNo: any) {
    this.txnNo = txn_id;
    this.srNo = sr_no;
    this.polNo = polNo;
    this.submitClaim();
  }
  submitClaim() {
    let obj = {
      id: this.txnNo,
      srNo: this.srNo,
      polNo: this.polNo,
      searchBy: this.routeData["searchBy"],
      value: this.routeData["value"]
    }
    if (this.txnNo === undefined && this.srNo === undefined)
      alert('Please select a policy');
    else
      this.router.navigate(['submit-claim'], { queryParams: obj, skipLocationChange: true });
  }
  goToPreviousPage() {
    this.router.navigate(['report-claim'], { queryParams: this.routeData, skipLocationChange: true });
  }
}
