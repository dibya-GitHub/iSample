import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindActivePolicyComponent } from './find-active-policy.component';

describe('FindActivePolicyComponent', () => {
  let component: FindActivePolicyComponent;
  let fixture: ComponentFixture<FindActivePolicyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindActivePolicyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindActivePolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
