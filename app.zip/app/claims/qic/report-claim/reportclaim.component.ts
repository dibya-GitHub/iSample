import { Component, OnInit } from '@angular/core';
import { ClaimService } from '../../services/claim.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Meta, Title } from '@angular/platform-browser';

@Component({
  selector: 'app-reportclaim',
  templateUrl: './reportclaim.component.html',
  styleUrls: ['./reportclaim.component.scss']
})
export class ReportclaimComponent implements OnInit {
  emiratedId: any;
  policyNo: any;
  searchBy: string;
  tmpData: any;
  showError = false;
  showErrorMsg: any;
  constructor(
    private meta: Meta,
    private router: Router,
    private route: ActivatedRoute,
    private claimService: ClaimService,
    private titleService: Title
  ) {
    this.titleService.setTitle('Report Insurance Claims | i-Insured Insurance Dubai');
    this.meta.addTag({ name: 'description', content: 'At i-Insured, we make it easy to report and track your insurance claims. Visit the site to report or track your insurance claims!' });
    this.meta.addTag({ name: 'keywords', content: 'qic travel insurance, qic car insurance, qic home contents insurance, car insurance online quotes, home Insurance Quotes, travel insurance quotes, health insurance prices, compare insurance uae' });
    this.route.queryParams.subscribe(params => {
      // this.txnId = params["id"];
      // this.srNo = params["srNo"];
      // this.polNo = params["polNo"];
      let data = params["searchBy"];
      if (data != undefined) {
        this.searchBy = data;
        if (data == 'TPI_CIVIL_ID') {
          this.emiratedId = params["value"];
        } else {
          this.policyNo = params["value"];
        }
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
  }

  getActivePolicyList() {
    if ((this.emiratedId === undefined || this.emiratedId.trim() == '') && (this.policyNo === undefined || this.policyNo.trim() == '')) {
      this.showErrorMsg = 'Please enter policy no or emirates id';
      this.showError = true;
    } else {
      if (this.emiratedId != '') {
        this.tmpData = this.emiratedId;
      }
      if (this.policyNo) {
        this.tmpData = this.policyNo;
      }
      this.tmpData = this.tmpData.trim();
      let obj = { searchBy: this.searchBy, value: this.tmpData }
      this.router.navigate(['find-active-policy'], { queryParams: obj, skipLocationChange: true });
    }
  }
  emirated() {
    if (this.emiratedId.length >= 1) {
      this.policyNo = '';
      this.searchBy = 'TPI_CIVIL_ID';
    }
  }
  policy() {
    if (this.policyNo.length >= 1) {
      this.emiratedId = '';
      this.searchBy = 'TPI_POLICY_NO';
    }
  }
}
