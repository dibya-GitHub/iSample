import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportclaimComponent } from './reportclaim.component';

describe('ReportclaimComponent', () => {
  let component: ReportclaimComponent;
  let fixture: ComponentFixture<ReportclaimComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportclaimComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportclaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
