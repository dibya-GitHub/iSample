import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-thankyou',
  templateUrl: './thankyou.component.html',
  styleUrls: ['./thankyou.component.scss']
})
export class ThankyouComponent implements OnInit {
  currentPathName: any;
  is_complaint: boolean = false;
  constructor(
    private route: ActivatedRoute
  ) {
    this.route.queryParams.subscribe(params => {
      this.is_complaint = params["is_complaint"];
      console.log("is_complaint", this.is_complaint);
    });
    console.log("current log is ", window.location.pathname);
    this.currentPathName = window.location.pathname;
  }
  ngOnInit() {
    window.scrollTo(0, 0);
  }
}
