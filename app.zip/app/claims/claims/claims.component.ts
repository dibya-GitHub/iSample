import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import * as $ from 'jquery';
@Component({
  selector: 'app-claims',
  templateUrl: './claims.component.html',
  styleUrls: ['./claims.component.scss']
})
export class ClaimsComponent implements OnInit {

  constructor(
    private meta: Meta,
    private titleService: Title
  ) {
    this.titleService.setTitle('Insurance Claim in Dubai | Submit Insurance Claim Online | i-Insured');
    this.meta.addTag({ name: 'description', content: 'For i-Insured insurance claims, submit your personal & car details in the form with the required documents. Get a quote now for insurance claims!' });
    this.meta.addTag({ name: 'keywords', content: 'insurance claim, accident insurance plan, travel insurance plan, home contents insurance quote, health plan, compare insurance uae, medical insurance plans, travel insurance quote, vehicle insurance quotes' });
  }
  currentIndex: any = 1;
  ngOnInit() {
    window.scrollTo(0, 0);
  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  afterChange(event) {
    this.currentIndex = $('.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '40px',
          slidesToShow: 3
        }
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '40px',
          slidesToShow: 1
        }
      }
    ]
  };



  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
  }

}
