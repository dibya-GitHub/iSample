import { ClaimsComponent } from './claims/claims.component';
import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

const claimsRoutes: Routes = [
    { path: '', component: ClaimsComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(claimsRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class ClaimsRoutingModule { }
