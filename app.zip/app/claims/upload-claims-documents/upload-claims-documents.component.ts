import { Component, NgZone, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiUrls } from '../../../shared/api-urls';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { ClaimService } from '../services/claim.service';

@Component({
  selector: 'app-upload-claims-documents',
  templateUrl: './upload-claims-documents.component.html',
  styleUrls: ['./upload-claims-documents.component.scss']
})

export class UploadClaimsDocumentsComponent implements OnInit {
  docCodeValue: string = '';
  uploadDriversDivClass: string = "";
  vechileRegistrationDivClass: string = "";
  uploadPoliceReportDivClass: string = "";
  photoName: any;
  allowedExtensions: any = [];
  fileExtension: any;
  fileExtensionError: boolean = false;
  fileExtensionMessage: any;
  imageURL: any = "";
  transId: string;
  clmRefNo: string;
  tranSrNo: string;
  driverLicenseImageURL: string = "";
  driverLicenseFrontImageURL: string = "";
  driverLicenseBackImageURL: string = "";
  policeReportImageURL: string = "";
  emiratesIdImageURL: string = "";
  licenseImageURL: string = "";
  vlicenseFrontImageURL: string = "";
  vlicenseBackImageURL: string = "";
  agencyQuotationImageURL: string = "";
  errorMsg: string = '';
  uploadedDocumentsLength: number = 0;
  totalNumberOfDocuments: number = 5;
  errorMessage: string;
  checkboxValue: boolean = false;

  policeRefNo: string = "";
  postDate: string = "";
  placeOfAccdnt: string = "";
  email: string = "";
  mobile: string = "";
  registrationNo: string = "";
  vehMakerid: string = "";
  vehModelsid: string = "";
  vehMakerText: string = "";
  vehModelsText: string = "";
  manfYear: string = "";
  claimantName: string = "";
  policy_number: string = "";
  Is_I_Insured: any;

  //for i insured
  acciDate: any;
  emailId: any;
  accidentLoc: any;
  mobileNo: any;
  vehRegnNo: any;
  towingYN: any;
  id: any;
  srNo: any;
  polNo: any;
  searchBy: any;
  value: any;
  currentPathName: string;
  accidentDate: any;
  vehLocation: any;
  vehMake: any;
  vehModel: any;
  modelYear: any;
  name: any;
  appUtilObj: AppUtil = new AppUtil();
  myErrorMess: any;
  claimDocsImageArray = new Array(5);
  uploadCall: boolean = false;
  uploadNameFlag: boolean = false;
  txnId: any;
  routeData: any;
  fileNameList = [];
  myMap = new Map();
  map1 = new Map();
  policeReportList = [];
  driverLicenseFrontList = [];
  driverLicenseBackList = [];
  vehicleLicenseFront = [];
  vehicleLicenseBack = [];

  constructor(
    private zone: NgZone,
    private router: Router,
    private route: ActivatedRoute,
    private insurancePlanService: InsuranceService,
    private loaderService: LoaderService,
    private claimService: ClaimService
  ) {

    this.route.queryParams.subscribe(params => {
      this.Is_I_Insured = params["Is_I_Insured"];
      if (!this.Is_I_Insured) {

        //this.clmRefNo = params["clmRefNo"];
        this.policeRefNo = params["policeRefNo"];
        this.accidentDate = params["accidentDate"];
        // this.postDate = params["postDate"];
        this.vehLocation = params["vehLocation"];
        this.emailId = params["emailId"];
        this.mobileNo = params["mobileNo"];
        this.vehRegnNo = params["vehRegnNo"];
        this.vehMake = params["vehMake"];
        this.vehModel = params["vehModel"];
        this.vehMakerText = params["vehMakerText"];
        this.vehModelsText = params["vehModelsText"];
        this.modelYear = params["modelYear"];
        this.name = params["name"];
        this.policy_number = params["policy_number"];

      } else {
        this.polNo = params["policyNo"];
        this.acciDate = params["acciDate"];
        this.policeRefNo = params["policeRefNo"];
        this.emailId = params["emailId"];
        this.mobileNo = params["mobileNo"];
        this.accidentLoc = params["accidentLoc"];
        this.vehRegnNo = params["vehRegnNo"];
        this.towingYN = params["towingYN"];
        this.id = params["txnId"];
        this.srNo = params["srNo"];
        this.searchBy = params["searchBy"];
        this.value = params["value"];
        // this.routeData = params["routeData"];
      }
    });

    this.currentPathName = window.location.pathname;
    console.log("this.currentPathName", this.currentPathName);
  }

  ngOnInit() {
  }

  goToPreviousPage() {
    if (!this.Is_I_Insured) {
      var obj = {
        "policeRefNo": this.policeRefNo,
        "postDate": this.accidentDate,
        "placeOfAccdnt": this.vehLocation,
        "email": this.emailId,
        "mobile": this.mobileNo,
        "registrationNo": this.vehRegnNo,
        "vehMakerid": this.vehMake,
        "vehModelsid": this.vehModel,
        "vehMakerText": this.vehMakerText,
        "vehModelsText": this.vehModelsText,
        "manfYear": this.modelYear,
        "claimantName": this.name,
        "policy_number": this.policy_number,
        "clmRefNo": ""
      }
      console.log('Object is', obj);
      this.router.navigate(['tp-claim'], { queryParams: obj, skipLocationChange: true });
    } else {

      var iObj = {
        "policeRefNo": this.policeRefNo,
        "acciDate": this.acciDate,
        "accidentLoc": this.accidentLoc,
        "emailId": this.emailId,
        "mobileNo": this.mobileNo,
        "vehRegnNo": this.vehRegnNo,
        "towingYN": this.towingYN,
        "id": this.id,
        "srNo": this.srNo,
        "polNo": this.polNo,
        "searchBy": this.searchBy,
        "value": this.value


      }
      console.log('Object is=', iObj);
      this.router.navigate(['submit-claim'], { queryParams: iObj, skipLocationChange: true });
    }

    //console.log('Object is', obj);
    //this.router.navigate(['tp-claim'], { queryParams:obj , skipLocationChange: true });


  }



  getDocumentCodeBeforeUpload(event) {
    console.log("event=>" + event);
    if (event == "policeReport") {
      this.docCodeValue = "013";
    } else if (event == "driverLicenseFront") {
      this.docCodeValue = "007";
    } else if (event == "driverLicenseBack") {
      this.docCodeValue = "00701";
    } else if (event == "vehicleLicense") {
      this.docCodeValue = "008";
    } else if (event == "vehicleLicenseFront" || event == "vCardFront") {
      this.docCodeValue = "008";
    } else if (event == "vehicleLicenseBack" || event == "vCardBack") {
      this.docCodeValue = "043";
    }
    console.log("Doc Code=>" + this.docCodeValue);
    return this.docCodeValue;
  }

  upload(event: any, files?: any, doc?: any, docCode?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    let fileNameFlag = true;
    //console.log("ImageURL");
    //console.log(this.imageURL);
    //console.log(file);
    if (!this.uploadNameFlag) {
      for (var i = 0; i < this.fileNameList.length; i++) {
        if (file.name == this.fileNameList[i]) {
          alert('Same file already been selected, Please rename the file and upload');
          fileNameFlag = false;
        }
      }
    }
    if (fileNameFlag) {
      if (this.docCodeValue === "013") {
        this.policeReportList.push(file.name);
        if (this.policeReportList.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "007") {
        this.driverLicenseFrontList.push(file.name);
        if (this.driverLicenseFrontList.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "00701") {
        this.driverLicenseBackList.push(file.name);
        if (this.driverLicenseBackList.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "008") {
        this.vehicleLicenseFront.push(file.name);
        if (this.vehicleLicenseFront.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "043") {
        this.vehicleLicenseBack.push(file.name);
        if (this.vehicleLicenseBack.length === 1) {
          fileNameFlag = true;
        }
      }
    }
    if (fileNameFlag) {
      if (this.docCodeValue === "013") {
        if (this.policeReportList.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.policeReportList[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.policeReportList.shift();
        }
      } else if (this.docCodeValue === "007") {
        if (this.driverLicenseFrontList.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            //if(this.driverLicenseFrontList[i] === this.fileNameList[i]){
            var index = this.fileNameList.indexOf(this.driverLicenseFrontList[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
            //  this.fileNameList.splice(this.driverLicenseFrontList[0],1);
            //}
          }
          this.driverLicenseFrontList.shift();
        }
      } else if (this.docCodeValue === "00701") {
        if (this.driverLicenseBackList.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.driverLicenseBackList[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.driverLicenseBackList.shift();
        }
      } else if (this.docCodeValue === "008") {
        if (this.vehicleLicenseFront.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.vehicleLicenseFront[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.vehicleLicenseFront.shift();
        }
      } else if (this.docCodeValue === "043") {
        if (this.vehicleLicenseBack.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.vehicleLicenseBack[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.vehicleLicenseBack.shift();
        }
      }
      for (var i = 0; i < this.fileNameList.length; i++) {
        if (file.name === this.fileNameList[i]) {
          this.fileNameList.splice(i, 1);
          fileNameFlag = false;
        }
      }
      this.fileNameList.push(file.name);
    }

    let uniqueChars = this.fileNameList.filter((c, index) => {
      return this.fileNameList.indexOf(c) === index;
    });
    this.fileNameList = uniqueChars

    if (file.type == 'application/pdf') {
      this.imageURL = './assets/images/Pdf-File-icon.png'
    }
    formData.append('fileObject', file, file.name);
    //formData.append('transId', this.transId);
    formData.append('transId', this.clmRefNo);

    formData.append('tranSrNo', "0");

    formData.append('docCode', ((docCode) ? docCode : this.docCodeValue));
    formData.append('userId', "online");
    console.log(fileNameFlag);
    if (fileNameFlag) {

      if (this.uploadCall) {
        // var uploadDocumentReponse = this.insurancePlanService.uploadClaimDocument(formData).subscribe(data => {
        //   this.loaderService.display(false);
        //   console.log("Data is===> ", data);
        // }, error => {
        //   let err = error.json();
        //   //console.log(JSON.stringify(err));
        //   this.errorMsg = err.errMessage;
        //   this.loaderService.display(false);
        // });
      }
    }



    if (!this.uploadCall && fileNameFlag) {

      if (event.target.id == "policeReport" || doc == "policeReport") {
        if (this.policeReportImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.policeReportImageURL = this.imageURL;
      } else if (event.target.id == "driverLicenseFront" || doc == "driverLicenseFront") {
        if (this.driverLicenseFrontImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.driverLicenseFrontImageURL = this.imageURL;
      } else if (event.target.id == "driverLicenseBack" || doc == "driverLicenseBack") {
        if (this.driverLicenseBackImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.driverLicenseBackImageURL = this.imageURL;
      } else if (event.target.id == "vCardFront" || doc == "vCardFront") {
        if (this.vlicenseFrontImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        // test
        this.vlicenseFrontImageURL = this.imageURL;

      } else if (event.target.id == "vCardBack" || doc == "vCardBack") {
        if (this.vlicenseBackImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.vlicenseBackImageURL = this.imageURL;

      }
    }


  }
  onClick(e) {
    event.target["value"] = '';
  }


  onFilesChange(fileList) {
    let doc = fileList.id;
    this.getDocumentCodeBeforeUpload(doc);
    this.fileExtensionError = false;
    this.fileExtensionMessage = "";
    let files = fileList.valid_files
    this.zone.run(() => {
      ////console.log("Upload Pictures");
      ////console.log(this.docCodeValue);
      if (files.length > 0) {
        //console.log(files.length);
        //console.log(doc);
        let file: File = files[0];

        if (doc == "policeReport") {
          this.claimDocsImageArray.splice(0, 1, { event: event, files: files, doc: doc });
        } else if (doc == "driverLicenseFront") {
          this.claimDocsImageArray.splice(1, 1, { event: event, files: files, doc: doc });
        } else if (doc == "driverLicenseBack") {
          this.claimDocsImageArray.splice(2, 1, { event: event, files: files, doc: doc });
        } else if (doc == "vCardFront") {
          this.claimDocsImageArray.splice(3, 1, { event: event, files: files, doc: doc });
        } else if (doc == "vCardBack") {
          this.claimDocsImageArray.splice(4, 1, { event: event, files: files, doc: doc });
        }

        console.log("claimDocsImageArray", this.claimDocsImageArray);
        var reader = new FileReader();
        var that = this;
        reader.onload = function () {
          that.imageURL = reader.result;
          that.upload(event, files, doc);
        }
        reader.readAsDataURL(files[0]);
        if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
          this.errorMessage = '';
        }
      }

    });

  }
  invalidFiles(files) {
    //files.preventDefault();
    if (files && files.length > 0) {
      this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
      this.fileExtensionError = true;
    }
  }

  /*- checks if word exists in array -*/
  isInArray(array, word) {
    ////console.log('inside in array function call');
    return array.indexOf(word.toLowerCase()) > -1;
  }

  uploadPicture(event: any) {
    //////console.log("inside upload picture function");
    ////console.log("event target id ---");
    console.log(event.target.id);
    let Id = event.target.id;
    this.getDocumentCodeBeforeUpload(event.target.id);
    if (event.target.files && (event.target.files.length > 0) && event.target.files[0]) {

      var fileDetail = event.target.files[0];
      this.photoName = fileDetail.name;

      this.allowedExtensions = ["jpeg", "jpg", "bmp", "gif", "png", "pdf"];
      this.fileExtension = this.photoName.split('.').pop();
      //console.log(this.fileExtension);

      if (this.isInArray(this.allowedExtensions, this.fileExtension)) {
        //console.log('inside if');
        this.fileExtensionError = false;
        this.fileExtensionMessage = "";
      } else {
        //console.log('inside else');
        this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
        this.fileExtensionError = true;
        //console.log(this.fileExtensionError);
        return;
      }

      this.zone.run(() => {
        //console.log("Upload Pictures");
        //console.log(this.docCodeValue);
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
          let file: File = fileList[0];

          var reader = new FileReader();
          var that = this;

          if (Id == "policeReport") {
            this.claimDocsImageArray.splice(0, 1, { event: event, fileList: fileList, doc: Id });
          } else if (Id == "driverLicenseFront") {
            this.claimDocsImageArray.splice(1, 1, { event: event, fileList: fileList, doc: Id });
          } else if (Id == "driverLicenseBack") {
            this.claimDocsImageArray.splice(2, 1, { event: event, fileList: fileList, doc: Id });
          } else if (Id == "vCardFront") {
            this.claimDocsImageArray.splice(3, 1, { event: event, fileList: fileList, doc: Id });
          } else if (Id == "vCardBack") {
            this.claimDocsImageArray.splice(4, 1, { event: event, fileList: fileList, doc: Id });
          }
          reader.onload = function () {
            that.imageURL = reader.result;
            that.upload(event);
          }
          reader.readAsDataURL(fileList[0]);
          if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
            this.errorMessage = '';
          }
        }
      });
    } else {
      return;
    }
  }



  // function to go to the summary page
  // submitClaimDocs(){
  //   this.router.navigate(['thank-you'], {skipLocationChange: true });
  // }


  submitClaimDocs() {
    if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
      //console.log('All documents are not uploaded');
      this.errorMessage = "Please upload all the documents!";
      return;
    } else {


      if (this.Is_I_Insured) {
        let insuredClaimData = {
          policyNo: this.polNo,
          accidentDate: this.acciDate,
          policeRefNo: this.policeRefNo,
          emailId: this.emailId,
          mobileNo: this.mobileNo,
          vehRegnNo: this.vehRegnNo,
          accidentLoc: this.accidentLoc,
          towingYN: this.towingYN,
          portal: 'D',
          userId: 'online'
        }
        this.loaderService.display(true);
        this.claimService.registerClaim(insuredClaimData, ApiUrls.REGISTER_OD_CLAIMS).subscribe((data: any) => {

          console.log("Data is===> ", data);
          if (data.respCode == 2000) {
            //this.router.navigate(['upload-claim-docs'], { queryParams: obj,skipLocationChange: true });

            this.uploadCall = true;
            this.uploadNameFlag = true;
            let i;
            this.clmRefNo = data.clmRefNo;
            if (this.claimDocsImageArray.length > 0) {

              for (i = 0; i < this.claimDocsImageArray.length; i++) {
                let event = this.claimDocsImageArray[i].event;
                let files = this.claimDocsImageArray[i].files;
                let doc = this.claimDocsImageArray[i].doc;

                const docCode = this.getDocumentCodeBeforeUpload(doc);
                this.upload(event, files, doc, docCode);

                //this.upload();
              }
              this.router.navigate(['thankyou'], { skipLocationChange: true });
              this.loaderService.display(false);
            }
          } else {
            this.errorMessage = data.errMessage;
          }
        }, error => {
          let err = error.json();
          console.log(JSON.stringify(err));
          this.errorMsg = err.errMessage;
          this.loaderService.display(false);
        });

      }



      // to submit docs for the TP claim
      if (!this.Is_I_Insured) {

        let tpClaimData = {
          policeRefNo: this.policeRefNo,
          vehLocation: this.vehLocation,
          accidentDate: this.accidentDate,
          emailId: this.emailId,
          mobileNo: this.mobileNo,
          vehRegnNo: this.vehRegnNo,
          vehMake: this.vehMake,
          vehModel: this.vehModel,
          modelYear: this.modelYear,
          name: this.name,
          policyNo: this.policy_number,
          portal: 'D',
          userId: 'online'
        }

        this.loaderService.display(true);

        this.claimService.registerClaim(tpClaimData, ApiUrls.REGISTER_TP_CLAIMS).subscribe((data: any) => {
          this.loaderService.display(false);
          if (data.respCode == 2000) {

            this.uploadCall = true;
            this.uploadNameFlag = true;
            let i;
            this.clmRefNo = data.clmRefNo;
            if (this.claimDocsImageArray.length > 0) {

              for (i = 0; i < this.claimDocsImageArray.length; i++) {
                let event = this.claimDocsImageArray[i].event;
                let files = this.claimDocsImageArray[i].files;
                let doc = this.claimDocsImageArray[i].doc;

                const docCode = this.getDocumentCodeBeforeUpload(doc);
                this.upload(event, files, doc, docCode);

                //this.upload();
              }
              this.router.navigate(['thankyou'], { skipLocationChange: true });
              this.loaderService.display(false);
            }

          } else {
            this.errorMessage = data.errMessage;
          }
        }, error => {
          this.errorMessage = this.appUtilObj.displayError(error["_body"], null);
          if (this.errorMessage == '') {
            let a = JSON.parse(error["_body"])
            this.errorMessage = a.errMessage;
          }
          this.loaderService.display(false);
        });
      }
    }
  }

  changeCheckboxStatus(event) {
    //console.log(event.target);
    if (event.target.checked) {
      this.errorMessage = "";
      this.checkboxValue = true;
    } else {
      this.checkboxValue = false;
    }
  }

}
