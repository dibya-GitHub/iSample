import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TpclaimComponent } from './tpclaim.component';

describe('TpclaimComponent', () => {
  let component: TpclaimComponent;
  let fixture: ComponentFixture<TpclaimComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TpclaimComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TpclaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
