import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { RegistrationLocation } from "src/shared/classes/registration-location";
import { ApiUrls } from '../../../../shared/api-urls';
import { AppUtil } from '../../../../shared/app-util';
import { LoaderService } from '../../../../shared/loader-service/loader.service';
import { InsuranceService as CommonService } from '../../../../shared/services/insurance.service';
import { ClaimService } from '../../services/claim.service';
import { InsuredVehicleDetails } from "src/app/car-insurance/classes/insured-vehicle-details";
import { MotorDropDownService } from 'src/app/car-insurance/services/motor-drop-down.service';
import { VehicleModel } from "src/shared/classes/vehicle-model";

@Component({
  selector: 'app-tpclaim',
  templateUrl: './tpclaim.component.html',
  styleUrls: ['./tpclaim.component.scss'],
})
export class TpclaimComponent implements OnInit {
  showMsg: boolean = false;
  locations: any[];
  startDate: any;
  postDate: any;
  registrationNo: any;
  placeOfAccdnt: any;
  mobile: any;
  email: any;
  policeRefNo: any;
  appUtilObj: AppUtil = new AppUtil();
  errorMsg: string = '';
  date: Date = new Date();
  registration_locations: RegistrationLocation[];
  // mu declarations
  public vehicle_makes: Array<any>;
  public claimData = new InsuredVehicleDetails();
  public vehicle_models: VehicleModel[];
  dropDownload = true;
  public carDetails = new InsuredVehicleDetails();
  claimantName: any;
  policy_number: any;
  manfYear: any;
  vehMaker: any;
  vehModels: any;
  accidentPlace: any;
  anyDate: any;
  myErrorMess: any;
  currentPathName: string;
  cusYear: number;


  public startDateOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    }
  };

  constructor(
    private meta: Meta,
    private router: Router,
    private route: ActivatedRoute,
    private titleService: Title,
    private getCarQuoteService: MotorDropDownService,
    private claimService: ClaimService,
    private loaderService: LoaderService,
    private commonService: CommonService,
  ) {
    this.titleService.setTitle('Insurance Claim Process | Non I-insured Customers');
    this.meta.addTag({ name: 'description', content: 'i-Insured helps manage your claim as quickly and efficiently as possible. File an insurance claim with i-Insured.' });
    this.meta.addTag({ name: 'keywords', content: 'life insurance policy, health plan, cheap travel insurance, renew car insurance, commercial vehicle insurance, health insurance coverage, health insurance prices' });

    this.route.queryParams.subscribe(params => {
      this.policeRefNo = params["policeRefNo"];
      this.email = params["email"];
      this.mobile = params["mobile"];
      this.registrationNo = params["registrationNo"];
      this.manfYear = params["manfYear"];
      this.claimantName = params["claimantName"];
      this.policy_number = params["policy_number"];
      if (params["postDate"] != undefined) {
        this.anyDate = new Date(params["postDate"]);
        // this.postDate=this.anyDate;
        this.postDate = params["postDate"];
        this.startDate = {
          "day": this.anyDate.getDate(),
          "month": (this.anyDate.getMonth() + 1),
          "year": this.anyDate.getFullYear(),
          "formatted": this.appUtilObj.appendZero(this.anyDate.getDate()) + '/' + this.appUtilObj.appendZero((this.anyDate.getMonth() + 1)) + '/' + this.anyDate.getFullYear(),
        };
        //, "formatted": "05.01.2017", "momentObj": "2017-01-04T23:00:00.000Z"
      }
      if (params["vehMakerid"] != undefined) {
        this.vehMaker = [{ id: params["vehMakerid"], text: params["vehMakerText"] }]
      }
      if (params["vehModelsid"] != undefined) {
        this.vehModels = [{ id: params["vehModelsid"], text: params["vehModelsText"] }]
      }
      if (params["placeOfAccdnt"] != undefined) {
        this.accidentPlace = params["placeOfAccdnt"];
      }
      else {
        this.accidentPlace = "";
      }
    });

    this.currentPathName = window.location.pathname;
    console.log("this.currentPathName", this.currentPathName);

  }
  ngOnInit() {
    window.scrollTo(0, 0);
    this.setRegLocationList();
    this.setVehicleMake();
  }


  changeAccidentDate(event: any) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsg = false;
      //console.log(this.startDate)
    }
    this.startDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
    this.postDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
  }

  passTpClaimData(Data) {
    let postData = {
      policeRefNo: this.policeRefNo,
      accidentDate: this.postDate,
      emailId: this.email,
      mobileNo: this.mobile,
      vehRegnNo: this.registrationNo,
      vehLocation: this.placeOfAccdnt,
      vehMake: this.vehMaker[0].id,
      vehModel: this.vehModels[0].id,
      vehMakerText: this.vehMaker[0].text,
      vehModelsText: this.vehModels[0].text,
      modelYear: this.manfYear,
      name: this.claimantName,
      policy_number: this.policy_number,
      "is_I_Insured": false
      // userId:'online',
      // portal:'D'

    }
    this.router.navigate(['upload-claim-docs'], { queryParams: postData, skipLocationChange: true });
  }



  registerClaim(Data) {
    console.log("Data", Data);
    let postData = {
      policeRefNo: this.policeRefNo,
      accidentDate: this.postDate,
      emailId: this.email,
      mobileNo: this.mobile,
      vehRegnNo: this.registrationNo,
      vehLocation: this.placeOfAccdnt,
      vehMake: this.vehMaker[0].id,
      vehModel: this.vehModels[0].id,
      modelYear: this.manfYear,
      name: this.claimantName,
      policyNo: this.policy_number,
      userId: 'online',
      portal: 'D'
    }


    var obj = {
      "policeRefNo": this.policeRefNo,
      "postDate": this.postDate,
      "placeOfAccdnt": this.placeOfAccdnt,
      "email": this.email,
      "mobile": this.mobile,
      "registrationNo": this.registrationNo,
      "vehMakerid": this.vehMaker[0].id,
      "vehMakerText": this.vehMaker[0].text,
      "vehModelsid": this.vehModels[0].id,
      "vehModelsText": this.vehModels[0].text,
      "manfYear": this.manfYear,
      "claimantName": this.claimantName,
      "policy_number": this.policy_number,
      "clmRefNo": "",
      "is_I_Insured": false
    }

    console.log("PostData", postData);

    console.log("Postdata", JSON.stringify(postData));
    this.loaderService.display(true);
    this.claimService.registerClaim(postData, ApiUrls.REGISTER_TP_CLAIMS).subscribe((data: any) => {
      this.loaderService.display(false);
      if (data.respCode == 2000) {
        obj.clmRefNo = data.clmRefNo;
        //var clmRefNo = {clmRefNo : data.clmRefNo};
        this.router.navigate(['upload-claim-docs'], { queryParams: obj, skipLocationChange: true });
        //this.router.navigate(['upload-claim-docs'], { skipLocationChange: true });
      } else {
        alert('error');
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      let a = JSON.parse(error["_body"])
      this.myErrorMess = a.errMessage;
      this.loaderService.display(false);



    });
  }
  /*setting registration locations*/
  setRegLocationList() {
    let location = { "type": "REGN_LOC" }
    this.claimService.getRegistrationLocationList(location)
      .subscribe(result => {
        this.registration_locations = result.appCodesArray;
        this.placeOfAccdnt = this.accidentPlace;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  onDateInput(event) {

    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.startDate = event.target.value;
        }
      }
    }

  }


  /*getting Vehicle make*/
  setVehicleMake() {
    let v_make = { "userId": "online" };
    this.getCarQuoteService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.vehicle_makes = arr;
        console.log("vehicle_makes", this.vehicle_makes);
        // this.vehicle_makes = result.makeArray;
        // this.vehicleData.vehMake = "";
        //this.getModel();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }


  /*getting vehicle model based on Vehicle make*/
  getModel(event) {
    this.claimData.vehMake = event.id;
    let postData = {
      type: "MOT_VEH_MOD",
      refCode: this.claimData.vehMake
    }
    this.getCarQuoteService.getVehicleModelList(postData).subscribe(result => {
      //console.log(JSON.stringify(response.json()));
      let arr = [];
      for (let i = 0; i < result.appCodesArray.length; i++) {
        let id = result.appCodesArray[i].code;
        let text = result.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      this.vehicle_models = arr;
      // this.vehicleData.vehModel = "";
      if (this.dropDownload == true) {
        //this.getDefaults();
        this.dropDownload = false;
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });

  }


  addVehicleMake(event) {
    this.carDetails.vehModel = event.id
  }
}
