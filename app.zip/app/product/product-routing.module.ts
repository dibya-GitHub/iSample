import { ProductComponent } from './product.component';

import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';



const productRoutes: Routes = [
    { path: '', component: ProductComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(productRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class ProductRoutingModule { }
