import { Component, OnInit } from '@angular/core';
import { Meta, Title } from "@angular/platform-browser";
import { Router } from '@angular/router';
import * as $ from 'jquery';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
})
export class ProductComponent implements OnInit {

  constructor(
    private router: Router,
    private meta: Meta,
    private titleService: Title
  ) {
    this.titleService.setTitle('i-Insured Products | Get Insurance Quotes for Car, Home, Travel & PAB');
    this.meta.addTag({ name: 'description', content: "Make sure you're ready for life's many surprises with our range of unique insurance products that take care of your needs. Get a quick insurance quotes for car, home, travel & PAB." });
    this.meta.addTag({ name: 'keywords', content: 'car insura nce dubai,  Home insurance dubai, Travel insurance dubai,  compare cycle insurance, PAB insurance dubai,  insurance companies dubai, insurance products, insurance companies, compare insurance in uae, cycle insurance dubai' });
  }
  currentIndex: any = 1;
  discountJSONFileValue: any = {
    "car": 10,
    "home": 30,
    "pab": 10,
    "travel": 10
  };
  ngOnInit() {
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  afterChange(event) {
    this.currentIndex = $('.for-count.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  setLocalVal(val: any) {
    window.localStorage.setItem('type', val);
    if (val == 'TP') {
      this.router.navigate(['car-insurance-without-chassi']);
    } else {
      this.router.navigate(['car-insurance']);
    }
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({ left: 0, top: 600, behavior: 'smooth' });
  }


  listContentCar = [
    {
      heading: 'Everything is online – even claims',
      description: 'Manage your policies and claims online and immediate – or let us handle it all for your via WhatsApp',
      icon: 'product-car-01',
      alt: 'Everything is online – even claims'
    },
    {
      heading: '24 Hour Emergency Helpline',
      description: 'Emergency roadside assistance throughout UAE 24 hours a day, 7 days a week – free with all our comprehensive car insurance products',
      icon: 'product-car-02',
      alt: '24 Hour Emergency Helpline'
    },
    {
      heading: 'Pay in four easy installments',
      description: 'Enjoy the full benefits of our comprehensive car insurance installments – don’t lose out on being fully covered if something happens. No credit check required',
      icon: 'product-car-03',
      alt: 'Pay in four easy installments'
    },
    {
      heading: 'Complementary personal driver services',
      description: 'Don’t’ worry about taking your car for service – we’ll pick it up, bring it to the workshop and return it when it’s done. We’ll also take you to the airport or pick you up',
      icon: 'product-car-04',
      alt: 'Complementary personal driver services'
    }
  ]
  listContentHome = [
    {
      heading: 'Even your food is covered',
      description: 'If your frozen food is damaged due to a freezer malfunction, your home contents insurance will cover the cost of replacing the food',
      icon: 'product-home-01',
      alt: 'Even your food is covered'
    },
    {
      heading: 'Relocation assistance',
      description: 'If your home is damaged and impossible to live in, we help you cover relocation and accommodation costs',
      icon: 'product-home-02',
      alt: 'Relocation assistance'
    },
    {
      heading: 'Damage done to others',
      description: 'If you or a family member accidentally damages someone else\'s property or accidentally injuring someone, liability coverage may help pay for related repair costs, etc.',
      icon: 'product-home-03',
      alt: 'Damage done to others'
    },
    {
      heading: 'Domestic servant cover',
      description: 'We cover accidental damage caused by your domestic servant – and also repatriation and accident benefits if s/he is injured and must be transported home',
      icon: 'product-home-04',
      alt: 'Domestic servant cover'
    }
  ]
  listContentTravel = [
    {
      heading: 'Including leisure activities',
      description: 'For example, we cover scuba diving all the way to 30 meters',
      icon: 'product-travel-01',
      alt: 'Including leisure activities'
    },
    {
      heading: 'Trip cancellations',
      description: 'We cover your expenses if you have to cancel your trip due to sickness, loss of job or other work related causes',
      icon: 'product-travel-02',
      alt: 'Trip cancellations'
    },
    {
      heading: 'Covers sport equipment',
      description: 'We’ll pay for rental fees if your sports equipment is delayed',
      icon: 'product-travel-03',
      alt: 'Covers sport equipment'
    },
    {
      heading: 'If your child is injured…',
      description: '…our travel insurance pays the expenses for you to stay in the hospital with your child',
      icon: 'product-travel-04',
      alt: 'If your child is injured…'
    }
  ]
  listContentPersonal = [
    {
      heading: 'Pays a sum if you are permanently injured',
      description: 'The PAB cover will pay a cash amount if you are permanently disabled after an accident',
      icon: 'product-personal-01',
      alt: 'Pays a sum if you are permanently injured'
    },
    {
      heading: 'Ultra-low premiums, great covers',
      description: 'The PAB insurance starts from only AED 270:- and can be bought online with no requirements',
      icon: 'product-personal-02',
      alt: 'Ultra-low premiums, great covers'
    },
    {
      heading: 'Accidental death',
      description: 'The nominee of the insurance will get 100 % of the sum insured in case of your death',
      icon: 'product-personal-03',
      alt: 'Accidental death'
    },
    {
      heading: 'No medical test and documentation required',
      description: 'No need to go through any medical test – and no documentation is required for purchasing the policy',
      icon: 'product-personal-04',
      alt: 'No medical test and documentation required'
    }
  ]
  listContentInsurance = [
    {
      heading: 'Wherever,  whenever',
      description: 'Our professional agents come to you at your convenient time and place – at home, in the office or while waiting for car service, you tell us!',
      icon: 'product-insurance-01',
      alt: 'Wherever,  whenever'
    },
    {
      heading: 'We take credit cards',
      description: 'You can pay for your insurance with debit or credit when our insurance agent is with you',
      icon: 'product-insurance-02',
      alt: 'We take credit cards'
    },
    {
      heading: 'You get your insurance immediately',
      description: 'Once you decide what cover you wish, we issue your new policy immediately – no need to wait for anything!',
      icon: 'product-insurance-03',
      alt: 'You get your insurance immediately'
    }
  ]


  slideConfig = {
    "slidesToShow": 3,
    "dots": true,
    "infinite": true,
    "centerMode": true,
    "centerPadding": '0px',
    "variableWidth": true
  };

  slideThreeItems = {
    "slidesToShow": 3,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }
  slideHighlights = {
    "slidesToShow": 4,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  };

}
