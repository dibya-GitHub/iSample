import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from './../shared.module';
import { ProductRoutingModule } from './product-routing.module';
import { ProductComponent } from './product.component';

@NgModule({
    declarations: [
        ProductComponent,
    ],
    imports: [
        ProductRoutingModule,
        CommonModule,
        SharedModule,
        SlickCarouselModule
    ],
})

export class ProductModule { }