import { TravelPolicyMembers } from '../classes/travel-policy-members'

export interface InsuredTravellers {
  respCode: string;
  errMessage: string;
  travelerArray: Array<TravelPolicyMembers>
}
