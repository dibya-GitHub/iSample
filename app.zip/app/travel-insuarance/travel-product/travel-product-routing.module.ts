import { TravelProductComponent } from './travel-product.component';
import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

const travelProductRoutes: Routes = [
    { path: '', component: TravelProductComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(travelProductRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class TravelProductRoutingModule { }
