import { TravelProductComponent } from './travel-product.component';
import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from "../../shared.module";
import { TravelProductRoutingModule } from './travel-product-routing.module';


@NgModule({
  declarations: [
    TravelProductComponent,
  ],
  imports: [
    TravelProductRoutingModule,
    CommonModule,
    SharedModule,
    SlickCarouselModule
  ],
})

export class TravelProductModule { }