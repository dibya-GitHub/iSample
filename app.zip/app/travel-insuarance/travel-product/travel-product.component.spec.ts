import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelProductComponent } from './travel-product.component';

describe('TravelProductComponent', () => {
  let component: TravelProductComponent;
  let fixture: ComponentFixture<TravelProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
