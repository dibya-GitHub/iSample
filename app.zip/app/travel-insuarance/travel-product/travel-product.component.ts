import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import * as $ from 'jquery';
import { Router } from "@angular/router";

@Component({
  selector: 'app-travel-product',
  templateUrl: './travel-product.component.html',
  styleUrls: ['./travel-product.component.scss'],
})
export class TravelProductComponent implements OnInit {
  constructor(
    private meta: Meta,
    private router: Router,
    private titleService: Title,
  ) {
    this.titleService.setTitle('Travel Insurance Dubai, UAE | Get International Travel Insurance | i-Insured');
    this.meta.addTag({ name: 'description', content: 'Compare and buy travel insurance online in Dubai. Get free quotes and online support from i-Insured on travel insurance premium, benefits, renewal and claims.' });
    this.meta.addTag({ name: 'keywords', content: 'travel insurance, online travel insurance, qic travel insurance, dubai travel insurance, travel insurance dubai, international travel insurance, travel insurance plan,dubai Travel Insurance' });

  }
  currentIndex: any = 1;
  selectedImageSrc = './assets/images/travel-pro-slide-01.png';
  title = 'Theft Coverage';
  subtitle = 'Should theft occur during your period of travel, this policy covers the loss';
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  ngOnInit() {
    this.initSliderForMobile();
    this.initSlider();
  }
  afterChange(event) {
    this.currentIndex = $('.insta-wp.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }


  travelCover = [
    {
      cover: 'Medical treatment abroad',
      isincluded: 'Included'
    },
    {
      cover: 'Medical and baggage transport',
      isincluded: 'Included'
    },
    {
      cover: 'Repatriation',
      isincluded: 'Included'
    },
    {
      cover: 'Hospitalization',
      isincluded: 'Included'
    },
    {
      cover: 'Medical evacuation and return of baggage',
      isincluded: 'Included'
    },
    {
      cover: 'Medicine consulting service',
      isincluded: 'Included'
    },
    {
      cover: 'Search & rescue recovery costs',
      isincluded: 'Included'
    },
    {
      cover: 'Travel cancellation',
      isincluded: 'Included'
    },
    {
      cover: 'Delayed start of trip',
      isincluded: 'Included'
    },
    {
      cover: 'Missed departure',
      isincluded: 'Included'
    },
    {
      cover: 'Unscheduled curtailment',
      isincluded: 'Included'
    },
    {
      cover: 'Interrupted tour',
      isincluded: 'Included'
    },
    {
      cover: 'Travel baggage insurance – accompanied ',
      isincluded: 'Included'
    },
    {
      cover: 'Travel baggage insurance – unaccompanied',
      isincluded: 'Included'
    },
    {
      cover: 'Delayed collection of baggage',
      isincluded: 'Included'
    },
    {
      cover: 'Loss of passport',
      isincluded: 'Included'
    },
    {
      cover: 'Overseas legal expenses',
      isincluded: 'Included'
    },
    {
      cover: 'Travel accident insurance',
      isincluded: 'Included'
    },
    {
      cover: 'Permanent disablement',
      isincluded: 'Included'
    },
    {
      cover: 'Personal liability',
      isincluded: 'Included'
    },
    {
      cover: 'Sports equipment',
      isincluded: 'Included'
    },
    {
      cover: 'Rental charges for sports equipment',
      isincluded: 'Included'
    },
    {
      cover: 'Winter sports extension',
      isincluded: '​Optional'
    },
    {
      cover: 'Terrorism extension',
      isincluded: '​Optional'
    }
  ]

  listContent = [
    {
      heading: 'Cancelled trip',
      description: 'We’ll cover the costs if you have to cancel your trip due to unforeseen circumstances',
      icon: 'no-sign-airplane',
      alt: 'Cancelled trip'
    },
    {
      heading: 'Flight delays',
      description: 'If your trip is delayed unexpectedly, the travel insurance will cover the costs',
      icon: 'watch',
      alt: 'Flight delays'
    },
    {
      heading: 'Delayed / lost luggage',
      description: 'The travel insurance will provide an amount for you to buy necessities if your luggage is lost or delayed',
      icon: 'luggage',
      alt: 'Delayed / lost luggage'
    },
    {
      heading: 'Accidents / illness',
      description: 'We cover the costs of hospitalization or repatriation if you’re injured or become ill during your travels',
      icon: 'hospital',
      alt: 'Accidents / illness'
    }
  ]
  listContent2 = [
    {
      heading: 'Regional travel insurance',
      description: 'Includes GCC, Arab countries, India, Pakistan, Sri Lanka, Bangladesh, Korea, Philippines, Indonesia, Nepal and Bhutan',
      icon: 'gcc',
      alt: 'Regional travel insurance'
    },
    {
      heading: 'Worldwide excluding USA and Canada',
      description: 'This covers loss of baggage or any other travel related inconveniences like loss of passport',
      icon: 'worldmap',
      alt: 'Worldwide excluding USA and Canada'
    },
    {
      heading: 'Worldwide',
      description: 'This cover has been designed for travelers who will be visiting the USA/Canada',
      icon: 'globe2',
      alt: 'Worldwide'
    },
    {
      heading: 'Fly Europe',
      description: 'Specially designed for travelers who are required to buy insurance for Schengen visa. This policy covers Medical Expenses up to USD 50,000',
      icon: 'eiffel-tower',
      alt: 'Fly Europe'
    }
  ]

  slideHighlights = {
    "slidesToShow": 4,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }
  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);

    });
  }
  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "draggable": false
  };
  initSlider() {
    var self = this;
    $(function () {
      $(".slick-dots button, .slick-next, .slick-prev, .triger-box").on("click", function () {
        // var title = $(".slick-current").find("h4").html();
        setTimeout(function () {
          var title = $(".slick-current").find("h4").attr("id")
          switch (title) {
            case "first":
              self.subtitle = 'Should theft occur during your period of travel, this policy covers the loss';
              break;
            case "second":
              self.subtitle = 'All losses incurred due to the loss of baggages during the course of your travels are covered by this policy';
              break;
            case "third":
              self.subtitle = 'Should your trip be cancelled due to unforeseen circumstances, the losses incurred are covered under this policy';
              break;
            default:
              self.subtitle = 'Cover yourself for injuries sustained during travel';
              break;
          }
        }, 500);
      });
    })
  }
  changeBackgroundImage(event: any) {
    console.log(event);
    let className = event.path[1].classList[1];
    $(function () {
      $('.thumbnail').click(function () {
        $('.thumbnail').removeClass('active');
        $(this).addClass('active');
      });
    });
    if (className === 'travel-pro-thumb-first') {
      this.selectedImageSrc = './assets/images/travel-pro-slide-01.png';
      // this.ng2parallax.src = './assets/images/travel-pro-slide-01.png';
      this.title = 'Theft coverage';
      this.subtitle = 'Get your valuable items covered against theft';

    }
    else if (className === 'travel-pro-thumb-sec') {

      this.selectedImageSrc = './assets/images/travel-pro-slide-03.png';
      // this.ng2parallax.src = './assets/images/travel-pro-slide-03.png';
      this.title = 'Lost baggage coverage';
      this.subtitle = 'Don’t ignore the baggage problems at the airport; get it covered';

    }
    else if (className === 'travel-pro-thumb-third') {

      this.selectedImageSrc = './assets/images/travel-pro-slide-02.png';
      // this.ng2parallax.src = './assets/images/travel-pro-slide-02.png';
      this.title = 'Trip cancellation coverage';
      this.subtitle = 'Cover your travel investment, just in case your plans get cancelled or interrupted ';

    }
    else if (className === 'travel-pro-thumb-fourth') {

      this.selectedImageSrc = './assets/images/travel-pro-slide-04.png';
      // this.ng2parallax.src = './assets/images/travel-pro-slide-04.png';
      this.title = 'Travel accident insurance';
      this.subtitle = 'Cover yourself for injuries sustained during travel';

    }
    // this.ng2parallax.ngOnInit();
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //  window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }
  goToFaq() {
    let obj = {
      productType: "Travel",
    }
    this.router.navigate(['faq'], { queryParams: obj, skipLocationChange: true });

  }

}
