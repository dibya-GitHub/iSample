export class TravelPolicyHolder {
  insName: string;
  insNameAr?: string;
  mobileNo: string;
  civilId: string;
  poBox: string;
  emailId: string;
  address: string;
  polStartDate?: any;
  polEndDate?: any
  nationality: string;
}
