export class TravelPolicyMembers {
  trvlrName: string;
  relation: string;
  gender: string;
  dob: any;
  passptNo: string;
  wntrSptsExtYN: boolean;
}
