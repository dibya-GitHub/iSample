import { TestBed, inject } from '@angular/core/testing';

import { TravelInfoService } from './travel-info.service';

describe('TravelInfoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TravelInfoService]
    });
  });

  it('should be created', inject([TravelInfoService], (service: TravelInfoService) => {
    expect(service).toBeTruthy();
  }));
});
