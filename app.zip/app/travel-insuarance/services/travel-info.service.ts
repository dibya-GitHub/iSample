import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiUrls } from 'src/shared/api-urls';
import { ApiHeadersService } from '../../../shared/api-headers.service';

@Injectable({
  providedIn: 'root'
})
export class TravelInfoService {
  requestOption;
  baseUrl = environment.baseUrl;
  loaderService: any;
  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  updateTravelInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_TRAVEL_INFO_URL, body, this.requestOption);
  }

  insTravelerDetls(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_TRAVELER_INFO_URL, body, this.requestOption);
  }

  getRelationType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_CODES, body, this.requestOption);
  }

  getQuoteTravelInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_TRAVEL_INFO, body, this.requestOption);
  }

  getTravelerDetls(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_TRAVELLER_DETAILS, body, this.requestOption);
  }

  printJasperReportUrl(body: any) {
    var url = this.baseUrl + ApiUrls.GET_PRINT_JASPER_URL;
    this.downloadFile(url, body, function (res) {
      const blob = new Blob([res], { type: 'application/pdf' });
      var url = URL.createObjectURL(blob);
      window.open(url);
    });
  }

  downloadFile(url, data, success) {
    const xhr: XMLHttpRequest = new XMLHttpRequest();
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', this.baseUrl + ApiUrls.GET_PRINT_JASPER_URL, true);
      let key = this.apiHeadersService.encodedKey;
      xhr.setRequestHeader("Authorization", "Basic " + key);
      xhr.setRequestHeader("company", '002');
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.responseType = "arraybuffer";
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
          if (success) success(xhr.response);
          if (xhr.status === 202) {
            resolve(JSON.parse(xhr.response));
          } else {
            reject(xhr.response);
          }
        }
      };
      xhr.send(JSON.stringify(data));
    });
  }

}
