import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalAndTravelInfoComponent } from './personal-and-travel-info.component';

describe('PersonalAndTravelInfoComponent', () => {
  let component: PersonalAndTravelInfoComponent;
  let fixture: ComponentFixture<PersonalAndTravelInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalAndTravelInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalAndTravelInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
