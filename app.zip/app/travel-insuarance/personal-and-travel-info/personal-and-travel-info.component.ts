import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Meta, Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { RecaptchaComponent } from 'ng-recaptcha';
import { IMyDateModel, IAngularMyDpOptions } from 'angular-mydatepicker';
import { TravelInfoService } from 'src/app/travel-insuarance/services/travel-info.service';
import { ApiConstants } from 'src/shared/api-constants';
import { AppUtil } from 'src/shared/app-util';
import { Gender } from 'src/shared/classes/gender';
import { InsuranceService } from 'src/shared/services/insurance.service';
import { TooltiptList } from "src/shared/tooltip-list";
import { environment } from '../../../environments/environment';
import { LoaderService } from '../../../shared/loader-service/loader.service';

@Component({
  selector: 'personal-and-travel-info',
  templateUrl: './personal-and-travel-info.component.html',
  styleUrls: ['./personal-and-travel-info.component.scss'],
})
export class PersonalAndTravelInfoComponent implements OnInit {
  returnDate: any;
  setTripId: any;
  showMsgDepartureDate: boolean = false;
  showMsgStartDate: boolean = false;
  message: boolean;
  messageShow: boolean;
  noOfChild: any;
  noOfAdults: any;
  insName: any;
  civilId: any;
  errorMsg: string = '';
  captchaErr: any;
  quoteNo: string = '';
  email: string;
  mobile: string;
  promoCodeError: any;
  siteKey: any = environment.siteKey;
  covidYn: any;
  isInbound = false;
  public acountryList: Array<any>;
  @ViewChild('captcha') captcha: RecaptchaComponent;
  @ViewChildren('input') vc;
  public gender_list: Gender[];
  public insuarance_types = [{ 'id': '1', 'type': 'Outbound' }];
  public trip_types = [{ 'id': '001', 'type': 'Single Trip', 'entry': 'Single Entry' }, { 'id': '002', 'type': 'Annual', 'entry': 'Multiple Entry' }]
  public adults: any[];
  public children: any[];
  public days: any[];
  public country_list: any;
  public ip: any;
  public _show = false;
  public _changeDateLabel = true;
  public _disabled = false;
  public daysOfTravel: any;
  public destination: any;
  public insuranceTypeId: any;
  public nationality_list: any;
  public paramforTravelInfo: any;
  public routeObj: any;
  public insuaranceType;
  public campaignTravel: any;
  orgCountry;
  destCountry = '002';
  sponsor;
  visaNo;
  passportNo
  maxDays: number = 0;
  el: any;
  Adu: any[];
  date: Date = new Date();
  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));
  appUtilObj: AppUtil = new AppUtil();
  public tootipMessage = new TooltiptList();

  public departureDate: any = { date: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() } };
  public startDate: any = { date: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() } };

  public startDateOptions: IAngularMyDpOptions = {
    // editableDateField: true,
    // indicateInvalidDate: true,
    // openSelectorOnInputClick: true,
    // showInputField: true,
    appendSelectorToBody: true,
    dateFormat: 'dd/mm/yyyy',
    disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };
  // selectedState: number=1;

  constructor(
    private meta: Meta,
    private router: Router,
    private fb: FormBuilder,
    private titleService: Title,
    private insuaranceService: InsuranceService,
    private travelInfoService: TravelInfoService,
    private loaderService: LoaderService,
  ) {
    this.titleService.setTitle('Travel Insurance in Dubai | Compare Insurance Policy Online');
    this.meta.addTag({ name: 'description', content: 'i-Insured Travel Insurance Quotes Online, I-Insured Insurance Company offers an easy online quote in Dubai for your travel insurance needs. Get a quote now!' });
    this.meta.addTag({ name: 'keywords', content: 'travel insurance Dubai, travel insurance online, buy travel insurance online Dubai, Compare travel Insurance quotes, dubai Travel Insurance, travel medical insurance, travel insurance quote, compare travel insurance' });

    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
    //console.log('constructor');
    this.setIP();
    this.onStartDateChanged(this.startDate);
  }

  ngOnInit() {
    if (window.localStorage.getItem("travelCampaignDetails")) {
      this.campaignTravel = JSON.parse(window.localStorage.getItem("travelCampaignDetails"))
      this.insName = this.campaignTravel["name"];
      this.civilId = this.campaignTravel["civilId"];
      this.email = this.campaignTravel["email"];
      this.mobile = this.campaignTravel["mobile"];
    }
    window.localStorage.removeItem('travelCampaignDetails');
    this.adults = Array(201).fill(0).map((x, i) => i); // [0,1,2,3,4]
    this.children = Array(201).fill(0).map((x, i) => i);
    //console.log('ngoninit');
    this.setGenderList();
    this.setCountryList();
    this.getDefaults();
  }

  ngAfterViewInit() {
    this.vc.first.nativeElement.focus();
  }

  onStartDateChanged(event) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsgStartDate = false;
    }

    if (this.startDate == null && event != null) {
      this.startDate = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    } else {

      if (this.startDate.date == undefined) {
        let temp: any = this.startDate;

        const stringDate = temp.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];
        let date = new Date(newDate);
        this.startDate = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      this.startDate.date = event.date;
    }
    let timestamp = new Date(event.epoc * 1000).getTime();

    if (event.epoc == undefined) {
      timestamp = new Date().getTime();
    }
    this.changeReturnDate();
  }
  onStartDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsgStartDate = true;
      } else {
        this.showMsgStartDate = false;
        if (event.target.value != '') {
          this.startDate = event.target.value;
        }
      }
    }

  }

  changeInboundTravelInfo() {
    if (this.insuaranceType == 'Inbound') {
      this.isInbound = true
    } else {
      this.isInbound = false
    }
  }

  onDepartureDateChanged(event) {
    if (this.departureDate != undefined || this.departureDate == null) {
      this.showMsgDepartureDate = false;
    }
    if (this.departureDate == null && event != null) {
      this.departureDate = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    } else {

      if (this.departureDate.date == undefined) {
        let temp: any = this.departureDate;
        const stringDate = temp.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];

        let date = new Date(newDate);
        this.departureDate = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      this.departureDate.date = event.date;
    }
    let timestamp = new Date(event.epoc * 1000).getTime();

    if (event.epoc == undefined) {
      timestamp = new Date().getTime();
    }
    this.changeReturnDate()
    //console.log(this.appUtilObj.getUTCDate(timestamp));
  }
  onDepartureInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsgDepartureDate = true;
      } else {
        this.showMsgDepartureDate = false;
        if (event.target.value != '') {
          this.departureDate = event.target.value;
        }
      }
    }

  }

  getDefaults() {
    this.daysOfTravel = '';
    this.noOfAdults = '';
    this.noOfChild = '';
    //this.insuaranceType = 'Outbound';

  }
  setCountryList() {
    const country_param = { 'type': 'COUNTRY' };
    this.insuaranceService.getCountryList(country_param).subscribe(
      countrylist => {
        this.country_list = countrylist.appCodesArray;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }
  setGenderList() {
    const gender_params = { 'paraType': 'GENDER' }
    this.insuaranceService.getGenderList(gender_params).subscribe(
      gender => {
        this.gender_list = gender.appParamsArray;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  setIP() {
    this.insuaranceService.getIPAddress().subscribe(result => {
      this.ip = result.ip;
      // //console.log(this.ip)
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  show_more_details(id) {
    //console.log('it happens ' + id)
    this.insuranceTypeId = id;
    if (id == 2) {
      this._show = true;
      this.destination = 'State of Qatar';
    } else {
      this.daysOfTravel = '';
      this._changeDateLabel = true;
      this._show = false;
    }

  }
  changeTripType(tripId) {
    //console.log(tripId)
    if (tripId == '001') {
      this.setTripId = tripId;
      this.daysOfTravel = '';
      this._changeDateLabel = true;
      this.daysOfTravel = '';
      this.maxDays = 90;
      //this.days = Array(30).fill(0).map((x, i) => i);
      this.departureDate = { date: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() } };
      this.onDepartureDateChanged(this.departureDate);


    } else {
      this.setTripId = tripId;
      this.maxDays = 0;
      this.startDate = { date: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() } };
      this.onStartDateChanged(this.startDate);
      this._changeDateLabel = false;
      if (this.insuranceTypeId == '2') {
        //console.log('not working')

        this.daysOfTravel = '';

      } else {
        this.daysOfTravel = new Date().getFullYear() % 4 == 0 ? 366 : 365;

      }

    }

  }

  save(travel) {
    if (!this.captcha.resolved) {
      this.captchaErr = 'Please Validate Captcha';
      return false;
    }
    let dataInbound;
    let dataOutBound;
    let dataToSend;
    console.log(this.covidYn);
    if (travel.tripType == '001' && (travel.daysOfTravel == 0 || travel.daysOfTravel > 90)) {
      return false;
    }
    if (this.noOfAdults == 0 && this.noOfChild == 0) {
      return false;
    }
    this.loaderService.display(true);
    if (this.setTripId == "001") {

      if (this.departureDate.epoc == undefined) {
        let temp: any;
        if (this.departureDate.date != undefined) {
          temp = this.departureDate.date.day + "/" + this.departureDate.date.month + "/" + this.departureDate.date.year;
        } else {

          temp = this.departureDate;
        }
        const stringDate = temp.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];
        this.departureDate = { epoc: new Date(newDate).getTime() / 1000 };
      }
      const timestamp = new Date(this.departureDate.epoc * 1000);
      const date = this.appUtilObj.getUTCDate(timestamp);
      travel['startDate'] = date;
    } else {
      if (this.startDate.epoc == undefined) {
        let temp: any;
        if (this.startDate.date != undefined) {
          temp = this.startDate.date.day + "/" + this.startDate.date.month + "/" + this.startDate.date.year;
        } else {
          temp = this.startDate;
        }
        const stringDate = temp.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];
        this.startDate = { epoc: new Date(newDate).getTime() / 1000 };
      }
      const timestamp = new Date(this.startDate.epoc * 1000);
      const date = this.appUtilObj.getUTCDate(timestamp);
      travel['startDate'] = date;
    }


    //travel['startDate'] = date;
    const currentDate = new Date();
    const displayDate = currentDate.toISOString();
    const paramForcreateQuote = {
      'lobCode': ApiConstants.TRAVEL_INSURANCE_LOBCODE,
      'portal': 'D', 'location': 'D',
      'userId': 'online',
      'bundleYN': '0',
      'ipAddress': this.ip,
      'sourceMkting': '',
      'campaignMkting': '',
      'promoCode': travel.promoCode,
      'polStartDate': travel['startDate'],
      prodShortDesc: 'TRAVEL'

    };

    const startDate = travel.departureDate;
    const moment = JSON.parse(JSON.stringify(startDate)).momentObj
    //travel['startDate'] = this.startDate;
    console.log(paramForcreateQuote, ">>>>>>>>>>>>>>paramForcreateQuote")
    this.insuaranceService.createQuote(paramForcreateQuote)
      .subscribe(result => {
        const responseFromCreateQuote = result;
        this.quoteNo = responseFromCreateQuote.quoteNo;
        this.routeObj = {
          transId: responseFromCreateQuote.transId,
          tranSrNo: responseFromCreateQuote.tranSrNo,
          quoteNo: responseFromCreateQuote.quoteNo,
          covid: this.covidYn
        }

        if (result.respCode == 2000) {
          travel['transId'] = responseFromCreateQuote.transId;
          travel['tranSrNo'] = responseFromCreateQuote.tranSrNo;


          travel['userId'] = 'online';
          travel['noOfInfants'] = '';
          travel['noOfSeniorCtzns'] = '';
          travel['wntrSptsExtYN'] = '';
          travel['wntrSptsExtYN'] = '';
          this.insuaranceService.isCovidSelected = this.covidYn
          if (this.covidYn === "1") {
            if (this.insuaranceType == "Outbound") {
              this.covidYn = "TR_OUT_COVID"
            } else {
              this.covidYn = "TR_IN_COVID"
            }
          } else {
            this.covidYn = "";
          }
          sessionStorage.setItem("covidValue", this.covidYn);
          dataOutBound = {
            'transId': responseFromCreateQuote.transId,
            'tranSrNo': responseFromCreateQuote.tranSrNo,
            'mapId': 'TRAVEL_POL_SCR_1',
            'emailId': travel.emailId,
            'mobileNo': travel.mobileNumber,
            'civilId': this.civilId,
            'insName': this.insName,
            'inboundYN': '0',
            "covidYn": this.covidYn,
          }
          dataInbound = {
            'transId': responseFromCreateQuote.transId,
            'tranSrNo': responseFromCreateQuote.tranSrNo,
            'mapId': 'TRAVEL_POL_SCR_1',
            'emailId': travel.emailId,
            'mobileNo': travel.mobileNumber,
            'civilId': this.passportNo,
            'insName': this.insName,
            'inboundYN': '1',
            "covidYn": this.covidYn,
            "refNo": this.visaNo,
            "selectYN": this.sponsor
          }
          if (this.isInbound == true) {
            dataToSend = dataInbound
          } else {
            dataToSend = dataOutBound
          }

          console.log(JSON.stringify(dataToSend) + ' update Insured ')
          this.insuaranceService.updateInsuredInfo(dataToSend)
            .subscribe((result: any) => {

              //console.log(result);
              //console.log('Update Insured running');

              if (result.respCode == 2000) {
                this.setObjectForTravelInfo(travel);
                console.log(JSON.stringify(this.paramforTravelInfo) + ' for travel')
                this.travelInfoService.updateTravelInfo(JSON.stringify(this.paramforTravelInfo))
                  .subscribe(result => {
                    //console.log(result)
                    //console.log('Update Travelinfo running');
                    const responseFromTravelInfoQuote = result;
                    if (result.respCode == 2000) {
                      const strPostData = { 'transId': responseFromCreateQuote.transId, 'tranSrNo': responseFromCreateQuote.tranSrNo, 'portal': ApiConstants.PORTAL, 'userId': ApiConstants.USER_ID, 'lobCode': ApiConstants.TRAVEL_INSURANCE_LOBCODE }

                      console.log(JSON.stringify(strPostData));
                      this.insuaranceService.calculatePricing(JSON.stringify(strPostData))
                        .subscribe((calcpricing: any) => {
                          //console.log(calcpricing);
                          this.loaderService.display(false);
                          if (calcpricing.respCode == 2000) {
                            this.router.navigate(['select-plan'], { queryParams: this.routeObj, skipLocationChange: true });
                          }
                        }, error => {
                          let obj = {
                            quoteNo: this.quoteNo
                          }
                          this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
                          //this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
                          this.loaderService.display(false);
                        });
                    }
                  }, error => {
                    this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
                    this.loaderService.display(false);
                  });
              }
            }, error => {
              this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
              this.loaderService.display(false);
            });
        }
      }, error => {
        let err = error.json();
        if (err.respCode == "5005") {
          this.promoCodeError = err.errMessage;
        } else {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        }
        this.loaderService.display(false);
      });
    //console.log(travel);
  }

  setObjectForTravelInfo(travel) {
    this.paramforTravelInfo = {
      'tripType': travel.tripType, 'daysOfTravel': this.daysOfTravel, 'noOfAdults': this.noOfAdults,
      'noOfChild': this.noOfChild, 'tranSrNo': travel.tranSrNo, 'destCountry': this.destCountry, 'orgCountry': this.orgCountry,
      'transId': travel.transId, 'userId': ApiConstants.USER_ID
    }
  }
  appendZero(temp: any) {
    if (temp < 10) {
      return '0' + temp;
    }
    return temp;
  }
  changeReturnDate() {
    if (this.setTripId == undefined) {
      this.returnDate = '';
    } else {
      if (this.setTripId == "001") {
        console.log(this.departureDate)

        if (this.departureDate.date == undefined) {
          let temp: any = this.departureDate;
          const stringDate = temp.split("/");
          const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];

          let date = new Date(newDate);
          this.departureDate = {
            date: {
              year: date.getFullYear(),
              month: date.getMonth() + 1,
              day: date.getDate()
            }
          }
        }
        if (this.departureDate.date.year != 0) {
          console.log(this.departureDate, "this.departureDate");
          let tempDate = this.departureDate.date.month + '/' + this.departureDate.date.day + '/' + this.departureDate.date.year;
          let time: any;
          console.log();
          if (this.daysOfTravel == '' || this.daysOfTravel == undefined || this.daysOfTravel == null || this.daysOfTravel <= 0 || this.daysOfTravel > 90) {
            this.returnDate = '';
          } else {
            time = (86400000 * this.daysOfTravel) - 86400000;
            let newDate = new Date(tempDate).getTime();
            let retdate = new Date(newDate + time);
            this.returnDate = this.appendZero(retdate.getDate()) + '/' + this.appendZero(retdate.getMonth() + 1) + '/' + retdate.getFullYear();
            console.log(retdate, "returdate");
          }
        } else {
          this.returnDate = '';
        }
      } else {
        if (this.startDate.date == undefined) {
          let temp: any = this.startDate;
          const stringDate = temp.split("/");
          const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];

          let date = new Date(newDate);
          this.startDate = {
            date: {
              year: date.getFullYear(),
              month: date.getMonth() + 1,
              day: date.getDate()
            }
          }
        }
        if (this.startDate.date.year != 0) {
          console.log(this.startDate, "this.startDate")
          let tempDate = this.startDate.date.month + '/' + this.startDate.date.day + '/' + this.startDate.date.year;
          let time = (86400000 * 365) - 86400000;
          let newDate = new Date(tempDate).getTime();
          let retdate = new Date(newDate + time);
          this.returnDate = this.appendZero(retdate.getDate()) + '/' + this.appendZero(retdate.getMonth() + 1) + '/' + retdate.getFullYear();
          console.log(retdate, "returdate");
        } else {
          this.returnDate = '';
        }


      }
      //this.returnDate =this.departureDate.date.day+this.daysOfTravel;
      console.log(this.returnDate)
    }
  }

}
