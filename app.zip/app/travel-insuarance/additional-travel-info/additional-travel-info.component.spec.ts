import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalTravelInfoComponent } from './additional-travel-info.component';

describe('AdditionalTravelInfoComponent', () => {
  let component: AdditionalTravelInfoComponent;
  let fixture: ComponentFixture<AdditionalTravelInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalTravelInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalTravelInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
