import { Component, NgZone, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { IAngularMyDpOptions } from "angular-mydatepicker";
import * as $ from 'jquery';
import { ApiConstants } from 'src/shared/api-constants';
import { AppUtil } from 'src/shared/app-util';
import { Gender } from "src/shared/classes/gender";
import { LoaderService } from "src/shared/loader-service/loader.service";
import { InsuranceService } from "src/shared/services/insurance.service";
import { TravelPolicyHolder } from '../classes/travel-policy-holder';
import { TravelPolicyMembers } from '../classes/travel-policy-members';
import { InsuredTravellers } from '../interfaces/insured-travellers';
import { TravelInfoService } from '../services/travel-info.service';

@Component({
  selector: 'additional-travel-info',
  templateUrl: './additional-travel-info.component.html',
  styleUrls: ['./additional-travel-info.component.scss'],
})
export class AdditionalTravelInfoComponent implements OnInit {
  setWinterSports: any;
  showDateErrorArr: any = [];
  showDateErrorArrChild: any = [];
  gender: any;
  nationality_list: Array<any>;
  nationality: any;
  gender_list: Gender[];
  travelInfo?: any;
  transId: string;
  tranSrNo: string;
  quoteNo: string;
  travelDays: any;
  relation_List: any[];
  relation: any;
  date: Date = new Date();
  options: IAngularMyDpOptions;
  InsertTravelerdataArray = [];
  travelPolicyHolder: TravelPolicyHolder = new TravelPolicyHolder();
  travelPolicyMembers: TravelPolicyMembers = new TravelPolicyMembers();
  insuredTravellers: InsuredTravellers[];
  totalAdults: number;
  totalChildren: number;
  adults: any = [];
  adultDetails: any = [];
  children: any = [];
  childDetails: any = [];
  travellersArray: any = [];
  appUtilObj: AppUtil = new AppUtil();
  insuredNationality: Array<any>;
  adultNationality: any = [];
  childNationality: any = [];
  isProceed = false;
  insuredArr: any = [];
  errorMsg: string = '';
  backButton: boolean;
  carTransId: string;
  lobCode: string;
  insValidYN: any;
  isCovidYN: any = false;
  showWinter
  public startDateOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'yyyy-mm-dd',
    disableSince: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() + 1 }

  };

  public myDatePickerOptionsDOB: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    disableSince: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() + 1 }
  };

  constructor(
    private zone: NgZone,
    private router: Router,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private insuranceService: InsuranceService,
    private travelInfoService: TravelInfoService
  ) {

    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      this.quoteNo = params["quoteNo"];
      this.backButton = params["backButton"];
      this.carTransId = params["carTransId"];
      this.lobCode = params["lobCode"];
      this.insValidYN = params["insValidYN"];
      this.showWinter = params["covid"]
    });

  }
  ngOnInit() {
    this.showWinter = sessionStorage.getItem('covidValue');
    if (this.showWinter != "") {
      this.isCovidYN = false
    } else {
      this.isCovidYN = true
    }
    this.loaderService.display(true);
    $('.container').hide();
    this.proceedNext();
    this.getQuote();
    // this.getTravelInfo();
    this.setRelationList();
    this.setCountrylist();
    this.setGenderList();
    // this.getDefault();
  }
  getQuote() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.insuranceService.getQuotInfo(data).subscribe((res: any) => {
      if (res.respCode == 2000) {
        this.travelPolicyHolder.insName = res.insName;
        this.travelPolicyHolder.insNameAr = res.insNameAr;
        this.travelPolicyHolder.emailId = res.emailId;
        this.travelPolicyHolder.mobileNo = res.mobileNo;
        this.travelPolicyHolder.civilId = res.civilId;
        this.travelPolicyHolder.poBox = res.poBox;
        this.travelPolicyHolder.address = res.address;
        if (res.nationality != null) {
          this.insuredNationality = [{ id: res.nationality, text: res.nationalityDesc }]
        }
        this.getTravelInfo();
        // this.travelPolicyHolder.nationality = res.nationality;
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getTravelInfo() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.travelInfoService.getQuoteTravelInfo(data).subscribe(
      res => {
        if (res.respCode == 2000) {
          //console.log("getTravelInfo object ", res);
          this.setWinterSports = res.wntrSptsExtYN;
          this.totalAdults = Number(res.noOfAdults);
          this.totalChildren = Number(res.noOfChild);
          let postData = {
            transId: this.transId,
            tranSrNo: this.tranSrNo
          }
          this.travelInfoService.getTravelerDetls(postData).subscribe(
            res => {

              if (res.respCode == 2000) {
                this.travellersArray = res.travelerArray;
                for (let traveller in this.travellersArray) {
                  if (this.travellersArray[traveller].category == "8003") {
                    this.adultNationality.push([{ id: this.travellersArray[traveller].nationality, text: this.travellersArray[traveller].nationalityDesc }])
                    this.travellersArray[traveller].wntrSptsExtYN = this.travellersArray[traveller].wntrSptsExtYN == "FALSE" ? false : true;
                    let adultDOB: Date = new Date(this.travellersArray[traveller].dob);
                    this.travellersArray[traveller].dob = { date: { year: adultDOB.getFullYear(), month: adultDOB.getMonth() + 1, day: adultDOB.getDate() } }
                    this.travellersArray[traveller].gender = (this.travellersArray[traveller].gender == null) ? this.travellersArray[traveller].gender = "" : this.travellersArray[traveller].gender;
                    this.adultDetails.push(this.travellersArray[traveller])
                  } else if (this.travellersArray[traveller].category == "8002") {
                    this.childNationality.push([{ id: this.travellersArray[traveller].nationality, text: this.travellersArray[traveller].nationalityDesc }])
                    this.travellersArray[traveller].wntrSptsExtYN = this.travellersArray[traveller].wntrSptsExtYN == "FALSE" ? false : true;
                    let childDOB: Date = new Date(this.travellersArray[traveller].dob);
                    this.travellersArray[traveller].dob = { date: { year: childDOB.getFullYear(), month: childDOB.getMonth() + 1, day: childDOB.getDate() } }
                    this.travellersArray[traveller].gender = (this.travellersArray[traveller].gender == null) ? this.travellersArray[traveller].gender = "" : this.travellersArray[traveller].gender;
                    this.childDetails.push(this.travellersArray[traveller])
                  }
                }
                $('.container').show();
                this.loaderService.display(false);
              } else {
                this.getDefaultData()
              }
            }, error => {
              this.getDefaultData()
              this.loaderService.display(false);
            }
          )
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
        $('.container').show();
      }
    )
  }

  getDefault() {
    this.travelPolicyHolder.nationality = "";
  }

  getDefaultData() {
    if (this.totalAdults && this.totalAdults >= 1) {
      if (this.totalAdults < 1) {
        console.log("child is policy holder")
      } else {
        console.log("adult is policy holder")
      }
      for (let i = 0; i < this.totalAdults; i++) {
        this.showDateErrorArr.push({ 'index': -1 })
        let adultData = {
          transId: this.transId,
          tranSrNo: this.tranSrNo,
          trvlrName: '',
          relation: '',
          gender: '',
          dob: '',
          passptNo: '',
          wntrSptsExtYN: this.setWinterSportsDiscount(),
          category: '',
          adultYN: '',
          srNo: '',
          nationality: '',
          userId: ApiConstants.USER_ID
        }
        if (this.totalAdults >= 1 && i == 0) {
          adultData['trvlrName'] = this.travelPolicyHolder.insName;
        }
        this.adults.push(i);
        this.adultDetails.push(adultData);
      }
      $('.container').show();
      this.loaderService.display(false);
    }
    if (this.totalChildren && this.totalChildren >= 1) {
      for (let i = 0; i < this.totalChildren; i++) {
        this.showDateErrorArrChild.push({ 'index': -1 })
        let childData = {
          transId: this.transId,
          tranSrNo: this.tranSrNo,
          trvlrName: '',
          relation: '',
          gender: '',
          dob: '',
          passptNo: '',
          wntrSptsExtYN: this.setWinterSportsDiscount(),
          category: '',
          adultYN: '',
          srNo: '',
          nationality: '',
          userId: ApiConstants.USER_ID
        }
        if (this.totalAdults < 1 && i == 0) {
          childData['trvlrName'] = this.travelPolicyHolder.insName;
        }
        this.children.push(i);
        this.childDetails.push(childData);
      }
      $('.container').show();
      this.loaderService.display(false);
    }
    this.getDefault();
  }

  scrollTop() {
    window.scrollTo(0, 0);
  }

  dobChanged(event: any, target: any, index: any) {


    let date = "";
    let timestamp;
    if (event.epoc != 0) {
      timestamp = new Date(event.epoc * 1000);
      date = this.appUtilObj.getUTCDate(timestamp);
    }
    if (target.indexOf("adultDob") > -1) {
      if (this.adultDetails[index].dob != undefined || this.adultDetails[index].dob == null) {
        this.showDateErrorArr[index] = -1;
      }
      this.adultDetails[index].dob = date;
    } else if (target.indexOf("childDob") > -1) {
      if (this.childDetails[index].dob != undefined || this.childDetails[index].dob == null) {
        this.showDateErrorArrChild[index] = -1;
      }
      this.childDetails[index].dob = date;
    }
  }
  setRelationList() {
    this.travelInfoService.getRelationType({ "type": "RELATION" })
      .subscribe(result => {
        this.relation_List = result;
        console.log(this.relation_List + " relation list");
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }
  setGenderList() {
    let get_genderList = { "paraType": "GENDER" };
    this.insuranceService.getGenderList(get_genderList)
      .subscribe(result => {
        this.gender_list = result.appParamsArray;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }
  /*setting country list*/
  setCountrylist() {
    let get_nationaLitylist = { "type": "NATIONALITY" };
    this.insuranceService.getNationalityList(get_nationaLitylist)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        let sortedArr = this.sortNationality(arr);
        this.nationality_list = sortedArr;
        //console.log(this.nationality_list)
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  gotoSummary() {
    if (this.carTransId) {
      let obj = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        lobCode: this.lobCode,
        bundleTransId: this.carTransId,
        backButton: this.backButton ? true : false,
        insValidYN: this.insValidYN
      }
      this.loaderService.display(false);
      this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
    } else {
      let obj = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        insValidYN: this.insValidYN
      }
      this.loaderService.display(false);
      this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
    }

  }
  save(travellerDetails) {
    this.InsertTravelerdataArray = [];
    this.loaderService.display(true);
    for (let i = 0; i < this.totalAdults; i++) {
      /*if(this.getAge(travellerDetails['Adult' + i + '']['adultDob'])==true){
        this.loaderService.display(false);
        return false;
      }*/
      let wntrSptsExtYN = '1';
      console.log(travellerDetails['Adult' + i + '']['wntrSptsExtYN']);
      if (travellerDetails['Adult' + i + '']['wntrSptsExtYN'] == true) {
        wntrSptsExtYN = '1';
      } else {
        wntrSptsExtYN = '0';
      }

      if (travellerDetails['Adult' + i + ''].adultDob.epoc == undefined && travellerDetails['Adult' + i + ''].adultDob.date == undefined) {
        const stringDate = travellerDetails['Adult' + i + ''].adultDob.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2]
        let date = new Date(newDate);
        travellerDetails['Adult' + i + ''].adultDob = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      //console.log(typeof(travellerDetails['Adult' + i + ''].nationality))
      let formattedDob = travellerDetails['Adult' + i + ''].adultDob.epoc ? travellerDetails['Adult' + i + ''].adultDob.epoc * 1000 : new Date(travellerDetails['Adult' + i + ''].adultDob.date.year, travellerDetails['Adult' + i + ''].adultDob.date.month - 1, travellerDetails['Adult' + i + ''].adultDob.date.day).getTime()
      travellerDetails['Adult' + i + ''].nationality = travellerDetails['Adult' + i + ''].nationality[0].id;
      /*if (typeof(travellerDetails['Adult' + i + ''].nationality === 'object')) {
        travellerDetails['Adult' + i + ''].nationality = travellerDetails['Adult' + i + ''].nationality[0].id;
      }*/
      travellerDetails['Adult' + i + ''].wntrSptsExtYN = wntrSptsExtYN;
      travellerDetails['Adult' + i + ''].dob = formattedDob
      travellerDetails['Adult' + i + '']['userId'] = "online";
      travellerDetails['Adult' + i + '']['category'] = "8003";
      travellerDetails['Adult' + i + '']['adultYN'] = "1";
      travellerDetails['Adult' + i + '']['tranSrNo'] = this.tranSrNo;
      travellerDetails['Adult' + i + '']['transId'] = this.transId;
      this.InsertTravelerdataArray.push(travellerDetails['Adult' + i + '']);

    }

    for (let i = 0; i < this.totalChildren; i++) {
      /* if (this.getChildAge(travellerDetails['child' + i + '']['childDob']) == true) {
         this.loaderService.display(false);
         return false;
       }*/
      let wntrSptsExtYN = '1';
      console.log(travellerDetails['child' + i + '']['wntrSptsExtYN']);
      if (travellerDetails['child' + i + '']['wntrSptsExtYN'] == true) {
        wntrSptsExtYN = '1';
      } else {
        wntrSptsExtYN = '0';
      }
      if (travellerDetails['child' + i + ''].childDob.epoc == undefined && travellerDetails['child' + i + ''].childDob.date == undefined) {
        const stringDate = travellerDetails['child' + i + ''].childDob.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2]
        let date = new Date(newDate);
        travellerDetails['child' + i + ''].childDob = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      let formattedDob = travellerDetails['child' + i + ''].childDob.epoc ? travellerDetails['child' + i + ''].childDob.epoc * 1000 : new Date(travellerDetails['child' + i + ''].childDob.date.year, travellerDetails['child' + i + ''].childDob.date.month - 1, travellerDetails['child' + i + ''].childDob.date.day).getTime()
      travellerDetails['child' + i + ''].nationality = travellerDetails['child' + i + ''].nationality[0].id;
      travellerDetails['child' + i + ''].wntrSptsExtYN = wntrSptsExtYN;
      travellerDetails['child' + i + ''].dob = formattedDob;
      travellerDetails['child' + i + '']['userId'] = "online";
      travellerDetails['child' + i + '']['category'] = "8002";
      travellerDetails['child' + i + '']['adultYN'] = "0";
      travellerDetails['child' + i + '']['tranSrNo'] = this.tranSrNo;
      travellerDetails['child' + i + '']['transId'] = this.transId;
      this.InsertTravelerdataArray.push(travellerDetails['child' + i + '']);
    }
    /**
     * for update insured info
     */
    //this.insuredArr.polHolderDetails.nationality = this.insuredArr.polHolderDetails.nationality[0].id
    // let dataToSend = this.insuredArr.polHolderDetails;
    // dataToSend['mapId'] = "TRAVEL_POL_SCR_2";
    // dataToSend['transId'] = this.transId
    // dataToSend['tranSrNo'] = this.tranSrNo;
    // console.log("==============");
    // console.log(dataToSend);
    // console.log("==============");
    //console.log("this.InsertTravelerdataArray[0].trvlrName",this.InsertTravelerdataArray[0].trvlrName)
    this.insuranceService.updateInsuredInfo({ 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'insName': this.InsertTravelerdataArray[0].trvlrName, 'mapId': 'TRAVEL_POL_SCR_2' })
      .subscribe((resultFromUpdateInusred: any) => {
        /**
         * service call to update traveller details
         */
        if (resultFromUpdateInusred.respCode = 2000) {
          this.travelInfoService.insTravelerDetls(JSON.stringify(this.InsertTravelerdataArray))
            .subscribe(result => {
              console.log(result);
              this.router.navigate(['upload-document'], { queryParams: { lobCode: ApiConstants.TRAVEL_INSURANCE_LOBCODE, transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo, }, skipLocationChange: false });

            }, error => {
              this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
              this.loaderService.display(false);
            });
        }
      })
    console.log(this.InsertTravelerdataArray + "  " + JSON.stringify(this.InsertTravelerdataArray))

  }
  /*getAge(dateString) {
    let age: any;
    let today = new Date();
    let birthDate = new Date(dateString);
    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }*/
  getAge(dateString: any) {
    if (dateString == '' || dateString == undefined) {
      return false;
    } else {
      //console.log(dateString)
      //let dobOf:string = dateString.formatted;
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {

        if (dateString.date != undefined) {
          dateString = dateString.date.month + "/" + dateString.date.day + "/" + dateString.date.year;
          birthDate = new Date(dateString);
        } else {
          let parts = dateString.split('/');
          birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
        }
      }

      // if(dateString.date!=undefined){
      //   dateString=dateString.date.month +"/"+ dateString.date.day+ "/" +  dateString.date.year;
      // }

      //   let parts = dateString.split('/');
      //   birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      // }

      //const date = this.appUtilObj.getUTCDate(timestamp);
      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age < 18) {
        return true;
      } else if (age > 70) {
        return true;
      }
      else {
        return false;
      }

    }

  }

  getChildAge(dateString: any) {
    if (dateString == '' || dateString == undefined) {
      return false;
    } else {
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {

        if (dateString.date != undefined) {
          dateString = dateString.date.month + "/" + dateString.date.day + "/" + dateString.date.year;
          birthDate = new Date(dateString);
        } else {
          let parts = dateString.split('/');
          birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
        }
        // if(dateString.date!=undefined){
        //   dateString=dateString.date.month +"/"+ dateString.date.day+ "/" +  dateString.date.year;
        // }
        // let parts = dateString.split('/');
        // birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }

      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age > 18) {
        return true;
      }
      else {
        return false;
      }

    }

  }
  proceedNext() {
    //this.insuredArr = data;
    this.isProceed = true;
  }

  goToPreviousPage() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      lobCode: "08",
      carTransId: this.carTransId
    }
    this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
  }

  setWinterSportsDiscount() {
    if (this.setWinterSports == 1) {
      return true;
    }
    return false;
  }
  onDateInput(event, i) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showDateErrorArr[i] = i;
      } else {
        this.showDateErrorArr[i] = -1;
        if (event.target.value != '') {
          this.adultDetails[i].dob = event.target.value;
        }
      }
    }

  }
  onDateInputChild(event, i) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showDateErrorArrChild[i] = i;
      } else {
        this.showDateErrorArrChild[i] = -1;
        if (event.target.value != '') {
          this.childDetails[i].dob = event.target.value;
        }
      }
    }

  }
  getProposalForm() {
    let params = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      repId: 'QIC_JSCH_022',
    }
    this.travelInfoService.printJasperReportUrl(params);
  }

}
