import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SharedModule } from './../shared.module';
import { RetrieveQuoteRoutingModule } from './retrieve-quote-routing.module';
import { RetrieveQuoteComponent } from './retrieve-quote/retrieve-quote.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
// import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
    declarations: [
        RetrieveQuoteComponent,
    ],
    imports: [
        RetrieveQuoteRoutingModule,
        CommonModule,
        SharedModule,
        SlickCarouselModule,
        // NgxPaginationModule

    ],
})

export class RetrieveQuoteModule { }