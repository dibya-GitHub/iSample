import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { RetrieveQuoteComponent } from './retrieve-quote/retrieve-quote.component';

const retQuoteRoutes: Routes = [
  { path: '', component: RetrieveQuoteComponent },
];
@NgModule({
  imports: [
    RouterModule.forChild(retQuoteRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class RetrieveQuoteRoutingModule { }
