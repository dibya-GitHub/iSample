import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrieveCustInfoComponent } from './retrieve-cust-info.component';

describe('RetrieveCustInfoComponent', () => {
  let component: RetrieveCustInfoComponent;
  let fixture: ComponentFixture<RetrieveCustInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetrieveCustInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrieveCustInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
