import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewChildren } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiConstants } from '../../../shared/api-constants';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { RetrieveQuoteService } from '../services/retrieve-quote.service';

@Component({
  selector: 'app-retrieve-cust-info',
  templateUrl: './retrieve-cust-info.component.html',
  styleUrls: ['./retrieve-cust-info.component.scss']
})
export class RetrieveCustInfoComponent implements OnInit {
  
  @ViewChildren('input') vc;
  quoteList: any = [];
  pubIp: any;
  response: any;
  insType: any;
  errorMessage: any = '';
  showDiv = false;
  p: any;
  appUtilObj: AppUtil = new AppUtil();
  quoteNo: string = '';
  routeData: any;
  datePipe: DatePipe;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private insuranceService: InsuranceService,
    private retrieveQuoteService: RetrieveQuoteService,
  ) {
    this.datePipe = new DatePipe('en-US');
    this.route.queryParams.subscribe(params => {
      this.routeData = params;
      this.retrieveQuoteService.getQuoteList(params).subscribe((data: any) => {

        this.quoteList = this.appUtilObj.sortArrayByPolicyStartDateDesc(data.quotesArray);
        //this.quoteList = data.quotesArray;
        this.showDiv = true;
        this.loaderService.display(false);
      }, error => {
        this.errorMessage = "No Records Found";
        this.showDiv = true;
        this.loaderService.display(false);
      });
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.insuranceService.getIPAddress().subscribe(data => {
      this.pubIp = data.ip;
      //console.log(this.pubIp)
    }, error => {
      this.errorMessage = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }

  ngAfterViewInit() {
    this.vc.first.nativeElement.focus();
  }

  changeQuote(response: any) {
    this.response = response;
    //console.log(this.response)
  }
  getQuote(response: any) {
    this.response = response;
    this.editQuote();
  }
  editQuote() {
    let response = this.response;
    let postData = {
      transId: response.transId,
      tranSrNo: response.tranSrNo,
      portal: ApiConstants.PORTAL,
      location: ApiConstants.LOCATION,
      ipAddress: this.pubIp,
      userId: ApiConstants.USER_ID,
      lobCode: response.lobCode
    }
    //console.log(JSON.stringify(postData));
    this.loaderService.display(true);
    let values = { "transId": response.transId, "tranSrNo": response.tranSrNo }
    this.insuranceService.getQuotInfo(values).subscribe((res: any) => {
      this.insType = res.insuranceType;
      this.quoteNo = res.quoteNo;
    }, error => {
      this.errorMessage = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
    this.retrieveQuoteService.editQUote(postData).subscribe((data: any) => {
      //console.log(JSON.stringify(data));
      this.loaderService.display(false)
      if (data.respCode == 2000) {
        this.insuranceService.calculatePricing(postData).subscribe((data: any) => {
          //console.log(data);
          if (data.respCode == 2000) {
            let obj = {
              transId: response.transId,
              tranSrNo: response.tranSrNo,
              lobCode: response.lobCode,
              quoteNo: response.quoteNo,
              insType: this.insType
            }
            this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
          } else {
            console.log('error');
            this.loaderService.display(false);
          }
        }, error => {
          this.errorMessage = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        })
      } else {
        console.log('error');
      }
      this.loaderService.display(false);
    }, error => {
      this.errorMessage = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  goToPreviousPage() {
    this.router.navigate(['retrieve-quote'], { queryParams: this.routeData, skipLocationChange: true });
  }
}
