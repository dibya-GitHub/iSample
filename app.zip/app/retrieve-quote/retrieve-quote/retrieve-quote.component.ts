import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
import { ApiConstants } from '../../../shared/api-constants';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { RetrieveQuoteService } from '../services/retrieve-quote.service';

@Component({
  selector: 'app-retrieve-quote',
  templateUrl: './retrieve-quote.component.html',
  styleUrls: ['./retrieve-quote.component.scss']
})
export class RetrieveQuoteComponent implements OnInit {
  emailId: any;
  quoteNo: any;
  mobileNo: any;
  searchBy: string;
  tmpData: any;
  activePolicyArray: any[];
  txnId: any;
  srNo: any;
  polNo: any;
  name: any;
  lobCode: any;
  pubIp: any;
  insType: any;
  error: any = '';
  appUtilObj: AppUtil = new AppUtil();
  discountJSONFileValue: any = {
    "car": 10,
    "home": 30,
    "pab": 10,
    "travel": 10
  };
  postData: any;
  transactionId: any;
  transactionSrNo: any;
  constructor(
    private meta: Meta,
    private router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private retrieveQuoteService: RetrieveQuoteService,
    private insuranceService: InsuranceService,
  ) {
    this.titleService.setTitle('Retrieve Insurance Quotes | Compare Insurance Online Dubai');
    this.meta.addTag({ name: 'description', content: "Get your insurance quote from best Insurance Company in Dubai, Here you can get any insurance quote we've prepared for you - quickly, easily and free of hassle." });
    this.meta.addTag({ name: 'keywords', content: 'compare insurance quotes, compare insurance uae, insurance companies in dubai, car insurance online quotes, home Insurance Quotes, travel insurance quote, vehicle insurance quotes' });

    this.route.queryParams.subscribe(params => {
      let data = params["searchBy"];
      if (data != undefined) {
        this.searchBy = data;
        if (data == 'QPI_EMAIL_ID') {
          this.emailId = params["value"];
        } else if (data == 'QPI_MOBILE_NO') {
          this.mobileNo = params["value"];
        } else {
          this.quoteNo = params["value"];
        }
        this.postData = {
          searchBy: this.searchBy,
          value: params["value"]
        }
      }
    });
  }
  currentIndex: any = 1;

  ngOnInit() {
    window.scrollTo(0, 0);
    this.insuranceService.getIPAddress().subscribe(data => {
      this.pubIp = data.ip;
      //console.log(this.pubIp)
    });
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  afterChange(event) {
    this.currentIndex = $('.for-count.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  slideConfig = {
    "slidesToShow": 3,
    "dots": true,
    "infinite": true,
    "centerMode": true,
    "centerPadding": '0px',
    "variableWidth": true
  };
  getQuoteList() {
    this.error = '';
    this.loaderService.display(true);
    if ((this.emailId === undefined || this.emailId.trim() == '') && (this.quoteNo === undefined || this.quoteNo.trim() == '') && (this.mobileNo === undefined || this.mobileNo.trim() == '')) {
      this.error = 'Please enter quote no. or e-mail address or mobile no.';
      this.loaderService.display(false);
    } else {
      this.postData.value = this.postData.value.trim();
      this.retrieveQuoteService.getQuoteList(this.postData).subscribe((data: any) => {
        if (data.respCode == "2000") {
          if (this.searchBy == 'QPI_QUOT_NO') {
            this.editQuote(data.quotesArray[0]);
          } else {
            this.router.navigate(['retrieve-cust-info'], { queryParams: this.postData, skipLocationChange: true });
          }
        }
      }, error => {
        try {
          this.loaderService.display(false);
          if (JSON.parse(error["_body"]).respCode == "1002") {
            console.log('no records found');
            this.error = JSON.parse(error["_body"]).errMessage;
          } else {
            this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          }
        } catch (err) {
          this.error = 'Sorry, something went wrong.';
        }
      });
    }
  }
  editQuote(response: any) {
    let postData = {
      transId: response.transId,
      tranSrNo: response.tranSrNo,
      portal: ApiConstants.PORTAL,
      location: ApiConstants.LOCATION,
      ipAddress: this.pubIp,
      userId: ApiConstants.USER_ID,
      lobCode: response.lobCode
    }
    //console.log(JSON.stringify(postData));
    this.loaderService.display(true);
    //this.transactionId = response.transId;
    //this.transactionSrNo = response.tranSrNo;
    let values = { "transId": response.transId, "tranSrNo": response.tranSrNo }
    this.insuranceService.getQuotInfo(values).subscribe((res: any) => {
      this.insType = res.insuranceType;
    }, error => {
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
    this.retrieveQuoteService.editQUote(postData).subscribe((data: any) => {
      //console.log(JSON.stringify(data));
      if (data.respCode == 2000) {
        /*if(postData.lobCode == "01"){
          this.getVehicleDetails();
        }*/
        this.insuranceService.calculatePricing(postData).subscribe((data: any) => {
          //console.log(data);
          if (data.respCode == 2000) {
            let obj = {
              transId: response.transId,
              tranSrNo: response.tranSrNo,
              lobCode: response.lobCode,
              quoteNo: this.quoteNo,
              insType: this.insType
            }

            this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
          } else {
            alert('error');
          }
        }, error => {
          let obj = {
            quoteNo: this.quoteNo
          }
          this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
          //this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
          this.loaderService.display(false);
        });
      } else {
        alert('error');
        this.loaderService.display(false);
      }
    }, error => {
      try {
        let err = error.json();
        if (err.respCode == "6001") {
          let obj = {
            errMsg: err.errMessage
          }
          this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
        } else {
          this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        }
        this.loaderService.display(false);
      } catch (err) {
        this.loaderService.display(false);
      }
    });
  }
  email() {
    if (this.emailId.length >= 1) {
      this.quoteNo = '';
      this.mobileNo = '';
      this.searchBy = 'QPI_EMAIL_ID';
      this.postData = { searchBy: this.searchBy, value: this.emailId }
    }
    this.error = '';
  }
  quote() {
    if (this.quoteNo.length >= 1) {
      this.emailId = '';
      this.mobileNo = '';
      this.searchBy = 'QPI_QUOT_NO';
      this.postData = { searchBy: this.searchBy, value: this.quoteNo }
    }
    this.error = '';
  }
  mobile() {
    if (this.mobileNo.length >= 1) {
      this.quoteNo = '';
      this.emailId = '';
      this.searchBy = 'QPI_MOBILE_NO';
      this.postData = { searchBy: this.searchBy, value: this.mobileNo }
    }
    this.error = '';
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //  window.scrollTo({ left: 0, top: 600, behavior: 'smooth' });
  }
  setLocalVal(val: any) {
    window.localStorage.setItem('type', val);
    if (val == 'TP') {
      this.router.navigate(['car-insurance-without-chassi']);
    } else {
      this.router.navigate(['car-insurance']);
    }
  }

  /*getVehicleDetails(){
    this.loaderService.display(true);
    let values = { "transId": this.transactionId, "tranSrNo": this.transactionSrNo }
    this.insuranceService.getQuoteRiskDetails(values).subscribe(res => {
      console.log(res);
    }, error => {
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

  }*/
}
