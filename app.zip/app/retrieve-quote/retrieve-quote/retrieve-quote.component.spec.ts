import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrieveQuoteComponent } from './retrieve-quote.component';

describe('RetrieveQuoteComponent', () => {
  let component: RetrieveQuoteComponent;
  let fixture: ComponentFixture<RetrieveQuoteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetrieveQuoteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrieveQuoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
