import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';

@Injectable({
  providedIn: 'root'
})
export class RetrieveQuoteService {

  requestOption: any;
  baseUrl: any = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  getQuoteList(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_LIST, body, this.requestOption);
  }
  editQUote(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.EDIT_QUOTE, body, this.requestOption);
  }
}
