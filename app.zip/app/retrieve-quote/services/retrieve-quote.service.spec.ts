import { TestBed, inject } from '@angular/core/testing';

import { RetrieveQuoteService } from './retrieve-quote.service';

describe('RetrieveQuoteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RetrieveQuoteService]
    });
  });

  it('should be created', inject([RetrieveQuoteService], (service: RetrieveQuoteService) => {
    expect(service).toBeTruthy();
  }));
});
