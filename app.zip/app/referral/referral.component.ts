import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-referral',
  templateUrl: './referral.component.html',
  styleUrls: ['./referral.component.scss']
})
export class ReferralComponent implements OnInit {
  quoteNo: any;
  showHeading = true;
  payErrMsg: any;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
  ) {
    this.route.queryParams.subscribe(params => {
      this.quoteNo = params["quoteNo"];
      this.payErrMsg = params["errMsg"];
      if (isNaN(this.quoteNo) || this.quoteNo == '') {
        this.showHeading = false;
      }
    });
  }

  ngOnInit() {
  }

}
