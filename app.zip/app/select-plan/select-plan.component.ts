import { Component, NgZone, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
import { PaymentService } from 'src/shared/services/payment.service';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { ApiConstants } from '../../shared/api-constants';
import { CreateQuotation } from '../../shared/interfaces/insurance-plan';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { InsuranceService } from '../../shared/services/insurance.service';
import { MotorDropDownService } from './../car-insurance/services/motor-drop-down.service';

@Component({
  selector: 'app-select-plan',
  templateUrl: './select-plan.component.html',
  styleUrls: ['./select-plan.component.scss']
})
export class SelectPlanComponent implements OnInit {
  checkIns: any = 0;
  tmpParms: any;
  registrationYear: string;
  licenceAge: string;
  slick: any;
  defaultNavTabs: string = 'ul.nav-tabs';

  constructor(
    public insurancePlanService: InsuranceService,
    public motorDropDownService: MotorDropDownService,
    public route: ActivatedRoute,
    public router: Router,
    public zone: NgZone,
    public loaderService: LoaderService,
    public paymentService: PaymentService,
    public pixelService: RocketFuelService
  ) {
    this.route.queryParams.subscribe(params => {
      this.tmpParms = params;
      this.transId = params["transId"];//"475709";//
      this.tranSrNo = params["tranSrNo"];
      this.quoteNo = params["quoteNo"];
      this.PABSeatingCapacity = params["seatingCapacity"];
      this.registrationYear = params["registrationYear"];
      this.lobCode = params["lobCode"];
      this.licenceAge = params["licenceAge"];
      this.policyNumber = params["policyNo"];
      this.type = params["insType"],
        this.vehicleType = params["vehicleType"],
        this.carTransId = params["carTransId"],
        this.insValidYN = params["insValidYN"]
    });
  }
  typeOfCoverModal: string = '';
  carInsurance: boolean = false;
  renewPolicy: boolean = false;
  retrieveQuote: boolean = false;
  homeInsurance: boolean = false;
  cycleInsurance = false;
  travelInsurance: boolean = false;
  pabInsurance: boolean = false;
  travelInfo: any;
  transId: string;
  tranSrNo: string;
  quoteNo: string;
  type: string;
  policyNumber: string;
  lobCode: string;
  createQuoteRes: CreateQuotation;
  quoteNum: any;
  product: any;
  schemes: any;
  coversArray: any[] = [];
  schemeNetPremium: any[] = [];
  productCode: any;
  covers: any;
  isCreated: boolean = false;
  premiumResponse: any[] = [];
  schemesList: any[] = [];
  basicCovers: any[] = [];
  basicFeesArray: any[] = [];
  discountsArray: any[] = [];
  deductiblesArray: any[] = [];
  basicDiscountArray: any[] = [];
  basicDeductiblesArray: any[] = [];
  premiumCovers: any[] = [];
  premiumFeesArray: any[] = [];
  premiumDiscountArray: any[] = [];
  premiumDeductiblesArray: any[] = [];
  premiumplusCovers: any[] = [];
  premiumplusFeesArray: any[] = [];
  premiumplusDiscountArray: any[] = [];
  premiumplusDeductiblesArray: any[] = [];
  //tempBasicDiscountArray:any[]=[];
  tempPremiumDiscountArray: any[] = [];
  tempPremiumplusDiscountArray: any[] = [];
  //tempBasicDeductiblesArray:any[]=[];
  tempPremiumDeductiblesArray: any[] = [];
  tempPremiumplusDeductiblesArray: any[] = [];
  PABDropdown: any[] = [];
  optionalSum: any[] = [];
  comparisionView: boolean = true;
  detailView: boolean = false;
  basicDetailView: boolean = false;
  premiumDetailView: boolean = true;
  premiumplusDetailView: boolean = false;
  basicOptionalSum: number = 0;
  premiumOptionalSum: number = 0;
  premiumplusOptionalSum: number = 0;
  basicTabClass = "tab-pane";
  premiumTabClass = "tab-pane active";
  premiumplusTabClass = "tab-pane";
  PABSeatingCapacity: any;
  basicTabCheck: string = "basic";
  premiumTabCheck: string = "premium active";
  basicOptionalCount: number = 0;
  premiumOptionalCount: number = 0;
  premiumplusOptionalCount: number = 0;
  coversHeadingClass: string = "";
  twoHeadersClass: string = "";
  twoTabWidth: string = "tab-pane"
  twoTabCompareWidth: string = "hidden-xs compare-list";
  twoTabInternalWidth: string = "tab-pane plain-basic light";
  installmentsApplicable: boolean = false;
  basicSchemeCode: string = "";
  premiumSchemeCode: string = "";
  premiumplusSchemeCode: string = ""
  premiumplusInstallmentList: any[] = [];
  premiumInstallmentList: any[] = [];
  basicInstallmentList: any[] = [];
  installmentList: any[] = [];
  installmentDisplay: boolean = false;
  isThirdPartySelected: boolean = false;
  vehicleType: any;
  conditionsArray: any[] = [];
  //limitBenefitPopup:boolean=false;
  selectedCoverName: string = "";
  insuranceTypeVal: string = "";
  schCode: any;
  installmentListMobi: any = [];
  currentSlider: number = 0;
  combinedPremiumplusConditionArray: any[] = [];
  combinedPremiumConditionArray: any[] = [];
  combinedBasicConditionArray: any[] = [];
  combinedConditionArray: any[] = [];
  conditionCodeArray: any[] = [];
  homeDropdownArray: any[] = [];
  popupColumnClass: any = "col-md-2 col-sm-2 font-size-14";
  emailId: string = "";
  showEmailModal: boolean = false;
  visibleAnimate: boolean = false;
  visibleBenefitLimit: boolean = false;
  showBenefitLimitModal: boolean = false;
  showOptionSwitchToThirdParty: boolean = false;
  showOptionSwitchToComprehensiveCar: boolean = false;
  deductiblesCodes: any[] = [];
  discountCodes: any[] = [];
  homeDropdownValue: any;
  sliderArray: any;
  slideValue: any;
  isBasicScheme: boolean = false;
  isPremiumScheme: boolean = false;
  isPremiumPlusScheme: boolean = false;
  carTransId: string;
  insValidYN: any;
  ifTelematics: string = "0";
  ngOnInit() {
    this.homeDropdownValue = "";
    var getQuoteResponse;
    console.log(window.location.href);
    this.loaderService.display(true);
    let postData = { 'paraType': 'HOME_LIMITS' };

    this.insurancePlanService.getApplicationParameters(postData).subscribe((response: any) => {
      console.log("response getApplicationParameters");
      console.log(response);
      this.homeDropdownArray = response.appParamsArray;
    });
    let data = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo
    };

    this.insurancePlanService.getQuoteInfo(data).subscribe((response: any) => {
      if (response.respCode == "2000") {
        this.emailId = response.emailId;
        this.insuranceTypeVal = response.insuranceType;
        this.ifTelematics = response.telematicsYn;
        console.log("this.ifTelematics", this.ifTelematics);
        //  alert(response.prodShortDesc);

        this.selectedHeader();
      }

    }, error => {
      console.log('inside error');
      this.loaderService.display(false);
    });



    //  this.PABDropdown = this.motorDropDownService.getSeatingCapacity();
    for (var i = 1; i <= 10; i++) {
      this.PABDropdown.push(i);
    }
    for (var i = 0; i < this.PABDropdown.length; i++) {
      if (this.PABDropdown[i] > this.PABSeatingCapacity) {
        this.PABDropdown.splice(i);
      }
    }
    console.log("PAB Dropdown------------");
    console.log(this.PABDropdown);
    this.getPlanInfo();
    this.installmentApplicable();

  }
  slideConfig1 = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "arrows": true
  };
  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "appendArrows": "swipe-continue-text"
  };


  setGoogleAnalyticsPages(fromUrl) {
    window.localStorage.setItem('urlFlow', fromUrl);
    var pathName = fromUrl + '/select-plan';
    (<any>window).gtag('set', 'page', pathName);
    (<any>window).gtag('send', 'pageview', pathName);
    (<any>window).gtag('config', 'UA-68986372-1', { 'page_path': pathName });
  }

  selectedHeader() {
    if (window.location.href.indexOf("/home-insurance") > -1) {
      this.homeInsurance = true;
      this.setGoogleAnalyticsPages('/home-insurance');
    }
    if (window.location.href.indexOf("/cycle-insurance") > -1) {
      this.cycleInsurance = true;
      this.setGoogleAnalyticsPages('/cycle-insurance');
    }
    if (window.location.href.indexOf("/travel-insurance") > -1) {
      this.travelInsurance = true;
      this.setGoogleAnalyticsPages('/travel-insurance');
    }
    if (window.location.href.indexOf("/renew-policy") > -1) {
      this.renewPolicy = true;
      if (this.lobCode == ApiConstants.CAR_INSURANCE_LOBCODE) {
        if (this.isThirdPartySelected == true) {
          this.carInsurance = false;
          console.log(this.isThirdPartySelected);
        } else {
          this.carInsurance = true;
        }
        this.setGoogleAnalyticsPages('/renew-policy/car-insurance');
      }
      //  alert(this.carInsurance);
      if (this.lobCode == ApiConstants.HOME_INSURANCE_LOBCODE) {
        this.homeInsurance = true;
        this.setGoogleAnalyticsPages('/renew-policy/home-insurance');
      }
      if (this.lobCode == ApiConstants.PAB_INSURANCE_LOBCODE) {

        if (this.insuranceTypeVal == "PAB") {
          this.pabInsurance = true;
          this.setGoogleAnalyticsPages('/renew-policy/pab-insurance');
        } else {
          this.travelInsurance = true;
          this.setGoogleAnalyticsPages('/renew-policy/travel-insurance');
        }

      }
    }
    if (window.location.href.indexOf("/retrieve-quote") > -1) {
      this.retrieveQuote = true;
      if (this.lobCode == ApiConstants.CYCLE_INSURANCE_LOBCODE && this.insuranceTypeVal == "HOME_CYL") {
        this.cycleInsurance = true;
        this.setGoogleAnalyticsPages('/retrieve-quote/cycle-insurance');
      }
      if (this.lobCode == ApiConstants.CAR_INSURANCE_LOBCODE) {
        if (this.isThirdPartySelected == true) {
          this.carInsurance = false;
          console.log(this.isThirdPartySelected);
        } else {
          this.carInsurance = true;
        }
        //  this.carInsurance=true;

        if (this.ifTelematics == "0") {
          this.setGoogleAnalyticsPages('/retrieve-quote/car-insurance');
        } else {
          this.setGoogleAnalyticsPages('/retrieve-quote/safe-driver');
        }

      }
      if (this.lobCode == ApiConstants.HOME_INSURANCE_LOBCODE) {
        this.homeInsurance = true;
        this.setGoogleAnalyticsPages('/retrieve-quote/home-insurance');
      }
      if (this.lobCode == ApiConstants.PAB_INSURANCE_LOBCODE) {

        if (this.insuranceTypeVal == "PAB") {
          this.pabInsurance = true;
          this.setGoogleAnalyticsPages('/retrieve-quote/pab-insurance');
        } else {
          this.travelInsurance = true;
          this.setGoogleAnalyticsPages('/retrieve-quote/travel-insurance');
        }
      }
    }
    if (window.location.href.indexOf("/pab-insurance") > -1) {
      this.pabInsurance = true;
      this.setGoogleAnalyticsPages('/pab-insurance');
    }
    if (window.location.href.indexOf("/car-insurance") > -1) {
      if (this.lobCode == ApiConstants.TRAVEL_INSURANCE_LOBCODE) {
        this.travelInsurance = true;
      } else if (this.lobCode == ApiConstants.HOME_INSURANCE_LOBCODE) {
        this.homeInsurance = true;
      } else if (this.vehicleType == 'TP' || this.vehicleType == 'TPL') {
        this.isThirdPartySelected = true;
      } else {
        this.carInsurance = true;
      }
      this.setGoogleAnalyticsPages('/car-insurance');
    }
    if (window.location.href.indexOf("/safe-driver") > -1) {
      this.carInsurance = true;
      this.setGoogleAnalyticsPages('/safe-driver');
    }
  }
  //method to show comparision view
  openComparisionView() {
    //  alert("openComparisionView");
    console.log(this.carInsurance && this.schemesList[this.checkIns].instlYn == 1)
    console.log(this.schemesList[this.checkIns].instlYn == 1);
    console.log(this.coversArray);
    this.detailView = false;
    this.comparisionView = true;
    console.log("this.comparisionView" + this.comparisionView)
    this.defaultNavTabs = "ul.upper-tabs";
    setTimeout(() => {
      console.log('inside setTimeout');
      this.setTotalPremium();
      this.getInstallmentsForMobile();
      this.setHeightAsPerHeaders(this.defaultNavTabs);
      this.adjustHeadersHeight();
      this.setSchemeCoversHeight();
      this.setSchemeCoversHeightDesktop();

    }, 100);

  }

  //function to set the total premium as per the scheme on mobile comparison view
  setTotalPremium() {
    //console.log('inside total premium function');
    this.sliderArray = <HTMLElement>document.getElementById('comparisonViewSlider');
    console.log(this.sliderArray.length);

    for (var i = 0; i < this.sliderArray.length; i++) {
      console.log(this.sliderArray[i]);

      for (var j = 0; j < (this.sliderArray[i].className.split(/\s+/)).length; j++) {
        if ((this.sliderArray[i].className.split(/\s+/))[j] == 'slick-active') {

          if (this.sliderArray[i].children[0].children[0].id.indexOf('premiumScheme') > -1) {
            console.log('Premium scheme');
            this.isPremiumScheme = true;
            this.isBasicScheme = false;
            this.isPremiumPlusScheme = false;
            this.checkIns = 1;
          } else if (this.sliderArray[i].children[0].children[0].id.indexOf('basicScheme') > -1) {
            console.log('Basic scheme');
            this.isBasicScheme = true;
            this.isPremiumPlusScheme = false;
            this.isPremiumScheme = false;
            this.checkIns = 0;
          } else if (this.sliderArray[i].children[0].children[0].id.indexOf('premiumplusScheme') > -1) {
            console.log('Premium plus scheme');
            this.isPremiumPlusScheme = true;
            this.isBasicScheme = false;
            this.isPremiumScheme = false;
            this.checkIns = 2;
          }
          break;
        }
      }
    }
  }
  //method to show detailed view

  openDetailView() {
    //  alert("openDetailView");
    console.log("Inside details View");
    console.log(this.coversArray);
    this.comparisionView = false;
    this.detailView = true;
    this.showPremiumScheme();
    this.defaultNavTabs = "ul.nav-tabs";
    this.getInstallmentsForMobile();
    setTimeout(() => {
      this.setHeightAsPerHeaders(this.defaultNavTabs);
      //this.setSchemeCoversHeight();
    }, 100);
  }
  //method to show basic detailed view
  showBasicScheme() {
    console.log("showBasic");
    this.detailView = true;
    this.basicDetailView = true;
    this.premiumDetailView = false;
    this.premiumplusDetailView = false;
    this.activeClass();
  }
  //method to show premium detailed view
  showPremiumScheme() {
    this.detailView = true;
    this.premiumDetailView = true;
    this.basicDetailView = false;
    this.premiumplusDetailView = false;
    this.activeClass();
  }
  //method to show premium plus detailed view
  showPremiumplusScheme() {
    this.detailView = true;
    this.premiumplusDetailView = true;
    this.basicDetailView = false;
    this.premiumDetailView = false;
    this.activeClass();

  }
  //method to apply class to various tabs
  activeClass() {
    if (this.basicDetailView) {
      this.basicTabClass = "tab-pane active single-compare-view";
    } else {
      this.basicTabClass = "tab-pane";
    }
    if (this.premiumDetailView) {
      this.premiumTabClass = "tab-pane active single-compare-view";
    } else {
      this.premiumTabClass = "tab-pane";
    }
    if (this.premiumplusDetailView) {
      this.premiumplusTabClass = "tab-pane active three-compare-view";
    } else {
      this.premiumplusTabClass = "tab-pane";
    }
  }
  // updateIsCreated() {
  //   this.isCreated = true;
  // }

  //method is called when user chosses to pay full
  payFull(event: any) {
    if (event.target.checked) {
      this.installmentDisplay = false;
    }

  }
  payFullInst(val: any, index: any) {
    this.loaderService.display(true);
    this.schCode = this.schemesList[index].schCode;
    if (val == 0) {
      this.installmentDisplay = false;
    }
    else {
      this.installmentDisplay = true;
    }
    //alert(JSON.stringify(this.schemesList));
    //alert(index +" : "+JSON.stringify(this.schCode));
    this.updateInstallmentFlag(val);
  }
  //method is called when user chooses to pay in installments
  displayInstallments(event: any) {
    if (event.target.checked) {
      //  this.installmentDisplay=true;
      this.updateInstallmentFlag("1");
    } else {
      this.installmentDisplay = false;
      this.updateInstallmentFlag("0");
    }


  }
  //method to check if installments are applicable or not
  installmentApplicable() {
    var installationAppData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "portal": ApiConstants.PORTAL }
    this.insurancePlanService.getInstallationApplicable(JSON.stringify(installationAppData)).subscribe((response: any) => {
      console.log("Installations Applicable service call");
      console.log(response);
      if (response.option == '1') {
        this.installmentsApplicable = true;

        //this.getInstallments();
      }
    }, error => {

    });
  }

  //method to update if installments selected by user or not
  updateInstallmentFlag(installApplicable: any) {
    var updateInstallmentFlagData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "instlYn": installApplicable };
    console.log("Update Installment Flag");
    console.log(updateInstallmentFlagData);
    this.insurancePlanService.updateInstallmentFlag(JSON.stringify(updateInstallmentFlagData)).subscribe((response: any) => {
      console.log(response);
      if (response.respCode == "2000") {
        if (installApplicable) {
          this.getInstallments();
          //  this.getInstallmentsForMobi();
        } else {
          this.loaderService.display(false);
          this.installmentDisplay = false;
        }
      }
    }, error => {

    });
  }

  getInstallments() {
    this.loaderService.display(true);
    var getInstallmentData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.insurancePlanService.getInstallments(JSON.stringify(getInstallmentData)).subscribe((response: any) => {
      console.log(response);
      if (response.respCode == "2000") {
        //  this.loaderService.display(false);
        this.installmentDisplay = true;
        this.installmentList = response.schemesInstallmentsList;
        for (var i = 0; i < this.installmentList.length; i++) {
          if (this.installmentList[i].schemeCode == this.basicSchemeCode) {
            if (this.schemesList[0].instlYn == 1) {
              this.basicInstallmentList = this.installmentList[i].Installments.sort((n1, n2) => {
                if (n1.instNo > n2.instNo) {
                  return 1;
                }
                if (n1.instNo < n2.instNo) {
                  return -1;
                }
                return 0;
              });
            } else {
              //this.basicInstallmentList[0]="Installment Not Applicable";
            }
          }
          else if (this.installmentList[i].schemeCode == this.premiumSchemeCode) {
            this.premiumInstallmentList = this.installmentList[i].Installments.sort((n1, n2) => {
              if (n1.instNo > n2.instNo) {
                return 1;
              }
              if (n1.instNo < n2.instNo) {
                return -1;
              }
              return 0;
            });
          }
          else if (this.installmentList[i].schemeCode == this.premiumplusSchemeCode) {
            if (this.schemesList[2].instlYn == 1) {
              this.premiumplusInstallmentList = this.installmentList[i].Installments.sort((n1, n2) => {
                if (n1.instNo > n2.instNo) {
                  return 1;
                }
                if (n1.instNo < n2.instNo) {
                  return -1;
                }
                return 0;
              });
            } else {
              //this.premiumplusInstallmentList[0]= "Installment Not Applicable";
            }
          }
        }
        this.loaderService.display(false);
        this.getInstallmentsForMobile();
        //this.installmentListMobi=this.basicInstallmentList;
      }
      console.log(this.basicInstallmentList);
      console.log(this.premiumInstallmentList);
      console.log(this.premiumplusInstallmentList);
    }, error => {
      this.loaderService.display(false);
    });
  }

  //method is used to navigate back to details
  // backToDetails(){
  //   if (this.homeInsurance) {
  //     this.router.navigate(['/home-insurance']);
  //   }else if (this.pabInsurance){
  //       this.router.navigate(['/pab-insurance']);
  //   }else if (this.renewPolicy) {
  //     this.router.navigate(['/renew-policy']);
  //   }else if (this.retrieveQuote) {
  //     this.router.navigate(['/retrieve-quote']);
  //   }else if(this.travelInsurance){
  //     this.router.navigate(['/travel-insurance']);
  //   }
  //   else if(this.carInsurance) {
  //   this.router.navigate(['/car-insurance']);
  //   }
  //
  //
  // }
  emptySchemeArrays() {
    this.detailView = true;
    this.basicDetailView = true;
    this.premiumDetailView = false;
    this.premiumplusDetailView = false;
    this.comparisionView = false;
    this.schemes = this.schemesList = [];
    this.premiumResponse = [];
    this.coversArray = [];
    this.basicCovers = [];
    this.basicFeesArray = [];
    this.basicDiscountArray = [];
    this.basicDeductiblesArray = [];
    this.premiumCovers = [];
    this.premiumFeesArray = [];
    this.premiumDiscountArray = [];
    this.premiumDeductiblesArray = [];
    this.premiumplusCovers = [];
    this.premiumplusFeesArray = [];
    this.premiumplusDiscountArray = [];
    this.premiumplusDeductiblesArray = [];
  }
  switchToComprehensiveCar() {
    //this.ngOnInit();

    this.isThirdPartySelected = false;
    this.carInsurance = true;
    this.loaderService.display(true);
    for (let product of this.product.prodArray) {
      this.showOptionSwitchToComprehensiveCar = false;
      this.showOptionSwitchToThirdParty = true;
      if ((product.prodDesc).search("Third Party Liability") == -1) {
        this.emptySchemeArrays();
        this.getDataWithProduct(product);

      }
    }
  }
  switchToThirdParty() {
    this.isThirdPartySelected = true;
    this.carInsurance = false;
    this.loaderService.display(true);
    for (let product of this.product.prodArray) {
      this.showOptionSwitchToComprehensiveCar = true;
      this.showOptionSwitchToThirdParty = false;
      if ((product.prodDesc).search("Third Party Liability") != -1) {
        this.emptySchemeArrays();
        this.getDataWithProduct(product);
      }
    }
  }
  getDataWithProduct(product: any) {
    //  let product = productArray.prodArray;
    this.productCode = product.prodCode;
    var schemesPostData = { "prodCode": this.productCode, "transId": this.transId, "tranSrNo": this.tranSrNo };
    //used to get all schemes
    this.insurancePlanService.getSchemes(schemesPostData).subscribe((schemeListResponse: any) => {
      console.log("schemeListResponse" + JSON.stringify(schemeListResponse));
      if (schemeListResponse.respCode == 2000) {
        this.schemesList = schemeListResponse.schemesArray;
      }
      //used to get Covers
      this.insurancePlanService.getSchemeCovers(schemesPostData).subscribe(schemeResponse => {
        if (schemeResponse.respCode == 2000) {
          this.schemes = schemeResponse.schemesArray;
          console.log("schemePremium : " + JSON.stringify(this.schemes));
          this.schemesList = this.schemesList.sort((n1, n2) => {
            if (n1.dispOrder > n2.dispOrder) {
              return 1;
            }

            if (n1.dispOrder < n2.dispOrder) {
              return -1;
            }
            return 0;
          });
          //console.log("this.schemesList", this.schemesList[2].instlYn)
          console.log("Sorted Array---------------");
          console.log(this.schemesList);
          //  for(var i=0;i<this.schemesList.length;i++){
          for (let scheme of this.schemes) {
            for (let schemeCoversArray of scheme.coversArray) {
              if (schemeCoversArray.coverCondtYN == "1" && (this.travelInsurance || this.pabInsurance)) {
                let postData = {
                  "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": schemeCoversArray.schCode,
                  "coverCode": schemeCoversArray.coverCode
                }
                console.log("postData for getCoverCondition----" + JSON.stringify(postData));
                this.getCoverConditionsForPABTravel(postData);
              }
            }
            //  this.populateCombinedBenefitsArray();
            if (this.schemesList[0] != undefined && scheme.schCode == this.schemesList[0].schCode) {
              this.basicSchemeCode = this.schemesList[0].schCode;
              this.basicCovers = scheme.coversArray;
              this.basicFeesArray = scheme.feesArray;
              this.basicDiscountArray = scheme.discountsArray;
              //this.tempBasicDiscountArray = Object.assign([], this.basicDiscountArray);
              this.basicDeductiblesArray = scheme.deductiblesArray;
              // console.log("Assigning basic");
              // console.log(this.tempBasicDiscountArray);
              this.premiumResponse.push({ ["schCode"]: scheme.schCode, "schDescription": scheme.schDesc.replace(/\*/g, ""), "schemePremium": scheme.premium, ["prodCode"]: this.productCode, "bestBuyYn": scheme.bestBuyYn, "instlYN": scheme.instlYN });

            }
            if (this.schemesList[1] != undefined && scheme.schCode == this.schemesList[1].schCode) {
              this.premiumSchemeCode = this.schemesList[1].schCode;
              this.premiumCovers = scheme.coversArray;
              this.premiumFeesArray = scheme.feesArray;

              this.premiumDiscountArray = scheme.discountsArray;
              //this.tempPremiumDiscountArray = Object.assign([], this.premiumDiscountArray);
              //  console.log("Assigning premium");
              //    console.log(this.tempPremiumDiscountArray);
              this.premiumDeductiblesArray = scheme.deductiblesArray;
              this.premiumResponse.push({ ["schCode"]: scheme.schCode, "schDescription": scheme.schDesc.replace(/\*/g, ""), "schemePremium": scheme.premium, ["prodCode"]: this.productCode, "bestBuyYn": scheme.bestBuyYn, "instlYN": scheme.instlYN });
            }
            if (this.schemesList[2] != undefined && scheme.schCode == this.schemesList[2].schCode) {
              this.premiumplusSchemeCode = this.schemesList[2].schCode;
              this.premiumplusCovers = scheme.coversArray;
              this.premiumplusFeesArray = scheme.feesArray;
              this.premiumplusDiscountArray = scheme.discountsArray;
              //  this.tempPremiumplusDiscountArray = Object.assign([], this.premiumplusDiscountArray);
              //  console.log("Assigning premium plus");
              //    console.log(this.premiumplusDiscountArray);
              this.premiumplusDeductiblesArray = scheme.deductiblesArray;
              this.premiumResponse.push({ ["schCode"]: scheme.schCode, "schDescription": scheme.schDesc.replace(/\*/g, ""), "schemePremium": scheme.premium, ["prodCode"]: this.productCode, "bestBuyYn": scheme.bestBuyYn, "instlYN": this.schemesList[2].instlYn });
            }

            console.log("Premium Covers");
            console.log(this.premiumResponse);
            console.log(this.basicCovers);
            console.log(this.premiumCovers);
            console.log(this.premiumplusCovers);
          }

          ///  }
          if (this.premiumResponse.length == 1) {
            this.popupColumnClass = "col-md-6 font-size-14"
          }
          if (this.premiumResponse.length == 2) {
            this.popupColumnClass = "col-md-3 font-size-14"
          }
          if (this.premiumResponse.length == 2) {
            console.log("Inside premium Response");
            this.coversHeadingClass = "twoSchemeCoversView";
            this.twoHeadersClass = "twoHedersClass";
            this.twoTabWidth = "tab-pane twoTabWidth";
            this.twoTabCompareWidth = "hidden-xs compare-list twoTabCompareWidth";
            this.twoTabInternalWidth = "tab-pane plain-basic light twoTabInternalWidth";
            this.basicTabCheck = "basic twoHeadersSingleView";
            this.premiumTabCheck = "premium active twoHeadersSingleView";
          }
          else if (this.premiumResponse.length == 3) {
            console.log("Inside premium Response");
            this.coversHeadingClass = "";
            this.twoHeadersClass = "";
            this.twoTabWidth = "tab-pane";
            this.twoTabCompareWidth = "hidden-xs compare-list";
            this.twoTabInternalWidth = "tab-pane plain-basic light";
            this.basicTabCheck = "basic";
            this.premiumTabCheck = "premium active";
          }

          //used to get list of all the covers
          this.insurancePlanService.getAllCovers(schemesPostData).subscribe(coverResponse => {
            if (coverResponse.respCode == 2000) {
              this.coversArray = coverResponse.coversArray;
              console.log("All covers----");
              console.log(this.coversArray);
              if (this.coversArray.length > 0) {
                this.insertCoverConditions();
                // this.updateInstallmentFlag("1");
                //this.installmentApplicable();
                this.selectParticularView();
                this.loaderService.display(false);
              }
              console.log(this.coversArray);
              if (this.comparisionView) {
                this.openComparisionView();

              }
            }
          },
            error => {
              this.loaderService.display(false);
            });
        }
      },
        error => {
          this.loaderService.display(false);
        });
    }, error => {
      this.loaderService.display(false);
    });

  }
  //This method is used to get product ,schemes and cover details
  getPlanInfo() {

    var productsPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    //used to get all products
    this.insurancePlanService.getProducts(productsPostData).subscribe(productResponse => {
      console.log(JSON.stringify(productResponse));
      if (productResponse.respCode == 2000) {
        this.product = productResponse;
        if (this.product.prodArray.length > 1) {
          this.showOptionSwitchToThirdParty = true;
          console.log("Product Response--------------------");
          console.log(this.product.prodArray);
          for (let product of this.product.prodArray) {
            if ((product.prodDesc).search("Third Party Liability") == -1) {
              if (product.prodShortDesc == 'TP') {

                this.isThirdPartySelected = true;
                this.carInsurance = false;
              } else if (product.prodShortDesc == null) {
                console.log("Inside else---------");
                let data = {
                  "transId": this.transId,
                  "tranSrNo": this.tranSrNo
                };
                this.insurancePlanService.getQuoteVehInfo(data).subscribe((response: any) => {
                  console.log(response);
                  if (response.sumAssured == 0) {
                    this.isThirdPartySelected = true;
                    this.carInsurance = false;
                  }
                  else if (response.sumAssured > 0) {
                    this.isThirdPartySelected = false;

                  }
                }, error => {

                });


              }
              this.getDataWithProduct(product);
            }
          }
        }
        else {
          if (this.product.prodArray[0].prodShortDesc == 'TP') {

            this.isThirdPartySelected = true;
            this.carInsurance = false;
          } else if (this.product.prodArray[0].prodShortDesc == null) {
            console.log("Inside else---------");
            let data = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo
            };
            this.insurancePlanService.getQuoteVehInfo(data).subscribe((response: any) => {
              console.log(response);
              if (response.sumAssured == 0) {
                this.isThirdPartySelected = true;
                this.carInsurance = false;
              }
              else if (response.sumAssured > 0) {
                this.isThirdPartySelected = false;

              }
            }, error => {

            });


          }
          this.getDataWithProduct(this.product.prodArray[0]);
        }

      }
    },
      error => {
        this.loaderService.display(false);
      });
  }

  //checks the length of responses and accordingly which view shoulb be shown
  selectParticularView() {
    // if(this.premiumResponse!=undefined && this.premiumResponse.length>=2){
    //   this.comparisionView=true;
    // }
    if (this.premiumResponse != undefined && this.premiumResponse.length == 1) {

      this.detailView = true;
      this.basicDetailView = true;
      this.premiumDetailView = false;
      this.comparisionView = false;
      this.basicTabCheck = "basic active singleHeaderDetailView";
      this.activeClass();

    }

    this.setHeightAsPerHeaders(this.defaultNavTabs);
    //this.setSchemeCoversHeight();
  }

  setHeightAsPerHeaders(target) {
    console.log(target);
    var max = -1;
    $(target).find('li').each(function () {

      var h = $(this).height();
      max = h > max ? h : max;
    });
    console.log(max);
    $(target).find('li').find('a').each(function () {
      console.log(this);
      $(this).css('height', max - 25);
    });
    //   var height=$('.premium-header').height();


  }
  //adjusting headers Height in case of mobile
  adjustHeadersHeight() {
    var basicHeaderHeight = $('.basic-header').height();
    var premiumHeaderHeight = $('.premium-header').height();
    var premiumplusHeaderHeight = $('.premiumplus-header').height();
    if (basicHeaderHeight > premiumHeaderHeight) {
      $('#basicScheme').css('margin-top', -(basicHeaderHeight - premiumHeaderHeight - 4));
      // $('.basic-header').css('padding')
    }
    else if (basicHeaderHeight > premiumplusHeaderHeight) {
      $('#basicScheme').css('margin-top', -(basicHeaderHeight - premiumplusHeaderHeight - 4));
      // $('.basic-header').css('padding')
    }
    if (premiumHeaderHeight > basicHeaderHeight) {
      $('#premiumScheme').css('margin-top', -(premiumHeaderHeight - basicHeaderHeight - 4));

    }
    else if (premiumHeaderHeight > premiumplusHeaderHeight) {
      $('#premiumScheme').css('margin-top', -(premiumHeaderHeight - premiumplusHeaderHeight - 4));
    }
    if (premiumplusHeaderHeight > basicHeaderHeight) {
      $('#premiumplusScheme').css('margin-top', -(premiumplusHeaderHeight - basicHeaderHeight - 4));

    }
    else if (premiumplusHeaderHeight > premiumHeaderHeight) {
      $('#premiumplusScheme').css('margin-top', -(premiumplusHeaderHeight - premiumHeaderHeight - 4));
    }

  }
  setSchemeCoversHeightDesktop() {
    var desktopCoversHeightArray = [];
    $('.plan-compare-info .summary').find('li.text-ellipsis').each(function () {
      console.log('summary', $(this).outerHeight(), $(this).height());
      desktopCoversHeightArray.push($(this).outerHeight());
    });
    console.log("desktopCoversHeightArray--------------");
    console.log(desktopCoversHeightArray);
    $(".desktop-inclusive-covers").find('li.desktop-scheme-basic').each(function (index) {
      console.log($(this));
      console.log(index);
      console.log("Assigning height");
      if (index >= desktopCoversHeightArray.length) {
        index = index - desktopCoversHeightArray.length;
      }
      $(this).css('height', desktopCoversHeightArray[index] + 'px');
    });
    $(".desktop-inclusive-covers").find('li.desktop-scheme-premium').each(function (index) {
      console.log($(this));
      console.log(index);
      console.log("Assigning height");

      if (index >= desktopCoversHeightArray.length) {
        index = index - desktopCoversHeightArray.length;
      }
      $(this).css('height', desktopCoversHeightArray[index]);
    });
    $(".desktop-inclusive-covers").find('li.desktop-scheme-premiumplus').each(function (index) {
      console.log($(this));
      console.log(index);
      console.log("Assigning height");
      if (index >= desktopCoversHeightArray.length) {
        index = index - desktopCoversHeightArray.length;
      }
      $(this).css('height', desktopCoversHeightArray[index]);
    });
  }
  setSchemeCoversHeight() {
    console.log('inside set scheme covers height');

    var coversHeightArray = [];
    $('.plan-compare-info .summary').find('li.mobile-li').each(function () {

      coversHeightArray.push($(this).outerHeight());

    });
    console.log(coversHeightArray);
    $(".mobile-inclusive-cover").find('li.mobile-scheme-basic').each(function (index) {
      console.log($(this));
      console.log(index);
      console.log("Assigning height");
      if (index >= coversHeightArray.length) {
        index = index - coversHeightArray.length;
      }
      $(this).css('height', coversHeightArray[index]);
    });
    $(".mobile-inclusive-cover").find('li.mobile-scheme-premium').each(function (index) {
      console.log($(this));
      console.log(index);
      console.log("Assigning height");
      if (index >= coversHeightArray.length) {
        index = index - coversHeightArray.length;
      }
      $(this).css('height', coversHeightArray[index]);
    });
    $(".mobile-inclusive-cover").find('li.mobile-scheme-premiumplus').each(function (index) {
      console.log($(this));
      console.log(index);
      console.log("Assigning height");
      if (index >= coversHeightArray.length) {
        index = index - coversHeightArray.length;
      }
      $(this).css('height', coversHeightArray[index]);
    });
  }

  //Inserting conditions in coverArray to that info can be displayed on the ui
  insertCoverConditions() {
    console.log("Inside cover conditions");
    console.log(this.coversArray);
    console.log(this.basicCovers);
    for (var i = 0; i < this.coversArray.length; i++) {

      for (var j = 0; j < this.basicCovers.length; j++) {
        // console.log(this.PABSeatingCapacity);
        console.log(this.coversArray[i].coverCode);
        console.log(this.basicCovers[j].coverCode);
        if (this.PABSeatingCapacity == undefined && this.basicCovers[j].coverCode == "01002") {

          this.PABSeatingCapacity = this.basicCovers[j].psgrLiabSeatCty;
          console.log(this.PABDropdown);
          for (var k = 0; k < this.PABDropdown.length; k++) {
            if (this.PABDropdown[k] > this.PABSeatingCapacity) {
              this.PABDropdown.splice(k);
            }
          }
        }
        console.log("above if --------" + this.coversArray[i].coverCode);

        if (this.coversArray[i].coverCode == this.basicCovers[j].coverCode) {

          this.coversArray[i]['basic'] = 'true';
          this.coversArray[i]['basicCoverDescription'] = this.basicCovers[j].coverDesc;
          this.coversArray[i]['basicSchemeCode'] = this.basicCovers[j].schCode;
          this.coversArray[i]['basicPremiumValue'] = this.basicCovers[j].premium;
          this.coversArray[i]['basicType'] = this.basicCovers[j].type;
          this.coversArray[i]['includeCoverBasic'] = this.basicCovers[j].inclYN;
          this.coversArray[i]['basicHelpText'] = this.basicCovers[j].helpText;
          this.coversArray[i]['basicFieldType'] = this.basicCovers[j].fldType;

          this.coversArray[i]['basicCoverCondition'] = this.basicCovers[j].coverCondtYN;


          if (this.basicCovers[j].type == 'O') {
            this.optionalSum.push({ "type": 'basic', "coverCode": this.basicCovers[j].coverCode, "schCode": this.basicCovers[j].schCode, "schemePremium": this.basicCovers[j].premium, "selected": "false" });
          }
        }
      }
      for (var j = 0; j < this.premiumCovers.length; j++) {

        if (this.coversArray[i].coverCode === this.premiumCovers[j].coverCode) {
          this.coversArray[i]['premium'] = 'true';
          this.coversArray[i]['premiumCoverDescription'] = this.premiumCovers[j].coverDesc;
          this.coversArray[i]['premiumSchemeCode'] = this.premiumCovers[j].schCode;
          this.coversArray[i]['premiumPremiumValue'] = this.premiumCovers[j].premium;
          this.coversArray[i]['premiumType'] = this.premiumCovers[j].type;
          this.coversArray[i]['includeCoverPremium'] = this.premiumCovers[j].inclYN;
          this.coversArray[i]['premiumHelpText'] = this.premiumCovers[j].helpText;
          this.coversArray[i]['premiumFieldType'] = this.premiumCovers[j].fldType;

          this.coversArray[i]['premiumCoverCondition'] = this.premiumCovers[j].coverCondtYN;


          if (this.premiumCovers[j].type == 'O') {
            this.optionalSum.push({ "type": 'premium', "coverCode": this.premiumCovers[j].coverCode, "schCode": this.premiumCovers[j].schCode, "schemePremium": this.premiumCovers[j].premium, "selected": "false" });
          }
        }
      }
      for (var j = 0; j < this.premiumplusCovers.length; j++) {

        if (this.coversArray[i].coverCode === this.premiumplusCovers[j].coverCode) {
          this.coversArray[i]['premiumplus'] = 'true';
          this.coversArray[i]['premiumplusCoverDescription'] = this.premiumplusCovers[j].coverDesc;
          this.coversArray[i]['premiumplusSchemeCode'] = this.premiumplusCovers[j].schCode;
          this.coversArray[i]['premiumplusPremiumValue'] = this.premiumplusCovers[j].premium;
          this.coversArray[i]['premiumplusType'] = this.premiumplusCovers[j].type;
          this.coversArray[i]['includeCoverPremiumplus'] = this.premiumplusCovers[j].inclYN;
          this.coversArray[i]['premiumplusHelpText'] = this.premiumplusCovers[j].helpText;
          this.coversArray[i]['premiumplusFieldType'] = this.premiumplusCovers[j].fldType;

          this.coversArray[i]['premiumplusCoverCondition'] = this.premiumplusCovers[j].coverCondtYN;

          if (this.premiumplusCovers[j].type == 'O') {
            this.optionalSum.push({ "type": 'premiumplus', "coverCode": this.premiumplusCovers[j].coverCode, "schCode": this.premiumplusCovers[j].schCode, "schemePremium": this.premiumplusCovers[j].premium, "selected": "false" });
          }
        }
      }

    }
    this.coversArray = this.coversArray.sort((n1, n2) => {
      if (n1.dispOrder > n2.dispOrder) {
        return 1;
      }

      if (n1.dispOrder < n2.dispOrder) {
        return -1;
      }

      if (n1.dispOrder == n2.dispOrder) {
        return 1;
      }
      return 0;
    });
    console.log("Sorted Covers Array-------");
    console.log(this.coversArray);
    this.sumOptionalCover();
    this.optionalCoverCount();
    this.populateDiscountArray();
    this.populateDeductiblesArray();
  }

  //this methos is used to calculate count of various optional covers
  optionalCoverCount() {
    for (var i = 0; i < this.coversArray.length; i++) {
      if (this.coversArray[i].basic == 'true' && this.coversArray[i].basicType == 'O') {
        this.basicOptionalCount++;
      }
      if (this.coversArray[i].premium == 'true' && this.coversArray[i].premiumType == 'O') {
        this.premiumOptionalCount++;
      }
      if (this.coversArray[i].premiumplus == 'true' && this.coversArray[i].premiumplusType == 'O') {
        this.premiumplusOptionalCount++;
      }

    }
  }

  //populateDiscount Aray
  populateDiscountArray() {
    this.discountsArray = [];


    // if(this.basicDiscountArray==undefined || this.basicDiscountArray.length==0){
    //   this.basicDiscountArray=this.tempBasicDiscountArray;
    //   console.log(this.basicDiscountArray);
    //   console.log("Assigning basic inside populate");
    //   console.log(this.tempBasicDiscountArray);
    // }
    // if(this.premiumDiscountArray==undefined || this.premiumDiscountArray.length==0){
    //   this.premiumDiscountArray=this.tempPremiumDiscountArray;
    //   console.log(this.premiumDiscountArray);
    //   console.log("Assigning premium inside populate");
    //   console.log(this.tempPremiumDiscountArray);
    //     this.tempPremiumDiscountArray=[];
    // }
    // if(this.premiumplusDiscountArray==undefined || this.premiumplusDiscountArray.length==0){
    //   this.premiumplusDiscountArray=this.tempPremiumplusDiscountArray;
    //   console.log(this.premiumplusDiscountArray);
    //   console.log("Assigning premiumplus inside populate");
    //   console.log(this.tempPremiumplusDiscountArray);
    //   this.tempPremiumplusDiscountArray=[];
    // }
    if (this.basicDiscountArray != undefined && this.basicDiscountArray.length > 0) {
      console.log("Basic Discount Array------------");
      console.log(this.basicDiscountArray.length);
      for (var i = 0; i < this.basicDiscountArray.length; i++) {
        this.discountsArray.push({ "discountCode": this.basicDiscountArray[i].code, "discDescription": this.basicDiscountArray[i].desc, "basicDiscValue": this.basicDiscountArray[i].value, "basic": "true" });
        this.discountCodes.push(this.basicDiscountArray[i].code);
      }
    }
    else if (this.basicDiscountArray.length == 0 && this.premiumDiscountArray != undefined && this.premiumDiscountArray.length > 0) {
      for (var i = 0; i < this.premiumDiscountArray.length; i++) {
        this.discountsArray.push({ "discountCode": this.premiumDiscountArray[i].code, "discDescription": this.premiumDiscountArray[i].desc, "premiumDiscValue": this.premiumDiscountArray[i].value, "premium": "true" });
        this.discountCodes.push(this.premiumDiscountArray[i].code);
      }
    }
    else if (this.premiumDiscountArray.length == 0 && this.premiumplusDiscountArray != undefined && this.premiumplusDiscountArray.length > 0) {
      for (var i = 0; i < this.premiumplusDiscountArray.length; i++) {
        this.discountsArray.push({ "discountCode": this.premiumplusDiscountArray[i].code, "discDescription": this.premiumplusDiscountArray[i].desc, "premiumplusDiscValue": this.premiumplusDiscountArray[i].value, "premiumplus": "true" });
        this.discountCodes.push(this.premiumplusDiscountArray[i].code);
      }
    }
    for (var i = 0; i < this.premiumDiscountArray.length; i++) {
      if (this.discountCodes.indexOf(this.premiumDiscountArray[i].code) == -1) {
        this.discountsArray.push({ "discountCode": this.premiumDiscountArray[i].code, "discDescription": this.premiumDiscountArray[i].desc, "premiumDiscValue": this.premiumDiscountArray[i].value, "premium": "true" });
      }
    }
    for (var i = 0; i < this.premiumplusDiscountArray.length; i++) {
      if (this.discountCodes.indexOf(this.premiumplusDiscountArray[i].code) == -1) {
        this.discountsArray.push({ "discountCode": this.premiumplusDiscountArray[i].code, "discDescription": this.premiumplusDiscountArray[i].desc, "premiumplusDiscValue": this.premiumplusDiscountArray[i].value, "premiumplus": "true" });
      }
    }
    if (this.discountsArray != undefined) {
      for (var i = 0; i < this.discountsArray.length; i++) {

        if (this.premiumDiscountArray != undefined) {
          for (var j = 0; j < this.premiumDiscountArray.length; j++) {

            if (this.discountsArray[i].discountCode == this.premiumDiscountArray[j].code) {
              this.discountsArray[i]["premium"] = "true";
              this.discountsArray[i]["premiumDiscValue"] = this.premiumDiscountArray[j].value;
              // this.tempPremiumDiscountArray.push(this.premiumDiscountArray[j]);
              // console.log("Temp premium");
              // console.log(this.tempPremiumDiscountArray);
              // this.premiumDiscountArray.splice(j);
            }
          }

        }


      }
    }
    if (this.discountsArray != undefined) {
      for (var i = 0; i < this.discountsArray.length; i++) {
        if (this.premiumplusDiscountArray != undefined) {
          for (var j = 0; j < this.premiumplusDiscountArray.length; j++) {

            if (this.discountsArray[i].discountCode == this.premiumplusDiscountArray[j].code) {
              this.discountsArray[i]["premiumplus"] = "true";
              this.discountsArray[i]["premiumplusDiscValue"] = this.premiumplusDiscountArray[j].value;
              // this.tempPremiumplusDiscountArray.push(this.premiumplusDiscountArray[j]);
              // console.log("Temp premium");
              // console.log(this.tempPremiumplusDiscountArray);
              // this.premiumplusDiscountArray.splice(j);
            }
          }
        }
      }
    }


    //   if(this.premiumDiscountArray!=undefined){
    //   for(var i=0;i<this.premiumDiscountArray.length;i++){
    //     this.discountsArray.push({ "discountCode": this.premiumDiscountArray[i].code,"discDescription":this.premiumDiscountArray[i].desc, "value": this.premiumDiscountArray[i].value, "premium":"true"  });
    //   }
    // }
    // if(this.premiumplusDiscountArray!=undefined){
    //   for(var i=0;i<this.premiumplusDiscountArray.length;i++){
    //     this.discountsArray.push({ "discountCode": this.premiumplusDiscountArray[i].code,"discDescription":this.premiumplusDiscountArray[i].desc, "value": this.premiumplusDiscountArray[i].value, "premiumplus":"true"  });
    //   }
    // }

    console.log("Discounts Array------------------------");
    console.log(this.discountsArray);
  }

  //this method ids used to populate deductibles Array
  populateDeductiblesArray() {


    this.deductiblesArray = [];
    // if(this.premiumDeductiblesArray==undefined || this.premiumDeductiblesArray.length==0){
    //   this.premiumDeductiblesArray=this.tempPremiumDeductiblesArray;
    //   this.tempPremiumDeductiblesArray=[];
    // }
    // if(this.premiumplusDeductiblesArray==undefined || this.premiumplusDeductiblesArray.length==0){
    //   this.premiumplusDeductiblesArray=this.tempPremiumplusDeductiblesArray;
    //
    //   this.tempPremiumplusDeductiblesArray=[];
    // }
    console.log(this.basicDeductiblesArray);
    if (this.basicDeductiblesArray != undefined && this.basicDeductiblesArray.length > 0) {
      for (var i = 0; i < this.basicDeductiblesArray.length; i++) {
        this.deductiblesArray.push({ "dedCode": this.basicDeductiblesArray[i].code, "discDescription": this.basicDeductiblesArray[i].desc, "basicDiscValue": this.basicDeductiblesArray[i].value, "basic": "true" });
        this.deductiblesCodes.push(this.basicDeductiblesArray[i].code);
      }
    }
    else if (this.basicDeductiblesArray.length == 0 && this.premiumDeductiblesArray != undefined && this.premiumDeductiblesArray.length > 0) {
      for (var i = 0; i < this.premiumDeductiblesArray.length; i++) {
        this.deductiblesArray.push({ "dedCode": this.premiumDeductiblesArray[i].code, "discDescription": this.premiumDeductiblesArray[i].desc, "premiumDiscValue": this.premiumDeductiblesArray[i].value, "premium": "true" });
        this.deductiblesCodes.push(this.premiumDeductiblesArray[i].code);
      }
    }
    else if (this.premiumDeductiblesArray.length == 0 && this.premiumplusDeductiblesArray != undefined && this.premiumplusDeductiblesArray.length > 0) {
      for (var i = 0; i < this.premiumDeductiblesArray.length; i++) {
        this.deductiblesArray.push({ "dedCode": this.premiumplusDeductiblesArray[i].code, "discDescription": this.premiumplusDeductiblesArray[i].desc, "premiumplusDiscValue": this.premiumplusDeductiblesArray[i].value, "premiumplus": "true" });
        this.deductiblesCodes.push(this.premiumplusDeductiblesArray[i].code);
      }
    }

    for (var i = 0; i < this.premiumDeductiblesArray.length; i++) {
      if (this.deductiblesCodes.indexOf(this.premiumDeductiblesArray[i].code) == -1) {
        this.deductiblesArray.push({ "dedCode": this.premiumDeductiblesArray[i].code, "discDescription": this.premiumDeductiblesArray[i].desc, "value": this.premiumDeductiblesArray[i].value, "premium": "true" });
      }
    }
    for (var i = 0; i < this.premiumplusDeductiblesArray.length; i++) {
      if (this.deductiblesCodes.indexOf(this.premiumplusDeductiblesArray[i].code) == -1) {
        this.deductiblesArray.push({ "dedCode": this.premiumplusDeductiblesArray[i].code, "discDescription": this.premiumplusDeductiblesArray[i].desc, "value": this.premiumplusDeductiblesArray[i].value, "premiumplus": "true" });
      }
    }

    if (this.deductiblesArray != undefined) {
      for (var i = 0; i < this.deductiblesArray.length; i++) {
        if (this.premiumDeductiblesArray != undefined) {
          console.log("this.premiumDeductiblesArray");
          console.log(this.premiumDeductiblesArray);
          for (var j = 0; j < this.premiumDeductiblesArray.length; j++) {

            if (this.deductiblesArray[i].dedCode == this.premiumDeductiblesArray[j].code) {
              this.deductiblesArray[i]["premium"] = "true";
              this.deductiblesArray[i]["premiumDiscValue"] = this.premiumDeductiblesArray[j].value;
              // this.tempPremiumDeductiblesArray.push(this.premiumDeductiblesArray[j]);
              // console.log("Temp premium");
              // console.log(this.tempPremiumDeductiblesArray);
              // this.premiumDeductiblesArray.splice(j);
            }
          }
        }

      }
    }
    if (this.deductiblesArray != undefined) {
      for (var i = 0; i < this.deductiblesArray.length; i++) {
        if (this.premiumplusDeductiblesArray != undefined) {
          for (var j = 0; j < this.premiumplusDeductiblesArray.length; j++) {

            if (this.deductiblesArray[i].dedCode == this.premiumplusDeductiblesArray[j].code) {
              this.deductiblesArray[i]["premiumplus"] = "true";
              this.deductiblesArray[i]["premiumplusDiscValue"] = this.premiumplusDeductiblesArray[j].value;
              // this.tempPremiumplusDeductiblesArray.push(this.premiumplusDeductiblesArray[j]);
              // console.log("Temp premium");
              // console.log(this.tempPremiumplusDeductiblesArray);
              // this.premiumplusDeductiblesArray.splice(j);
            }
          }
        }
      }
    }
    // if(this.premiumDeductiblesArray!=undefined){
    //   for(var i=0;i<this.premiumDeductiblesArray.length;i++){
    //     this.deductiblesArray.push({ "dedCode": this.premiumDeductiblesArray[i].code,"discDescription":this.premiumDeductiblesArray[i].desc, "value": this.premiumDeductiblesArray[i].value, "premium":"true"  });
    //
    //   }
    // }
    //   if(this.premiumplusDeductiblesArray!=undefined){
    //   for(var i=0;i<this.premiumplusDeductiblesArray.length;i++){
    //     this.deductiblesArray.push({ "dedCode": this.premiumplusDeductiblesArray[i].code,"discDescription":this.premiumplusDeductiblesArray[i].desc, "value": this.premiumplusDeductiblesArray[i].value, "premiumplus":"true"  });
    //
    //   }
    // }
    console.log("Deductibles Array----------------");
    console.log(this.deductiblesArray);
  }
  // this method is used to calculate addition of all optional covers
  sumOptionalCover() {
    this.basicOptionalSum = 0;
    this.premiumOptionalSum = 0;
    this.premiumplusOptionalSum = 0;
    for (var i = 0; i < this.optionalSum.length; i++) {
      if (this.optionalSum[i].selected == 'true') {
        if (this.optionalSum[i].type == 'basic') {
          console.log("Inside SumOptional Cover");
          console.log(this.basicOptionalSum);
          this.basicOptionalSum = this.basicOptionalSum + parseInt(this.optionalSum[i].schemePremium);
          console.log("After update" + this.basicOptionalSum);
        }


        if (this.optionalSum[i].type == 'premium') {
          console.log("Inside SumOptional Cover");
          console.log(this.premiumOptionalSum);
          this.premiumOptionalSum = this.premiumOptionalSum + parseInt(this.optionalSum[i].schemePremium);
          console.log("After Update" + this.premiumOptionalSum);
        }


        if (this.optionalSum[i].type == 'premiumplus') {
          this.premiumplusOptionalSum = this.premiumplusOptionalSum + parseInt(this.optionalSum[i].schemePremium);
        }
      }

    }
  }
  //this method i used to navigate user to next page(additionalInfo Page)
  proceed(premiumSelected: any) {

    var instlYN = '0';
    if (this.installmentDisplay == true) {
      instlYN = '1';
    }
    else if (this.installmentDisplay == false) {
      instlYN = '0';
    }
    this.loaderService.display(true);
    console.log("premiumSelected : " + JSON.stringify(premiumSelected));

    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      registrationYear: this.registrationYear,
      licenceAge: this.licenceAge,
      carInsType: this.isThirdPartySelected.toString(),
      carTransId: this.carTransId,
      lobCode: this.lobCode,
      vehicleType: this.vehicleType,
      ifTelematics: this.ifTelematics,
      insValidYN: this.insValidYN
    }
    var insuranceplanData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": premiumSelected.prodCode, "schCode": premiumSelected.schCode, "instYN": instlYN, "bundleYN": "0", "portal": ApiConstants.PORTAL };

    //used to update the scheme selected by user
    this.insurancePlanService.updateProductScheme(insuranceplanData).subscribe((response: any) => {
      console.log(response);
      if (response.respCode == 2000) {
        this.pixelService.pixelFireValue('Universal');
        this.pixelService.pixelFireValue('4');
        if (this.cycleInsurance) {
          this.router.navigate(['additional-cycle-info'], { queryParams: obj, skipLocationChange: true });
        } else if (this.homeInsurance) {
          this.router.navigate(['additional-home-info'], { queryParams: obj, skipLocationChange: true });
        } else if (this.pabInsurance) {
          this.router.navigate(['additional-pab-info'], { queryParams: obj, skipLocationChange: true })
        } else if (this.renewPolicy) {
          if (this.lobCode == ApiConstants.CAR_INSURANCE_LOBCODE) {
            this.router.navigate(['carDetails'], { queryParams: obj, skipLocationChange: true });
          } else {
            this.router.navigate(['additional-home-info'], { queryParams: obj, skipLocationChange: true });
          }
        } else if (this.retrieveQuote) {
          console.log(ApiConstants.CAR_INSURANCE_LOBCODE)
          if (this.lobCode == ApiConstants.CAR_INSURANCE_LOBCODE) {
            this.router.navigate(['carDetails'], { queryParams: obj, skipLocationChange: true });
          } else if (this.lobCode == ApiConstants.PAB_INSURANCE_LOBCODE && this.type == "PAB") {
            this.loaderService.display(false);
            this.router.navigate(['additional-pab-info'], { queryParams: obj, skipLocationChange: true });
          } else if (this.lobCode == ApiConstants.TRAVEL_INSURANCE_LOBCODE) {
            this.loaderService.display(false);
            this.router.navigate(['additional-travel-info'], { queryParams: obj, skipLocationChange: true });
          } else {
            this.router.navigate(['additional-home-info'], { queryParams: obj, skipLocationChange: true });
          }
        } else if (this.travelInsurance) {
          this.router.navigate(['additional-travel-info'], { queryParams: obj, skipLocationChange: true });
        }
        else if (this.carInsurance || this.isThirdPartySelected) {
          this.router.navigate(['carDetails'], { queryParams: obj, skipLocationChange: true });
        }
      }
    }, error => {
      this.loaderService.display(false);
    });
  }
  addOptCover(event: any, coversArr: any, val: any) {
    this.persistRadioVal(event, coversArr, val);
    console.log(coversArr);
    let plan;
    if (val == 0) {
      plan = 'basic';
    } else if (val == 1) {
      plan = 'premium';
    } else {
      plan = 'premiumplus';
    }
    var updateCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": coversArr.prodCode, "schCode": coversArr.schCode, "coverCode": coversArr.coverCode, "mode": "1", "portal": ApiConstants.PORTAL };
    this.addOptionalCover(event, updateCoverData, coversArr, plan);
  }
  //used to update basic optional Cover
  addBasicOptionalCover(event: any, coversArr: any) {

    this.persistRadioVal(event, coversArr, 0);
    var updateCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": coversArr.basicSchemeCode, "coverCode": coversArr.coverCode, "mode": "1", "portal": ApiConstants.PORTAL };
    this.addOptionalCover(event, updateCoverData, coversArr, "basic");
  }

  //used to update premium optional cover
  addPremiumOptionalCover(event: any, coversArr: any) {
    this.persistRadioVal(event, coversArr, 1);
    var updateCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": coversArr.premiumSchemeCode, "coverCode": coversArr.coverCode, "mode": "1", "portal": ApiConstants.PORTAL };
    this.addOptionalCover(event, updateCoverData, coversArr, "premium");
  }

  //used to update premiumplus optional cover
  addPremiumplusOptionalCover(event: any, coversArr: any) {
    this.persistRadioVal(event, coversArr, 2);
    var updateCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": coversArr.premiumplusSchemeCode, "coverCode": coversArr.coverCode, "mode": "1", "portal": ApiConstants.PORTAL };
    this.addOptionalCover(event, updateCoverData, coversArr, "premiumplus");
  }

  //this calls the update optional cover service based on the scheme for which cover needs to be updated
  addOptionalCover(event: any, updateOptionalCover: any, coversArr: any, typeOfScheme: any) {
    console.log(event);

    //console.log(coversArr);
    for (var i = 0; i < this.premiumResponse.length; i++) {
      if (this.premiumResponse[i].schCode == updateOptionalCover.schCode) {
        updateOptionalCover.prodCode = this.premiumResponse[i].prodCode;
      }
    }
    if (event.target.checked) {
      this.loaderService.display(true);
      console.log("upadteOptionalCOver");
      console.log(updateOptionalCover);

      //used to upadte optional cover selection
      this.insurancePlanService.updateOptionalCover(updateOptionalCover).subscribe((response: any) => {
        console.log(response);
        if (response.respCode == 2000) {
          if (this.installmentDisplay == true) {
            //alert();
            this.getInstallments();
          }
          for (var i = 0; i < this.premiumResponse.length; i++) {
            if (this.premiumResponse[i].schCode == updateOptionalCover.schCode) {
              this.premiumResponse[i].schemePremium = response.premium;
              console.log("UPdated Premium afer optional cover selected");
              console.log(response);


            }
          }
          //service call to get the deductibles summary.
          var coverDeductionData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "type": "DED", "prodCode": this.productCode, "schCode": updateOptionalCover.schCode }
          console.log(coverDeductionData);
          this.insurancePlanService.getOptionalCoverDiscDedLoad(JSON.stringify(coverDeductionData)).subscribe((deductionResponse: any) => {
            console.log("DEduction")
            console.log(deductionResponse);

            if (deductionResponse.respCode == '2000') {
              if (typeOfScheme == "basic") {
                this.basicDeductiblesArray = deductionResponse.coversArray;
                console.log(this.basicDeductiblesArray);
                //  this.populateDeductiblesArray();
              }
              if (typeOfScheme == "premium") {
                this.premiumDeductiblesArray = deductionResponse.coversArray;
                //this.populateDeductiblesArray();
              }
              if (typeOfScheme == "premiumplus") {
                this.premiumplusDeductiblesArray = deductionResponse.coversArray;

              }
              this.populateDeductiblesArray();
            }
            // if(response["othersArray"]!="" && response["othersArray"]!=null){
            //   this.deductiblesA = response["othersArray"][0].value;
            // }
          }, error => {

          });

          ////service call to get the discount summary. Need to uncomment this piece of code once the service returns correct results.
          var coverDiscountData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "type": "DISC", "prodCode": this.productCode, "schCode": updateOptionalCover.schCode }
          console.log(coverDiscountData);
          this.insurancePlanService.getOptionalCoverDiscDedLoad(JSON.stringify(coverDiscountData)).subscribe((discountResponse: any) => {
            console.log("Discounts")
            console.log(discountResponse);
            // if(response["othersArray"]!="" && response["othersArray"]!=null){
            //   this.discountsArray = response["othersArray"][0].value;
            // }
            //var updatedDiscountArray=discountResponse.coversArray;
            if (discountResponse.respCode == '2000') {
              if (typeOfScheme == "basic") {
                this.basicDiscountArray = discountResponse.coversArray;
                console.log(this.basicDiscountArray);


              }
              if (typeOfScheme == "premium") {
                this.premiumDiscountArray = discountResponse.coversArray;

              }
              if (typeOfScheme == "premiumplus") {
                this.premiumplusDiscountArray = discountResponse.coversArray;

              }
              this.populateDiscountArray();
            }
          }, error => {

          });
          for (var i = 0; i < this.optionalSum.length; i++) {
            if (this.optionalSum[i].coverCode == updateOptionalCover.coverCode && this.optionalSum[i].schCode == updateOptionalCover.schCode) {
              this.optionalSum[i].selected = "true";

              this.sumOptionalCover();
              console.log("UPdated optional List");
              console.log(this.optionalSum);
            }
          }
          for (var i = 0; i < this.coversArray.length; i++) {
            if (updateOptionalCover.schCode == this.coversArray[i].basicSchemeCode) {
              if (updateOptionalCover.coverCode == this.coversArray[i].coverCode) {
                this.coversArray[i]["basicOptional"] = "true";
                this.coversArray[i]["includeCoverBasic"] = "1";
              }
            }
            if (updateOptionalCover.schCode == this.coversArray[i].premiumSchemeCode) {
              if (updateOptionalCover.coverCode == this.coversArray[i].coverCode) {
                this.coversArray[i]["premiumOptional"] = "true";
                this.coversArray[i]["includeCoverPremium"] = "1";
              }
            }
            if (updateOptionalCover.schCode == this.coversArray[i].premiumplusSchemeCode) {
              if (updateOptionalCover.coverCode == this.coversArray[i].coverCode) {
                this.coversArray[i]["premiumplusOptional"] = "true";
                this.coversArray[i]["includeCoverPremiumplus"] = "1";
              }
            }
          }

          console.log(this.coversArray);
        }
        this.loaderService.display(false);
      }, error => {
        this.loaderService.display(false);
      });

    } else {
      this.loaderService.display(true);
      updateOptionalCover.mode = "0";

      //used to upadte optional cover selection
      this.insurancePlanService.updateOptionalCover(updateOptionalCover).subscribe((response: any) => {
        console.log(response);
        if (response.respCode == 2000) {
          if (this.installmentDisplay == true) {
            //alert();
            this.getInstallments();
          }
          for (var i = 0; i < this.premiumResponse.length; i++) {
            if (this.premiumResponse[i].schCode == updateOptionalCover.schCode) {
              this.premiumResponse[i].schemePremium = response.premium;
              console.log("UPdated Premium afer optional cover deselected");
              console.log(response);
            }
          }
          for (var i = 0; i < this.optionalSum.length; i++) {
            if (this.optionalSum[i].coverCode == updateOptionalCover.coverCode) {
              this.optionalSum[i].selected = "false";
              if (this.optionalSum[i].schCode == updateOptionalCover.schCode) {
                if (this.optionalSum[i].type == 'basic') {
                  this.basicOptionalSum = this.basicOptionalSum - this.optionalSum[i].schemePremium;
                }
                if (this.optionalSum[i].type == 'premium') {
                  this.premiumOptionalSum = this.premiumOptionalSum - this.optionalSum[i].schemePremium;
                }

                if (this.optionalSum[i].type == 'premiumplus') {
                  this.premiumplusOptionalSum = this.premiumplusOptionalSum - this.optionalSum[i].schemePremium;
                }

              }

              console.log("UPdated optional List unselect an optional cover");
              console.log(this.optionalSum);
            }
          }
          for (var i = 0; i < this.coversArray.length; i++) {
            if (updateOptionalCover.schCode == this.coversArray[i].basicSchemeCode) {
              if (updateOptionalCover.coverCode == this.coversArray[i].coverCode) {
                this.coversArray[i]["basicOptional"] = "false";
                this.coversArray[i]["includeCoverBasic"] = "0";
              }
            }
            if (updateOptionalCover.schCode == this.coversArray[i].premiumSchemeCode) {
              if (updateOptionalCover.coverCode == this.coversArray[i].coverCode) {
                this.coversArray[i]["premiumOptional"] = "false";
                this.coversArray[i]["includeCoverPremium"] = "0";
              }
            }
            if (updateOptionalCover.schCode == this.coversArray[i].premiumplusSchemeCode) {
              if (updateOptionalCover.coverCode == this.coversArray[i].coverCode) {
                this.coversArray[i]["premiumplusOptional"] = "false";
                this.coversArray[i]["includeCoverPremiumplus"] = "0";
              }
            }
          }

        } this.loaderService.display(false);
      }, error => {
        this.loaderService.display(false);
      });
    }


  }
  //this method is called when user changes the number of PAB to Passengers
  updatePABSelection(event: any, coversArr: any) {
    console.log(event);
    console.log(coversArr);


    this.zone.run(() => {
      var updateCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "lobCode": this.lobCode, "prodCode": this.productCode, "schCode": "", "coverCode": coversArr.coverCode, "newValue": event, "portal": ApiConstants.PORTAL };

      //used to upadte optional cover selection
      console.log(updateCoverData);
      this.insurancePlanService.updatePABDropdown(updateCoverData).subscribe((response: any) => {

        if (response.respCode == "2000") {
          console.log("PAB update");
          console.log(response.coverPremiums);
          var coversPremiumArray = response.coverPremiums;
          for (var i = 0; i < coversPremiumArray.length; i++) {
            for (var j = 0; j < this.coversArray.length; j++) {
              if (coversPremiumArray[i].coverCode == this.coversArray[j].coverCode) {
                if (coversPremiumArray[i].schCode == this.coversArray[j].basicSchemeCode) {
                  this.coversArray[j].basicPremiumValue = coversPremiumArray[i].premium;
                }
                else if (coversPremiumArray[i].schCode == this.coversArray[j].premiumSchemeCode) {
                  this.coversArray[j].premiumPremiumValue = coversPremiumArray[i].premium;
                }
                else if (coversPremiumArray[i].schCode == this.coversArray[j].premiumplusSchemeCode) {
                  this.coversArray[j].premiumplusPremiumValue = coversPremiumArray[i].premium;
                }
              }
            }
          }
          if (coversArr.basicOptional == "true") {
            var netPremiumData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": coversArr.basicSchemeCode }
            this.getNetSchemePremium(event, netPremiumData);
          }
          if (coversArr.premiumOptional == "true") {
            var netPremiumData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": coversArr.premiumSchemeCode }
            this.getNetSchemePremium(event, netPremiumData);
          }
          if (coversArr.premiumplusOptional == "true") {
            this.getNetSchemePremium(event, netPremiumData);
          }



        }
        console.log("UPdated Premium afer PAB changed");
        console.log(response);
      }, error => {

      });

    });



  }

  getNetSchemePremium(event: any, netPremiumData: any) {
    //  var updatedData = this.premiumResponse;



    //  var netPremiumData={"transId": this.transId, "tranSrNo": this.tranSrNo,"prodCode": this.premiumResponse[i].prodCode, "schCode": this.premiumResponse[i].schCode}
    console.log(netPremiumData);
    this.insurancePlanService.getSchemeNetPremium(JSON.stringify(netPremiumData)).subscribe((netPremiumResponse: any) => {
      this.PABSeatingCapacity = event;

      for (var i = 0; i < this.premiumResponse.length; i++) {
        if (this.premiumResponse[i].schCode == netPremiumData.schCode) {
          this.premiumResponse[i].schemePremium = netPremiumResponse.premium;
          console.log("premiumresponse----------" + netPremiumResponse)
        }
      }

      console.log("Premium Response");
      console.log(this.premiumResponse);

    }
      , error => {

      });



  }
  emailQuote(premiumSelected: any) {
    this.loaderService.display(true);
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      prodCode: premiumSelected.prodCode,
      schCode: premiumSelected.schCode
    }
    console.log("email quote : " + JSON.stringify(postData))
    this.insurancePlanService.emailQuote(postData).subscribe((response: any) => {
      if (response.respCode == "2000") {
        this.loaderService.display(false);
        console.log(response);
        this.showEmailModal = true;
        setTimeout(() => this.visibleAnimate = true, 100);
        console.log("Email Sent");
      }

    })
  }

  hideEmailModal() {
    this.visibleAnimate = false;
    setTimeout(() => this.showEmailModal = false, 300);
  }
  hideBenefitLimitModal() {
    this.visibleBenefitLimit = false;
    setTimeout(() => this.showBenefitLimitModal = false, 300);

  }
  //method used to open benefits/limits popup
  openLimitBenefitPopUp(coversArr: any, typeOfCall: any) {
    console.log("typeOfCall----------" + typeOfCall);
    console.log(coversArr);
    this.conditionsArray = [];
    if (typeOfCall == "Basic" || typeOfCall == this.basicSchemeCode) {
      this.selectedCoverName = coversArr.basicCoverDescription;
      if (coversArr.basicCoverDescription == undefined) {
        this.selectedCoverName = coversArr.coverDesc;
      }
      let postData = {
        "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": this.basicSchemeCode,
        "coverCode": coversArr.coverCode
      }
      this.getCoverConditions(postData);
    }
    else if (typeOfCall == "Premium" || typeOfCall == this.premiumSchemeCode) {
      this.selectedCoverName = coversArr.premiumCoverDescription;
      if (coversArr.premiumCoverDescription == undefined) {
        this.selectedCoverName = coversArr.coverDesc;
      }
      let postData = {
        "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": this.premiumSchemeCode,
        "coverCode": coversArr.coverCode
      }
      this.getCoverConditions(postData);
    }
    else if (typeOfCall == "Premiumplus" || typeOfCall == this.premiumplusSchemeCode) {
      this.selectedCoverName = coversArr.premiumplusCoverDescription;
      if (coversArr.premiumplusCoverDescription == undefined) {
        this.selectedCoverName = coversArr.coverDesc;
      }
      let postData = {
        "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": this.premiumplusSchemeCode,
        "coverCode": coversArr.coverCode
      }
      this.getCoverConditions(postData);
    }

  }
  getCoverConditionsForPABTravel(postData: any) {
    this.insurancePlanService.getCoverConditions(JSON.stringify(postData)).subscribe((response: any) => {
      console.log("inside getCover condition for PAB travel");
      console.log(response);
      if (response.respCode == "2000") {
        //  this.limitBenefitPopup=true;
        // for(var i=0;i<response.conditionsArray.length;i++){
        //   response.conditionsArray[i]['coverCode'] = postData.coverCode;
        // }

        if (this.combinedConditionArray == undefined || this.combinedConditionArray.length == 0) {
          console.log(postData.schCode);
          console.log(this.basicSchemeCode);
          if (postData.schCode == this.basicSchemeCode) {
            for (var i = 0; i < response.conditionsArray.length; i++) {
              this.combinedConditionArray.push({ "condCode": response.conditionsArray[i].condCode, "coverCode": postData.coverCode, "helpText": response.conditionsArray[i].helpText, "basicValue": response.conditionsArray[i].value, "condDesc": response.conditionsArray[i].condDesc, "basic": "true" });
              this.conditionCodeArray.push(response.conditionsArray[i].condCode);
            }
          }
          else if (postData.schCode == this.premiumSchemeCode) {
            for (var i = 0; i < response.conditionsArray.length; i++) {
              this.combinedConditionArray.push({ "condCode": response.conditionsArray[i].condCode, "coverCode": postData.coverCode, "helpText": response.conditionsArray[i].helpText, "premiumValue": response.conditionsArray[i].value, "condDesc": response.conditionsArray[i].condDesc, "premium": "true" });
              this.conditionCodeArray.push(response.conditionsArray[i].condCode);
            }
          }
          else if (postData.schCode == this.premiumplusSchemeCode) {
            for (var i = 0; i < response.conditionsArray.length; i++) {
              this.combinedConditionArray.push({ "condCode": response.conditionsArray[i].condCode, "coverCode": postData.coverCode, "helpText": response.conditionsArray[i].helpText, "premiumplusValue": response.conditionsArray[i].value, "condDesc": response.conditionsArray[i].condDesc, "premiumplus": "true" });
              this.conditionCodeArray.push(response.conditionsArray[i].condCode);
            }
          }
        }

        for (var i = 0; i < response.conditionsArray.length; i++) {
          console.log("response.conditionsArray[i]")
          console.log(response.conditionsArray[i]);
          console.log(typeof (response.conditionsArray[i]));
          for (var j = 0; j < this.combinedConditionArray.length; j++) {
            if (this.combinedConditionArray[j].condCode == response.conditionsArray[i].condCode) {
              if (postData.schCode == this.basicSchemeCode) {
                this.combinedConditionArray[j]["basic"] = "true";
                this.combinedConditionArray[j]["basicValue"] = response.conditionsArray[i].value;

              }
              else if (postData.schCode == this.premiumSchemeCode) {
                this.combinedConditionArray[j]["premium"] = "true";
                this.combinedConditionArray[j]["premiumValue"] = response.conditionsArray[i].value;

              }
              else if (postData.schCode == this.premiumplusSchemeCode) {
                this.combinedConditionArray[j]["premiumplus"] = "true";
                this.combinedConditionArray[j]["premiumplusValue"] = response.conditionsArray[i].value;

              }
            }

          }
          if (this.conditionCodeArray.indexOf(response.conditionsArray[i].condCode) == -1) {
            console.log(this.conditionCodeArray);
            console.log("Inside condiitionCode array -----------" + this.conditionCodeArray.indexOf(response.conditionsArray[i].condCode))
            if (postData.schCode == this.basicSchemeCode) {
              for (var i = 0; i < response.conditionsArray.length; i++) {
                this.combinedConditionArray.push({ "condCode": response.conditionsArray[i].condCode, "coverCode": response.conditionsArray[i].coverCode, "helpText": response.conditionsArray[i].helpText, "basicValue": response.conditionsArray[i].value, "condDesc": response.conditionsArray[i].condDesc, "basic": "true" });
                this.conditionCodeArray.push(response.conditionsArray[i].condCode);
              }
            }
            else if (postData.schCode == this.premiumSchemeCode) {
              for (var i = 0; i < response.conditionsArray.length; i++) {
                this.combinedConditionArray.push({ "condCode": response.conditionsArray[i].condCode, "coverCode": response.conditionsArray[i].coverCode, "helpText": response.conditionsArray[i].helpText, "premiumValue": response.conditionsArray[i].value, "condDesc": response.conditionsArray[i].condDesc, "premium": "true" });
                this.conditionCodeArray.push(response.conditionsArray[i].condCode);
              }
            }
            else if (postData.schCode == this.premiumplusSchemeCode) {
              for (var i = 0; i < response.conditionsArray.length; i++) {
                this.combinedConditionArray.push({ "condCode": response.conditionsArray[i].condCode, "coverCode": response.conditionsArray[i].coverCode, "helpText": response.conditionsArray[i].helpText, "premiumplusValue": response.conditionsArray[i].value, "condDesc": response.conditionsArray[i].condDesc, "premiumplus": "true" });
                this.conditionCodeArray.push(response.conditionsArray[i].condCode);
              }
            }

          }

        }


        var index = 0;
        for (var i = 0; i < response.conditionsArray.length; i++) {

          index = this.combinedConditionArray.indexOf(response.conditionsArray[i].condCode);
          console.log("index" + index);
        }
        //   let found =response.conditionsArray.some(r=> this.combinedConditionArray.includes(r));
        //   console.log("Found----------"+found);
        // //this.combinedBasicConditionArray.push(response.conditionsArray[i]);
      }





      console.log("Combined condition Array------------------");
      console.log(this.combinedConditionArray);
      console.log("Inisde travel PAB get condition");
      //  console.log(this.combinedPremiumplusConditionArray);

    });
  }


  // populateCombinedBenefitsArray(){
  //   console.log("Combined conditional array");
  //   console.log(" If-----------------"+this.combinedBasicConditionArray.length);
  //
  //   console.log(this.combinedBasicConditionArray);
  //   if(this.combinedBasicConditionArray!=undefined){
  //     console.log("Inside If-----------------"+this.combinedBasicConditionArray.length);
  //     for(var i=0;i<this.combinedBasicConditionArray.length;i++){
  //   console.log("Inside for-----------------");
  //       this.combinedConditionArray.push({ "condCode":this.combinedBasicConditionArray[i].condCode,"coverCode": this.combinedBasicConditionArray[i].coverCode,"helpText":this.combinedBasicConditionArray[i].desc, "basicValue": this.combinedBasicConditionArray[i].value,"condDesc":this.combinedBasicConditionArray[i].condDesc, "basic":"true"  });
  //
  //     }
  //   }
  //   console.log("this.combinedConditionArray-------------------------------");
  //   console.log(this.combinedConditionArray);
  //   if(this.combinedConditionArray!=undefined){
  //     for(var i=0;i<this.combinedConditionArray.length;i++){
  //       if(this.combinedPremiumConditionArray!=undefined){
  //         for(var j=0;j<this.combinedPremiumConditionArray.length;j++){
  //
  //           if(this.combinedConditionArray[i].condCode==this.combinedPremiumConditionArray[j].condCode){
  //             this.combinedConditionArray[i]["premium"]="true";
  //             this.combinedConditionArray[i]["premiumValue"]= this.combinedPremiumConditionArray[j].value;
  //             //this.tempPremiumDeductiblesArray.push(this.premiumDeductiblesArray[j]);
  //
  //             this.combinedPremiumConditionArray.splice(j);
  //           }
  //         }
  //       }
  //     }
  // }
  // if(this.combinedConditionArray!=undefined){
  //   for(var i=0;i<this.combinedConditionArray.length;i++){
  //       if(this.combinedPremiumplusConditionArray!=undefined){
  //         for(var k=0;k<this.combinedPremiumplusConditionArray.length;k++){
  //
  //           if(this.combinedConditionArray[i].dedCode==this.combinedPremiumplusConditionArray[k].condCode){
  //             this.combinedConditionArray[i]["premiumplus"]="true";
  //             this.combinedConditionArray[i]["premiumplusValue"]= this.combinedPremiumplusConditionArray[k].value;
  //
  //             this.combinedPremiumplusConditionArray.splice(j);
  //           }
  //         }
  //       }
  //     }
  //
  //     }
  //
  //
  //   if(this.combinedPremiumConditionArray!=undefined){
  //     for(var i=0;i<this.combinedPremiumConditionArray.length;i++){
  //       this.combinedConditionArray.push({ "condCode":this.combinedPremiumConditionArray[i].condCode,"coverCode": this.combinedPremiumConditionArray[i].coverCode,"helpText":this.combinedPremiumConditionArray[i].desc, "basicValue": this.combinedPremiumConditionArray[i].value,"condDesc":this.combinedPremiumConditionArray[i].condDesc, "premium":"true"  });
  //
  //     }
  //   }
  //   if(this.combinedPremiumplusConditionArray!=undefined){
  //     for(var i=0;i<this.combinedPremiumplusConditionArray.length;i++){
  //       this.combinedConditionArray.push({ "condCode":this.combinedPremiumplusConditionArray[i].condCode,"coverCode": this.combinedPremiumplusConditionArray[i].coverCode,"helpText":this.combinedPremiumplusConditionArray[i].desc, "basicValue": this.combinedPremiumplusConditionArray[i].value,"condDesc":this.combinedPremiumplusConditionArray[i].condDesc, "premiumplus":"true"  });
  //
  //     }
  //   }
  //
  //
  //
  //
  // console.log("Combined conditional array--- nhjksdhkafukash-----------------------------------");
  // console.log(this.combinedConditionArray);
  //
  // }
  //method is used to get cover cinditions in case of benefits and limits
  getCoverConditions(postData) {
    console.log("Get cover condition");
    console.log(postData);
    this.insurancePlanService.getCoverConditions(JSON.stringify(postData)).subscribe((response: any) => {
      console.log(response);
      if (response.respCode == "2000") {
        //  this.limitBenefitPopup=true;

        console.log("Combined condition Array------------------");
        console.log(this.combinedBasicConditionArray);
        console.log(this.combinedPremiumConditionArray);
        console.log(this.combinedPremiumplusConditionArray);

        this.conditionsArray = response.conditionsArray;
        this.showBenefitLimitModal = true;
        setTimeout(() => this.visibleBenefitLimit = true, 100);

      }
    }, error => {

    });
  }

  openCoverInfoModal(type: any) {

    this.typeOfCoverModal = type;

  }

  afterChangeSlider(event: any) {
    console.log("after change slider", this.currentSlider);
    console.log(event.currentSlide);

    //alert(event.currentSlide)
    //this.setSchemeCoversHeight();
    this.currentSlider = event.currentSlide;
    console.log(this.currentSlider);

    if (this.schemesList.length < 2) {
      console.log("plan one")
    } else if (this.schemesList.length < 3) {
      console.log("plan two")
      switch (event.currentSlide) {
        case 0:
          this.checkIns = 1;
          break;
        case 1:
          this.checkIns = 0;
          break;
      }
    } else if (this.schemesList.length == 3) {
      console.log("plan three")
      switch (event.currentSlide) {
        case 0:
          this.checkIns = 0;
          break;
        case 1:
          this.checkIns = 2;
          break;
        case 2:
          this.checkIns = 1;
          break;
      }
    }
    if (this.comparisionView) {
      this.setTotalPremium();
    }
    this.getInstallmentsForMobile();
  }
  getInstallmentsForMobile() {
    this.installmentListMobi = [];
    if (this.detailView) {
      console.log('inside detail view');
      if (this.currentSlider == 0) {
        this.installmentListMobi = this.basicInstallmentList;
        // var height=$('.basic-header').innerHeight();
        // $('.mobile-cover-heading').css({'height': height,'position':'relative'});

      }
      else if (this.currentSlider == 1) {
        this.installmentListMobi = this.premiumInstallmentList;
        // var height=$('.premium-header').innerHeight();
        // $('.mobile-cover-heading').css({'height': height,'position':'relative'});

      }
      else if (this.currentSlider == 2) {
        this.installmentListMobi = this.premiumplusInstallmentList;
        // var height=$('.premiumplus-header').innerHeight();
        // $('.mobile-cover-heading').css({'height': height,'position':'relative'});

      }
    }

    if (this.comparisionView) {
      if (this.isBasicScheme) {
        this.installmentListMobi = this.basicInstallmentList;
      } else if (this.isPremiumScheme) {
        this.installmentListMobi = this.premiumInstallmentList;
      } else if (this.isPremiumPlusScheme) {
        this.installmentListMobi = this.premiumplusInstallmentList;
      }
    }
  }

  //added method to persist radio button newValue
  persistRadioVal(event: any, coversArr: any, val: any) {
    let tmpVal;
    if (event.target.checked) {
      tmpVal = 1;
    } else {
      tmpVal = 0;
    }
    for (let i = 0; i < this.schemes[val].coversArray.length; i++) {
      if (this.schemes[val].coversArray[i].coverCode == coversArr.coverCode) {
        this.schemes[val].coversArray[i].inclYN = tmpVal;
      }
    }
  }


}
