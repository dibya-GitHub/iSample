import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrieveCustInsurancePageComponent } from './retrieve-cust-insurance-page.component';

describe('RetrieveCustInsurancePageComponent', () => {
  let component: RetrieveCustInsurancePageComponent;
  let fixture: ComponentFixture<RetrieveCustInsurancePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetrieveCustInsurancePageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrieveCustInsurancePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
