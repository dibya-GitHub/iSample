import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { TooltiptList } from 'src/shared/tooltip-list';
import { ApiConstants } from '../../../shared/api-constants';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { RenewService } from '../services/renew.service';

@Component({
  selector: 'app-retrieve-cust-insurance-page',
  templateUrl: './retrieve-cust-insurance-page.component.html',
  styleUrls: ['./retrieve-cust-insurance-page.component.scss']
})
export class RetrieveCustInsurancePageComponent implements OnInit {
  checkDate: boolean = false;
  showMsg: boolean = false;
  date: Date = new Date();
  public startDateOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
    disableSince: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: (this.date.getDate() + 1) }
  };

  txnId: any;
  srNo: any;
  polNo: any;
  lobCode: any;
  insuredData: any;
  isEdit: boolean = false;
  startDate: Date;
  registrationNo: any;
  placeOfAccdnt: any;
  mobile: any;
  email: any;
  policeRefNo: any;
  towingYN: any = 0;
  policyVehInfoArr: any = [];
  policyInfo: any = [];
  regnLocationList: any = [];
  nationalityList: any = [];
  cylList: any = [];
  drivingExpList: any = [];
  pubIp: any;
  assName: any;
  isError: boolean = false;
  vehUsage: any;
  promoCode: any = '';
  insuredNationality: any = [];
  appUtilObj: AppUtil = new AppUtil();
  civilId: any;
  mobileNo: any;
  gender: any;
  gender_list: any = [];
  isCivilIdDisabled = true;
  isDobDisabled = true;
  isThirdParty = false;
  error: any = '';
  dob: any;
  quoteNo: string = '';
  routeData: any;
  import_country_list: Array<any>;
  tootipMessage: any = new TooltiptList();
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private renewService: RenewService,
    private loaderService: LoaderService,
    private insuranceService: InsuranceService
  ) {
    this.route.queryParams.subscribe(params => {
      this.routeData = params;
      this.txnId = params["transId"];
      this.srNo = params["tranSrNo"];
      this.polNo = params["policyNo"];
      this.assName = params["name"];
      this.lobCode = params["lobCode"];
      this.promoCode = params["promoCode"];
      let get_genderList = { "paraType": "GENDER" };
      this.insuranceService.getGenderList(get_genderList)
        .subscribe(result => {
          this.gender_list = result.appParamsArray;
          this.gender = "";
        }, error => {
          this.isError = true;
          this.error = this.appUtilObj.displayError(error["_body"], null);
          this.loaderService.display(false);
        });
      this.getQuotVehInfo();
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.loaderService.display(true);
    this.getDefaults();
    this.getVehicleCylinder();
    this.getDrivingExp();
    this.insuranceService.getIPAddress().subscribe(data => {
      this.pubIp = data.ip;
    });
    this.ImportCountryList();
  }

  ImportCountryList() {
    let get_nationaLitylist = { "type": "COUNTRY" };
    this.insuranceService.getImportCountryList(get_nationaLitylist)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.import_country_list = arr;
        console.log(this.import_country_list);
      }, error => {
        this.loaderService.display(false);
      });
  }
  getQuotVehInfo() {
    let postData = {
      transId: this.txnId,
      tranSrNo: this.srNo
    }
    this.insuranceService.getQuotInfo(postData).subscribe(data => {
      this.policyInfo = data;
      this.civilId = this.policyInfo.civilId;
      this.quoteNo = this.policyInfo.quoteNo;
      if (this.civilId == null) {
        this.isCivilIdDisabled = false;
      }
      this.mobileNo = this.policyInfo.mobileNo;
      if (this.policyInfo.gender != null) {
        this.gender = this.policyInfo.gender;
      }
    }, error => {
      this.isError = true;
      this.error = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    })
    this.loaderService.display(true);
    this.renewService.getQuotVehInfo(postData).subscribe((data: any) => {
      if (this.policyVehInfoArr.insName == undefined || this.policyVehInfoArr.insName == null || this.policyVehInfoArr.insName == '') {
        this.policyVehInfoArr.insName = this.policyInfo.insName;
      }
      this.insuredNationality = [{ id: data.nationality, text: data.nationalityDesc }]
      this.policyVehInfoArr = data;
      if (this.policyInfo.prodShortDesc == 'TP') {
        this.policyVehInfoArr.gccSpecYN = '0';
        this.isThirdParty = true;
      } else if (this.policyInfo.prodShortDesc == 'OD') {
        this.policyVehInfoArr.gccSpecYN = '1';
      } else {
        this.policyVehInfoArr.gccSpecYN = '';
      }
      this.policyVehInfoArr.userId = ApiConstants.USER_ID;
      if (data.driverDob == null) {
        this.isDobDisabled = false;
      } else {
        let dob = new Date(this.policyVehInfoArr.driverDob);
        this.dob = this.policyVehInfoArr.driverDob;
        this.policyVehInfoArr.driverDob = { date: { year: dob.getFullYear(), month: dob.getMonth() + 1, day: dob.getDate() } }
      }
      this.getRegnLocation();
      this.getNationality();
      this.loaderService.display(false);
    }, error => {
      this.isError = true;
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    })
  }
  getRegnLocation() {
    this.renewService.getApplicationCodes("REGN_LOC").subscribe(data => {
      var tmpArr = data.appCodesArray.reverse();
      this.regnLocationList = this.appUtilObj.sortedArray(tmpArr);
      if (this.policyVehInfoArr.regnLoc == null) {
        this.policyVehInfoArr.regnLoc = "";
      }
    }, error => {
      this.isError = true;
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    })
  }
  getNationality() {
    this.renewService.getApplicationCodes('NATIONALITY').subscribe(data => {
      ////console.log(data);
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      let sortedArr = this.sortNationality(arr);
      this.nationalityList = sortedArr;
    }, error => {
      this.isError = true;
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    })
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  getVehicleCylinder() {
    let postData = { "type": "MOT_VEH_NOC" }
    this.renewService.getVehicleCylinderList(postData).subscribe(data => {
      this.cylList = data.appCodesArray;
      console.log(JSON.stringify(this.cylList));
    }, error => {
      this.isError = true;
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    })
  }
  getDrivingExp() {
    for (let i = 0; i <= 10; i++) {
      if (i == 10) {
        this.drivingExpList.push('10+');
        break;
      }
      this.drivingExpList.push(i);
    }
  }

  getDefaults() {
    if (this.policyVehInfoArr.gccSpecYN == null) {
      this.policyVehInfoArr.gccSpecYN = "";
    }
    if (this.policyVehInfoArr.vehCylinders == null) {
      this.policyVehInfoArr.vehCylinders = "";
    }
    if (this.policyInfo.gender == null) {
      this.gender = '';
    }
  }
  updateVehInfo() {
    this.loaderService.display(true);
    this.policyVehInfoArr.mapId = "MOT_REN_RISK_SCR_1";
    this.policyVehInfoArr.nationality = this.insuredNationality[0].id;
    this.policyVehInfoArr.nationalityDesc = this.insuredNationality[0].text;
    if (this.policyVehInfoArr.driverDob != null) {
      let age;
      if (this.policyVehInfoArr.driverDob.formatted != undefined) {
        age = this.getAge(this.policyVehInfoArr.driverDob.formatted);
      } else {
        this.dob = this.policyVehInfoArr.driverDob;
        if (this.dob.date != undefined) {
          this.dob = this.dob.date.month + "/" + this.dob.date.day + "/" + this.dob.date.year;
        } else {
          let temp = this.dob.split("/");
          this.dob = temp[1] + "/" + temp[0] + "/" + temp[2];
        }
        age = this.getAge(new Date(this.dob).toLocaleDateString());
      }
      if (this.policyVehInfoArr.driverDob.epoc != undefined) {
        this.policyVehInfoArr.driverDob = this.policyVehInfoArr.driverDob.epoc * 1000;
      } else {
        if (this.dob.date != undefined) {
          this.dob = this.dob.date.month + "/" + this.dob.date.day + "/" + this.dob.date.year;
        }
        // let temp = this.dob.split("/"); 
        // let stringDate = temp[1]+"/"+temp[0]+"/"+temp[2];
        let timeStamp = new Date(this.dob).getTime();
        this.policyVehInfoArr.driverDob = timeStamp;
        //this.policyVehInfoArr.driverDob = this.dob / 1000;
      }
      this.policyVehInfoArr.driverAge = age + '';
    } else {
      this.policyVehInfoArr.driverDob = '';
    }
    this.policyVehInfoArr.gender = this.gender;
    this.policyVehInfoArr.mobileNo = this.mobileNo;
    this.policyVehInfoArr.civilId = this.civilId;
    console.log(JSON.stringify(this.policyVehInfoArr));
    this.renewService.updateVehicleInfo(this.policyVehInfoArr).subscribe((data: any) => {
      if (data.respCode == 2000) {
        let postData = {
          transId: this.txnId,
          tranSrNo: this.srNo,
          portal: ApiConstants.PORTAL,
          userId: ApiConstants.USER_ID,
          lobCode: this.lobCode
        }
        ////console.log("========updateVehicleInfo resp=======");
        ////console.log(JSON.stringify(this.policyVehInfoArr));
        this.insuranceService.calculatePricing(postData).subscribe((data: any) => {
          ////console.log(data);
          let obj = {
            transId: this.txnId,
            tranSrNo: this.srNo,
            lobCode: this.lobCode,
            policyNo: this.polNo,
            registrationYear: this.policyVehInfoArr.firstRegYear
          }
          if (data.respCode == 2000) {
            this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
          } else {
            alert('error');
            this.loaderService.display(false);
          }
        }, error => {
          this.isError = true;
          this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        })
      } else {
        alert('error');
        this.loaderService.display(false);
      }
    }, error => {
      this.isError = true;
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    })
  }
  updateInsInfo() {
    if (this.checkDate == true) {
      return false;
    }
    let postData = {
      transId: this.txnId,
      tranSrNo: this.srNo,
      mapId: "MOT_REN_POL_SCR_1",
      emailId: this.policyInfo.emailId,
      civilId: this.civilId,
      mobileNo: this.mobileNo,
      gender: this.gender,
      promoCode: this.promoCode
    }
    this.policyInfo.nationality = this.insuredNationality[0].id
    console.log(JSON.stringify(postData));
    this.renewService.updateInsInfo(postData).subscribe(data => {
      this.updateVehInfo();
    }, error => {
      this.isError = true;
      this.error = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    })
  }
  getAge(dateString) {
    let parts = dateString.split('/');
    let age: any;
    let today = new Date();
    console.log(today);
    let birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
    console.log(birthDate);

    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }
  goToPreviousPage() {
    let postData = {
      searchBy: this.routeData["searchBy"],
      value: this.routeData["value"],
      promoCode: this.routeData["promoCode"]
    }
    if (this.routeData["searchBy"] == 'TPI_CIVIL_ID') {
      this.router.navigate(['retrieve-cust-insurance-info'], { queryParams: this.routeData, skipLocationChange: true });
    } else {
      this.router.navigate(['renew-policy'], { queryParams: postData, skipLocationChange: true });
    }
  }

  onDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.policyVehInfoArr.driverDob = event.target.value;
        }
      }
    }
    console.log(this.policyVehInfoArr.driverDob);
  }
  onDateChanged(event) {

    if (this.policyVehInfoArr.driverDob != undefined || this.policyVehInfoArr.driverDob == null) {
      this.showMsg = false;
      //console.log(this.perslData.insDob)
    }
    console.log(this.policyVehInfoArr.driverDob)
  }
  getAgeValidate(dateString: any) {
    //console.log("dateString>>>>>>>>", dateString)
    if (dateString == '' || dateString == undefined || (/^\d+$/.test(dateString) == true) || (/^-\d+$/.test(dateString) == true)) {
      return false;
    } else {
      //console.log(dateString)
      //let dobOf:string = dateString.formatted;
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {
        if (dateString.date != undefined) {
          dateString = dateString.date.month + "/" + dateString.date.day + "/" + dateString.date.year;
          birthDate = new Date(dateString);
        } else {
          let parts = dateString.split('/');
          birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
        }
        // if(dateString.date!=undefined){
        //   dateString=dateString.date.month +"/"+ dateString.date.day+ "/" +  dateString.date.year;
        // }

        // let parts = dateString.split('/');
        // birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }

      //const date = this.appUtilObj.getUTCDate(timestamp);
      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age < 18) {
        this.checkDate = true;
        return true;
      } else if (age > 70) {
        this.checkDate = true;
        return true;
      }
      else {
        this.checkDate = false;
        return false;
      }

    }

  }
}
