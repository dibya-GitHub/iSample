import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
import { ApiConstants } from '../../../shared/api-constants';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { RenewService } from '../services/renew.service';
@Component({
  selector: 'app-renew-policy',
  templateUrl: './renew-policy.component.html',
  styleUrls: ['./renew-policy.component.scss']
})
export class RenewPolicyComponent implements OnInit {
  emiratedId: any;
  policyNo: any;
  mobileNo: any;
  searchBy: string;
  tmpData: any;
  activePolicyArray: any[];
  txnId: any;
  srNo: any;
  polNo: any;
  name: any;
  lobCode: any;
  pubIp: any;
  promoCode: any = "";
  error: any = '';
  appUtilObj: AppUtil = new AppUtil();
  discountJSONFileValue: any = {
    "car": 10,
    "home": 30,
    "pab": 10,
    "travel": 10
  };
  postData: any;
  showForm = false;
  constructor(
    private meta: Meta,
    private router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private renewService: RenewService,
    private loaderService: LoaderService,
    private insuranceService: InsuranceService,
  ) {
    this.titleService.setTitle('Renew Insurance Policy Online | i-Insured Insurance Dubai');
    this.meta.addTag({ name: 'description', content: 'Insurance renewal services at i-Insured now made easier than ever. Renew your insurance policies online with us in just few clicks!' });
    this.meta.addTag({ name: 'keywords', content: 'insurance brokers in dubai, dubai insurance company, health insurance companies, travel insurance companies, home Insurance companies, insurance in dubai' });

    this.route.queryParams.subscribe(params => {
      console.log(JSON.stringify(params));
      let data = params["searchBy"];
      let token = params["token"];
      if (data != undefined) {
        this.searchBy = data;
        this.promoCode = params["promoCode"];
        if (data == 'TPI_CIVIL_ID') {
          this.emiratedId = params["value"];
        } else if (data == 'TPI_MOBILE_NO') {
          this.mobileNo = params["value"];
        } else {
          this.policyNo = params["value"];
        }
        this.postData = {
          searchBy: this.searchBy,
          value: params["value"],
          promoCode: this.promoCode
        }
      }
      if (token) {
        let params = { payToken: token }
        this.loaderService.display(true);
        this.insuranceService.validateRenLink(params).subscribe(
          (res: any) => {
            let condition = +res.linkValidYn;
            if (condition) {
              this.txnId = res.transId;
              this.srNo = res.tranSrNo;
              this.lobCode = res.lobCode;
              this.renewPolicy();
            } else {
              this.error = "Link is expired or invalid";
              this.showForm = true;
              this.resetParallex();
              this.loaderService.display(false);
            }
          }, error => {
            try {
              let err = error.json();
              let obj = {
                errMsg: err.errMessage
              }
              this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
            } catch (err) {

            }
            this.loaderService.display(false);
          }
        )
      } else {
        this.showForm = true;
        this.resetParallex();
      }
    });
  }
  currentIndex: any = 1;

  ngOnInit() {
    window.scrollTo(0, 0);
    this.insuranceService.getIPAddress().subscribe(data => {
      this.pubIp = data.ip;
    });
  }


  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  afterChange(event) {
    this.currentIndex = $('.for-count.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  slideConfig = {
    "slidesToShow": 3,
    "dots": true,
    "infinite": true,
    "centerMode": true,
    "centerPadding": '0px',
    "variableWidth": true
  };
  toggle() {
    $("#promoCode").toggle(1000);
    $("#promo").toggle(1000);
  }
  getActivePolicyList() {
    this.loaderService.display(true);
    if ((this.emiratedId == undefined || this.emiratedId.trim() == '') && (this.policyNo == undefined || this.policyNo.trim() == '') && (this.mobileNo == undefined || this.mobileNo.trim() == '')) {
      this.error = 'Please enter policy no. or emirates id or mobile no.';
      this.loaderService.display(false);
    } else {
      this.postData.value = this.postData.value.trim();
      if (this.policyNo != '' && this.policyNo != undefined) {
        this.renewService.getActivePolList(this.postData).subscribe((data: any) => {
          this.txnId = data.activePolicyArray[0].transId;
          this.srNo = data.activePolicyArray[0].tranSrNo;
          this.polNo = data.activePolicyArray[0].policyNo;
          this.name = data.activePolicyArray[0].insName;
          this.lobCode = data.activePolicyArray[0].lobCode;
          if (data.activePolicyArray[0].renwAllowYN > 0) {
            this.renewPolicy();
          } else {
            this.error = 'Renewal not allowed. Please try with some other policy.';
            this.loaderService.display(false);
          }
        }, error => {
          try {
            this.loaderService.display(false);
            if (JSON.parse(error["_body"]).respCode == "1002") {
              console.log('no records found');
              this.error = JSON.parse(error["_body"]).errMessage;
            } else {
              this.error = this.appUtilObj.displayError(error["_body"], this.policyNo);
            }
          } catch (err) {
            this.error = 'Sorry, something went wrong.';
          }
        })
      } else {
        this.renewService.getActivePolList(this.postData).subscribe((data: any) => {
          console.log(JSON.stringify(data));
          if (data.respCode == "2000") {
            this.router.navigate(['retrieve-cust-insurance-info'], { queryParams: this.postData, skipLocationChange: true });
          }
        }, error => {
          try {
            this.loaderService.display(false);
            if (JSON.parse(error["_body"]).respCode == "1002") {
              console.log('no records found');
              this.error = JSON.parse(error["_body"]).errMessage;
            } else {
              //this.error = this.appUtilObj.displayError(error["_body"], this.policyNo);
            }
          } catch (err) {
            this.error = 'Sorry, something went wrong.';
          }
        });
      }
    }
  }
  renewPolicy() {
    let postData = {
      transId: this.txnId,
      tranSrNo: this.srNo,
      portal: ApiConstants.PORTAL,
      ipAddress: this.pubIp,
      userId: ApiConstants.USER_ID,
      lobCode: this.lobCode,
      promoCode: this.promoCode
    }
    console.log(JSON.stringify(postData));
    this.loaderService.display(true);
    this.renewService.renewPolicy(postData).subscribe((data: any) => {
      //console.log(JSON.stringify(data));
      let obj = {
        transId: this.txnId,
        tranSrNo: parseInt(this.srNo) + 1,
        policyNo: this.polNo,
        name: this.name,
        lobCode: this.lobCode
      }
      if (data.respCode == 2000) {
        let SrNo = parseInt(this.srNo) + 1;
        let postData = {
          transId: this.txnId,
          tranSrNo: SrNo,
          portal: ApiConstants.PORTAL,
          userId: ApiConstants.USER_ID,
          lobCode: this.lobCode
        }
        let val = this.policyNo;
        if (this.searchBy == 'TPI_CIVIL_ID') {
          val = this.emiratedId;
        } else if (this.searchBy == 'TPI_MOBILE_NO') {
          val = this.mobileNo;
        }
        let obj = {
          transId: this.txnId,
          tranSrNo: SrNo,
          lobCode: this.lobCode,
          policyNo: this.polNo,
          searchBy: this.searchBy,
          value: val,
          promoCode: this.promoCode
        }
        if (data.respCode == 2000) {
          if (this.lobCode == ApiConstants.CAR_INSURANCE_LOBCODE) {
            this.router.navigate(['retrieve-cust-insurance-page'], { queryParams: obj, skipLocationChange: true });
          } else {
            this.insuranceService.calculatePricing(postData).subscribe((data: any) => {
              if (data.respCode == 2000) {
                this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
              } else {
                alert('error');
                this.loaderService.display(false);
              }
            }, error => {
              this.error = this.appUtilObj.displayError(error["_body"], null);
              this.loaderService.display(false);
            })
          }
        } else {
          alert('error');
          this.loaderService.display(false);
        }
      } else {
        alert('error');
      }
      this.loaderService.display(false);
    }, error => {
      let err = error.json();
      this.error = err.errMessage;
      this.loaderService.display(false);
    })
  }
  emirated() {
    this.policyNo = '';
    this.mobileNo = '';
    this.error = '';
    if (this.emiratedId.length >= 1) {
      this.searchBy = 'TPI_CIVIL_ID';
      this.postData = {
        searchBy: this.searchBy,
        value: this.emiratedId,
        promoCode: this.promoCode
      }
    }
  }
  policy() {
    this.emiratedId = '';
    this.mobileNo = '';
    this.error = '';
    if (this.policyNo.length >= 1) {
      this.searchBy = 'TPI_POLICY_NO';
      this.postData = {
        searchBy: this.searchBy,
        value: this.policyNo,
        promoCode: this.promoCode
      }
    }
  }
  mobile() {
    this.emiratedId = '';
    this.policyNo = '';
    this.error = '';
    if (this.mobileNo.length >= 1) {
      this.searchBy = 'TPI_MOBILE_NO';
      this.postData = {
        searchBy: this.searchBy,
        value: this.mobileNo,
        promoCode: this.promoCode
      }
    }
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({ left: 0, top: 600, behavior: 'smooth' });
  }
  setLocalVal(val: any) {
    window.localStorage.setItem('type', val);
    if (val == 'TP') {
      this.router.navigate(['car-insurance-without-chassi']);
    } else {
      this.router.navigate(['car-insurance']);
    }
  }
  resetParallex() {
    setTimeout(() => {
      $(window).resize(function () {
        // $('[data-parallax="scroll"]').parallax();
      }).resize();
    }, 10);
  }
}
