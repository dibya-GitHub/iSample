import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';

@Injectable({
  providedIn: 'root'
})
export class RenewService {

  requestOption:any;
  baseUrl:any = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  getActivePolList(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_ACTIVE_POL_LIST, body, this.requestOption);
  }
  getLocation(type: any) {
    let postData = {
      type: type
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_CODES, postData, this.requestOption);
  }
  getPolicyVehicleInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_VEHICLE_INFO, body, this.requestOption);
  }
  getApplicationCodes(refType: any): Observable<any> {
    let postData = {
      type: refType
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_CODES, postData, this.requestOption);
  }
  getApplicationRefCodes(refType: any, referenceCode: any): Observable<any> {
    let postData = {
      type: refType,
      refCode: referenceCode
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_REF_CODES, postData, this.requestOption);
  }
  updateVehicleInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_VEH_INFO, body, this.requestOption);
  }
  updateInsInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INS_INFO, body, this.requestOption);
  }
  getQuotVehInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_VEHICLE_INFO, body, this.requestOption);
  }
  renewPolicy(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.RENEW_POLICY, body, this.requestOption);
  }
  getVehicleType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_TYPE_URL, body, this.requestOption);
  }

  getVehicleMake(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_MAKE_URL, body, this.requestOption);
  }

  getVehicleUsageList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEH_USAGE, body, this.requestOption);
  }

  getVehicleCylinderList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_CYLINDER_LIST_URL, body, this.requestOption);
  }
}
