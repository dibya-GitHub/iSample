import { TestBed, inject } from '@angular/core/testing';

import { RenewService } from './renew.service';

describe('RenewService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RenewService]
    });
  });

  it('should be created', inject([RenewService], (service: RenewService) => {
    expect(service).toBeTruthy();
  }));
});
