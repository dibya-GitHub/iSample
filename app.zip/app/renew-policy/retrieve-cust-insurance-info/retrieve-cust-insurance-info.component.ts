import { Component, OnInit, AfterViewInit, ViewChildren } from '@angular/core';
import { RenewService } from '../services/renew.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { ApiConstants } from '../../../shared/api-constants';
import { InsuranceService } from '../../../shared/services/insurance.service'
import { DatePipe } from "@angular/common";
import { AppUtil } from "src/shared/app-util";

@Component({
  selector: 'app-retrieve-cust-insurance-info',
  templateUrl: './retrieve-cust-insurance-info.component.html',
  styleUrls: ['./retrieve-cust-insurance-info.component.scss']
})
export class RetrieveCustInsuranceInfoComponent implements OnInit {
  @ViewChildren('input') vc;
  activePolicyArray: any[];
  txnNo: any;
  srNo: any;
  polNo: any;
  assName: any;
  lobCode: any;
  selectOrConfirm: string;
  errorMessage: string = '';
  showDiv: boolean = false;
  pubIp: any;
  promoCode: any = "";
  routeData: any;
  datePipe:DatePipe = new DatePipe('en-US');
  error: any = '';
  p: any;
  appUtilObj: AppUtil = new AppUtil();

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private renewService: RenewService,
    private loaderService: LoaderService,
    private insuranceService: InsuranceService
  ) {
    this.loaderService.display(true);
    this.route.queryParams.subscribe(params => {
      this.routeData = params;
      this.promoCode = params["promoCode"];
      if (params['searchBy'] == 'TPI_CIVIL_ID') {
        this.selectOrConfirm = 'Select your policy';
      }
      else {
        this.selectOrConfirm = 'Confirm your policy';
      }
      this.renewService.getActivePolList(params).subscribe((data:any) => {
        console.log(JSON.stringify(data));
        if (data.errMessage == "No Records Found") {
          this.errorMessage = "No Records Found";
        } else {
          this.activePolicyArray =this.appUtilObj.sortArrayByPolicyStartDateDesc(data.activePolicyArray.filter(policy => policy.renwAllowYN == 1));            
          this.errorMessage = '';
          if (this.activePolicyArray.length == 0) {
            this.errorMessage = "No Records Found";
          }
        }
        this.showDiv = true;
        this.loaderService.display(false);
      }, error => {
        this.errorMessage = "No Records Found";
        this.showDiv = true;
        this.loaderService.display(false);
      })
    });
  }
  ngOnInit() {
    window.scrollTo(0, 0);
    this.insuranceService.getIPAddress().subscribe(data => {
      this.pubIp = data.ip;
    });
  }

  ngAfterViewInit() {
    this.vc.first.nativeElement.focus();
  }

  setSrAndTxn(txn_id: any, sr_no: any, polNo: any, name: any, lobCode: any) {
    this.txnNo = txn_id;
    this.srNo = sr_no;
    this.polNo = polNo;
    this.assName = name;
    this.lobCode = lobCode;
  }
  getQuote(txn_id: any, sr_no: any, polNo: any, name: any, lobCode: any) {
    this.txnNo = txn_id;
    this.srNo = sr_no;
    this.polNo = polNo;
    this.assName = name;
    this.lobCode = lobCode;
    this.submitRenew();
  }
  submitRenew() {
    let postData = {
      transId: this.txnNo,
      tranSrNo: this.srNo,
      portal: ApiConstants.PORTAL,
      ipAddress: this.pubIp,
      userId: ApiConstants.USER_ID,
      promoCode: this.promoCode
    }
    console.log(JSON.stringify(postData));
    this.loaderService.display(true);
    this.renewService.renewPolicy(postData).subscribe((data:any) => {
      this.loaderService.display(false)
      if (data.respCode == 2000) {
        let SrNo = parseInt(this.srNo) + 1;
        let postData = {
          transId: this.txnNo,
          tranSrNo: SrNo,
          portal: ApiConstants.PORTAL,
          userId: ApiConstants.USER_ID,
          lobCode: this.lobCode
        }
        let obj = {
          transId: this.txnNo,
          tranSrNo: parseInt(this.srNo) + 1,
          policyNo: this.polNo,
          name: this.assName,
          lobCode: this.lobCode,
          searchBy: this.routeData['searchBy'],
          value: this.routeData['value'],
          promoCode: this.promoCode
        }
        if (this.lobCode == ApiConstants.CAR_INSURANCE_LOBCODE) {
          this.router.navigate(['retrieve-cust-insurance-page'], { queryParams: obj, skipLocationChange: true });
        } else {
          this.insuranceService.calculatePricing(postData).subscribe((data:any) => {
            if (data.respCode == 2000) {
              this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
            } else {
              alert('error');
              this.loaderService.display(false);
            }
          }, error => {
            this.loaderService.display(false);
          })
        }
      } else {
        alert('error');
      }
      this.loaderService.display(false);
    }, error => {
      let err = error.json();
      this.errorMessage = err.errMessage;
      this.loaderService.display(false);
    })
  }
  goToPreviousPage() {
    this.router.navigate(['renew-policy'], { queryParams: this.routeData, skipLocationChange: true });
  }

}
