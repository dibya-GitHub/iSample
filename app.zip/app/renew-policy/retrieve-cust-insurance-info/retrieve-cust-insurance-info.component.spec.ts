import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrieveCustInsuranceInfoComponent } from './retrieve-cust-insurance-info.component';

describe('RetrieveCustInsuranceInfoComponent', () => {
  let component: RetrieveCustInsuranceInfoComponent;
  let fixture: ComponentFixture<RetrieveCustInsuranceInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetrieveCustInsuranceInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrieveCustInsuranceInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
