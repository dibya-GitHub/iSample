import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from './../shared.module';
import { RenewPolicyRoutingModule } from './renew-policy-routing.module';
import { RenewPolicyComponent } from './renew-policy/renew-policy.component';

@NgModule({
    declarations: [
        RenewPolicyComponent,
    ],
    imports: [
        RenewPolicyRoutingModule,
        CommonModule,
        SharedModule,
        TooltipModule,
        SlickCarouselModule
        // NgxPaginationModule
    ],
})

export class RenewPolicyModule { }