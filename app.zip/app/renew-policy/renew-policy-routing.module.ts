import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { RenewPolicyComponent } from './renew-policy/renew-policy.component';

const renewPolicyRoutes: Routes = [
    { path: '', component: RenewPolicyComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(renewPolicyRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class RenewPolicyRoutingModule { }
