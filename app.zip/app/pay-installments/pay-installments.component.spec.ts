import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayInstallmentsComponent } from './pay-installments.component';

describe('PayInstallmentsComponent', () => {
  let component: PayInstallmentsComponent;
  let fixture: ComponentFixture<PayInstallmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayInstallmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayInstallmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
