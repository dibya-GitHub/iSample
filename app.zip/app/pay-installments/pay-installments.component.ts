import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ApiHeadersService } from 'src/shared/api-headers.service';
import { PaymentService } from 'src/shared/services/payment.service';
import { AppUtil } from '../../shared/app-util';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { InsuranceService } from "../../shared/services/insurance.service";
import { NewPayment } from './../../shared/interfaces/new-payment';

@Component({
  selector: 'app-pay-installments',
  templateUrl: './pay-installments.component.html',
  styleUrls: ['./pay-installments.component.scss']
})
export class PayInstallmentsComponent implements OnInit {
  regPaymentInfo: any;
  showModal: boolean = false;
  termsAndConditionText: any;
  accept: boolean = false;
  transId: string = "";
  tranSrNo: string = "";
  installmentsArray: any = [];
  paymentOptionsArr: any = [];
  premiumPaid: number = 0;
  totalPremium: number = 0;
  currentInstPremium: number = 0;
  currentInstValue: string = "";
  policyNo: string = "";
  totalPendingPremium: number = 0;
  payInInstallment: boolean = true;
  payFull: string = "0";
  installmentNo: number;
  payNowInfo: any;
  pgReqUrl: any;
  showDiv = false;
  quoteInfoData: any;
  //public data: Payment;
  data: NewPayment;
  controls;
  premiumToSend: any;
  selectedPaymentType: any;
  currentInstDiv: string = "p-installment-box active";
  totalPremiumDiv: string = "p-installment-box";
  errorMsg: string = '';
  appUtilObj: AppUtil = new AppUtil();
  checkboxVal: boolean;
  baseUrl = environment.baseUrl;
  token: string;
  userId: string;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private insurancePlanService: InsuranceService,
    private paymentService: PaymentService,
    private apiHeadersService: ApiHeadersService
  ) {
    this.loaderService.display(true);
    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      this.policyNo = params["policyNo"];
      this.token = params["token"];
      this.userId = params["userId"];
      if (this.token && this.userId) {
        let params = { payToken: this.token, userId: this.userId }
        this.insurancePlanService.validateInstLink(params).subscribe(
          (res: any) => {
            if (res.linkValidYn) {
              this.transId = res.transId;
              this.tranSrNo = res.tranSrNo;
              this.customCall();
            }
          }, error => {
            try {
              let err = error.json();
              let obj = {
                errMsg: err.errMessage
              }
              this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
            } catch (err) {
            }
            this.loaderService.display(false);
          }
        )
      } else {
        this.customCall();
      }
    });
  }
  ngOnInit() {

  }
  customCall() {
    this.loaderService.display(true);
    //service call to get the installment details
    var installmentData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "userId": "online" };
    console.log(installmentData);
    this.insurancePlanService.getInstallmentDetails(JSON.stringify(installmentData)).subscribe((response: any) => {
      console.log(response);
      this.installmentsArray = response.instArray;
      this.showDiv = true;
      this.populateInstallmentDetails();
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });

    //service call to get the payment options
    var getPaymentOptData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.insurancePlanService.getPaymentOptions(JSON.stringify(getPaymentOptData)).subscribe((response: any) => {
      console.log(response);
      this.paymentOptionsArr = response.payOptsArray;
      this.selectedPaymentType = this.paymentOptionsArr[0].paymtType;
      this.getQuoteInfo();
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });

  }

  //method to populate the details of installment
  populateInstallmentDetails() {
    for (var i = 0; i < this.installmentsArray.length; i++) {
      if (this.installmentsArray[i].paidDate != null) {
        this.premiumPaid = this.premiumPaid + parseFloat(this.installmentsArray[i].premium);
      }
      this.totalPremium = this.totalPremium + parseFloat(this.installmentsArray[i].premium);
    }

    //filter the first unpaid installment
    for (var i = 0; i < this.installmentsArray.length; i++) {
      if (this.installmentsArray[i].paidDate == null) {
        if (this.installmentsArray[i].instNo == 1) {
          this.currentInstValue = "1st";
        } else if (this.installmentsArray[i].instNo == 2) {
          this.currentInstValue = "2nd";
        } else if (this.installmentsArray[i].instNo == 3) {
          this.currentInstValue = "3rd";
        } else if (this.installmentsArray[i].instNo == 4) {
          this.currentInstValue = "4th";
        }
        this.currentInstPremium = this.installmentsArray[i].premium;
        break;
      }
    }

    //calculate the pending premium
    this.totalPendingPremium = this.totalPremium - this.premiumPaid;
    this.installmentNo = +this.currentInstValue.substring(0, 1);
    this.loaderService.display(false);
  }

  selectInstallmentOpt(event) {
    //console.log(event);
    if (event.target.id == "instOption") {
      this.payFull = "0";
      this.installmentNo = +this.currentInstValue.substring(0, 1);
      this.currentInstDiv = "p-installment-box active";
      this.totalPremiumDiv = "p-installment-box";
    } else if (event.target.id == "fullPremium") {
      this.payFull = "1";
      this.installmentNo = 0;
      this.totalPremiumDiv = "p-installment-box active";
      this.currentInstDiv = "p-installment-box";
    }
  }

  changePaymentType(event) {
    console.log(event);
    this.selectedPaymentType = event.target.value;
  }

  getQuoteInfo() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    };
    this.insurancePlanService.getPolInfo(postData).subscribe(data => {

      this.quoteInfoData = data;
      console.log('quote info data --');
      console.log(this.quoteInfoData);
      this.setTermsAndConditionText();
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }

  // initPayment() {
  //   if(this.payFull == "0") {
  //     this.premiumToSend = this.currentInstPremium;
  //   } else if(this.payFull == "1") {
  //     this.premiumToSend = this.totalPendingPremium;
  //   }
  //   this.data = this.paymentService.initPayment(this.quoteInfoData, this.payNowInfo, this.premiumToSend);
  //   //console.log(JSON.stringify(this.data));
  //   let signedFields = this.data.signed_field_names.split(",");
  //   var fieldValues = [];
  //   signedFields.forEach(item => {
  //     var tmp = item + "=" + (this.data[item]);
  //     fieldValues.push(tmp);
  //   });
  //   let key = this.payNowInfo.secret_key;
  //   //alert(key);
  //   var hash = CryptoJS.HmacSHA256(fieldValues.join(","), key);
  //   var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
  //   this.data.signature = hashInBase64;
  //   if (this.quoteInfoData.emailId == null) this.quoteInfoData.emailId = "qicdubai@qici.com.qa";
  //   if (this.quoteInfoData.address == null) this.quoteInfoData.address = "Al Dana Centre Building";
  //   if (this.quoteInfoData.mobileNo == null) this.quoteInfoData.mobileNo = "42224045";
  //   if (this.quoteInfoData.cityDesc == null) this.quoteInfoData.cityDesc = "Dubai";
  //   if (this.quoteInfoData.poBox == null) this.quoteInfoData.poBox = "4066";
  //   this.data.bill_to_address_line1 = this.quoteInfoData.address;
  //   this.data.bill_to_phone = this.quoteInfoData.mobileNo;
  //   this.data.bill_to_address_city = this.quoteInfoData.cityDesc;
  //   this.data.bill_to_address_state = "DU";
  //   this.data.bill_to_surname = "QIC";
  //   this.data.bill_to_address_country = "AE";
  //   this.data.bill_to_address_postal_code = this.quoteInfoData.poBox;
  //   this.data.org_id = this.payNowInfo.org_id;
  //   this.data.bill_to_forename = this.quoteInfoData.insName;
  //   this.data.bill_to_email = this.quoteInfoData.emailId;

  //   this.controls = Object.keys(this.data).map((k) => {
  //     return { key: k, value: this.data[k] };
  //   });
  // }
  initPayment() {
    if (this.payFull == "0") {
      this.premiumToSend = this.currentInstPremium;
    } else if (this.payFull == "1") {
      this.premiumToSend = this.totalPendingPremium;
    }
    this.data = this.paymentService.newInitPayment(this.quoteInfoData, this.regPaymentInfo, this.premiumToSend);
    //console.log(JSON.stringify(this.data));
    //alert(key);
    this.data.billing_address = this.quoteInfoData.address;
    this.data.billing_tel = this.quoteInfoData.mobileNo;
    this.data.billing_city = this.quoteInfoData.cityDesc;
    this.data.billing_state = "DU";
    this.data.billing_name = this.quoteInfoData.insName;
    this.data.billing_country = "AE";
    this.data.billing_zip = this.quoteInfoData.poBox;
    this.data.billing_email = this.quoteInfoData.emailId;

    //this.paymentService.setPaymentInformation = this.data
    // service call to get the payment information
    //this.data = this.paymentService.getPaymentInformation;



    console.log(JSON.stringify(this.data));
    this.controls = Object.keys(this.data).map((k) => {
      return { key: k, value: this.data[k] };
    });
  }
  checkTermsCheckbox(event) {
    if (event) {
      this.checkboxVal = false;
    } else {
      this.checkboxVal = true;
    }
  }

  validateCheckbox() {

    if (this.accept == true) {
      this.payNow();
      setTimeout(function () {
        window.localStorage.clear();
        document.getElementById('payment_confirmation')[0].onsubmit();
        // $("#payment_confirmation")[0].submit();
        this.loaderService.display(false)
      }, 5000)
    } else {
      this.checkAcceptTermsCondition();
    }//

  }

  payNow() {
    //service call to get the payment options
    this.loaderService.display(true);
    var registerPaymentData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "installmentNo": this.installmentNo, "fullPymtYN": this.payFull, "userId": "online", "paymtType": this.selectedPaymentType };
    console.log('registerPaymentData ---');
    console.log(registerPaymentData);
    this.insurancePlanService.registerPayment(JSON.stringify(registerPaymentData)).subscribe(response => {
      console.log(response);
      this.regPaymentInfo = response;
      this.pgReqUrl = "./ccavRequestHandler.jsp"
      this.initPayment();
    }, error => {
      try {
        let err = error.json();
        let obj = {
          errMsg: err.errMessage
        }
        this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
      } catch (err) {
      }
      this.loaderService.display(false);
    });
  }

  hideModal() {
    this.accept = false;
    setTimeout(() => this.showModal = false, 300);
  }
  acceptedTermCondition() {
    this.accept = true;
    this.validateCheckbox();
    this.loaderService.display(true);
  }
  checkAcceptTermsCondition() {

    let terms = document.getElementById('termsCheckbox')[0].checked; //$("#termsCheckbox")[0].checked;
    if (!terms) {
      return this.checkboxVal = true;
    }
    this.loaderService.display(false);
    if (this.accept == true) {
      this.showModal = false;
      this.validateCheckbox();
    } else {
      this.showModal = true;
    }

  }
  setTermsAndConditionText() {

    let dataToSend = { "transId": this.quoteInfoData.transId, "tranSrNo": this.quoteInfoData.tranSrNo, "prodCode": this.quoteInfoData.prodCode, "schCode": this.quoteInfoData.schCode };
    this.insurancePlanService.getPaymentOptions(dataToSend).subscribe((result: any) => {
      this.termsAndConditionText = result.payOptsArray[0].paymCond;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    })
    //this.termsAndConditionTex = this.quoteInfoData.
  }
}
