import { FaqComponent } from './faq.component';
import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

const FaqRoutes: Routes = [
    { path: '', component: FaqComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(FaqRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class FaqRoutingModule { }
