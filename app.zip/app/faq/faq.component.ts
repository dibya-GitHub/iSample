import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import * as $ from 'jquery';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {
  productType: string = "";
  constructor(
    private router: Router,
    private meta: Meta,
    private titleService: Title,
    private route: ActivatedRoute
  ) {
    this.titleService.setTitle('Insurance FAQs | Get Answer of All Questions | i-Insured');
    this.meta.addTag({ name: 'description', content: 'Got a question about insurance? Find answers in our Frequently Asked Questions (FAQ) section on Car, Home, Travel and PAB Insurance in Dubai.' });
    this.meta.addTag({ name: 'keywords', content: 'car insurance renewal quotes, which car insurance is best, rental property insurance, compare travel insurance,car insurance faq, home contents insurance faq, travel insurance faq, pab insurance faq' });
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
    this.route.queryParams.subscribe(params => {
      //console.log(this.productType)
      this.productType = params["productType"];
      //console.log(this.productType)
      if (this.productType == undefined) {
        this.productType = "Car";
      }
    });
  }

  ngOnInit() {
    //responsive tab
    // tabbed content
    // http://www.entheosweb.com/tutorials/css/tabs.asp
    $(".tab_content").hide();
    $(".tab_content:first").show();

    /* if in tab mode */
    $("ul.tabs li").click(function () {

      $(".tab_content").hide();
      var activeTab = $(this).attr("rel");
      $("#" + activeTab).fadeIn();
      $("ul.tabs li").removeClass("active");
      $(this).addClass("active");
      $(".tab_drawer_heading").removeClass("d_active");
      $(".tab_drawer_heading[rel^='" + activeTab + "']").addClass("d_active");
    });
    /* if in drawer mode */
    $(".tab_drawer_heading").click(function () {
      $(".tab_content").hide();
      var d_activeTab = $(this).attr("rel");
      $("#" + d_activeTab).fadeIn();
      $(".tab_drawer_heading").removeClass("d_active");
      $(this).addClass("d_active");
      $("ul.tabs li").removeClass("active");
      $("ul.tabs li[rel^='" + d_activeTab + "']").addClass("active");
    });
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }
}
