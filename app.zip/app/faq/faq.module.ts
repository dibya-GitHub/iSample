import { FaqComponent } from './faq.component';
import { SharedModule } from './../shared.module';
import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { FaqRoutingModule } from './faq-routing.module';


@NgModule({
    declarations: [
        FaqComponent,
    ],
    imports: [
        FaqRoutingModule,
        CommonModule,
        SharedModule,
    ],
})

export class FaqModule { }