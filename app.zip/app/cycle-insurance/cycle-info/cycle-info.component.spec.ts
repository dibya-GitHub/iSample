import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CycleInfoComponent } from './cycle-info.component';

describe('CycleInfoComponent', () => {
  let component: CycleInfoComponent;
  let fixture: ComponentFixture<CycleInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CycleInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CycleInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
