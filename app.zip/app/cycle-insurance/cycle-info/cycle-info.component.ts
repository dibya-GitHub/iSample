import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Router } from "@angular/router";
import { IAngularMyDpOptions } from "angular-mydatepicker";
import { RecaptchaComponent } from 'ng-recaptcha';
import { CycleInfo } from "src/app/cycle-insurance/classes/cycle-info";
import { InsuredInfo } from "src/app/cycle-insurance/classes/insured-info";
import { CycleInsuranceService } from "src/app/cycle-insurance/services/cycle-insurance.service";
import { environment } from '../../../environments/environment';
import { ApiConstants } from '../../../shared/api-constants';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService as CommonService } from '../../../shared/services/insurance.service';

@Component({
  selector: 'app-cycle-info',
  templateUrl: './cycle-info.component.html',
  styleUrls: ['./cycle-info.component.scss'],
})
export class CycleInfoComponent implements OnInit {
  checkDate: boolean = false;
  showMsg: boolean = false;
  quoteNo: string;
  @ViewChild('captcha') captcha: RecaptchaComponent;
  @ViewChildren('input') vc;
  captchaErr: any;
  errorMsg: string = '';
  ip: any;
  manYear: number[];
  coverageArray: any;
  public date = new Date();
  public cycleInfo = new CycleInfo();
  public insuredInfo = new InsuredInfo();
  appUtilObj: AppUtil = new AppUtil();
  promoCodeError: any;
  siteKey: any = environment.siteKey;
  public startDateOptions: IAngularMyDpOptions = {
    // other options..
    // inline:false,
    // editableDateField:true,
    // indicateInvalidDate:true,
    // openSelectorOnInputClick: true,
    // showInputField:true,
    dateFormat: 'dd/mm/yyyy',
    disableSince: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() + 1 }
  };

  constructor(
    private meta: Meta,
    private router: Router,
    private cycleInsurance: CycleInsuranceService,
    private loaderService: LoaderService,
    private commonService: CommonService,
    private titleService: Title
  ) {
    this.titleService.setTitle('Cycle Insurance Dubai | Get Bicycle Insurance Quotes');
    this.meta.addTag({ name: 'description', content: "i-Insured offer comprehensive and reliable bicycle Insurance tailored to your needs, whether you're casual cyclist or professional athlete." });
    this.meta.addTag({ name: 'keywords', content: 'cycle insurance Dubai, cycle insurance online, private cycle insurance Dubai, cycle insurance, buy cycle insurance online Dubai, compare cycle insurance quotes, buy cycle insurance online' });
  }
  ngOnInit() {
    this.scrollTop();
    this.setCoverageDropDown();
    this.setManufactureYear();
    this.setDefault();
    this.setContentsVal();
    this.commonService.getIPAddress().subscribe(data => {
      this.ip = data.ip;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  ngAfterViewInit() {
    this.vc.first.nativeElement.focus();
  }



  scrollTop() {
    window.scrollTo(0, 0);
  }
  setContentsVal() {
    let data = { "paraType": "HOME_CYL_CON" };
    this.cycleInsurance.getContentsVal(data).subscribe(result => {
      console.log(result)
      this.cycleInfo.contentsVal = result.value;

    })

  }
  setDefault() {
    this.cycleInfo.bldngType = "";
    this.cycleInfo.manfYear = "";
  }
  setManufactureYear() {
    let year: number = (new Date()).getFullYear();
    year = year - 20;
    this.manYear = Array(21).fill(0).map((x, i) => i + year + 1).reverse();
    console.log(this.manYear)
  }
  setCoverageDropDown() {
    const coverage_param = { 'type': 'CYCLECOVERAG' };
    this.cycleInsurance.getCoverage(coverage_param).subscribe(result => {
      console.log('getCoverage >>', JSON.stringify(result));
      this.coverageArray = result;
    })
  }
  getAge(dateString) {

    let parts = dateString.split('/');
    let age: any;
    let today = new Date();
    console.log(today);
    let birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
    console.log(birthDate);

    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }

  getQuote() {

    // if (this.captcha.execute) {
    //   this.captchaErr = 'Please Validate Captcha';
    //   return false;
    // }
    // if (this.checkDate == true) {
    //   return false;
    // }
    this.loaderService.display(true);
    const postData = {
      lobCode: ApiConstants.CYCLE_INSURANCE_LOBCODE,
      portal: ApiConstants.PORTAL,
      location: ApiConstants.LOCATION,
      userId: ApiConstants.USER_ID,
      ipAddress: this.ip,
      bundleYN: '0',
      sourceMkting: '',
      campaignMkting: '',
      promoCode: this.insuredInfo.promoCode,
      polStartDate: new Date().getTime(),
      prodShortDesc: 'HOME_CYL'
    }
    console.log(postData);
    this.commonService.createQuote(postData).subscribe(createQuoteResponse => {
      console.log('Create Quote');
      console.log(JSON.stringify(createQuoteResponse));
      this.insuredInfo.transId = createQuoteResponse.transId;
      this.insuredInfo.tranSrNo = createQuoteResponse.tranSrNo;
      this.cycleInfo.transId = createQuoteResponse.transId;
      this.cycleInfo.tranSrNo = createQuoteResponse.tranSrNo;
      this.quoteNo = createQuoteResponse.quoteNo;
      this.insuredInfo.userId = ApiConstants.USER_ID;
      console.log("this.insuredInfo.insAge", this.insuredInfo);

      if (this.insuredInfo.insDob.formatted == undefined) {
        this.insuredInfo.insAge = '' + this.getAge(this.insuredInfo.insDob);
        this.insuredInfo.insDob = this.insuredInfo.insDob;
      } else {
        this.insuredInfo.insAge = '' + this.getAge(this.insuredInfo.insDob.formatted);
        this.insuredInfo.insDob = this.insuredInfo.insDob.formatted;

      }


      //let dateString = this.insuredInfo.insDob.formatted;

      console.log(this.insuredInfo);
      let sendData = JSON.stringify(this.insuredInfo);
      console.log(sendData);
      this.commonService.updateInsuredInfo(JSON.stringify(this.insuredInfo)).subscribe(data => {
        console.log(JSON.stringify(data));
        this.cycleInfo.tplLimit = ((this.cycleInfo.buildingVal * 10) / 100).toFixed(2);
        console.log(JSON.stringify(this.cycleInfo));
        this.cycleInsurance.updateHomeInfo(JSON.stringify(this.cycleInfo)).subscribe(data => {
          console.log(JSON.stringify(data));
          const postData = {
            transId: this.cycleInfo.transId,
            tranSrNo: this.cycleInfo.tranSrNo,
            userId: ApiConstants.USER_ID,
            portal: ApiConstants.PORTAL,
            lobCode: ApiConstants.CYCLE_INSURANCE_LOBCODE
          }
          this.commonService.calculatePricing(postData).subscribe(data => {
            this.loaderService.display(false);
            const obj = {
              transId: this.cycleInfo.transId,
              tranSrNo: this.cycleInfo.tranSrNo,
              quoteNo: createQuoteResponse.quoteNo,
              lobCode: ApiConstants.CYCLE_INSURANCE_LOBCODE,
            }
            this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
          }, error => {
            this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
            this.loaderService.display(false);
          });
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        });
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    }, error => {
      let err = error.json();
      if (err.respCode == "5005") {
        this.promoCodeError = err.errMessage;
      } else {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      }
      this.loaderService.display(false);
    });
  }

  onDateInput(event) {

    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.insuredInfo.insDob = event.target.value;
        }
      }
    }

  }

  onDateChanged(event) {

    if (this.insuredInfo.insDob != undefined || this.insuredInfo.insDob == null) {
      this.showMsg = false;
      console.log(this.insuredInfo.insDob)
    }
    console.log(this.insuredInfo.insDob)
  }
  getAgeValidate(dateString: any) {
    if (dateString == '' || dateString == undefined) {
      return false;
    } else {
      //console.log(dateString)
      //let dobOf:string = dateString.formatted;
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {
        if (dateString.date != undefined) {
          dateString = dateString.date.month + "/" + dateString.date.day + "/" + dateString.date.year;
        }

        let parts = dateString.split('/');
        birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }

      //const date = this.appUtilObj.getUTCDate(timestamp);
      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age < 18) {
        this.checkDate = true;
        return true;
      } else if (age > 70) {
        this.checkDate = true;
        return true;
      }
      else {
        this.checkDate = false;
        return false;
      }

    }

  }

}
