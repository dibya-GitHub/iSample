import { TestBed, inject } from '@angular/core/testing';

import { CycleInsuranceService } from './cycle-insurance.service';

describe('CycleInsuranceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CycleInsuranceService]
    });
  });

  it('should be created', inject([CycleInsuranceService], (service: CycleInsuranceService) => {
    expect(service).toBeTruthy();
  }));
});
