import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiUrls } from 'src/shared/api-urls';
import { environment } from 'src/environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';

@Injectable({
  providedIn: 'root'
})
export class CycleInsuranceService {
  requestOption: any;
  baseUrl: any = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }
  getCoverage(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_CODES, body, this.requestOption);
  }
  getContentsVal(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_PARAM, body, this.requestOption);
  }
  updateHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_HOME_INFO_URL, body, this.requestOption);
  }
  updatePolicyDuration(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_POLICY_DURATION, body, this.requestOption);
  }
  getQuoteHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_HOME_INFO, body, this.requestOption);
  }
  getPolicyHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_HOME_INFO, body, this.requestOption);
  }
  insContentDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_CONTENT_DETAILS, body, this.requestOption);
  }
  getContentDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_CONTENT_DETAILS, body, this.requestOption);
  }
}
