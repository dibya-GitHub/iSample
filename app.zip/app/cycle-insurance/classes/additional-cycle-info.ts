export class AdditionalCycleInfo {
    mapId:string;
    insName:string;
    address:string;
    poBox:string;
    nationality:string;
    civilId:string;
    city:string;
    zoneArea:string;
    streetBlock:string;

    transId: number;
    tranSrNo: number;
    userId: string;
    startDate: Date;
    endDate: Date;
}
