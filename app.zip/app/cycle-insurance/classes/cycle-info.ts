export class CycleInfo {
    transId : string;
    tranSrNo: string;
    mapId :string ='HOME_CYL_RISK_SCR_1';
    insName:string;
    sumAssured:any;
    tplLimit:any;
    buildingVal:any;
    contentsVal:any;
    cycleMake:string;
    cycleModel:string;
    manfYear:any;
    bldngType:any;
}

