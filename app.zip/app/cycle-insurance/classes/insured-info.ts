export class InsuredInfo {
    mapId:string='HOME_CYL_POL_SCR_1';
    insName:string;
    mobileNo:string;
    emailId:string;
    insuranceType:string='HOME_CYL';
    insDob:any;
    insAge:string;
    promoCode:any;
    transId:any;
    tranSrNo:any;
    userId:any;
    
}
