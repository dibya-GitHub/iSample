import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CycleProductComponent } from './cycle-product.component';

describe('CycleProductComponent', () => {
  let component: CycleProductComponent;
  let fixture: ComponentFixture<CycleProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CycleProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CycleProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
