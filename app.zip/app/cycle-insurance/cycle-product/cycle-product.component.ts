import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser'
import * as $ from 'jquery';
import { Router } from "@angular/router";
@Component({
  selector: 'app-cycle-product',
  templateUrl: './cycle-product.component.html',
  styleUrls: ['./cycle-product.component.scss']
})
export class CycleProductComponent implements OnInit {

  constructor(
    private meta: Meta,
    private titleService: Title,
    private router: Router
  ) {
    this.titleService.setTitle('Cycle Insurance Dubai | Compare and Buy Cycle Insurance');
    this.meta.addTag({ name: 'description', content: 'Cycle Insurance in Dubai by i-Insured. A wide range of covers, offering protection against accidental damage and theft that may occur to the bicycle.' });
    this.meta.addTag({ name: 'keywords', content: 'cycle insurance, bicycle insurance quote, best cycle insurance, cycle insurance compare, compare cycle insurance, pedal cycle insurance, bicycle insurance' });
  }

  ngOnInit() {
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //  window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }
  goToFaq() {
    let obj = {
      productType: "Cycle",
    }
    this.router.navigate(['faq'], { queryParams: obj, skipLocationChange: true });

  }
}
