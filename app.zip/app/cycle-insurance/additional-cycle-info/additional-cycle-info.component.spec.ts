import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalCycleInfoComponent } from './additional-cycle-info.component';

describe('AdditionalCycleInfoComponent', () => {
  let component: AdditionalCycleInfoComponent;
  let fixture: ComponentFixture<AdditionalCycleInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalCycleInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalCycleInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
