import { Component, OnInit } from '@angular/core';
import { IAngularMyDpOptions, IMyDateModel } from "angular-mydatepicker";
import { AppUtil } from "src/shared/app-util";
import { InsuranceService } from "src/shared/services/insurance.service";
import { ActivatedRoute, Router, NavigationEnd } from "@angular/router";
import { LoaderService } from "src/shared/loader-service/loader.service";
import { CycleInsuranceService } from '../services/cycle-insurance.service';
import { ApiConstants } from 'src/shared/api-constants';
import { AdditionalCycleInfo } from '../classes/additional-cycle-info';

@Component({
  selector: 'app-additional-cycle-info',
  templateUrl: './additional-cycle-info.component.html',
  styleUrls: ['./additional-cycle-info.component.scss'],
  providers: []
})
export class AdditionalCycleInfoComponent implements OnInit {
  showMsg: boolean = false;
  lobCodeValue: any;
  tplLimit: string;
  showAccessories: boolean = false;
  isSecondDivAvailable: any;
  isProceedNext: boolean;
  showHelperPersDiv: boolean;
  isHomeContentDetailsAvailable: number;
  isServentDetailsAvailable: number;
  showTotalValError: boolean;
  contentSumInsured: number;
  addRowData: any = [];
  persBelTotalValue: number;
  selectedCity: any;
  selectedNationality: any;
  nationalityList: any;
  streetList: any;
  zoneList: any;
  cityList: any;
  isHidden: boolean;
  errorMsg: any;
  quoteNo: any;
  tranSrNo: any;
  transId: any;
  endDate: string;
  isBackButton = false;
  appUtilObj: AppUtil = new AppUtil();
  public additionalCycleInfo = new AdditionalCycleInfo();
  date: Date = new Date();
  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));
  public startDate = { date: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() } };
  public myDatePickerOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
    disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private cycleInsuranceService: CycleInsuranceService,
    private commonService: InsuranceService,
    private loaderService: LoaderService
  ) {
    this.route.queryParams.subscribe(params => {
      this.transId = params['transId'];
      this.tranSrNo = params['tranSrNo'];
      this.quoteNo = params['quoteNo'];
      if (params['backButton'] == 'true') {
        this.showAccessories = true;
        this.isBackButton = true;
      }
      this.onDateChanged(this.startDate);
      let postData;
      const fnName = '';

      postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo
      }
      this.loaderService.display(true);
      this.cycleInsuranceService.getQuoteHomeInfo(postData).subscribe((data: any) => {
        console.log(data);
        this.tplLimit = ((data.buildingVal * 10) / 100).toFixed(2);
        //alert(this.tplLimit);
        this.setInformation(data);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });

    });
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  ngOnInit() {
    const tmpArr = {
      details: '',
    }
    if (!this.isBackButton && window.location.href.indexOf("/retrieve-quote") == -1) {
      this.addRowData.push(tmpArr);
    }
    this.getCity();
    this.getNationality();
    this.getStreetBlock();

    //this.loaderService.display(false);
  }
  scrollTop() {
    window.scrollTo(0, 0);
  }
  addAccessories(val: any, index) {
    this.addRowData[index].details = val;
  }
  addRow() {
    const tmpArr = {
      details: '',
    }
    this.addRowData.push(tmpArr);
  }
  removeRow(index: number) {
    this.addRowData.splice(index, 1);
  }
  onDateChanged(event) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsg = false;
    }
    ////console.log('onDateChanged(): ', event.date, ' - jsdate: ', new Date(event.jsdate).toLocaleDateString(), ' - formatted: ', event.formatted, ' - epoc timestamp: ', event.epoc);
    if (this.startDate == null) {
      this.startDate = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    } else {
      if (this.startDate.date == undefined) {
        let temp: any = this.startDate;
        const stringDate = temp.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];

        let date = new Date(newDate);
        this.startDate = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      this.startDate.date = event.date;
    }
    const timestamp = new Date(event.epoc * 1000).getTime();
    console.log('1 : ' + timestamp);
    if (timestamp == 0) {
      this.endDate = '';
    } else {
      const postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        polStartDate: this.appUtilObj.getUTCDate(timestamp)
      }
      console.log(JSON.stringify(postData));
      if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) != '/renew-policy') {
        this.cycleInsuranceService.updatePolicyDuration(postData).subscribe((data: any) => {
          //alert(JSON.stringify(data));
          //this.endDate = new Date(data.polEndDate).toLocaleDateString();
          let endDate = new Date(data.polEndDate);
          this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
        })
      }
    }
  }
  getDefaults() {
    this.additionalCycleInfo.city = '';
    this.additionalCycleInfo.zoneArea = '';
    //this.additionalCycleInfo.bldngAge = '';
    //this.additionalCycleInfo.bldngType = '';
    // this.additionalCycleInfo.nationality = '';
    this.additionalCycleInfo.streetBlock = '';
    //this.additionalCycleInfo.financedBank = '';
  }
  getCity() {
    this.commonService.getApplicationRefCodes('STATE', '002').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // const tmpArr = data.appCodesArray.reverse(); ;
      this.cityList = this.appUtilObj.sortedArray(arr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getZoneArea(id) {
    this.commonService.getApplicationRefCodes('ZONE_AREA', id).subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();;
      this.zoneList = this.appUtilObj.sortedArray(tmpArr);
    }, error => {
      this.zoneList = [];
      this.additionalCycleInfo.zoneArea = '';
      //this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getStreetBlock() {
    this.commonService.getApplicationCodes('STREET_BLOCK').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();;
      this.streetList = this.appUtilObj.sortedArray(tmpArr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getNationality() {
    this.commonService.getApplicationCodes('NATIONALITY').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // const tmpArr = data.appCodesArray;
      let sortedArr = this.sortNationality(arr);
      this.nationalityList = sortedArr;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  setInformation(data: any) {

    this.getDefaults();
    this.additionalCycleInfo.address = data.address;
    if (data.city != null) {
      this.selectedCity = [{ id: data.city, text: data.cityDesc }]
      // this.additionalCycleInfo.city = data.city;
      this.getZoneArea(data.city);
    }
    this.additionalCycleInfo.poBox = data.poBox;
    // if (data.bldngAge != null) {
    //   this.additionalCycleInfo.bldngAge = data.bldngAge
    // }
    // if (data.financedBank != null) {
    //   this.selectedBank = [{ id: data.financedBank, text: data.financedBankDesc }]
    //   // this.additionalCycleInfo.financedBank = data.financedBank
    // }
    // if (data.bldngType != null) {
    //   this.additionalCycleInfo.bldngType = data.bldngType
    // }
    if (data.streetBlock != null) {
      this.additionalCycleInfo.streetBlock = data.streetBlock
    }
    if (data.zoneArea != null) {
      this.additionalCycleInfo.zoneArea = data.zoneArea
    }
    const postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.commonService.getQuotInfo(postData).subscribe((data: any) => {
      console.log(data);
      this.lobCodeValue = data.lobCode;

      if (data.insName == 'GUEST') {
        this.additionalCycleInfo.insName = '';
      } else {
        this.additionalCycleInfo.insName = data.insName;
      }
      this.additionalCycleInfo.civilId = data.civilId;
      //this.additionalCycleInfo.mobileNo = data.mobileNo;
      this.additionalCycleInfo.address = data.address;
      if (data.nationality != null) {
        this.selectedNationality = [{ id: data.nationality, text: data.nationalityDesc }]
        // this.additionalCycleInfo.nationality = data.nationality;
      }
      //this.additionalCycleInfo.insNameAr = data.insNameAr;
      const date: Date = new Date(data.polStartDate);
      this.startDate = { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
      const endDate = new Date(data.polEndDate);
      this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
    const conntentPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.cycleInsuranceService.getContentDetls(conntentPostData).subscribe((data: any) => {
      this.loaderService.display(true);
      for (let i = 0; i < data.contentDetails.length; i++) {
        const tmpArr = {
          details: data.contentDetails[i].contentDetls,
        }
        this.addRowData.push(tmpArr);
        console.log("this is getContentDetls()");
        this.loaderService.display(false);
      }
      if (!this.isBackButton && window.location.href.indexOf("/retrieve-quote") == -1) {
        this.addRowData.splice(0, 1);
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
    //this.policyHomeInfo = data;
    //this.additionalCycleInfo.address = data.address;

    //this.loaderService.display(false);

  }
  proceedNext() {
    this.scrollTop();
    this.showAccessories = true;
    this.updateUserData();
    window.localStorage.setItem('additionalDataSaved', 'true');

    //this.router.navigate(['summary'], { queryParams: { transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo, displaySecondDivision: this.isSecondDivAvailable, displayPersonalBelonging: this.isHomeContentDetailsAvailable, displayHelpers: this.isServentDetailsAvailable }, skipLocationChange: true });

  }
  insContentDetls() {
    const postArr: any = [];
    ////console.log(this.addRowData);

    let j = 1;
    for (let i = 0; i < this.addRowData.length; i++) {
      const postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        userId: ApiConstants.USER_ID,
        contentType: 0,
        contentDetls: '',
      };
      if (this.addRowData[i].details != '') {
        ////console.log(this.addRowData.length == i + 1);

        postData.contentDetls = this.addRowData[i].details;
        postData.contentType = j;
        postArr.push(postData);
        j++;
      }

    }
    console.log(postArr);
    if (postArr.length > 0) {
      this.cycleInsuranceService.insContentDetls(postArr).subscribe(data => {
        console.log(JSON.stringify(data));

        this.router.navigate(['upload-document'], { queryParams: { transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo, lobCode: this.lobCodeValue, displaySecondDivision: this.isSecondDivAvailable, displayPersonalBelonging: this.isHomeContentDetailsAvailable, displayHelpers: this.isServentDetailsAvailable }, skipLocationChange: true });

      })
    } else {
      const postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        userId: ApiConstants.USER_ID,
        contentType: 1,
        contentDetls: '',
      };
      postArr.push(postData);
      this.cycleInsuranceService.insContentDetls(postArr).subscribe(data => {
        console.log(JSON.stringify(data));

        this.router.navigate(['upload-document'], { queryParams: { transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo, lobCode: this.lobCodeValue, displaySecondDivision: this.isSecondDivAvailable, displayPersonalBelonging: this.isHomeContentDetailsAvailable, displayHelpers: this.isServentDetailsAvailable }, skipLocationChange: true });

      })
    }
    this.loaderService.display(false);
  }

  updateUserData() {

    // if (jQuery('.alert.alert-danger')[0]) {
    //   return false;
    // }
    this.additionalCycleInfo.transId = this.transId;
    this.additionalCycleInfo.tranSrNo = this.tranSrNo;
    if (this.selectedNationality != undefined) {
      this.additionalCycleInfo.nationality = this.selectedNationality[0].id;
    }
    this.additionalCycleInfo.city = this.selectedCity[0].id;
    this.additionalCycleInfo.mapId = 'HOME_CYL_POL_SCR_2';
    this.commonService.updateInsuredInfo(this.additionalCycleInfo).subscribe(data => {
      //////console.log(JSON.stringify(data));
      this.additionalCycleInfo.mapId = 'HOME_CYL_RISK_SCR_2';
      //console.log(JSON.stringify(this.additionalCycleInfo));
      this.cycleInsuranceService.updateHomeInfo(this.additionalCycleInfo).subscribe(data => {
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  backToDetails() {
    const obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      lobCode: ApiConstants.CYCLE_INSURANCE_LOBCODE
    }
    this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
  }
  onDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.startDate = event.target.value;
        }
      }
    }

  }
}
