import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { CarInsurancePlanService } from "src/app/car-insurance/services/car-insurance-plan.service";
import { environment } from 'src/environments/environment';
import { ApiHeadersService } from 'src/shared/api-headers.service';
import { AppUtil } from 'src/shared/app-util';
import { NewPayment } from 'src/shared/interfaces/new-payment';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { InsuranceService } from "src/shared/services/insurance.service";
import { PaymentService } from 'src/shared/services/payment.service';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { ApiConstants } from '../../shared/api-constants';
import { HomeInsurancePlanService } from '../home-insurance/services/home-insurance-plan.service';
import { TravelInfoService } from '../travel-insuarance/services/travel-info.service';

@Component({
  selector: 'app-payment-summary',
  templateUrl: './payment-summary.component.html',
  styleUrls: ['./payment-summary.component.scss']
})
export class PaymentSummaryComponent implements OnInit {
  showModal: boolean = false;
  termsAndConditionText: any;
  accept: boolean = false;
  instYnCheckForMailLink: any = 0;
  mailLink: boolean = false;
  checkDate: boolean = false;
  showMsg: boolean = false;
  cycleInsurance: boolean;
  public show_inst: boolean;
  public data: NewPayment;
  paymentSummary: boolean = false;
  discount: number = 0;
  deductibles: number = 0;
  charges: any = [];
  taxes: any = [];
  premium: any;
  public controls;
  transId: any;
  tranSrNo: any;
  quoteNo: any;
  policyNo: any;
  carInsurance: boolean = false;
  homeInsurance: boolean = false;
  travelInsurance: boolean = false;
  pabInsurance: boolean = false;
  sumOptional: any = [];
  coversArray: any[] = [];
  sumInclusiveMandatory: any = [];
  processRowClass: string = "process-row nav nav-tabs";
  installmentOption: boolean = false;
  showInstallment: boolean = false;
  isThirdPartySelected: boolean;
  applyProcessFourTab: string = "process";
  renewPolicy: boolean = false;
  paymentOptionsArray: any[] = [];
  quoteInfoData: any;
  regPaymentInfo: any;
  ip: any;
  retrieveQuote: boolean = false;
  lobCodeValue: string = "";
  insuranceTypeValue: string = "";
  pgReqUrl: any;
  installmentList: any = [];
  showDiv = false;
  displaySecondDiv: any;
  displayPersonalBelonging: any;
  displayHelpers: any;
  showPersonalBelongingText: boolean = false;
  showHelpersText: boolean = false;
  toggleVal: any = 0;
  premiumToSend: any;
  title: any;
  titleMsg: any;
  isInstallment = false;
  token: string;
  userId: string;
  vehicleInfo: boolean = false;
  personalInfo: boolean = false
  travelerInfo: boolean = false;
  homeInfo: boolean = false;
  vehicleInfoData: any;
  travelerData: any;
  homeData: any;
  products: any = [];
  bundledTransId: string;
  bundledTranSrNo: string;
  bundledPremium: string;
  showBundledProducts: boolean = false;
  showPremiumDetails: boolean = false;
  bundledSumIncMandHome: any = [];
  bundledSumOptionalHome: any = [];
  bundledDiscountHome: any = [];
  bundledDeductiblesHome: any = [];
  bundledTaxHome: any = [];
  bundledTaxTravel: any = [];
  bundledChargesTravel: any = [];
  bundledCoversArray: any[] = [];
  bundledProdPremium: string;
  bundledTravelObject: any = {};
  bundledHomeObject: any = {};
  showHome: boolean = false;
  showTravel: boolean = false;
  homeProductCode: any = "";
  travelProductcode: any = "";
  bundledSumIncMandTravel: any = []
  bundledSumOptionalTravel: any = [];
  bundledDeductiblesTravel: any = [];
  bundledDiscountTravel: any = [];
  displayHomeForm: boolean = false;
  displayTravelForm: boolean = false;
  gender_list: any = [];
  relation_list: any = [];
  nationality_list: any = [];
  appUtilObj: AppUtil = new AppUtil();
  date: Date = new Date();
  bankList: any = [];
  cityList: any = [];
  streetList: any = [];
  bulTypeList: any = [];
  buildingAge: any = [];
  zoneList: any = [];
  bundledHomePremium: any;
  bundledTravelPremium: any;
  nationality_value: any = {};
  travelerDetailArray: any = [];
  bundledTravelTransId: string;
  bundledTravelTranSrNo: string;
  bundledHomeTransId: string;
  bundledHomeTranSrNo: string;
  dob: any;
  city: any = {};
  bank: any = {};
  checkboxVal: boolean;
  termsCheckBox: boolean = false;
  errorMsg: string = '';
  bundledTravelerName: string;
  bundledTravelerDOB: any;
  bundledTravelerNationality: any;
  bundledHomeCity: any;
  bundledHomePoBox: string;
  bundledTravelerGender: any;
  bundledTravelerRelation: any;
  bundledTravelerPassport: any;
  baseUrl = environment.baseUrl;
  carInsType: any;
  insValidYN: any;
  bundleTransId: string;
  editPlanArr: any = [];
  lobCode: any;
  bundledHomeAddress: string;
  bundledHomeZone: any;
  bundledHomeStreet: any;
  backButton: boolean = false;
  isFirstTime: boolean = true;
  pdfUrl: any;
  showTokenError: any = '';
  tripType: any = '';
  personalInformation: any = [];
  ifTelematics: string = "0";

  public myDatePickerOptionsDOB: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    disableSince: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() + 1 }

  };
  ncdYear: any;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private paymentService: PaymentService,
    private pixelService: RocketFuelService,
    private travelInfoService: TravelInfoService,
    private apiHeadersService: ApiHeadersService,
    private insurancePlanService: InsuranceService,
    private carInsurancePlanService: CarInsurancePlanService,
    private homeInsurancePlanService: HomeInsurancePlanService,
  ) {
    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      this.quoteNo = params["quoteNo"];
      this.displaySecondDiv = params["displaySecondDivision"];
      this.displayPersonalBelonging = params["displayPersonalBelonging"];
      this.displayHelpers = params["displayHelpers"];
      this.token = params["token"];
      this.carInsType = params["carInsType"];
      this.insValidYN = params["insValidYN"];
      this.userId = params["userId"];
      this.bundleTransId = params["bundleTransId"];
      this.isThirdPartySelected = params["isThirdPartyInsurance"];
      this.lobCode = params["lobCode"];
      this.backButton = params["backButton"];
      this.ncdYear = params['ncdYear'];
      //this.loaderService.display(true);
      if (this.displayPersonalBelonging == 1) {
        this.showPersonalBelongingText = true;
      } else {
        this.showPersonalBelongingText = false;
      }

      if (this.displayHelpers == 1) {
        this.showHelpersText = true;
      } else {
        this.showHelpersText = false;
      }

    });
  }

  ngOnInit() {
    this.editPlanArr.push({ editPlanYN: 0 }, { editPlanYN: 0 })
    this.loaderService.display(true);
    if (window.location.href.indexOf("/car-insurance") > -1) {
      this.carInsurance = true;
      if (this.isThirdPartySelected) {
        this.processRowClass = "process-two-tab process-row nav nav-tabs";
      } else {
        this.processRowClass = "process-three-tab process-row nav nav-tabs";
      }
    }
    if (window.location.href.indexOf("/home-insurance") > -1) {
      this.homeInsurance = true;
      this.processRowClass = "process-two-tab process-row nav nav-tabs";
    }

    if (window.location.href.indexOf("/pab-insurance") > -1) {
      this.pabInsurance = true;
      this.processRowClass = "process-two-tab process-row nav nav-tabs";
    }
    if (window.location.href.indexOf("/travel-insurance") > -1) {
      this.travelInsurance = true;
      this.processRowClass = "process-two-tab process-row nav nav-tabs";
    }
    if (window.location.href.indexOf("/renew-policy") > -1) {
      this.renewPolicy = true;
    }
    if (window.location.href.indexOf("/retrieve-quote") > -1) {
      this.retrieveQuote = true;
    }
    if (this.bundleTransId && !this.toBoolean(this.backButton)) {
      this.getBundledProducts(this.transId, this.tranSrNo)
    } else if (this.token && this.userId) {
      let params = { payToken: this.token, userId: this.userId }
      this.insurancePlanService.validatePayLink(params).subscribe(
        (res: any) => {
          this.mailLink = true;
          if (res.linkValidYn) {
            this.transId = res.transId;
            this.tranSrNo = res.tranSrNo;
            this.quoteNo = res.quoteNo;
            this.getQuoteInfo();
            this.getCoverDetails();
          }
        }, error => {
          try {
            let err = error.json();
            let obj = {
              errMsg: err.errMessage
            }
            this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
          } catch (err) {

          }
          this.loaderService.display(false);
        }
      )
    } else {
      this.getQuoteInfo();
      this.getCoverDetails();
    }

    // this.checkBundledProduct();
    $('.box-shadow').hide();
    $('.container').hide();

    this.setGoogleAnalyticsPages();
  }

  setGoogleAnalyticsPages() {
    var fromUrl = window.localStorage.getItem('urlFlow');
    var pathName = fromUrl + '/summary';
    (<any>window).gtag('set', 'page', pathName);
    (<any>window).gtag('send', 'pageview', pathName);
    (<any>window).gtag('config', 'UA-68986372-1', { 'page_path': pathName });
  }

  toBoolean(bool) {
    if (bool === 'false') bool = false
    return !!bool
  }

  checkBundledProduct() {
    if (this.products.length > 0) {
      this.showBundledProducts = true;
      return this.products;
    } else {
      const params = { transId: this.transId, tranSrNo: this.tranSrNo };
      this.getBundledProducts(this.transId, this.tranSrNo);
    }
  }

  getBundledProducts(transId, tranSrNo) {
    const params = { transId: transId, tranSrNo: tranSrNo };
    this.paymentService.checkBundledProduct(params).subscribe(
      data => {
        if (data.option == "1") {
          this.paymentService.getBundledProductDetails(params).subscribe(
            res => {
              console.log(JSON.stringify(res));
              let bundledArr = res.bundleArray.filter(prod => prod.lobCode != "01")
              for (var i in bundledArr) {
                if (bundledArr[i].lobCode == "04") {
                  this.products.push(bundledArr[i])
                  this.homeProductCode = bundledArr[i].prodCode;
                } else if (bundledArr[i].lobCode == "08") {
                  this.products.push(bundledArr[i])
                  this.travelProductcode = bundledArr[i].prodCode;
                }
              }
              if (this.bundleTransId) {
                this.transId = this.bundleTransId
                for (var i in bundledArr) {
                  if (bundledArr[i].selectYN == "1") {
                    this.displayForm(bundledArr[i], true, i)
                  }
                }
                if (this.isFirstTime) {
                  this.getCoverDetails();
                  this.getQuoteInfo();
                }
                this.isFirstTime = false;
              }
              this.showBundledProducts = true;
            }, error => {
              this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
              this.loaderService.display(false);
            });
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  displayForm(product, event, index: any) {
    this.loaderService.display(true)
    var formCheck = event ? "1" : "0"
    this.editPlanArr[index].editPlanYN = formCheck;
    if (product.lobCode == "04") {
      if (formCheck == "1") {
        let params = { transId: this.transId, tranSrNo: this.tranSrNo, userId: "online", prodCode: product.prodCode, schCode: product.schCode, selectYN: "1", lobCode: product.lobCode }
        this.paymentService.updateBundlSel(params).subscribe(
          res => {
            if (res.respCode == "2000") {
              this.bundledHomeTransId = res.transId;
              this.bundledHomeTranSrNo = res.tranSrNo;
              this.getHomeFormDetails()
              const params = { transId: this.bundledHomeTransId, tranSrNo: this.bundledHomeTranSrNo }
              this.insurancePlanService.getNetPremSumm(JSON.stringify(params)).subscribe(response => {
                this.bundledHomePremium = response["TOTALPREMIUN"];
                this.premium += this.bundledHomePremium;
                this.premiumToSend = this.premium;
              }, error => {
                this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
                this.loaderService.display(false);
              });
              this.displayHomeForm = event;
              this.loaderService.display(false)
            }
          }, error => {
            this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
            this.loaderService.display(false);
          }
        )
      } else {
        let params = { transId: this.transId, tranSrNo: this.tranSrNo, userId: "online", prodCode: product.prodCode, schCode: product.schCode, selectYN: "0", lobCode: product.lobCode }
        this.paymentService.updateBundlSel(params).subscribe(
          res => {
            if (res.respCode == "2000") {
              this.premium -= this.bundledHomePremium;
              this.premiumToSend = this.premium;
              this.displayHomeForm = event;
              this.loaderService.display(false)
            }
          }
        )
      }
    } else if (product.lobCode == "08") {
      if (formCheck == "1") {
        // $("#travelPlan").show();
        let params = { transId: this.bundleTransId ? this.bundleTransId : this.transId, tranSrNo: this.tranSrNo, userId: "online", prodCode: product.prodCode, schCode: product.schCode, selectYN: "1", lobCode: product.lobCode }
        this.paymentService.updateBundlSel(params).subscribe(
          res => {
            if (res.respCode == "2000") {
              this.bundledTravelTransId = res.transId;
              this.bundledTravelTranSrNo = res.tranSrNo;
              this.getTravelFormDetails()
              const params = { transId: this.bundledTravelTransId, tranSrNo: this.bundledTravelTranSrNo }
              this.insurancePlanService.getNetPremSumm(JSON.stringify(params)).subscribe(response => {
                this.bundledTravelPremium = response["TOTALPREMIUN"];
                this.premium += this.bundledTravelPremium;
                this.premiumToSend = this.premium;
              });
              this.displayTravelForm = event;
              setTimeout(() => {
                if (this.bundledTravelerPassport != undefined && this.bundledTravelerPassport.length > 0) {
                  $('#passNo').removeClass('invalid').addClass('valid');
                }
              }, 1000);
              this.loaderService.display(false)
            }
          }, error => {
            this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
            this.loaderService.display(false);
          });
      } else {
        let params = { transId: this.bundleTransId ? this.bundleTransId : this.transId, tranSrNo: this.tranSrNo, userId: "online", prodCode: product.prodCode, schCode: product.schCode, selectYN: "0", lobCode: product.lobCode }
        this.paymentService.updateBundlSel(params).subscribe(
          res => {
            if (res.respCode == "2000") {
              this.premium -= this.bundledTravelPremium;
              this.premiumToSend = this.premium;
              this.displayTravelForm = event;
              this.loaderService.display(false)
            }
          }, error => {
            this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
            this.loaderService.display(false);
          }
        )
      }
    }
  }

  chooseBundledPlan(product) {
    for (let i = 0; i < this.products.length; i++) {
      if (this.products[i].lobCode != product.lobCode) {
        let params = { transId: this.transId, tranSrNo: this.tranSrNo, userId: "online", prodCode: this.products[i].prodCode, schCode: this.products[i].schCode, selectYN: "0", lobCode: this.products[i].lobCode }
        this.paymentService.updateBundlSel(params)
      }
    }
    if (product.lobCode == "04") {
      let obj = {
        transId: this.bundledHomeTransId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        lobCode: product.lobCode,
        carTransId: this.transId,
        insValidYN: this.insValidYN

      }
      this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
    } else if (product.lobCode == "08") {
      let obj = {
        transId: this.bundledTravelTransId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        lobCode: product.lobCode,
        carTransId: this.transId,
        insValidYN: this.insValidYN
      }
      this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
    }
  }

  getHomeFormDetails() {
    // City list
    this.insurancePlanService.getApplicationRefCodes('STATE', '002').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // const tmpArr = data.appCodesArray.reverse(); ;
      this.cityList = this.appUtilObj.sortedArray(arr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

    // Street/Block List
    this.insurancePlanService.getApplicationCodes('STREET_BLOCK').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();;
      this.streetList = this.appUtilObj.sortedArray(tmpArr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

    // populate data
    if (this.bundleTransId) {
      let params = { "transId": this.bundledHomeTransId, "tranSrNo": this.tranSrNo }
      this.homeInsurancePlanService.getQuoteHomeInfo(params).subscribe(
        (res: any) => {
          this.bundledHomePoBox = res.poBox;
          this.bundledHomeCity = [{ id: res.city, text: res.cityDesc }];
          if (res.address) {
            this.bundledHomeAddress = res.address;
            $('#address').removeClass("invalid").addClass("valid");
          } else {
            this.bundledHomeAddress = ""
          }
          let zone = this.getZoneArea(res.city);
          // this.bundledHomeZone = res.zoneArea ? res.zoneArea : "";
          this.bundledHomeZone = this.getZoneArea(res.city);
          if (res.streetBlock) {
            this.bundledHomeStreet = res.streetBlock;
            $('#street').removeClass("invalid").addClass("valid");
          } else {
            this.bundledHomeStreet = ""
          }
          $(function () {
            $('#zone-area').removeClass("invalid").addClass("valid");
          })
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        }
      )
    } else {
      let quoute_params = { "transId": this.transId, "tranSrNo": this.tranSrNo }
      this.insurancePlanService.getQuotInfo(quoute_params).subscribe(
        (res: any) => {
          this.bundledHomeCity = [{ id: res.city, text: res.cityDesc }];
          this.bundledHomePoBox = res.poBox;
          let zone = this.getZoneArea(res.city);
          this.bundledHomeZone = this.getZoneArea(res.city);
          this.bundledHomeStreet = "";
          this.bundledHomeAddress = "";
          $(function () {
            $('#zone-area').removeClass("invalid").addClass("valid");
          })
        }
      )
    }

    $(function () {
      $('#address').on('input', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#buildError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#buildError").show(); }
      });

      $('#poBox').on('input', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#poBoxError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#poBoxError").show(); }
      });

      $('#zone-area').on('change', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#zoneAreaError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#zoneAreaError").show(); }
      });

      $('#street').on('change', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#streetError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#streetError").show(); }
      });
    })
  }

  getCity(value: any): void {
    if (!this.checkEmptyObject(value)) {
      this.city = value;
      $("#citySearch").removeClass("invalid").addClass("valid");
      $("#cityError").hide();
    } else {
      $("#citySearch").removeClass("valid").addClass("invalid");
      $("#cityError").show();
    }
  }

  getZoneArea(id) {
    // Zone area
    if (id) {
      this.insurancePlanService.getApplicationRefCodes('ZONE_AREA', id).subscribe(data => {
        const tmpArr = data.appCodesArray.reverse();;
        this.zoneList = this.appUtilObj.sortedArray(tmpArr);
      }, error => {
        this.zoneList = [];
        this.bundledHomeZone = '';
        //this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    }

  }

  getTravelFormDetails() {
    // Gender List
    const gender_param = { 'paraType': 'GENDER' }
    this.insurancePlanService.getGenderList(gender_param).subscribe(
      res => {
        this.gender_list = res.appParamsArray;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });

    // Relation List
    const relation_param = { "type": "RELATION" }
    this.insurancePlanService.getRelationList(relation_param).subscribe(
      res => {
        this.relation_list = res.appCodesArray;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });

    // Nationality list
    let get_nationaLitylist = { "type": "NATIONALITY" };
    this.insurancePlanService.getNationalityList(get_nationaLitylist)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        let sortedArr = this.sortNationality(arr);
        this.nationality_list = sortedArr;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });

    // populate data
    if (this.bundleTransId) {
      let params = { "transId": this.bundledTravelTransId, "tranSrNo": this.tranSrNo }
      this.travelInfoService.getTravelerDetls(params).subscribe(
        res => {
          let travelerDetails = res.travelerArray[0]
          this.bundledTravelerName = travelerDetails.trvlrName;
          this.bundledTravelerGender = travelerDetails.gender;
          if (this.bundledTravelerGender == null) {
            this.bundledTravelerGender = '';
          }
          this.bundledTravelerNationality = [{ id: travelerDetails.nationality, text: travelerDetails.nationalityDesc }];
          this.bundledTravelerRelation = travelerDetails.relation;
          this.bundledTravelerPassport = travelerDetails.passptNo;
          let date = new Date(travelerDetails.dob);
          this.bundledTravelerDOB = { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } }
          $(function () {
            $('#relation, #passNo, #selectNationality, #dobDate, #gender').removeClass("invalid").addClass("valid");
          })
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        }
      )
    } else {
      let quote_params = { "transId": this.transId, "tranSrNo": this.tranSrNo }
      this.insurancePlanService.getQuotInfo(quote_params).subscribe(
        (res: any) => {
          this.bundledTravelerName = res.insName;
          this.bundledTravelerRelation = "";
          if (res.insDob) {
            let DOB = this.getDate(res.insDob)
            this.bundledTravelerDOB = { date: { year: DOB.getFullYear(), month: DOB.getMonth() + 1, day: DOB.getDate() } }
            $('#dobDate').removeClass("invalid").addClass("valid");
          } else {
            this.bundledTravelerDOB = ""
          }
          if (res.nationality) {
            this.bundledTravelerNationality = [{ id: res.nationality, text: res.nationalityDesc }]
            $('#selectNationality').removeClass("invalid").addClass("valid");
          } else {
            this.bundledTravelerNationality = ''
          }
          if (res.gender) {
            this.bundledTravelerGender = res.gender;
            $('#gender').removeClass("invalid").addClass("valid");
          } else {
            this.bundledTravelerGender = "";
          }
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        }
      )
    }

    $(function () {
      $('#insName').on('input', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#insNameError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#insNameError").show(); }
      });

      $('#relation').on('input', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#relationError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#relationError").show(); }
      });

      $('#gender').on('input', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#genderError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#genderError").show(); }
      });

      $('#passNo').on('input', function () {
        var input = $(this);
        var is_name = input.val();
        if (is_name) { input.removeClass("invalid").addClass("valid"); $("#passNoError").hide(); }
        else { input.removeClass("valid").addClass("invalid"); $("#passNoError").show(); }
      });

    })
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  getDate(date) {
    const dateParts = date.split("/");
    return new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
  }

  checkEmptyObject(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

  getPremiumDetails(product) {
    if (product.lobCode == "04") {
      $("#homeDrop").slideToggle("slow");
      $("a#home").toggleClass("icon-down icon-up");
    } else if (product.lobCode == "08") {
      $("#travelDrop").slideToggle("slow");
      $("a#travel").toggleClass("icon-down icon-up");
    }
    if (product.lobCode == "04" && !this.checkEmptyObject(this.bundledHomeObject)) {
      this.showHome = true
      return this.bundledHomeObject;
    } else if (product.lobCode == "08" && !this.checkEmptyObject(this.bundledTravelObject)) {
      this.showTravel = true
      return this.bundledTravelObject;
    } else {
      const params = { transId: product.bundleTransId, tranSrNo: product.bundleTranSrNo, userId: "online", prodCode: product.prodCode, schCode: product.schCode, selectYN: product.selectYN }
      this.paymentService.updateBundlSel(params).subscribe(
        res => {
          if (res.respCode == "2000") {
            this.bundledTransId = res.transId;
            this.bundledTranSrNo = res.tranSrNo;
            this.bundledPremium = res.premium;
            this.getSummaryDetails(this.bundledTransId, this.bundledTranSrNo, product.lobCode)
          }
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        });
    }
  }

  getSummaryDetails(bundledTransId, bundledTranSrNo, lob) {
    var coverSummaryData = { "transId": bundledTransId ? bundledTransId : this.transId, "tranSrNo": bundledTranSrNo ? bundledTranSrNo : this.tranSrNo };
    this.insurancePlanService.getCoverSummary(JSON.stringify(coverSummaryData)).subscribe(response => {
      var array = bundledTransId ? this.bundledCoversArray = response["coversArray"] : this.coversArray = response["coversArray"];
      let j = 0;
      for (var i = 0; i < array.length; i++) {
        if (array[i].type == 'I' || array[i].type == 'M') {
          if (array[i].type == 'I') {
            array[i].premium = 'Inclusive';
            if (bundledTransId && lob == "04") {
              this.bundledSumIncMandHome.push(array[i]);
              this.bundledHomeObject["mandCovers"] = this.bundledSumIncMandHome;
            } else if (bundledTransId && lob == "08") {
              this.bundledSumIncMandTravel.push(array[i])
              this.bundledTravelObject["mandCovers"] = this.bundledSumIncMandTravel;
            } else {
              this.sumInclusiveMandatory.push(array[i]);
            }
          } else {
            if (array[i].premium > 0) {
              if (bundledTransId && lob == "04") {
                this.bundledSumIncMandHome.splice(j, 0, array[i]);
                this.bundledHomeObject["mandCovers"] = this.bundledSumIncMandHome;
              } else if (bundledTransId && lob == "08") {
                this.bundledSumIncMandTravel.splice(j, 0, array[i]);
                this.bundledTravelObject["mandCovers"] = this.bundledSumIncMandTravel;
              } else {
                this.sumInclusiveMandatory.splice(j, 0, array[i]);
              }
              j++;
            }
          }
        }
        if (array[i].type == 'O') {
          if (bundledTransId && lob == "04") {
            this.bundledSumOptionalHome.push(array[i]);
            this.bundledHomeObject["optCovers"] = this.bundledSumOptionalHome;
          } else if (bundledTransId && lob == "08") {
            this.bundledSumOptionalTravel.push(array[i]);
            this.bundledTravelObject["optCovers"] = this.bundledSumOptionalTravel;
          } else {
            this.sumOptional.push(array[i]);
          }
        }
      }
      this.showDiv = true;
      this.loaderService.display(false);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

    let taxesPostData = { "transId": bundledTransId ? bundledTransId : this.transId, "tranSrNo": bundledTranSrNo ? bundledTranSrNo : this.tranSrNo, "type": "TAX" }
    this.insurancePlanService.getDiscDedLoadFeesSumm(JSON.stringify(taxesPostData)).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null) {
        if (bundledTransId && lob == "04") {
          this.bundledTaxHome = response["othersArray"];
          this.bundledHomeObject["tax"] = this.bundledTaxHome;
        } else if (bundledTransId && lob == "08") {
          this.bundledTaxTravel = response["othersArray"];
          this.bundledTravelObject["tax"] = this.bundledTaxTravel;
        } else {
          this.taxes = response["othersArray"];
        }
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

    let chargesPostData = { "transId": bundledTransId ? bundledTransId : this.transId, "tranSrNo": bundledTranSrNo ? bundledTranSrNo : this.tranSrNo, "type": "FEES" }
    this.insurancePlanService.getDiscDedLoadFeesSumm(JSON.stringify(chargesPostData)).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null) {
        if (bundledTransId && lob == "08") {
          this.bundledChargesTravel = response["othersArray"];
          this.bundledTravelObject["charges"] = this.bundledChargesTravel;
        } else {
          this.charges = response["othersArray"];
        }
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

    //taxes and charges
    // let chargesPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "type": "FEES" }
    // this.insurancePlanService.getDiscDedLoadFeesSumm(JSON.stringify(chargesPostData)).subscribe(response => {
    //   this.charges = response["othersArray"];
    // });
    // let postData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "type": "TAX" }
    // this.insurancePlanService.getDiscDedLoadFeesSumm(JSON.stringify(postData)).subscribe(response => {
    //   this.taxes = response["othersArray"];
    // });



    //service call to get the deductibles summary. As of now the transId is hard-coded because the service does not return correct result for random generated transId. Need to update.
    let coverDeductionData = { "transId": bundledTransId ? bundledTransId : this.transId, "tranSrNo": bundledTranSrNo ? bundledTranSrNo : this.tranSrNo, "type": "DED" }
    this.insurancePlanService.getDiscDedLoadFeesSumm(JSON.stringify(coverDeductionData)).subscribe(
      response => {
        if (response["othersArray"] != "" && response["othersArray"] != null) {
          if (bundledTransId && lob == "04") {
            this.bundledDeductiblesHome = response["othersArray"];
            this.bundledHomeObject["deductibles"] = this.bundledDeductiblesHome;
          } else if (bundledTransId && lob == "08") {
            this.bundledDeductiblesTravel = response["othersArray"];
            this.bundledTravelObject["deductibles"] = this.bundledDeductiblesTravel;
          } else {
            this.deductibles = response["othersArray"];
          }
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    ////service call to get the discount summary. Need to uncomment this piece of code once the service returns correct results.
    let coverDiscountData = { "transId": bundledTransId ? bundledTransId : this.transId, "tranSrNo": bundledTranSrNo ? bundledTranSrNo : this.tranSrNo, "type": "DISC" }
    this.insurancePlanService.getDiscDedLoadFeesSumm(JSON.stringify(coverDiscountData)).subscribe(response => {
      //////////console.log("Discounts")
      //console.log(response);
      if (response["othersArray"] != "" && response["othersArray"] != null) {
        if (bundledTransId && lob == "04") {
          this.bundledDiscountHome = response["othersArray"];
          this.bundledHomeObject["discounts"] = this.bundledDiscountHome;
        } else if (bundledTransId && lob == "08") {
          this.bundledDiscountTravel = response["othersArray"];
          this.bundledTravelObject["discounts"] = this.bundledDiscountTravel;
        } else {
          this.discount = response["othersArray"];
        }
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
    this.insurancePlanService.getNetPremSumm(JSON.stringify(coverSummaryData)).subscribe(response => {
      if (bundledTransId && lob == "04") {
        this.bundledHomePremium = response["TOTALPREMIUN"];
        // this.premiumToSend = this.bundledHomePremium;
      } else if (bundledTransId && lob == "08") {
        this.bundledTravelPremium = response["TOTALPREMIUN"];
        // this.premiumToSend = this.bundledTravelPremium;
      } else {
        this.premium = response["TOTALPREMIUN"];
        this.premiumToSend = this.premium;

      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

    if (lob) {
      if (lob == "04") {
        this.bundledHomeObject["mandCovers"] = this.bundledSumIncMandHome;
        this.bundledHomeObject["optCovers"] = this.bundledSumOptionalHome;
        this.bundledHomeObject["discounts"] = this.bundledDiscountHome;
        this.bundledHomeObject["deductibles"] = this.bundledDeductiblesHome;
      } else {
        this.bundledTravelObject["mandCovers"] = this.bundledSumIncMandTravel;
        this.bundledTravelObject["optCovers"] = this.bundledSumOptionalTravel;
        this.bundledTravelObject["discounts"] = this.bundledDiscountTravel;
        this.bundledTravelObject["deductibles"] = this.bundledDeductiblesTravel;
      }
    }

    if (bundledTransId) {
      this.showPremiumDetails = true;
    }

    if (lob === "04") {
      this.showHome = true
    } else if (lob === "08") {
      this.showTravel = true;
    }
  }

  getCoverDetails(bundledTransId?: string, bundledTranSrNo?: string, lob?: string) {
    this.getSummaryDetails(bundledTransId, bundledTranSrNo, lob)

    //service call to get the premium.
    var coverSummaryData = { "transId": bundledTransId ? bundledTransId : this.transId, "tranSrNo": bundledTranSrNo ? bundledTranSrNo : this.tranSrNo };
    this.insurancePlanService.getNetPremSumm(JSON.stringify(coverSummaryData)).subscribe(response => {
      this.premium = response["TOTALPREMIUN"];
      this.premiumToSend = this.premium;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

    //service call to get the payment options
    this.insurancePlanService.getPaymentOptions(JSON.stringify(coverSummaryData)).subscribe((response: any) => {
      //////////console.log("Payment options ---");
      //////////console.log(response);
      //////////console.log(response.payOptsArray);
      this.paymentOptionsArray = response.payOptsArray;
      //////////console.log(this.paymentOptionsArray);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  showInstallments() {
    this.show_inst = !this.show_inst;
  }

  public getUTCDate(): string {
    var now = new Date();
    var now_utc = now.getUTCFullYear() + "-" + this.appendZero(now.getUTCMonth() + 1) + "-" + this.appendZero(now.getUTCDate()) + "T" + this.appendZero(now.getUTCHours()) + ":" + this.appendZero(now.getUTCMinutes()) + ":" + this.appendZero(now.getUTCSeconds()) + "Z";
    return now_utc;
  }

  public appendZero(digit): string {
    if (digit < 10)
      return "0" + digit;
    else
      return digit;
  }

  goToPreviousPage() {
    let obj = {
      transId: this.bundleTransId ? this.bundleTransId : this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      backButton: !this.backButton,
      lobCode: this.lobCodeValue,
      insValidYN: this.insValidYN,
      carInsType: this.carInsType != undefined ? this.carInsType.toString() : '',
      ncdYear: this.ncdYear
    }
    if (this.lobCodeValue == "01" && this.carInsType == "true") {
      this.router.navigate(['carDetails'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCodeValue == "01") {
      this.router.navigate(['upload-document'], { queryParams: obj, skipLocationChange: true });
    } else if (this.cycleInsurance) {
      this.router.navigate(['upload-document'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCodeValue == "04") {
      this.router.navigate(['upload-document'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCodeValue == "08" && this.insuranceTypeValue == "PAB") {
      this.router.navigate(['additional-pab-info'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCodeValue == "08") {
      this.router.navigate(['upload-document'], { queryParams: obj, skipLocationChange: true });
    }
  }


  toggle(val: any) {

    if (val == 0) {
      this.updateInstallmentFlag(val);
      this.isInstallment = false;
      // this.checkBundledProduct();
    } else {
      this.updateInstallmentFlag(val);
      this.showBundledProducts = false;
      this.isInstallment = true;
    }
    this.toggleVal = val;
    // this.updateInstallmentFlag(val);
    $("#inslDiv").toggle(300);
  }


  /*initPayment() {
    this.data = this.paymentService.initPayment(this.quoteInfoData, this.regPaymentInfo, this.premiumToSend);
    //console.log(JSON.stringify(this.data));
    let signedFields = this.data.signed_field_names.split(",");
    var fieldValues = [];
    signedFields.forEach(item => {
      var tmp = item + "=" + (this.data[item]);
      fieldValues.push(tmp);
    });
    let key = this.regPaymentInfo.secret_key;
    //alert(key);
    var hash = CryptoJS.HmacSHA256(fieldValues.join(","), key);
    var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
    this.data.signature = hashInBase64;
    this.data.bill_to_address_line1 = this.quoteInfoData.address;
    this.data.bill_to_phone = this.quoteInfoData.mobileNo;
    this.data.bill_to_address_city = this.quoteInfoData.cityDesc;
    this.data.bill_to_address_state = "DU";
    this.data.bill_to_surname = "QIC";
    this.data.bill_to_address_country = "AE";
    this.data.bill_to_address_postal_code = this.quoteInfoData.poBox;
    this.data.org_id = this.regPaymentInfo.org_id;
    this.data.bill_to_forename = this.quoteInfoData.insName;
    this.data.bill_to_email = this.quoteInfoData.emailId;
    //this.paymentService.setPaymentInformation = this.data
    // service call to get the payment information
    //this.data = this.paymentService.getPaymentInformation;


    
    console.log(JSON.stringify(this.data));
    this.controls = Object.keys(this.data).map((k) => {
      return { key: k, value: this.data[k] };
    });
  }*/

  /**
   * New PG code for CCAvenue
   */
  initPayment() {
    this.data = this.paymentService.newInitPayment(this.quoteInfoData, this.regPaymentInfo, this.premiumToSend);
    //console.log(JSON.stringify(this.data));
    //alert(key);
    this.data.billing_address = this.quoteInfoData.address;
    this.data.billing_tel = this.quoteInfoData.mobileNo;
    this.data.billing_city = this.quoteInfoData.cityDesc;
    this.data.billing_state = "DU";
    this.data.billing_name = this.quoteInfoData.insName;
    this.data.billing_country = "AE";
    this.data.billing_zip = this.quoteInfoData.poBox;
    this.data.billing_email = this.quoteInfoData.emailId;

    //this.paymentService.setPaymentInformation = this.data
    // service call to get the payment information
    //this.data = this.paymentService.getPaymentInformation;



    console.log(JSON.stringify(this.data));
    this.controls = Object.keys(this.data).map((k) => {
      return { key: k, value: this.data[k] };
    });
  }
  getQuoteInfo() {
    if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == "/renew-policy") {
      let postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo - 1
      };
      this.insurancePlanService.getPolInfo(postData).subscribe((data: any) => {
        if (data.prodShortDesc == "TP") {
          this.isThirdPartySelected = true;
        } else {
          this.isThirdPartySelected = false;
        }
        this.policyNo = data.policyNo;
        this.quoteInfoData = data;
        this.setPersonalData();
        this.getTitleHeading();
        if (this.quoteInfoData.instYN == 1) {
          this.updateInstallmentFlag(this.quoteInfoData.instYN);
        } else {
          this.premiumToSend = this.premium;

          this.isInstallment = false;

          this.loaderService.display(false);
          this.checkBundledProduct();
        }
        this.checkIfPayInstallment();
        this.lobCodeValue = data.lobCode;
        this.insuranceTypeValue = data.insuranceType;
        this.setNavigationCss();
        //this.initPayment();
        this.setPaymentDefault();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    } else {
      let postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo
      };
      this.insurancePlanService.getQuoteInfo(postData).subscribe((data: any) => {

        if (data.lobCode && data.prodShortDesc == "HOME_CYL") {
          this.cycleInsurance = true;
        }
        if (data.prodShortDesc == "TP") {
          this.isThirdPartySelected = true;
        } else {
          this.isThirdPartySelected = false;
        }
        this.lobCodeValue = data.lobCode
        this.ifTelematics = data.telematicsYn;
        if (this.token && this.userId) {
          if (this.lobCodeValue == "01") {
            this.getCarInfo();
          } else if (this.lobCodeValue == "08") {
            this.travelInfoService.getQuoteTravelInfo(data).subscribe(
              res => { this.tripType = res.tripTypeDesc }, error => { this.loaderService.display(false) });
            this.getTravelerInfo();
          } else if (this.lobCodeValue == "04") {
            this.getHomeInfo();
          }
        }
        this.quoteInfoData = data;
        this.setPersonalData();
        this.getTitleHeading();
        this.instYnCheckForMailLink = this.quoteInfoData.instYN;
        if (this.instYnCheckForMailLink == 1 && this.mailLink) {
          this.toggle(1);
        }
        if (this.quoteInfoData.instYN == 1) {
          this.updateInstallmentFlag(this.quoteInfoData.instYN);
        } else {
          this.premiumToSend = this.premium;

          this.isInstallment = false;

          this.loaderService.display(false);
          this.checkBundledProduct();
        }
        this.checkIfPayInstallment();
        this.lobCodeValue = data.lobCode;
        this.insuranceTypeValue = data.insuranceType;
        ////////console.log("====================");
        ////////console.log(JSON.stringify(this.quoteInfoData));
        ////////console.log("====================");
        this.setNavigationCss();
        //this.initPayment();
        this.setPaymentDefault();
        this.setTermsAndConditionText();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    }

  }

  getCarInfo() {
    const params = { transId: this.transId, tranSrNo: this.tranSrNo };
    this.insurancePlanService.getQuoteVehInfo(params).subscribe(
      data => {
        this.vehicleInfoData = data;
        this.personalInfo = true;
        this.vehicleInfo = true;
        this.setHyphen();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  getTravelerInfo() {
    const params = { transId: this.transId, tranSrNo: this.tranSrNo };
    this.travelInfoService.getTravelerDetls(params).subscribe(
      data => {
        this.travelerData = data.travelerArray;
        this.quoteInfoData.insName = this.travelerData[0].trvlrName;
        this.personalInfo = true;
        this.travelerInfo = true;
        this.setHyphen();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  getHomeInfo() {
    const params = { transId: this.transId, tranSrNo: this.tranSrNo };
    this.homeInsurancePlanService.getQuoteHomeInfo(params).subscribe(
      data => {
        this.homeData = data;
        console.log(JSON.stringify(this.homeData));
        this.personalInfo = true;
        this.homeInfo = true;
        this.setHyphen();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  refreshValue(value: any): void {
    if (!this.checkEmptyObject(value)) {
      this.nationality_value = value;
      $("#selectNationality").removeClass("invalid").addClass("valid");
      $("#nationalityError").hide();
    } else {
      $("#selectNationality").removeClass("valid").addClass("invalid");
      $("#nationalityError").show();
    }
  }

  getBank(value: any): void {
    this.bank = value;
  }
  onDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.bundledTravelerDOB = event.target.value;
        }
      }
    }

  }
  dobChanged(event) {
    if (this.bundledTravelerDOB != undefined || this.bundledTravelerDOB == null) {
      this.showMsg = false;
    }
    if (event.epoc) {
      this.dob = event.epoc * 1000
      $("#dobDate").removeClass("invalid").addClass("valid");
      $("#dobError").hide();
    } else {
      $("dobDate").removeClass("valid").addClass("invalid");
      $("#dobError").show();
    }
  }
  getAgeValidate(dateString: any) {
    if (dateString == '' || dateString == undefined) {
      return false;
    } else {
      //console.log(dateString)
      //let dobOf:string = dateString.formatted;
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {
        if (dateString.date != undefined) {
          dateString = dateString.date.month + "/" + dateString.date.day + "/" + dateString.date.year;
          birthDate = new Date(dateString);
        } else {
          let parts = dateString.split('/');
          birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
        }


      }

      //const date = this.appUtilObj.getUTCDate(timestamp);
      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age < 18) {
        this.checkDate = true;
        return true;
      } else if (age > 70) {
        this.checkDate = true;
        return true;
      }
      else {
        this.checkDate = false;
        return false;
      }

    }

  }

  submitTravelForm(homeForm, travelForm) {
    this.loaderService.display(true)
    let insName = this.bundledTravelerName;
    let relation = this.bundledTravelerRelation;
    let gender = this.bundledTravelerGender;
    let passport = this.bundledTravelerPassport;

    if (this.bundledTravelerDOB.date == undefined) {
      let temp = this.bundledTravelerDOB.split("/");

      this.bundledTravelerDOB = { date: { year: temp[2], month: temp[1], day: temp[0] } }
    }
    let date = this.bundledTravelerDOB.date;
    let stringDob = date.year + '/' + date.month + '/' + date.day;
    let dob = new Date(stringDob).getTime();
    let nationality = this.bundledTravelerNationality[0].id;
    let travelerData = { transId: this.bundledTravelTransId, tranSrNo: this.bundledTravelTranSrNo, trvlrName: insName, relation: relation, gender: gender, passptNo: passport, dob: dob, nationality: nationality, userId: 'online', category: '8003' }
    this.travelerDetailArray.push(travelerData)
    this.travelInfoService.insTravelerDetls(this.travelerDetailArray).subscribe(
      res => {
        if (res.respCode == "2000") {
          if (homeForm) {
            this.loaderService.display(false)
            this.submitHomeForm()
          } else {
            this.submit();
          }
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      }
    )
  }

  submitHomeForm() {
    this.loaderService.display(true)
    let buildingAddress = this.bundledHomeAddress;
    let poBox = this.bundledHomePoBox;
    let city = this.bundledHomeCity[0].id;
    let zoneArea = this.bundledHomeZone;
    let street = this.bundledHomeStreet;
    let homeData = {
      transId: this.bundledHomeTransId, tranSrNo: this.bundledHomeTranSrNo,
      address: buildingAddress, poBox: poBox, city: city, zoneArea: zoneArea,
      streetBlock: street, mapId: "HOME_RISK_SCR_2"
    }
    this.homeInsurancePlanService.updateHomeInfo(homeData).subscribe(
      (res: any) => {
        if (res.respCode == "2000") {
          this.submit();
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      }
    )
  }

  checkTerms(event) {
    if (event) {
      this.checkboxVal = false;
    } else {
      this.checkboxVal = true;
    }
  }

  checkInstallmentTerms(event) {
    if (event) {
      this.termsCheckBox = false;
    } else {
      this.termsCheckBox = true;
    }
  }

  checkBundledForms() {
    this.loaderService.display(true);
    if (this.checkDate == true) {
      this.loaderService.display(false)
      return false;
    }
    let terms = document.getElementById('checkbox2')[0].checked;//$("#checkbox2")[0].checked;

    if (!this.isInstallment && this.showBundledProducts) {
      let homeForm = document.getElementById('product0')[0].checked;//$("#product0")[0].checked;
      let travelForm = document.getElementById('product1')[0].checked;//$("#product1")[0].checked;
      if (homeForm && travelForm) {
        if ($(".invalid").length > 0) {
          var error_inputs = $(".invalid").siblings(".alert-danger").show();
          this.loaderService.display(false);
          return false;
        }
      } else if (homeForm) {
        if ($(".invalid").length > 0) {
          var error_inputs = $(".invalid").siblings(".alert-danger").show();
          this.loaderService.display(false);
          return false;
        }
      } else if (travelForm) {
        if ($(".invalid").length > 0) {
          var error_inputs = $(".invalid").siblings(".alert-danger").show();
          this.loaderService.display(false);
          return false;
        }
      }
      if (!terms) {
        this.loaderService.display(false);
        return this.checkboxVal = true;
      }
      // this.loaderService.display(true);
      // setTimeout(function() {
      if (homeForm && travelForm && this.accept) {
        this.submitTravelForm(homeForm, travelForm);
        // this.submitHomeForm;
        // window.localStorage.clear();
        // $("#payment_confirmation")[0].submit()
        // this.loaderService.display(false);
      } else {
        if (travelForm && this.accept) {
          this.submitTravelForm(homeForm, travelForm);
          // window.localStorage.clear();
          // $("#payment_confirmation")[0].submit()
          // this.loaderService.display(false);
        } else if (homeForm && this.accept) {
          this.submitHomeForm();
          // window.localStorage.clear();
          // $("#payment_confirmation")[0].submit()
          // this.loaderService.display(false);
        } else {

          this.submit();
          // this.loaderService.display(false);
        }
      }
      // }, 5000)
    } else {
      this.loaderService.display(true)

      if (this.isInstallment) {
        let installmentTerms = document.getElementById('installmentTerms')[0].checked; //$("#installmentTerms")[0].checked;
        if (!installmentTerms) {
          this.loaderService.display(false)
          return this.termsCheckBox = true;
        }
        if (!terms) {
          this.loaderService.display(false)
          return this.checkboxVal = true;
        }
        //this.regPayment();
        this.submit();
      } else {
        if (!terms) {
          this.loaderService.display(false)
          return this.checkboxVal = true;
        }
        //this.regPayment();
        this.submit();
      }
    }
  }

  setNavigationCss() {
    if (this.lobCodeValue == '01') {
      if (this.isThirdPartySelected) {
        this.processRowClass = "process-two-tab process-row nav nav-tabs";
      } else {
        this.processRowClass = "process-three-tab process-row nav nav-tabs";
      }
    } else if (this.lobCodeValue == '04') {
      if (this.displaySecondDiv == 'true') {
        this.processRowClass = "process-three-tab process-row nav nav-tabs";
      } else {
        this.processRowClass = "process-two-tab process-row nav nav-tabs";
      }
      this.applyProcessFourTab = "process";
    } else if (this.lobCodeValue == '08' && this.insuranceTypeValue != 'PAB') {
      this.processRowClass = "process-two-tab process-row nav nav-tabs";
      this.applyProcessFourTab = "process";
    } else if (this.lobCodeValue == '08' && this.insuranceTypeValue == 'PAB') {
      this.processRowClass = "process-two-tab process-row nav nav-tabs";
    }
    this.loaderService.display(false);
    $('.box-shadow').show();
    $('.container').show();
  }

  setPaymentDefault() {
    if (this.quoteInfoData.emailId == null) this.quoteInfoData.emailId = "qicdubai@qici.com.qa";
    if (this.quoteInfoData.address == null) this.quoteInfoData.address = "Al Dana Centre Building";
    if (this.quoteInfoData.mobileNo == null) this.quoteInfoData.mobileNo = "42224045";
    if (this.quoteInfoData.cityDesc == null) this.quoteInfoData.cityDesc = "Dubai";
    if (this.quoteInfoData.poBox == null) this.quoteInfoData.poBox = "4066";
    //////////console.log("=================default===============");
    //////////console.log(JSON.stringify(this.quoteInfoData));
    //////////console.log("=================default===============");
  }
  checkIfPayInstallment() {
    var installmentData = {
      "portal": "D", "transId": this.transId, "tranSrNo": this.tranSrNo,
      "schCode": this.quoteInfoData.schCode, "prodCode": this.quoteInfoData.prodCode
    };
    if (this.quoteInfoData.prodShortDesc == 'OD') {
      this.insurancePlanService.getInstallationApplicable(JSON.stringify(installmentData)).subscribe((response: any) => {
        if (response.option == 1) {
          this.showInstallment = true;
          //this.isInstallment = true;
        } else if (response.option == 0) {
          this.showInstallment = false;
          //this.isInstallment = false;
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    }
  }

  //method to update if installments selected by user or not
  updateInstallmentFlag(installApplicable: any) {
    this.loaderService.display(true);
    var updateInstallmentFlagData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "instlYn": installApplicable };
    this.insurancePlanService.updateInstallmentFlag(JSON.stringify(updateInstallmentFlagData)).subscribe((response: any) => {
      //console.log(response);
      if (response.respCode == "2000") {
        if (installApplicable == true) {
          this.getInstallments();

          this.isInstallment = true;
          if (this.bundledHomePremium && this.displayHomeForm) {
            this.premium -= this.bundledHomePremium
            this.bundledHomePremium = "";
          }
          if (this.bundledTravelPremium && this.displayTravelForm) {
            this.premium -= this.bundledTravelPremium
            this.bundledTravelPremium = "";
          }
          this.showHome = false;
          this.showTravel = false;
          this.displayTravelForm = false;
          this.displayHomeForm = false;
          this.products.splice(0, this.products.length)
          this.bundledSumIncMandTravel = [];
          this.bundledSumIncMandHome = [];
          this.bundledHomeObject = {};
          this.bundledTravelObject = {};
        } else {
          this.premiumToSend = this.premium
          this.isInstallment = false;
          this.getBundledProducts(this.transId, this.tranSrNo)
        }
        this.loaderService.display(false);
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  //method to get the installments for the schemes
  getInstallments() {
    let getInstallmentData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    console.log(JSON.stringify(getInstallmentData));

    this.insurancePlanService.displayInstallments(getInstallmentData).subscribe(
      (response: any) => {
        if (response.respCode == "2000") {
          this.installmentList = response.instArray;
          for (let inst in this.installmentList) {
            if (this.installmentList[inst].instNo == 1) {
              this.premiumToSend = this.installmentList[inst].premium;
              break;
            }
          }

          this.isInstallment = true;
          this.toggleVal = 1;
          $('#inslDiv').show(300);

        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });

    // this.insurancePlanService.getInstallments(getInstallmentData).subscribe(response => {
    //   ////console.log(response);
    //   if (response.respCode == "2000") {
    //     for (let i = 0; i < response.schemesInstallmentsList.length; i++) {
    //       if (response.schemesInstallmentsList[i].schemeCode == this.quoteInfoData.schCode) {
    //         this.installmentList = response.schemesInstallmentsList[i].Installments;
    //         this.loaderService.display(false);
    //       }
    //     }
    //     this.premiumToSend = this.installmentList[0].premium;
    //     this.isInstallment = true;
    //     this.toggleVal = 1;
    //     $('#inslDiv').show(300);
    //
    //   }
    // }, error => {
    //   this.loaderService.display(false);
    // });
  }


  regPayment() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      premium: this.premiumToSend,
      paymtType: "CC",
      userId: ApiConstants.USER_ID
    };
    //console.log(JSON.stringify(postData))
    this.paymentService.registerPayment(postData).subscribe(data => {
      this.regPaymentInfo = data;
      this.pgReqUrl = "./ccavRequestHandler.jsp"//this.regPaymentInfo.pgReqUrl;
      this.initPayment();
    }, error => {
      try {
        let err = error.json();
        if (err.respCode == "6001") {
          let obj = {
            errMsg: err.errMessage
          }
          this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
        } else {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        }
        this.loaderService.display(false);
      } catch (err) {
        this.loaderService.display(false);
      }
    })
  }
  getTitleHeading() {
    if (this.quoteInfoData.lobCode == '01' && this.quoteInfoData.prodShortDesc == 'OD') {
      this.title = 'Comprehensive Car Insurance';
      this.pdfUrl = './assets/policy-wordings-pdf/Comprehensive_Motor_Terms_And_Conditions.pdf';
    } else if (this.quoteInfoData.lobCode == '01' && this.quoteInfoData.prodShortDesc == 'TP') {
      this.title = 'Third Party Insurance';
      this.pdfUrl = './assets/policy-wordings-pdf/Third_Party_Liability.pdf';
    } else if (this.quoteInfoData.lobCode == '04' && !this.cycleInsurance) {
      this.title = 'Home Contents Insurance';
      this.pdfUrl = './assets/policy-wordings-pdf/Home_Terms_And_ConditionsMAF.pdf';
    } else if (this.quoteInfoData.lobCode == '04' && this.cycleInsurance) {
      this.title = 'Cycle Insurance';
      this.pdfUrl = './assets/policy-wordings-pdf/Cycle_Terms_And_Conditions.pdf';
    } else if (this.quoteInfoData.lobCode == '08' && this.quoteInfoData.prodShortDesc == 'PAB') {
      this.title = 'PAB Insurance';
      this.pdfUrl = './assets/policy-wordings-pdf/PA_Policy_Wording_and_Exclusions.pdf';
    } else {
      this.title = 'Travel Insurance';
      this.pdfUrl = './assets/policy-wordings-pdf/Travel_Terms_And_Conditions.pdf';
    }

    if (this.renewPolicy) {
      this.titleMsg = 'Policy: ' + this.policyNo + ' is now ready for renewal';
    } else {
      this.titleMsg = 'Quote: ' + this.quoteNo + ' is now ready for purchase';
    }

  }
  openPdf() {
    window.open(this.pdfUrl, "_blank");
  }
  openTelematicsPdf() {
    var telematicsPDFUrl = "./assets/policy-wordings-pdf/Telematics_Terms_Condition.pdf";
    window.open(telematicsPDFUrl, "_blank");
  }
  setHyphen() {
    setTimeout(() => {
      for (var i = 0; i < $('.gray-value').length; i++) {
        if ($('.gray-value')[i].textContent == '') {
          $('.gray-value')[i].textContent = '-'
        }
      }
    }, 500)
  }
  submit() {
    if (this.accept == true) {
      this.pixelService.pixelFireValue('Universal');
      this.pixelService.pixelFireValue('7');
      this.regPayment();
      setTimeout(() => {
        console.log('redirecting......');
        window.localStorage.clear();
        document.getElementById('payment_confirmation')[0].onsubmit(true);
        // $("#payment_confirmation")[0].submit();
      }, 5000);
    } else {
      this.checkAcceptTermsCondition();
    }
  }
  setPersonalData() {
    this.personalInformation["email"] = this.quoteInfoData.emailId;
    this.personalInformation["address"] = this.quoteInfoData.address;
    this.personalInformation["mobile"] = this.quoteInfoData.mobileNo;
    this.personalInformation["cityDesc"] = this.quoteInfoData.cityDesc;
    this.personalInformation["poBox"] = this.quoteInfoData.poBox;
  }

  addRemoveValidation(value: any, target: any) {
    if (target == 'address') {
      if (value.length > 0) {
        $('#buildError').css('display', 'none');
        $('#address').removeClass("invalid").addClass("valid");
      } else {
        $('#buildError').css('display', 'block');
        $('#address').removeClass("valid").addClass("invalid");
      }
    }
    if (target == 'street') {
      if (value != '') {
        $('#streetError').css('display', 'none');
        $('#street').removeClass("invalid").addClass("valid");
      } else {
        $('#streetError').css('display', 'block');
        $('#street').removeClass("valid").addClass("invalid");
      }
    }
  }

  checkAcceptTermsCondition() {
    this.loaderService.display(false);
    if (this.accept == true) {
      this.showModal = false;
      this.submit();
    } else {
      this.showModal = true;
    }

  }
  setTermsAndConditionText() {
    let dataToSend = { "transId": this.quoteInfoData.transId, "tranSrNo": this.quoteInfoData.tranSrNo, "prodCode": this.quoteInfoData.prodCode, "schCode": this.quoteInfoData.schCode };
    this.insurancePlanService.getPaymentOptions(dataToSend).subscribe((result: any) => {
      this.termsAndConditionText = result.payOptsArray[0].paymCond;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    })
    //this.termsAndConditionTex = this.quoteInfoData.
  }
  hideModal() {
    this.accept = false;
    setTimeout(() => this.showModal = false, 300);
  }
  acceptedTermCondition() {
    this.accept = true;
    this.checkBundledForms();
    this.loaderService.display(true);
  }

  openCoverPdf(coverCode) {
    this.loaderService.display(true);
    let params = {
      "coverCode": coverCode
    }
    this.insurancePlanService.getCoverDocUrl(params);
    this.loaderService.display(false);
  }
}
