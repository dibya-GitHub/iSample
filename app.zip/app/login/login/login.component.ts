import { Component, OnInit } from '@angular/core';
import { Login } from '../classes/login';
import { Router } from '@angular/router';
import { Meta, Title } from '@angular/platform-browser';
import { DataService } from 'src/shared/services/data.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  login: Login = new Login()

  constructor(
    private meta: Meta,
    private router: Router,
    private data: DataService,
    private titleService: Title
  ) {
    this.titleService.setTitle('Login | i-Insured Insurance Company Dubai, UAE');
    this.meta.addTag({ name: 'description', content: 'Welcome to i-Insured online service, Get started by logging in and explore the plethora of opportunities offered by I-Insured.' });
    this.meta.addTag({ name: 'keywords', content: 'dubai insurance, best car insurance policy, qic home contents insurance, qic travel insurance, qic insurance, insurance companies in dubai' });
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  saveUser() {
    window.localStorage.setItem('userDetails', JSON.stringify(this.login))
    this.data.alert("login", true);
    this.data.alert("userLogin", true);
    this.router.navigate(["my-qic"]);
  }
}
