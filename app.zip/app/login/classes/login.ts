export class Login {
  name: string;
  civilId: string;
  mobileNo: string;
  emailId: string;
}
