import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from './../shared.module';
import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login/login.component';


@NgModule({
    schemas: [
        CUSTOM_ELEMENTS_SCHEMA
    ],
    declarations: [
        LoginComponent,
    ],
    imports: [
        FormsModule,
        ReactiveFormsModule,
        LoginRoutingModule,
        CommonModule,
        SharedModule,
    ],
})

export class LoginModule { }