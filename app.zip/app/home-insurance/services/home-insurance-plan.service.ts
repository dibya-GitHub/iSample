import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';

@Injectable({
  providedIn: 'root'
})
export class HomeInsurancePlanService {

  public requestOption;
  public baseUrl = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  updateHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_HOME_INFO_URL, body, this.requestOption);
  }

  GetApplicationParameter(refType: any): Observable<any> {
    const postData = {
      paraType: refType
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_PARAM, postData, this.requestOption);
  }
  updatePolicyDuration(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_POLICY_DURATION, body, this.requestOption);
  }
  getQuoteHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_HOME_INFO, body, this.requestOption);
  }
  getPolicyHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_HOME_INFO, body, this.requestOption);
  }
  insContentDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_CONTENT_DETAILS, body, this.requestOption);
  }
  getContentDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_CONTENT_DETAILS, body, this.requestOption);
  }
  insServantDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_SERVENT_DETAILS, body, this.requestOption);
  }
  getServantDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_SERVENT_DETAILS, body, this.requestOption);
  }
  getHomeConentServantInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_HOME_CONTENT_SERVENT_INFO, body, this.requestOption);
  }
}
