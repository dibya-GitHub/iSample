import { TestBed, inject } from '@angular/core/testing';

import { HomeInsurancePlanService } from './home-insurance-plan.service';

describe('HomeInsurancePlanService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HomeInsurancePlanService]
    });
  });

  it('should be created', inject([HomeInsurancePlanService], (service: HomeInsurancePlanService) => {
    expect(service).toBeTruthy();
  }));
});
