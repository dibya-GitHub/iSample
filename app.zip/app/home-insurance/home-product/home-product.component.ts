import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { Meta, Title } from '@angular/platform-browser';
import { Router } from "@angular/router";

@Component({
  selector: 'app-home-product',
  templateUrl: './home-product.component.html',
  styleUrls: ['./home-product.component.scss'],
})
export class HomeProductComponent implements OnInit {
  constructor(
    private meta: Meta,
    private router: Router,
    private titleService: Title,
    ) {
    this.titleService.setTitle('Home Contents Insurance Dubai | Compare, Buy or Renew Home Insurance');
    this.meta.addTag({ name: 'description', content: 'Our Home Contents Insurance covers all the things that your landlord’s insurance does not. Contact i-Insured for the best home contents insurance in Dubai, UAE.' });
    this.meta.addTag({ name: 'keywords', content: 'home contents insurance, home contents insurance quotes, get home contents insurance, home contents insurance online, compare Home Contents Insurance, cheap home contents insurance' });
  }
  currentIndex: any = 1;
  selectedImageSrc = './assets/images/qic_campaign_car.png';
  title = "Fire And Theft Covered";
  subtitle = 'Protect your home against uncalled risks in simple steps';

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  ngOnInit() {
    this.initSlider()
    this.initSliderForMobile();
  }
  afterChange(event) {
    this.currentIndex = $('.insta-wp.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);

    });
  }
  initSlider() {
    var self = this;
    $(function () {
      $(".slick-dots button, .slick-next, .slick-prev, .triger-box").on("click", function () {
        // var title = $(".slick-current").find("h4").html();
        setTimeout(function () {
          var title = $(".slick-current").find("h4").attr("id")
          switch (title) {
            case "first":
              self.subtitle = 'Protect your home against uncalled risks in simple steps';
              break;
            case "second":
              self.subtitle = 'Delight yourself with an instant insurance with instant approvals';
              break;
            case "third":
              self.subtitle = 'Your home is your dearest investment. Cover it!';
              break;
            default:
              self.subtitle = 'Enjoy a complete peace of mind with an easy claim';
              break;
          }
        }, 500);
      });
    })
  }

  buildingCover = [
    {
      cover: 'Building cover for building owners',
      explanation: 'The building cover covers the building itself from fire, flood, storm, riot, etc',
      isincluded: 'Included in building cover policy'

    }
  ]
  homeCover = [
    {
      cover: 'Loss of or damage to contents',
      explanation: 'Covers contents inside the house that are accidentally broken or ruined',
      isincluded: 'Included'
    },
    {
      cover: 'Additional expense of alternative accommodation',
      explanation: 'Covers the additional expense by living somewhere else if the home is inhabitable due to an accident',
      isincluded: 'Included'
    },
    {
      cover: 'Loss of or damage to domestic servant’s property',
      explanation: 'Covers accidental damage caused to the personal belongings of the domestic servant',
      isincluded: 'Included'
    },
    {
      cover: 'Plumbing',
      explanation: 'QIC will send a plumber to perform emergency repairs to breakages in pipes',
      isincluded: 'Included'
    },
    {
      cover: 'Electrical repairs',
      explanation: 'QIC will send an electrician to perform emergency repairs to the electrical supply',
      isincluded: 'Included'
    },
    {
      cover: 'Locksmith',
      explanation: 'In cause of lost or stolen keys, QIC will send a locksmith to open the door to your home',
      isincluded: 'Included'
    },
    {
      cover: 'Air conditioning',
      explanation: 'QIC send a professional to repair broken AC units and leave a temporary unit if it’s impossible to fix the broken unit',
      isincluded: 'Included'
    },
    {
      cover: 'Visitor’s personal effects',
      explanation: 'Covers a visitor’s belongings that are lost or damaged during visit',
      isincluded: 'Included'
    },
    {
      cover: 'Liability to the landlord',
      explanation: 'Damage caused to the landlord’s belongings and / or to people employed by the landlord is covered',
      isincluded: 'Included'
    },
    {
      cover: 'Compensation of death / permanent disablement',
      explanation: 'QIC pays compensation if the policy holder, spouse, children and /domestic servant dies or is permanently disabled',
      isincluded: 'Optional'
    },
    {
      cover: 'All risks extension',
      explanation: 'Covers personal belongings with the insured when outside the home',
      isincluded: 'Optional'
    }

  ]

  listContent = [
    {
      heading: 'If your domestic servant gets seriously injured',
      description: 'A serious accident to your servant is expensive – you must cover repatriation costs and pay a sum if the servant is invalidated – this too is covered',
      icon: 'person-falling',
      alt: 'Domestic Servant'
    },
    {
      heading: 'Covers damage to your fridge or aircon',
      description: 'If your aircon unit stops working, we’ll send a professional to repair it – if we cannot repair, we’ll install a temporary AC unit at your place. Even food ruined due to a malfunctioning fridge is covered',
      icon: 'fridge',
      alt: 'Covers damage to your fridge or aircon'
    },
    {
      heading: 'House relocation costs',
      description: 'A fire, flood or similar may make it impossible for you to stay in your home – the Home Contents Insurance covers the costs of your alternative accommodation',
      icon: 'moving-truck',
      alt: 'House relocation costs'
    },
    {
      heading: 'Damage or theft to things when traveling',
      description: 'If your watch or jewelry is damaged or stolen outside your home, we cover that too! Your home contents insurance can cover valuables not covered by standard travel insurance',
      icon: 'thief',
      alt: 'Damage or theft to things when traveling'
    }
  ]
  listContent2 = [
    {
      heading: 'Sum insured',
      description: 'The total value of the contents that you want the insurance to cover – your final premium will depend on the size of the sum insured',
      icon: 'money-bag',
      alt: 'Sum insured'
    },
    {
      heading: 'Included perils',
      description: 'These are the calamities / accidents that are covered under the home contents insurance, i.e. fire, theft, flood, thunderstorm, vandalism etc',
      icon: 'whirlwind',
      alt: 'Included perils'
    },
    {
      heading: 'Your landlord will NOT cover',
      description: 'The insurance your landlord has covers the building and not your content, so an accident will leave you with costs to replace your own belongings',
      icon: 'no-sign',
      alt: 'Your landlord will NOT cover'
    }
  ]


  slideHighlights = {
    "slidesToShow": 4,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }

  slideThreeItems = {
    "slidesToShow": 3,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }

  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "draggable": false
  };

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }
  goToFaq() {
    let obj = {
      productType: "Home",
    }
    this.router.navigate(['faq'], { queryParams: obj, skipLocationChange: true });

  }

}
