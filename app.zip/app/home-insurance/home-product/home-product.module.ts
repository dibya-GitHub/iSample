import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from "../../shared.module";
import { HomeProductRoutingModule } from './home-product-routing.module';
import { HomeProductComponent } from './home-product.component';

@NgModule({
  declarations: [
    HomeProductComponent,
  ],
  imports: [
    HomeProductRoutingModule,
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    SlickCarouselModule
  ],
})

export class HomeProductModule { }