import { HomeProductComponent } from './home-product.component';
import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';



const homeProductRoutes: Routes = [
    { path: '', component: HomeProductComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(homeProductRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class HomeProductRoutingModule { }
