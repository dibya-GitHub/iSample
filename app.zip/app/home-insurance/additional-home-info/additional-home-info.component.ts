import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as $ from 'jquery';
import { TooltiptList } from "src/shared/tooltip-list";
import { ApiConstants } from '../../../shared/api-constants';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService as CommonService } from '../../../shared/services/insurance.service';
import { AdditionalHomeInfo } from '../interfaces/additional-home-info';
import { HomeInsurancePlanService } from '../services/home-insurance-plan.service';

@Component({
  selector: 'app-additional-home-info',
  templateUrl: './additional-home-info.component.html',
  styleUrls: ['./additional-home-info.component.scss']
})
export class AdditionalHomeInfoComponent implements OnInit {

  showMsg: boolean = false;
  public tootipMessage = new TooltiptList();
  date: Date = new Date();
  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));
  appUtilObj: AppUtil = new AppUtil();
  public startDate = { date: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() } };
  public myDatePickerOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
    disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };
  public myDatePickerOptionsDOB: IAngularMyDpOptions = {
    // other options...
    openSelectorTopOfInput: true,
    alignSelectorRight: true,
    showSelectorArrow: false,
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    }
  };
  public myDatePickerOptionsContractDesk: IAngularMyDpOptions = {
    openSelectorTopOfInput: true,
    showSelectorArrow: false,
    dateFormat: 'dd/mm/yyyy'
  };
  public myDatePickerOptionsContract: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy'
  };

  endDate: string;
  buildingAge: any = [];
  cityList: any = [];
  zoneList: any = [];
  streetList: any = [];
  bulTypeList: any = [];
  bankList: any = [];
  nationalityList: any = [];
  transId: any;
  tranSrNo: any;
  additionalHomeInfo: AdditionalHomeInfo = new AdditionalHomeInfo();
  policyHomeInfo: any;
  contentsList: any = [];
  addRowData: any = [];
  storeTmpRowData: any = [];
  index: any;
  contentsListSize: any;
  showPersnlblngsDiv = false;
  showDriverDetailsDiv = false;
  noOfDomstServDriv: any = [];
  postServentDetails: any = [];
  isSuccessful = false;
  quoteNo: any;
  setFieldDisabled = false;
  isHidden = false;
  isHomeContentDetailsAvailable: any;
  isServentDetailsAvailable: any;
  showHelperPersDiv = false;
  isSecondDivAvailable = false;
  isProceedNext = false;
  persBelHeading: any = '';
  helperHeading: any = '';
  selectedCity: Array<any>;
  selectedBank: Array<any>;
  selectedNationality: Array<any>;
  errorMsg: string = '';
  contentSumInsured: number;
  persBelTotalValue: number = 0;
  showTotalValError = false;
  disableAdd = false;
  isAdditionalDataSaved = false;
  backward: any;
  carTransId: any;
  lobCode: any;
  showDateMsgArr: any = [];
  showDateMsgArrContract: any = [];
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private homeInsurancePlanService: HomeInsurancePlanService,
    private commonService: CommonService,
    private loaderService: LoaderService
  ) {
    this.route.queryParams.subscribe(params => {
      this.transId = params['transId'];
      this.tranSrNo = params['tranSrNo'];
      this.quoteNo = params['quoteNo'];
      this.backward = params['backButton'];
      this.carTransId = params["carTransId"];
      this.lobCode = params["lobCode"]
      if (window.localStorage.getItem('additionalDataSaved') != undefined && window.localStorage.getItem('additionalDataSaved') != null && window.localStorage.getItem('additionalDataSaved') == 'true') {
        this.isAdditionalDataSaved = true;
      }
      if (window.localStorage.getItem('showHelperPersDiv') != undefined && window.localStorage.getItem('showHelperPersDiv') != null && window.localStorage.getItem('showHelperPersDiv') == 'true' && this.backward == 'true') {
        this.showHelperPersDiv = true;
        this.isProceedNext = true;
      }
      this.onDateChanged(this.startDate);
      let postData;
      const fnName = '';
      if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/renew-policy') {
        postData = {
          transId: this.transId,
          tranSrNo: this.tranSrNo - 1
        }
        this.isHidden = true;
        this.loaderService.display(true);
        this.homeInsurancePlanService.getPolicyHomeInfo(postData).subscribe(data => {
          this.setInformation(data);
          this.loaderService.display(false);
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        });
      } else {
        postData = {
          transId: this.transId,
          tranSrNo: this.tranSrNo
        }
        this.loaderService.display(true);
        this.homeInsurancePlanService.getQuoteHomeInfo(postData).subscribe(data => {
          this.setInformation(data);
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        });
      }
    });
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });

  }
  ngOnInit() {
    this.index = 0;
    this.getCity();
    this.getNationality();
    this.getStreetBlock();
    this.getBuildingType();
    this.getBankOfFinance();
    this.getAgeOfBuilding();
    this.getDefaults();
    $('.container').hide();
  }
  setInformation(data: any) {
    this.getDefaults();
    this.additionalHomeInfo.address = data.address;
    if (data.city != null) {
      this.selectedCity = [{ id: data.city, text: data.cityDesc }]
      // this.additionalHomeInfo.city = data.city;
      this.getZoneArea(data.city);
    }
    this.additionalHomeInfo.poBox = data.poBox;
    if (data.bldngAge != null) {
      this.additionalHomeInfo.bldngAge = data.bldngAge
    }
    if (data.financedBank != null) {
      this.selectedBank = [{ id: data.financedBank, text: data.financedBankDesc }]
      // this.additionalHomeInfo.financedBank = data.financedBank
    }
    if (data.bldngType != null) {
      this.additionalHomeInfo.bldngType = data.bldngType
    }
    if (data.streetBlock != null) {
      this.additionalHomeInfo.streetBlock = data.streetBlock
    }
    if (data.zoneArea != null) {
      this.additionalHomeInfo.zoneArea = data.zoneArea
    }
    const postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.commonService.getQuotInfo(postData).subscribe((data: any) => {
      if (data.insName == 'GUEST') {
        this.additionalHomeInfo.insName = '';
      } else {
        this.additionalHomeInfo.insName = data.insName;
      }
      this.additionalHomeInfo.civilId = data.civilId;
      this.additionalHomeInfo.mobileNo = data.mobileNo;
      this.additionalHomeInfo.address = data.address;
      if (data.nationality != null) {
        this.selectedNationality = [{ id: data.nationality, text: data.nationalityDesc }]
        // this.additionalHomeInfo.nationality = data.nationality;
      }
      this.additionalHomeInfo.insNameAr = data.insNameAr;
      const date: Date = new Date(data.polStartDate);
      this.startDate = { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
      const endDate = new Date(data.polEndDate);
      this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
    this.policyHomeInfo = data;
    //this.additionalHomeInfo.address = data.address;
    this.homeInsurancePlanService.getHomeConentServantInfo(postData).subscribe((data: any) => {
      this.contentSumInsured = data.contentSumInsured;
      this.isHomeContentDetailsAvailable = +data.homeContents;
      this.isServentDetailsAvailable = +data.homeServants;
      if (this.isHomeContentDetailsAvailable == 1) {
        this.commonService.getApplicationCodes('CONTENT_TYPE').subscribe((data: any) => {
          this.contentsList = data.appCodesArray;
          if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/renew-policy' || window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/retrieve-quote' || this.isAdditionalDataSaved) {
            const postData = {
              transId: this.transId,
              tranSrNo: this.tranSrNo
            }
            this.loaderService.display(true);
            this.homeInsurancePlanService.getContentDetls(postData).subscribe((data: any) => {
              for (let i = 0; i < data.contentDetails.length; i++) {
                let tmp;
                const val = data.contentDetails[i].contentType;
                for (let j = 0; j < this.contentsList.length; j++) {
                  if (this.contentsList[j].code === val) {
                    tmp = this.contentsList.splice(j, 1);
                  }
                }
                // if (data.contentDetails.length == i + 1) {
                //   this.contentsList.splice(0, 0, tmp[0]);
                //   tmp = this.contentsList;
                // }
                const tmpArr = {
                  contentList: tmp,
                  details: data.contentDetails[i].contentDetls,
                  value: data.contentDetails[i].value
                }
                this.addRowData.push(tmpArr);
                this.storeTmpRowData.push(tmp);
              }
              const tmpArr = {
                contentList: this.contentsList,
                details: '',
                value: ''
              }
              this.addRowData.push(tmpArr);
              this.removeRow(this.addRowData.length - 1);
              this.showPersnlblngsDiv = true;
              this.loaderService.display(false);
            }, error => {
              if (this.addRowData.length == 0) {
                const tmpArr = {
                  contentList: this.contentsList,
                  details: '',
                  value: ''
                }
                this.addRowData.push(tmpArr);
              }
              this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
              this.loaderService.display(false);
            });
            this.showPersnlblngsDiv = true;
          } else {
            this.showPersnlblngsDiv = true;
            const tmpArr = {
              contentList: this.contentsList,
              details: '',
              value: ''
            }
            this.addRowData.push(tmpArr);
          }
          this.contentsListSize = this.contentsList.length;
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        });
      }
      if (this.isServentDetailsAvailable > 0) {
        for (let i = 0; i < this.policyHomeInfo.noOfDomstServDriv; i++) {
          this.showDateMsgArr.push({ 'index': -1 })
          this.showDateMsgArrContract.push({ 'index': -1 })
          const data = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            servantName: '',
            civilId: '',
            dob: '',
            contractExpDt: '',
            userId: ApiConstants.USER_ID
          }
          this.noOfDomstServDriv.push(i);
          this.postServentDetails.push(data);
        }
        if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/renew-policy' || window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/retrieve-quote' || this.isAdditionalDataSaved) {
          const postData = {
            transId: this.transId,
            tranSrNo: this.tranSrNo
          }
          this.loaderService.display(true);
          this.homeInsurancePlanService.getServantDetls(postData).subscribe((data: any) => {
            console.log(JSON.stringify(data));
            this.noOfDomstServDriv = data.servantDetails;
            for (let i = 0; i < this.noOfDomstServDriv.length; i++) {
              if (data.servantDetails[i].contractExpDt != null && data.servantDetails[i].contractExpDt != '') {
                const contractDate: Date = new Date(data.servantDetails[i].contractExpDt);
                this.postServentDetails[i].contractExpDt = contractDate.getTime();
                this.noOfDomstServDriv[i].contractExpDt = { date: { year: contractDate.getFullYear(), month: contractDate.getMonth() + 1, day: contractDate.getDate() } }
              }
              if (data.servantDetails[i].dob != null && data.servantDetails[i].dob != '') {
                const date: Date = new Date(data.servantDetails[i].dob);
                this.postServentDetails[i].dob = date.getTime();
                this.noOfDomstServDriv[i].dob = { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } }
              }
              this.postServentDetails[i].servantName = data.servantDetails[i].servantName;
              this.postServentDetails[i].civilId = data.servantDetails[i].civilId;
            }
            this.loaderService.display(false);
          }, error => {
            this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
            this.loaderService.display(false);
          });
        }
        this.showDriverDetailsDiv = true;
        this.loaderService.display(false);
        $('.container').show();
        ////console.log(JSON.stringify(this.noOfDomstServDriv))
        //alert(this.showDriverDetailsDiv)
      } else {
        this.loaderService.display(false);
      }
      if (this.isHomeContentDetailsAvailable == 1 && this.isServentDetailsAvailable > 0) {
        this.persBelHeading = 'Personal Belongings';
        this.helperHeading = '& Helper';
        this.isSecondDivAvailable = true;
        $('.container').show();
      } else if (this.isHomeContentDetailsAvailable == 1 || this.isServentDetailsAvailable > 0) {
        if (this.isHomeContentDetailsAvailable == 1) {
          this.persBelHeading = 'Personal Belongings';
        } else {
          this.helperHeading = 'Helper';
        }
        this.isSecondDivAvailable = true;
        $('.container').show();
        this.loaderService.display(false);
      } else {
        this.isSecondDivAvailable = false;
        $('.container').show();
        this.loaderService.display(false);
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
      $('.container').show();
    });
    //this.loaderService.display(false);

  }
  getCity() {
    this.commonService.getApplicationRefCodes('STATE', '002').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // const tmpArr = data.appCodesArray.reverse(); ;
      this.cityList = this.appUtilObj.sortedArray(arr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getZoneArea(id) {
    this.commonService.getApplicationRefCodes('ZONE_AREA', id).subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.zoneList = this.appUtilObj.sortedArray(tmpArr);
    }, error => {
      this.zoneList = [];
      this.additionalHomeInfo.zoneArea = '';
      //this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getStreetBlock() {
    this.commonService.getApplicationCodes('STREET_BLOCK').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();;
      this.streetList = this.appUtilObj.sortedArray(tmpArr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getBuildingType() {
    this.commonService.getApplicationCodes('BUILDING_TYP').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();;
      this.bulTypeList = this.appUtilObj.sortedArray(tmpArr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getAgeOfBuilding() {
    for (let i = 1; i <= 11; i++) {
      if (i == 11) {
        this.buildingAge.push('Above 10 Years');
        break;
      }
      this.buildingAge.push(i);
    }
  }
  getBankOfFinance() {
    this.commonService.getApplicationCodes('BANK').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // const tmpArr = data.appCodesArray.reverse(); ;
      this.bankList = this.appUtilObj.sortedArray(arr);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  getNationality() {
    this.commonService.getApplicationCodes('NATIONALITY').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // const tmpArr = data.appCodesArray;
      let sortedArr = this.sortNationality(arr);
      this.nationalityList = sortedArr;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  getDefaults() {
    this.additionalHomeInfo.city = '';
    this.additionalHomeInfo.zoneArea = '';
    this.additionalHomeInfo.bldngAge = '';
    this.additionalHomeInfo.bldngType = '';
    // this.additionalHomeInfo.nationality = '';
    this.additionalHomeInfo.streetBlock = '';
    this.additionalHomeInfo.financedBank = '';
  }

  onDateChanged(event) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsg = false;
    }
    ////console.log('onDateChanged(): ', event.date, ' - jsdate: ', new Date(event.jsdate).toLocaleDateString(), ' - formatted: ', event.formatted, ' - epoc timestamp: ', event.epoc);
    if (this.startDate == null) {
      this.startDate = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    } else {
      if (this.startDate.date == undefined) {
        let temp: any = this.startDate;
        const stringDate = temp.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];

        let date = new Date(newDate);
        this.startDate = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      this.startDate.date = event.date;
    }
    const timestamp = new Date(event.epoc * 1000).getTime();
    console.log('1 : ' + timestamp);
    if (timestamp == 0) {
      this.endDate = '';
    } else {
      const postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        polStartDate: this.appUtilObj.getUTCDate(timestamp)
      }
      console.log(JSON.stringify(postData));
      if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) != '/renew-policy') {
        this.homeInsurancePlanService.updatePolicyDuration(postData).subscribe((data: any) => {
          //alert(JSON.stringify(data));
          //this.endDate = new Date(data.polEndDate).toLocaleDateString();
          let endDate = new Date(data.polEndDate);
          this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
        })
      }
    }
  }
  addRow() {
    const tmpAddRowData = this.addRowData;
    if (this.index == 0)
      this.storeTmpRowData.push(this.contentsList.splice(0, 1));
    else
      this.storeTmpRowData.push(this.contentsList.splice(this.index, 1));
    //console.log(JSON.stringify(this.storeTmpRowData));
    const tmpArr = {
      contentList: this.contentsList,
      details: '',
      value: ''
    }
    this.addRowData = [];
    for (let i = 0; i < this.storeTmpRowData.length; i++) {
      try {
        const data = {
          contentList: this.storeTmpRowData[i],
          details: tmpAddRowData[i].details,
          value: tmpAddRowData[i].value,
        }
        this.addRowData.push(data);
      } catch (error) {
        alert(error);
      }
    }
    this.addRowData.push(tmpArr);
    this.index = 0;
    if (this.contentsListSize == this.addRowData.length) {
      this.disableAdd = true;
      return false;
    }
  }
  removeRow(index: number) {
    this.disableAdd = false;
    let tmpVal = this.addRowData[index].value;
    if (this.addRowData[index].value == '' || null == this.addRowData[index].value) {
      tmpVal = 0;
    }
    this.persBelTotalValue = this.persBelTotalValue - tmpVal;
    if (this.persBelTotalValue <= this.contentSumInsured) {
      this.showTotalValError = false;
    }
    let pushData;
    if (index == 1 && this.addRowData.length == 2) {
      this.storeTmpRowData.splice(index, 1);
      const data = this.addRowData[0].contentList[0];
      this.contentsList.splice(0, 0, data);
      this.addRowData.splice(index, 1);
      this.storeTmpRowData = [];
    } else {
      if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/home-insurance' || index == 0) {
        this.addRowData.splice(index, 1)
        pushData = this.storeTmpRowData.splice(index, 1);
        this.contentsList.push((pushData[0])[0]);
      } else {
        let data;
        if (index == this.addRowData.length - 1) {
          data = this.addRowData[index - 1].contentList[0];
          this.contentsList.splice(0, 0, data);
          this.storeTmpRowData.splice(index - 1, 1);
        } else {
          data = this.addRowData[index].contentList[0];
          this.contentsList.push(data);
          this.storeTmpRowData.splice(index, 1);
        }
        this.addRowData.splice(index, 1);
      }
    }
    //////console.log(this.addRowData);
    this.addRowData[this.addRowData.length - 1].contentList = this.contentsList;
  }
  perBelonSelect(code: any, i: any) {
    let index = -1;
    const val = code;
    const filteredObj = this.contentsList.find(function (item, i) {
      if (item.code === val) {
        index = i;
        return i;
      }
    });
    // if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) != '/renew-policy' && window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) != '/retrieve-quote') {
    //   const tmpData = this.contentsList.filter(data => data.code === code);
    //   this.addRowData[i].contentList = [];
    //   this.addRowData[i].contentList.push(tmpData[0]);
    // }
    //this.storeTmpRowData = this.addRowData;
    this.index = index;
  }
  setServentDetails(value: any, target: any, index: any) {
    if (target.indexOf('name') > -1) {
      this.postServentDetails[index].servantName = value;
    } else if (target.indexOf('civilId') > -1) {
      this.postServentDetails[index].civilId = value;
    }
  }
  driverDetailChanged(event: any, target: any, index: any) {
    let date = '';
    let timestamp;
    if (event.epoc != 0) {
      timestamp = new Date(event.epoc * 1000);
      date = this.appUtilObj.getUTCDate(timestamp);
    }
    if (target.indexOf('contractExpDt') > -1) {
      if (this.postServentDetails[index].contractExpDt != undefined || this.postServentDetails[index].contractExpDt == null) {
        this.showDateMsgArrContract[index] = -1;
      }
      this.postServentDetails[index].contractExpDt = date;
    } else if (target.indexOf('dob') > -1) {
      if (this.postServentDetails[index].dob != undefined || this.postServentDetails[index].dob == null) {
        this.showDateMsgArr[index] = -1;
      }
      this.postServentDetails[index].dob = date;
    }

    ////console.log(this.postServentDetails);
  }
  setPersBelong(value: any, target: any, index: any) {
    if (target.indexOf('details') > -1) {
      this.addRowData[index].details = value;
    } else if (target.indexOf('value') > -1) {
      this.addRowData[index].value = value;
    }
    this.showTotalValError = false;
  }

  scrollTop() {
    window.scrollTo(0, 0);
  }

  updateUserData() {
    if ($('.alert.alert-danger')[0]) {
      return false;
    }
    this.additionalHomeInfo.transId = this.transId;
    this.additionalHomeInfo.tranSrNo = this.tranSrNo;
    if (this.selectedNationality != undefined) {
      this.additionalHomeInfo.nationality = this.selectedNationality[0].id;
    }
    if (this.selectedBank != undefined) {
      this.additionalHomeInfo.financedBank = this.selectedBank[0].id;
    }
    this.additionalHomeInfo.city = this.selectedCity[0].id;
    this.additionalHomeInfo.mapId = 'HOME_POL_SCR_2';
    this.commonService.updateInsuredInfo(this.additionalHomeInfo).subscribe(data => {
      //////console.log(JSON.stringify(data));
      this.additionalHomeInfo.mapId = 'HOME_RISK_SCR_2';
      //console.log(JSON.stringify(this.additionalHomeInfo));
      this.homeInsurancePlanService.updateHomeInfo(this.additionalHomeInfo).subscribe(data => {
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  insContentDetls() {
    if ($('.alert.alert-danger')[0]) {
      return false;
    }
    const postArr: any = [];
    ////console.log(this.addRowData);
    for (let i = 0; i < this.addRowData.length; i++) {
      const postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        userId: ApiConstants.USER_ID,
        contentType: '',
        contentDetls: '',
        value: ''
      };
      if (this.addRowData[i].value != '') {
        ////console.log(this.addRowData.length == i + 1);
        if (this.addRowData.length == i + 1) {
          postData.contentType = this.contentsList[this.index].code;
        } else {
          postData.contentType = this.addRowData[i].contentList[0].code;
        }
        postData.contentDetls = this.addRowData[i].details;
        postData.value = this.addRowData[i].value;
        postArr.push(postData);
      }
    }
    if (postArr.length > 0) {
      this.homeInsurancePlanService.insContentDetls(postArr).subscribe(data => {
        console.log(JSON.stringify(data));
        if (this.isServentDetailsAvailable > 0) {
          this.insServantDetls();
        } else {
          this.router.navigate(['upload-document'], { queryParams: { lobCode: ApiConstants.HOME_INSURANCE_LOBCODE, transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo, displaySecondDivision: this.isSecondDivAvailable, displayPersonalBelonging: this.isHomeContentDetailsAvailable, displayHelpers: this.isServentDetailsAvailable }, skipLocationChange: true });
        }
      })
    }
    this.loaderService.display(false);
  }
  insServantDetls() {
    const tmpSerPostData = [];
    console.log(this.postServentDetails);
    for (let i = 0; i < this.postServentDetails.length; i++) {
      if (this.postServentDetails[i].servantName.trim() != '' && this.postServentDetails[i].civilId.trim() != '') {
        tmpSerPostData.push(this.postServentDetails[i]);
      }
    }
    if (tmpSerPostData.length > 0) {
      this.homeInsurancePlanService.insServantDetls(tmpSerPostData).subscribe(data => {
        this.router.navigate(['upload-document'], { queryParams: { lobCode: ApiConstants.HOME_INSURANCE_LOBCODE, transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo, displaySecondDivision: this.isSecondDivAvailable, displayPersonalBelonging: this.isHomeContentDetailsAvailable, displayHelpers: this.isServentDetailsAvailable }, skipLocationChange: true });
      })
    }
    this.loaderService.display(false);
  }
  emailQuote() {
    const postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    //console.log("email quote : " + JSON.stringify(postData))
    this.commonService.emailQuote(postData).subscribe(data => {
      //console.log(data);
      this.isSuccessful = true;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  proceedNext() {
    this.loaderService.display(true);
    this.updateUserData();
    window.localStorage.setItem('additionalDataSaved', 'true');
    if (this.isServentDetailsAvailable > 0 || this.isHomeContentDetailsAvailable == 1) {
      this.showHelperPersDiv = true;
      this.isProceedNext = true;
      window.localStorage.setItem('showHelperPersDiv', 'true');
      setTimeout(() => {
        this.loaderService.display(false);
      }, 1000);
    } else {
      window.localStorage.setItem('additionalDataSaved', 'true');
      if (this.carTransId) {
        let obj = {
          transId: this.transId,
          tranSrNo: this.tranSrNo,
          quoteNo: this.quoteNo,
          lobCode: this.lobCode,
          bundleTransId: this.carTransId
        }
        this.router.navigate(['upload-document'], { queryParams: obj, skipLocationChange: true });
      } else {
        this.router.navigate(['upload-document'], { queryParams: { lobCode: ApiConstants.HOME_INSURANCE_LOBCODE, transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo, displaySecondDivision: this.isSecondDivAvailable, displayPersonalBelonging: this.isHomeContentDetailsAvailable, displayHelpers: this.isServentDetailsAvailable }, skipLocationChange: true });
      }
    }
  }
  updateOtherInfo() {
    if (this.isHomeContentDetailsAvailable == 1) {
      this.persBelTotalValue = 0;
      for (let i = 0; i < this.addRowData.length; i++) {
        if (this.addRowData[i].value != '') {
          let val: number = +this.addRowData[i].value;
          this.persBelTotalValue += val;
        }
      }
      if (this.persBelTotalValue > this.contentSumInsured) {
        this.showTotalValError = true;
        return false;
      } else {
        this.insContentDetls();
      }
    } else if (this.isServentDetailsAvailable > 0) {
      this.insServantDetls();
    }
  }
  backToDetails() {
    const obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
      domesticHelpers: this.policyHomeInfo.noOfDomstServDriv,
      carTransId: this.carTransId
    }
    this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
  }

  onDateInput(event, i) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showDateMsgArr[i] = i;
      } else {
        this.showDateMsgArr[i] = -1;
        if (event.target.value != '') {
          this.noOfDomstServDriv[i].dob = event.target.value;
        }
      }
    }

  }
  onDateInputContactExp(event, i) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showDateMsgArrContract[i] = i;
      } else {
        this.showDateMsgArrContract[i] = -1;
        if (event.target.value != '') {
          this.noOfDomstServDriv[i].contractExpDt = event.target.value;
        }
      }
    }

  }
  onDateInputOfStart(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          let temp: any = event.target.value;
          const stringDate = temp.split("/");
          const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];

          let date = new Date(newDate);
          this.startDate = {
            date: {
              year: date.getFullYear(),
              month: date.getMonth() + 1,
              day: date.getDate()
            }
          };
          //this.startDate = event.target.value;
        }
      }
    }

  }

}
