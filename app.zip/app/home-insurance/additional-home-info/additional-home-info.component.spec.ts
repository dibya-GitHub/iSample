import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalHomeInfoComponent } from './additional-home-info.component';

describe('AdditionalHomeInfoComponent', () => {
  let component: AdditionalHomeInfoComponent;
  let fixture: ComponentFixture<AdditionalHomeInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalHomeInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalHomeInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
