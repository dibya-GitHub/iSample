export class Home {
  CODE: string;
  DESC: string;
  VALUE: string;
  DESCAR?: string;
}
