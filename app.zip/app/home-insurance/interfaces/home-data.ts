import{ Home } from './home'

export interface HomeData {
  errMessage: string;
  respCode: string;
  homeDataArray: Array<Home>
}
