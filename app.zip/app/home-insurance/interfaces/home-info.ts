export class HomeInfo {
  transId: string;
  tranSrNo: string;
  userId: string;
  mapId: string;
  contentsVal: string;
  persnlblngsVal: string;
  noOfDomstServDriv: string;
  emailId: string;
  mobileNo: string;
  promoCode: string;
  buildingVal: string;
  constructor()
  { }
}
