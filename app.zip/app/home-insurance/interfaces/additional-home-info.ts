export class AdditionalHomeInfo {
  transId: number;
  tranSrNo: number;
  userId: string;
  mapId: string;
  startDate: Date;
  endDate: Date;
  address: string;
  buildAddress: string;
  poBox: string;
  city: any;
  zoneArea: string;
  streetBlock: string;
  bldngAge: string;
  bldngType: string;
  financedBank: any;
  insName: string;
  insNameAr: string;
  civilId: string;
  mobileNo: string;
  nationality: any;
  polHoldAddr: string;
  country: string;
}
