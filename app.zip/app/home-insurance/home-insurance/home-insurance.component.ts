import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { Router } from '@angular/router';
import { HomeInfo } from '../interfaces/home-info'
import { RecaptchaComponent } from 'ng-recaptcha';
import { HomeInsurancePlanService } from '../services/home-insurance-plan.service'
import { InsuranceService as CommonService } from '../../../shared/services/insurance.service';
import { ApiConstants } from '../../../shared/api-constants';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { AppUtil } from '../../../shared/app-util';
import { TooltiptList } from "src/shared/tooltip-list";
import { Meta, Title } from '@angular/platform-browser';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-home-insurance',
  templateUrl: './home-insurance.component.html',
  styleUrls: ['./home-insurance.component.scss'],
  providers: [CommonService]
})
export class HomeInsuranceComponent implements OnInit {
  @ViewChild('captcha') captcha: RecaptchaComponent;
  @ViewChildren('input') vc;
  homeInfo: HomeInfo = new HomeInfo();
  homeContentList: any = [];
  personalBelongingsList: any = [];
  domesticHelpersList: any = [];
  ip: any;
  errorMsg: string = '';
  appUtilObj: AppUtil = new AppUtil();
  captchaErr: any;
  quoteNo: string = '';
  promoCodeError: any;
  siteKey:any = environment.siteKey;
  public tootipMessage = new TooltiptList();
  constructor(
    private meta: Meta,
    private router: Router,
    private titleService: Title,
    private homeInsurancePlanService: HomeInsurancePlanService,
    private commonService: CommonService,
    private loaderService: LoaderService,
  ) {
    window.scrollTo(0, 0);

    this.titleService.setTitle('Get Home Insurance Quotes in Dubai, UAE | i-Insured');
    this.meta.addTag({ name: 'description', content: 'Compare and buy online home contents insurance in Dubai. Get free quotes and online support from i-Insured on home Insurance premium, benefits, renewal and claims.' });
    this.meta.addTag({ name: 'keywords', content: 'home contents insurance, home contents insurance quotes, get home contents insurance, home contents insurance online, compare Home Contents Insurance, cheap home contents insurance' });

    this.homeInfo.emailId = localStorage.getItem('emailIdVal');
    this.homeInfo.mobileNo = localStorage.getItem('mobileNoVal');
    this.homeInfo.noOfDomstServDriv = localStorage.getItem('domesticHelpersVal');
    this.homeInfo.contentsVal = localStorage.getItem('homeContentsVal');
    window.localStorage.removeItem('additionalDataSaved');
    window.localStorage.removeItem('showHelperPersDiv');
  }

  ngOnInit() {
    this.getHomeContent();
    this.getPersBelongings();
    this.getHelpers();
    this.getDefaults();
    this.commonService.getIPAddress().subscribe(data => {
      this.ip = data.ip;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }

  ngAfterViewInit() {
    //this.vc.first.nativeElement.focus();
  }
  
  getQuote() {
    // if (this.captcha.execute) {
    //   this.captchaErr = 'Please Validate Captcha';
    //   return false;
    // }
    this.loaderService.display(true);
    const postData = {
      lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
      portal: ApiConstants.PORTAL,
      location: ApiConstants.LOCATION,
      userId: ApiConstants.USER_ID,
      ipAddress: this.ip,
      promoCode: this.homeInfo.promoCode,
      polStartDate: new Date().getTime(),
      prodShortDesc: 'HOME'
    }
    this.commonService.createQuote(postData).subscribe(createQuoteResponse => {
      console.log('Create Quote');
      console.log(JSON.stringify(createQuoteResponse));
      this.homeInfo.transId = createQuoteResponse.transId;
      this.homeInfo.tranSrNo = createQuoteResponse.tranSrNo;
      this.quoteNo = createQuoteResponse.quoteNo;
      this.homeInfo.userId = ApiConstants.USER_ID;
      this.homeInfo.mapId = 'HOME_POL_SCR_1';
      this.commonService.updateInsuredInfo(this.homeInfo).subscribe(data => {
        console.log(JSON.stringify(data));
        this.homeInfo.mapId = 'HOME_RISK_SCR_1';
        this.homeInsurancePlanService.updateHomeInfo(this.homeInfo).subscribe(data => {
          console.log(JSON.stringify(data));
          const postData = {
            transId: this.homeInfo.transId,
            tranSrNo: this.homeInfo.tranSrNo,
            userId: ApiConstants.USER_ID,
            portal: ApiConstants.PORTAL,
            lobCode: ApiConstants.HOME_INSURANCE_LOBCODE
          }
          this.commonService.calculatePricing(postData).subscribe(data => {
            this.loaderService.display(false);
            const obj = {
              transId: this.homeInfo.transId,
              tranSrNo: this.homeInfo.tranSrNo,
              quoteNo: createQuoteResponse.quoteNo,
              lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
              domesticHelpers: this.homeInfo.noOfDomstServDriv
            }
            this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
          }, error => {
            //this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
            let obj ={
              quoteNo: this.quoteNo
            }
            this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
            this.loaderService.display(false);
          });
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        });
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
    }, error => {
      let err = error.json();
      if (err.respCode == "5005") {
        this.promoCodeError = err.errMessage;
      } else {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      }
      this.loaderService.display(false);
    });
  }
  getHomeContent() {
    this.homeInsurancePlanService.GetApplicationParameter('HOME_CONTENT').subscribe(data => {
      this.homeContentList = this.sortedArray(data.appParamsArray);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  getPersBelongings() {
    this.commonService.getApplicationCodes('HOM_PER_CONT').subscribe(data => {
      this.personalBelongingsList = data.appCodesArray.reverse();
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  getHelpers() {
    for (let i = 0; i <= 30; i++) {
      this.domesticHelpersList.push(i);
    }
  }
  getDefaults() {

    if (this.homeInfo.contentsVal != null && this.homeInfo.contentsVal != '') {
      console.log('value is available');
    } else {
      this.homeInfo.contentsVal = '';
    }

    if (this.homeInfo.noOfDomstServDriv != null && this.homeInfo.noOfDomstServDriv != '') {
      console.log('value is available');
    } else {
      this.homeInfo.noOfDomstServDriv = '';
    }

    if (this.homeInfo.emailId == 'undefined' || this.homeInfo.emailId == null) {
      console.log('value is undefined --');
      this.homeInfo.emailId = '';
    } else {
      console.log('value is available');
    }

    if (this.homeInfo.mobileNo == 'undefined' || this.homeInfo.mobileNo == null) {
      console.log('value is undefined --');
      this.homeInfo.mobileNo = '';
    } else {
      console.log('value is available');
    }

    //this.homeInfo.persnlblngsVal = '';
    this.homeInfo.promoCode = '';
    this.removeItems();

  }

  removeItems() {
    localStorage.removeItem('emailIdVal');
    localStorage.removeItem('mobileNoVal');
    localStorage.removeItem('domesticHelpersVal');
    localStorage.removeItem('homeContentsVal');
  }

  sortedArray(tmpArr: any) {
    return tmpArr.sort((d1, d2) => {
      const n1 = parseInt(d1.value);
      const n2 = parseInt(d2.value);
      if (n1 > n2) {
        return 1;
      }

      if (n1 < n2) {
        return -1;
      }
      return 0;
    });
  }
}
