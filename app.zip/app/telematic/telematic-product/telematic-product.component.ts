import { Component, OnInit } from '@angular/core';
import { DomSanitizer, Meta, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AppUtil } from 'src/shared/app-util';
import { LoaderService } from 'src/shared/loader-service/loader.service';

@Component({
  selector: 'app-telematic-product',
  templateUrl: './telematic-product.component.html',
  styleUrls: ['./telematic-product.component.scss']
})
export class TelematicProductComponent implements OnInit {
  currentIndex: any = 1;
  appUtilObj: AppUtil = new AppUtil();
  deviceInfo = null;
  visibleAnimate: boolean = false;
  showModal: boolean = false;
  recommendedVideosList: any = [];
  modalData: any = {
    id: "",
    name: "",
    videoUrl: "",
    imageUrl: "",
  };
  pdfUrl: string = './assets/policy-wordings-pdf/OSeven_Client App terms Mass Market-QIC_From OSeven - FINAL.pdf';
  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "draggable": false
  };

  //http://www.youtube.com/embed/M7lc1UVf-VE?controls=0&autopl=0

  videoArray = [
    {
      id: 0,
      name: "i-Insured video 1",
      videoUrl: "https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=1&rel=0",
      imageUrl: "./assets/images/safeDriver001.jpg",
      mobileVideoUrl: this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/XMHBVPL04WU?autoplay=0&rel=0')
    },
    {
      id: 1,
      name: "i-Insured  video 2",
      videoUrl: "https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=1&rel=0",
      imageUrl: "./assets/images/safeDriver001.jpg",
      mobileVideoUrl: this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=0&rel=0')
    },
    {
      id: 2,
      name: "i-Insured  video 3",
      videoUrl: "https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=1&rel=0",
      imageUrl: "./assets/images/safeDriver001.jpg",
      mobileVideoUrl: this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=0&rel=0')
    },
    {
      id: 3,
      name: "i-Insured  video 4",
      videoUrl: "https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=1&rel=0",
      imageUrl: "./assets/images/safeDriver001.jpg",
      mobileVideoUrl: this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=0&rel=0')
    },
    {
      id: 4,
      name: "i-Insured  video 5",
      videoUrl: "https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=1&rel=0",
      imageUrl: "./assets/images/safeDriver001.jpg",
      mobileVideoUrl: this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=0&rel=0')
    },
    {
      id: 5,
      name: "i-Insured  video 6",
      videoUrl: "https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=1&rel=0",
      imageUrl: "./assets/images/safeDriver001.jpg",
      mobileVideoUrl: this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/XMHBVPL04WU?controls=0&autoplay=0&rel=0')
    }
  ];

  //https://www.youtube.com/watch?v=XMHBVPL04WU&feature=youtu.be

  constructor(
    private meta: Meta,
    private router: Router,
    private titleService: Title,
    private sanitizer: DomSanitizer,
    private deviceService: DeviceDetectorService,
    private loaderService: LoaderService,
  ) {
    this.titleService.setTitle('Safe Driver');
    this.meta.addTag({ name: 'description', content: 'Safe Driver' });
    this.meta.addTag({ name: 'keywords', content: 'Safe Driver' });
    this.recommendedVideosList = [];
  }

  videoURL(url) {
    //console.log(url);
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  ngOnInit() {
    this.initSliderForMobile();
  }

  hideModal() {
    this.visibleAnimate = false;
    setTimeout(() => this.showModal = false, 300);
  }

  showVideoModal(data, event) {
    this.recommendedVideosList = [];
    event.preventDefault();
    this.loaderService.display(true);
    this.modalData = {
      id: data.id,
      name: data.name,
      videoUrl: data.videoUrl,
      imageUrl: data.imageUrl
    };
    $("#playerModal").attr('src', this.modalData.videoUrl);
    setTimeout(() => {
      this.visibleAnimate = true;
      this.showModal = true;
      this.loaderService.display(false);
      this.recommendedVideos();
    }, 500);
    setTimeout(() => {
      $('#popupVideo').trigger('resize');
    }, 1000);
  }



  recommendedVideos() {
    //this.recommendedVideosList = this.videoArray;
    var currentVideoIndex = this.modalData.id;
    var selectedVideo = this.videoArray.filter(function (el) {
      return el.id == currentVideoIndex;
    });
    var remainingVideo = this.videoArray.filter(function (el) {
      return el.id != currentVideoIndex;
    });
    this.recommendedVideosList = selectedVideo.concat(remainingVideo);
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
    this.deviceInfo = this.deviceService.getDeviceInfo();
    if (this.deviceInfo.browser == "ie") {
      $('#videoTag').css('transform', 'scale(1.35)');
    }
  }

  afterChange(event) {
    this.currentIndex = $('.insta-wp.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);
    });
  }

  slideThreeItems = {
    "slidesToShow": 4,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  };

  videoslideThreeItems = {
    "slidesToShow": 3,
    "slidesToScroll": 1,
    "infinite": false,
    "dots": true,
    "prevArrow": true,
    "nextArrow": true,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }
  videoslideThreeItemsPopup = {
    "slidesToShow": 4,
    "slidesToScroll": 1,
    "infinite": false,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }

  OnBuyAndSave() {
    this.router.navigate(['safe-driver']);
  }

  goToFaq() {
    let obj = {
      productType: "Telematics",
    }
    this.router.navigate(['faq'], { queryParams: obj, skipLocationChange: true });

  }
  openPdf() {
    window.open(this.pdfUrl, "_blank");
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 530 }, 500);
  }

}