import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TelematicProductComponent } from './telematic-product.component';

describe('TelematicProductComponent', () => {
  let component: TelematicProductComponent;
  let fixture: ComponentFixture<TelematicProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TelematicProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TelematicProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
