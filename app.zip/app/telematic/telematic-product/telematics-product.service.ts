import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiHeadersService } from 'src/shared/api-headers.service';
import { ApiUrls } from 'src/shared/api-urls';

@Injectable({
  providedIn: 'root'
})
export class TelematicsService {
  requestOption;
  baseUrl = environment.baseUrl.replace("qicservices", "telematics");
  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  getToken(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.VALIDATE_TOKEN, body, this.requestOption);
  }

  verifyTelematics(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.VERIFY_TELEMATICS, body, this.requestOption)
  }

  resetTelematics(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.RESET_PASSWORD, body, this.requestOption);
  }
}
