import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { TravelCampaignForm } from './classes/travel-campaign-form';
import * as $ from 'jquery';


@Component({
  selector: 'app-travel-campaign',
  templateUrl: './travel-campaign.component.html',
  styleUrls: ['./travel-campaign.component.scss']
})
export class TravelCampaignComponent implements OnInit {

  travelForm: TravelCampaignForm = new TravelCampaignForm();

  constructor(
    private router: Router, 
    private meta: Meta, 
    private titleService: Title) {
    this.titleService.setTitle('Pay Travel Insurance through Installment | Travel Insurance Quotes');
    this.meta.addTag({ name: 'description', content: 'Pay Travel Insurance through Installment, i-Insured provides travel insurance plans for travelers to ensure complete peace of mind while travelling.' });
    this.meta.addTag({ name: 'keywords', content: 'travel installment plans, travel insurance in dubai, travel insurance quotes, travel insurance in installments, easy travel installment, easy travel insurance' }); }

  ngOnInit() {

  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  submitForm(){
    window.localStorage.setItem('travelCampaignDetails', JSON.stringify(this.travelForm))
    this.router.navigate(['/travel-insurance'])
  }

  scrollDown() {
      $( 'body, html' ).animate({scrollTop:600}, 500);
  //  window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }

}
