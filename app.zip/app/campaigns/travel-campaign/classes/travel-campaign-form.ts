export class TravelCampaignForm {
  name: string;
  email: string;
  civilId: string;
  mobile: string;
}
