import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { SharedModule } from '../shared.module';
import { CampaignsRoutingModule } from './campaigns-routing.module';
import { CarCampaignComponent } from './car-campaign/car-campaign.component';
import { HomeCampaignComponent } from './home-campaign/home-campaign.component';
import { PABCampaignComponent } from './pab-campaign/pab-campaign.component';
import { TravelCampaignComponent } from './travel-campaign/travel-campaign.component';
@NgModule({
    schemas: [
        CUSTOM_ELEMENTS_SCHEMA
    ],
    declarations: [
        HomeCampaignComponent,
        CarCampaignComponent,
        PABCampaignComponent,
        TravelCampaignComponent
    ],
    imports: [
        // TooltipModule,
        CommonModule,
        // MyDatePickerModule,
        SharedModule,
        // DropdownModule,
        CampaignsRoutingModule,
        NgSelectModule,
        FormsModule,
        ReactiveFormsModule
    ],
})

export class CampaignsModule { }