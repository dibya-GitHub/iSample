export class CarCampaignForm {
  name: string;
  email: string;
  mobile: string;
  carValue: string;
  nationality: string;
  nationalityDesc: string;
  civilId: string;
}
