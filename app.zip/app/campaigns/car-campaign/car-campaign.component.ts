import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { DomSanitizer, Meta, SafeResourceUrl, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { InsuranceService } from 'src/shared/services/insurance.service';

@Component({
  selector: 'app-car-campaign',
  templateUrl: './car-campaign.component.html',
  styleUrls: ['./aos.css', './animation.css', './car-campaign.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CarCampaignComponent implements OnInit {

  name: string;
  video: any = { id: 'lsSElg0esZM' };
  baseUrl: string = 'https://www.youtube.com/embed/';
  url: SafeResourceUrl;
  carCampaignForm: UntypedFormGroup;
  public nationalities: any = [];
  public nationality: any = [];

  constructor(
    private fb: FormBuilder,
    private titleService: Title,
    private sanitizer: DomSanitizer,
    private router: Router,
    private insuranceService: InsuranceService,
    private meta: Meta,
  ) {
    this.titleService.setTitle('Pay In Installments Offer | i-Insured Insurance Dubai');
    this.meta.addTag({ name: 'description', content: 'Pay your car insurance the easy way!  With i-Insured flexible installment plan give your dream car the right insurance. Apply Now!' });
    this.meta.addTag({ name: 'keywords', content: 'At i-Insured, we make it easy for you to make insurance payment in installments. Visit our site to know more on installment payment offers and make your request by filling out the form provided.' });
    this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.baseUrl + this.video.id);
  }

  ngOnInit() {
    this.getNationality();
    this.initSliderForMobile();
    this.createContactForm();
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  createContactForm() {
    this.carCampaignForm = this.fb.group({
      name: [''],
      email: [''],
      mobile: [''],
      carValue: [''],
      nationality: [''],
      nationalityDesc: [''],
      civilId: [''],
    });
  }
  getNationality() {
    const param = { 'type': 'NATIONALITY' };
    this.insuranceService.getNationalityList(param).subscribe(nationality => {
      let arr = [];
      for (let i = 0; i < nationality.appCodesArray.length; i++) {
        let id = nationality.appCodesArray[i].code;
        let text = nationality.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      let sortedArr = this.sortNationality(arr);
      this.nationalities = sortedArr;
    }, error => {
    });
  }

  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true
  };
  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);

    });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  submitForm() {
    var carCampaign;
    if (this.nationality != 'undefined' && this.nationality.length > 0) {
      carCampaign.nationality = this.nationality[0].id;
      carCampaign.nationalityDesc = this.nationality[0].text
    }
    window.localStorage.setItem('carCampaignDetails', JSON.stringify(carCampaign))
    this.router.navigate(['/car-insurance']);
  }


  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }
}
