import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarCampaignComponent } from './car-campaign.component';

describe('CarCampaignComponent', () => {
  let component: CarCampaignComponent;
  let fixture: ComponentFixture<CarCampaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarCampaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
