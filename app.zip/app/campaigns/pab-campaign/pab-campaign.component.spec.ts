import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PABCampaignComponent } from './pab-campaign.component';

describe('PABCampaignComponent', () => {
  let component: PABCampaignComponent;
  let fixture: ComponentFixture<PABCampaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PABCampaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PABCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
