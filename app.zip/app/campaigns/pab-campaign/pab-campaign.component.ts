import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { AppUtil } from '../../../shared/app-util';
import { MonthlySalary } from '../../../shared/classes/monthly-salary';
import { PabInfo } from '../../pab-insuarance/classes/pab-info';
import { PabInsuranceService } from '../../pab-insuarance/services/pab-insuarance.service';

@Component({
  selector: 'app-pab-campaign',
  templateUrl: './pab-campaign.component.html',
  styleUrls: ['./pab-campaign.component.scss']
})
export class PABCampaignComponent implements OnInit {
  pabInfo: PabInfo = new PabInfo();
  public monthly_salaries: MonthlySalary[];
  appUtilObj: AppUtil = new AppUtil();
  errorMsg: string = '';
  constructor(
    private router: Router,
    private pabInsuranceService: PabInsuranceService,
    private meta: Meta,
    private titleService: Title) {
    this.titleService.setTitle('Pay Accident Insurance through Installment | Health Insurance Quotes');
    this.meta.addTag({ name: 'description', content: 'No need to worry about accident insurance premium, now pay for your mediclaim policy in easy installments from i-Insured.' });
    this.meta.addTag({ name: 'keywords', content: 'health installment plans, health insurance in dubai, health insurance quotes, health insurance in installments, easy health installment, easy health insurance' });
  }

  ngOnInit() {
    this.getMonthlySalary();
    this.pabInfo.monthlySalary = '';
  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //  window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }

  getMonthlySalary() {
    let salary_params = { 'type': 'PAB_SAL' };
    this.pabInsuranceService.getMonthlySalary(salary_params).subscribe(salary => {
      this.monthly_salaries = salary.appCodesArray;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
    });
  }

  goToPabPage() {
    localStorage.setItem("emailIdVal", this.pabInfo.emailId);
    localStorage.setItem("mobileNoVal", this.pabInfo.mobileNo);
    localStorage.setItem("monthlySalValue", this.pabInfo.monthlySalary);
    this.router.navigate(['/pab-insurance']);
  }

}
