import { CarCampaignComponent } from './car-campaign/car-campaign.component';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { HomeCampaignComponent } from './home-campaign/home-campaign.component';
import { PABCampaignComponent } from './pab-campaign/pab-campaign.component';
import { TravelCampaignComponent } from './travel-campaign/travel-campaign.component';

const campaignRoute: Routes=[
    { path: 'home', component: HomeCampaignComponent },
    { path: 'pab', component: PABCampaignComponent },
    { path: 'travel', component: TravelCampaignComponent},
    { path: 'car', component: CarCampaignComponent },
]
@NgModule({
    imports:[
        RouterModule.forChild(campaignRoute)
    ],
    exports:[RouterModule]
})
export class CampaignsRoutingModule{

}