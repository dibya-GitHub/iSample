import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { AppUtil } from '../../../shared/app-util';
import { HomeInfo } from '../../home-insurance/interfaces/home-info';
import { HomeInsurancePlanService } from '../../home-insurance/services/home-insurance-plan.service';
@Component({
  selector: 'app-home-campaign',
  templateUrl: './home-campaign.component.html',
  styleUrls: ['./home-campaign.component.scss']
})
export class HomeCampaignComponent implements OnInit {
  homeInfo: HomeInfo = new HomeInfo();
  homeContentList: any = [];
  appUtilObj: AppUtil = new AppUtil();
  errorMsg: string = '';
  domesticHelpersList: any = [];
  constructor(
    private router: Router,
    private homeInsurancePlanService: HomeInsurancePlanService,
    private meta: Meta,
    private titleService: Title) {
    this.titleService.setTitle('Pay Home Contents Insurance through Installment | Home Contents Insurance Quotes');
    this.meta.addTag({ name: 'description', content: 'Protect your home and belongings with i-Insured home contents insurance plan with competitive premiums, Pay Home Contents Insurance through easy Installment.' });
    this.meta.addTag({ name: 'keywords', content: 'home installment plans, home contents insurance in dubai, home contents insurance quotes, home contents insurance in installments, easy home installment, easy home contents insurance' });
  }

  ngOnInit() {
    this.getDefaults();
    this.getHomeContent();
    this.getHelpers();
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }

  getDefaults() {
    this.homeInfo.contentsVal = '';
    this.homeInfo.noOfDomstServDriv = '';
  }

  getHomeContent() {
    this.homeInsurancePlanService.GetApplicationParameter('HOME_CONTENT').subscribe(data => {
      this.homeContentList = this.sortedArray(data.appParamsArray);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
    });
  }

  getHelpers() {
    for (let i = 0; i <= 30; i++) {
      this.domesticHelpersList.push(i);
    }
  }

  goToHomePage() {
    localStorage.setItem("emailIdVal", this.homeInfo.emailId);
    localStorage.setItem("mobileNoVal", this.homeInfo.mobileNo);
    localStorage.setItem("homeContentsVal", this.homeInfo.contentsVal);
    localStorage.setItem("domesticHelpersVal", this.homeInfo.noOfDomstServDriv);
    this.router.navigate(['/home-insurance']);
  }

  sortedArray(tmpArr: any) {
    return tmpArr.sort((d1, d2) => {
      const n1 = parseInt(d1.value);
      const n2 = parseInt(d2.value);
      if (n1 > n2) {
        return 1;
      }

      if (n1 < n2) {
        return -1;
      }
      return 0;
    });
  }

}
