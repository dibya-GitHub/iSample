import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeCampaignComponent } from './home-campaign.component';

describe('HomeCampaignComponent', () => {
  let component: HomeCampaignComponent;
  let fixture: ComponentFixture<HomeCampaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeCampaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
