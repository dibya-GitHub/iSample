import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvantageClubComponent } from './advantage-club.component';

describe('AdvantageClubComponent', () => {
  let component: AdvantageClubComponent;
  let fixture: ComponentFixture<AdvantageClubComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvantageClubComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvantageClubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
