import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import * as $ from 'jquery';

@Component({
  selector: 'app-advantage-club',
  templateUrl: './advantage-club.component.html',
  styleUrls: ['./advantage-club.component.scss']
})
export class AdvantageClubComponent implements OnInit {

  constructor(private meta: Meta, private titleService: Title) {
    this.titleService.setTitle('i-Insured Advantage Club | Insurance Benefits & Deals');
    this.meta.addTag({ name: 'description', content: 'i-Insured Advantage Club is your one stop shop to amazing deals that offers some extra benefit on buying the insurance policy from i-Insured.' });
    this.meta.addTag({ name: 'keywords', content: 'i-Insured Advantage club, insurance policy benefits, insurances from i-Insured, insurance company dubai, buy insurance policy in dubai,  i-Insured insurance' });
  }

  ngOnInit() {
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //  window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }

}
