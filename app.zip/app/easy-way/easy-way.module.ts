import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from './../shared.module';
import { EasyWayRoutingModule } from './easy-way-routing.module';
import { EasyWayComponent } from './easy-way.component';


@NgModule({
    declarations: [
        EasyWayComponent
    ],
    imports: [
        EasyWayRoutingModule,
        CommonModule,
        SharedModule,
        SlickCarouselModule

    ],
})

export class EasyWayModule { }