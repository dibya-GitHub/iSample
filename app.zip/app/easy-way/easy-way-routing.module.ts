import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EasyWayComponent } from './easy-way.component';

const easywayRoutes: Routes = [
  { path: '', component: EasyWayComponent },
];
@NgModule({
  imports: [
    RouterModule.forChild(easywayRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class EasyWayRoutingModule { }
