import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import * as $ from 'jquery';
@Component({
  selector: 'app-easy-way',
  templateUrl: './easy-way.component.html',
  styleUrls: ['./easy-way.component.scss']
})
export class EasyWayComponent implements OnInit {

  constructor(
    private router: Router,
    private meta: Meta,
    private titleService: Title) {

    if (window.location.href.indexOf("/about-qic") > -1) {
      this.titleService.setTitle('About | Insurance Company in Dubai | i-Insured');
      this.meta.addTag({ name: 'description', content: 'i-Insured, leading insurance company in Dubai provides car insurance, home content insurance, travel insurance and personal accident insurance which is established in 1964.' });
      this.meta.addTag({ name: 'keywords', content: 'insurance in dubai, health insurance plans, travel insurance plan, claim for accident, best online car insurance, Get Home Contents Insurance, cheap holiday insurance, get health insurance, insurance companies in dubai' });
    }
    else {
      this.titleService.setTitle('Easy Insurance in Dubai, UAE | i-Insured');
      this.meta.addTag({ name: 'description', content: 'We believe in the “Easy Way” for our customers. We believe insurance should be convenient, fast and free of hassle or time-consuming processes. Welcome to i-Insured' });
      this.meta.addTag({ name: 'keywords', content: 'insurance in dubai, health insurance plans, travel insurance plan, claim for accident, best online car insurance, Get Home Contents Insurance, cheap holiday insurance, get health insurance, insurance companies in dubai' });

    }
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }
  subtitle = 'Getting insured is as easy as pie. We make it easy to get the tailored insurance coverage that you are looking for – either online or over the phone';

  currentIndex: any = 1;

  ngOnInit() {
    this.initSlider();
    this.initSliderForMobile();
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  afterChange(event) {
    this.currentIndex = $('.insta-wp.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);

    });
  }

  testimonials = [
    {
      name: 'Muhammad',
      image: 'easy-way-male-avatar-07',
      heading: 'Professional & Swift Services',
      message: 'I found QIC very professional and swift at handling claims. It\'s online system proves to be real peace for my mind'
    },
    {
      name: 'Shekar Agarval',
      image: 'easy-way-female-avatar-08',
      heading: 'Expedient website & service delivery',
      message: 'Very efficient and user friendly online interface. The policy was promptly delivered to my office'
    },
    {

      name: 'Hussain Sultan Alhyaki',
      image: 'easy-way-female-avatar-08',
      heading: 'Fast services, great timings',
      message: 'Their services are fast and their branch opening hours are great that are particularly suitable for my life-style'
    },
    {

      name: 'Mr. Naveed Akhtar',
      image: 'easy-way-male-avatar-07',
      heading: 'Committed to the service promise',
      message: 'QIC is the best insurance company that committedly delivers on its promises'
    },
    {

      name: 'Raza Ali M. Muhammad',
      image: 'easy-way-male-avatar-07',
      heading: 'Insurance company with many advantages',
      message: 'Simple & fast process, easy accessibility, good customer responses, staff to guide, high degree of organization & management & high availability.. these are some of qualities of QIC'
    },
    {

      name: 'Shanjose A. Nitto',
      image: 'easy-way-male-avatar-07',
      heading: 'The best insurance company',
      message: 'The best insurance company, I have ever dealt with'
    },
    {

      name: 'Jeshua Ruiz I',
      image: 'easy-way-male-avatar-07',
      heading: 'Excellent rates & Services',
      message: 'The insurance company with Excellent rates and service'
    },
    {

      name: 'Kerrie McDonald',
      image: 'easy-way-male-avatar-07',
      heading: 'Impeccable client satisfaction',
      message: 'Their follow up service to ensure my satisfaction with the process, was impeccable! Well done, QIC!'
    },
    {

      name: 'Narcisa Bleza',
      image: 'easy-way-male-avatar-07',
      heading: 'Commendable business process',
      message: 'Keep up the good work. I really appreciate the way you do your business'
    },
    {

      name: 'Hassan Aziz',
      image: 'easy-way-male-avatar-07',
      heading: 'The best ever',
      message: 'The best insurance company I have ever associated with'
    },
    {

      name: 'Manish Barman',
      image: 'easy-way-male-avatar-07',
      heading: 'Hassle-free, Rightly Priced',
      message: 'QIC services offer ease of transaction, are hassle-free and rightly priced'
    },
    {

      name: 'Mr. Gilbert Aouad',
      image: 'easy-way-male-avatar-07',
      heading: 'Professional Services',
      message: 'Their services are professional'
    },
    {

      name: 'Mr. John David Henry Mainka',
      image: 'easy-way-male-avatar-07',
      heading: 'Professional & Online',
      message: 'QIC offer a very professional service and the ability to renew online is fantastic'
    },
    {

      name: 'Oliver Moritz',
      image: 'easy-way-male-avatar-07',
      heading: 'Great availability of Services',
      message: 'Great service at all times. Uncomplicated resolution of the issues'
    },
    {


      name: 'Margie Ferrera Fortu',
      image: 'easy-way-male-avatar-07',
      heading: 'In Good Hands',
      message: 'I\'m in good hands with QIC vehicle insurance'
    },
    {

      name: 'Yehia Khamis',
      image: 'easy-way-male-avatar-07',
      heading: 'Great Service, fair prices',
      message: 'Good rates and great customer service'
    },
    {

      name: 'Hassan Ibrahim Ahmed Nimir+QNB',
      image: 'easy-way-male-avatar-07',
      heading: 'The best in the world',
      message: 'QIC is the best insurance company in the world, everything is easy and at hand, no need for taking any hassle. Go Forward QIC'
    },
    {

      name: 'Susan Erni',
      image: 'easy-way-male-avatar-07',
      heading: 'Dependable Services, User-friendly Website',
      message: 'I have lived in 4 countries and QIC has been the most reliable, dependable and best insurance I have had. Theirs staff is friendly, helpful and supportive and their website, easy to use and very helpful!'
    },
    {

      name: 'Nationwide International',
      image: 'easy-way-male-avatar-07',
      heading: 'Feels Good',
      message: 'It feels good to be a customer of QIC'
    },
    {

      name: 'Bhoira Zakaria Mohammedhusain',
      image: 'easy-way-male-avatar-07',
      heading: 'Everything Online',
      message: 'The best thing about QIC is that every thing is online'
    },
    {

      name: 'Katrina Bilae Laureta',
      image: 'easy-way-male-avatar-07',
      heading: 'Great Service',
      message: 'Great service and very quick response!'
    },
    {

      name: 'Bien Patrick M. Cordero',
      image: 'easy-way-male-avatar-07',
      heading: 'Good way to get insured',
      message: 'It was a quick online enrollment, no need to go to your office. You provide us with a very good way to get insured'
    },
    {

      name: 'Bernard Christain Jacobs',
      image: 'easy-way-male-avatar-07',
      heading: 'Quick, Efficient & Consistent Services',
      message: 'I have been with QIC since 2006 and in all these years I have just received EXCELLENT service and support from them. I was involved in a car accident where my vehicle was scrapped a few years back and QIC handled it very quickly and very efficiently. Hats off to QIC, you are excellent!'
    },
    {
      name: 'Samuel Piercy Evans',
      image: 'easy-way-male-avatar-07',
      heading: 'Great Service Value',
      message: 'Exceptional services delivering great value'
    },
    {

      name: 'Mohamad Zairi Bin Poniran + HSBC',
      image: 'easy-way-male-avatar-07',
      heading: 'Easy & Efficient Services',
      message: 'Easy online services and efficient counter services'
    },
    {

      name: 'Rony Mathew Oommen',
      image: 'easy-way-male-avatar-07',
      heading: 'Easy Claims Settlement',
      message: 'Claim settlement with QIC, is really easy'
    },
    {
      name: 'Kallangat Kuzhiyil M. Kabeer',
      image: 'easy-way-male-avatar-07',
      heading: 'Easy Insurance',
      message: 'It\'s very easy to get insured with QIC, it takes only a few seconds!'
    },
    {
      name: 'Elena Nicole L. Khoury',
      image: 'easy-way-male-avatar-07',
      heading: 'Impressive Online facility',
      message: 'I appreciate their services such as sms reminders and the ability to renew insurance online and avail discount!'
    }

  ]

  listContent = [
    {
      heading: 'WhatsApp services',
      description: 'Talk with us, buy your policy or file and manage your claims through WhatsApp',
      icon: 'whatsapp',
      alt: 'WhatsApp services'
    },
    {
      heading: '99.6 % of all claims approved instantly',
      description: 'No hassle, no long discussions – just a fast and convenient claims process',
      icon: 'ok-stamp',
      alt: '99.6 % of all claims approved instantly'
    },
    {
      heading: 'All is online',
      description: 'You never have to leave your office or home to deal with us – all our services are online',
      icon: 'www',
      alt: 'All is online'
    },
    {
      heading: 'Rated excellent',
      description: 'Our customers give us 4.7 stars out of a maximum of five – we’re always aiming for five stars!',
      icon: 'stars-rating',
      alt: 'Rated excellent'
    }
  ]

  slideAbout = {
    "slidesToShow": 2,
    "slidesToScroll": 2,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 736,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  };

  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "draggable": false
  };
  slideTestimonials = {
    "slidesToShow": 3,
    "slidesToScroll": 3,
    "infinite": true,
    "dots": true,
    "prevArrow": false,
    "nextArrow": false,
    autoplay: true,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 3,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 2,
          "infinite": true,
          "dots": false,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": false,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": false,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }

  slideHighlights = {
    "slidesToShow": 4,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
  }

  loadLayer2() {
    $("#btn1").hide();
    $(".one").hide();
    $(".layer2").slideDown();
    $("#btn2").show();

  }

  loadLayer3() {
    $("#btn2").hide();
    $(".two").hide();
    $(".layer3").slideDown();
    $("#btn3").show();

  }

  hideLayers() {
    $(".layer3").slideUp().hide();
    $(".layer2").slideUp().hide();
    $("#btn1").show();
    $(".one").show();
  }
  initSlider() {
    var self = this;
    $(function () {
      $(".slick-dots button, .slick-next, .slick-prev, .triger-box").on("click", function () {
        // var title = $(".slick-current").find("h4").html();
        setTimeout(function () {
          var title = $(".slick-current").find("h4").html();
          switch (title) {
            case "Same Price Better Deal":
              self.subtitle = 'The right coverage, for the right price, at the right time! Compare the benefits and services we offer';
              break;
            case "Less Hassel More Peace":
              self.subtitle = 'Purchase and manage your insurance policies from the comfort of your home as well as the unforeseen risks conveniently anytime from anywhere';
              break;
            case "Navigate You Through The Souq":
              self.subtitle = 'Our knowledgeable and experienced insurance specialists can evaluate your situation, answer your questions and help determine the best insurance coverage for you';
              break;
            default:
              self.subtitle = 'Getting insured is as easy as pie. We make it easy to get the tailored insurance coverage that you are looking for – either online or over the phone';
              break;
          }
        }, 500);
      });
    })
  }
}
