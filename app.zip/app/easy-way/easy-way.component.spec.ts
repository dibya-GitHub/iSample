import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EasyWayComponent } from './easy-way.component';

describe('EasyWayComponent', () => {
  let component: EasyWayComponent;
  let fixture: ComponentFixture<EasyWayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EasyWayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EasyWayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
