import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SlickCarouselModule } from "ngx-slick-carousel";
import { CustomMaxDirective } from "src/shared/directive/custom-max-validator.directive";
import { CustomMinDirective } from "src/shared/directive/custom-min-validator.directive";

@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [
    CustomMinDirective,
    CustomMaxDirective,
  ],
  imports:[
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [
    CustomMinDirective,
    CustomMaxDirective,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class SharedModule { }