import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/shared/services/data.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-session-timeout',
  templateUrl: './session-timeout.component.html',
  styleUrls: ['./session-timeout.component.scss']
})
export class SessionTimeoutComponent implements OnInit {

  constructor(
    private data: DataService
  ) { }

  ngOnInit() {
    window.localStorage.clear();
    this.data.alert("login", false);
    this.data.alert("userLogin", false);
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
}
