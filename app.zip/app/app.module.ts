import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgSelectModule } from '@ng-select/ng-select';
import { RecaptchaFormsModule, RecaptchaModule, RecaptchaSettings, RECAPTCHA_SETTINGS } from 'ng-recaptcha';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { environment } from 'src/environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CarThankYouComponent } from './car-insurance/car-thank-you/car-thank-you.component';
import { SharedModule } from './shared.module';
// import { NgxPaginationModule } from 'ngx-pagination';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SubmitClaimComponent } from './claims/qic/submit-claim/submit-claim.component';
import { HomeInsuranceComponent } from './home-insurance/home-insurance/home-insurance.component';
import { HomeComponent } from './home/home.component';
import { MyQicComponent } from './my-qic/my-qic/my-qic.component';
import { AdditionalPabInfoComponent } from './pab-insuarance/additional-pab-info/additional-pab-info.component';
import { PersonalAndFamilyInfoComponent } from './pab-insuarance/personal-and-family-info/personal-and-family-info.component';
import { RegisterComplaintComponent } from './register-complaint/register-complaint.component';
import { RetrieveCustInsurancePageComponent } from './renew-policy/retrieve-cust-insurance-page/retrieve-cust-insurance-page.component';
import { TelematicProductComponent } from './telematic/telematic-product/telematic-product.component';
import { PersonalAndTravelInfoComponent } from './travel-insuarance/personal-and-travel-info/personal-and-travel-info.component';

import { AngularMyDatePickerModule } from 'angular-mydatepicker';
import { AdditionalCarInfoComponent } from './car-insurance/additional-car-info/additional-car-info.component';
import { SecondScreenComponent } from './car-insurance/chassi-entry-and-details-form/second-screen/second-screen.component';
import { UploadDocumentsComponent } from './car-insurance/upload-documents/upload-documents.component';
import { TpclaimComponent } from './claims/non-qic/tpclaim/tpclaim.component';
import { ReportclaimComponent } from './claims/qic/report-claim/reportclaim.component';
import { CycleInfoComponent } from './cycle-insurance/cycle-info/cycle-info.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PaymentSummaryComponent } from './payment-summary/payment-summary.component';
import { SelectPlanComponent } from './select-plan/select-plan.component';
import { FirstScreenMotorComponent } from './car-insurance/chassi-entry-and-details-form/first-screen-motor/first-screen-motor.component';
import { RouterModule } from '@angular/router';
import { FirstScreenComponent } from './car-insurance/chassi-entry-and-details-form/first-screen/first-screen.component';
import { AdditionalHomeInfoComponent } from './home-insurance/additional-home-info/additional-home-info.component';
import { PersonalAndVehicleInfoComponent } from './car-insurance/personal-and-vehicle-info/personal-and-vehicle-info.component';
import { NiceCarProductComponent } from './car-insurance/nice-car-product/nice-car-product.component';

@NgModule({
  schemas: [
    NO_ERRORS_SCHEMA,
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [
    AppComponent,
    MyQicComponent,
    HomeComponent,
    TelematicProductComponent,
    RetrieveCustInsurancePageComponent,
    SubmitClaimComponent,
    PersonalAndTravelInfoComponent,
    RegisterComplaintComponent,
    AdditionalPabInfoComponent,
    HomeInsuranceComponent,
    PersonalAndFamilyInfoComponent,
    PersonalAndFamilyInfoComponent,
    AdditionalCarInfoComponent,
    TpclaimComponent,
    CarThankYouComponent,
    ReportclaimComponent,
    SecondScreenComponent,
    PaymentSummaryComponent,
    UploadDocumentsComponent,
    SelectPlanComponent,
    CycleInfoComponent,
    NavbarComponent,
    FirstScreenMotorComponent,
    FirstScreenComponent,
    AdditionalHomeInfoComponent,
    PersonalAndVehicleInfoComponent,
    NiceCarProductComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    CurrencyMaskModule,
    RecaptchaFormsModule,
    RecaptchaModule,
    NgSelectModule,
    TooltipModule,
    SharedModule,
    SlickCarouselModule,
    AngularMyDatePickerModule,
  ],
  providers: [
    {
      provide: RECAPTCHA_SETTINGS,
      useValue: {
        siteKey: environment.siteKey,
      } as RecaptchaSettings,
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
