
import { Component, OnInit } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
declare var $: any;
declare var fbq: Function;
import { DeviceDetectorService } from 'ngx-device-detector';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { LoaderService } from '../shared/loader-service/loader.service';
import { InsuranceService } from '../shared/services/insurance.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  showLoader: boolean;
  title = 'app';
  currentRoute: string;
  deviceInfo = null;
  showErrorMessage: boolean = false;
  constructor(
    private loaderService: LoaderService,
    private router: Router,
    private insuranceService: InsuranceService,
    private meta: Meta,
    private deviceService: DeviceDetectorService,
    private pixelService: RocketFuelService) {
    this.router.events.subscribe(event => {
      // console.log(event);

      $('link[rel="canonical"]').attr('href', window.location.href);
      $('link[rel="alternate"]').attr('href', window.location.href);
      window.scrollTo(0, 1);
      try {
        if (event instanceof NavigationStart) {
          this.meta.removeTag('name="description"');
          this.meta.removeTag('name="keywords"');
        }
        if (event instanceof NavigationEnd) {
          var pathName = event.urlAfterRedirects;;
          var UrlRedirect = event.urlAfterRedirects.split('?');
          if (UrlRedirect[0] != '/select-plan' && UrlRedirect[0] != '/summary') {
            (<any>window).gtag('set', 'page', pathName);
            (<any>window).gtag('send', 'pageview', pathName);
            (<any>window).gtag('config', 'UA-68986372-1', { 'page_path': pathName });
            //(<any>window).gtag('config', 'UA-118996059-1', {'page_path': pathName});//for local only my machine
          }

          $('.addCustomColor').parent('#myPages').removeClass('active');
          if (window.location.href.indexOf('login') > -1 && window.localStorage.getItem('userDetails') != undefined && window.localStorage.getItem('userDetails') != null) {
            this.router.navigate(["my-qic"]);
          }
          /**
           * sending page view to facebook pixel
           */
          fbq('track', 'PageView');

          $('.parallax-mirror').remove();
   
          $(window).scroll(function () {
            $('[data-parallax="scroll"]').parallax();
          }).resize();

          for (let i = 0; i < $('app-root').children().length; i++) {
            if ($('app-root').children()[i].tagName.toLowerCase().indexOf('app') > -1) {
              let sheet = document.createElement('style')
              sheet.innerHTML = $('app-root').children()[i].tagName.toLowerCase() + "{flex: 1 0 auto;}";
              document.body.appendChild(sheet);

            }
          }
          $(function () {
            $('.panel-collapse').on('show.bs.collapse', function () {
              $(this).siblings('.panel-heading').addClass('active');
            });

            $('.panel-collapse').on('hide.bs.collapse', function () {
              $(this).siblings('.panel-heading').removeClass('active');
            });
          })
        }
      } catch (e) {
      }
    });

    // Listen for orientation changes
    window.addEventListener("orientationchange", function () {
      // Announce the new orientation number
      //alert(window.orientation);
      if (/Android|webOS|iPhone|iPad|iPod|Opera Mini/i.test(navigator.userAgent)) {
        if (window.orientation != 0 && $(window).width() < 767) {
          $('body').addClass("rotateMobileScreen");
          $(window).resize(function () {
            $('[data-parallax="scroll"]').parallax();
          }).resize();
        } else {
          $('body').removeClass("rotateMobileScreen");
          $(window).resize(function () {
            $('[data-parallax="scroll"]').parallax();
          }).resize();
        }
      }
    }, false);
    this.epicFunction();
  }

  ngOnInit() {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
    this.insuranceService.getIPAddress().subscribe(data => {
      localStorage.setItem('ip', data.ip);
    });
    this.pixelService.pixelFire.subscribe(
      (pixelValue) => {
        this.setPixel(pixelValue);
      }
    );
  }

  setPixel(pixelValue) {
    switch (pixelValue) {
      case 'Universal':
        console.log('Universal');
        this.firePixel('9', '33491', '33491', '20787506', '20787506');
        break;
      case '1':
        console.log('1');
        this.firePixel('9', '33491', '33491', '20787507', '20787507');
        break;
      case '2':
        console.log('2');
        this.firePixel('9', '33491', '33491', '20795583', '20795583');
        break;
      case '3':
        console.log('3');
        this.firePixel('9', '33491', '33491', '20795670', '20795670');
        break;
      case '4':
        console.log('4');
        this.firePixel('9', '33491', '33491', '20795673', '20795673');
        break;
      case '5':
        console.log('5');
        this.firePixel('9', '33491', '33491', '20795674', '20795674');
        break;
      case '6':
        console.log('6');
        this.firePixel('9', '33491', '33491', '20795675', '20795675');
        break;
      case '7':
        console.log('7');
        this.firePixel('9', '33491', '33491', '20800407', '20800407');
        break;
      //E-data proceed Button
      case '2.1':
        console.log('2.1');
        this.firePixel('9', '33491', '33491', '20800218', '20800218');
        break;
      //E-data Get Quote Button
      case '3.1':
        console.log('3.1');
        this.firePixel('9', '33491', '33491', '20800219', '20800219');
        break;
      case 'ThankYou':
        console.log('ThankYou');
        this.firePixel('9', '33491', '33491', '20787508', '20787508');
        break;
    }
  }

  firePixel(ver, rb, o, ca, t) {
    (<any>window)._rfi('setArgs', 'ver', ver);
    (<any>window)._rfi('setArgs', 'rb', rb);
    (<any>window)._rfi('setArgs', '_o', o);
    (<any>window)._rfi('setArgs', 'ca', ca);
    (<any>window)._rfi('setArgs', '_t', t);
    (<any>window)._rfi('track');
  }

  goToAdvantageClub() {
    this.router.navigate(['advantage-club']);
  }

  epicFunction() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    if (this.deviceInfo.browser == "ie" && this.deviceInfo.browser_version < 11) {
      this.showErrorMessage = true
    }
    console.log("device info is", JSON.stringify(this.deviceInfo));
  }

}

