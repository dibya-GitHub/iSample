import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MyBlogComponent } from './my-blog.component';

const MyBlogRoutes: Routes = [
  { path: '', component: MyBlogComponent },
];
@NgModule({
  imports: [
    RouterModule.forChild(MyBlogRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class MyBlogRoutingModule { }
