import { DatePipe } from "@angular/common";
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { InsuranceService } from 'src/shared/services/insurance.service';

@Component({
  selector: 'app-blog-details',
  templateUrl: './blog-details.component.html',
  styleUrls: ['./blog-details.component.scss']
})
export class BlogDetailsComponent implements OnInit {
  title: string;
  blogObj: any;
  showContent: boolean = false;
  url: string;
  datePipe: DatePipe;

  constructor(
    private loader: LoaderService,
    private route: ActivatedRoute,
    private insuranceService: InsuranceService,
  ) { }

  ngOnInit() {
    this.datePipe = new DatePipe('en-US');
    this.route.params.subscribe(params => {
      this.title = params["title"];
    })

    this.insuranceService.getBlogFeeds().subscribe(
      (res: any) => {
        for (let i = 0; i < res.posts.length; i++) {
          res.posts[i].date = Date.parse(res.posts[i].date.replace(/^(.*-[0-9][0-9])(\ )([0-9][0-9]\:.*$)/, '$1T$3'));
          if (res.posts[i].slug == this.title) {
            this.blogObj = res.posts[i];
          }
        }
        this.showContent = true;
      }
    )
  }

  shareBlog(text, url) {
    switch (text) {
      case 'facebook':
        this.url = "https://www.facebook.com/sharer.php?u=" + url + "";
        break;
      case 'twitter':
        this.url = "https://twitter.com/share?text=" + url + "";
        break;
      case 'linkedin':
        this.url = "https://linkedin.com/shareArticle?mini=true&amp;url=" + url + "";
        break;
      case 'tumblr':
        this.url = "http://www.tumblr.com/share/link?url=" + url + "";
        break;
      default:
        this.url = "https://plus.google.com/share?url=" + url + "";
    }
    window.open(this.url, '', "width=400,height=1000")
  }

}
