import { DatePipe } from "@angular/common";
import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import * as $ from 'jquery';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { InsuranceService } from 'src/shared/services/insurance.service';

@Component({
  selector: 'app-my-blog',
  templateUrl: './my-blog.component.html',
  styleUrls: ['./my-blog.component.scss'],
})
export class MyBlogComponent implements OnInit {
  showViewMore: boolean = true;
  blogResults: any = [];
  counter: number;
  content: any[] = new Array();
  datePipe: DatePipe;
  constructor(
    private meta: Meta,
    private loader: LoaderService,
    private insuranceService: InsuranceService,
    private titleService: Title,
  ) {
    this.datePipe = new DatePipe('en-US');
    this.titleService.setTitle('Blog | i-Insured Insurance Dubai, UAE');
    this.meta.addTag({ name: 'description', content: 'The i-Insured insurance blog provides you with the latest insurance tips and a complete guide to what insurance you need.' });
    this.meta.addTag({ name: 'keywords', content: 'insurance blog, dubai home contents insurance, life insurance, insurance companies in dubai, insurance brokers in dubai, cheap Home Contents Insurance, dubai life insurance' });
    this.counter = 0
  }
  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "draggable": false
  };


  ngOnInit() {
    this.loader.display(true);
    this.insuranceService.getBlogFeeds().subscribe(
      (res: any) => {
        this.blogResults = res.posts;
        for (let i = 0; i < this.blogResults.length; i++) {
          this.blogResults[i].date = Date.parse(this.blogResults[i].date.replace(/^(.*-[0-9][0-9])(\ )([0-9][0-9]\:.*$)/, '$1T$3'));
          this.blogResults[i].excerpt = this.blogResults[i].excerpt.replace(/<[^>]+>/g, '').substring(0, 150) + '...';
          //console.log(this.blogResults[i].content,">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        }
        this.loader.display(false);
        this.getData();
      }, error => {
        this.loader.display(false);
      })
    this.initSliderForMobile();
  }


  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }


  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);

    });
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }

  getData() {
    if (this.counter + 1 >= this.blogResults.length) {
      this.showViewMore = false;
    }
    for (let i = this.counter + 1; i < this.blogResults.length; i++) {
      this.content.push(this.blogResults[i]);

      if (i % 3 == 0) break;

    }

    this.counter += 3;

  }

}
