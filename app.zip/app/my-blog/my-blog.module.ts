import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SharedModule } from './../shared.module';
import { MyBlogRoutingModule } from './my-blog-routing.module';
import { MyBlogComponent } from './my-blog.component';

@NgModule({
    declarations: [
        MyBlogComponent
    ],
    imports: [
        CommonModule,
        MyBlogRoutingModule,
        SharedModule,
    ],
})

export class MyBlogModule { }