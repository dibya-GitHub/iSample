import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ApiUrls } from "src/shared/api-urls";;
import { ApiHeadersService } from '../../../shared/api-headers.service'

@Injectable({
  providedIn: 'root'
})
export class MyPageService {
  requestOption:any;
  baseUrl:any = environment.baseUrl;
  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }
  updateCallMeAndFeedBack(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_FEEDBACK_AND_CALL_INFO_URL, body, this.requestOption);
  }
}
