export class MyPage {
    callType:any;
    name:any;
    mobileNo:any;
    emailId:any;
    civilId:any;
    product:any;
    fdbkCategory:any; 
    preferTime:any;
    rating:any; 
    suggestion:any;
    userId:any;
}
