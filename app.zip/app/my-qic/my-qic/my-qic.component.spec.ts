import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyQicComponent } from './my-qic.component';

describe('MyQicComponent', () => {
  let component: MyQicComponent;
  let fixture: ComponentFixture<MyQicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyQicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyQicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
