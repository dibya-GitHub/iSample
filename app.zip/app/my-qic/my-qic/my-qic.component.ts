import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppUtil } from '../../../shared/app-util';
import { ApiConstants } from '../../../shared/api-constants';
import { MyPage } from "src/app/my-qic/classes/my-page";
import { MyPageService } from "src/app/my-qic/services/my-page.service";
import * as $ from 'jquery';
import { NgForm } from "@angular/forms";
import { environment } from '../../../environments/environment';
import { ApiUrls } from 'src/shared/api-urls';
import { ApiHeadersService } from 'src/shared/api-headers.service';
import { DatePipe } from "@angular/common";
import { HttpClient } from '@angular/common/http';
import { InsuranceService } from 'src/shared/services/insurance.service';
import { LoaderService } from 'src/shared/loader-service/loader.service';

@Component({
  selector: 'app-my-qic',
  templateUrl: './my-qic.component.html',
  styleUrls: ['./my-qic.component.scss'],
})
export class MyQicComponent implements OnInit {
  discountJSONFileValue: any = {
    "car": 10,
    "home": 30,
    "pab": 10,
    "travel": 10
  };
  selectedPolicy: any;
  p: any;
  userDetails: any;
  searchBy: string = "TPI_CIVIL_ID";
  value: string;
  policyList: any = [];
  policyDetails: any;
  showPolicyStatus: boolean = false;
  renew: any;
  claims: any;
  addMoreCovers: any;
  payInstallment: any;
  printPolicy: any;
  startDate: string;
  endDate: string;
  transId: string;
  tranSrNo: string;
  policyNumber: string = "";
  isInstYN: string = "";
  insName: string;
  lob: string;
  polType: string;
  insuranceType: string;
  vehicleMake: string;
  vehicleModel: string;
  vehicleBody: string;
  vehicleYear: string;
  vehicleChassisNo: string;
  vehicleValue: string;
  policyCovers: any;
  personalBel: any;
  homeAddress: any;
  homeContentValue: any;
  polEndDate: any;
  polStartDate: any;
  tripType: any;
  travelDays: any;
  public feedBackObject = new MyPage();
  public callMeObject = new MyPage();
  public baseUrl = environment.baseUrl;
  public requestOption;
  errorMsg: string = '';
  appUtilObj: AppUtil = new AppUtil();
  showModal: boolean = false;
  nativeWindow: any;
  showPopup = false;
  datePipe: DatePipe = new DatePipe('en-US');
  showDiv = false;
  constructor(
    private router: Router,
    private http: HttpClient,
    private route: ActivatedRoute,
    private insuranceService: InsuranceService,
    private myPageService: MyPageService,
    private apiHeadersService: ApiHeadersService,
    private loaderService: LoaderService,
    ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
    this.nativeWindow = insuranceService.getNativeWindow();
  }
  currentIndex: any = 1;

  ngOnInit() {
    this.loaderService.display(true);

    this.userDetails = JSON.parse(window.localStorage.getItem("userDetails"))
    /**
     * getting active policy list for current user
     */
    let params = { "searchBy": this.searchBy, value: this.userDetails.civilId }
    this.insuranceService.getActivePolList(params).subscribe(
      (response: any) => {

        this.policyList = this.appUtilObj.sortArrayByPolicyStartDateDesc(response.activePolicyArray);

        this.showDiv = true;
        this.loaderService.display(false);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.showDiv = true;
        this.loaderService.display(false);
      });
  }
  afterChange(event) {
    this.currentIndex = $('.for-count.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }

  slideConfig = {
    "slidesToShow": 3,
    "dots": true,
    "infinite": true,
    "centerMode": true,
    "centerPadding": '0px',
    "variableWidth": true
  };
  getPolicy(policy) {
    this.selectedPolicy = policy;
    console.log(policy);
    this.claims = policy.regClaimYN;
    this.renew = policy.renwAllowYN;
    this.addMoreCovers = policy.addCovYN;
    this.payInstallment = policy.instYN;
    this.printPolicy = policy.prntReceiptYN;
    this.transId = policy.transId;
    this.tranSrNo = policy.tranSrNo;
    this.policyNumber = policy.policyNo;

    let params = { "transId": policy.transId, "tranSrNo": policy.tranSrNo }
    this.insuranceService.getPolInfo(params).subscribe(
      response => {
        console.log(response)
        this.policyDetails = response;
        console.log(this.policyDetails + "policy details")
        this.startDate = this.policyDetails.polStartDate;
        this.endDate = this.policyDetails.polEndDate;
        this.isInstYN = this.policyDetails.instYN;
        this.showPolicyStatus = true;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      });
  }

  openDoc(docType) {
    let queryString = '&';
    queryString += 'transId=' + this.transId;
    queryString += '&tranSrNo=' + this.tranSrNo;
    queryString += '&docType=' + docType;
    queryString += '&userId=' + ApiConstants.USER_ID;

    let url = this.baseUrl + ApiUrls.GET_POLICY_REPORT + queryString

    this.apiHeadersService.openPdf(url);
  }

  openPopup() {
    const params = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.insuranceService.getPolInfo(params).subscribe(
      (res: any) => {
        this.insName = res.insName;
        this.polStartDate = res.polStartDate;
        this.polEndDate = res.polEndDate;
        this.lob = res.lobCode;
        this.insuranceType = res.insuranceType;
        if (this.lob == "01") {
          this.insuranceService.getPolVehInfo(params).subscribe(
            (res: any) => {
              this.vehicleMake = res.vehMakeDesc;
              this.vehicleModel = res.vehModelDesc;
              this.vehicleBody = res.vehBodyTypeDesc;
              this.vehicleYear = res.firstRegYear;
              this.vehicleValue = res.sumAssured
              this.vehicleChassisNo = res.chassisNo;
            })
        } else if (this.lob == "04") {
          this.insuranceService.getPolicyHomeInfo(params).subscribe(
            (res: any) => {
              this.personalBel = res.persnlblngsVal;
              this.homeAddress = res.address;
              this.homeContentValue = res.contentsVal;
            }
          )
        } else if (this.lob == "08" && this.insuranceType == null) {
          this.insuranceService.getPolTravelInfo(params).subscribe(
            (res: any) => {
              this.tripType = res.tripTypeDesc;
              this.travelDays = res.daysOfTravel;
            }
          )
        }
        this.insuranceService.getPolCovers(params).subscribe(
          (res: any) => {
            if (res.respCode == "2000") {
              this.policyCovers = res.coversArray;
              this.showPopup = true;
            }
          }
        )
      }
    )
    this.showModal = true;
  }

  closePopup() {
    this.showModal = false;
  }

  openPdf(coverCode) {
    // let param = {"coverCode": coverCode}
    this.apiHeadersService.openPdf(this.baseUrl + ApiUrls.GET_COVER_DOC + "?coverCode=" + coverCode);
  }

  policyStatusClasses(obj) {
    return {
      'btn': true,
      'disabled': obj === "0",
      'disable-btn': obj === "0",
      'active-btn': obj === "1"
    }
  }

  goToInstallment() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "policyNo": this.policyNumber
    };
    this.router.navigate(['pay-installment'], { queryParams: obj, skipLocationChange: true });
  }

  /* code for feedback and callback*/
  onCallMeClick() {
    console.log("onCallMeClick")
    this.callMeObject.product = "";
    this.callMeObject.preferTime = "";

  }
  onFeedbackClick() {
    this.feedBackObject.fdbkCategory = "";
  }
  clearFields(data: any) {
    data.name = "";
    data.mobileNo = "";
    data.emailId = "";
    data.civilId = "";
    data.product = "";
    data.fdbkCategory = "";
    data.preferTime = "";
    data.rating = "";
    data.suggestion = "";
    data.userId = "";
  }
  submitCallMeDetails(callMe: NgForm) {
    this.callMeObject.callType = "C";
    console.log(JSON.stringify(this.callMeObject));
    this.myPageService.updateCallMeAndFeedBack(JSON.stringify(this.callMeObject))
      .subscribe(result => {
        console.log(result);
        // $("#callModal").modal("hide");
        this.clearFields(this.callMeObject);
        callMe.resetForm();

      })
  }

  submitFeedBackDetails(feed: NgForm) {
    this.feedBackObject.callType = "F";
    console.log(JSON.stringify(this.feedBackObject));
    this.myPageService.updateCallMeAndFeedBack(JSON.stringify(this.feedBackObject))
      .subscribe(result => {
        console.log(result);
        // $("#feedModal").modal("hide");
        this.clearFields(this.feedBackObject);
        feed.resetForm();

      })
  }

  sendToRenew() {
    this.router.navigate(['/renew-policy'])
  }

  sendToClaims() {
    this.router.navigate(['/insurance-claims'])
  }

  setLocalVal(val: any) {
    window.localStorage.setItem('type', val);
    if (val == 'TP') {
      this.router.navigate(['car-insurance-without-chassi']);
    } else {
      this.router.navigate(['car-insurance']);
    }
  }

}
