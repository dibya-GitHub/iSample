import { VehicleType } from '../../../shared/classes/vehicle-type';
import { VehicleMake } from '../../../shared/classes/vehicle-make'
import { VehicleModel } from '../../../shared/classes/vehicle-model'
import { VehicleCylinder } from '../../../shared/classes/vehicle-cylinder'
import { RegistrationLocation } from '../../../shared/classes/registration-location'

export interface VehicleTypes {
    errMessage: string;
    respCode: string;
    typeArray: Array<VehicleType>
}

export interface VehicleMakes {
    respCode: string;
    errMessage: string;
    makeArray: Array<VehicleMake>
}

export interface VehicleModels {
    respCode: string;
    errMessage: string;
    appCodesArray: Array<VehicleModel>
}

export interface VehicleCylinders {
    errMessage: string;
    respCode: string;
    appCodesArray: Array<VehicleCylinder>
}

export interface RegistrationLocationList {
    errMessage: string;
    respCode: string;
    appCodesArray: Array<RegistrationLocation>
}
