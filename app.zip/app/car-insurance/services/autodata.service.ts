import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiUrls } from '../../../shared/api-urls';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service'
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AutoDataService {

  requestOption: any;
  baseUrl: any = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }
  getModelYears(): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_MODEL_YEAR + ApiUrls.company, {}, this.requestOption);
  }

  getVehicleMakeList(): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_MAKE_LIST + ApiUrls.company, {}, this.requestOption);
  }

  getVehicleModelList(makeInfo: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_MODEL_LIST + ApiUrls.company,
      makeInfo, this.requestOption);
  }

  getSpecifications(vechileInfo: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_SPECIFICATIONS + ApiUrls.company + '&agentId=online',
      vechileInfo, this.requestOption);
  }

  getQuoteData(request: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE + ApiUrls.company + '&agentId=online',
      request, this.requestOption);
  }
  // Motor insurence chassis number
  getVehicleInfoFromChassisNo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VECHILE_INFO_BY_CHASSIS + ApiUrls.company + '&agentId=online',
      body, this.requestOption);
  }
}
