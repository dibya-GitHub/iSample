import { TestBed, inject } from '@angular/core/testing';

import { MotorDropDownService } from './motor-drop-down.service';

describe('MotorDropDownService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MotorDropDownService]
    });
  });

  it('should be created', inject([MotorDropDownService], (service: MotorDropDownService) => {
    expect(service).toBeTruthy();
  }));
});
