import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';


@Injectable({
  providedIn: 'root'
})
export class CarInsurancePlanService {

  requestOption:any;
  baseUrl:any = environment.baseUrl;

  constructor(
    public http: HttpClient,
    public apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  // This method is used to update the motor information
  updateVehicleInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_VEHICLE_INFO_URL, body, this.requestOption)
  }

  // This method validates if the chassis no already exists or not
  validateDuplicateChassisNo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.VALIDATE_CHASSIS_NO_URL, body, this.requestOption);
  }

  validateDuplicateChassisNoPkg(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.VALIDATE_CHASSIS_NO_PKG, body, this.requestOption);
  }

  // This method checks if the chassis no entered is a valid one or not
  allowChassisNo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.ALLOW_CHASSIS_NO_URL, body, this.requestOption);
  }

  // This method checks if the policy is active or not
  checkPolicyStatus(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CHECK_POLICY_STATUS_URL, body, this.requestOption);
  }
  getChassiDetails(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_EDATA_INFO, body, this.requestOption)
  }






}
