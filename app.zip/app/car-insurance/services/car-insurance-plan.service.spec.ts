import { TestBed, inject } from '@angular/core/testing';

import { CarInsurancePlanService } from './car-insurance-plan.service';

describe('CarInsurancePlanService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CarInsurancePlanService]
    });
  });

  it('should be created', inject([CarInsurancePlanService], (service: CarInsurancePlanService) => {
    expect(service).toBeTruthy();
  }));
});
