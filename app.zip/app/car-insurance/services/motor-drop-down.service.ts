import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';

import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class MotorDropDownService {

  requestOption: any;
  baseUrl: any = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  getVehicleType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_TYPE_URL, body, this.requestOption);
  }
  getVehicleUsage(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_USAGE, body, this.requestOption);
  }

  getVehicleMake(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_MAKE_URL, body, this.requestOption);
  }

  getVehicleModelList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_MODEL_LIST_URL, body, this.requestOption);
  }

  getVehicleCylinderList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEHICLE_CYLINDER_LIST_URL, body, this.requestOption);
  }

  getRegistrationLocationList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_REGISTRATION_LIST_URL, body, this.requestOption);
  }

  getSeatingCapacity() {
    let seatingCapicity = [2, 4, 5, 6, 7, 8, 9]
    return seatingCapicity;
  }

  getDrivingExperience() {
    let drivingExperience = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    return drivingExperience;
  }

  getNcdOptions() {
    return [0, 1, 2, 3, 4, 5];
  }
}
