import { Component, NgZone, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import * as $ from 'jquery';
import { Payment } from 'src/shared/interfaces/payment';
import { PaymentService } from 'src/shared/services/payment.service';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { TelematicsService } from '../../telematic/telematic-product/telematics-product.service';
import { CarInsurancePlanService } from '../services/car-insurance-plan.service';

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.scss']
})
export class UploadDocumentsComponent implements OnInit {
  dataToReturn: any = '';
  docNumber: any;
  docCode: any = '';
  cycleInsurance: boolean;
  travelInsurance: boolean;
  imageURL: any = "";
  transId: string;
  tranSrNo: string;
  quoteNo: string;
  insValidYN: any;
  docTypeBoxClass = "doc-type-box hidden-xs hidden-sm";
  uploadVehicleDivClass: string = "";
  uploadEmiratesDivClass: string = "";
  uploadDriversDivClass: string = "";
  uploadVehFrontDivClass: string = "";
  uploadVehLeftDivClass: string = "";
  uploadVehRightDivClass: string = "";
  uploadVehRearDivClass: string = "";
  uploadagencyQuotaionDivClass: string = "";
  uploadPassingPagerDivClass: string = "";
  public data: Payment;
  carInsurance: boolean = false;
  displayPassingPager: boolean = false;
  docCodeValue: string = '';
  registrationYear: number = 0;
  date: Date = new Date();
  yearDiff: number = 0;
  currentYear: any;
  fileExtensionError: boolean = false;
  fileExtension: any;
  fileExtensionMessage: any;
  photoName: any;
  allowedExtensions: any = [];
  checkboxValue: boolean = false;
  accepted: boolean = false;
  errorMessage: string;
  licenseImageURL: any = "";
  emiratesIdImageURL: any = "";
  tenancyIdImageURL: any = "";
  agencyQuotationImageURL: any = "";
  driverLicenseImageURL: any = "";
  uploadVehFrontimageURL: string = "";
  vehRightViewImageURL: string = "";
  uploadVehLeftimageURL: string = "";
  vehRearViewImageURL: string = "";
  passsingPagerImageURL: string = "";
  totalNumberOfDocuments: number = 0;
  uploadedDocumentsLength: number = 0;
  isPolicyActive: string = "0";
  prodShortDesc: string = "";
  appUtilObj: AppUtil = new AppUtil();
  carInsType: any;
  cycleIdImageURL: string = "";
  passPortIdImageURL: string = "";
  invoiceIdImageURL: string = "";
  tetancyIdImageURL: string = "";
  lobCode: any;
  backButton: boolean;
  ifTelematics: string;
  visibleAnimate: boolean = false;
  showModal: boolean = false;
  emiratesIdValue: string = "";

  appNotInstalled: boolean = false;
  applicationInstallError: string = "";
  ncdYear: any;
  ncdDocImageUrl: any = '';
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private zone: NgZone,
    private insurancePlanService: InsuranceService,
    private paymentService: PaymentService,
    private loaderService: LoaderService,
    private carInsurancePlanService: CarInsurancePlanService,
    private telematicsService: TelematicsService,
    private pixelService: RocketFuelService,
    private domSanitizer: DomSanitizer
  ) {
    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      this.quoteNo = params["quoteNo"];
      this.lobCode = params["lobCode"];
      this.registrationYear = params["registrationYear"];
      this.carInsType = params["carInsType"];
      this.backButton = params["backButton"]
      this.ncdYear = params['ncdYear'];
      this.insValidYN = params["insValidYN"];
      this.ifTelematics = params["ifTelematics"];
      this.emiratesIdValue = params["emiratesIdValue"];
    });

    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.disableDrag()
    if (window.location.href.indexOf("/renew-policy") > -1) {
      this.getQuoteInfo();
    } else {
      this.uploadDocuments();
    }
  }

  disableDrag() {
    $(document.body).bind("dragover", function (e) {
      e.preventDefault();
      return false;
    });

    $(document.body).bind("drop", function (e) {
      e.preventDefault();
      return false;
    });
  }

  getQuoteInfo() {
    var quotData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.insurancePlanService.getQuoteInfo(quotData).subscribe((data: any) => {
      console.log('data --');
      console.log(data);
      this.prodShortDesc = data.prodShortDesc;
      this.getPolicyStatus();
    }, error => {
      this.errorMessage = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  uploadDocuments() {
    console.log('inside upload documents');
    if (this.lobCode == "04") {
      console.log("/cycle-insurance");
      this.cycleInsurance = true;
      this.carInsurance = true;
      this.totalNumberOfDocuments = 2;
      this.loaderService.display(false);
    } else if (this.lobCode == "08") {
      this.cycleInsurance = false;
      this.carInsurance = false;
      this.totalNumberOfDocuments = 1;
      this.travelInsurance = true;
      this.loaderService.display(false);
    } else if (window.location.href.indexOf("/car-insurance") > -1 || window.location.href.indexOf("/retrieve-quote") > -1 || this.isPolicyActive == "1") {
      this.carInsurance = true;

      if (this.insValidYN == 2) {
        if (this.ncdYear && this.ncdYear !== '0') {
          this.totalNumberOfDocuments = 2;
        } else {
          this.totalNumberOfDocuments = 1;
        }
        // this.docCode = '024'
        this.setUploadDocument(this.docCode)

      } else {
        if (this.ncdYear && this.ncdYear !== '0') {
          this.totalNumberOfDocuments = 4;
        } else {
          this.totalNumberOfDocuments = 3;
        }
        this.setUploadDocument(this.docCode)
      }
      this.loaderService.display(false);
    } else if (this.prodShortDesc == "OD" && this.isPolicyActive == "0") {
      this.displayPassingPagerOrNot();
    }
    else if (window.location.href.indexOf("/safe-driver") > -1) {
      this.carInsurance = true;
      if (this.insValidYN == 2) {
        this.totalNumberOfDocuments = 1;
      } else {
        this.totalNumberOfDocuments = 3;
      }
      this.loaderService.display(false);
    }
  }

  getPolicyStatus() {

    var policyData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.carInsurancePlanService.checkPolicyStatus(policyData).subscribe((data: any) => {
      this.isPolicyActive = data.active;
      console.log('status of policy --');
      console.log(this.isPolicyActive);
      this.uploadDocuments();
    }, error => {
      this.errorMessage = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });

  }

  displayPassingPagerOrNot() {

    this.currentYear = this.date.getFullYear();
    this.yearDiff = this.currentYear - this.registrationYear;

    if (this.yearDiff > 3) {
      this.displayPassingPager = true;
      this.docTypeBoxClass = "doc-type-box hidden-xs hidden-sm doc-type-box-margin-left";
      this.totalNumberOfDocuments = 5;
    } else {
      this.displayPassingPager = false;
      this.docTypeBoxClass = "doc-type-box hidden-xs hidden-sm doc-type-margin-left";
      this.totalNumberOfDocuments = 4;
    }
    this.loaderService.display(false);
  }

  getDocumentCodeBeforeUpload(event) {
    if (event == "vehFrontView") {
      this.docCodeValue = "033";
    } else if (event == "vehLeftView") {
      this.docCodeValue = "035";
    } else if (event == "vehRightView") {
      this.docCodeValue = "035";
    } else if (event == "vehRearView") {
      this.docCodeValue = "034";
    } else if (event == "passingPagerView") {
      this.docCodeValue = "009";
    } else if (event == "vehicleLicensePic") {
      this.docCodeValue = "008";
    } else if (event == "emiratesId") {
      this.docCodeValue = "004";
    } else if (event == "driverLicense") {
      this.docCodeValue = "007";
    } else if (event == "cycleImage") {
      this.docCodeValue = "033";
    } else if (event == "invoiceId") {
      this.docCodeValue = "024";
    } else if (event == "passportId") {
      this.docCodeValue = "006";
    } else if (event == "agencyQuotation") {
      this.docCodeValue = "024";
    } else if (event === 'ncd') {
      this.docCodeValue = '051';
    } else if (event == "tetancyId") {
      this.docCodeValue = '094';
    }

  }

  onFilesChange(fileList) {
    let doc = fileList.id;
    //let doc = fileList.evt.target.parentElement.parentElement.getElementsByTagName("input")[0].id;
    this.getDocumentCodeBeforeUpload(doc);
    this.fileExtensionError = false;
    this.fileExtensionMessage = "";
    let files = fileList.valid_files
    this.zone.run(() => {
      console.log("Upload Pictures");
      console.log(this.docCodeValue);
      if (files.length > 0) {
        let file: File = files[0];

        var reader = new FileReader();
        var that = this;
        reader.onload = function () {
          that.imageURL = reader.result;
          that.upload(event, files, doc);
        }
        reader.readAsDataURL(files[0]);
        if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
          this.errorMessage = "";
        }
      }

    });

  }

  invalidFiles(files) {
    if (files && files.length > 0) {
      this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
      this.fileExtensionError = true;
    }
  }

  //used to upload documents
  uploadPicture(event: any) {
    //console.log("inside upload picture function");
    //console.log("event target id ---");
    //console.log(event.target.id);

    this.getDocumentCodeBeforeUpload(event.target.id);

    var fileDetail = event.target.files[0];
    this.photoName = fileDetail.name;

    this.allowedExtensions = ["jpeg", "jpg", "bmp", "gif", "png", "pdf"];
    this.fileExtension = this.photoName.split('.').pop();
    console.log(this.fileExtension);

    if (this.isInArray(this.allowedExtensions, this.fileExtension)) {
      console.log('inside if');
      this.fileExtensionError = false;
      this.fileExtensionMessage = "";
    } else {
      console.log('inside else');
      this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
      this.fileExtensionError = true;
      console.log(this.fileExtensionError);
      return;
    }

    this.zone.run(() => {
      console.log("Upload Pictures");
      console.log(this.docCodeValue);
      let fileList: FileList = event.target.files;
      if (fileList.length > 0) {
        let file: File = fileList[0];

        var reader = new FileReader();
        var that = this;
        reader.onload = function () {
          that.imageURL = reader.result;
          that.upload(event);
        }
        reader.readAsDataURL(fileList[0]);
        if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
          this.errorMessage = "";
        }
      }
    });
  }

  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    console.log("ImageURL");
    console.log(this.imageURL);
    console.log(file);
    console.log(file.name);
    if (file.type == 'application/pdf') {
      this.imageURL = './assets/images/Pdf-File-icon.png'
    }
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('docCode', this.docCodeValue);
    formData.append('userId', "online");

    console.log("formData=========", formData);
    var uploadDocumentReponse = this.insurancePlanService.uploadPolicyDocument(formData);
    if (event.target.id == "vehicleLicensePic" || doc == "vehicleLicensePic") {
      if (this.licenseImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.licenseImageURL = this.imageURL;
    } else if (event.target.id == "emiratesId" || doc == "emiratesId") {
      if (this.emiratesIdImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.emiratesIdImageURL = this.imageURL;
    } else if (event.target.id == "driverLicense" || doc == "driverLicense") {
      if (this.driverLicenseImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.driverLicenseImageURL = this.imageURL;
    } else if (event.target.id == "vehFrontView" || doc == "vehFrontView") {
      if (this.uploadVehFrontimageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.uploadVehFrontimageURL = this.imageURL;
    } else if (event.target.id == "vehRightView" || doc == "vehRightView") {
      if (this.vehRightViewImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.vehRightViewImageURL = this.imageURL;
    } else if (event.target.id == "vehLeftView" || doc == "vehLeftView") {
      if (this.uploadVehLeftimageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.uploadVehLeftimageURL = this.imageURL;
    } else if (event.target.id == "vehRearView" || doc == "vehRearView") {
      if (this.vehRearViewImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.vehRearViewImageURL = this.imageURL;
    } else if (event.target.id == "passingPagerView" || doc == "passingPagerView") {
      if (this.passsingPagerImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.passsingPagerImageURL = this.imageURL;
    } else if (event.target.id == "invoiceId" || doc == "invoiceId") {
      if (this.invoiceIdImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.invoiceIdImageURL = this.imageURL;
    } else if (event.target.id == "tetancyId" || doc == "tetancyId") {
      if (this.tetancyIdImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.tetancyIdImageURL = this.imageURL;
    } else if (event.target.id == "passportId" || doc == "passportId") {
      if (this.passPortIdImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.passPortIdImageURL = this.imageURL;
    } else if (event.target.id == "cycleImage" || doc == "cycleImage") {
      if (this.cycleIdImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.cycleIdImageURL = this.imageURL;

    } else if (event.target.id == "agencyQuotation" || doc == "agencyQuotation") {
      if (this.agencyQuotationImageURL == '') {
        this.uploadedDocumentsLength++;
      }
      this.agencyQuotationImageURL = this.imageURL;
    } else if (event.target.id === 'ncd' || doc === 'ncd') {
      if (this.ncdDocImageUrl === '') {
        this.uploadedDocumentsLength++;
      }
      this.ncdDocImageUrl = this.imageURL;
    }

  }
  /*- checks if word exists in array -*/
  isInArray(array, word) {
    console.log('inside in array function call');
    return array.indexOf(word.toLowerCase()) > -1;
  }

  changeCheckboxStatus(event) {
    console.log(event.target);
    if (event.target.checked) {
      this.errorMessage = "";
      this.checkboxValue = true;
    } else {
      this.checkboxValue = false;
    }
  }


  hideModal() {
    this.visibleAnimate = false;
    setTimeout(() => this.showModal = false, 300);
  }

  verifyTelematics() {
    this.loaderService.display(true);
    //"28535632996",//this.emiratesIdValue
    // "civilId":"28835642455", 
    var quotData = {
      "civilId": this.emiratesIdValue,
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "userId": "online"
    };
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      carInsType: this.carInsType.toString(),
      backButton: this.backButton ? true : false,
      insValidYN: this.insValidYN,
      ncdYear: this.ncdYear
    }

    var errObj403 = {
      "quoteNo": this.quoteNo,
      "errMsg": "App is not registered with the given Civil ID Or You have reached the maximum policy count. Please contact QIC Insured."
    };
    var errObj500 = {
      "quoteNo": this.quoteNo,
      "errMsg": "Unable to process your request. Please try after sometime."
    };
    this.telematicsService.verifyTelematics(quotData).subscribe(data => {
      console.log("data for telematics success", data);
      this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
      // if(data.status==200){
      //  this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
      // }
      // else if(data.status==403){
      //  this.router.navigate(['referral'], { queryParams: errObj403, skipLocationChange: true });
      // }
      // else if(data.status==500){
      //  this.router.navigate(['referral'], { queryParams: errObj500, skipLocationChange: true });
      // }
      // else{
      //  this.router.navigate(['referral'], { queryParams: errObj500, skipLocationChange: true });
      // }
      this.loaderService.display(false);
    }, error => {
      console.log("data for telematics failure", error);
      this.appNotInstalled = true;
      this.applicationInstallError = error.json().message;
      //this.router.navigate(['referral'], { queryParams: errObj500, skipLocationChange: true });
      this.loaderService.display(false);
    });



  }

  submitAddInfo() {
    if (this.lobCode == "08") {
      this.checkboxValue = true;
    }
    if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
      console.log('All documents are not uploaded');
      this.errorMessage = "Please upload all the documents!";
      return;
    } else {
      console.log('all documents are uploaded');
      if (!this.checkboxValue && this.cycleInsurance == false) {
        this.errorMessage = "Please agree to the terms and conditions to proceed further";
        return;
      } else {
        this.loaderService.display(true);
        let obj;
        if (this.cycleInsurance == true) {
          obj = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            quoteNo: this.quoteNo,
          }
        } else if (this.travelInsurance == true) {
          obj = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            quoteNo: this.quoteNo,
          }
        } else {
          obj = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            quoteNo: this.quoteNo,
            carInsType: this.carInsType.toString(),
            backButton: this.backButton ? true : false,
            insValidYN: this.insValidYN,
            ncdYear: this.ncdYear

          }
        }
        if (this.ifTelematics == "1") {
          this.loaderService.display(false);
          this.visibleAnimate = true;
          this.showModal = true;
          return;
        }
        this.pixelService.pixelFireValue('Universal');
        this.pixelService.pixelFireValue('6');
        //navigate to payment summary page
        this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
      }
    }
  }

  goToPreviousPage() {
    let carParam = '';
    if (this.carInsType != undefined) {
      carParam = this.carInsType.toString();
    }
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      backButton: true,
      registrationYear: this.registrationYear,
      carInsType: carParam
    }
    if (this.lobCode == "04") {
      this.router.navigate(['additional-home-info'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCode == "08") {
      this.router.navigate(['additional-travel-info'], { queryParams: obj, skipLocationChange: true });
    } else {
      this.router.navigate(['carDetails'], { queryParams: obj, skipLocationChange: true });
    }
  }
  setUploadDocument(docCode) {
    this.loaderService.display(true);
    let dataToSend = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      docCode: docCode
    }
    this.insurancePlanService.setUploadDocument(dataToSend).subscribe((result: any) => {
      console.log(result);
      if (docCode != '') {
        this.docNumber = result.docsArray[0].docNo;
        this.insurancePlanService.getUploadDocument(this.docNumber).subscribe((showResult: any) => {

          this.agencyQuotationImageURL = this.domSanitizer.bypassSecurityTrustUrl('data:' + showResult.MimeType + ';base64,' + showResult.FileData);

        })
        this.uploadedDocumentsLength++;
      } else {
        for (let entry of result.docsArray) {
          console.log(entry);
          this.docCode = entry.docCode;
          this.docNumber = entry.docNo;
          if (this.docCode == "008") {
            this.insurancePlanService.getUploadDocument(this.docNumber).subscribe((showResult: any) => {
              this.licenseImageURL = this.domSanitizer.bypassSecurityTrustUrl('data:' + showResult.MimeType + ';base64,' + showResult.FileData);
            })

            this.uploadedDocumentsLength++;
          } else if (this.docCode == "007") {
            this.insurancePlanService.getUploadDocument(this.docNumber).subscribe((showResult: any) => {
              this.driverLicenseImageURL = this.domSanitizer.bypassSecurityTrustUrl('data:' + showResult.MimeType + ';base64,' + showResult.FileData);
            })
            this.uploadedDocumentsLength++;
          } else if (this.docCode == "004") {
            this.insurancePlanService.getUploadDocument(this.docNumber).subscribe((showResult: any) => {
              this.emiratesIdImageURL = this.domSanitizer.bypassSecurityTrustUrl('data:' + showResult.MimeType + ';base64,' + showResult.FileData);
            })
            this.uploadedDocumentsLength++;
          } else if (this.docCode == '') {
            this.insurancePlanService.getUploadDocument(this.docNumber).subscribe((showResult: any) => {
              this.ncdDocImageUrl = this.domSanitizer.bypassSecurityTrustUrl('data:' + showResult.MimeType + ';base64,' + showResult.FileData);
            })
            this.uploadedDocumentsLength++;
          }
        }
      }
    })
    this.loaderService.display(false);
  }
}
