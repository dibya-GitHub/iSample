export class InsuredDetails {
    transId: string;
    tranSrNo: string;
    mapId: string = 'MOT_COMP_RISK_SCR_1';
    polTerm: string = '1';
    emailId: string;
    mobileNo: string;
    insDob: string;
    insName: string;
    insAge: string;
    nationality: any;
    consultantCode: string = "";
    gender: string;
    civilId: string;
}
