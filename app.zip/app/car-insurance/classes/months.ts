export class Months {
    constructor(public id: number, public name: string) {

    }
}