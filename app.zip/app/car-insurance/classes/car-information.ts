export class CarInformation {
  regnNo: string;
  licenceNo: string;
  tcfNo: string;
  financedBank: string;
  engineNo: string;
  vehColor: string;
  chassisNo: string;
  plateChar: string;
  mileage: string;
}
