import { DateModel } from 'ng2-datepicker';
export class PersonalInformation {
  insDob: Date;
  city: string;
  poBox: string;
  licenceAge: string;
}
