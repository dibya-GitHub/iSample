export class InsuredVehicleDetails {
    transId: string;
    tranSrNo: string;
    mapId: string;
    userId: string;
    vehBodyType: string;
    vehUsage: string;
    sumAssured: string;
    vehMake: any;
    vehMakeDesc: any;
    vehModel: any;
    vehModelDesc: any;
    regnLoc: string;
    gccSpecYN: string;
    firstRegYear: string;
    firstRegAge: string;
    vehCylinders: string;
    seatingCty: string;
    psgrLiabSeatCty: string;
    driverDob: string;
    driverAge: string;
    insAge: number;
    nationality: any;
    licenceAge: string;
    gender: string;
    ncdYear: string;
    isVehImported: string;
    isFirstTimeReg: string;
    importCountry: string;

}
