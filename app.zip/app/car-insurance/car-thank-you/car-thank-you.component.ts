import { DatePipe } from "@angular/common";
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
import { environment } from "src/environments/environment";
import { ApiHeadersService } from 'src/shared/api-headers.service';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { ApiConstants } from '../../../shared/api-constants';
import { ApiUrls } from '../../../shared/api-urls';
import { InsuranceService } from '../../../shared/services/insurance.service';

@Component({
  selector: 'app-car-thank-you',
  templateUrl: './car-thank-you.component.html',
  styleUrls: ['./car-thank-you.component.scss']
})
export class CarThankYouComponent implements OnInit, AfterViewInit {
  totalWords = 3000;
  policyDetails: any;
  email: any;
  insName: any;
  policyNumber: any;
  totalPremium: any;
  civilId: string;
  mobileNo: string;
  baseUrl = environment.baseUrl;
  transId: any;
  tranSrNo: any;
  feebackDetails: any = [];
  showModal: boolean = false;
  question1: any;
  question2: any;
  question3: any;
  question4: any;
  question5: any;
  answer1: any;
  answer2: any;
  answer3: any;
  answer4: any;
  answer5: any;
  answer: any = [];
  suggestion: any;
  service_text: any;
  feedbackArr: any = [];
  selectedOption: any;
  disableSubmit: boolean = true;
  datePipe: DatePipe;
  constructor(
    private activatedRoute: ActivatedRoute,
    private insuranceService: InsuranceService,
    private apiHeadersService: ApiHeadersService,
    private router: Router,
    private loaderService: LoaderService,
    private pixelService: RocketFuelService) {
    this.datePipe = new DatePipe('en-US');
    this.activatedRoute.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      if (params["respCode"] == 2000) {
        this.confirmPolicy();
      } else {
        let path = window.location.pathname.substr(0, window.location.pathname.lastIndexOf('/'));
        let obj = {
          errMsg: params['errMessage']
        }
        this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
        return false;
      }
    });
  }
  confirmPolicy() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.insuranceService.confirmPolicy(postData).subscribe(data => {
      console.log(JSON.stringify(data));
      this.policyDetails = data;
      this.email = data[0].emailId;
      this.insName = data[0].insName;
      this.policyNumber = data[0].policyNo
      this.totalPremium = data[0].premium;
      this.civilId = data[0].civilId;
      this.mobileNo = data[0].mobileNo;
      // for (let i = 0; i < this.policyDetails.length; i++) {
      //   this.policyDetails[i].polStartDate = this.datePipe.transform(new Date(this.policyDetails[i].polStartDate), 'd MMM, y');
      //   this.policyDetails[i].polEndDate = this.datePipe.transform(new Date(this.policyDetails[i].polEndDate), 'd MMM, y');
      //   this.policyDetails[i].quotIssDate = this.datePipe.transform(new Date(this.policyDetails[i].quotIssDate), 'd MMM, y');
      // }
      (<any>window).analytics('ecommerce:addTransaction', {
        'id': this.policyDetails[0].transId,
        'affiliation': this.policyDetails[0].tranSrNo,
        'revenue': this.policyDetails[0].premium,
        'shipping': 0,
        'tax': 0,
        'scheme': this.policyDetails[0].schDesc,
        'portalType': this.policyDetails[0].portal,
        'transactionTotal': this.policyDetails[0].premium
      });
      (<any>window).analytics('ecommerce:addItem', {
        'id': this.policyDetails[0].transId,
        'name': this.policyDetails[0].prodDesc,
        'sku': this.policyDetails[0].policyNo,
        'category': this.policyDetails[0].lobCode,
        'price': this.policyDetails[0].premium,
        'quantity': 1
      });
      (<any>window).analytics('ecommerce:send');
    })
  }
  ngOnInit() {
    for (let i = 0; i < 5; i++) {
      let pushData = {}
    }
    this.pixelService.pixelFireValue('ThankYou');
    window.scrollTo(0, 0);
  }



  ngAfterViewInit() {
    let answers = ["Awesome", "Good-ish", "Okie Dokie", "Not too good", "Unhappy"];
    let lastTowAnswers = ["excited", "happy", "unmoved", "sad", "angry"];
    let questions = ["Easy to use?", "Presentation?", "Product information", "Product features", "Overall online experience"]
    for (let i = 0; i < questions.length; i++) {
      if (i < 3) {
        let data = { question: questions[i], answers: answers }
        this.feebackDetails.push(data)
      }
      else {
        let data = { question: questions[i], answers: lastTowAnswers }
        this.feebackDetails.push(data)
      }

    }

    setTimeout(() => {
      //this.showModal = true;
    }, 2000);

  }

  hideModal() {
    this.showModal = false;
  }

  getAns(val: any, index: any, question: any) {
    switch (index) {
      case 1:
        this.answer1 = val;
        this.question1 = index;
        break;
      case 2:
        this.answer2 = val;
        this.question2 = index;
        break;
      case 3:
        this.answer3 = val;
        this.question3 = index;
        break;
      case 4:
        this.answer4 = val;
        this.question4 = index;
        break;
      default:
        this.answer5 = val;
        this.question5 = index;
        break;
    }
  }

  selectedFeedBack(event) {
    this.disableSubmit = true;
    if (event.target.id == "awesomeDiv") {
      $('.modal-title').html('You’re very happy, so we are too! Share your feelings?');
      this.selectedOption = 1;
    } else if (event.target.id == "goodIshDiv") {
      $('.modal-title').html('You’re happy, so we are too! Share your feelings?');
      this.selectedOption = 2;
    } else if (event.target.id == "OkDiv") {
      $('.modal-title').html('You’re not happy, so neither are we! Share your feelings?');
      this.selectedOption = 3;
    } else if (event.target.id == "NotGoodDiv") {
      $('.modal-title').html('You’re sad, and so are we! Share your feelings?');
      this.selectedOption = 4;
    } else if (event.target.id == "UnhappyDiv") {
      $('.modal-title').html('We’re so sorry we made you angry! Share your feelings?');
      this.selectedOption = 5;
    }
  }

  save() {
    this.loaderService.display(true);
    // formType - POL_APPR, name, civilId, refNo - (Policy No), emailId, mobileNo, question1, option1, question2, option2, question3, option3, question4, option4, question5, option5, remarks, suggestion
    let params = {
      "formType": "POL_APPR",
      "name": this.insName,
      "refNo": this.policyNumber,
      "emailId": this.email,
      "question1": 1,
      "option1": this.selectedOption,
      "civilId": this.civilId,
      "mobileNo": this.mobileNo
    }
    console.log(params);
    this.insuranceService.custFeedback(params).subscribe(
      (res: any) => {
        if (res.respCode == "2000") {
          this.loaderService.display(false);
          console.log('your feedback is saved');
          this.suggestion = "";
          $('.thankyouFeedback').show();
        } else {
          this.loaderService.display(false);
        }
      }, error => {
        this.loaderService.display(false);
      });
  }

  openDoc(transId, docType) {
    let queryString = '&';
    queryString += 'transId=' + transId;
    queryString += '&tranSrNo=' + this.tranSrNo;
    queryString += '&docType=' + docType;
    queryString += '&userId=' + ApiConstants.USER_ID;

    let url = this.baseUrl + ApiUrls.GET_POLICY_REPORT + queryString

    this.apiHeadersService.openPdf(url);

    //window.open(url);
  }
  total(suggestion) {
    this.totalWords = 3000;
    if (suggestion.length >= 3000) {

    } else {
      this.totalWords = this.totalWords - suggestion.length;
    }

  }

  validateText(event: string) {
    console.log('inside validateText');
    console.log(event);
    let passedString = event;
    if (/\S/.test(passedString)) {
      // string is not empty and not just whitespace
      // activate button
      this.disableSubmit = false;
    } else {
      this.disableSubmit = true;
    }
  }
}
