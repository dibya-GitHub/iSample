import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarThankYouComponent } from './car-thank-you.component';

describe('CarThankYouComponent', () => {
  let component: CarThankYouComponent;
  let fixture: ComponentFixture<CarThankYouComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarThankYouComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarThankYouComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
