import { AfterViewInit, Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { NavigationEnd, Router } from "@angular/router";
import { IAngularMyDpOptions } from 'angular-mydatepicker';
// import { RecaptchaComponent } from 'ng-recaptcha';
import { InsuredDetails } from "src/app/car-insurance/classes/insured-details";
import { InsuredVehicleDetails } from "src/app/car-insurance/classes/insured-vehicle-details";
import { MotorDropDownService } from "src/app/car-insurance/services/motor-drop-down.service";
import { Gender } from "src/shared/classes/gender";
import { RegistrationLocation } from "src/shared/classes/registration-location";
import { VehicleCylinder } from "src/shared/classes/vehicle-cylinder";
import { VehicleModel } from "src/shared/classes/vehicle-model";
import { VehicleType } from "src/shared/classes/vehicle-type";
import { InsuranceService } from 'src/shared/services/insurance.service';
import { TooltiptList } from "src/shared/tooltip-list";
import { environment } from '../../../environments/environment';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { Months } from './../classes/months';


@Component({
  selector: 'app-nice-car-product',
  templateUrl: './nice-car-product.component.html',
  styleUrls: ['./nice-car-product.component.scss'],

})
export class NiceCarProductComponent implements OnInit, AfterViewInit {
  allmonths: Months[];
  emiratesIdValue = '';
  showThankYouMsg: boolean = false;
  vehicleSelected: boolean = true;
  vehicleSelectedFlag: any = 0;
  showMsg: boolean = false;
  dropDownload = true;
  // @ViewChild('captcha') captcha: RecaptchaComponent;
  @ViewChildren('input') vc;
  public vehicle_types: VehicleType[];
  public vehicle_makes: Array<any>;
  public vehicle_models: VehicleModel[];
  public vehicle_cylinders: VehicleCylinder[];
  public registration_locations: RegistrationLocation[];
  public gender_list: Gender[];
  public nationality_list: Array<any>;
  public responseFromCreateQuote: any;
  public responseFromUpdateInsuredInfo: any;
  public ip: string;
  public vehicleData = new InsuredVehicleDetails();
  public perslData = new InsuredDetails();
  public seating: any;
  public drivingExperience: any;
  public carDetails = new InsuredVehicleDetails();
  public insuredData: boolean;
  isFirstPage: boolean = true;
  insuranceType: any;
  vehUsageArray: any = [];
  vehicleOptionSelected: any;
  date: Date = new Date();
  manfYear: any;
  renMonth: any;
  cusYear: number;
  public startDateOptions: IAngularMyDpOptions = {
    // other options...
    inline: false,
    // editableDateField: true,
    // indicateInvalidDate: true,
    // openSelectorOnInputClick: true,
    // showInputField: true,
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    }
  };
  yearArray: any = [];
  setFieldDisabled: boolean = true;
  appUtilObj: AppUtil = new AppUtil();
  errorMsg: string = '';
  showCaptchaErr = false;
  captchaErr: any;
  campaignCar: any;
  promoCode: any = '';
  promoCodeError: any = '';
  siteKey: any = environment.siteKey;
  ifTelematics: boolean = false;
  nationalityObject: any;
  public tootipMessage = new TooltiptList();
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private insuranceService: InsuranceService,
    private getCarQuoteService: MotorDropDownService,
  ) {
    this.setDrivingExp();
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
    });
    if (window.localStorage.getItem('type') == 'TP') {
      this.setVehicleType('TP');
    } else {
      this.setVehicleType('OD');
    }

    /*Telematics Changes
    this.route.queryParams.subscribe(params => {
      if(params["ifTelematics"]==="true"){
        this.ifTelematics = true;
        this.promoCode = "703446";
        this.setVehicleType('OD');
      }
    });*/


    if (window.location.href.indexOf("/safe-driver") > -1) {
      this.ifTelematics = true;
      this.promoCode = "703446";
      this.setVehicleType('OD');
    }
    /*Telematics Changes*/
  }
  ngAfterViewInit() {
    // this.vc.first.nativeElement.focus();
  }
  ngOnInit() {

    this.allmonths = [
      new Months(1, 'January'),
      new Months(2, 'February'),
      new Months(3, 'March'),
      new Months(5, 'April'),
      new Months(6, 'May'),
      new Months(7, 'June'),
      new Months(8, 'July'),
      new Months(9, 'August'),
      new Months(10, 'September'),
      new Months(11, 'November'),
      new Months(12, 'December'),

    ];
    this.cusYear = new Date().getFullYear() + 1;
    if (window.localStorage.getItem("carCampaignDetails")) {
      this.campaignCar = JSON.parse(window.localStorage.getItem("carCampaignDetails"))
      this.vehicleData.sumAssured = this.campaignCar["carValue"];
      this.perslData.insName = this.campaignCar["name"];
      this.perslData.emailId = this.campaignCar["email"];
      this.perslData.mobileNo = this.campaignCar["mobile"];
      this.perslData.civilId = this.campaignCar["civilId"];
      if (this.campaignCar["nationality"]) {
        this.perslData.nationality = [{ id: this.campaignCar["nationality"], text: this.campaignCar["nationalityDesc"] }]
      }
    }
    window.localStorage.removeItem('carCampaignDetails');
    window.scrollTo(0, 0);
    this.getDefaults();
    let year = new Date().getFullYear();
    for (let i = year + 2; i >= year; i--) {
      this.yearArray.push(i);
    }
    /*getting IP address*/
    this.setIP();
    /*setting number of cylinder*/
    this.setCylinderList();
    /*setting gender dropdown*/
    this.setGenderList();
    /*setting country list*/
    this.setCountrylist();
    /*setting registration locations*/
    this.setRegLocationList();
    /*setting driving experince dropdown*/
    // this.setDrivingExp();
    /*setting Seating Capacity dropdown*/
    this.setSeatingCapacity();
    //this.getModel();
    this.setVehicleMake();
  }

  /*getting IP address*/
  setIP() {
    this.insuranceService.getIPAddress().subscribe(result => {
      this.ip = result.ip;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error.status, null);
      this.loaderService.display(false);
    });
  }
  setVehicleTypeNew(data) {

    this.vehicleData.vehBodyType = data;

    this.vehicleSelectedFlag = 1;
    if (this.vehicleSelectedFlag = 1) {
      this.vehicleSelected = true;
    }

    this.setVehicleUsage(data);
    this.getDefaultsForCompVehiclTypeChange();
  }
  getDefaultsForCompVehiclTypeChange() {
    this.vehicleData.vehMake = "";
    this.vehicleData.vehModel = "";
  }
  getDefaults() {
    this.vehicleData.vehBodyType = "";
    this.vehicleData.vehMake = "";
    this.vehicleData.vehModel = "";
    this.vehicleData.seatingCty = '';
    this.vehicleData.firstRegYear = '';
    this.vehicleData.licenceAge = "";
    this.vehicleData.firstRegAge = "";
    this.vehicleData.vehCylinders = ""
    this.vehicleData.regnLoc = "";
    this.renMonth = "";
  }
  setDrivingExp() {
    this.drivingExperience = this.getCarQuoteService.getDrivingExperience();
  }

  setSeatingCapacity() {
    this.seating = this.getCarQuoteService.getSeatingCapacity();
  }

  /*getting vechicle type*/
  setVehicleType(data: any) {
    this.vehicleData.firstRegYear = '';
    this.vehicleOptionSelected = data;
    if (data == 'TP') {
      this.setFieldDisabled = false;
      //this.vehicleData.gccSpecYN = "";
      this.ifTelematics = false;
      this.promoCode = "";
      this.vehicleData.gccSpecYN = "0";
    } else if (data == 'TPL') {
      this.setFieldDisabled = false;
      //this.vehicleData.gccSpecYN = "";
      this.ifTelematics = false;
      this.promoCode = "";
      this.vehicleData.gccSpecYN = "";
    } else {
      this.vehicleData.gccSpecYN = "";
      this.setFieldDisabled = true;
      if (window.location.href.indexOf("/safe-driver") > -1) {
        this.ifTelematics = true;
        this.promoCode = "703446";
      }


    }
    let v_type = { "agentId": "", "insuranceType": data, "portal": "D" }
    //console.log(JSON.stringify(v_type));
    this.getCarQuoteService.getVehicleType(v_type).subscribe(
      result => {
        this.vehicle_types = result.typeArray;
        this.vehicleData.vehBodyType = '';
        this.vehicleData.vehMake = undefined;
        this.vehicleData.vehModel = undefined;
        this.setVehicleUsage(result.typeArray[0].VEHTYPECODE);
        //console.log("body Type", JSON.stringify(this.vehicle_types));
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }
  setVehicleUsage(data) {
    let v_usage = { "portal": "D", "vehType": data }
    this.getCarQuoteService.getVehicleUsage(v_usage).subscribe(data => {
      this.vehUsageArray = data.usageArray;
      this.vehicleData.vehUsage = '';
      console.log(data.usageArray);
      this.vehicleData.vehUsage = "";
      if (this.dropDownload == false) {
        //this.getDefaults();
        this.dropDownload = true;
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  setGcc(data: any) {
    //this.vehicleData.firstRegYear = '';
    if (data == 0 && this.setFieldDisabled == false) {
      //this.setFieldDisabled = false;
      //this.setVehicleType('TP');
    } else if (data == 0 && this.setFieldDisabled == true) {
      this.setFieldDisabled = false;
      this.setVehicleType('TP');
    }
  }
  /*getting Vehicle make*/
  setVehicleMake() {
    let v_make = { "userId": "online" };
    this.getCarQuoteService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.vehicle_makes = arr;
        // this.vehicle_makes = result.makeArray;
        // this.vehicleData.vehMake = "";
        //this.getModel();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  /*setting cylinder list*/
  setCylinderList() {
    let v_cylinder = { "type": "MOT_VEH_NOC" };
    this.getCarQuoteService.getVehicleCylinderList(v_cylinder)
      .subscribe(result => {
        this.vehicle_cylinders = result.appCodesArray;
        //this.vehicleData.vehCylinders = this.vehicle_cylinders[0].code;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  setGenderList() {
    let get_genderList = { "paraType": "GENDER" };
    this.insuranceService.getGenderList(get_genderList)
      .subscribe(result => {
        this.gender_list = result.appParamsArray;
        this.perslData.gender = "";
        //console.log(result);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  /*setting country list*/
  setCountrylist() {
    let get_nationaLitylist = { "type": "NATIONALITY" };
    this.insuranceService.getNationalityList(get_nationaLitylist)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        let sortedArr = this.sortNationality(arr);
        this.nationality_list = sortedArr
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  /*setting registration locations*/
  setRegLocationList() {
    let location = { "type": "REGN_LOC" }
    this.getCarQuoteService.getRegistrationLocationList(location)
      .subscribe(result => {
        this.registration_locations = result.appCodesArray;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  /*getting vehicle model based on Vehicle make*/
  getModel(event) {
    this.vehicleData.vehMake = event.id;
    let postData = {
      type: "MOT_VEH_MOD",
      refCode: this.vehicleData.vehMake
    }
    this.getCarQuoteService.getVehicleModelList(postData).subscribe(result => {
      //console.log(JSON.stringify(response.json()));
      let arr = [];
      for (let i = 0; i < result.appCodesArray.length; i++) {
        let id = result.appCodesArray[i].code;
        let text = result.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      this.vehicle_models = arr;
      // this.vehicleData.vehModel = "";
      if (this.dropDownload == true) {
        //this.getDefaults();
        this.dropDownload = false;
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });

  }

  addVehicleMake(event) {
    this.carDetails.vehModel = event.id
  }

  addNationality(event) {
    this.carDetails.nationality = event.id
  }
  /*function to submit vehicle detail*/
  resolved(event) {
    console.log(event);
  }
  onSubmit(carDetailform, perslData) {

    // if (this.captcha.execute) {
    //   this.captchaErr = 'Please Validate Captcha';
    //   this.showCaptchaErr = true;
    //   return false;
    // } else {
    //   this.showCaptchaErr = false;
    // }
    this.loaderService.display(true);
    let dateString = perslData.insDob.formatted;

    if (dateString == undefined) {
      dateString = perslData.insDob;
    }
    if (perslData.insDob.epoc != undefined) {
      this.carDetails["driverDob"] = this.appUtilObj.getUTCDate(perslData.insDob.epoc * 1000);
    } else {
      const stringDate = dateString.split("/");
      const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2]
      let tempdate = new Date(newDate);
      this.carDetails["driverDob"] = this.appUtilObj.getUTCDate(tempdate.getTime());
    }
    const tellUsWhenJSONData = {
      makeCode: this.vehicleData.vehMake[0].id,
      modelCode: this.vehicleData.vehModel[0].id,
      month: this.renMonth,
      regYear: this.vehicleData.firstRegYear,
      modelYear: this.manfYear,
      regionCode: 'NC',
      portal: 'D',
      name: perslData.insName,
      emailId: perslData.emailId,
      mobileNo: perslData.mobileNo,
      civilId: this.emiratesIdValue,
      nationality: perslData.nationality[0].id,
      dob: this.carDetails["driverDob"],
    }
    this.insuranceService.tellUsWhen(tellUsWhenJSONData).subscribe((result: any) => {
      if (result.respCode == 2000) {
        this.showThankYouMsg = true;
        window.scrollTo(0, 0);
        this.loaderService.display(false);
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    })

  }

  /* function to calculate age */
  getAge(dateString) {
    console.log(dateString + " DOB")

    let parts = dateString.split('/');
    let age: any;
    let today = new Date();
    console.log(today);
    let birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
    console.log(birthDate);

    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }
  back() {
    window.onbeforeunload = function () {
      window.scrollTo(0, 0);
    }
    this.vehicleData.vehMake = [{ id: this.carDetails.vehMake, text: this.carDetails.vehMakeDesc }]
    this.vehicleData.vehModel = [{ id: this.carDetails.vehModel, text: this.carDetails.vehModelDesc }]
    this.isFirstPage = true;
  }
  onDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.perslData.insDob = event.target.value;
        }
      }
    }
    console.log(this.perslData.insDob)
  }

  onDateChanged(event) {
    if (this.perslData.insDob != undefined || this.perslData.insDob == null) {
      this.showMsg = false;
      //console.log(this.perslData.insDob)
    }
    //console.log(this.perslData.insDob)
  }
  getAgeValidate(dateString: any) {
    if (dateString == '' || dateString == undefined) {
      return false;
    } else {
      //console.log(dateString)
      //let dobOf:string = dateString.formatted;
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {
        let parts = dateString.split('/');
        birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }

      //const date = this.appUtilObj.getUTCDate(timestamp);
      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age < 18) {
        return true;
      } else if (age > 70) {
        return true;
      }
      else {
        return false;
      }

    }

  }

}
