import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CarProductComponent } from './car-product.component';


const routes: Routes = [
  { path: '', component: CarProductComponent },
];
@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class CarProductRoutingModule { }
