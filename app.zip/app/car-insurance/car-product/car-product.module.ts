import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from "../../shared.module";
import { CarProductRoutingModule } from "./car-product-routing.module";
import { CarProductComponent } from "./car-product.component";


@NgModule({
  declarations: [
    CarProductComponent,
  ],
  imports: [
    CarProductRoutingModule,
    CommonModule,
    SharedModule,
    SlickCarouselModule
  ],
})

export class CarProductModule { }