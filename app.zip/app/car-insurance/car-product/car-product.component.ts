import { Component, OnInit } from '@angular/core';
// import { ng2parallax } from 'ang2-parallax/ng2-parallax-directive/parallax.directive';
import { Meta, Title } from "@angular/platform-browser";
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';

@Component({
  selector: 'app-car-product',
  templateUrl: './car-product.component.html',
  styleUrls: ['./car-product.component.scss'],
})
export class CarProductComponent implements OnInit {
  constructor(
    // private ng2parallax: ng2parallax,
    private router: Router,
    private meta: Meta,
    private titleService: Title,
    private pixelService: RocketFuelService) {
    this.titleService.setTitle('Compare, Buy or Renew Car Insurance | Vehicle Insurance in Dubai | i-Insured');
    this.meta.addTag({ name: 'description', content: 'Compare online and buy or renew car insurance in Dubai. Get free Quotes and Online Support from i-Insured on Car Insurance Plan, Benefits, Renewal and Claims.' });
    this.meta.addTag({ name: 'keywords', content: 'buy online car insurance, car insurance quotes, qic car insurance, renewal of car insurance, multi car insurance quotes, third party insurance of car, auto insurance rates, best car insurance in dubai' });
  }
  currentIndex: any = 1;
  selectedImageSrc = './assets/images/car-pro-slide-01.png';
  title = 'Claims on WhatsApp';
  subtitle = 'File your claim the easy way through our WhatsApp services at 56 500 4742. Just send your police report number and our customer service team will take care of the rest';
  ngOnInit() {
    /*Setting universal and LP1 Pixel*/
    this.pixelService.pixelFireValue('Universal');
    setTimeout(
      () => {
        this.pixelService.pixelFireValue('1');
      }, 100
    );
    /*Setting universal and LP1 Pixel*/
    this.initSlider();
    this.initSliderForMobile();

    $(".tab_content").hide();
    $(".tab_content:first").show();

    /* if in tab mode */
    $("ul.tabs li").click(function () {

      $(".tab_content").hide();
      var activeTab = $(this).attr("rel");
      $("#" + activeTab).fadeIn();

      $("ul.tabs li").removeClass("active");
      $(this).addClass("active");

      $(".tab_drawer_heading").removeClass("d_active");
      $(".tab_drawer_heading[rel^='" + activeTab + "']").addClass("d_active");

    });
    /* if in drawer mode */
    $(".tab_drawer_heading").click(function () {

      $(".tab_content").hide();
      var d_activeTab = $(this).attr("rel");
      $("#" + d_activeTab).fadeIn();

      $(".tab_drawer_heading").removeClass("d_active");
      $(this).addClass("d_active");

      $("ul.tabs li").removeClass("active");
      $("ul.tabs li[rel^='" + d_activeTab + "']").addClass("active");
    });
  }

  afterChange(event) {
    this.currentIndex = $('.insta-wp.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }
  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      console.log(winWidth)
      var instaWidth = $(window).width();
      console.log(instaWidth)
      $('.insta-width').width(instaWidth);

    });
  }

  initSlider() {
    var self = this;
    $(function () {
      $(".slick-dots button, .slick-next, .slick-prev, .triger-box").on("click", function () {
        // var title = $(".slick-current").find("h4").html();
        setTimeout(function () {
          var title = $(".slick-current").find("h4").attr("id")
          switch (title) {
            case "first":
              self.subtitle = 'File your claim the easy way through our WhatsApp services at 56 500 4742. Just send your police report number and our customer service team will take care of the rest';
              break;
            case "second":
              self.subtitle = 'Being without a car can be frustrating, which is why we are here to provide you a courtesy car for 3 days while your car is being repaired';
              break;
            case "third":
              self.subtitle = '';
              break;
            default:
              self.subtitle = 'Our Roadside Assistance cover gets you moving quickly. Apart from towing services, we also offer mechanical first aid, flat tyre, lock – out, fuel and battery services';
              break;
          }
        }, 500);
      });
    })
  }

  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "draggable": false
  };

  planConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": false,
    "infinite": true,
    "draggable": false,
    "prevArrow": false,
    "nextArrow": false,
  };


  slideThreeItems = {
    "slidesToShow": 3,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }

  changeBackgroundImage(event: any) {
    console.log(event);
    let className = event.path[1].classList[1];
    $(function () {
      $('.thumbnail').click(function () {
        $('.thumbnail').removeClass('active');
        $(this).addClass('active');
      });
    });
    if (className === 'car-pro-thumb-first') {
      this.selectedImageSrc = './assets/images/car-pro-slide-01.png';
      // this.ng2parallax.src = './assets/images/car-pro-slide-01.png';
      this.title = 'Installment Campaign';
      this.subtitle = 'Installment Campaign orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer posuere turpis sem et magnis dis parturient. Orci varius natoque penatibus et.';

    }
    else if (className === 'car-pro-thumb-sec') {

      this.selectedImageSrc = './assets/images/car-pro-slide-02.png';
      // this.ng2parallax.src = './assets/images/car-pro-slide-02.png';
      this.title = 'Easy Way';
      this.subtitle = 'Travel Campaign orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer posuere turpis sem et magnis dis parturient. Orci varius natoque penatibus et.';

    }
    else if (className === 'car-pro-thumb-third') {

      this.selectedImageSrc = './assets/images/car-pro-slide-03.png';
      // this.ng2parallax.src = './assets/images/car-pro-slide-03.png';
      this.title = 'Get 10% Discount';
      this.subtitle = 'Home Campaign orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer posuere turpis sem et magnis dis parturient. Orci varius natoque penatibus et.';

    }
    else if (className === 'car-pro-thumb-fourth') {

      this.selectedImageSrc = './assets/images/car-pro-slide-04.png';
      // this.ng2parallax.src = './assets/images/car-pro-slide-04.png';
      this.title = 'Claims';
      this.subtitle = 'PAB Campaign orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer posuere turpis sem et magnis dis parturient. Orci varius natoque penatibus et.';

    }
    // this.ng2parallax.ngOnInit();
  }
  setLocalVal(val: any) {

    window.localStorage.setItem('type', val);
    if (val == 'TP') {
      this.router.navigate(['car-insurance-without-chassi']);
    } else {
      this.router.navigate(['car-insurance']);
    }

  }

  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
  }
  goToPlan() {
    $('body, html').animate({ scrollTop: $('#plan-comparison').offset().top - 90 }, 700);
  }
  goToComprehensive() {
    $('body, html').animate({ scrollTop: $('#plan-comprehensive').offset().top - 90 }, 700);
  }
  goToFaq() {
    let obj = {
      productType: "Car",
    }
    this.router.navigate(['faq'], { queryParams: obj, skipLocationChange: true });

  }

}
