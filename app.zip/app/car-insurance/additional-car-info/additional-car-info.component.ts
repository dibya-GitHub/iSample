import { Component, NgZone, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as $ from 'jquery';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { TooltiptList } from 'src/shared/tooltip-list';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { InsuranceService as CommonService } from '../../../shared/services/insurance.service';
import { HomeInsurancePlanService } from '../../home-insurance/services/home-insurance-plan.service';
import { CarInformation } from '../classes/car-information';
import { CarInsurancePlanService } from '../services/car-insurance-plan.service';
import { Gender } from './../../../shared/classes/gender';
import { MotorDropDownService } from './../services/motor-drop-down.service';

@Component({
  selector: 'app-additional-car-info',
  templateUrl: './additional-car-info.component.html',
  styleUrls: ['./additional-car-info.component.scss']
})
export class AdditionalCarInfoComponent implements OnInit {
  drivingExperience: any;
  gender: string = '';
  civilId: string;
  //insuranceValid:any='';
  //insValidYN:any=[];
  insValidYNList: any = [];
  public gender_list: Gender[];
  public plate_code_list: any[];
  showMsg: boolean = false;
  disableFinancedBank: boolean;
  disableVehColor: boolean;
  disableEngineNo: boolean;
  disableLicenceNo: boolean;
  disableRegnNo: boolean;
  disableTcfNo: boolean;
  date: Date = new Date();
  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));
  appUtilObj: AppUtil = new AppUtil();
  public carInformation = new CarInformation();
  startDate: any;
  public myDatePickerOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
    disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };

  endDate: string;
  transId: string;
  tranSrNo: string;
  quoteNo: string;
  startDateOptions = this.myDatePickerOptions;
  endDateOptions = this.myDatePickerOptions;
  premium: any;
  base64textString: string = '';
  bankOfFinanceList: any = [];
  vehicleColorList: any = [];
  registrationYear: string;
  // licenceAge: string;
  isThirdPartySelected: boolean = false;
  applyProcessFourTab: string = 'process';
  applyProcessNavTabs: string = 'process-row nav nav-tabs';
  quoteInfo: any;
  isValidChassiNo = true;
  chassiErr: any;
  selectedBank: Array<any>;
  selectedColor: Array<any>;
  isRenewPolicy = false;
  cityList: any = [];
  insuredNameValue: string = '';
  genderValue: string = '';
  vehPlateCode: string = '';
  nationalityValue: string = '';
  emiratesIdValue: string = '';
  selectedCity: Array<any>;
  insuranceValid: Array<any>;
  poBox: any;
  nationalityDesc: any;
  errorMsg: string = '';
  carInsType: any;
  vehicleType: any;
  insValidDesc: any = ['No', 'Yes', 'Brand New']
  ifTelematics: string;

  tootipMessage = new TooltiptList();
  ncdYear: any;
  selectedRegnLoc: any;
  disableRegnLoc: boolean;
  vehiclePlateChars: any;
  selectedPlateChar: any[];
  constructor(
    private router: Router,
    private zone: NgZone,
    private getCarQuoteService: MotorDropDownService,
    private carInsurancePlanService: CarInsurancePlanService,
    private route: ActivatedRoute,
    private homeInsurancePlanService: HomeInsurancePlanService,
    private commonService: CommonService,
    private loaderService: LoaderService,
    private pixelService: RocketFuelService) {
    if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/renew-policy') {
      this.isRenewPolicy = true;
    }
    this.route.queryParams.subscribe(params => {
      this.transId = params['transId'];
      this.tranSrNo = params['tranSrNo'];
      this.quoteNo = params['quoteNo'];

      this.onDateChanged(this.startDate);
      this.registrationYear = params['registrationYear'];
      this.carInsType = params['carInsType'];
      this.vehicleType = params['vehicleType'];
    });
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  ngOnInit() {
    this.loaderService.display(true);
    //this.insValidYN=[{id: '1', text: 'Yes'},{id: '0', text: 'No'},{id: '2', text: 'Brand New'}];

    var installationAppData = { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'Portal': 'D' };
    console.log(installationAppData);
    this.getBankOfFinance();
    this.getVehicleColor();
    this.setGenderList();
    this.getPlateCodeList();
    this.setDefaultValues();
    this.getCity();
    this.getIsInsuredValid();
    this.setDrivingExp();

    $('.box-shadow').hide();
    $('.container').hide();
  }

  //used to save additional car Information
  additionalCarInfoSave(vehicleInfo) {
    console.log(this.startDate, ' Is this a null value')
    this.loaderService.display(true);
    this.validateChassisPkg(this.carInformation.chassisNo);
    console.log(vehicleInfo);
    if (this.isThirdPartySelected) {
      vehicleInfo['mapId'] = 'MOT_TP_RISK_SCR_2';
    } else {
      vehicleInfo['mapId'] = 'MOT_COMP_RISK_SCR_2';
    }
    vehicleInfo['transId'] = this.transId;
    vehicleInfo['tranSrNo'] = this.tranSrNo;
    if (this.isThirdPartySelected) {
      vehicleInfo['insValidYN'] = '';
    } else {

      vehicleInfo['insValidYN'] = this.insuranceValid[0].id;
    }


    if (this.selectedCity && this.selectedCity.length > 0) {
      vehicleInfo['city'] = this.selectedCity[0].id;
    }
    vehicleInfo['poBox'] = this.poBox;
    if (this.selectedBank && this.selectedBank.length > 0) {
      vehicleInfo.financedBank = this.selectedBank[0].id
    }
    if (this.selectedColor && this.selectedColor.length > 0) {
      vehicleInfo.vehColor = this.selectedColor[0].id
    }

    if (this.selectedPlateChar && this.selectedPlateChar.length > 0) {
      vehicleInfo.plateChar = this.selectedPlateChar[0].id
    }
    if (this.selectedPlateChar && this.selectedPlateChar.length > 0) {
      vehicleInfo.plateChar = this.selectedPlateChar[0].id
    }
    vehicleInfo.vehPlateCode = this.vehPlateCode;
    console.log('=========================');
    console.log('Ve Information======>', JSON.stringify(vehicleInfo));
    console.log('=========================');
    //update vehicle info
    this.carInsurancePlanService.updateVehicleInfo(vehicleInfo).subscribe(response => {
      let mapId;
      if (this.isThirdPartySelected) {
        mapId = 'MOT_TP_POL_SCR_2';
      } else {
        mapId = 'MOT_COMP_POL_SCR_2';
      }
      let city = '';
      if (this.selectedCity != undefined) {
        city = this.selectedCity[0].id
        //alert(this.selectedCity[0].id);
      }
      let cond = !this.isThirdPartySelected
      let personalInfo = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        mapId: mapId,
        insName: this.insuredNameValue,
        city: city,
        poBox: this.poBox,
        civilId: this.emiratesIdValue,
        nationality: this.nationalityValue,
        gender: this.genderValue,


        ...(cond ? { insValidYN: this.insuranceValid[0].id } : {})



      };
      let carData = '';
      if (this.carInsType != undefined) {
        carData = this.carInsType.toString()
      }
      let obj = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        registrationYear: this.registrationYear,
        isThirdPartyInsurance: this.isThirdPartySelected,
        ncdYear: this.ncdYear,
        carInsType: carData,
        ...(cond ? { insValidYN: this.insuranceValid[0].id } : {}),
        isThirdPartySelected: this.isThirdPartySelected,
        //insValidYN:this.insuranceValid[0].id,

        ifTelematics: this.ifTelematics,
        emiratesIdValue: this.emiratesIdValue

      }
      console.log(JSON.stringify(personalInfo));

      this.commonService.updateInsuredInfo(personalInfo).subscribe(response => {
        console.log(response);
        this.pixelService.pixelFireValue('Universal');
        this.pixelService.pixelFireValue('5');
        if (this.isThirdPartySelected) {
          console.log('third party is selected navigate to summary');
          this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
        } else {
          console.log('third party is not selected navigate to upload document');
          this.loaderService.display(false);
          this.router.navigate(['upload-document'], { queryParams: obj, skipLocationChange: true });
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
        this.loaderService.display(false);
      });
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  getBankOfFinance() {
    this.commonService.getApplicationCodes('BANK').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // var tmpArr = data.appCodesArray.reverse();
      this.bankOfFinanceList = this.appUtilObj.sortedArray(arr);
      console.log(this.bankOfFinanceList);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  getPlateCharacters() {
    let countryCode;
    if (this.selectedRegnLoc && this.selectedRegnLoc.length) {
      countryCode = (this.selectedRegnLoc === '001') ? '002' : '003';
    } else {
      return;
    }
    this.commonService.getPlateCharactors(countryCode).subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.plateCharArray.length; i++) {
        let id = data.plateCharArray[i].AC_CODE;
        let text = data.plateCharArray[i].AC_DESC;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // var tmpArr = data.appCodesArray.reverse();
      this.vehiclePlateChars = arr; // this.appUtilObj.sortedArray(arr);
      console.log(this.vehiclePlateChars);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  getIsInsuredValid() {
    let insValidYN = this.commonService.getInsuranceValid();
    //let arr=[];
    //arr.push(insValidYN);
    this.insValidYNList = insValidYN;
    console.log('this.insValidYNList', this.insValidYNList);

    //console.log('this.insValidYN',this.insValidYN);

  }
  getVehicleColor() {
    this.commonService.getApplicationCodes('MOT_VEH_COL').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // var tmpArr = data.appCodesArray.reverse();
      this.vehicleColorList = this.appUtilObj.sortedArray(arr);
      console.log(this.vehicleColorList);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  onDateChanged(event) {
    let date: any;
    if (this.startDate != undefined) {
      this.showMsg = false;
    }
    if (this.startDate == null) {
      this.startDate = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    } else {
      if (this.startDate.date == undefined) {
        let temp: any = this.startDate;
        const stringDate = temp.split('/');
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];

        date = new Date(newDate);
        this.startDate = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      this.startDate.date = event.date;
    }
    let timestamp: any;
    if (event.epoc != undefined) {
      timestamp = new Date(event.epoc * 1000).getTime();
    } else {

      const newDate = this.startDate.date.month + '/' + this.startDate.date.day + '/' + this.startDate.date.year;
      timestamp = new Date(newDate).getTime();
    }


    if (timestamp == 0) {
      this.endDate = '';
    } else {
      let postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        polStartDate: this.appUtilObj.getUTCDate(timestamp)
      }

      console.log(JSON.stringify(postData));
      this.homeInsurancePlanService.updatePolicyDuration(postData).subscribe((data: any) => {
        console.log(data);
        let endDate = new Date(data.polEndDate);
        this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
      })
    }

  }

  setDefaultValues() {
    this.carInformation.financedBank = '';
    this.carInformation.vehColor = '';
    this.genderValue = '';
    let data = {
      'transId': this.transId,
      'tranSrNo': this.tranSrNo
    };
    this.commonService.getQuoteInfo(data).subscribe((response: any) => {

      this.quoteInfo = response;
      this.quoteNo = this.quoteInfo.quoteNo;
      this.insuredNameValue = this.quoteInfo.insName;
      this.emiratesIdValue = this.quoteInfo.civilId;

      this.nationalityValue = this.quoteInfo.nationality;
      this.nationalityDesc = this.quoteInfo.nationalityDesc;
      this.poBox = this.quoteInfo.poBox;
      this.ifTelematics = this.quoteInfo.telematicsYn;
      if (this.quoteInfo.gender != null || this.quoteInfo.gender != undefined) {
        this.genderValue = this.quoteInfo.gender;
      }

      console.log('response from get quote insured info');
      console.log(response.prodShortDesc);
      if (response.prodShortDesc == 'TP') {
        this.isThirdPartySelected = true;
        console.log(this.isThirdPartySelected);
        this.applyProcessNavTabs = 'process-two-tab process-row nav nav-tabs';
        $('.box-shadow').show();
        $('.container').show();
      } else {
        this.isThirdPartySelected = false;
        this.applyProcessNavTabs = 'process-three-tab process-row nav nav-tabs';
        $('.box-shadow').show();
        $('.container').show();
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
      $('.box-shadow').show();
      $('.container').show();
    });

    this.commonService.getQuoteVehInfo(data).subscribe(response => {
      console.log('response from get quote insured info');
      console.log(response);
      this.prePopulateFields(response);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
    });

  }

  prePopulateFields(responseObj) {
    let checkFields = window.location.href.indexOf('/renew-policy') > -1 ? true : false
    if (this.nationalityDesc == null || this.nationalityDesc == '') {
      this.nationalityDesc = responseObj.nationalityDesc;
    }
    let date: Date = new Date(responseObj.polStartDate);
    this.startDate = { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
    //console.log(this.startDate);

    //End date check
    let timestamp = new Date(responseObj.polStartDate).getTime();
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      polStartDate: this.appUtilObj.getUTCDate(timestamp)
    }
    console.log(JSON.stringify(postData));
    this.homeInsurancePlanService.updatePolicyDuration(postData).subscribe((data: any) => {
      console.log(data);
      let endDate = new Date(data.polEndDate);
      this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
    })

    // if (this.genderValue == null || this.genderValue == undefined || this.genderValue == '') {
    //  this.genderValue = responseObj.gender;
    // }
    if (responseObj.regnLoc != null) {
      if (responseObj.plateChar && responseObj.plateCharDesc) {
        this.selectedPlateChar = [{ id: responseObj.plateChar, text: responseObj.plateCharDesc }];
      }
      this.selectedRegnLoc = responseObj.regnLoc; // [{ id: responseObj.regnLoc, text: responseObj.regnLocDesc }];
      this.carInformation.plateChar = '';
      // this.carInformation.financedBank = responseObj.financedBank;
      this.disableRegnLoc = checkFields;
    }

    this.getPlateCharacters();
    if (responseObj.financedBank != null) {
      this.selectedBank = [{ id: responseObj.financedBank, text: responseObj.financedBankDesc }]
      // this.carInformation.financedBank = responseObj.financedBank;
      this.disableFinancedBank = checkFields;
    }
    if (responseObj.vehColor != null) {
      this.selectedColor = [{ id: responseObj.vehColor, text: responseObj.vehColorDesc }];
      this.disableVehColor = checkFields;
      // this.carInformation.vehColor = responseObj.vehColor;
    }
    if (responseObj.engineNo != null) {
      this.carInformation.engineNo = responseObj.engineNo;
      this.disableEngineNo = checkFields;
    }
    if (responseObj.licenceNo != null) {
      this.carInformation.licenceNo = responseObj.licenceNo;
      this.disableLicenceNo = checkFields;
    }
    if (responseObj.regnNo != null) {
      this.carInformation.regnNo = responseObj.regnNo;
      this.disableRegnNo = checkFields;
    }
    if (responseObj.tcfNo != null) {
      this.carInformation.tcfNo = responseObj.tcfNo;
      this.disableTcfNo = checkFields;
    }
    this.carInformation.chassisNo = responseObj.chassisNo;
    if (responseObj.city != null) {
      this.selectedCity = [{ id: responseObj.city, text: responseObj.cityDesc }]
    }

    if (responseObj.ncdYear) {
      this.ncdYear = responseObj.ncdYear;
    }

    if (responseObj.insValidYN != null) {
      //this.insuranceValid =   responseObj.insValidYN;
      this.insuranceValid = [{ id: responseObj.insValidYN, text: this.insValidDesc[responseObj.insValidYN] }]
    }
    if (responseObj.mileage) {
      this.carInformation.mileage = responseObj.mileage;
    }
    if (responseObj.vehPlateCode) {
      this.vehPlateCode = responseObj.vehPlateCode;
    }

    this.loaderService.display(false);
  }
  validateChassi(value: any) {
    let postData = {
      transId: this.quoteInfo.transId,
      tranSrNo: this.quoteInfo.tranSrNo,
      civilId: this.quoteInfo.civilId,
      chassisNo: this.carInformation.chassisNo
    }
    this.carInsurancePlanService.allowChassisNo(postData).subscribe(data => {
      let postData = {
        transId: this.quoteInfo.transId,
        tranSrNo: this.quoteInfo.tranSrNo,
        chassisNo: this.carInformation.chassisNo
      }
      this.carInsurancePlanService.validateDuplicateChassisNo(postData).subscribe(data => {
        this.isValidChassiNo = true;
      }, error => {
        //let err = error.json();
        this.isValidChassiNo = false;
        this.chassiErr = this.appUtilObj.displayError(error['_body'], this.quoteNo);
        //alert('1 : ' +this.chassiErr);
      })
    }, error => {
      //let err = error.json();
      this.isValidChassiNo = false;
      this.chassiErr = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      //this.loaderService.display(false);
      //alert('2 : ' +this.chassiErr);
    })
  }

  validateChassisPkg(value: any) {
    let postData = {
      transId: this.quoteInfo.transId,
      tranSrNo: this.quoteInfo.tranSrNo,
      chassisNo: this.carInformation.chassisNo
    }
    this.carInsurancePlanService.validateDuplicateChassisNoPkg(postData).subscribe((data: any) => {
      if ("1" == data.validYN) {
        this.isValidChassiNo = true;
      } else {
        this.isValidChassiNo = false;
      }
    }, error => {
      let err = error.json();
      this.isValidChassiNo = false;
      let obj = {
        quoteNo: this.quoteNo
      }
      this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
      //this.loaderService.display(false);
      //alert('2 : ' +this.chassiErr);
    })
  }
  getCity() {
    this.commonService.getApplicationRefCodes('STATE', '002').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      arr.reverse()
      // var tmpArr = data.appCodesArray.reverse();
      this.cityList = this.appUtilObj.sortedArray(arr);


    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  // getInsValid(insValidYn){
  //    let id;
  //    let text;
  //   if(insValidYn=1){
  //     id=1;
  //     text='Yes';
  //   } else if(insValidYn=0){
  //     id=0;
  //     text='No';
  //   } else {
  //     id=2;
  //     text='';
  //   }

  // }


  goToPreviousPage() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      lobCode: '01',
      carInsType: this.carInsType.toString(),
      vehicleType: this.vehicleType
    }
    this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
  }
  onDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.startDate = event.target.value;
        }
      }
    }

  }


  setGenderList() {
    let get_genderList = { 'paraType': 'GENDER' };
    this.commonService.getGenderList(get_genderList)
      .subscribe(result => {
        this.gender_list = result.appParamsArray;
        this.gender = '';
        //console.log(result);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error['_body'], null);
        this.loaderService.display(false);
      });
  }

  getPlateCodeList() {
    this.commonService.getApplicationCodes('MOT_PLAT_TYP').subscribe(data => {
      let arr = [];
      for (let i = 0; i < data.appCodesArray.length; i++) {
        let id = data.appCodesArray[i].code;
        let text = data.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      // var tmpArr = data.appCodesArray.reverse();
      this.plate_code_list = this.appUtilObj.sortedArray(arr);
      console.log(this.plate_code_list);
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error['_body'], this.quoteNo);
      this.loaderService.display(false);
    });
  }
  setDrivingExp() {
    this.drivingExperience = this.getCarQuoteService.getDrivingExperience();
  }


}
