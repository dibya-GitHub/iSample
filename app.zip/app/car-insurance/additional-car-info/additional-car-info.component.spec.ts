import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalCarInfoComponent } from './additional-car-info.component';

describe('AdditionalCarInfoComponent', () => {
  let component: AdditionalCarInfoComponent;
  let fixture: ComponentFixture<AdditionalCarInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalCarInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalCarInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
