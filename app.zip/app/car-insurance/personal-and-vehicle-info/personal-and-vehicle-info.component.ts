import { AfterViewInit, Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { RecaptchaComponent } from 'ng-recaptcha';
import { InsuredDetails } from "src/app/car-insurance/classes/insured-details";
import { InsuredVehicleDetails } from "src/app/car-insurance/classes/insured-vehicle-details";
import { CarInsurancePlanService } from "src/app/car-insurance/services/car-insurance-plan.service";
import { MotorDropDownService } from "src/app/car-insurance/services/motor-drop-down.service";
import { ApiConstants } from "src/shared/api-constants";
import { Gender } from "src/shared/classes/gender";
import { RegistrationLocation } from "src/shared/classes/registration-location";
import { VehicleCylinder } from "src/shared/classes/vehicle-cylinder";
import { VehicleModel } from "src/shared/classes/vehicle-model";
import { VehicleType } from "src/shared/classes/vehicle-type";
import { InsuranceService } from 'src/shared/services/insurance.service';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { TooltiptList } from "src/shared/tooltip-list";
import { environment } from '../../../environments/environment';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';

@Component({
  selector: 'personal-and-vehicle-info',
  templateUrl: './personal-and-vehicle-info.component.html',
  styleUrls: ['./personal-and-vehicle-info.component.scss'],

})
export class PersonalAndVehicleInfoComponent implements OnInit, AfterViewInit {

  vehicleSelected: boolean = true;
  vehicleSelectedFlag: any = 0;
  showMsg: boolean = false;
  dropDownload = true;
  @ViewChild('captcha') captcha: RecaptchaComponent;
  @ViewChildren('input') vc;
  vehicle_types: VehicleType[];
  vehicle_makes: Array<any>;
  vehicle_models: VehicleModel[];
  vehicle_cylinders: VehicleCylinder[];
  registration_locations: RegistrationLocation[];
  import_country_list: Array<any>;
  gender_list: Gender[];
  nationality_list: Array<any>;
  responseFromCreateQuote: any;
  responseFromUpdateInsuredInfo: any;
  ip: string;
  vehicleData = new InsuredVehicleDetails();
  perslData = new InsuredDetails();
  seating: any;
  drivingExperience: any;
  ncdOptions: any;
  carDetails = new InsuredVehicleDetails();
  insuredData: boolean;
  isFirstPage: boolean = true;
  insuranceType: any;
  vehUsageArray: any = [];
  vehicleOptionSelected: any;
  date: Date = new Date();
  manfYear: any;
  cusYear: number;
  public startDateOptions: IAngularMyDpOptions = {
    // other options...
    inline: false,
    // editableDateField:true,
    // indicateInvalidDate:true,
    // openSelectorOnInputClick: true,
    // showInputField:true,
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    }
  };
  yearArray: any = [];
  setFieldDisabled: boolean = true;
  appUtilObj: AppUtil = new AppUtil();
  errorMsg: string = '';
  showCaptchaErr = false;
  captchaErr: any;
  campaignCar: any;
  promoCode: any = '';
  promoCodeError: any = '';
  siteKey: any = environment.siteKey;
  ifTelematics: boolean = false;
  nationalityObject: any;

  public tootipMessage = new TooltiptList();
  autoData: any;
  canDisabledClylinders: string;
  canDisabledSeats: string;
  canDisabledVehicleValue: string;
  canDisabledModelYear: string;
  canDisableMake: string;
  canDisableModel: string;
  canDisableVehType: string;
  autoDataErr: string;
  
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private getCarQuoteService: MotorDropDownService,
    private insuranceService: InsuranceService,
    private carInsurancePlanService: CarInsurancePlanService,
    private loaderService: LoaderService,
    private pixelService: RocketFuelService
  ) {
    this.setDrivingExp();
    this.setNcdOptions();
    /*getting vechicle type*/
    /*getting Vehicle make*/

    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
    });
    if (window.localStorage.getItem('type') == 'TP') {
      this.setVehicleType('TP');
    } else {
      this.setVehicleType('OD');
    }

    /*Telematics Changes
    this.route.queryParams.subscribe(params => {
      if(params["ifTelematics"]==="true"){
        this.ifTelematics = true;
        this.promoCode = "703446";
        this.setVehicleType('OD');
      }
    });*/


    if (window.location.href.indexOf("/safe-driver") > -1) {
      this.ifTelematics = true;
      this.promoCode = "703446";
      this.setVehicleType('OD');
    }
    /*Telematics Changes*/
  }
  ngAfterViewInit() {
    // this.vc.first.nativeElement.focus();
  }
  ngOnInit() {
    this.cusYear = new Date().getFullYear() + 1;
    if (window.localStorage.getItem("carCampaignDetails")) {
      this.campaignCar = JSON.parse(window.localStorage.getItem("carCampaignDetails"))
      this.vehicleData.sumAssured = this.campaignCar["carValue"];
      this.perslData.insName = this.campaignCar["name"];
      this.perslData.emailId = this.campaignCar["email"];
      this.perslData.mobileNo = this.campaignCar["mobile"];
      this.perslData.civilId = this.campaignCar["civilId"];
      if (this.campaignCar["nationality"]) {
        this.perslData.nationality = [{ id: this.campaignCar["nationality"], text: this.campaignCar["nationalityDesc"] }]
      }
    }
    window.localStorage.removeItem('carCampaignDetails');
    window.scrollTo(0, 0);
    this.getDefaults();
    let year = new Date().getFullYear();
    for (let i = year; i > (year - 16); i--) {
      this.yearArray.push(i);
    }
    /*getting IP address*/
    this.setIP();
    /*setting number of cylinder*/
    this.setCylinderList();
    /*setting gender dropdown*/
    this.setGenderList();
    /*setting country list*/
    this.setCountrylist();
    /*setting registration locations*/
    this.setRegLocationList();
    /*setting driving experince dropdown*/
    // this.setDrivingExp();
    /*setting Seating Capacity dropdown*/
    this.setSeatingCapacity();
    this.ImportCountryList();
    //this.getModel();
    this.setVehicleMake();
    this.route.queryParams.subscribe((param: any) => {
      if (param && param.selection) {
        this.autoData = JSON.parse(param.selection);
        this.setAutoData();
      }
      if (param && param.errMsg) {
        this.autoDataErr = param.errMsg;
      }
      setTimeout(() => this.loaderService.display(false), 2000);
      // this.loaderService.display(false);
    });
  }

  /*getting IP address*/
  setIP() {
    this.insuranceService.getIPAddress().subscribe(result => {
      this.ip = result.ip;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error, null);
      this.loaderService.display(false);
    });
  }
  setVehicleTypeNew(data) {

    this.vehicleData.vehBodyType = data;

    this.vehicleSelectedFlag = 1;
    if (this.vehicleSelectedFlag = 1) {
      this.vehicleSelected = true;
    }

    this.setVehicleUsage(data);
    // this.getDefaultsForCompVehiclTypeChange();
  }
  getDefaultsForCompVehiclTypeChange() {
    this.vehicleData.vehMake = "";
    this.vehicleData.vehModel = "";
  }
  getDefaults() {
    this.vehicleData.vehBodyType = "";
    this.vehicleData.vehMake = "";
    this.vehicleData.vehModel = "";
    this.vehicleData.seatingCty = '';
    this.vehicleData.firstRegYear = '';
    this.vehicleData.licenceAge = "";
    this.vehicleData.firstRegAge = "";
    this.vehicleData.vehCylinders = ""
    this.vehicleData.regnLoc = "";
    this.vehicleData.ncdYear = '';
  }
  setDrivingExp() {
    this.drivingExperience = this.getCarQuoteService.getDrivingExperience();
  }

  setNcdOptions() {
    this.ncdOptions = this.getCarQuoteService.getNcdOptions();
  }
  setSeatingCapacity() {
    this.seating = this.getCarQuoteService.getSeatingCapacity();
  }

  /*getting vechicle type*/
  setVehicleType(data: any) {
    this.vehicleData.firstRegYear = '';
    this.vehicleOptionSelected = data;
    if (data == 'TP') {
      this.setFieldDisabled = false;
      //this.vehicleData.gccSpecYN = "";
      this.ifTelematics = false;
      this.promoCode = "";
      this.vehicleData.gccSpecYN = "0";
    } else if (data == 'TPL') {
      this.setFieldDisabled = false;
      //this.vehicleData.gccSpecYN = "";
      this.ifTelematics = false;
      this.promoCode = "";
      this.vehicleData.gccSpecYN = "";
    } else {
      this.vehicleData.gccSpecYN = "";
      this.setFieldDisabled = true;
      if (window.location.href.indexOf("/safe-driver") > -1) {
        this.ifTelematics = true;
        this.promoCode = "703446";
      }


    }
    let v_type = { "agentId": "", "insuranceType": data, "portal": "D" }
    //console.log(JSON.stringify(v_type));
    this.getCarQuoteService.getVehicleType(v_type).subscribe(
      result => {
        this.vehicle_types = result.typeArray;
        if (this.autoData && this.autoData.bodyType) {
          this.vehicleData.vehBodyType = this.autoData.bodyType; // [ ]
          const vehicleType = this.vehicle_types.find((type: any) => type.VEHTYPECODE === this.autoData.bodyType);
          this.setVehicleTypeNew(this.vehicleData.vehBodyType);
          this.setVehicleUsage(vehicleType.VEHTYPECODE);
          this.canDisableVehType = 'disabled';
        } else {
          this.vehicleData.vehBodyType = '';
          this.vehicleData.vehMake = '';
          this.vehicleData.vehModel = '';
          this.setVehicleUsage(result.typeArray[0].VEHTYPECODE);
        }
        //console.log("body Type", JSON.stringify(this.vehicle_types));
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }
  setVehicleUsage(data) {
    let v_usage = { "portal": "D", "vehType": data }
    this.getCarQuoteService.getVehicleUsage(v_usage).subscribe(data => {
      this.vehUsageArray = data.usageArray;
      this.vehicleData.vehUsage = '';
      console.log(data.usageArray);
      this.vehicleData.vehUsage = "";
      if (this.dropDownload == false) {
        //this.getDefaults();
        this.dropDownload = true;
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  setGcc(data: any) {
    //this.vehicleData.firstRegYear = '';
    if (data == 0 && this.setFieldDisabled == false) {
      //this.setFieldDisabled = false;
      //this.setVehicleType('TP');
    } else if (data == 0 && this.setFieldDisabled == true) {
      this.setFieldDisabled = false;
      this.setVehicleType('TP');
    }
  }

  setAutoData() {
    // this.vehicleData.vehBodyType = this.autoData.bodyType;
    // this.vehicleData.vehMake = this.autoData.vehMake;
    // this.vehicleData.vehModel = this.autoData.vehModel;
    /*  if (this.autoData.cylinders) {
        this.vehicleData.vehCylinders = this.autoData.cylinders;
        this.canDisabledClylinders = 'disabled';
      }*/
    if (this.autoData.seats) {
      this.vehicleData.seatingCty = this.autoData.seats;
      this.canDisabledSeats = 'disabled';
    }
    if (this.autoData.vehicleValue) {
      this.vehicleData.sumAssured = this.autoData.vehicleValue;
      // this.canDisabledVehicleValue = 'disabled';
    }
    if (this.autoData.modelYear) {
      this.manfYear = this.autoData.modelYear;
      this.canDisabledModelYear = 'disabled';
    }

  }

  /*getting Vehicle make*/
  setVehicleMake() {
    let v_make = { "userId": "online" };
    this.getCarQuoteService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.vehicle_makes = arr;
        if (this.autoData && this.autoData.vehMake) {
          this.vehicleData.vehMake = [this.vehicle_makes.find(veh => veh.id === this.autoData.vehMake)];
          this.canDisableMake = 'disabled';
          this.getModel({ id: this.vehicleData.vehMake[0].id });
        }
        // this.setAutoData();
        // this.vehicle_makes = result.makeArray;
        // this.vehicleData.vehMake = "";
        // this.getModel();
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  /*setting cylinder list*/
  setCylinderList() {
    let v_cylinder = { "type": "MOT_VEH_NOC" };
    this.getCarQuoteService.getVehicleCylinderList(v_cylinder)
      .subscribe(result => {
        this.vehicle_cylinders = result.appCodesArray;
        if (this.autoData && this.autoData.vehModel) {
          this.vehicleData.vehCylinders = this.autoData.cylinders;
          this.canDisabledClylinders = 'disabled';
        }
        //this.vehicleData.vehCylinders = this.vehicle_cylinders[0].code;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  setGenderList() {
    let get_genderList = { "paraType": "GENDER" };
    this.insuranceService.getGenderList(get_genderList)
      .subscribe(result => {
        this.gender_list = result.appParamsArray;
        this.perslData.gender = "";
        //console.log(result);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  /*setting country list*/
  setCountrylist() {
    let get_nationaLitylist = { "type": "NATIONALITY" };
    this.insuranceService.getNationalityList(get_nationaLitylist)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        let sortedArr = this.sortNationality(arr);
        this.nationality_list = sortedArr
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  ImportCountryList() {
    let get_nationaLitylist = { "type": "COUNTRY" };
    this.insuranceService.getImportCountryList(get_nationaLitylist)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.import_country_list = arr;
        console.log(this.import_country_list);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  /*setting registration locations*/
  setRegLocationList() {
    let location = { "type": "REGN_LOC" }
    this.getCarQuoteService.getRegistrationLocationList(location)
      .subscribe(result => {
        this.registration_locations = result.appCodesArray;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  /*getting vehicle model based on Vehicle make*/
  getModel(event) {
    // this.vehicleData.vehMake = event.id;
    let postData = {
      type: "MOT_VEH_MOD",
      refCode: event.id
    }
    this.getCarQuoteService.getVehicleModelList(postData).subscribe(result => {
      //console.log(JSON.stringify(response.json()));
      let arr = [];
      for (let i = 0; i < result.appCodesArray.length; i++) {
        let id = result.appCodesArray[i].code;
        let text = result.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      this.vehicle_models = arr;
      if (this.autoData && this.autoData.vehModel) {
        this.vehicleData.vehModel = [this.vehicle_models.find((veh: any) => veh.id === this.autoData.vehModel)];
        this.autoData.vehModel = undefined;
        this.canDisableModel = 'disabled';
      }
      // this.vehicleData.vehModel = "";
      if (this.dropDownload == true) {
        //this.getDefaults();
        this.dropDownload = false;
      }
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });

  }

  addVehicleMake(event) {
    this.carDetails.vehModel = event.id
  }

  addNationality(event) {
    this.carDetails.nationality = event.id
  }
  /*function to submit vehicle detail*/

  onSubmit(carDetailform, perslData) {

    if (this.vehicleSelectedFlag == 0 && this.setFieldDisabled) {
      this.vehicleSelected = false;
      return false;
    }
    if (this.manfYear > (this.cusYear) || this.manfYear < 1000) {
      return false;
    }
    if (+this.vehicleData.firstRegYear >= (this.cusYear) || +this.vehicleData.firstRegYear < 1000) {
      return false;
    }
    var currentDate = new Date();
    var displayDate = currentDate.toISOString();
    this.carDetails = carDetailform;
    this.carDetails['psgrLiabSeatCty'] = String(parseInt(carDetailform.seatingCty) - 1);
    console.log("Seating Capacity-------------------" + this.carDetails['psgrLiabSeatCty']);
    //this.carDetails['vehUsage'] = carDetailform.vehBodyType;
    this.carDetails["firstRegAge"] = (new Date().getFullYear() - parseInt(this.carDetails['firstRegYear'])).toString();
    if (this.setFieldDisabled) {
      this.carDetails.vehMakeDesc = this.carDetails["vehMake"][0].text
      this.carDetails.vehMake = this.carDetails["vehMake"][0].id
      this.carDetails.vehModelDesc = this.carDetails["vehModel"][0].text
      this.carDetails.vehModel = this.carDetails["vehModel"][0].id
    }
    console.log("Car details submitted ", this.carDetails)
    this.pixelService.pixelFireValue('Universal');
    this.pixelService.pixelFireValue('2');
    this.personalData(perslData)
    //this.isFirstPage = false;
    //document.body.scrollTop = document.documentElement.scrollTop = 0;
  }
  personalData(f2) {
    // if (this.captcha.execute) {
    //   this.captchaErr = 'Please Validate Captcha';
    //   this.showCaptchaErr = true;
    //   return false;
    // } else {
    //   this.showCaptchaErr = false;
    // }
    window.localStorage.removeItem('type');
    if (f2.nationality[0].id != undefined) {
      this.nationalityObject = f2.nationality;
      f2.nationality = f2.nationality[0].id
    }
    //let dateString=insuredData.value.insDob.formatted;
    //this.insuredData =false;
    this.loaderService.display(true);
    let currentDate = new Date();
    let displayDate = currentDate.toISOString();
    let dateString = f2.insDob.formatted;

    if (dateString == undefined) {
      dateString = f2.insDob;
    }
    console.log("is NAN " + dateString);
    if (!this.setFieldDisabled) {
      //this.vehicleData.gccSpecYN = "0";
      this.vehicleData.vehMake = "";
      this.vehicleData.vehModel = "";
    } else {
      this.vehicleData.gccSpecYN = "1";
      this.vehicleData.vehUsage = "1001";
    }

    //  console.log(f2.value.insDob.formatted+'T00:00:00.000Z')
    if (f2.insDob.epoc != undefined) {
      this.carDetails["driverDob"] = this.appUtilObj.getUTCDate(f2.insDob.epoc * 1000);
    } else {
      const stringDate = dateString.split("/");
      const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2]
      let tempdate = new Date(newDate);
      this.carDetails["driverDob"] = this.appUtilObj.getUTCDate(tempdate.getTime());
    }

    if (this.getAgeValidate(dateString) == true) {
      this.loaderService.display(false);
      return false;
    }
    //console.log(this.vehicleData.driverDob)
    //alert(this.getAge(dateString));
    if (this.getAge(dateString) < 25 || parseInt(this.vehicleData.licenceAge) < 1) {
      this.vehicleOptionSelected = 'TP';
      this.vehicleData.sumAssured = "0";
      this.vehicleData.gccSpecYN = "0";
    }
    /**
     * parameter for get quote for car insurance
     */
    let paramForcreateQuote = {
      "lobCode": ApiConstants.CAR_INSURANCE_LOBCODE,
      "portal": "D", "location": "D",
      "userId": "online", "bundleYN": "0", "ipAddress": this.ip,
      "sourceMkting": "", "campaignMkting": "", "promoCode": this.promoCode,
      "polStartDate": displayDate, prodShortDesc: this.vehicleOptionSelected
    };
    this.carDetails["driverAge"] = this.getAge(dateString) + '';
    //this.carDetails["nationality"] = f2.nationality
    //this.vehicleData.licenceAge=f2.value.drivingExp;
    this.carDetails["gender"] = f2.gender;
    this.carDetails["regnLoc"] = this.vehicleData.regnLoc;

    this.perslData.insDob = dateString;
    console.log(this.carDetails);
    /**
     * creating information
     */
    this.insuranceService.createQuote(paramForcreateQuote).subscribe(result => {
      this.responseFromCreateQuote = result;
      console.log("create Quote response");
      console.log(result);
      let obj = {
        transId: this.responseFromCreateQuote.transId,
        tranSrNo: this.responseFromCreateQuote.tranSrNo,
        quoteNo: this.responseFromCreateQuote.quoteNo,
        seatingCapacity: this.carDetails['psgrLiabSeatCty'],
        lobCode: ApiConstants.CAR_INSURANCE_LOBCODE,
        registrationYear: this.carDetails['firstRegYear'],
        licenceAge: this.carDetails['licenceAge'],
        vehicleType: this.vehicleOptionSelected
      }
      // Updating insured person information
      if (result.respCode == 2000) {
        if (this.setFieldDisabled == true) {
          f2['mapId'] = "MOT_COMP_POL_SCR_1";
        } else {
          f2['mapId'] = "MOT_TP_POL_SCR_1";
        }
        f2["transId"] = obj.transId;
        f2["tranSrNo"] = obj.tranSrNo;
        f2["vehCylinders"] = this.vehicleData.vehCylinders;
        f2["insAge"] = this.getAge(dateString);
        f2["nationality"] = this.perslData.nationality;
        f2["gender"] = this.perslData.gender;
        let personalDataJson = JSON.stringify(f2);
        console.log("======ins info=====")
        console.log(JSON.stringify(personalDataJson));
        this.insuranceService.updateInsuredInfo(personalDataJson).subscribe((updateInfoResult: any) => {
          this.responseFromUpdateInsuredInfo = updateInfoResult;
          console.log("update insured info");
          console.log(this.responseFromUpdateInsuredInfo);
          console.log(2);
          if (updateInfoResult.respCode == 2000) {
            // this.vehicleData.transId = this.responseFromCreateQuote.transId;
            // this.vehicleData.tranSrNo =this.responseFromCreateQuote.tranSrNo;
            this.carDetails["transId"] = this.responseFromCreateQuote.transId;
            this.carDetails["tranSrNo"] = this.responseFromCreateQuote.tranSrNo;
            this.carDetails["nationality"] = this.perslData.nationality;
            if (this.setFieldDisabled == true) {
              this.carDetails['mapId'] = "MOT_COMP_RISK_SCR_1";
            } else {
              this.carDetails['mapId'] = "MOT_TP_RISK_SCR_1";
            }
            this.carDetails['userId'] = "online";
            if (this.vehicleOptionSelected == 'TP') {
              this.carDetails['sumAssured'] = "0";
            }
            this.carDetails["manfYear"] = this.manfYear;
            this.carDetails["vehAge"] = new Date().getFullYear() - parseInt(this.manfYear);
            if (this.vehicleOptionSelected != 'TP' && this.autoDataErr == undefined) {
              this.carDetails["chassisNo"] = this.autoData.chassisNo;
            }
            let vehicleDataJson = JSON.stringify(this.carDetails);
            console.log(vehicleDataJson);

            this.carInsurancePlanService.updateVehicleInfo(vehicleDataJson).subscribe((updateVehicleInfo: any) => {
              console.log("update vehicle info");
              console.log(updateVehicleInfo);
              if (updateVehicleInfo.respCode == 2000) {
                var strPostData = { "transId": this.responseFromCreateQuote.transId, "tranSrNo": this.responseFromCreateQuote.tranSrNo, "portal": ApiConstants.PORTAL, "userId": ApiConstants.USER_ID, lobCode: ApiConstants.CAR_INSURANCE_LOBCODE }
                console.log(strPostData);

                this.insuranceService.calculatePricing(JSON.stringify(strPostData)).subscribe((response: any) => {
                  console.log("calculate Response");
                  console.log(response);
                  //  this.loaderService.display(false);
                  if (response.respCode == 2000) {
                    this.pixelService.pixelFireValue('Universal');
                    this.pixelService.pixelFireValue('3');
                    this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
                  }

                }, error => {
                  console.log("Inside calPricing error");
                  let obj = {
                    quoteNo: this.responseFromCreateQuote.quoteNo
                  }
                  this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
                  // this.errorMsg = this.appUtilObj.displayError(error["_body"], this.responseFromCreateQuote.quoteNo);
                  this.loaderService.display(false);
                });


                //this.router.navigate(['/car-insurancePlan']);
              }
            }, error => {
              this.errorMsg = this.appUtilObj.displayError(error["_body"], this.responseFromCreateQuote.quoteNo);
              this.loaderService.display(false);
            });
          }
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.responseFromCreateQuote.quoteNo);
          this.loaderService.display(false);
        });
      }
    }, error => {
      let err = error.json();
      f2.nationality = this.nationalityObject;
      if (err.respCode == "5005") {
        this.promoCodeError = err.errMessage;
      } else {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      }
      this.loaderService.display(false);
    });
  }
  /* function to calculate age */
  getAge(dateString) {
    console.log(dateString + " DOB")

    let parts = dateString.split('/');
    let age: any;
    let today = new Date();
    console.log(today);
    let birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
    console.log(birthDate);

    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }
  back() {
    window.onbeforeunload = function () {
      window.scrollTo(0, 0);
    }
    this.vehicleData.vehMake = [{ id: this.carDetails.vehMake, text: this.carDetails.vehMakeDesc }]
    this.vehicleData.vehModel = [{ id: this.carDetails.vehModel, text: this.carDetails.vehModelDesc }]
    this.isFirstPage = true;
  }
  onDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.perslData.insDob = event.target.value;
        }
      }
    }
    console.log(this.perslData.insDob)
  }

  onDateChanged(event) {
    if (this.perslData.insDob != undefined || this.perslData.insDob == null) {
      this.showMsg = false;
      //console.log(this.perslData.insDob)
    }
    //console.log(this.perslData.insDob)
  }
  getAgeValidate(dateString: any) {
    if (dateString == '' || dateString == undefined) {
      return false;
    } else {
      //console.log(dateString)
      //let dobOf:string = dateString.formatted;
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {
        let parts = dateString.split('/');
        birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }

      //const date = this.appUtilObj.getUTCDate(timestamp);
      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age < 18) {
        return true;
      } else if (age > 70) {
        return true;
      }
      else {
        return false;
      }

    }

  }

}
