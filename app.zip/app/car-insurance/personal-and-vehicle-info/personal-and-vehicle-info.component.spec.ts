import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalAndVehicleInfoComponent } from './personal-and-vehicle-info.component';

describe('PersonalAndVehicleInfoComponent', () => {
  let component: PersonalAndVehicleInfoComponent;
  let fixture: ComponentFixture<PersonalAndVehicleInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalAndVehicleInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalAndVehicleInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
