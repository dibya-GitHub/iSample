export class UserData {
  insType:number;
  name: string;
  chassisNo: string;
  mobileNo: string;
  emailId: string;
}
