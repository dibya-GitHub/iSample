import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstScreenMotorComponent } from './first-screen-motor.component';

describe('FirstScreenMotorComponent', () => {
  let component: FirstScreenMotorComponent;
  let fixture: ComponentFixture<FirstScreenMotorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FirstScreenMotorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstScreenMotorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
