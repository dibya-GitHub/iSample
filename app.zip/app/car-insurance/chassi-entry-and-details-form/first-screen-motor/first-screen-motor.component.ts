import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AutoDataService } from 'src/app/car-insurance/services/autodata.service';
import { MotorDropDownService } from 'src/app/car-insurance/services/motor-drop-down.service';
import { ApiConstants } from 'src/shared/api-constants';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { InsuranceService } from 'src/shared/services/insurance.service';

@Component({
  selector: 'app-first-screen-motor',
  templateUrl: './first-screen-motor.component.html',
  styleUrls: ['./first-screen-motor.component.scss']
})
export class FirstScreenMotorComponent implements OnInit {
  date = new Date();
  public spin: Boolean = false;
  // ToolTip
  // public tooltipMessgae = new Tooltip();

  // Error Message
  // public Err_msg = new ErrorMessage();

  // public validator = new ValidatorService();
  edataError: string;
  chassisForm: FormGroup;
  vehModelDetailsForm: FormGroup;
  specificationForm: FormGroup;
  public edataVehiInfoFlag = false;
  withoutChesisno: boolean = false;
  withoutChassisNoFlag: boolean;
  quoteNo: string;
  chassisNo: string;
  transId: string;
  tranSrNo: string;
  VehModalYearError;
  vehMakeError;
  vehModalError;
  vehTrimError;
  vehBodyTypeError;
  vehEngSizeError;
  public modelList: Array<any>;
  public makeList: Array<any>;
  public specificationsList: Array<any>;
  yearArray: any = [];
  ip: string;

  formSubmitAttempt = false;
  @ViewChild('someModal') someModal: ElementRef;
  canShowSpecification: boolean = false;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private autoDataService: AutoDataService,
    private motorDropDownService: MotorDropDownService,
    private loaderService: LoaderService,
    private insuranceService: InsuranceService
    // public carInsurancePlanService: AutoDataService,
    ) {

  }

  ngOnInit() {
    this.loaderService.display(false);
    this.chassisForm = this.fb.group({
      chassisNo: ['', Validators.required]
    });
    this.insuranceService.getIPAddress().subscribe(result => {
      this.ip = result.ip;
      console.log(this.ip)
    }, error => {
      // this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
    const year = new Date().getFullYear();
    for (let i = year; i > (year - 5); i--) {
      // console.log('year',i)
      this.yearArray.push(i);
    }
  }


  onClickSubmit(form) {

    this.formSubmitAttempt = true;
    if (this.chassisForm.valid) {
      this.spin = true;
      this.chassisNo = form.chassisNo;
      const param = {
        'chassisNo': form.chassisNo,
        'ipAddress': this.ip
      };
      console.log('param', param);
      this.loaderService.display(true);
      this.autoDataService.getVehicleInfoFromChassisNo(param)
        .subscribe(response => {
          if (response.respCode === '1001') {
            // this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: response.errMessage });
            // timer(3000).subscribe(res =>);
            this.router.navigate(['car-insurance-without-chassi'], {
              queryParams: { errMsg: response.errMessage }
            });
          } else {
            delete response.errMessage;
            delete response.respCode;
            console.log(response);
            this.initModelDetailsForm(response);
          }
        }, err => {
          console.log('getVehicleInfoFromChassisNo', err);
          this.loaderService.display(false);
        });
    } else {
      this.validateAllFormFields(this.chassisForm);
      console.error('InvalidForm');
    }

  }

  isAllCompleted(resolve) {
    if (this.withoutChesisno) {
      if (this.yearArray && this.makeList) {
        resolve();
      }
    }
    else {
      if (this.yearArray && this.makeList && this.modelList) {
        resolve();
      }
    }
  }

  getSelectOptions(vehicleInfo): Promise<any> {
    return new Promise((resolve, reject) => {
      // this.motorDropDownService.getVehicleUsage({}).subscribe(
      this.autoDataService.getModelYears().subscribe(
        res => {
          this.yearArray = res.modelyearArray;
          this.isAllCompleted(resolve);
        }, err => reject(err));
      this.autoDataService.getVehicleMakeList().subscribe(
        // this.motorDropDownService.getVehicleMake({}).subscribe(
        res => {
          this.makeList = res.vehMakeArray;
          this.isAllCompleted(resolve);
        }, err => reject(err));
      if (!this.withoutChesisno) {
        this.autoDataService.getVehicleModelList(vehicleInfo).subscribe(
          res => {
            this.modelList = res.vehModelArray;
            this.isAllCompleted(resolve);
          }, err => reject(err));
      }
    });
  }



  initModelDetailsForm(vehicleData: any) {
    this.getSelectOptions(vehicleData)
      .then(res => {
        this.edataVehiInfoFlag = true;
        this.vehModelDetailsForm = this.fb.group({
          vehModelYear: ['', Validators.required],
          vehMake: ['', Validators.required],
          vehModel: [undefined, Validators.required],
          admeId: ['']
        });
        this.vehModelDetailsForm.patchValue(vehicleData);
        this.loaderService.display(false);
      }).catch(err => {
        //console.log(JSON.stringify(err));
        this.loaderService.display(false);
      });
  }

  InitSpecificationForm(vehicleDetailsForm) {
    if (this.vehModelDetailsForm.valid) {
      this.loaderService.display(true);
      this.getVehicleSpecificationDetails()
        .then(res => {
          this.specificationForm = this.fb.group(
            {
              admeId: ['', Validators.required]
            }
          );
          this.edataVehiInfoFlag = false;
          this.canShowSpecification = true;
          this.loaderService.display(false);
        }).catch(err => {
          console.log(JSON.stringify(err));
          this.loaderService.display(false);
        });
    } else {
      this.validateAllFormFields(this.vehModelDetailsForm);
    }
  }

  getVehicleSpecificationDetails(): Promise<any> {
    return new Promise((resolve, reject) => {
      const request = Object.assign({}, this.vehModelDetailsForm.value, { chassisNo: this.chassisNo, withoutChassisNoFlag: this.withoutChesisno });
      delete request.admeId;
      this.loaderService.display(true);
      this.autoDataService.getSpecifications(request).subscribe(res => {
          if (res.respCode === '1001') {
            window.localStorage.setItem('type', 'OD');
            this.router.navigate(['car-insurance-without-chassi'], {
              queryParams: { errMsg: "Unable to find vehicle Details" }
            });
          } else {
            this.specificationsList = res.specification;
            this.vehModelDetailsForm.patchValue({ admeId: '' });
            const specCntrl = this.vehModelDetailsForm.get('admeId');
            specCntrl.setValidators([Validators.required]);
            specCntrl.updateValueAndValidity();
            this.vehModelDetailsForm.get('vehModelYear').disable();
            this.vehModelDetailsForm.get('vehMake').disable();
            this.vehModelDetailsForm.get('vehModel').disable();
            this.canShowSpecification = true;
          }
          this.loaderService.display(false);
          resolve({});
        }, err => {
          console.log(err);
          this.loaderService.display(false);
          reject(err);
        });
    });
  }
  onSubmit() {
    if (this.vehModelDetailsForm.valid) {

      if (this.canShowSpecification) {
        this.getTransactionId();
      } else {
        this.getVehicleSpecificationDetails();
      }
    } else {
      this.validateAllFormFields(this.vehModelDetailsForm);
    }
  }
  callNoChassis() {
    let obj = {
      "vehMake": "", "vehModelYear": "", "gccSpecYn": "", "vehModel": ""
    }
    this.withoutChesisno = true;
    this.initModelDetailsForm(obj);
  }
  getTransactionId() {
    if (this.vehModelDetailsForm.valid) {

      if (this.withoutChesisno) {
        this.vehModelDetailsForm.get('vehModelYear').enable();
        this.vehModelDetailsForm.get('vehMake').enable();
        this.vehModelDetailsForm.get('vehModel').enable();
      }

      let request = {
        chassisNo: this.chassisNo,
        admeId: this.vehModelDetailsForm.value.admeId,
        portal: ApiConstants.PORTAL,
        userId: ApiConstants.USER_ID,
        ipAddress: this.ip,
        vehMake: this.vehModelDetailsForm.get('vehMake').value,
        vehModel: this.vehModelDetailsForm.get('vehModel').value,
        vehModelYear: this.vehModelDetailsForm.get('vehModelYear').value
      };


      request = Object.assign({}, request, this.vehModelDetailsForm.value, { chassisNo: this.chassisNo, withoutChassisNoFlag: this.withoutChesisno });
      //const request =  { chassisNo: this.chassisNo, admeId: this.vehModelDetailsForm.value.admeId };
      this.loaderService.display(true);
      this.autoDataService.getQuoteData(request)
        .subscribe(res => {
          if (res.respCode === '1001') {
            this.router.navigate(['car-insurance-without-chassi'], {
              queryParams: { errMsg: res.errMessage }
            });
          } else {
            res.chassisNo = this.chassisNo;
            this.router.navigate(['car-insurance-without-chassi'], { queryParams: { selection: JSON.stringify(res) } });
          }
          this.loaderService.display(false);
        }, err => {
          console.log(err);
          this.loaderService.display(false);
        });
    } else {
      this.validateAllFormFields(this.vehModelDetailsForm);
    }
  }

  updateModelList() {
    const vehDetails = this.vehModelDetailsForm.value;
    if (vehDetails.vehMake) {
      this.loaderService.display(true);
      this.autoDataService.getVehicleModelList(vehDetails)
        .subscribe(res => {
          this.vehModelDetailsForm.patchValue({ vehModel: undefined, admeId: '' });
          this.modelList = res.vehModelArray;
          this.specificationsList = [];
          this.loaderService.display(false);
        }, err => {
          this.modelList = [];
          this.vehModelDetailsForm.patchValue({ vehMake: '', admeId: '' });
          console.log(JSON.stringify(err));
          this.loaderService.display(false);
        });
    }
  }


  validateAllFormFields(formGroup: FormGroup) {
    window.scrollTo(0, 0);
    // this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      console.log(field + ':' + control.status);
      if (control instanceof FormControl) {
        console.log(formGroup.get(field));
        control.markAsTouched({ onlySelf: true });
      }
    });
  }
  clickForTp() {
    window.localStorage.setItem('type', 'TP');
    this.router.navigate(['car-insurance-without-chassi']);
  }

}
