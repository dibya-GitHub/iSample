import { Component, OnInit } from '@angular/core';
import { Meta, Title } from "@angular/platform-browser";
import { NavigationEnd, Router } from "@angular/router";
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { TooltiptList } from "src/shared/tooltip-list";
import { UserData } from '../classes/userData';
@Component({
  selector: 'app-first-screen',
  templateUrl: './first-screen.component.html',
  styleUrls: ['./first-screen.component.scss']
})
export class FirstScreenComponent implements OnInit {
  showChildComponent: boolean = true;
  ifTelematics: boolean = false;
  userData: UserData = new UserData();
  //setFieldDisabled = false;
  public tootipMessage = new TooltiptList();
  constructor(
    private router: Router,
    private meta: Meta,
    private titleService: Title,
    private pixelService: RocketFuelService) {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
    });
    // if(window.localStorage.getItem('type')=='TP'){
    //   this.setVehicleType('0');
    //   this.setFieldDisabled = true;
    // }else{
    //   this.setVehicleType('1');
    // }

    if (window.location.href.indexOf("/safe-driver") > -1) {
      this.setVehicleType('1');
      this.ifTelematics = true;
    }

    this.titleService.setTitle('Car Insurance Dubai, UAE | Motor Insurance Dubai | I-insured');
    this.meta.addTag({ name: 'description', content: 'i-Insured is a trusted car insurance company in Dubai, UAE. Renew your motor & vehicle insurance at i-Insure. Get the best quote now!' });
    this.meta.addTag({ name: 'keywords', content: 'car insurance dubai, motor insurance dubai, car insurance online, private car insurance dubai, vehicle insurance, buy car insurance online dubai, compare car insurance quotes, buy car insurance online' });
  }

  ngOnInit() {
    if (null != window.localStorage.getItem('userDetailsWithChassis') && window.localStorage.getItem('userDetailsWithChassis') != undefined) {
      this.userData = JSON.parse(window.localStorage.getItem('userDetailsWithChassis'));
      if (this.userData.insType == 0) {
        //this.setFieldDisabled = true;
        this.userData.insType = 0;
      } else {
        this.userData.insType = 1;
        //this.setFieldDisabled = false;
      }
    }
    if (window.localStorage.getItem('type') !== undefined && window.localStorage.getItem('type') == 'TP') {
      this.userData.insType = 0;
      // this.setFieldDisabled = true;
    } else if (window.localStorage.getItem('type') !== undefined && window.localStorage.getItem('type') == 'OD') {
      this.userData.insType = 1;
    }
  }
  saveDetails() {
    window.localStorage.removeItem('type');
    if (this.userData.insType === undefined) {
      this.userData.insType = 1;
    }
    console.log("Details are" + this.userData);
    this.pixelService.pixelFireValue('Universal');
    this.pixelService.pixelFireValue('2.1');
    window.localStorage.setItem('userDetailsWithChassis', JSON.stringify(this.userData));
    this.router.navigate(["/chassi-second-screen"], { skipLocationChange: true });
  }
  setVehicleType(val: any) {
    this.userData.insType = val;
    if (val == '0') {
      this.showChildComponent = false;
    } else {
      this.showChildComponent = true;
    }
  }
}
