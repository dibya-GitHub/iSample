import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as $ from 'jquery';
import { RecaptchaComponent } from 'ng-recaptcha';
import { CarInsurancePlanService } from "src/app/car-insurance/services/car-insurance-plan.service";
import { MotorDropDownService } from "src/app/car-insurance/services/motor-drop-down.service";
import { ApiConstants } from "src/shared/api-constants";
import { InsuranceService } from 'src/shared/services/insurance.service';
import { RocketFuelService } from 'src/shared/services/rocketFuel.service';
import { TooltiptList } from "src/shared/tooltip-list";
import { environment } from '../../../../environments/environment';
import { AppUtil } from '../../../../shared/app-util';
import { LoaderService } from '../../../../shared/loader-service/loader.service';
import { UserData } from '../classes/userData';
import { UserDetails } from '../classes/userDetails';

@Component({
  selector: 'app-second-screen',
  templateUrl: './second-screen.component.html',
  styleUrls: ['./second-screen.component.scss']
})
export class SecondScreenComponent implements OnInit {

  @ViewChild('captcha') captcha: RecaptchaComponent;
  userData: UserData = new UserData();
  appUtilObj: AppUtil = new AppUtil();
  userDetails: UserDetails = new UserDetails();
  readOnlyInput = true;
  errorMsg: any = '';
  quoteNo: any;
  registration_locations: any = [];
  vehicle_types: any = [];
  yearArray: any = [];
  vehicle_models: any = [];
  vehicle_makes: any = [];
  vehicle_cylinders: any = [];
  vehUsageArray: any = [];
  seating: any = [];
  gender_list: any = [];
  nationality_list: any = [];
  drivingExperience: any = [];
  chassisBasedData: any = [];
  date: Date = new Date();
  startDateOptions: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    }
  };
  setDisabled = false;
  makeDesc: any;
  modelDesc: any;
  bodyDesc: any;
  gccDesc: any;
  vehValDesc: any;
  cylDesc: any;
  captchaErr: any;
  showCaptchaErr = false;
  promoCodeError: any = '';
  dob: any;
  nationality: any = [];
  siteKey: any = environment.siteKey;
  showDiv = false;
  cusYear: any;
  firstRegYear: any;
  manfYear: any;
  setInvalid = false;
  vehMaxValuation: any;
  vehMinValuation: any;
  ifTelematics: boolean = false;
  public tootipMessage = new TooltiptList();
  constructor(
    private router: Router,
    private carInsurancePlanService: CarInsurancePlanService,
    private getCarQuoteService: MotorDropDownService,
    private insuranceService: InsuranceService,
    private loaderService: LoaderService,
    private pixelService: RocketFuelService
  ) {
    this.userData = JSON.parse(window.localStorage.getItem('userDetailsWithChassis'));
    this.userDetails.mobileNo = this.userData.mobileNo;
    this.userDetails.emailId = this.userData.emailId;
    this.userDetails.insName = this.userData.name;
    //window.history.replaceState('', '', window.location.origin + '/car-insurance');
  }

  ngOnInit() {
    this.getEdataDetails();
    this.getRegLocationList();
    this.getRegYear();
    this.getSeatingCapacity();
    this.getGenderList();
    this.getCountrylist();
    this.getDrivingExp();
    this.setDefaults();
    this.cusYear = new Date().getFullYear() + 1;
  }

  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  getEdataDetails() {
    this.errorMsg = '';
    this.resetFormOnEdataError();
    this.loaderService.display(true);
    this.carInsurancePlanService.getChassiDetails({ "chassisNo": this.userData.chassisNo }).subscribe((data: any) => {
      console.log(JSON.stringify(data));
      if (data.respCode == 2000) {
        this.readOnlyInput = true;
        this.chassisBasedData = data;
        this.userDetails.manfYear = this.chassisBasedData.general.modelYear;
        this.userDetails.firstRegYear = this.chassisBasedData.registration.registrationYear;
        if (this.userDetails.firstRegYear != null && this.userDetails.firstRegYear != '') {
          this.userDetails.firstRegAge = (new Date().getFullYear() - parseInt(this.userDetails.firstRegYear)).toString();
          this.firstRegYear = this.userDetails.firstRegYear;
        } else {
          this.userDetails.firstRegYear = '';
        }
        if (this.userDetails.manfYear != null && this.userDetails.manfYear != '') {
          this.manfYear = this.userDetails.manfYear;
        }
        this.userDetails.vehMake = this.chassisBasedData.general.make;
        this.getVehicleMake();
        this.userDetails.vehModel = this.chassisBasedData.general.model;
        this.userDetails.vehBodyType = this.chassisBasedData.general.bodyType;
        this.userDetails.seatingCty = this.chassisBasedData.general.noOfSeats;
        this.userDetails.vehCylinders = this.chassisBasedData.technical.engineCylinders;
        this.getCylinderList();
        this.userDetails.gccSpecYN = this.chassisBasedData.registration.gccSpecYn;
        if (this.userDetails.gccSpecYN == '0') {
          this.setDisabled = true;
          this.userDetails.sumAssured = '0';
          this.gccDesc = 'No';
          this.vehValDesc = '0';
          if (window.location.href.indexOf("/safe-driver") > -1) {
            this.ifTelematics = false;
          }
        } else {
          this.gccDesc = 'Yes';
          //this.userDetails.sumAssured = '';
          this.setDisabled = false;
          //this.vehValDesc = '';
          if (this.chassisBasedData.valuation != undefined && this.chassisBasedData.valuation.medium != null) {
            this.vehValDesc = this.chassisBasedData.valuation.medium;
            this.userDetails.sumAssured = this.chassisBasedData.valuation.medium;
            this.vehMaxValuation = this.chassisBasedData.valuation.high;
            this.vehMinValuation = this.chassisBasedData.valuation.low;
          }
          else {
            this.vehValDesc = '';
          }

          if (window.location.href.indexOf("/safe-driver") > -1) {
            this.ifTelematics = true;
          }
        }

        this.getVehicleType();
        this.showDiv = true;
        this.resetParallex();
        this.loaderService.display(false);
      } else {
        this.errorMsg = this.appUtilObj.displayError(data, null);
        this.loaderService.display(false);
      }
    }, error => {
      try {
        let err = JSON.parse(error);
        this.errorMsg = err.errMessage
      } catch (err) {
        this.errorMsg = 'No records found'
      }
      this.loaderService.display(false);
    });
  }
  onDateChanged(event: any) {
    this.dob = event;
  }
  submit() {

    // if (jQuery('.alert.alert-danger')[0]) {
    //   this.scrollTo(2);
    //   return false;
    // }

    // if (this.captcha.execute) {
    //   this.captchaErr = 'Please Validate Captcha';
    //   this.showCaptchaErr = true;
    //   return false;
    // } else {
    //   this.showCaptchaErr = false;
    // }
    this.loaderService.display(true);
    this.userDetails.userId = ApiConstants.USER_ID;
    this.userDetails.firstRegAge = (new Date().getFullYear() - parseInt(this.userDetails.firstRegYear)).toString();
    this.userDetails["vehAge"] = (new Date().getFullYear() - parseInt(this.userDetails.manfYear)).toString();
    if (this.userDetails.promoCode == undefined) {
      this.userDetails.promoCode = '';
    }
    if (this.userDetails.vehUsage == undefined || this.userDetails.vehUsage == '') {
      this.userDetails.vehUsage = '1001';
    }
    console.log(this.userDetails.insDob);
    let age = this.userDetails.insDob.formatted;
    this.userDetails.driverDob = this.userDetails.insDob.epoc;
    this.userDetails.insAge = this.getAge(age);
    this.userDetails.driverAge = this.userDetails.insAge;
    this.userDetails.insDob = this.userDetails.insDob.formatted;
    if (this.userDetails.vehMake[0].id != undefined) {
      this.userDetails.vehMake = this.userDetails.vehMake[0].id;
    }
    if (this.userDetails.vehModel[0].id != undefined) {
      this.userDetails.vehModel = this.userDetails.vehModel[0].id;
    }
    if (this.userDetails.nationality[0] != undefined) {
      this.userDetails.nationality = this.userDetails.nationality[0].id;
    }
    let insType;
    if (this.userDetails.insAge < 25 || parseInt(this.userDetails.licenceAge) < 1) {
      this.userDetails.sumAssured = "0";
      this.userDetails.gccSpecYN = "0";
      insType = 'TP'
    } else {
      if (parseInt(this.userDetails.gccSpecYN) == 1) {
        insType = 'OD';
      } else {
        insType = 'TP';
      }
    }
    let postData = {
      lobCode: ApiConstants.CAR_INSURANCE_LOBCODE,
      portal: ApiConstants.PORTAL,
      location: ApiConstants.LOCATION,
      userId: ApiConstants.USER_ID,
      bundleYN: "0",
      sourceMkting: "",
      campaignMkting: "",
      prodShortDesc: insType,
      ipAddress: window.localStorage.getItem('ip'),
      promoCode: this.ifTelematics ? '703446' : this.userDetails.promoCode,
      polStartDate: new Date().getTime()
    };
    console.log(JSON.stringify(postData));
    this.insuranceService.createQuote(postData).subscribe(result => {
      if (result.respCode == 2000) {
        this.quoteNo = result.quoteNo;
        this.userDetails.transId = result.transId;
        this.userDetails.tranSrNo = result.tranSrNo;
        this.userDetails.psgrLiabSeatCty = parseInt(this.userDetails.seatingCty) - 1;
        let insType;
        if (this.userData.insType == 1) {
          insType = 'OD';
          this.userDetails.mapId = "MOT_COMP_POL_SCR_1";
        } else {
          insType = 'TP';
          this.userDetails.mapId = "MOT_TP_POL_SCR_1";
        }
        console.log(JSON.stringify(this.userDetails));
        let obj = {
          transId: this.userDetails.transId,
          tranSrNo: this.userDetails.tranSrNo,
          quoteNo: result.quoteNo,
          seatingCapacity: this.userDetails.psgrLiabSeatCty,
          lobCode: ApiConstants.CAR_INSURANCE_LOBCODE,
          registrationYear: this.userDetails.firstRegYear,
          licenceAge: this.userDetails.licenceAge,
          vehicleType: insType
        }
        this.insuranceService.updateInsuredInfo(this.userDetails).subscribe(updateInfoResult => {
          if (this.userData.insType == 1) {
            this.userDetails.mapId = "MOT_COMP_RISK_SCR_1";
          } else {
            this.userDetails.mapId = "MOT_TP_RISK_SCR_1";
          }
          this.carInsurancePlanService.updateVehicleInfo(this.userDetails).subscribe((updateVehicleInfo: any) => {
            if (updateVehicleInfo.respCode == 2000) {
              let strPostData = {
                transId: this.userDetails.transId,
                tranSrNo: this.userDetails.tranSrNo,
                portal: ApiConstants.PORTAL,
                userId: ApiConstants.USER_ID,
                lobCode: ApiConstants.CAR_INSURANCE_LOBCODE
              }
              this.insuranceService.calculatePricing(JSON.stringify(strPostData)).subscribe((response: any) => {
                if (response.respCode == 2000) {
                  this.pixelService.pixelFireValue('Universal');
                  this.pixelService.pixelFireValue('3.1');
                  window.localStorage.removeItem('userDetailsWithChassis');
                  this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
                }
              }, error => {
                console.log("Inside calPricing error");
                this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
                this.loaderService.display(false);
              });
            }
          }, error => {
            this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
            this.loaderService.display(false);
          });
        }, error => {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
          this.loaderService.display(false);
        });
      }
    }, error => {
      this.userDetails.insDob = this.dob;
      this.userDetails.nationality = this.nationality;
      let err = error.json();
      if (err.respCode == "5005") {
        this.promoCodeError = err.errMessage;
      } else {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      }
      this.loaderService.display(false);
    });
  }
  getRegLocationList() {
    let location = { "type": "REGN_LOC" };
    this.getCarQuoteService.getRegistrationLocationList(location)
      .subscribe(result => {
        this.registration_locations = result.appCodesArray;
        this.userDetails.regnLoc = "";
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }
  getVehicleType() {
    let data;
    if (this.userData.insType == 0 || this.userDetails.gccSpecYN == '0') {
      data = 'TP';
    } else {
      data = 'OD';
    }
    let v_type = { "insuranceType": data, "portal": ApiConstants.PORTAL }
    this.getCarQuoteService.getVehicleType(v_type).subscribe(
      result => {
        console.log(result);
        this.vehicle_types = result.typeArray;
        let that = this;
        function findArr(arr) {
          return arr.VEHTYPECODE == that.userDetails.vehBodyType;
        }
        this.getVehicleUsage(result.typeArray[0].VEHTYPECODE);
        try {

          this.bodyDesc = this.vehicle_types.find(findArr).VEHTYPEDESC;

        } catch (err) {
          this.bodyDesc = undefined;
          this.userDetails.vehBodyType = ''
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }
  getRegYear() {
    let year = new Date().getFullYear();
    for (let i = year; i > (year - 5); i--) {
      this.yearArray.push(i);
    }
    this.userDetails.firstRegYear = "";
  }
  getVehicleMake() {
    let v_make = { "userId": ApiConstants.USER_ID };
    this.getCarQuoteService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        let tmpId;
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          if (id == this.userDetails.vehMake) {
            this.makeDesc = result.makeArray[i].MAKEDESC;
          }
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.vehicle_makes = arr;
        let postData = {
          type: "MOT_VEH_MOD",
          refCode: this.userDetails.vehMake
        }
        this.getCarQuoteService.getVehicleModelList(postData).subscribe(result => {
          //console.log(JSON.stringify(response.json()));
          let arr = [];
          for (let i = 0; i < result.appCodesArray.length; i++) {
            let id = result.appCodesArray[i].code;
            if (id == this.userDetails.vehModel) {
              this.modelDesc = result.appCodesArray[i].desc;
            }
            let text = result.appCodesArray[i].desc;
            let object = { id: id, text: text };
            arr.push(object);
          }
          this.vehicle_models = arr;
          if (this.modelDesc == undefined) {
            this.userDetails.vehModel = null;
          }
        });
      });
  }
  getModel(event) {
    this.userDetails.vehMake = event.id;
    let postData = {
      type: "MOT_VEH_MOD",
      refCode: this.userDetails.vehMake
    }
    this.getCarQuoteService.getVehicleModelList(postData).subscribe(result => {
      //console.log(JSON.stringify(response.json()));
      let arr = [];
      for (let i = 0; i < result.appCodesArray.length; i++) {
        let id = result.appCodesArray[i].code;
        if (id == this.userDetails.vehModel) {
          this.modelDesc = result.appCodesArray[i].desc;
        }
        let text = result.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      this.vehicle_models = arr;
    });
  }
  addVehicleMake(event) {
    this.userDetails.vehModel = event.id
  }
  setGcc(data: any) {
    this.userDetails.gccSpecYN = data;
    if (data == 0) {
      this.setDisabled = true;
      this.userDetails.sumAssured = '0';
      this.userDetails.vehMake = '';
      this.userDetails.vehModel = '';
      this.userDetails.mapId = "MOT_TP_POL_SCR_1";
      this.userData.insType = 0;
      if (window.location.href.indexOf("/safe-driver") > -1) {
        this.ifTelematics = false;
      }
    } else {
      this.setDisabled = false;
      //this.userDetails.sumAssured = '';
      this.userDetails.mapId = "MOT_COMP_POL_SCR_1";
      this.userData.insType = 1;
      if (window.location.href.indexOf("/safe-driver") > -1) {
        this.ifTelematics = true;
      }
    }
  }
  getCylinderList() {
    let v_cylinder = { "type": "MOT_VEH_NOC" };
    this.getCarQuoteService.getVehicleCylinderList(v_cylinder)
      .subscribe(result => {
        this.vehicle_cylinders = result.appCodesArray;
        let that = this;
        function findArr(arr) {
          if (arr.code == that.userDetails.vehCylinders) {
            return that.cylDesc = arr.desc;
          }
        }
        this.vehicle_cylinders.find(findArr);
        if (this.cylDesc == undefined || this.cylDesc == null) {
          this.userDetails.vehCylinders = '';
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }
  getSeatingCapacity() {
    this.seating = this.getCarQuoteService.getSeatingCapacity();
    this.userDetails.seatingCty = '';
  }
  getVehicleUsage(data: any) {
    let v_usage = { "portal": "D", "vehType": data }
    this.getCarQuoteService.getVehicleUsage(v_usage).subscribe(data => {
      this.vehUsageArray = data.usageArray;
      this.userDetails.vehUsage = '';
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }
  getGenderList() {
    let get_genderList = { "paraType": "GENDER" };
    this.insuranceService.getGenderList(get_genderList)
      .subscribe(result => {
        this.gender_list = result.appParamsArray;
        this.userDetails.gender = '';
        //console.log(result);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }
  getCountrylist() {
    let get_nationaLitylist = { "type": "NATIONALITY" };
    this.insuranceService.getNationalityList(get_nationaLitylist)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        let sortedArr = this.sortNationality(arr);
        this.nationality_list = sortedArr;
        this.userDetails.nationality = '';
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        this.loaderService.display(false);
      });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  addNationality(event) {
    this.nationality.push({ id: event.id, text: event.text });
    this.userDetails.nationality = event.id;
  }
  getAge(dateString) {
    let parts = dateString.split('/');
    let age: any;
    let today = new Date();
    let birthDate = new Date(parts[2], parts[1] - 1, parts[0]);

    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }
  getDrivingExp() {
    this.drivingExperience = this.getCarQuoteService.getDrivingExperience();
  }
  setDefaults() {
    this.userDetails.vehMake = '';
    this.userDetails.vehModel = '';
    this.userDetails.vehUsage = '';
    this.userDetails.licenceAge = '';
    this.userDetails.firstRegYear = '';
    this.userDetails.regnLoc = '';
    this.userDetails.gender = '';
  }
  scrollTo(temp) {
    if (temp == '1') {
      $('html, body').animate({
        scrollTop: $('#edataCarform').offset().top
      }, 1500, function () {
      });
    }

    else {
      $('html, body').animate({
        scrollTop: $('#edataCarformtop').offset().top
      }, 1500, function () {
      });
    }
  }
  checkValidYears() {

    if (+this.userDetails.manfYear > (this.cusYear) || +this.userDetails.manfYear < 1000) {
      return false;
    }
    if (+this.userDetails.firstRegYear >= (this.cusYear) || +this.userDetails.firstRegYear < 1000) {
      return false;
    }

    return true;
  }
  checkIfTopFormValid(C_FormTop: NgForm) {
    if (C_FormTop.invalid || !this.checkValidYears()) {
      this.scrollTo(2);
      return false;
    } else {
      return true;
    }
  }

  resetParallex() {
    setTimeout(() => {
      $(window).resize(function () {
        // $('[data-parallax="scroll"]').parallax();
      }).resize();
    }, 10);
  }
  resetFormOnEdataError() {
    this.bodyDesc = undefined;
    this.cylDesc = undefined;
    this.makeDesc = undefined;
    this.modelDesc = undefined;
    this.vehValDesc = undefined;
    this.firstRegYear = undefined;
    this.manfYear = undefined;
    this.gccDesc = undefined;
    this.userDetails.seatingCty = undefined;
    this.userDetails.vehUsage = undefined;
    this.userDetails.sumAssured = '';
    this.userDetails.licenceAge = '';
    this.userDetails.gender = '';
    this.userDetails.regnLoc = '';
    this.showDiv = false;
  }
  setValidation() {
    if (this.userDetails.vehModel == null) {
      this.setInvalid = true;
    } else {
      this.setInvalid = false;
    }
    console.log(this.setInvalid);
  }
}
