import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-thank-you',
  templateUrl: './policy-thank-you.component.html',
  styleUrls: ['./policy-thank-you.component.scss']
})
export class PolicyThankYouComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
