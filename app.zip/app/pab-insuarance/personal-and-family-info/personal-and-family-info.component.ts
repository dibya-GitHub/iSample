import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { RecaptchaComponent } from 'ng-recaptcha';
import { ApiConstants } from 'src/shared/api-constants';
import { MonthlySalary } from 'src/shared/classes/monthly-salary';
import { PabPolicyType } from 'src/shared/classes/pab-policy-type';
import { InsuranceService } from 'src/shared/services/insurance.service';
import { TooltiptList } from "src/shared/tooltip-list";
import { environment } from '../../../environments/environment';
import { AppUtil } from '../../../shared/app-util';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { PabInfo } from '../classes/pab-info';
import { PabInsuranceService } from '../services/pab-insuarance.service';

@Component({
  selector: 'personal-and-family-info',
  templateUrl: './personal-and-family-info.component.html',
  styleUrls: ['./personal-and-family-info.component.scss'],
})
export class PersonalAndFamilyInfoComponent implements OnInit {

  @ViewChild('captcha') captcha: RecaptchaComponent;
  @ViewChildren('input') vc;
  pabInfo: PabInfo = new PabInfo();
  ip: any;
  policy_types: PabPolicyType[];
  adults = ['1'];
  monthly_salaries: MonthlySalary[];
  errorMsg: string = '';
  appUtilObj: AppUtil = new AppUtil();
  captchaErr: any;
  quoteNo: string = '';
  promoCodeError: any;
  siteKey: any = environment.siteKey;
  tootipMessage = new TooltiptList();

  constructor(
    private meta: Meta,
    private router: Router,
    private titleService: Title,
    private pabInsuranceService: PabInsuranceService,
    private insuranceService: InsuranceService,
    private loaderService: LoaderService,
  ) {
    this.titleService.setTitle('PAB Insurance in Dubai | Medical Health Insurance Company Dubai');
    this.meta.addTag({ name: 'description', content: 'i-Insured PAB Insurance will give you the financial buffer to focus on your recovery after an accident with the best PAB insurance plans in Dubai.' });
    this.meta.addTag({ name: 'keywords', content: 'life insurance, medical insurance, health insurance dubai, health insurance companies in dubai, health insurance plans, life insurance policy, accident insurance policy in dubai, accident insurance plan, family health insurance' });

    this.pabInfo.totalAdults = this.adults[0];
    this.pabInfo.emailId = localStorage.getItem('emailIdVal');
    this.pabInfo.mobileNo = localStorage.getItem('mobileNoVal');
    this.pabInfo.monthlySalary = localStorage.getItem('monthlySalValue');
  }

  ngOnInit() {
    this.setDefaultValues();
    const params = { 'paraType': 'PAB_INS_TYP' }
    this.pabInsuranceService.getPabPolicyType(params).subscribe(policy => {
      this.policy_types = policy.appParamsArray
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });

    const salary_params = { 'type': 'PAB_SAL' }
    this.pabInsuranceService.getMonthlySalary(salary_params).subscribe(salary => {
      this.monthly_salaries = salary.appCodesArray
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }

  ngAfterViewInit() {
    this.vc.first.nativeElement.focus();
  }

  setDefaultValues() {
    if (this.pabInfo.monthlySalary != null && this.pabInfo.monthlySalary != '') {
      console.log('value is available');
    } else {
      this.pabInfo.monthlySalary = '-1';
    }

    if (this.pabInfo.emailId == 'undefined' || this.pabInfo.emailId == null) {
      console.log('value is undefined --');
      this.pabInfo.emailId = '';
    } else {
      console.log('value is available');
    }

    if (this.pabInfo.mobileNo == 'undefined' || this.pabInfo.mobileNo == null) {
      console.log('value is undefined --');
      this.pabInfo.mobileNo = '';
    } else {
      console.log('value is available');
    }

    this.removeItems();
  }

  removeItems() {
    localStorage.removeItem('emailIdVal');
    localStorage.removeItem('mobileNoVal');
    localStorage.removeItem('monthlySalValue');
  }

  setIP() {
    this.insuranceService.getIPAddress().subscribe(result => {
      this.ip = result.ip
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      this.loaderService.display(false);
    });
  }

  save(pab) {
    // if (this.captcha.execute) {
    //   this.captchaErr = 'Please Validate Captcha';
    //   return false;
    // }
    this.loaderService.display(true);
    const params = {
      lobCode: ApiConstants.PAB_INSURANCE_LOBCODE,
      portal: ApiConstants.PORTAL,
      location: ApiConstants.LOCATION,
      userId: ApiConstants.USER_ID,
      bundleYN: '0',
      ipAddress: this.ip,
      sourceMkting: '',
      campaignMkting: '',
      promoCode: this.pabInfo.promoCode,
      polStartDate: new Date().getTime(),
      prodShortDesc: 'PAB'
    };
    console.log('Create Quote')
    console.log(JSON.stringify(params))
    this.insuranceService.createQuote(params).subscribe(
      result => {
        if (result.respCode == 2000) {
          this.pabInfo.transId = result.transId;
          this.pabInfo.tranSrNo = result.tranSrNo;
          this.quoteNo = result.quoteNo;
          this.pabInfo.mapId = 'PAB_POL_SCR_1';
          this.pabInfo.userId = ApiConstants.USER_ID;
          this.pabInfo.polTerm = '1';
          this.pabInfo.insuranceType = 'PAB';
          console.log('this.pabInfo')
          console.log(JSON.stringify(this.pabInfo))
          this.insuranceService.updateInsuredInfo(JSON.stringify(this.pabInfo)).subscribe(
            (data: any) => {
              if (data.respCode == 2000) {
                let pabDetails = {
                  'monthlySalary': this.pabInfo.monthlySalary,
                  'noOfAdults': "1",
                  'transId': this.pabInfo.transId,
                  'tranSrNo': this.pabInfo.tranSrNo,
                  'polType': '1001',
                  'userId': ApiConstants.USER_ID,
                  'mapId': 'PAB_RISK_SCR_1'
                }
                console.log('updPersAccidentInfo')
                console.log(JSON.stringify(pabDetails))
                this.pabInsuranceService.updPersAccidentInfo(pabDetails).subscribe(
                  pabResult => {
                    if (pabResult.respCode == 2000) {
                      const postData = {
                        'transId': this.pabInfo.transId,
                        'tranSrNo': this.pabInfo.tranSrNo,
                        'portal': ApiConstants.PORTAL,
                        'userId': ApiConstants.USER_ID,
                        'lobCode': ApiConstants.PAB_INSURANCE_LOBCODE
                      }
                      this.insuranceService.calculatePricing(postData).subscribe(
                        (response: any) => {
                          this.loaderService.display(false);
                          if (response.respCode == 2000) {
                            const obj = {
                              transId: this.pabInfo.transId,
                              tranSrNo: this.pabInfo.tranSrNo,
                              quoteNo: result.quoteNo

                            }

                            console.log(JSON.stringify(obj))
                            this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
                          }
                        }, error => {
                          //this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
                          let obj = {
                            quoteNo: this.quoteNo
                          }
                          this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
                          this.loaderService.display(false);
                        });
                    }
                  }, error => {
                    this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
                    this.loaderService.display(false);
                  });
              }
            }, error => {
              this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
              this.loaderService.display(false);
            });
        }
      }, error => {
        let err = error.json();
        if (err.respCode == "5005") {
          this.promoCodeError = err.errMessage;
        } else {
          this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
        }
        this.loaderService.display(false);
      });
  }
}
