import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalAndFamilyInfoComponent } from './personal-and-family-info.component';

describe('PersonalAndFamilyInfoComponent', () => {
  let component: PersonalAndFamilyInfoComponent;
  let fixture: ComponentFixture<PersonalAndFamilyInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalAndFamilyInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalAndFamilyInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
