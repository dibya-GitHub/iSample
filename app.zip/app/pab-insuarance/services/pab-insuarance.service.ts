import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiHeadersService } from '../../../shared/api-headers.service';
import { ApiUrls } from '../../../shared/api-urls';

@Injectable({
  providedIn: 'root'
})
export class PabInsuranceService {
  requestOption: any;
  baseUrl: any = environment.baseUrl;

  constructor(
    private http: HttpClient,
    private apiHeadersService: ApiHeadersService
  ) {
    this.requestOption = this.apiHeadersService.requestHeaders;
  }

  getMonthlySalary(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_MONTHLY_SALARY_URL, body, this.requestOption);
  }

  getGeographicalLimit(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_GEOGRAPHICAL_LIMIT_URL, body, this.requestOption);
  }

  getPabPolicyType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_TYPE_URL, body, this.requestOption);
  }

  updPersAccidentInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_PAB_INFO_URL, body, this.requestOption);
  }

  updatePolicyDuration(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_POLICY_DURATION, body, this.requestOption);
  }

  insertPABCoveredMembrs(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_PAB_COVERED_MEMBERS, body, this.requestOption);
  }

  getPABCvrdMembrs(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_PAB_COVERED_MEMBER_DETAILS, body, this.requestOption);
  }
  getQuotePersonalAccidentInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOT_PERSONAL_ACCIDENT_INFO, body, this.requestOption);
  }
}
