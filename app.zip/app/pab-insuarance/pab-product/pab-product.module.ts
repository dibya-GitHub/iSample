import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from "../../shared.module";
import { PabProductRoutingModule } from './pab-product-routing.module';
import { PabProductComponent } from './pab-product.component';

@NgModule({
  declarations: [
    PabProductComponent,
  ],
  imports: [
    PabProductRoutingModule,
    CommonModule,
    SharedModule,
    SlickCarouselModule,

  ],
})

export class PabProductModule { }