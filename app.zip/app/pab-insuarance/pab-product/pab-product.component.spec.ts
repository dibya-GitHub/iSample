import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PabProductComponent } from './pab-product.component';

describe('PabProductComponent', () => {
  let component: PabProductComponent;
  let fixture: ComponentFixture<PabProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PabProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PabProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
