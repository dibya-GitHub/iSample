import { PabProductComponent } from './pab-product.component';
import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';



const pabProductRoutes: Routes = [
    { path: '', component: PabProductComponent },
  ];
@NgModule({
  imports: [
         RouterModule.forChild(pabProductRoutes)
     ],
     exports: [
         RouterModule
     ]
})
export class PabProductRoutingModule { }
