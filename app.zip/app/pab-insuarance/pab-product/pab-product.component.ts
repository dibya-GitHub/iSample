import { Component, OnInit } from '@angular/core';
// import { ng2parallax } from 'ang2-parallax/ng2-parallax-directive/parallax.directive';
// import { SwiperModule } from 'angular2-useful-swiper';
import { Meta, Title } from '@angular/platform-browser';
import * as $ from 'jquery';
import { Router } from "@angular/router";

@Component({
  selector: 'app-pab-product',
  templateUrl: './pab-product.component.html',
  styleUrls: ['./pab-product.component.scss'],
})
export class PabProductComponent implements OnInit {
  constructor(
    private meta: Meta,
    private router: Router,
    // private ng2parallax: ng2parallax,
    private titleService: Title,
    ) {
    this.titleService.setTitle('Personal Accident Insurance Dubai | Compare and Buy Health Insurance');
    this.meta.addTag({ name: 'description', content: 'Compare and buy personal accident insurance online in Dubai. Get free quotes and online support from i-insured on medical & health insurance premium, renewal & claims.' });
    this.meta.addTag({ name: 'keywords', content: 'life insurance policy, life insurance dubai, health insurance plans, life insurance policy, private health care, private medical insurance, medical insurance companies, medical insurance plans, health insurance in dubai' });

  }
  currentIndex: any = 1;
  selectedImageSrc = './assets/images/pab-pro-slide-01.png';
  title = 'Special discount';
  subtitle = 'Purchase your policy today and enjoy a special 10% discount';

  ngOnInit() {
    this.initSliderForMobile();
    this.initSlider()
  }
  afterChange(event) {
    this.currentIndex = $('.insta-wp.slick-slide.slick-current.slick-active').attr('data-slick-index');
    this.currentIndex++;
  }
  initSliderForMobile() {
    $(function () {
      var winWidth = $(window).width() - 100;
      $('.insta-wp .card-shadow ').width(winWidth);
      var instaWidth = $(window).width();
      $('.insta-width').width(instaWidth);

    });
  }
  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "dots": true,
    "infinite": true,
    "draggable": false
  };

  changeBackgroundImage(event: any) {
    let className = event.path[1].classList[1];
    $(function () {
      $('.thumbnail').click(function () {
        $('.thumbnail').removeClass('active');
        $(this).addClass('active');
      });
    });
    if (className === 'pab-pro-thumb-first') {
      this.selectedImageSrc = './assets/images/pab-pro-slide-01.png';
      // this.ng2parallax.src = './assets/images/pab-pro-slide-01.png';
      this.title = 'Special discount';
      this.subtitle = 'Get PAB Insurance with a special discount';

    }
    else if (className === 'pab-pro-thumb-sec') {

      this.selectedImageSrc = './assets/images/pab-pro-slide-02.png';
      // this.ng2parallax.src = './assets/images/pab-pro-slide-02.png';
      this.title = 'Hospital bills covered';
      this.subtitle = 'Get your hospital bills covered against uncalled risks';

    }
    else if (className === 'pab-pro-thumb-third') {

      this.selectedImageSrc = './assets/images/qic_house.png';
      // this.ng2parallax.src = './assets/images/qic_house.png';
      this.title = 'Death and disabilities covered';
      this.subtitle = 'Opt for extra protection towards death and disabilities.';

    }
    else if (className === 'pab-pro-thumb-fourth') {

      this.selectedImageSrc = './assets/images/qic_pab.png';
      // this.ng2parallax.src = './assets/images/qic_pab.png';
      this.title = 'Financial support for post-hospitalization care';
      this.subtitle = 'Get the financial support post mayhem at no additional cost.';

    }
    // this.ng2parallax.ngOnInit();
  }

  listContent = [
    {
      heading: 'Accident medical expenses',
      description: 'The PAB insurance covers medical expenses caused by accidents',
      icon: '',
      alt: 'Accident medical expenses'
    },
    {
      heading: 'Loss of limbs or sight',
      description: 'If an accident causes you to lose sight or limbs, the PAB insurance will pay you a fixed amount',
      icon: '',
      alt: 'Loss of limbs or sight'
    },
    {
      heading: 'Permanent total disablement',
      description: 'An accident leaving you totally disabled will pay out the full sum insured to you',
      icon: '',
      alt: 'Permanent total disablement'
    },
    {
      heading: 'Death',
      description: 'If you die due to an accident, your spouse will receive the full sum insured',
      icon: '',
      alt: 'Death'
    }
  ]


  slideHighlights = {
    "slidesToShow": 4,
    "slidesToScroll": 1,
    "infinite": true,
    "dots": false,
    "prevArrow": false,
    "nextArrow": false,
    "responsive": [
      {
        breakpoint: 1030,
        settings: {
          "slidesToShow": 3,
          "slidesToScroll": 1,
          "infinite": true,
          "draggable": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 775,
        settings: {
          "slidesToShow": 2,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 740,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      },
      {
        breakpoint: 414,
        settings: {
          "slidesToShow": 1,
          "slidesToScroll": 1,
          "infinite": true,
          "dots": true,
          "prevArrow": true,
          "nextArrow": true
        }
      }
    ]
  }
  scrollDown() {
    $('body, html').animate({ scrollTop: 600 }, 500);
    //window.scrollTo({left:0, top:600, behavior: 'smooth'});
  }
  initSlider() {
    var self = this;
    $(function () {
      $(".slick-dots button, .slick-next, .slick-prev, .triger-box").on("click", function () {
        // var title = $(".slick-current").find("h4").html();
        setTimeout(function () {
          var title = $(".slick-current").find("h4").attr("id")
          switch (title) {
            case "first":
              self.subtitle = 'Purchase your policy today and enjoy a special 10% discount';
              break;
            case "second":
              self.subtitle = 'Be assured that during an unfortunate incident of death or a disability, you will be covered';
              break;
            case "third":
              self.subtitle = 'Enjoy financial support during the time you need it the most';
              break;
            default:
              self.subtitle = 'If you need hospital care after an accident the insurance will cover your stay in hospital up to 10 weeks';
              break;
          }
        }, 500);
      });
    })
  }

  goToFaq() {
    let obj = {
      productType: "PAB",
    }
    this.router.navigate(['faq'], { queryParams: obj, skipLocationChange: true });

  }
}
