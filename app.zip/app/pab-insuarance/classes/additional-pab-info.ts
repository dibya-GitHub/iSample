export class AdditionalPabInfo {
  transId: string;
  tranSrNo: string;
  userId: string;
  mapId: string;
  startDate: any;
  endDate: any;
  insName: string;
  civilId: string;
  geoArea: string;
  nationality:string;
  mobileNo: string;
  emailId: string;
  poBox: string;
  address: string;
}
