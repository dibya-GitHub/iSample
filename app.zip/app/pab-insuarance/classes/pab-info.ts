export class PabInfo {
  transId: string;
  tranSrNo: string;
  userId: string;
  mapId: string;
  totalAdults: string;
  monthlySalary: string;
  emailId: string;
  mobileNo: string;
  promoCode?: string;
  polTerm: string;
  insuranceType: string;
}
