export class PabCoveredMember {
  name: string;
  relation: string;
  gender: string;
  dob: any;
  nationality?: string;
  profession?: string;
}
