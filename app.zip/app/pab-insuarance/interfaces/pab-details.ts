import { GeographicalLimit } from 'src/shared/classes/geographical-limit';
import { MonthlySalary } from 'src/shared/classes/monthly-salary';
import { PabPolicyType } from 'src/shared/classes/pab-policy-type';

export interface MonthlySalaryList {
  errMessage: string;
  respCode: string;
  appCodesArray: Array<MonthlySalary>
}

export interface GeographicalLimitList {
  errMessage: string;
  respCode: string;
  appCodesArray: Array<GeographicalLimit>
}

export interface PabPolicyTypes {
  errMessage: string;
  respCode: string;
  appParamsArray: Array<PabPolicyType>
}
