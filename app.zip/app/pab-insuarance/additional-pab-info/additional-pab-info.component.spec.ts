import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalPabInfoComponent } from './additional-pab-info.component';

describe('AdditionalPabInfoComponent', () => {
  let component: AdditionalPabInfoComponent;
  let fixture: ComponentFixture<AdditionalPabInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalPabInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalPabInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
