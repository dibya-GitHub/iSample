import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as $ from 'jquery';
import { ApiConstants } from 'src/shared/api-constants';
import { Gender } from 'src/shared/classes/gender';
import { GeographicalLimit } from 'src/shared/classes/geographical-limit';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { InsuranceService } from 'src/shared/services/insurance.service';
import { TooltiptList } from "src/shared/tooltip-list";
import { AppUtil } from '../../../shared/app-util';
import { InsuranceService as CommonService } from '../../../shared/services/insurance.service';
import { AdditionalPabInfo } from '../classes/additional-pab-info';
import { PabCoveredMember } from '../classes/pab-covered-member';
import { PabInsuranceService } from '../services/pab-insuarance.service';

@Component({
  selector: 'app-additional-pab-info',
  templateUrl: './additional-pab-info.component.html',
  styleUrls: ['./additional-pab-info.component.scss']
})

export class AdditionalPabInfoComponent implements OnInit {
  checkDate: boolean = false;
  showMsgStartDate: boolean = false;
  showMsg: boolean = false;
  public tootipMessage = new TooltiptList();
  additionalInfo: AdditionalPabInfo = new AdditionalPabInfo();
  pabCoveredMember: PabCoveredMember = new PabCoveredMember();
  transId: any;
  tranSrNo: any;
  quoteNo: any;
  pabObject: any;
  public nationalities: any = []
  public genderList: Gender[]
  public geographicalLimitList: GeographicalLimit[]
  appUtilObj: AppUtil = new AppUtil();
  date: Date = new Date();
  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));
  endDate: string;
  adultNationality: Array<any>;
  errorMsg: string = '';

  public myDatePickerOptions: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };
  public myDatePickerOptionsDOB: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
    disableSince: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() + 1 }

  };
  public startDate: any = { date: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() } };

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public insuranceService: InsuranceService,
    public pabInsuranceService: PabInsuranceService,
    public commonService: CommonService,
    public loaderService: LoaderService,
  ) {

    this.route.queryParams.subscribe(params => {
      this.transId = params['transId'];
      this.tranSrNo = params['tranSrNo'];
      this.quoteNo = params['quoteNo'];
      this.pabObject = params['pabObject'];
    });

    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
    this.onDateChanged(this.startDate);
  }

  ngOnInit() {
    this.loaderService.display(true);
    $('.container').hide();
    // this.pabCoveredMember.dob="";
    this.getQuoteInfo()
    /**
     * setting dropdown lists
     */
    this.getCoveredMemberDetails();
    if (window.location.pathname.substr(window.location.pathname.lastIndexOf('/')) == '/retrieve-quote') {
      this.getQuotePersonalAccidentInfo();
    }
    this.setDefaults();
    this.getNationality();
    this.getGender();
    this.getGeographicalLimit();

  }

  getQuoteInfo() {
    const data = { 'transId': this.transId, 'tranSrNo': this.tranSrNo }
    this.insuranceService.getQuotInfo(data).subscribe(
      (res: any) => {
        this.additionalInfo.mobileNo = res.mobileNo;
        this.additionalInfo.emailId = res.emailId;
        this.additionalInfo.address = res.address;
        this.additionalInfo.poBox = res.poBox;
        if (res.insName != 'GUEST') {
          this.additionalInfo.insName = res.insName;
        } else {
          this.additionalInfo.insName = '';
        }
        this.additionalInfo.civilId = res.civilId;
        const date: Date = new Date(res.polStartDate);
        this.startDate = { date: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
        // end date
        const endDate = new Date(res.polEndDate);
        this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
        $('.container').show();
        this.loaderService.display(false);
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
        $('.container').show();
      });
  }

  getCoveredMemberDetails() {
    const data = { 'transId': this.transId, 'tranSrNo': this.tranSrNo }
    this.pabInsuranceService.getPABCvrdMembrs(data).subscribe(
      (res: any) => {
        this.pabCoveredMember.name = res.membersArray[0].name;
        this.pabCoveredMember.relation = res.membersArray[0].relation;
        this.pabCoveredMember.gender = res.membersArray[0].gender;
        this.pabCoveredMember.profession = res.membersArray[0].profession;
        // this.pabCoveredMember.nationality = res.membersArray[0].nationality;
        this.adultNationality = [{ id: res.membersArray[0].nationality, text: res.membersArray[0].nationalityDesc }]
        const memberDob: Date = new Date(res.membersArray[0].dob);
        this.pabCoveredMember.dob = { date: { year: memberDob.getFullYear(), month: memberDob.getMonth() + 1, day: memberDob.getDate() } };
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  setDefaults() {
    this.additionalInfo.poBox = '';
    this.additionalInfo.address = '';
    this.pabCoveredMember.relation = '';
    this.pabCoveredMember.gender = '';
    this.pabCoveredMember.nationality = '';
    this.pabCoveredMember.name = '';
    this.pabCoveredMember.profession = '';
  }
  onDateChanged(event) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsgStartDate = false;
    }
    if (this.startDate == null) {
      this.startDate = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    } else {
      if (this.startDate.date == undefined) {
        let temp: any = this.startDate;
        const stringDate = temp.split("/");
        const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2];
        let date = new Date(newDate);
        this.startDate = {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        };
      }
      this.startDate.date = event.date;
    }
    let timestamp = new Date(event.epoc * 1000).getTime();
    if (timestamp == 0) {
      this.endDate = '';
    } else {
      const postData = {
        transId: this.transId, //this.transId,
        tranSrNo: this.tranSrNo, //this.tranSrNo,
        polStartDate: this.appUtilObj.getUTCDate(timestamp)
      }
      //console.log(JSON.stringify(postData));
      this.pabInsuranceService.updatePolicyDuration(postData).subscribe((data: any) => {
        console.log('time', data);
        let endDate = new Date(data.polEndDate);
        this.endDate = this.appUtilObj.appendZero(endDate.getDate()) + '/' + this.appUtilObj.appendZero((endDate.getMonth() + 1)) + '/' + endDate.getFullYear();
      })
    }
  }

  dobChanged(event) {
    let date = '';
    let timestamp;
    if (event.epoc != 0) {
      timestamp = new Date(event.epoc * 1000);
      date = this.appUtilObj.getUTCDate(timestamp);
    }
    if (this.pabCoveredMember.dob != undefined || this.pabCoveredMember.dob == null) {
      this.showMsg = false;
    }
  }

  getNationality() {
    const param = { 'type': 'NATIONALITY' };
    this.insuranceService.getNationalityList(param).subscribe(nationality => {
      let arr = [];
      for (let i = 0; i < nationality.appCodesArray.length; i++) {
        let id = nationality.appCodesArray[i].code;
        let text = nationality.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      let sortedArr = this.sortNationality(arr);
      this.nationalities = sortedArr;
    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
      this.loaderService.display(false);
    });
  }

  getGender() {
    const param = { 'paraType': 'GENDER' }
    this.insuranceService.getGenderList(param).subscribe(
      gender => {
        this.genderList = gender.appParamsArray
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  getGeographicalLimit() {
    const param = { 'type': 'PAB_GEO' };
    this.pabInsuranceService.getGeographicalLimit(param).subscribe(
      geo => {
        this.geographicalLimitList = geo.appCodesArray;
        this.additionalInfo.geoArea = this.geographicalLimitList[0].code;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  sortNationality(arr) {
    return arr.sort(function (a, b) {
      var nation1 = a.text.toLowerCase(), nation2 = b.text.toLowerCase()
      if (nation1 < nation2) //sort string ascending
        return -1
      if (nation1 > nation2)
        return 1
      return 0 //default return value (no sorting)
    })
  }

  submit() {
    this.loaderService.display(true);
    if (this.checkDate == true) {
      this.loaderService.display(false);
      return false;
    }

    this.additionalInfo.transId = this.transId //this.transId;
    this.additionalInfo.tranSrNo = this.tranSrNo//this.tranSrNo;
    this.additionalInfo.mapId = 'PAB_POL_SCR_2';
    if (this.adultNationality != undefined) {
      this.additionalInfo.nationality = this.adultNationality[0].id
    }
    if (this.pabCoveredMember.dob.epoc == undefined && this.pabCoveredMember.dob.date == undefined) {
      const stringDate = this.pabCoveredMember.dob.split("/");
      const newDate = stringDate[1] + '/' + stringDate[0] + '/' + stringDate[2]
      let date = new Date(newDate);
      this.pabCoveredMember.dob = {
        date: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      };
    }
    let formattedDob = this.pabCoveredMember.dob.epoc ? this.pabCoveredMember.dob.epoc * 1000 : new Date(this.pabCoveredMember.dob.date.year, this.pabCoveredMember.dob.date.month - 1, this.pabCoveredMember.dob.date.day).getTime();
    console.log("formattedDob", formattedDob)


    this.commonService.updateInsuredInfo(this.additionalInfo).subscribe(
      (response: any) => {
        if (response.respCode == 2000) {
          const memberDetails = [{
            'transId': this.transId,
            'tranSrNo': this.tranSrNo,
            'name': this.pabCoveredMember.name,
            'relation': "008",
            'gender': this.pabCoveredMember.gender,
            'dob': formattedDob,
            'category': '8003',
            'userId': ApiConstants.USER_ID,
            'passptNo': this.additionalInfo.civilId,
            'nationality': this.additionalInfo.nationality,
            'profession': this.pabCoveredMember.profession
          }];
          this.pabInsuranceService.insertPABCoveredMembrs(memberDetails).subscribe(
            res => {
              const postData = {
                transId: this.transId,
                tranSrNo: this.tranSrNo,
                insName: this.additionalInfo.insName,
                geoArea: this.additionalInfo.geoArea,
                mapId: 'PAB_RISK_SCR_2'
              }
              this.pabInsuranceService.updPersAccidentInfo(postData).subscribe(
                pabResult => {
                  this.loaderService.display(false);
                  this.router.navigate(['summary'], { queryParams: { transId: this.transId, tranSrNo: this.tranSrNo, quoteNo: this.quoteNo }, skipLocationChange: true });
                })
            }
          );
        }
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }
  getQuotePersonalAccidentInfo() {
    const postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.pabInsuranceService.getQuotePersonalAccidentInfo(postData).subscribe(
      (pabResult: any) => {
        this.additionalInfo.geoArea = pabResult.geoArea;
      }, error => {
        this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        this.loaderService.display(false);
      });
  }

  goToPreviousPage() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      lobCode: "08",
      insType: "PAB"
    }
    this.router.navigate(['select-plan'], { queryParams: obj, skipLocationChange: true });
  }

  onDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.pabCoveredMember.dob = event.target.value;
        }
      }
    }

  }
  onDateStartDateInput(event) {
    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsgStartDate = true;
      } else {
        this.showMsgStartDate = false;
        if (event.target.value != '') {
          this.startDate = event.target.value;
        }
      }
    }
  }
  getAgeValidate(dateString: any) {
    if (dateString == '' || dateString == undefined) {
      return false;
    } else {
      //console.log(dateString)
      //let dobOf:string = dateString.formatted;
      let birthDate: any;
      if (dateString.epoc != undefined) {
        birthDate = new Date(dateString.epoc * 1000);
      } else {

        if (dateString.date != undefined) {
          dateString = dateString.date.month + "/" + dateString.date.day + "/" + dateString.date.year;
          birthDate = new Date(dateString);
        } else {
          let parts = dateString.split('/');
          birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
        }
        // if(dateString.date!=undefined){
        //   dateString=dateString.date.month +"/"+ dateString.date.day+ "/" +  dateString.date.year;
        // }

        // let parts = dateString.split('/');
        // birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }

      //const date = this.appUtilObj.getUTCDate(timestamp);
      let age: any;
      let today = new Date();
      //let birthDate = new Date(timestamp);
      age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      //console.log(age);
      if (age < 18) {
        this.checkDate = true;
        return true;
      } else if (age > 70) {
        this.checkDate = true;
        return true;
      }
      else {
        this.checkDate = false;
        return false;
      }

    }

  }

}
