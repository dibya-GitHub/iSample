// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  baseUrl: 'https://www.devapi.anoudapps.com/qicservices/',
  // siteKey: '6Lf_4i0UAAAAAJPEeCj0_juPW5X38FQFghcFRDqP'
  siteKey: '6Lf_4i0UAAAAAJPEeCj0_juPW5X38FQFghcFRDqP'

  //Production
  
  // baseUrl: 'https://www.api.qic-insured.com/qicservices/',
  // siteKey: '6LdTej4UAAAAAG0rSNcsm7XGf9oqy0RmWUuz-gq6'
  
  //Local
  
  // baseUrl: 'http://localhost:3000/qicservices/',
  // siteKey: '6LdTej4UAAAAAG0rSNcsm7XGf9oqy0RmWUuz-gq6'
  // baseUrl: 'http://192.168.80.141:8080/qic-services/',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
