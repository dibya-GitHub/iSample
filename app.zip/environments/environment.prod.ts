export const environment = {
  production: true,
  //Production
  // baseUrl: 'https://www.api.qic-insured.com/qicservices/',
  // siteKey: '6LdTej4UAAAAAG0rSNcsm7XGf9oqy0RmWUuz-gq6'
  
  // UAT
  baseUrl: 'https://www.devapi.anoudapps.com/qicservices/',
  siteKey: '6Lf_4i0UAAAAAJPEeCj0_juPW5X38FQFghcFRDqP'
};
