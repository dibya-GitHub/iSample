export class AppUtil {
  percentage: string = "76";
  percentageInwords: string = "seventy six";
  respCode: string = "";
  // This method is used to get the time in UTC format
  getUTCDate(timeStamp: any): string {
    const now: Date = new Date(timeStamp);
    const now_utc = now.getFullYear() + '-' + this.appendZero(now.getMonth() + 1) + '-' + this.appendZero(now.getDate()) + 'T' + this.appendZero(now.getHours()) + ':' + this.appendZero(now.getMinutes()) + ':' + this.appendZero(now.getSeconds()) + '.' + '000' + 'Z';
    return now_utc;
  }

  getUTCDateForProgressBar(timeStamp: any): string {
    const now: Date = new Date(timeStamp);
    const now_utc = now.getFullYear() + '-' + this.appendZero(now.getMonth() + 1) + '-' + this.appendZero(now.getDate()) + 'T' + this.appendZero(now.getHours()) + ':' + this.appendZero(now.getMinutes()) + ':' + this.appendZero(now.getSeconds());
    return now_utc;
  }
  // This method is used to append the zeroes to display the number as a two digit
  appendZero(digit): string {
    if (digit < 10) {
      return '0' + digit;
    } else {
      return digit;
    }
  }

  // This method is used to sort the array.
  sortedArray(tmpArr: any) {
    return tmpArr.sort((n1, n2) => {
      if (n1.desc > n2.desc) {
        return 1;
      }

      if (n1.desc < n2.desc) {
        return -1;
      }
      return 0;
    });
  }

  displayError(responseBody, quoteNo) {
    try {
      this.respCode = JSON.parse(responseBody).respCode;
    } catch (e) {
      this.respCode = responseBody.responseCode;
    }
    if (this.respCode == "1002" || this.respCode == "1003" || this.respCode == "1004") {
      return '';
    } else if (this.respCode == "5001" || this.respCode == "5003" || this.respCode == "5005" || this.respCode == "5007" || this.respCode == "5008" || this.respCode == "0000") {
      return JSON.parse(responseBody).errMessage;
    } else if (this.respCode == "1001" || this.respCode == "5002" || this.respCode == "5004" || this.respCode == "5006" || this.respCode == "6000"
      || this.respCode == "6001" || this.respCode == "6002" || this.respCode == "6003" || this.respCode == "6004") {
      let path = window.location.pathname.substr(0, window.location.pathname.lastIndexOf('/'));
      window.location.href = path + "/referral?quoteNo=" + quoteNo;
    }
  }

  sortArrayByPolicyStartDateDesc(tmpArr: any) {
    return tmpArr.sort((n1, n2) => {
      if (n1.polStartDate > n2.polStartDate) {
        return -1;
      }

      if (n1.polStartDate < n2.polStartDate) {
        return 1;
      }
      return 0;
    });
  }

}


