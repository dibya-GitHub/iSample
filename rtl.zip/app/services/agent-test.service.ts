import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiUrls } from '../../shared/api-urls';
import { environment } from '../../environments/environment';
import { SessionStorageService } from 'angular-web-storage';

@Injectable({
  providedIn: 'root'
})
export class AgentTestService {
  public baseUrl = environment.baseUrl;

  constructor(private http: HttpClient, private session: SessionStorageService) { }
  getUserName(body: any) {
    return this.http.get(this.baseUrl + ApiUrls.GET_AGENT_USER_NAME + '?company=' + this.session.get('companyCode') + '&userId=' + body.userId + '&userType=' + body.userType);
  }
}
