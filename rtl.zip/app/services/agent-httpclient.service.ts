import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApiUrls } from '../../shared/api-urls';

import { SessionStorageService } from 'angular-web-storage';
import { TravelInfo, TravelQuoteInfo } from 'src/app/agent-travel/classes/primaryInfo';
import { Dashboardinterface } from '../../app/agent-dashboard/dashboard-interface';
import { BoundType, CountryList } from '../../app/agent-travel/interface/agent';
import {
  CoverSummary,
  DiscountDeductibleSummary,
  GeographicalLimits, Quotation,
  UsageArray, VehicleCylinders,
  VehicleMakes, VehicleModels, VehicleTypes,
  appParamArray
} from '../../app/motor-insurance/interfaces/vehicleDetails';
import { Schemes } from '../../shared/interfaces/insurance-plan';

@Injectable({
  providedIn: 'root'
})
export class AgentHttpclientService {


  public searchHeaders;
  public searchOption;




  public baseUrl = environment.baseUrl;

  constructor(private http: HttpClient, private session: SessionStorageService) { }
  getUserName(body: any) {
    // TODO REVERT
    //return this.http.get(this.baseUrl + ApiUrls.GET_AGENT_USER_NAME +'?company='+this.session.get('companyCode')+'&userId='+body.userId+'&userType='+body.userType);
    return this.http.get('https://www.devapi.anoudapps.com/angularservices/' + ApiUrls.GET_AGENT_USER_NAME + '?company=' + this.session.get('companyCode') + '&userId=' + body.userId + '&userType=' + body.userType);
    //return this.http.get('https://www.api.qic-insured.com/agentservices/' + ApiUrls.GET_AGENT_USER_NAME + '?company=' + this.session.get('companyCode') + '&userId=' + body.userId + '&userType=' + body.userType);
  }




  getVehicleMake(body: any): Observable<VehicleMakes> {

    return this.http.get<VehicleMakes>(this.baseUrl + ApiUrls.MOTOR_MAKE_LIST + '?company=' + this.session.get('companyCode') + '&groupCode='
      + body.groupCode + '&makeFliterYn=' + body.makeFliterYn);

  }

  getVehicleModel(body: any): Observable<VehicleModels> {
    return this.http.post<VehicleModels>(this.baseUrl + ApiUrls.MOTOR_MODEL_LIST + '?company=' + this.session.get('companyCode'), body);

  }

  getVehicleType(body: any): Observable<VehicleTypes> {
    return this.http.post<VehicleTypes>(this.baseUrl + ApiUrls.MOTOR_BODY_LIST + '?company=' + this.session.get('companyCode'), body);

  }

  getUsageList(body: any): Observable<UsageArray> {
    return this.http.post<UsageArray>(this.baseUrl + ApiUrls.MOTOR_USAGE_LIST + '?company=' + this.session.get('companyCode'),
      body);

  }




  // ---------- Product List ----------//
  getProducts(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_LOB_LIST + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- Scheme List ----------//
  getSchemeList(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_SCHEME_LIST + '?company=' + this.session.get('companyCode'),
      body);

  }

  // ---------- User List ----------//
  getUserList(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_USER_LIST + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- Quote search ----------// 
  getQuote(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_QUOTE_DETAILS + '?company=' + this.session.get('companyCode') + '&agentId=' + this.session.get('agent'),
      body);


  }
  // ---------- Policy search ----------// 

  getPolicy(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_POLICY_DETAILS + '?company=' + this.session.get('companyCode'), body);

  }

  getActCLaimPolicy(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_ACT_CLM_POLICY_DETAILS + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- Get Business ----------// 
  getBusiness(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_BUSINESS_DETAILS + '?company=' + this.session.get('companyCode'), body);


  }

  // ---------- Get getPolicyBusiness ----------// 
  getPolicyBusiness(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POLICY_BUSINESS_DETAILS + '?company=' + this.session.get('companyCode'), body)

  }


  registerClaim(body: any) {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.CALL_OD_REG_CLAIMS + '?company=' + this.session.get('companyCode'), body);
  }

  registerTpClaim(body: any) {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.CALL_TP_REG_CLAIMS + '?company=' + this.session.get('companyCode'), body);
  }

  // ---------- Get getReportUrl ----------// 
  getReportUrl(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_REPORT_URL + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- Get ReportUrl ----------// 
  /* PrintReportUrl(body: any): Observable<Dashboardinterface> {
     return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_PRINT_REPORT_URL + '?company=' + this.session.get('companyCode'), body);
 
 
   }*/

  PrintReportUrl(body: any) {

    var url = this.baseUrl + ApiUrls.GET_PRINT_REPORT_URL + '?company=' + this.session.get('companyCode');
    //  + '&transId=' + body.transId + '&tranSrNo='+ body.tranSrNo + '&reportType=' + body.reportType + '&tranType=' + body.tranType;
    // var url = this.baseUrl + ApiUrls.GET_REPORT_URL + '?company=' + this.session.get('companyCode') + '&transId=837652&tranSrNo=0&reportType=Schedule&tranType=POL';
    // var data = 'transId=' + body.transId + '&tranSrNo='+ body.tranSrNo + '&docType='+ body.docType + '&reportType=' + body.reportType + '&tranType=' + body.tranType;
    // var data = body
    this.downloadFile(url, body, function (res) {
      // res = JSON.parse(res);
      // var i, l, d, array;
      //   d = res.FileData;
      //   l = d.length;
      //   array = new Uint8Array(l);
      //   for ( i = 0; i < l; i++){
      //       array[i] = d.charCodeAt(i);
      //   }
      // const blob = new Blob([res.FileDataAsString], {type: res.MimeType});
      const blob = new Blob([res], { type: 'application/pdf' });

      var url = URL.createObjectURL(blob);
      window.open(url);
    });
    const context = this;



  }

  downloadFile(url, data, success) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    let token = this.session.get('access_token')
    token = token.slice(1, -1);
    xhr.setRequestHeader("Authorization", "Bearer " + token);
    //xhr.setRequestHeader("Authorization", "Bearer " + this.session.get('access_token'));
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.responseType = "arraybuffer";
    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4) {
        if (success) success(xhr.response);
      }
    };
    xhr.send(JSON.stringify(data));
  }


  // ---------- Get DocInfoByType ----------// 
  getDocInfoByType(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_DOC_INFO_URL + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- Get FileUrl ----------// 
  getFileUrl(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_FILE_URL + '?company=' + this.session.get('companyCode'), body);


  }

  // ---------- View  Policy Details ----------// 
  viewPolicyDetails(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.VIEW_POLICY_DETAILS + '?company=' + this.session.get('companyCode'), body);


  }


  getPolicyReqDetails(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POL_APPR_REQ + '?company=' + this.session.get('companyCode'), body);


  }

  // ---------- Get EndorsementType  Details ----------// 
  getEndorsementType(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_ENDORSEMENT_TYPE + '?company=' + this.session.get('companyCode'), body);

  }

  getEndorseDates(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_ENDORSEMENT_REN_DATES + '?company=' + this.session.get('companyCode'), body);

  }

  validateEndorseDates(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.VALIDATE_ENDORSEMENT_DATES + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- Get CallculationType  Details ----------// 
  getCallculationType(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_CAL_TYPE + '?company=' + this.session.get('companyCode'), body);

  }

  // ----------  checkEndorsedData  Details ----------// 
  checkEndorsedData(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.CHECK_END_DATA + '?company=' + this.session.get('companyCode'), body);


  }

  checkTrimCode(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_ADME_ID + '?company=' + this.session.get('companyCode'), body);


  }

  // ----------  Call EndorsePackage  Details ----------// 
  callEndorsePackage(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.CALL_END_PACKAGE + '?company=' + this.session.get('companyCode'), body);


  }

  // ----------  Get EndorseDetails  Details ----------// 
  getEndorseDetails(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_END_DETAILS + '?company=' + this.session.get('companyCode'), body);

  }

  // ----------  Get Policy Request ----------// 
  getPolicyRequest(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POLICY_REQ + '?company=' + this.session.get('companyCode'), body);


  }

  // ---------- Update User Message  ----------// 
  updateAgentMessage(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPD_USER_AGENT_MSG + '?company=' + this.session.get('companyCode'), body);



  }

  // ---------- Get Policy History   ----------// 
  getPolicyHistory(body: any): Observable<any> {

    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POLICY_HISTORY + '?company=' + this.session.get('companyCode'), body)

  }

  // ---------- Get User Message  ----------// 
  getUserMessage(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_USER_AGENT_MSG + '?company=' + this.session.get('companyCode'), body)

  }

  // ---------- cancelEndrosement ----------// 

  cancelEndrosement(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.CANCEL_ENDORSEMENT + '?company=' + this.session.get('companyCode'), body)

  }

  // ---------- updateHomeInfo ----------// 

  updateHomeInfo(body: any): Observable<any> {
    //  alert("Company is**"+this.session.get('companyCode'));
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_HOME_INFO_URL + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- get DMS Type List ----------// 

  getDMSTypeList(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_DMS_TYPE_LIST + '?company=' + this.session.get('companyCode'), body)

  }

  getPolicyInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POLICY_INFO + '?company=' + this.session.get('companyCode'), body)

  }


  getDocumentList(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_DOC_LIST + '?company=' + this.session.get('companyCode'), body);

  }



  getSchemes(body: any): Observable<Schemes> {
    return this.http.post<Schemes>(this.baseUrl + ApiUrls.GET_AGENT_SCHEMES + '?company=' + this.session.get('companyCode'), body);

  }

  getSchemeCovers(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_SCHEMECOVERS_URL + '?company=' + this.session.get('companyCode'), body);

  }

  getAllCovers(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_ALLCOVERS_URL + '?company=' + this.session.get('companyCode'), body);

  }

  getTravelSubCovers(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_TRAVEL_SUB_COVERS + '?company=' + this.session.get('companyCode'), body);

  }

  updateOptionalCover(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_OPTIONAL_COVER_URL + '?company=' + this.session.get('companyCode'), body);

  }

  updateHomePAB_SI(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_PABHOME_SI + '?company=' + this.session.get('companyCode'), body);

  }

  processRateReCal(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.PROCESS_RATE_RE_CALC + '?company=' + this.session.get('companyCode'), body);

  }

  fetchConfirmData(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_CONFIRM_SCREEN_DATA + '?company=' + this.session.get('companyCode'), body);

  }

  getAgentSessionProps(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_AGENT_SESSION_PROPS + '?company=' + this.session.get('companyCode'), body);

  }

  proceedToBuyPkgCall(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.PROCEED_TO_BUY_PKG + '?company=' + this.session.get('companyCode'), body);

  }

  // This service method is used to fetch the no. of Children/Servants/Drivers.
  getCount(): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_COUNT_URL + '?company=' + this.session.get('companyCode'), {});

  }
  // This service method is used to fetch the questions related to home lob.
  getUWQuestions(): Observable<any> {
    let body = {};
    return this.http.post(this.baseUrl + ApiUrls.GET_UWQUESTIONS_URL + '?company=' + this.session.get('companyCode'), body);

  }
  // This service method is used to update the user information.

  updateInsuredInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_INSURED_INFO_URL + '?company=' + this.session.get('companyCode'), body);

  }

  getApplicationRefCodes(refType: any, referenceCode: any): Observable<any> {
    const postData = {
      type: refType,
      refCode: referenceCode
    }
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APPL_REF_CODES + '?company=' + this.session.get('companyCode'), postData);

  }

  getApplicationCodes(refType: any): Observable<any> {
    const postData = {
      type: refType
    }
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APPL_CODES + '?company=' + this.session.get('companyCode'), postData);

  }

  getApplicationCountryCodes(refType: any): Observable<any> {
    const postData = {
      type: refType
    }
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APPL_COUNTRY_CODES + '?company=' + this.session.get('companyCode'), postData);

  }
  /*
    getGenderLists(refType: any): Observable<any> {
      const postData = {
        type: refType
      }
      return this.http.post<any>(this.baseUrl + ApiUrls.GET_APP_PARAM+ '?company=' + this.session.get('companyCode'), postData);
  
    }
  */
  getTaxFlag(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APP_PARAM + '?company=' + this.session.get('companyCode'), body);

  }

  getQuoteInformation(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_QUOT_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  getHeaderInformation(body: any) {
    return this.http.get<any>(this.baseUrl + ApiUrls.GET_HEADER_INFO + '?company=' + this.session.get('companyCode') + '&transId=' + body.transId + "&tranSrNo=" + body.tranSrNo);

  }

  getPremiumSummary(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_PREMIUM_SUMMARY + '?company=' + this.session.get('companyCode'), body);

  }




  getCylinderList(body: any): Observable<VehicleCylinders> {
    return this.http.post<VehicleCylinders>(this.baseUrl + ApiUrls.MOTOR_APPL_LIST + '?company=' + this.session.get('companyCode'), body);

  }



  //This method is used to approve & create Policy no.
  approvePolicy(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.APPROVE_POLICY + '?company=' + this.session.get('companyCode'), body);

  }

  //This method is used to fetch quotation details by mapId
  getQuotInsInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOT_INS_INFO + '?company=' + this.session.get('companyCode'), body);

  }



  getGeoList(body: any): Observable<GeographicalLimits> {
    return this.http.post<GeographicalLimits>(this.baseUrl + ApiUrls.MOTOR_APPL_LIST + '?company=' + this.session.get('companyCode'), body);

  }

  getApplParam(body: any): Observable<appParamArray> {

    return this.http.post<appParamArray>(this.baseUrl + ApiUrls.MOTOR_APPL_PARAM_LIST + '?company=' + this.session.get('companyCode'), body);

  }



  createQuote(body: any): Observable<Quotation> {
    return this.http.post<Quotation>(this.baseUrl + ApiUrls.CREATE_QUOTATION + '?company=' + this.session.get('companyCode'), body);

  }


  endtProceedtoBuy(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.END_PROCEED_TO_BUY + '?company=' + this.session.get('companyCode'), body);
  }

  getSchemeProdDetails(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_SCH_PROD_DETAILS + '?company=' + this.session.get('companyCode'), body);
  }

  endtFleetProceedtoBuy(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.END_FLEET_PROCEED_TO_BUY + '?company=' + this.session.get('companyCode'), body);
  }

  updateVehicleInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_VEHICLE_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  calculatePricing(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.CALCULATE_PRICING + '?company=' + this.session.get('companyCode'), body);

  }


  getPolicyDuration(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POL_DURATION + '?company=' + this.session.get('companyCode'), body);

  }
  updateTrimValues(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_VEHICLE_TRIM_DET + '?company=' + this.session.get('companyCode'), body);

  }



  insertErrorMsg(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.INSERT_ERROR_MSG + '?company=' + this.session.get('companyCode'), body);

  }

  // /*getQuoteInformation(body :any){
  //   return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_INFO+'?company='+this.session.get('companyCode'),body)
  //   .pipe(map((response : Response) =>{
  //     return response.json();
  //   })); 
  // }*/

  getCoverSummary(body: any): Observable<CoverSummary> {

    return this.http.post<CoverSummary>(this.baseUrl + ApiUrls.GET_COVER_SUMMARY + '?company=' + this.session.get('companyCode'), body);

  }

  getDiscDedLoadFeesSumm(body: any): Observable<DiscountDeductibleSummary> {
    return this.http.post<DiscountDeductibleSummary>(this.baseUrl + ApiUrls.GET_DIS_DUCT_SUMMARY + '?company=' + this.session.get('companyCode'), body);

  }


  updateEdataVehicleInfo(body) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_EDATA_VEH_INFO + '?company=' + this.session.get('companyCode'), body);

  }
  getEdataInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_EDATA_QUOTE_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  getEdataVehicleInfo(chassisNo: string): Observable<any> {
    return this.http.get<any>(this.baseUrl + ApiUrls.GET_EDATA_VEH_INFO + '?company=' + this.session.get('companyCode') + '&chassisNo=' + chassisNo);

  }

  getEdataEngineSizelist(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_EDATA_ENGINE_SIZE + '?company=' + this.session.get('companyCode') +
      "&year=" + body.year + "&make=" + encodeURI(body.make) + "&model=" + encodeURI(body.model) + "&trim="
      + encodeURI(body.trim) + "&bodyType=" + encodeURI(body.bodyType), body);

  }

  getEdataTrimList(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.EDATA_TRIM_LIST + '?company=' + this.session.get('companyCode') +
      "&year=" + body.year + "&make=" + encodeURI(body.make) + "&model=" + encodeURI(body.model), body);

  }

  eDataEvaluation(body) {
    return this.http.post<any>(this.baseUrl + ApiUrls.EDATA_EVALUATION + '?company=' + this.session.get('companyCode'),
      body);

  }

  getEdataCode(acType: string, edataDesc: string): Observable<any> {

    return this.http.get<any>(this.baseUrl + ApiUrls.GET_EDATA_CODE + '?company=' + this.session.get('companyCode') + '&acType=' + acType + "&edataDesc=" + edataDesc);

  }
  getEdataBodyTypeList(acType: string): Observable<any> {
    return this.http.get<any>(this.baseUrl + ApiUrls.GET_EDATA_BODY_TYPE_LIST + '?company=' + this.session.get('companyCode') + '&acType=' + acType)

  }
  getVehicleInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_VEH_INFO + '?company=' + this.session.get('companyCode'), body);

  }
  getNetPremium(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_NET_PREMIUM + '?company=' + this.session.get('companyCode'), body);

  }
  insertAdditionalDriverInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_ADDL_DRIVER_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  getCoverInfo(body: any) {

    return this.http.post(this.baseUrl + ApiUrls.GET_COVER_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  approveAgentPolicy(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.APPROVE_AGENT_POLICY + '?company=' + this.session.get('companyCode'), body);

  }

  valDupChassisNo(body: any) {

    return this.http.post<any>(this.baseUrl + ApiUrls.VAL_DUP_CHASSIS_NO + '?company=' + this.session.get('companyCode'), body);

  }
  checkChassisNoEditWhileChassiflow(body: any) {

    return this.http.post<any>(this.baseUrl + ApiUrls.CHECK_CHASSIS_FLOW + '?company=' + this.session.get('companyCode'), body);

  }
  checkEdataChassisFlow(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.CHECK_EDATA_CHASSIS_NO + '?company=' + this.session.get('companyCode'), body);
  }

  valDupChassisNoPkg(body: any) {

    return this.http.post<any>(this.baseUrl + ApiUrls.VALIDATE_PKG_DUP_CHASSIS_NO + '?company=' + this.session.get('companyCode'), body);

  }

  allowChassisNo(body: any) {

    return this.http.post(this.baseUrl + ApiUrls.ALLOW_CHASSIS_NO + '?company=' + this.session.get('companyCode'), body);

  }
  getAgentAuthDtls(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_AGENT_AUTH_DTLS + '?company=' + this.session.get('companyCode'), body);

  }

  getInsuredInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_INSURED_DTLS + '?company=' + this.session.get('companyCode'), body);

  }

  getCertQuoteInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_CERT_QUOT_DTLS + '?company=' + this.session.get('companyCode'), body);

  }

  getAddlInsuredInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_INSURED_DTLS + '?company=' + this.session.get('companyCode'), body);

  }

  updateInstFlag(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSTALL_FLAG + '?company=' + this.session.get('companyCode'), body);

  }

  dispInst(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_ISTALLMENT_DETLS + '?company=' + this.session.get('companyCode'), body);

  }




  getDiscriptionList(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_DISCRIPTION_DETLS + '?company=' + this.session.get('companyCode'), body);

  }

  getAddtionalOtherInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_OTHER_DETLS + '?company=' + this.session.get('companyCode'), body);
  }


  insertQuoteOtherInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_OTHER_DETLS + '?company=' + this.session.get('companyCode'), body);
  }

  getDriverDetails(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_DRIVER_DETLS + '?company=' + this.session.get('companyCode'), body);

  }


  getBoundTypes(body): Observable<BoundType> {
    return this.http.post<BoundType>(this.baseUrl + ApiUrls.GET_APP_PARAM + '?company=' + this.session.get('companyCode'), body);
  }


  getCountryList(body): Observable<CountryList> {
    return this.http.post<CountryList>(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body);


  }
  updateTravelInfo(body: any): Observable<TravelInfo> {
    return this.http.post<TravelInfo>(this.baseUrl + ApiUrls.UPDATE_TRAVEL_INFO_URL + '?company=' + this.session.get('companyCode'), body);

  }

  updateTravelAddInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_TRAVEL_ADDL_INFO_URL + '?company=' + this.session.get('companyCode'), body);

  }

  getTravelAddInfo(body: any): Observable<any> {
    if (body) {
      body.userId = this.session.get('username');
    }
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_TRAVEL_ADDL_INFO_URL + '?company=' + this.session.get('companyCode'), body);

  }

  getQuotInfo(body: any): Observable<TravelQuoteInfo> {
    return this.http.post<TravelQuoteInfo>(this.baseUrl + ApiUrls.GET_QUOTE_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  getQuoteTravelInfo(body: any): Observable<TravelInfo> {
    return this.http.post<TravelInfo>(this.baseUrl + ApiUrls.GET_QUOTE_TRAVEL_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  getRelationType(body: any): Observable<any> {

    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body);

  }

  getGenderList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_PARAM + '?company=' + this.session.get('companyCode'), body);

  }

  getNationalityList(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body);

  }

  getCityList(body: any): Observable<any> {

    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APP_REF_CODES + '?company=' + this.session.get('companyCode'), body);

  }
  getOccupationType(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body);

  }

  getAgentNetPremium(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_AGENT_PREM + '?company=' + this.session.get('companyCode'), body);

  }

  insertTravelInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.INS_TRAVEL_INFO + '?company=' + this.session.get('companyCode'), body);

  }


  updateInsInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSURED_INFO_URL + '?company=' + this.session.get('companyCode'), body);

  }


  checkPolicyForRenewal(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.CHECK_POLICY_FOR_RENEWAL + '?company=' + this.session.get('companyCode'), body);

  }



  chkChassisExist(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.CHECK_CHASSIS_EXISTS + '?company=' + this.session.get('companyCode'), body);

  }

  getRecalculte(body): any {
    return this.http.post<any>(this.baseUrl + ApiUrls.ADJUST_POLICY_PKG + '?company=' + this.session.get('companyCode'), body)

  }




  getHomeInfo(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_HOME_INFO + '?company=' + this.session.get('companyCode'), body);

  }


  // This service method is used to update the endorsed information.
  updateEndorsedInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSURED_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  proceedToBuyEndorsement(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.PROCEED_TO_BUY + '?company=' + this.session.get('companyCode'), body);
  }

  cancelEndorsement(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CANCEL_ENDORSEMENT + '?company=' + this.session.get('companyCode'), body);

  }


  getTravelerDetls(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_TRAVEL_DETAILS + '?company=' + this.session.get('companyCode'), body);

  }

  getAgentFilterInfo(body: any) {
    return this.http.get<any>(this.baseUrl + ApiUrls.GET_AGENT_FILTER + '?company=' + this.session.get('companyCode') + '&userRoleId=' + body.userRoleId + '&lobCode=' + body.lobCode);

  }


  // //------------------Policy Cancel Endorsment---------------//

  getPlateType(body: any): Observable<any> {

    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body);
  }

  getImportCountryList(body: any): Observable<any> {

    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES_COUNTRY + '?company=' + this.session.get('companyCode'), body);
  }



  VechicleShape(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body);
  }

  agentForgotPwd(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.AGENT_FORGOT_PWD + '?company=' + this.session.get('companyCode'), body);

  }
  edataSumInsuredValidation(transId, tranSrNo, sumAssured, userId) {
    return this.http.get<any>(this.baseUrl + ApiUrls.EDATA_SUM_INSURED_VALIDATION + '?company=' + this.session.get('companyCode') + "&transId=" + transId + "&tranSrNo=" + tranSrNo
      + "&sumAssured=" + sumAssured + "&userId=" + userId);

  }


  // //----------------claim Search-------------------//

  getClaimInfo(body: any): Observable<Dashboardinterface> {
    return this.http.post<Dashboardinterface>(this.baseUrl + ApiUrls.GET_CLAIM_INFO + '?company=' + this.session.get('companyCode'), body)


  }


  getClaimRatioList(body: any): Observable<any> {
    return this.http.get<any>(this.baseUrl + ApiUrls.GET_CLAIM_RATIO_INFO + '?company=' + this.session.get('companyCode') + '&policyNo=' + body);


  }

  // //--------------Endrosment AddDelCoverInfo-------///
  getAddlCoverInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_ADDL_COVER_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  deleteAddlCover(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.DEL_ADDL_COVER + '?company=' + this.session.get('companyCode'), body);

  }

  addRemoveCover(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.INCL_EXCL_COVER + '?company=' + this.session.get('companyCode'), body);

  }

  getOptionalCover(body: any): Observable<CoverSummary> {
    return this.http.post<CoverSummary>(this.baseUrl + ApiUrls.GET_OPT_COVER + '?company=' + this.session.get('companyCode'), body);

  }
  getTaxCover(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_TAX_COVER + '?company=' + this.session.get('companyCode'), body);

  }
  getPremCoverInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_PREM_COVER_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  endProceedToConfirm(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.END_PRCED_CONFRM + '?company=' + this.session.get('companyCode'), body);

  }

  getDelCoveSumm(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_DEL_COVER_INFO + '?company=' + this.session.get('companyCode'), body);

  }

  // ---------- Fleet Policy List ----------//
  getFleetPolicies(body: any): Observable<Dashboardinterface> {
    return this.http.post(this.baseUrl + ApiUrls.GET_FLEET_POLICY_LIST + '?company=' + this.session.get('companyCode'), body);


  }

  // ---------- getAgentDashboardUrl List ----------//
  getAgentDashboardUrl(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_AGENT_DASH_URL + '?company=' + this.session.get('companyCode'), body);


  }

  // ---------- getFleetvehicleList List ----------//
  getFleetvehicleList(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_FLEET_VEH_LIST + '?company=' + this.session.get('companyCode'), body);


  }
  getPolicyTax(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POL_TAX_LIST + '?company=' + this.session.get('companyCode'), body);

  }

  getEditFlagTax(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_EDIT_FLAG + '?company=' + this.session.get('companyCode'), body);

  }
  getWinSportsFlgYN(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_WIN_SPRTS_FLAG + '?company=' + this.session.get('companyCode'), body);
  }

  getTaxApplYn(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_TAX_APPL_FLAG + '?company=' + this.session.get('companyCode'), body);
  }

  callInstallmentProcedure(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.CALL_INST_PROC + '?company=' + this.session.get('companyCode'), body);
  }

  displayInstallment(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.DISP_INST_DETLS + '?company=' + this.session.get('companyCode'), body);
  }

  updateInstallmentNo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_INST_DETLS + '?company=' + this.session.get('companyCode'), body);
  }


  // For Payment//

  registerPayment(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.REG_PAYMENT + '?company=' + this.session.get('companyCode'), body);
  }

  getPaymentOption(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_PAYMENT_OPTIONS_URL + '?company=' + this.session.get('companyCode'), body);
  }

  getAgentList(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_AGENT_LIST + '?company=' + this.session.get('companyCode'), body);
  }

  updateAgentCommissionInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_AGENT_COMMISSON + '?company=' + this.session.get('companyCode'), body);
  }

  // Motor insurence chassis number
  getVehicleInfoFromChassisNo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_VECHILE_INFO_BY_CHASSIS +
      '?company=' + this.session.get('companyCode') +
      '&agentId=' + this.session.get('agent'),
      body);
  }

  getModelYears(): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_MODEL_YEAR +
      '?company=' + this.session.get('companyCode'), {});
  }

  getVehicleMakeList(): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_MAKE_LIST +
      '?company=' + this.session.get('companyCode'), {});
  }

  getVehicleModelList(makeInfo: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_MODEL_LIST +
      '?company=' + this.session.get('companyCode'),
      makeInfo);
  }

  getSpecifications(vechileInfo: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_SPECIFICATIONS +
      '?company=' + this.session.get('companyCode') +
      '&agentId=' + this.session.get('agent'),
      vechileInfo);
  }

  getVehDetails(vechileInfo: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_AUTODATA_VEH_DETAILS +
      '?company=' + this.session.get('companyCode') +
      '&agentId=' + this.session.get('agent'),
      vechileInfo);
  }

  getQuoteData(request: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_QUOTE +
      '?company=' + this.session.get('companyCode') +
      '&agentId=' + this.session.get('agent'),
      request);
  }

  getDocumentsList(transId: string): Observable<any> {
    return this.http.get<any>(this.baseUrl + ApiUrls.GET_DOCS +
      '?company=' + this.session.get('companyCode') +
      '&transId=' + transId);
  }

  viewDocument(docNo: string): Observable<any> {
    return this.http.get<any>(this.baseUrl + ApiUrls.VIEW_DOCS + '?company=' + this.session.get('companyCode') +
      '&docNo=' + docNo);
  }

  sendPayLink(request: any): Observable<any> {
    if (request) {
      request.userId = this.session.get('LoginID');
    }
    return this.http.post<any>(this.baseUrl + ApiUrls.SEND_PAY_LINK +
      '?company=' + this.session.get('companyCode'),
      request);
  }

  /* Pleasure craft service methods.*/
  getYachtInfo() {
    return this.http.get<any>(this.baseUrl + ApiUrls.GET_YACHT_INFO + '?userType=Agent&company=' + this.session.get('companyCode'));
  }

  getPolVehicleInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_CLM_VEH_INFO + '?company=' + this.session.get('companyCode'), body);
  }

  updateBoatInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_BOAT_INFO + '?company=' + this.session.get('companyCode'), body);
  }
  getProductForMarine(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_PRODUCTS + '?company=' + this.session.get('companyCode'), body);
  }
  getBasicInfo(body: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_BOAT_QUOTE_RISK_INFO + '?company=' + this.session.get('companyCode'), body);
  }

  // Home Insurance Content block
  getHomeConentServantInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_HOME_CONTENT_SERVENT_INFO + '?company=' + this.session.get('companyCode'), body);
  }


  insContentDetls(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.INSERT_CONTENT_DETAILS + '?company=' + this.session.get('companyCode'), body);

  }

  getContentDetls(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_CONTENT_DETAILS + '?company=' + this.session.get('companyCode'), body);
  }
  getPolicyContentDetls(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_POLICY_CONTENT_DETAILS + '?company=' + this.session.get('companyCode'), body);
  }
  getSumInsuredRange(body: any) {
    return this.http.post<any>(this.baseUrl + 'getSumInsuredRange' + '?company=' + this.session.get('companyCode'), body);

  }
  getVehicleCount(body: any) {
    return this.http.post<any>(this.baseUrl + 'getVehicleCount' + '?company=' + this.session.get('companyCode'), body);
  }



  getAutoDataRiskDetails(body: any) {
    return this.http.post<any>(this.baseUrl + 'getAutoDataRiskDetails' + '?company=' + this.session.get('companyCode'), body);

  }

  updatePolicyDuration(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.UPDATE_POL_DURATION + '?company=' + this.session.get('companyCode'), body);
  }

  approveWorkflowRequest(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.APPR_WF_REQ + '?company=' + this.session.get('companyCode'), body);
  }

  getPendingTranPolicyDetails(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_PI_POL_DTLS + '?company=' + this.session.get('companyCode'), body);
  }

  generateAndUploadProposalForm(body: any) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GEN_AND_UPLD_PROPFORM + '?company=' + this.session.get('companyCode'), body);

  }
}
