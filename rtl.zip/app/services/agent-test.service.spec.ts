import { TestBed } from '@angular/core/testing';

import { AgentTestService } from './agent-test.service';

describe('AgentTestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgentTestService = TestBed.get(AgentTestService);
    expect(service).toBeTruthy();
  });
});
