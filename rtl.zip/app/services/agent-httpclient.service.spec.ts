import { TestBed } from '@angular/core/testing';

import { AgentHttpclientService } from './agent-httpclient.service';

describe('AgentHttpclientService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgentHttpclientService = TestBed.get(AgentHttpclientService);
    expect(service).toBeTruthy();
  });
});
