export class AgentClaim {
}
