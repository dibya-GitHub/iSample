import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentHttpclientService } from 'src/app/services/agent-httpclient.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';


@Component({
  selector: 'app-report-claim',
  templateUrl: './report-claim.component.html',
  styleUrls: ['./report-claim.component.scss']
})
export class ReportClaimComponent implements OnInit {
  emiratedId: any;
  policyNo: any;
  searchBy: string;
  tmpData: any;
  showError = false;
  showErrorMsg: any;


  constructor(
    private session: SessionStorageService,
    private fb: UntypedFormBuilder,
    private router: Router,
    public route: ActivatedRoute,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService
  ) {
    this.route.queryParams.subscribe(params => {
      // this.txnId = params["id"];
      // this.srNo = params["srNo"];
      // this.polNo = params["polNo"];
      let data = params["searchBy"];
      if (data != undefined) {
        this.searchBy = data;
        if (data == 'TPI_CIVIL_ID') {
          this.emiratedId = params["value"];
        } else {
          this.policyNo = params["value"];
        }
      }
    });
  }

  ngOnInit() {

  }
  getActivePolicyList() {
    if ((this.emiratedId === undefined || this.emiratedId.trim() == '') && (this.policyNo === undefined || this.policyNo.trim() == '')) {
      this.showErrorMsg = 'Please enter policy no or emirates id';
      this.showError = true;
    } else {
      if (this.emiratedId != '') {
        this.tmpData = this.emiratedId;
        this.searchBy = "TPI_CIVIL_ID"
      }
      if (this.policyNo) {
        this.tmpData = this.policyNo;
        this.searchBy = "TPI_POLICY_NO"
      }
      this.tmpData = this.tmpData.trim();
      let obj = { searchBy: this.searchBy, value: this.tmpData }
      this.router.navigate(['find-active-policy'], { queryParams: obj, skipLocationChange: true });
    }
  }
}
