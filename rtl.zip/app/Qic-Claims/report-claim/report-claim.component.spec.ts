import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportClaimComponent } from './report-claim.component';

describe('ReportClaimComponent', () => {
  let component: ReportClaimComponent;
  let fixture: ComponentFixture<ReportClaimComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportClaimComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
