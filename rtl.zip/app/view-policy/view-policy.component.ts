import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
@Component({
  selector: 'app-view-policy',
  templateUrl: './view-policy.component.html',
  styleUrls: ['./view-policy.component.scss']
})
export class ViewPolicyComponent implements OnInit {

  customerInfo: any;
  vehicleInfo: any;
  coversDetails: any;
  goodsDetails: any;
  termsCond: any;
  travelInfo: any;
  travelersDetails: any;
  homeInfo: any;
  boatInfo: any;
  homeDetails: any;
  otherDed: any;
  otherFees: any;
  otherLoad: any;
  otherDisc: any;
  otherTax: any;
  summaryInfo: any;
  printCreditAccess: string;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  showContent: any;
  lobCode: any;

  constructor(
    private router: Router,
    private session: SessionStorageService,
    private commonService: AgentUserService, 
    private agentService: AgentHttpclientService,
    ) { }

  ngOnInit() {

    this.lobCode = this.commonService.getParamValue('lobCode');
    var tranSrNo = this.commonService.getParamValue('tranSrNo');
    var transId = this.commonService.getParamValue('transId');
    var params = { "transId": transId, "tranSrNo": tranSrNo, "lobCode": this.lobCode };
    this.getContentdetails(transId, tranSrNo);
    this.agentService.viewPolicyDetails(params)
      .subscribe(result => {
        this.otherDed = result.otherDed.othersArray;
        this.otherDisc = result.otherDisc.othersArray;
        this.otherFees = result.otherFees.othersArray;
        this.otherLoad = result.otherLoad.othersArray;
        this.otherTax = result.otherTax.othersArray;
        this.coversDetails = result.coversDetails;
        this.goodsDetails = result.goodsDetails;
        this.termsCond = result.termsCond;
        this.customerInfo = result.customerInfo;
        this.vehicleInfo = result.vehicleInfo;
        this.travelInfo = result.travelInfo;
        this.travelersDetails = result.travelersDetails;
        this.homeInfo = result.homeInfo;
        this.boatInfo = result.boatInfoBean;
        this.homeDetails = result.homeDetails;
        this.summaryInfo = result.summaryInfo


      });
    this.printCreditAccess = this.session.get('printCreditAccess');
  }

  hasPrintAccess() {
    return ("1" == this.session.get("printCreditAccess"));
  }
  showdialog(viewpolicy) {
    viewpolicy.className = 'modal show';
  }
  getContentdetails(transId, tranSrNo) {
    let editparam = {
      "transId": transId,
      "tranSrNo": tranSrNo,
    };
    this.agentService.getPolicyContentDetls(editparam).subscribe(response => {
      this.showContent = response.contentPolicyDetails;
    },
      error => {
      });
  }

}
