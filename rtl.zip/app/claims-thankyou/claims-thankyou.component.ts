import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claims-thankyou',
  templateUrl: './claims-thankyou.component.html',
  styleUrls: ['./claims-thankyou.component.scss']
})
export class ClaimsThankyouComponent implements OnInit {
  Is_complaint: any;
  constructor() { }

  ngOnInit() {
  }

}
