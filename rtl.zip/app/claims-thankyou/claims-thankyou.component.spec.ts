import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsThankyouComponent } from './claims-thankyou.component';

describe('ClaimsThankyouComponent', () => {
  let component: ClaimsThankyouComponent;
  let fixture: ComponentFixture<ClaimsThankyouComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimsThankyouComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsThankyouComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
