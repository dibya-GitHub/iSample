import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AgentDashboardComponent } from 'src/app/agent-dashboard/agent-dashboard.component';
import { AgentUserService } from "../shared/services/agent-user.service";
import { ApiHeadersService } from "../shared/services/api-header.service";
import { AdditionalSiAdjustmentEndorsementComponent } from './additional-discounts-si-adjustment-endorsement/additional-discounts-si-adjustment-endorsement.component';
import { AppComponent } from './app.component';
import { ConfirmQuoteComponent } from './confirm-quote/confirm-quote.component';
import { EndorsementsComponent } from './endorsements/endorsements.component';
import { HomeComponent } from './home/home.component';
import { AdditionalInfoScreenComponent } from './motor-insurance/additional-info-screen/additional-info-screen.component';
import { NumbersOnlyDirectiveDirective } from './motor-insurance/directives/numbers-only-directive.directive';
import { PrimaryMotorInfoComponent } from './motor-insurance/primary-motor-info/primary-motor-info.component';
import { NonFinancialEndorsementComponent } from './non-financial-endorsement/non-financial-endorsement.component';
import { PremiumAdjustmentEndorsementComponent } from './premium-si-adjustment-endorsement/premium-si-adjustment-endorsement.component';
import { PremiumSiAdjustmentEndorsementSummary } from './premium-si-endorsement-summary/premium-si-endorsement-summary.component';
import { SchemePlansComponent } from './scheme-plans/scheme-plans.component';
import { ViewDocumentComponent } from './view-document/view-document.component';
import { ViewPolicyComponent } from './view-policy/view-policy.component';
// import { InsuranceService } from '../shared/services/insurance.service';
import { CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import {DpDatePickerModule} from 'ng2-date-picker';
import { AddCoverConfirmEndComponent } from './add-cover-confirm-end/add-cover-confirm-end.component';
import { AddCoverEndorsmentComponent } from './add-cover-endorsment/add-cover-endorsment.component';
import { AddCoverSummaryEndComponent } from './add-cover-summary-end/add-cover-summary-end.component';
import { AddTravelInfoComponent } from './add-travel-info/add-travel-info.component';
import { AdditionalExtensionEndorsementComponent } from './additional-extension-endorsement/additional-extension-endorsement.component';
import { AgentFooterComponent } from './agent-footer/agent-footer.component';
import { AgentHeaderComponent } from './agent-header/agent-header.component';
import { AgentLoginComponent } from './agent-login/agent-login/agent-login.component';
import { ForgotPasswordComponent } from './agent-login/forgot-password/forgot-password.component';
import { AgentTravelComponent } from './agent-travel/agent-travel.component';
import { AppRoutingModule } from './app-routing.module';
import { TokenInterceptor } from './auth/token-interceptor';
import { CertificateEndorsementComponent } from './certificate-endorsement/certificate-endorsement/certificate-endorsement.component';
import { ChangeInVehParamEndorsementComponent } from './change-in-vehicleParameter-end/change-in-veh-param-endorsement/change-in-veh-param-endorsement.component';
import { ChangeOwnershipComponent } from './change-ownership-endorsement/change-ownership-endorsement.component';
import { IntallmentGridComponent } from './common/intallment-grid/intallment-grid.component';
import { ReferralComponentComponent } from './common/referral-component/referral-component.component';
import { ReloadAdditionalChargesComponent } from './common/reload-additional-charges/reload-additional-charges.component';
import { EndorsementApproveComponent } from './endorsement-approve/endorsement-approve.component';
import { ExtensionPolicyEndorsementComponent } from './extension-policy/extension-policy-endorsement.component';
import { ExtensionSummaryEndorsement } from './extension-summary-endorsement/extension-summary-endorsement.component';
import { FilterdataPipe } from './filterdata.pipe';
import { FleetCertificateProceedComponent } from './fleet-certificate-proceed/fleet-certificate-proceed.component';
import { HomeCoverProcessComponent } from './home-cover-process/home-cover-process.component';
import { AdditionalHomeInfoComponent } from './home/additional-home-info/additional-home-info.component';
import { HomeInsurancePlanService } from './home/services/home-insurance-plan.service';
import { FirstScreenMotorComponent } from './motor-insurance/first-screen-motor/first-screen-motor.component';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { PolicyCancelSummEndComponent } from './policy-cancel-summ-end/policy-cancel-summ-end.component';
import { PolicyCancelationEndorsmentComponent } from './policy-cancelation-endorsment/policy-cancelation-endorsment.component';
import { PolicyHistoryComponent } from './policy-history/policy-history.component';
import { PolicyRenewalDashboardComponent } from './policy-renewal-dashboard/policy-renewal-dashboard.component';
import { PolicyThankYouComponent } from './policy-thank-you/policy-thank-you.component';
import { ProgressBarComponent } from './progress-bar/progress-bar.component';
import { QuoteDashboardComponent } from './quote-dashboard/quote-dashboard.component';
import { QuoteInfoComponent } from './quote-info/quote-info.component';
import { SessionTimeoutComponent } from './session-timeout/session-timeout.component';
import { SummaryInfoComponent } from './summary-info/summary-info.component';
import { DragDirective } from './upload-documents/drag.directive';
import { UploadDocumentsComponent } from './upload-documents/upload-documents.component';
import { ViewClaimComponent } from './view-claim/view-claim.component';


import { AgGridModule } from '@ag-grid-community/angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { AngularMyDatePickerModule } from 'angular-mydatepicker';
import { CurrencyMaskModule } from "ng2-currency-mask";
import { NgxLoadingModule } from 'ngx-loading';
import { NgxPaginationModule } from 'ngx-pagination';
import { MessageService } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { PanelModule } from 'primeng/panel';
import { ToastModule } from 'primeng/toast';
import { EmiratesIdDirective } from 'src/shared/directives/emirates-id.directive';
import { LoaderService } from '../shared/loader-service/loader.service';
import { UploadClaimsDocumentsComponent } from './ClaimsUpload/upload-claims-documents/upload-claims-documents.component';
import { TpClaimComponent } from './NonQic-Claims/tp-claim/tp-claim.component';
import { ReportClaimComponent } from './Qic-Claims/report-claim/report-claim.component';
import { AgGridLinkComponent } from './ag-grid-link/ag-grid-link.component';
import { MarineLoginComponent } from './agent-login/marine-login/marine-login.component';
import { IntimateClaimsComponent } from './claim-intimation/intimate-claims/intimate-claims.component';
import { ClaimsThankyouComponent } from './claims-thankyou/claims-thankyou.component';
import { CurrencyDirective } from './currency-format.directive';
import { EndorsmentApprovalComponent } from './endorsment-approval/endorsment-approval.component';
import { FindActivePolicyComponent } from './find-active-policy/find-active-policy.component';
import { MarineAddlInfoComponent } from './marine-insurance/marine-addl-info/marine-addl-info.component';
import { MarineCreateCertificateComponent } from './marine-insurance/marine-create-certificate/marine-create-certificate.component';
import { MarineInfoComponent } from './marine-insurance/marine-info/marine-info.component';
import { MarineUploadInfoComponent } from './marine-insurance/marine-upload-info/marine-upload-info.component';
import { PCraftAdditionalInfo } from './pleasure-craft/p-craft-additional-info/p-craft-additional-info.component';
import { PCraftBasicInfoComponent } from './pleasure-craft/p-craft-basic-info/p-craft-basic-info.component';
import { PCraftConfirmationComponent } from './pleasure-craft/p-craft-confirmation/p-craft-confirmation.component';
import { PCraftSelectPolicyComponent } from './pleasure-craft/p-craft-select-policy/p-craft-select-policy.component';
import { SubmitClaimComponent } from './submit-claim/submit-claim.component';
import { WorkflowAddlInfoScreenComponent } from './workflow-addl-info-screen/workflow-addl-info-screen.component';
import { WorkflowComponent } from './workflow-det/workflow/workflow.component';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';


import { RECAPTCHA_SETTINGS, RecaptchaFormsModule, RecaptchaModule, RecaptchaSettings } from 'ng-recaptcha';
// import { MyDateRangePickerModule } from 'mydaterangepicker';
// import { DateTimePickerModule } from 'ng-pick-datetime';
// import { ParallaxModule } from 'ngx-parallax';
import { environment } from 'src/environments/environment';

@NgModule({
    schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
    ],
    declarations: [
        AppComponent,
        AgentDashboardComponent,
        SchemePlansComponent,
        PrimaryMotorInfoComponent,
        NumbersOnlyDirectiveDirective,
        AdditionalInfoScreenComponent,
        ViewDocumentComponent,
        ViewPolicyComponent,
        EndorsementsComponent,
        NonFinancialEndorsementComponent,
        ConfirmQuoteComponent,
        AgentHeaderComponent,
        AgentFooterComponent,
        ReferralComponentComponent,
        HomeCoverProcessComponent,
        HomeComponent,
        AdditionalHomeInfoComponent,
        SummaryInfoComponent,
        ReloadAdditionalChargesComponent,
        AgentTravelComponent,
        AddTravelInfoComponent,
        AdditionalHomeInfoComponent,
        UploadDocumentsComponent,
        PolicyCancelationEndorsmentComponent,
        ChangeOwnershipComponent,
        PolicyHistoryComponent,
        AgentLoginComponent,
        ForgotPasswordComponent,
        ViewClaimComponent,
        ForgotPasswordComponent,
        FirstScreenMotorComponent,
        EndorsementApproveComponent,
        AddCoverEndorsmentComponent,
        SummaryInfoComponent,
        DragDirective,
        AddCoverSummaryEndComponent,
        AddCoverConfirmEndComponent,
        SummaryInfoComponent,
        QuoteInfoComponent,
        ProgressBarComponent,
        PremiumAdjustmentEndorsementComponent,
        AdditionalSiAdjustmentEndorsementComponent,
        PremiumSiAdjustmentEndorsementSummary,
        PolicyCancelSummEndComponent,
        PremiumSiAdjustmentEndorsementSummary,
        ExtensionPolicyEndorsementComponent,
        AdditionalExtensionEndorsementComponent,
        ExtensionSummaryEndorsement,
        FleetCertificateProceedComponent,
        CertificateEndorsementComponent,
        FleetCertificateProceedComponent,
        ChangeInVehParamEndorsementComponent,
        FilterdataPipe,
        CurrencyDirective,
        SessionTimeoutComponent,
        PolicyThankYouComponent,
        IntallmentGridComponent,
        QuoteDashboardComponent,
        PolicyRenewalDashboardComponent,
        MyDashboardComponent,
        AgGridLinkComponent,
        EndorsmentApprovalComponent,
        PCraftBasicInfoComponent,
        EmiratesIdDirective,
        PCraftBasicInfoComponent,
        PCraftAdditionalInfo,
        PCraftSelectPolicyComponent,
        PCraftConfirmationComponent,
        MarineInfoComponent,
        MarineCreateCertificateComponent,
        MarineAddlInfoComponent,
        MarineUploadInfoComponent,
        MarineLoginComponent,
        IntimateClaimsComponent,
        ReportClaimComponent,
        TpClaimComponent,
        FindActivePolicyComponent,
        SubmitClaimComponent,
        UploadClaimsDocumentsComponent,
        ClaimsThankyouComponent,
        WorkflowComponent,
        WorkflowAddlInfoScreenComponent,
    ],
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        HttpClientModule,
        NgSelectModule,
        AngularMyDatePickerModule,
        NgbModule,
        NgxPaginationModule,
        ToastModule,
        CurrencyMaskModule,
        AgGridModule.withComponents([AgGridLinkComponent]),
        AutoCompleteModule,
        PanelModule,
        NgxLoadingModule,
        RecaptchaFormsModule,
        RecaptchaModule,
        NgIdleKeepaliveModule.forRoot(),
        DpDatePickerModule,
        // DateTimePickerModule,
        // ParallaxModule,
        // MyDateRangePickerModule,
    ],
    providers: [
        MessageService,
        // ApiHeadersService,
        DatePipe,
        DecimalPipe,
        LoaderService,
        CurrencyPipe,
        // InsuranceService,
        HomeInsurancePlanService,
        AgentUserService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: TokenInterceptor,
            multi: true
        },
        {
            provide: RECAPTCHA_SETTINGS,
            useValue: {
                siteKey: environment.siteKey,
            } as RecaptchaSettings,
        },
    ],
    bootstrap: [AppComponent],
})

export class AppModule {

}

