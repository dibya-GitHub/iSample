import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCoverSummaryEndComponent } from './add-cover-summary-end.component';

describe('AddCoverSummaryEndComponent', () => {
  let component: AddCoverSummaryEndComponent;
  let fixture: ComponentFixture<AddCoverSummaryEndComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddCoverSummaryEndComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCoverSummaryEndComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
