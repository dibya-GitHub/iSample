import { Component, OnInit } from '@angular/core';
import { FormGroup, UntypedFormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { ApplicationConstants } from 'src/shared/application-constants';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'add-cover-summary-end',
  templateUrl: './add-cover-summary-end.component.html',
  styleUrls: ['./add-cover-summary-end.component.scss']
})
export class AddCoverSummaryEndComponent implements OnInit {
  reportType: any;
  agentPercnt: any;
  agentPremium: any;
  agentTax: any;
  permiumRange = 0;
  quoteNo: any;
  endType: any;
  addlCoverInfoList: any[] = [];
  optionalCovers: any[] = [];
  sumInclusiveMandatory: any[] = [];
  customerInfo: any;
  policyNo: any;
  lobCode: any;
  tranSrNo: any;
  transId: any;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  customerTypes: any;
  filteredAgentList: Array<any>;
  agentInfoForm: FormGroup;
  public agentInfo: boolean = false;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    public route: ActivatedRoute,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private spinnerService: LoaderService,
    private session: SessionStorageService) { }

  ngOnInit() {
    /*this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      this.lobCode = params["lobCode"];
      this.policyNo = params["policyNo"];
      this.endType = params["endType"];
      
    });*/
    this.customerTypes = [
      { id: "0", value: "Individual" },
      { id: "1", value: "Company" }
    ]
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    this.endType = this.commonService.getParamValue('endType');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.reportType = this.commonService.getParamValue('reportType');
    this.createAgentForm();

    this.getEndorsementDetails();
    this.getCoverSummary();
    this.getAdditionalCoverInfo();
    this.getOptionalCover();
  }

  createAgentForm() {
    this.agentInfoForm = this.fb.group({
      agentId: '',
      agentName: '',
      agentCommPerc: '0',
      agentCommValue: '0',
      subAgentId: '',
      subAgentName: '',
      subAgentCommPerc: '0',
      subAgentCommValue: '0',
      transId: this.transId,
      tranSrNo: this.tranSrNo,

    });
  }

  getSelectedId(event, name) {
    this.agentInfoForm.get(name).setValue(event.id);
  }
  getAgentList(event) {
    var searchValue = event.query;
    var param = {
      'modeOfPay': 'AGENTS',
      'searchValue': searchValue
    }
    this.agentService.getAgentList(param).subscribe(data => {
      let arr = [];

      for (let i = 0; i < data.custList.length; i++) {
        let id = data.custList[i].key;
        let text = data.custList[i].key + "-" + data.custList[i].value;
        let object = { id: id, text: text };
        arr.push(object);

      }
      this.filteredAgentList = arr;
    });
  }
  getEndorsementDetails() {
    let params = { "trans_Id": this.transId, "trans_Sno": this.tranSrNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {
        this.customerInfo = result.customerInfo;
        if ("0" === result.customerInfo.companyYn) {
          this.customerInfo.companyYn = 'Individual';
        } else if ("1" === result.customerInfo.companyYn) {
          this.customerInfo.companyYn = 'Company';
        }
        if (result.customerInfo.agentName != null || result.customerInfo.agentName != '') {
          this.agentInfo = true;
        } else {
          this.agentInfo = false;
        }

        this.agentInfoForm.patchValue({
          agentId: result.customerInfo.agentId,
          agentName: result.customerInfo.agentName,
          agentCommPerc: result.customerInfo.agentCommPerc,
          agentCommValue: result.customerInfo.agentCommValue,
          subAgentId: result.customerInfo.subAgentId,
          subAgentName: result.customerInfo.subAgentName,
          subAgentCommPerc: result.customerInfo.subAgentCommPerc,
          subAgentCommValue: result.customerInfo.subAgentCommValue
        });

      });
  }



  back() {
    let params = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      lobCode: this.lobCode,
      endType: this.endType,
      policyNo: this.policyNo,
      reportType: this.reportType
    }
    if ('017' === this.endType) {
      this.router.navigate(['vehicleparamendt'], { queryParams: params, skipLocationChange: true });
    } else {
      this.agentService.deleteAddlCover(params).subscribe(resp => {
      })
      this.router.navigate(['addcoverendt'], { queryParams: params, skipLocationChange: true });
    }
  }

  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            this.sumInclusiveMandatory.push(array[i]);
          }
          else {
            this.optionalCovers.push(array[i]);
          }
        }
      });
    this.getAgentNetPremium();
  }

  getOptionalCover() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getOptionalCover(param).subscribe(response => {
      var array = response["optionalList"];
      let j = 0;
      var permiumRange = 0;
      for (var i = 0; i < array.length; i++) {
        this.permiumRange = array[i].COVERAGERATE;
        this.optionalCovers.push(array[i]);
      }
    });
  }


  getAdditionalCoverInfo() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getAddlCoverInfo(param)
      .subscribe(response => {
        var array = response["coverList"];
        for (var i = 0; i < array.length; i++) {
          this.addlCoverInfoList.push(array[i]);
        }
      });
  }
  getAgentNetPremium() {
    this.agentService.getAgentNetPremium({ "transId": this.transId, "tranSrNo": this.tranSrNo }).subscribe(result => {
      this.agentPremium = result.PREMIUM;
      this.agentPercnt = result.AGENT_PERCENT;
      this.agentTax = result.QPI_ACOMM_TAX;
    })
  }


  proceedEndorsement() {
    this.spinnerService.isBusy = true;
    if (this.endType != undefined && '017' === this.endType) {
      let obj = {
        "agentId": this.agentInfoForm.get('agentId').value,
        "agentCommPerc": this.agentInfoForm.get('agentCommPerc').value,
        "agentCommValue": this.agentInfoForm.get('agentCommValue').value,
        "subAgentId": this.agentInfoForm.get('subAgentId').value,
        "subAgentCommPerc": this.agentInfoForm.get('subAgentCommPerc').value,
        "subAgentCommValue": this.agentInfoForm.get('subAgentCommValue').value,
        "transId": this.agentInfoForm.get('transId').value,
        "tranSrNo": this.agentInfoForm.get('tranSrNo').value
      }
      this.agentService.updateAgentCommissionInfo(obj).subscribe(data => {
        this.callRecalcularProcedure();
      });
    } else {
      this.callRecalcularProcedure();
    }


  }

  callRecalcularProcedure() {
    let params = {
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'agentId': this.session.get('agent')
    }
    this.agentService.getRecalculte(params).subscribe(result => {

      this.router.navigate(['addcoverendtconfirm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'policyNo': this.customerInfo.policyNo, 'lobCode': ApplicationConstants.LOB_MOTOR, 'endType': this.endType, 'reportType': 'POL' }, skipLocationChange: true });
      this.spinnerService.isBusy = false;
    }, error => {
      let errorMsglet = error.error.errMessage;
      let obj = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "quoteNo": this.quoteNo,
        "errorMsg": errorMsglet
      };
      this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

    });
  }

  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }
  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }

}
