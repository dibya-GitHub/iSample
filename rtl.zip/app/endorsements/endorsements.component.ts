import { Component, OnInit } from '@angular/core';
import { FormGroup, UntypedFormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { ApplicationConstants } from 'src/shared/application-constants';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-endorsements',
  templateUrl: './endorsements.component.html',
  styleUrls: ['./endorsements.component.scss']
})
export class EndorsementsComponent implements OnInit {

  transId;
  transSNo;
  policyNo;
  lobCode;
  prodCode;
  schCode;
  polEndDate;
  polStartDate;
  renewalEndDt;
  renewalStDt;
  endorsementTranSno;
  endorsementTypeList;
  calculationTypeList;
  EndorsementForm: FormGroup;
  checkDate: boolean;
  disableEffDate: boolean;
  disableFromDate: boolean;
  disableToDate: boolean;
  error: any = { isError: false, errorMessage: '' };
  public myDatePickerOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
  };
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';

  constructor(
    private router: Router,
    public route: ActivatedRoute,
    private agentService: AgentHttpclientService,
    private fb: UntypedFormBuilder,
    private session: SessionStorageService,
    private loaderService: LoaderService
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.transSNo = params["transSNo"];
      this.policyNo = params["policyNo"];
      this.lobCode = params["lobCode"];
      this.polStartDate = params["polStartDate"];
      this.polEndDate = params["polEndDate"];
      this.schCode = params["schCode"];
      this.prodCode = params["prodCode"];
      this.endorsementTranSno = parseInt(this.transSNo) + 1;
    });

    this.checkEndorsedData();
    this.getEndorseDates();
    this.getEndorsementType();
    this.createForm();

    let date = new Date();
    const ms = parseInt(this.polEndDate);
    let enddate;
    if (ms && ms > 3000) {
      enddate = moment(this.polEndDate, 'x').toDate();
    } else {
      enddate = this.polEndDate
    }
    let issueDate = moment(date).format('DD/MM/YYYY HH:mm');
    this.EndorsementForm.patchValue({
      //tranIssueDate: issueDate,
      fromDate: {
        date: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      },
      toDate: {
        date: {
          year: moment(enddate, 'DD/MM/YYYY HH:mm').year(),
          month: moment(enddate, 'DD/MM/YYYY HH:mm').month() + 1,
          day: moment(enddate, 'DD/MM/YYYY HH:mm').date()
        }
      }
    });

  }

  checkEndorsedData() {
    let params = { "trans_Id": this.transId, "endTranSno": this.endorsementTranSno };
    this.agentService.checkEndorsedData(params)
      .subscribe(result => {
        let obj = { "transId": this.transId, "tranSrNo": this.endorsementTranSno, "lobCode": this.lobCode, "policyNo": this.policyNo, "reportType": 'POL', "endType": result.endorsedData, "schCode": this.schCode, "prodCode": this.prodCode };
        if (ApplicationConstants.ENDORSE_TYPE_NON_FINANCIAL == result.endorsedData) {

          this.router.navigate(['nonfinancialendt'], { queryParams: obj, skipLocationChange: true });
        }
        else if (ApplicationConstants.ENDORSE_TYPE_RENEWAL == result.endorsedData && ApplicationConstants.LOB_MOTOR == this.lobCode) {

          this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
        }
        else if (ApplicationConstants.ENDORSE_TYPE_CANCELLATION == result.endorsedData) {
          this.router.navigate(['policycancelendt'], { queryParams: obj, skipLocationChange: true });
        }
        else if (ApplicationConstants.ENDORSE_TYPE_RENEWAL == result.endorsedData && ApplicationConstants.LOB_HOME == this.lobCode) {
          this.router.navigate(['home'], { queryParams: obj, skipLocationChange: true });
        }
        else if (ApplicationConstants.ENDORSE_TYPE_ADD_COVER == result.endorsedData || ApplicationConstants.ENDORSE_TYPE_DEL_COVER == result.endorsedData) {
          this.router.navigate(['addcoverendt'], { queryParams: obj, skipLocationChange: true });
        }
        else if (ApplicationConstants.ENDORSE_TYPE_CHANGE_OWNER == result.endorsement) {
          this.router.navigate(['changeownershipendt'], { queryParams: obj, skipLocationChange: true });
        }
        else if (ApplicationConstants.ENDORSE_TYPE_ADJUST_PREMSI == result.endorsedData) {
          this.router.navigate(['adjustpremiumendt'], { queryParams: obj, skipLocationChange: true });
        }
        else if (ApplicationConstants.ENDORSE_TYPE_EXTENSION == result.endorsedData) {
          this.router.navigate(['extensionendt'], { queryParams: obj, skipLocationChange: true });
        } else if (ApplicationConstants.ENDORSE_TYPE_VEH_PARAMS == result.endorsedData) {
          this.router.navigate(['vehicleparamendt'], { queryParams: obj, skipLocationChange: true });
        } else if (ApplicationConstants.ENDORSE_TYPE_FLEET_CERT == result.endorsedData) {
          this.router.navigate(['certificateendt'], { queryParams: obj, skipLocationChange: true });
        }
      }, error => {
        let errorMsg = error.error.errMessage;
        let obj = { "transId": this.transId, "transSNo": this.transSNo, "policyNo": this.policyNo, "lobCode": this.lobCode, "polStartDate": this.polStartDate, "polEndDate": this.polEndDate, "schCode": this.schCode, "prodCode": this.prodCode };
        this.router.navigate(['endorsements'], { queryParams: obj, skipLocationChange: true });

      });
  }


  getEndorsementType() {
    let params = { "userRole": this.session.get("USER_ROLE_ID"), "lobCode": this.lobCode };
    this.agentService.getEndorsementType(params)
      .subscribe(result => {
        this.endorsementTypeList = result.endorsementTypeList;
      });
  }
  getEndorseDates() {
    let params = { "polStDate": this.polStartDate, "polEnDate": this.polEndDate, "lobCode": this.lobCode };
    this.agentService.getEndorseDates(params)
      .subscribe(result => {
        this.renewalStDt = result.values.key;
        this.renewalEndDt = result.values.value;
      });
  }
  getFormattedDate(date) {
    return date.day + "/" + date.month + "/" + date.year;
  }

  getCallculationType(endType) {
    let params = { "endorseType": endType };
    if (endType == '001' || endType == '005' || endType == '009' || endType == '017' || endType == '008') {
      this.disableEffDate = true;
      this.disableToDate = true;
      this.disableFromDate = false;
      let tranIssueDate = new Date();
      let fromDate = moment(tranIssueDate).format('DD/MM/YYYY HH:mm');
      let dateTo = this.polEndDate;
      this.EndorsementForm.patchValue({
        tranIssueDate: moment(fromDate, 'DD/MM/YYYY HH:mm').toISOString(),
        fromDate: moment(fromDate, 'DD/MM/YYYY HH:mm').toISOString(),
        toDate: moment(dateTo, 'DD/MM/YYYY HH:mm').toISOString(),
      });
    }
    else if (endType == '002') {
      this.disableEffDate = true;
      this.disableFromDate = true;
      this.disableToDate = true;
      let fromDate = this.polEndDate;
      let renStDate = this.renewalStDt;
      let renewalEndDt = this.renewalEndDt;
      let tranIssueDate = new Date();
      let transDate = moment(tranIssueDate).format('DD/MM/YYYY HH:mm');
      this.EndorsementForm.patchValue({
        tranIssueDate: moment(transDate, 'DD/MM/YYYY HH:mm').toISOString(),
        fromDate: moment(this.renewalStDt, 'DD/MM/YYYY HH:mm').toISOString(),
        toDate: moment(this.renewalEndDt, 'DD/MM/YYYY HH:mm').toISOString(),
      });

    }

    else if (endType == '004') {
      this.disableEffDate = true;
      this.disableFromDate = false;
      this.disableToDate = false;
    }
    if (endType == '003') {
      this.disableEffDate = true;
      this.disableFromDate = true;
      this.disableToDate = false;
      let toDate = new Date(parseInt(this.polEndDate));
      let dateTo = new Date(new Date(parseInt(this.polEndDate)).getTime() + (1 * 24 * 60 * 60 * 1000));
      this.EndorsementForm.patchValue({
        fromDate: {
          date: {
            year: dateTo.getFullYear(),
            month: dateTo.getMonth() + 1,
            day: dateTo.getDate()
          }
        },
        toDate: ''
      });

    }

    this.agentService.getCallculationType(params)
      .subscribe(result => {
        this.calculationTypeList = result.calculationTypeList;
      });
  }

  callEndorsePackage(data) {
    if (data.endType == "") {
      this.error = { isError: true, errorMessage: 'please select endorsement type' };
    } else if (data.calType == "") {
      this.error = { isError: true, errorMessage: 'please select calculation type' };
    } else if (data.fromDate == "" || data.fromDate == null) {
      this.error = { isError: true, errorMessage: 'Invalid Effective From Date' };
    } else if (data.toDate == "" || data.toDate == null) {
      this.error = { isError: true, errorMessage: 'Invalid Effective To Date' };
    } else {
      let pFromDate1 = data.fromDate;
      let convertedFromDate1 = new Date(
        pFromDate1.year,
        pFromDate1.month - 1,
        pFromDate1.day);
      let pEndDate1 = data.toDate;
      let convertedToDate1 = new Date(
        pEndDate1.year,
        pEndDate1.month - 1,
        pEndDate1.day);
      let convertedDate2 = new Date(
        moment(this.polStartDate, 'DD/MM/YYYY').year(),
        moment(this.polStartDate, 'DD/MM/YYYY').month(),
        moment(this.polStartDate, 'DD/MM/YYYY').date()
      );



      /* if (data.endType == "003" && convertedFromDate1 > convertedToDate1) {
         this.error = { isError: true, errorMessage: 'Endorsement To date must be equal to or greater than from date' };
       }
       else if (data.endType == '001' && convertedDate2 > convertedFromDate1) {
         this.error = { isError: true, errorMessage: 'Effective from date must be greater than or equal to Policy Start date' };
       }*/
      //  else {
      this.loaderService.isBusy = true;
      let endFromDate = moment(data.fromDate).format('DD/MM/YYYY');
      let endToDate = moment(data.toDate).format('DD/MM/YYYY');
      let endTranIssueDate = moment(new Date()).format('DD/MM/YYYY');
      let params = {
        "trans_Id": this.transId, "trans_Sno": this.transSNo, "endorseType": data.endType, "endFromDate": endFromDate, "lobCode": this.lobCode,
        "endToDate": endToDate, "calType": data.calType, "userName": this.session.get("username"), "userType": this.session.get("usertype"), "endTranSno": this.endorsementTranSno, "endTranIssueDate": endTranIssueDate
      };
      if (ApplicationConstants.ENDORSE_TYPE_RENEWAL == data.endType) {
        let obj = {
          "transId": this.transId,
          "tranSrNo": this.transSNo
        };
        this.agentService.checkPolicyForRenewal(obj).
          subscribe(result => {
            this.agentService.callEndorsePackage(params)
              .subscribe(result => {
                if (result.errMessage != 'success') {
                  this.error = { isError: true, errorMessage: result.errMessage };
                } else {
                  const obj = { "transId": this.transId, "tranSrNo": this.endorsementTranSno, "endType": data.endType, policyNo: this.policyNo };
                  //  this.router.navigate(['motor'], { queryParams: { "transId": this.transId, "tranSrNo": this.endorsementTranSno, "endType": data.endType }, skipLocationChange: true });
                  if (ApplicationConstants.LOB_MOTOR == this.lobCode) {
                    this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
                    this.loaderService.isBusy = false;

                  }
                  else if (ApplicationConstants.LOB_HOME == this.lobCode) {
                    this.router.navigate(['home'], { queryParams: obj, skipLocationChange: true });
                    this.loaderService.isBusy = false;

                  }
                }
              });
            this.loaderService.isBusy = false;
          }, error => {
            let param = {
              "transId": this.transId,
              "quoteNo": this.policyNo,
              "traSrNo": this.transSNo,
              "errMessage": " You are not authorized to renew this policy"

            };
            this.agentService.insertErrorMsg(param).subscribe(response => {

              this.router.navigate(['refferal'], { queryParams: param, skipLocationChange: true });
              this.loaderService.isBusy = false;
            });
          });

      } else {
        this.loaderService.isBusy = true;
        let endFromDate = moment(data.fromDate).format('DD/MM/YYYY');
        let endToDate = moment(data.toDate).format('DD/MM/YYYY');
        let paramsDates = {
          "polEndStartDate": this.polStartDate, "polEndEnDate": this.polEndDate, "lobCode": this.lobCode, "endorseType": data.endType, "endFromDate": endFromDate,
          "endToDate": endToDate, "userRole": this.session.get("USER_ROLE_ID")
        };
        this.agentService.validateEndorseDates(paramsDates)
          .subscribe(result => {
            if (result.errMessage != 'success') {
              this.error = { isError: true, errorMessage: result.errMessage };
            } else {
              this.agentService.callEndorsePackage(params)
                .subscribe(result => {
                  if (result.errMessage != 'success') {
                    this.error = { isError: true, errorMessage: result.errMessage };
                  } else {
                    let obj = { "transId": this.transId, "tranSrNo": this.endorsementTranSno, "lobCode": this.lobCode, "policyNo": this.policyNo, "reportType": 'POL', "endType": result.endorsement, "schCode": this.schCode, "prodCode": this.prodCode };
                    if (ApplicationConstants.ENDORSE_TYPE_NON_FINANCIAL == result.endorsement) {
                      this.router.navigate(['nonfinancialendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (ApplicationConstants.ENDORSE_TYPE_CHANGE_OWNER == result.endorsement) {
                      this.router.navigate(['changeownershipendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (ApplicationConstants.ENDORSE_TYPE_CANCELLATION == result.endorsement) {
                      this.router.navigate(['policycancelendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (ApplicationConstants.ENDORSE_TYPE_ADD_COVER == result.endorsement || ApplicationConstants.ENDORSE_TYPE_DEL_COVER == result.endorsement) {
                      this.router.navigate(['addcoverendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (ApplicationConstants.ENDORSE_TYPE_ADJUST_PREMSI == result.endorsement) {
                      this.router.navigate(['adjustpremiumendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (ApplicationConstants.ENDORSE_TYPE_EXTENSION == result.endorsement) {
                      this.router.navigate(['extensionendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (ApplicationConstants.ENDORSE_TYPE_VEH_PARAMS == result.endorsement) {
                      this.router.navigate(['vehicleparamendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (ApplicationConstants.ENDORSE_TYPE_FLEET_CERT == result.endorsedData) {
                      this.router.navigate(['certificateendt'], { queryParams: obj, skipLocationChange: true });
                    } else if (result.endorsedData == null || result.endorsedData == '') {
                      let obj = {
                        "transId": this.transId,
                        "tranSrNo": this.transSNo,
                        "quoteNo": this.policyNo,
                        "errorMsg": "Endorsement Not Available"
                      };
                      this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
                      this.loaderService.isBusy = false;
                    }
                  }
                }, error => {
                  let errorMsg = error.error.errMessage;
                  let obj = {
                    "transId": this.transId,
                    "tranSrNo": this.transSNo,
                    "quoteNo": this.policyNo,
                    "errorMsg": errorMsg
                  };
                  this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
                  this.loaderService.isBusy = false;
                });
            }
          });

      }
    }

  }

  createForm() {
    this.EndorsementForm = this.fb.group({
      endType: ['', [Validators.required]],
      calType: ['', [Validators.required]],
      tranIssueDate: ['', [Validators.required]],
      fromDate: ['', [Validators.required]],
      toDate: [null]
    });
  }

  cancleEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  convertDate(jsonDate) {
    return jsonDate.date.day + "/" + jsonDate.date.month + "/" + jsonDate.date.year;
  }
}
