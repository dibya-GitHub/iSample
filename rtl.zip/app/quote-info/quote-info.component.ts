import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../services/agent-httpclient.service';
@Component({
  selector: 'app-quote-info',
  templateUrl: './quote-info.component.html',
  styleUrls: ['./quote-info.component.scss']
})
export class QuoteInfoComponent implements OnInit {
  transId;
  tranSrNo;
  lobCode;
  polStartDate;
  sumInsured;
  polEndDate;
  polEndFmDate;
  polEndToDate;
  civilId;
  quoteNo;
  insuredName;
  quoteIssueDate;
  polIssueDate;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  companyYn: any;
  constructor(
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
    private session: SessionStorageService,
  ) { }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.getQuoteInformation();
    this.companyYn = this.session.get('companyYn');
  }

  appendZero(temp: any) {
    if (temp < 10) {
      return '0' + temp;
    }
    return temp;
  }

  getQuoteInformation() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      mapId: 'AGENT_HOME_POL_SCR_1'
    }
    let date = new Date();
    this.agentService.getQuoteInformation(postData).subscribe(quoteInfo => {
      this.civilId = quoteInfo.civilId;
      this.quoteNo = quoteInfo.quoteNo;
      this.insuredName = quoteInfo.insName;
      //this.polStartDate = quoteInfo.polStartDate;
      this.polStartDate = moment(quoteInfo.polStartDate, 'DD/MM/YYYY HH:mm').toISOString(),
        this.polEndDate = moment(quoteInfo.polEndDate, 'DD/MM/YYYY HH:mm').toISOString(),
        this.polEndFmDate = moment(quoteInfo.polEndFmDate, 'DD/MM/YYYY HH:mm').toISOString(),
        this.polEndToDate = moment(quoteInfo.polEndToDate, 'DD/MM/YYYY HH:mm').toISOString(),
        //  this.polEndDate = quoteInfo.polEndDate;
        this.quoteIssueDate = quoteInfo.quotIssDate;
      this.polIssueDate = new Date();
      this.session.set('companyYn', quoteInfo.companyYn);
      this.session.set('emailId', quoteInfo.emailId);
      this.companyYn = this.session.get('companyYn');
      this.sumInsured = quoteInfo.sumInsured;
    }, error => {

    });
  }

  getFormattedDate(date) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    return this.appendZero(day) + "/" + this.appendZero(month) + "/" + this.appendZero(year);
  }

}
