import { AgRendererComponent } from "@ag-grid-community/angular";
import { Component } from "@angular/core";

@Component({
    selector: 'app-ag-grid-link',
    template: `<a (click)="onClick()" style="cursor: pointer;">{{value}}</a>`
})
export class AgGridLinkComponent implements AgRendererComponent {

    data: any;
    colDef: any;
    params: any;
    value: any;

    constructor() { }

    refresh(params: any): boolean {
        return false;
    }
    agInit(params: any): void {
        this.value = params.value;
        this.data = params.data;
        this.colDef = params.colDef;
        this.params = params.colDef.cellRendererParams;
    }
    onClick() {
        if (this.params && this.params.click) {
            this.params.click(this.data);
        }
    }
}