import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeInVehParamEndorsementComponent } from './change-in-veh-param-endorsement.component';

describe('ChangeInVehParamEndorsementComponent', () => {
  let component: ChangeInVehParamEndorsementComponent;
  let fixture: ComponentFixture<ChangeInVehParamEndorsementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeInVehParamEndorsementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeInVehParamEndorsementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
