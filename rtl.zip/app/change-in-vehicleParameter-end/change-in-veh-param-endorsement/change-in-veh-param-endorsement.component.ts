import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { ApplicationConstants } from 'src/shared/application-constants';
import { AgentUserService } from "../../../shared/services/agent-user.service";
import { AgentHttpclientService } from "../../services/agent-httpclient.service";
import { LoaderService } from 'src/shared/loader-service/loader.service';

@Component({
  selector: 'app-change-in-veh-param-endorsement',
  templateUrl: './change-in-veh-param-endorsement.component.html',
  styleUrls: ['./change-in-veh-param-endorsement.component.scss']
})
export class ChangeInVehParamEndorsementComponent implements OnInit {
  editFlag: boolean;
  enableCompany: boolean;

  yearArray: any = [];
  currentYear: any;
  customerInfo: any;
  vehicleInfo: any;
  transId: string;
  tranSrNo: number;
  lobCode: string;
  policyNo: string;
  quoteNo: string;
  endorseType: string;
  civilIdErrorMessage: string;
  mobileNoerrorMessage: string;
  nationalityList: Array<any>;
  customerInfoForm: UntypedFormGroup;
  vehicleInfoForm: UntypedFormGroup;
  public sumInclusiveMandatory: any[] = [];
  optionalCovers: any[] = [];
  public discounts: any[] = [];
  public deductables: any[] = [];
  public loading: any[] = [];
  public fees: any[] = [];
  public taxes: any[] = [];
  public load: any[] = [];
  agentCommissionPercent;
  agentCommisionValue;
  agentCommissionTax;
  netPremium;
  modelList: Array<any>;
  makeList: Array<any>;
  bodyTypeList: Array<any>;
  vehicleTypeList: Array<any>;
  cylinderList: Array<any>;
  regnLocList: Array<any>;
  geoAreaList: Array<any>;
  colorList: Array<any>;
  vehUsageList: Array<any>;
  groupCode: string = this.session.get("groupCode");
  userFilter: any = this.session.get("userFilter");
  premium: any;

  customerTypes = [
    { id: "0", value: "Individual" },
    { id: "1", value: "Company" }
  ]
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private session: SessionStorageService,
    private agentService: AgentHttpclientService,
    private loaderService: LoaderService,
    private messageService: MessageService,
    private commonService: AgentUserService) {
  }

  createForm() {
    this.customerInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      transRemark: ['', Validators.required],
      userId: this.session.get("username"),
      custCode: this.session.get("agent"),
      portal: this.session.get("portaltype"),
      interest: '',
      vatRefNo: '',
      insName: ['', Validators.required],
      insNameAr: '',
      cardRefNo: '',
      mapId: 'VEH_PARAM_CUS_INFO_UDATE',
      companyYn: ''

    });
    this.vehicleInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      userId: this.session.get("username"),
      mapId: 'UPDATE_VEH_PARAM_ENDORSEMENT',
      chassisNo: ['', Validators.required],
      engineNo: ['', Validators.required],
      regnNo: '',
      licenceNo: '',
      trafficLoc: ['', Validators.required],
      tcfNo: ['', Validators.required],
      vehMake: ['', Validators.required],
      vehModel: ['', Validators.required],
      manfYear: ['', Validators.required],
      firstRegYear: ['', Validators.required],
      vehBodyType: ['', Validators.required],
      vehUsage: ['', Validators.required],
      vehColor: '',
      geoArea: ['', Validators.required],
      seatingCty: ['', Validators.required],
      psgrLiabSeatCty: ['', Validators.required],
      tplLimit: ['', Validators.required],
      regnLoc: ['', Validators.required],
      driverAge: ['', Validators.required],
      nationality: ['', Validators.required],
      vehCylinders: ['', Validators.required]

    });
  }
  ngOnInit() {
    this.currentYear = new Date().getFullYear();
    let year = new Date().getFullYear();
    for (let i = year; i > (year - 5); i--) {
      this.yearArray.push(i);
    }
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.endorseType = this.commonService.getParamValue('endType');

    this.civilIdErrorMessage = this.commonService.civilIdErrorMessage();
    this.mobileNoerrorMessage = this.commonService.mobileNoErrorMessage();
    this.createForm();
    this.getNationalityList();
    this.dropDownList();
    this.getCoverSummary();
    this.getDiscDedLoadFeesSumm();
    this.getPremiumSummary();
    //getting endrosement details
    let params = { "trans_Id": this.transId, "trans_Sno": this.tranSrNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {
        this.customerInfo = result.customerInfo;
        this.vehicleInfo = result.vehicleInfo;
        if (this.customerInfo.companyYn == null || this.customerInfo.civilId == null) {
          this.editFlag = false;
        }
        else {
          this.editFlag = true;
          if (this.customerInfo.companyYn == '0') {
            this.customerInfo.companyType = 'Individual';
          } else {
            this.customerInfo.companyType = 'Company';
          }
        }


        let v_model = { "type": "MOT_VEH_MOD", "refCode": this.vehicleInfo.vehMake };
        this.agentService.getVehicleModel(v_model)
          .subscribe(result => {
            let arr = [];
            for (let i = 0; i < result.appCodesArray.length; i++) {
              let id = result.appCodesArray[i].code;
              let text = result.appCodesArray[i].desc;
              let object = { id: id, text: text };
              arr.push(object);
            }
            this.modelList = arr;
          });

        let v_usage = { "vehType": this.vehicleInfo.vehBodyType };
        this.agentService.getUsageList(v_usage)
          .subscribe((result: any) => {

            let arr2 = [];
            for (let i = 0; i < result.usageArray.length; i++) {
              let id = result.usageArray[i].USAGECODE;
              let text = result.usageArray[i].USAGEDESC;
              let object = { id: id, text: text };
              arr2.push(object);

            }
            this.vehUsageList = arr2;
          });

        this.customerInfoForm.patchValue({

          vatRefNo: this.customerInfo.taxRefNo,
          insName: this.customerInfo.insName,
          insNameAr: this.customerInfo.insNameAr,
          companyYn: this.customerInfo.companyYn,
          nationality: this.customerInfo.nationality,
          transRemark: this.customerInfo.transRemark,
          interest: this.customerInfo.interest,
          cardRefNo: this.customerInfo.authCode
        });

        this.vehicleInfoForm.patchValue({
          vehMake: this.vehicleInfo.vehMake,
          vehModel: this.vehicleInfo.vehModel,
          vehBodyType: this.vehicleInfo.vehBodyType,
          vehUsage: this.vehicleInfo.vehUsage,
          vehColor: this.vehicleInfo.vehColor,
          manfYear: this.vehicleInfo.manfYear,
          vehCylinders: this.vehicleInfo.vehCylinders,
          seatingCty: this.vehicleInfo.seatingCty,
          psgrLiabSeatCty: this.vehicleInfo.psgrLiabSeatCty,
          chassisNo: this.vehicleInfo.chassisNo,
          engineNo: this.vehicleInfo.engineNo,
          tcfNo: this.vehicleInfo.tcfNo,
          trafficLoc: this.vehicleInfo.trafficLoc,
          driverAge: this.vehicleInfo.driverAge,
          tplLimit: this.vehicleInfo.tplLimit,
          regnLoc: this.vehicleInfo.regnLoc,
          firstRegYear: this.vehicleInfo.firstRegYear
        });
      });

  }

  getModelList(event) {
    this.loaderService.isBusy = true;
    let make_var = event.id;
    let v_model = { "type": "MOT_VEH_MOD", "refCode": make_var };
    this.agentService.getVehicleModel(v_model)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.modelList = arr;

        this.loaderService.isBusy = false;
      });
  }
  getNationalityList() {
    this.agentService.getNationalityList({ "type": "NATIONALITY" }).subscribe(resp => {
      this.nationalityList = resp.appCodesArray;
    })
  }

  dropDownList() {
    let v_make = {
      "makeFliterYn": this.userFilter.CUST_MAKE_FILTER_YN,
      "groupCode": this.userFilter.CUST_GROUP_CODE
    };
    this.agentService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.makeList = arr;
        //vehicleType
        let v_type = { "userId": "online" };
        this.agentService.getVehicleType(v_type)
          .subscribe(result => {
            let arr = [];
            this.bodyTypeList = result.typeArray;
            for (let i = 0; i < result.typeArray.length; i++) {
              let id = result.typeArray[i].VEHTYPECODE;
              let text = result.typeArray[i].VEHTYPEDESC;
              let object = { id: id, text: text };
              arr.push(object);

            }
            this.vehicleTypeList = arr;

            let v_cylinder = { "type": "MOT_VEH_NOC" };
            this.agentService.getCylinderList(v_cylinder)
              .subscribe(result => {
                let arr = [];
                for (let i = 0; i < result.appCodesArray.length; i++) {
                  let id = result.appCodesArray[i].code;
                  let text = result.appCodesArray[i].desc;
                  let object = { id: id, text: text };
                  arr.push(object);
                }
                this.cylinderList = arr;
                let v_geoArea = { "type": "AREA" };
                this.agentService.getGeoList(v_geoArea)
                  .subscribe(result => {
                    let arr = [];
                    for (let i = 0; i < result.appCodesArray.length; i++) {
                      let id = result.appCodesArray[i].code;
                      let text = result.appCodesArray[i].desc;
                      let object = { id: id, text: text };
                      arr.push(object);

                    }
                    this.geoAreaList = arr;
                    let v_regLoc = { "type": "REGN_LOC" };
                    this.agentService.getGeoList(v_regLoc)
                      .subscribe(result => {
                        let arr = [];
                        for (let i = 0; i < result.appCodesArray.length; i++) {
                          let id = result.appCodesArray[i].code;
                          let text = result.appCodesArray[i].desc;
                          let object = { id: id, text: text };
                          arr.push(object);

                        }
                        this.regnLocList = arr;
                        let v_color = { "type": "MOT_VEH_COL" };
                        this.agentService.getGeoList(v_color)
                          .subscribe(result => {
                            this.colorList = result.appCodesArray;
                          });
                      });
                  });
              });
          });
      });
  }


  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            this.sumInclusiveMandatory.push(array[i]);
          }
          else {
            this.optionalCovers.push(array[i]);
          }
        }
      });
  }

  getDiscDedLoadFeesSumm() {
    let taxesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "TAX"
    };
    this.agentService.getDiscDedLoadFeesSumm(taxesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.taxes.push(data[k]);
        }
      }

    }, error => {


    });

    let dedPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DED"
    };
    this.agentService.getDiscDedLoadFeesSumm(dedPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.deductables.push(data[k]);
        }
      }
    }, error => {


    });

    let discountPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DISC"
    };
    this.agentService.getDiscDedLoadFeesSumm(discountPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.discounts.push(data[k]);
        }
      }
    }, error => {


    });

    let feesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "FEES"
    };
    this.agentService.getDiscDedLoadFeesSumm(feesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.fees.push(data[k]);
        }
      }
    }, error => {


    });

    let loadPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "LOAD"
    };
    this.agentService.getDiscDedLoadFeesSumm(loadPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.load.push(data[k]);
        }
      }
    }, error => {


    });
  }

  proceedEndorsement() {
    if (this.customerInfoForm.valid) {
      this.loaderService.isBusy = true;
      this.agentService.updateInsuredInfo(this.customerInfoForm.value)
        .subscribe(result => {
          if (this.vehicleInfoForm.valid) {
            this.agentService.updateVehicleInfo(this.vehicleInfoForm.value)
              .subscribe(result => {
                let obj = {
                  transId: this.transId,
                  tranSrNo: this.tranSrNo,
                  userId: this.session.get("agent"),
                  endType: this.endorseType
                }
                this.agentService.endtProceedtoBuy(obj)
                  .subscribe(result => {
                    this.router.navigate(['addcoverendtsummary'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'policyNo': this.customerInfo.policyNo, 'lobCode': ApplicationConstants.LOB_MOTOR, 'endType': this.endorseType, 'reportType': 'POL' }, skipLocationChange: true });

                  });
                //this.router.navigate(['add-cover-summary'],{queryParams:{'transId':this.transId,'tranSrNo':this.transSNo,'policyNo':this.customerInfo.policyNo,'lobCode':ApplicationConstants.LOB_MOTOR,'endType': this.endorseType}});

              });
          } else {
            this.validateAllFormFields(this.vehicleInfoForm);
          }
        });

    } else {
      this.validateAllFormFields(this.customerInfoForm);
    }
  }


  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }
  getPremiumSummary() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.agentService.getNetPremium(postData).subscribe(response => {
      this.agentCommisionValue = response.AGENT_FC;
      this.agentCommissionPercent = response.AGENT_PERCENT;
      this.agentCommissionTax = response.QPI_ACOMM_TAX;
      this.premium = response.PREMIUM;
    }, error => {

    });
  }


  updateCompany(customerType) {
    if (customerType == '1') {
      this.enableCompany = true;
    }
    else {
      this.enableCompany = false;
    }
  }
}
