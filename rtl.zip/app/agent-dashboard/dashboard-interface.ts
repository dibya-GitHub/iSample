import { Business } from '../../shared/classes/business';
import { Product } from '../../shared/classes/product';
import { Quote } from '../../shared/classes/quote';


export interface Dashboardinterface {
    respCode?: string;
    errMessage?: string;
    clmRefNo?: string;
    list?: Array<Product>;
    quotesArray?: Array<Quote>;
    activePolicyArray?: Array<Quote>;
    businesslist?: Array<Business>;
    userList?: Array<any>;
    schemeList?: Array<any>;
    resultUrl?: string;
    documentInfoList?: Array<any>;
    fileUrl?: Array<any>;
    activeLobList?: Array<any>;
    applLobDetails?: Array<any>;
    claimList?: Array<any>;
    fleetPolicyList?: Array<any>;
}
