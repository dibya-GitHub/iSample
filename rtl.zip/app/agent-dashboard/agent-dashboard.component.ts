import { DatePipe } from '@angular/common';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormGroup, UntypedFormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { MessageService } from 'primeng/api';
import { ApplicationConstants } from 'src/shared/application-constants';
import { Search } from '../../shared/classes/search';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { HomeInsurancePlanService } from '../home/services/home-insurance-plan.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

declare function calltable(): any;
declare function getdaterange(): any;
@Component({
  selector: 'app-agent-dashboard',
  templateUrl: './agent-dashboard.component.html',
  styleUrls: ['./agent-dashboard.component.scss']
})

export class AgentDashboardComponent implements OnInit {
  pieChartLabels: string[];
  pieChartData: number[];
  pieChartLabels1: string[];
  pieChartData1: number[];
  quotesearchvalue;
  quotesearchname;
  policysearchname;
  policysearchvalue;
  diaplaysearch = 'Your Requests';
  QuoteSearchForm: FormGroup;
  PolicySearchForm: FormGroup;
  UserForm: FormGroup;
  summary: false;
  excel: false;
  products: any;
  activeLobList: any;
  applLobList: any;
  quotes: any = [];
  policy: any;
  business: any;
  users: any;
  schemes: any;
  viewdocuments: any;
  loginUserName;
  trans_Id;
  trans_Sno;
  policy_No;
  lob_Code;
  polStartDate
  polEndDate
  userId;
  userName;
  schCode;
  prodCode;
  buttonEnable = false;
  policyReqList: any;
  message;
  agent;
  messageForm: FormGroup;
  searchMessage;
  commissions: number;
  premium: number;
  qutations;
  policies;
  product;
  businessList;
  quoteCount: number;
  policyCount: number;
  policyList;
  quoteList;
  policyHistoryList;
  quoteBusinessInfo;
  policyBusinessInfo;
  currentDate: any;
  quotevalue: any;
  policyvalue: any;
  historyFlag: any;
  claimAccess: any;
  creditAccess: any;
  selectedPolicy: any;
  showPolicyStatus: any;
  dashboardUrl: any;
  roleId: any;
  showDiv = false;
  ativePolicyList: any;
  fleetVehicleList: any;
  showFleetPolicyStatus: any;
  selectedFleetPolicy: any;
  selectedVehicle: any;
  riskSrNo: any;
  tranType: any;
  viewQuote: boolean = false;
  showMarine = false;
  public isOldVessel: boolean = true;
  oldTrimId: any;
  enableCertificateBtn = false;
  @ViewChild('trigger') tr: ElementRef;
  queryString
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';

  public myDatePickerOptions: IAngularMyDpOptions = {
    dateFormat: 'DD/MM/YYYYY',
  };
  quotesearchList = [
    new Search('QPI_QUOT_NO', 'Quote No'),
    new Search('QPI_POL_REF_NO', 'Ref No'),
    new Search('QPI_MOBILE_NO', 'Mobile No'),
    new Search('QPI_CIVIL_ID', 'Civil ID'),
    new Search('QRI_CHASSIS_NO', 'Chassis No'),
    new Search('QRI_ENGINE_NO', 'Engine No'),
    new Search('QRI_REG_NO', 'Plate No')
  ];

  quotecertificateList = [
    new Search('QPI_QUOT_NO', 'Draft Certificate No'),
  ];

  quoteMarinesearchList = [
    new Search('TPI_INS_NAME', 'Assured Name'),
    new Search('TRI_LC_DATE_NO', 'L/c No'),
    new Search('TPI_QUOT_NO', 'Quote No'),
    new Search('TPI_MOBILE_NO', 'Interest'),
    new Search('TRI_BILL_LAD_NO', 'PO Number'),
    new Search('TRI_INV_NO', 'Invoice Number '),
    new Search('TPI_POLICY_NO', 'Certificate No')
  ];
  policysearchList = [
    new Search('TPI_POLICY_NO', 'Policy No'),
    new Search('TPI_POL_REF_NO', 'Ref No'),
    new Search('TPI_QUOT_NO', 'Quote No'),
    new Search('TPI_MOBILE_NO', 'Mobile No'),
    new Search('TRI_REG_NO', 'Plate No'),
    new Search('TPI_CIVIL_ID', 'Civil ID'),
    new Search('TRI_CHASSIS_NO', 'Chassis No'),
    new Search('TRI_ENGINE_NO', 'Engine No'),
    new Search('TPI_POLICY_NO', 'Certificate No')
  ];
  certificatesearchList = [
    new Search('TPI_POLICY_NO', 'Certificate No'),
    new Search('TPI_QUOT_NO', 'Quote No'),
    new Search('TRI_INV_NO', 'Invoice number'),
    new Search('TRI_BILL_LAD_NO', 'Purchase Order number'),
    new Search('TRI_LC_DATE_NO', 'LC No')
  ];
  config: any;
  onlyMarine: boolean;
  constructor(
    private session: SessionStorageService,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private fb: UntypedFormBuilder,
    private router: Router,
    private homeInsurancePlanService: HomeInsurancePlanService,
    private messageService: MessageService,
    private loaderService: LoaderService,
    private route: ActivatedRoute,
    private datepipe: DatePipe) {
    this.config = {
      currentPage: 1,
      itemsPerPage: 4
    };
    // this.route.queryParamMap.map(params => params.get('page'))
    //   .subscribe(page => this.config.currentPage = page);
    this.loginUserName = this.session.get("loginUserName");
  }


  ngOnInit() {

    this.loaderService.isBusy = true;
    this.historyFlag = this.session.get("historyFlag");
    this.claimAccess = this.session.get("claimAccess");
    this.creditAccess = this.session.get("printCreditAccess");
    this.dashboardUrl = this.session.get("dashboardUrl");
    this.roleId = this.session.get("USER_ROLE_ID");
    // getdaterange();
    this.createForm();
    this.getUserList();
    // this.getSchemeList();
    this.getUserMessage();

    // let intObj = setInterval(() => {
    //  calltable(); 
    // },2000)

    if (this.dashboardUrl == "FleetCustomer") {
      this.getFleetData();
    } else {
      this.getBusiness();
      this.getPolicyBusiness();
      this.getPolicyRequest();

      let params = { "empUserId": this.session.get("agent"), "userId": this.session.get("username"), "empDivnCode": this.session.get("divisionCode"), empDeptCode: this.session.get("departmentCode") };
      this.onlyMarine = false;
      this.agentService.getProducts(params)
        .subscribe(result => {
          this.activeLobList = result.activeLobList;
          // this.activeLobList = result.applLobDetails;
          this.products = result.list;
          if (this.activeLobList != null && this.activeLobList[0].info1 === "03" && this.roleId != "A_HULL_MGR") {
            this.onlyMarine = true;
            this.UserForm.controls['userLob'].setValue(this.activeLobList[0].key);
            this.UserForm.controls['reportType'].setValue("2");
            this.UserForm.controls['userLob'].setValue("03");
          } else {
            if (this.products != null && this.products.length == 1) {
              this.UserForm.controls['userLob'].setValue(this.products[0].key);
              this.UserForm.controls['reportType'].setValue("1");
            }
          }


        });
    }

    let date = new Date();
    this.currentDate = new Date();
    this.UserForm.patchValue({
      daterange: {
        beginDate: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        },
        endDate: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      }
    });
    this.loaderService.isBusy = false;
    this.commonService.events$.forEach(event => this.getFleetData());

  }

  getFleetData() {
    this.loaderService.isBusy = true;
    let params = { "agentId": this.session.get("agent") };
    this.queryString = '';
    this.agentService.getFleetPolicies(params)
      .subscribe(result => {
        this.ativePolicyList = result.fleetPolicyList;
        setTimeout(() => {
          this.loaderService.isBusy = false;
        }, 2000);
      });
  }

  setFleetpolicyDetails(quote) {
    this.trans_Id = quote.transId;
    this.trans_Sno = quote.tranSrNo;
    this.policy_No = quote.policyNo;
    this.schCode = quote.schCode;
    this.prodCode = quote.prodCode;
    this.tranType = quote.transType;
    this.showFleetPolicyStatus = true;
    this.selectedPolicy = quote;
  }
  setvehicleDetails(vehicle) {
    this.selectedVehicle = vehicle;
    this.riskSrNo = vehicle.tranSrNo;

  }

  getVehicleList() {
    this.loaderService.isBusy = true;
    let params = { "transId": this.trans_Id };
    this.agentService.getFleetvehicleList(params)
      .subscribe(result => {
        this.fleetVehicleList = result.fleetVehicleList;
        this.loaderService.isBusy = false;

      });
  }


  createForm() {
    this.loaderService.isBusy = false;
    this.QuoteSearchForm = this.fb.group({
      quotesearchname: '',
      quotesearchvalue: '',

    });
    this.PolicySearchForm = this.fb.group({
      policysearchname: '',
      policysearchvalue: ''

    });

    this.UserForm = this.fb.group({
      reportType: '',
      userId: this.session.get("username"),
      userLob: '01',
      userScheme: 'X',
      startdate: '',
      enddate: '',
      userSummary: '',
      userExcel: '',
      daterange: ''
    });
    this.messageForm = this.fb.group({
      message: this.message
    });

  }

  quoteSearch(quotesearchDiv, reqPolicyDiv) {
    this.loaderService.isBusy = true;
    quotesearchDiv.style.display = "block";
    reqPolicyDiv.style.display = "none";
    var data = this.QuoteSearchForm.value;
    if (data.quotesearchname == "") {
      window.scrollTo(0, 0);
      this.messageService.add({ severity: 'warn', summary: 'Warning Message', detail: 'Please Search By Name' });
    } else if (data.quotesearchvalue == "") {
      window.scrollTo(0, 0);
      this.messageService.add({ severity: 'warn', summary: 'Warning Message', detail: 'Please Search By Number' });
    } else {
      let params = { "searchBy": data.quotesearchname, "value": data.quotesearchvalue };
      this.agentService.getQuote(params)
        .subscribe(result => {
          this.quotes = result.quotesArray;
          this.searchMessage = "";
          this.loaderService.isBusy = false;
        },
          error => {
            this.quotes = [];
            this.searchMessage = error.error.errMessage;
            this.loaderService.isBusy = false;
          });
    }
  }
  policySearch(policysearchDiv, reqPolicyDiv) {
    this.showDiv = true;
    policysearchDiv.style.display = "block";
    reqPolicyDiv.style.display = "none";
    this.policy = null;
    var data = this.PolicySearchForm.value;
    this.buttonEnable = false;
    if (data.policysearchname !== "" && data.policysearchname == "TPI_INS_NAME") {
      data.policysearchvalue = data.policysearchvalue.toUpperCase()
    }
    if (data.policysearchname == "") {
      this.messageService.add({ severity: 'warn', summary: 'Warning Message', life: 2000, detail: 'Please Search By Name' });
    } else if (data.policysearchvalue == "") {
      this.messageService.add({ severity: 'warn', summary: 'Warning Message', detail: 'Please Search By Number' });
    } else {
      let params = { "searchBy": data.policysearchname, "value": data.policysearchvalue, "agentId": this.session.get("agent"), "deptCode": this.session.get("departmentCode"), "userId": this.session.get("username") };
      this.agentService.getPolicy(params)
        .subscribe(result => {
          this.diaplaysearch = 'Policies';
          this.policy = result.activePolicyArray;
          this.searchMessage = "";
        },
          error => {
            this.searchMessage = error.error.errMessage;
          });
    }
  }

  printReport(datas) {
    let data = this.UserForm.value;
    if (!this.onlyMarine) {
      data.reportType = "2";
    }
    var vald = document.getElementById('reportrang').innerHTML;
    var dates = vald.split(' - ');
    let endate = dates[1];
    let stdate = dates[0];
    // let startDate = stdate.day + "/" + stdate.month + "/" + stdate.year
    // let endDate = endate.day + "/" + endate.month + "/" + endate.year;
    if ("2" == data.reportType) {
      var params = {
        "userId": this.session.get("agent"), "userName": data.userId, "lobCode": data.userLob, "schemes": data.userScheme, "divnCode": this.session.get("divisionCode"),
        "startDate": stdate, "endDate": endate, "summary": '1', "userExcel": data.userExcel, "portal": this.session.get("portaltype"), "comm": this.session.get("subAGprintCreditAccess"), "subComm": this.session.get("printCreditAccess"), "loginUserName": this.session.get("username")
      };
      if ("1" == data.userExcel || "" == data.userExcel) {
        var param = {
          "agent": this.session.get("agent"),
          "lobCode": data.userLob,
          "divisionCode": this.session.get("divisionCode"),
          "departmentCode": this.session.get("departmentCode"),
          "startDate": stdate,
          "endDate": endate,
          "userId": data.userId,
          "schemes": data.userScheme,
          "loginUserName": this.session.get("username"),
          "reportType": data.reportType
        };
        this.commonService.excelExport(param)
      } else {
        this.agentService.PrintReportUrl(params)
      }
      var Url;

      /*.subscribe(result => {
       /* Url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
        width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(Url, 'Product Category', param);

      });*/
    } else if ("1" == data.reportType) {
      data.userLob = '01';
      var param = {
        "agent": this.session.get("agent"),
        "lobCode": data.userLob,
        "divisionCode": this.session.get("divisionCode"), "departmentCode": this.session.get("departmentCode"),
        "startDate": stdate, "endDate": endate,
        "userId": data.userId,
        "schemes": data.userScheme,
        "loginUserName": this.session.get("username"),
        "reportType": data.reportType
      };
      this.commonService.excelExport(param)
    } else {
      this.messageService.add({ severity: 'warn', summary: 'Warning Message', detail: 'Please Select Report Type' });
    }
  }
  getSchemeList() {
    let userLob = this.UserForm.get('userLob').value
    let params = { "empUserId": this.session.get("agent"), "empLobCode": userLob };
    this.agentService.getSchemeList(params)
      .subscribe(result => {
        this.schemes = result.schemeList;
      });
  }

  getUserList() {
    let params = { "empUserId": this.session.get("agent"), "empCrUid": this.session.get("username") };
    this.agentService.getUserList(params)
      .subscribe(result => {
        this.users = result.userList;
      });
  }

  getPolicyRequest() {
    this.policyReqList = null;
    let params = { "empUserId": this.session.get("username") };
    this.agentService.getPolicyRequest(params)
      .subscribe(result => {
        this.policyReqList = result.policyReqList;
        this.loaderService.isBusy = false;
      });
  }
  changebusiness(type) {
    if ("premium" == type) {
      setTimeout(() => {
        this.getBusiness();
      }, 5000);
    }
    else if ("policy" == type) {
      setTimeout(() => {
        this.getPolicyBusiness();
      }, 5000);
    }
  }

  getBusiness() {
    this.loaderService.isBusy = true;
    let drp = $('#reportrange4').data('daterangepicker');
    var startDate;
    var endDate;
    if (drp != undefined) {
      let stdate = new Date(drp.startDate);
      let endate = new Date(drp.endDate);
      startDate = stdate.getDate() + "/" + (stdate.getMonth() + 1) + "/" + stdate.getFullYear();
      endDate = endate.getDate() + "/" + (endate.getMonth() + 1) + "/" + endate.getFullYear();
    } else {
      let date = new Date();
      startDate = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
      endDate = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
    }
    let params = { "empUserId": this.session.get("agent"), "empCrUid": this.session.get("username"), "startDate": startDate, "endDate": endDate };
    this.premium = 0;
    this.commissions = 0;
    let arr1 = new Array();
    let arr2 = new Array();
    let arr3 = new Array();
    let arr4 = new Array();
    this.agentService.getBusiness(params)

      .subscribe(result => {
        this.businessList = result.businesslist;
        for (let i = 0; i < result.businesslist.length; i++) {
          let lobdesc = result.businesslist[i].key;
          let netpremium = parseInt(result.businesslist[i].value);
          let lob = result.businesslist[i].info1;
          let agentcomm = parseInt(result.businesslist[i].info2);
          this.premium = this.premium + netpremium;
          this.commissions = this.commissions + agentcomm;
          arr1.push(lobdesc);
          arr2.push(netpremium);
          arr3.push(lobdesc);
          arr4.push(agentcomm);
        }
        if (arr1.length > 0 && arr2.length > 0) {
          this.pieChartLabels = arr1;
          this.pieChartData = arr2;
        } else {
          this.pieChartLabels = ['No Business'];
          this.pieChartData = [100];
        }
        if (arr3.length > 0 && arr4.length > 0) {
          this.pieChartLabels1 = arr3;
          this.pieChartData1 = arr4;
        } else {
          this.pieChartLabels1 = ['No Business'];
          this.pieChartData1 = [100];
        }
        this.loaderService.isBusy = false;
      });
  }

  getPolicyBusiness() {
    this.loaderService.isBusy = true;
    this.quotevalue = null;
    this.policyvalue = null;
    let drp = $('#reportrange3').data('daterangepicker');
    var startDate;
    var endDate;
    if (drp != undefined) {
      let stdate = new Date(drp.startDate);
      let endate = new Date(drp.endDate);
      startDate = stdate.getDate() + "/" + (stdate.getMonth() + 1) + "/" + stdate.getFullYear();
      endDate = endate.getDate() + "/" + (endate.getMonth() + 1) + "/" + endate.getFullYear();
    } else {
      let date = new Date();
      startDate = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
      endDate = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
    }
    let params = { "empUserId": this.session.get("agent"), "empCrUid": this.session.get("username"), "startDate": startDate, "endDate": endDate };
    this.agentService.getPolicyBusiness(params)
      .subscribe(result => {
        this.quoteBusinessInfo = result.quoteInfo;
        this.policyBusinessInfo = result.policyInfo;
        this.quoteCount = this.quoteBusinessInfo.length;
        this.policyCount = this.policyBusinessInfo.length;
        this.loaderService.isBusy = false;

      });
  }

  viewquoteDetails() {
    this.quotevalue = this.quoteBusinessInfo;
  }
  viewpolictDetails() {
    $('#search-tabs-home, #tab-rp').hide();
    this.policyvalue = this.policyBusinessInfo;
  }
  getUserMessage() {
    let params = { "agentId": this.session.get("agent"), "userId": this.session.get("username") };
    this.agentService.getUserMessage(params)
      .subscribe(result => {
        this.message = result.resultMsg;
      });
  }

  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public pieChartType: string = 'pie';
  public randomizeType(): void {
    this.pieChartType = this.pieChartType === 'doughnut' ? 'pie' : 'doughnut';
  }

  public chartClicked(e: any): void {
  }

  getReport(reportType) {
    this.loaderService.isBusy = true;
    if (reportType == "Fleet_Cert") {
      this.commonService.getFleetReport(this.trans_Id, this.trans_Sno - 1, reportType, this.session.get("portaltype"), "END", this.riskSrNo, this.riskSrNo, "", "");
    } else {
      this.commonService.getReport(this.trans_Id, this.trans_Sno, reportType, this.session.get("portaltype"), this.tranType, this.riskSrNo, this.riskSrNo);
    }
    this.loaderService.isBusy = false;
  }

  loadAgentDoc(reportType) {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=1000,height=400,left=100%,top=100%`;
    var winRef = window.open('viewdocument?transId=' + this.trans_Id + '&reportType=' + reportType + '&policyNo=' + this.policy_No + '&page=dash', 'Product Category', param);
  }

  loadAgentMarineDoc() {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=1000,height=400,left=100%,top=100%`;
    var winRef = window.open('viewdocument?transId=' + this.trans_Id + '&reportType=&policyNo=' + this.policy_No + '&page=dash', 'Product Category', param);
  }


  viewPolicyDetails() {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=0,height=0,left=-1000,top=-1000`;
    var winRef = window.open('viewPolicy?transId=' + this.trans_Id + '&tranSrNo=' + this.trans_Sno + '&lobCode=' + this.lob_Code, 'view policy', param);
  }

  getDocument(transId, tranSrNo) {
    var params = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=0,height=0,left=-1000,top=-1000`;
    var winRef = window.open('./assets/Forms_Templates/001/Third_Party_Liability.pdf', 'Product Category', params);
    winRef.focus();
  }
  GetEndorsementPage() {
    let obj = { "transId": this.trans_Id, "transSNo": this.trans_Sno, "policyNo": this.policy_No, "lobCode": this.lob_Code, "polStartDate": this.polStartDate, "polEndDate": this.polEndDate, "schCode": this.schCode, "prodCode": this.prodCode };
    this.router.navigate(['endorsements'], { queryParams: obj, skipLocationChange: true });
  }
  endorsement(quote) {
    let obj = { "transId": quote.transId, "transSNo": quote.tranSrNo, "policyNo": quote.policyNo, "lobCode": quote.lobCode, "polStartDate": quote.polStartDate, "polEndDate": quote.polEndDate, "schCode": quote.schCode, "prodCode": quote.prodCode };
    this.router.navigate(['endorsements'], { queryParams: obj, skipLocationChange: true });
  }


  getPolicyHistory() {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
  width=0,height=0,left=-1000,top=-1000`;
    var winRef = window.open('./viewHistory?transId=' + this.trans_Id, 'History', param);
  }

  setpolicyDetails(Quote) {
    this.showPolicyStatus = true;
    this.selectedPolicy = Quote;
    this.trans_Id = Quote.transId;
    this.trans_Sno = Quote.tranSrNo;
    this.policy_No = Quote.policyNo;
    this.lob_Code = Quote.lobCode;
    this.polStartDate = Quote.polStartDate;
    this.polEndDate = Quote.polEndDate;
    this.schCode = Quote.schCode;
    this.prodCode = Quote.prodCode;
    this.tranType = Quote.transType;
  }

  proceedViewCertificate() {
    if (this.policy_No === "" || this.policy_No === undefined || this.policy_No === null || this.policy_No === 'null') {
      this.messageService.add({ severity: 'error', summary: 'Error Message', detail: 'Please Select Certificate No.' });
    } else {
      this.PolicySearchForm.patchValue({
        policysearchname: 'TPI_POLICY_NO',
        policysearchvalue: this.policy_No,
      });

      this.showDiv = true;
      $('#contaniner-policysearch-results, #contaniner-policysearch-results').show();
      this.policy = null;
      var data = this.PolicySearchForm.value;
      this.buttonEnable = false;
      let params = { "searchBy": data.policysearchname, "value": data.policysearchvalue, "agentId": this.session.get("agent"), "deptCode": this.session.get("departmentCode"), "userId": this.session.get("username") };
      this.agentService.getPolicy(params)
        .subscribe(result => {
          this.diaplaysearch = 'Policies';
          this.policy = result.activePolicyArray;
          this.searchMessage = "";
        },
          error => {
            this.searchMessage = error.error.errMessage;
          });
      $('.radio-marine').attr('checked', 'true');
      $('.c-modal').css('display', 'none');
      $('#search-tabs-home, #tab-rp').show();
      window.scrollTo(0, 0);
    }
  }

  CheckSummaryValue(event) {
    this.summary = event.target.checked;
    if (event.target.checked) {
      this.UserForm.get('userExcel').disable();
      this.UserForm.get('userExcel').setValue("0");
    } else {
      this.UserForm.get('userExcel').enable();
      this.UserForm.get('userExcel').setValue("1");
    }
  }
  CheckExcelValue(event) {
    this.excel = event.target.checked;
    if (event.target.checked) {
      this.UserForm.get('userSummary').disable();
      this.UserForm.get('userExcel').setValue("1");
    } else {
      this.UserForm.get('userSummary').enable();
      this.UserForm.get('userExcel').setValue("0");
    }
  }

  checkExcelYn(event) {
    if (event) {
      // this.UserForm.get('userSummary').disable();
      //this.UserForm.get('userExcel').enable();
      this.UserForm.get('userExcel').setValue("1");
    } else {
      // this.UserForm.get('userExcel').disable();
      this.UserForm.get('userExcel').enable();
      this.UserForm.get('userExcel').setValue("0");
    }
  }

  checkSummaryYn(event) {
    if (event) {
      this.UserForm.get('userSummary').enable();
      this.UserForm.get('userExcel').disable();
      this.UserForm.get('userExcel').setValue("0");
    } else {
      this.UserForm.get('userSummary').disable();
      this.UserForm.get('userExcel').enable();
      this.UserForm.get('userExcel').setValue("1");
    }
  }

  retrieveQuote(Quote) {
    let obj = {
      "transId": Quote.transId,
      "tranSrNo": Quote.tranSrNo
    };
    this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
  }

  editMessage(str) {
    this.messageForm.patchValue({
      message: str
    });
  }

  fetchingQuoteData(data) {
    let obj = {
      transId: data.transId,
      tranSrNo: data.tranSrNo,
      quoteNo: data.quoteNo,
      editYn: "1",
      openPolicyNo: data.openPolNo
    };
    if (ApplicationConstants.LOB_MOTOR == data.lobCode) {
      this.checkTrimCode(data);
      //this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: false });
    } else if (ApplicationConstants.LOB_TRAVEL == data.lobCode) {
      this.router.navigate(['travel'], { queryParams: obj, skipLocationChange: false });

    } else if (ApplicationConstants.LOB_HOME == data.lobCode) {
      this.router.navigate(['home'], { queryParams: obj, skipLocationChange: false });

    } else if (ApplicationConstants.LOB_MARINE_HULL == data.lobCode) {
      this.router.navigate(['marine_hull'], { queryParams: obj, skipLocationChange: false });
    } else if (ApplicationConstants.LOB_MARINE_INSURANCE == data.lobCode) {
      this.router.navigate(['create-certificate'], { queryParams: obj, skipLocationChange: false });
    }
  }


  getFormattedDate(date) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    const hours = date.getHours();
    const minutes = date.getMinutes();
    return day + "/" + month + "/" + year + " " + hours + ":" + minutes;
  }

  closemodel(myModel) {
    myModel.className = 'modal hide';
  }
  saveMessage() {
    var data = this.messageForm.value;
    let params = { "value": data.message, "agentId": this.session.get("agent") };
    this.agentService.updateAgentMessage(params)
      .subscribe(result => {
        this.getUserMessage();
      });
  }

  quoteRetrive(cont, policysearchDiv, reqPolicyDiv, block) {
    policysearchDiv.style.display = "block";
    reqPolicyDiv.style.display = "active-blue";
    cont.style.display = "block";
    block.style.display = "block";
  }

  policyRetrive(cont, quotesearchDiv, reqPolicyDiv, block) {
    quotesearchDiv.style.display = "none";
    reqPolicyDiv.style.display = "none";
    cont.style.display = "block";
    block.style.display = "block";
  }

  ngAfterViewInit() {
    var $modal = $('.c-modal');
    var $button = $('.js-modal');
    var $close = $('.js-close-modal');
    var $submit = $('.js-submit-modal');

    $modal.hide();

    $button.on('click', function () {
      // give empty display property to css 'display: "" '
      $modal.css('display', '');

      // sets the target to the correct modal
      var target = "#" + $(this).data("target");

      // hide any modal other than the one clicked
      $modal.not(target).hide();

      // adds 'js-animate-in' for the modal clicked
      $(target).addClass('js-animate');

      $('modal1').show();

      // checked to see which modal was clicked


    });

    $close.on('click', function () {

      $modal.removeClass('js-animate');
      $modal.css('display', '');
      $modal.addClass('js-animate-out');

      setTimeout(function () {
        $modal.removeClass('js-animate-out');
        $modal.css('display', 'none');
      }, 1000);

    });

    // submits the form
    $submit.on('click', function () {
      $submit.toggleClass('js-loading');
      // $submit.css('display', "block");
      setTimeout(function () {
        $submit.removeClass('js-loading');
        $submit.addClass('js-animate-submit');
      }, 2000);
    })

  }
  //------------------view Claims-------------------//
  viewClaimDetails(viewClaim) {
    let obj = { "transId": this.trans_Id, "tranSrNo": this.trans_Sno, "policyNo": this.policy_No, "lobCode": this.lob_Code };
    this.router.navigate(['viewClaim'], { queryParams: obj, skipLocationChange: true });

  }

  checkEndorsedData() {
    this.loaderService.isBusy = true;
    let params = { "trans_Id": this.trans_Id, "endTranSno": parseInt(this.trans_Sno) + 1 };
    this.agentService.checkEndorsedData(params)
      .subscribe(result => {
        let obj = { "transId": this.trans_Id, "tranSrNo": parseInt(this.trans_Sno) + 1, "lobCode": '01', "policyNo": this.policy_No, "reportType": 'POL', "endType": result.endorsedData, "schCode": this.schCode, "prodCode": this.prodCode };
        if ('016' == result.endorsedData) {
          this.router.navigate(['certificateendt'], { queryParams: obj, skipLocationChange: true });
          this.loaderService.isBusy = false;
        }
      },
        error => {
          this.callEndorsePackage();

        });
  }

  callEndorsePackage() {
    let endFromDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy');
    let endToDate = this.datepipe.transform(new Date().getTime() + (7 * 24 * 60 * 60 * 1000), 'dd/MM/yyyy');
    let endTranIssueDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy');


    let params = {
      "trans_Id": this.trans_Id, "trans_Sno": this.trans_Sno, "endorseType": ApplicationConstants.ENDORSE_TYPE_FLEET_CERT, "endFromDate": endFromDate, "lobCode": ApplicationConstants.LOB_MOTOR,
      "endToDate": endToDate, "calType": '2', "userName": this.session.get("username"), "userType": this.session.get("usertype"), "endTranSno": parseInt(this.trans_Sno) + 1, "endTranIssueDate": endTranIssueDate
    };

    this.agentService.callEndorsePackage(params)
      .subscribe(result => {
        let obj = { "transId": this.trans_Id, "tranSrNo": parseInt(this.trans_Sno) + 1, "lobCode": ApplicationConstants.LOB_MOTOR, "policyNo": this.policy_No, "reportType": 'POL', "endType": result.endorsement, "schCode": this.schCode, "prodCode": this.prodCode };
        if (ApplicationConstants.ENDORSE_TYPE_FLEET_CERT == result.endorsement) {
          this.router.navigate(['certificateendt'], { queryParams: obj, skipLocationChange: true });
        }

      });

  }

  onMotorClick(menu) {
    const eDataFlag = this.session.get('eDataFlag');
    if (eDataFlag && eDataFlag === '1') {
      let obj = {
        isOldVessel: true
      };
      this.router.navigate(['/firstScreenMotor'], { queryParams: obj, skipLocationChange: true });
      //this.router.navigate(['/firstScreenMotor']);
    } else {
      this.router.navigate([menu.key.toLowerCase()]);
    }
  }

  getNames() {
  }

  onIconClick(data) {
    if (data.key == 'HOME') {
      this.router.navigate(['/home']);
    }
    if (data.key == 'MARINE_HULL') {
      this.router.navigate(['/marine_hull']);
    }
    if (data.key == 'TRAVEL') {
      this.router.navigate(['/travel']);
    }
    if (data.key == 'MARINE') {
      this.router.navigate(['/marine-insurance']);
    }
  }
  pageChange(newPage: number) {
    this.router.navigate(['agentdashboard'], { queryParams: { page: newPage }, skipLocationChange: true });
  }

  checkTrimCode(data) {
    this.loaderService.isBusy = true;
    let params = { "transId": data.transId, "tranSrNo": data.tranSrNo };
    this.agentService.checkTrimCode(params)
      .subscribe(result => {
        if (result.vesselCode != null) {
          let obj = {
            transId: data.transId,
            tranSrNo: data.tranSrNo,
            specVal: "1",
            isOldVessel: false,
            oldTrimId: result.vesselCode
          };
          this.router.navigate(['/firstScreenMotor'], { queryParams: obj, skipLocationChange: true });
        } else {
          let obj = {
            transId: data.transId,
            tranSrNo: data.tranSrNo,
            quoteNo: data.quoteNo,
            editYn: "1",
          };
          this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
        }
      },
        error => {


        });
  }

}
