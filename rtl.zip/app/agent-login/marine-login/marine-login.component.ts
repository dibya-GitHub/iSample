import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { RecaptchaComponent } from 'ng-recaptcha';
import { ApplicationConstants } from 'src/shared/application-constants';
import { environment } from '../../../environments/environment';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { AgentUserService } from '../../../shared/services/agent-user.service';
import { AgentHttpclientService } from '../../services/agent-httpclient.service';

declare function SHA512(password): string;

@Component({
  selector: 'app-marine-login',
  templateUrl: './marine-login.component.html',
  styleUrls: ['./marine-login.component.scss']
})
export class MarineLoginComponent implements OnInit {

  @ViewChild('captcha') captcha: RecaptchaComponent;

  captchaErr;
  showCaptchaErr: boolean = false;
  public siteKey = environment.siteKey;
  public count: number = 0;
  portalType: string = ApplicationConstants.SRC_TYPE_AGENT;
  agentLoginForm: UntypedFormGroup;
  loginProceedForm: UntypedFormGroup;
  resetForm: UntypedFormGroup;
  private formSubmitAttempt: boolean;
  private form2submitAttempt: boolean = false;
  private form3SubmitAttempt: boolean = false;
  public userName: string;
  public screen1: boolean = true;
  public empUserId: string;
  public errorMsg: string;
  companyCode = '002';
  public resetScreen = false;
  public screen2: boolean = false;
  hashkey: string;
  hashValue: string;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';


  constructor(public router: Router,
    private agentService: AgentUserService,
    private clientService: AgentHttpclientService,
    private fb: UntypedFormBuilder,
    private session: SessionStorageService,
    private spinnerService: LoaderService
  ) {
    this.agentLoginForm = this.fb.group({
      userId: ['', Validators.required]
    });
  }

  ngOnInit() {
    // this.loaderService.isBusy = true;
    this.screen2 = true;
    this.session.set("companyCode", this.companyCode);
    this.createForm();
  }
  // ngAfterConentInit(){
  //   const scene=document.getElementById('scene');
  //   const parallaxInstance=new Parallax(scene,{
  //       relativeInput:true,
  //       howerOnly:true
  //   });
  // }
  createForm() {
    this.loginProceedForm = this.fb.group({
      password: ['', Validators.required],
      userId: ['', Validators.required]
    });
  }

  createRestForm() {
    this.resetForm = this.fb.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      rePassword: ['', Validators.required]
    });
  }

  onClickSubmit() {
    this.formSubmitAttempt = true;
    //this.empUserId = this.agentLoginForm.get('userId').value;

    this.empUserId = this.loginProceedForm.get('userId').value;

    /*if (this.count >= 2) {
        if (this.captcha.getResponse() == '') {
          this.captchaErr = 'Please Validate Username and Captcha';
          this.showCaptchaErr = true;
          return false;
        } else {
          this.count = 0;
          this.showCaptchaErr = false;
        }
      }*/
    this.spinnerService.isBusy = true;
    var obj = {
      userId: this.empUserId,
      userType: 'A'
    };
    this.clientService.getUserName(obj).subscribe(response => {
      this.spinnerService.isBusy = false;
      let data: any = response;
      this.session.set('lastLogin', data.lastLogin);

      this.userName = data.userName;
      this.hashkey = data.key;
      this.hashValue = data.value;
      this.screen1 = false;
      this.screen2 = true;
      this.errorMsg = null;
    }, error => {
      this.spinnerService.isBusy = false;
      this.screen1 = true;
      this.errorMsg = "Invalid Login ID";
      this.count++;

    });
    //}

  }

  secondScreenProceed() {

    this.form2submitAttempt = true;
    if (this.loginProceedForm.valid) {
      // if (this.count >= 2) {
      //   if (this.captcha.execute) {
      //     this.captchaErr = 'Please Validate Password and Captcha';
      //     this.showCaptchaErr = true;
      //     return false;
      //   } else {
      //     this.count = 0;
      //     this.showCaptchaErr = false;
      //   }

      // }
      this.spinnerService.isBusy = true;
      let hashedPwd = SHA512(this.loginProceedForm.get('password').value + this.hashValue);
      let reqParams = {
        "username": this.empUserId,
        "password": hashedPwd,
        // "password": this.loginProceedForm.get('password').value,
        "portalType": this.portalType,
        "grant_type": "retail", "scope": "oob",
        "key": this.hashkey
      };
      this.agentService.verifyAgentLogin(reqParams).subscribe((response: any) => {
        this.session.set("access_token", response.access_token);
        this.session.set("refresh_token", response.refresh_token);
        let jwtStr: any = response.jwt.split(".");
        var data: any = JSON.parse(atob(jwtStr[1]));
        this.session.set("username", data.empUserId);
        //this.session.set('ipAddress',data.ip); //This has to be found and set 
        this.session.set("LoginID", this.empUserId);
        this.session.set("portaltype", ApplicationConstants.SRC_TYPE_AGENT);
        this.session.set("nameSpace", "/agent");
        this.session.set("country", this.companyCode);
        this.session.set("companyCode", this.companyCode);
        this.session.set("USER_ROLE_ID", data.empUserRoleId)
        this.session.set("divisionCode", data.empDivnCode);
        this.session.set("departmentCode", data.empDeptCode);
        this.session.set("adminYN", data.empAdminYn); //For Emp Portal
        this.session.set("usertype", ApplicationConstants.SESSION_SRC_TYPE_AGENT);
        this.session.set("agent", data.empAgentId);
        this.session.set("loginUserName", data.empUserName);
        this.getDocument(response.empAgentId, 'POL');
        let reqParams = {
          "empUserRoleId": data.empUserRoleId, "portalType": this.portalType, "empAgentId": data.empAgentId,
          "empCode": data.empAgentId
        };
        this.agentService.getAgentSessionProps(reqParams).subscribe((response: any) => {
          if (response.respCode == 2000) {
            this.session.set("USER_PAY_LINK_YN", response.payLinkAccess)
            this.session.set("USER_CR_DT", response.curDateTime)
            this.session.set("precision", response.roundOff)
            this.session.set("ApplicationMode", response.APP_MODE)
            this.session.set("baseCurrency", response.CURR_CODE)
            this.session.set("CurrencyName", response.CURR_NAME)
            this.session.set("policyDuration", response.POL_DURATION)
            this.session.set("policyAccess", response.policyAccess)
            this.session.set("claimAccess", response.claimAccess)
            this.session.set("printAccess", response.printAccess)
            this.session.set("printCreditAccess", response.printCreditAccess)
            this.session.set("userSettingAccess", response.userSettingAccess)
            this.session.set("quoteAccess", response.quoteAccess)
            this.session.set("vehicleAccess", response.vehicleAccess)
            this.session.set("payLinkAccess", response.payLinkAccess)
            this.session.set("subAGprintCreditAccess", response.subAGprintCreditAccess)
            this.session.set("historyFlag", response.historyFlag)
            this.session.set("showReport", response.REPORT_FLAG)
            this.session.set("installAccess", response.installAccess)
            this.session.set('eDataFlag', response.eDataFlag);
            this.session.set("userFilter", response.userFilter)
            let reqParams = { "userId": this.session.get("USER_ROLE_ID") };
            this.agentService.getAgentDashboardUrl(reqParams).subscribe(response => {
              this.session.set("dashboardUrl", response.dashboardurl);
              this.router.navigate(['agentdashboard']);
            },
              error => {
                this.errorMsg = "Invalid Credential";
              });
          }
          //this.router.navigate(['agent-dashboard'],{queryParams:{'transId':"1397780",'tranSrNo':"0","lobCode":"01"},skipLocationChange: true}); 
          this.spinnerService.isBusy = false;
          //this.router.navigate(['agent-dashboard']); 
        },

          error => {
            this.spinnerService.isBusy = false;
            this.errorMsg = "Invalid Credential";
          });


      }, error => {
        this.spinnerService.isBusy = false;
        let status = JSON.parse(error["_body"]).error_description;
        if ('Reset Password' === status) {
          this.createRestForm();
          this.errorMsg = "";
          this.resetScreen = true;
          this.screen1 = false;
          this.screen2 = false;
        } else {
          this.errorMsg = status;
          this.spinnerService.isBusy = false;
          this.count++;
          this.router.navigate(['/marine-login']);
        }
      });

    }
  }

  resetPwd() {
    this.form3SubmitAttempt = true;
    this.errorMsg = null;
    if (this.resetForm.valid) {
      this.spinnerService.isBusy = true;
      let hashedPwd = SHA512(this.resetForm.get('oldPassword').value + this.hashValue);
      let param = {
        empUserId: this.empUserId,
        empOldPassword: this.resetForm.get('oldPassword').value,
        empPassword: this.resetForm.get('newPassword').value,
        empConfirmPassword: this.resetForm.get('rePassword').value,
        portalType: 'A',
        key: this.hashkey
      };
      this.agentService.resetPassword(param).subscribe((response: any) => {
        this.spinnerService.isBusy = false;
        this.resetScreen = false;
        this.screen2 = true;
        this.errorMsg = response.errMessage;
        //this.router.navigate(['/marine-login']);
      }, error => {
        let status = error._body;
        status = JSON.parse(status).errMessage;
        this.errorMsg = status;
        //this.router.navigate(['/marine-login']);
      });
    }
  }

  getDocument(angenId, reportType) {
    var params = { "trans_Id": angenId, "typeOfReport": reportType, "userId": this.session.get("username") };
    this.agentService.getDocInfoByType(params)
      .subscribe(result => {
        for (let i = 0; i < result.documentInfoList.length; i++) {
          let docUrl = result.documentInfoList[i].docUrl;
          this.getFileUrl(docUrl);
        }
      });

  }

  getFileUrl(url) {
    var params = { "fileUrl": url, "userRole": this.session.get("USER_ROLE_ID") };
    this.agentService.getFileUrl(params)
      .subscribe(result => {
        this.session.set("profileUrl", result.fileUrl)
      });
  }

  homePage() {

  }

  forgotPwd() {
    this.router.navigate(['reset'], { queryParams: { 'userId': this.empUserId }, skipLocationChange: true });

  }

  get f() { return this.agentLoginForm.controls; }

  get f2() { return this.loginProceedForm.controls; }

  get f3() { return this.resetForm.controls; }

}
