import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarineLoginComponent } from './marine-login.component';

describe('MarineLoginComponent', () => {
  let component: MarineLoginComponent;
  let fixture: ComponentFixture<MarineLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarineLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarineLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
