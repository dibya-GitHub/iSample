import { Component, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { RecaptchaComponent } from 'ng-recaptcha';
import { AgentUserService } from '../../../shared/services/agent-user.service';

import { environment } from '../../../environments/environment';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { AgentHttpclientService } from '../../services/agent-httpclient.service';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  @ViewChild('captcha') captcha: RecaptchaComponent;
  public errorMsg: string = '';
  agentResetForm: UntypedFormGroup;
  showCaptchaErr;
  captchaErr;
  public siteKey = environment.siteKey;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  constructor(public router: Router,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private fb: UntypedFormBuilder,
    private session: SessionStorageService,
    private spinnerService: LoaderService
  ) {
    this.agentResetForm = this.fb.group({
      userId: ['', Validators.required],
      civilId: ['', Validators.required]
    });
  }

  ngOnInit() {

  }

  onClickSubmit() {

    if (this.captcha.execute) {
      this.captchaErr = 'Please Validate Captcha';
      this.showCaptchaErr = true;
      return false;
    } else {
      this.showCaptchaErr = false;
    }
    if (this.agentResetForm.get('userId').value == '') {
      alert('Please enter user Id');
      return false;
    }
    if (this.agentResetForm.get('civilId').value == '') {
      alert('Please enter emirates Id');
      return false;
    }
    this.spinnerService.isBusy = true;
    let obj = {
      "empUserId": this.agentResetForm.get('userId').value,
      "empCivilId": this.agentResetForm.get('civilId').value
    };
    this.agentService.agentForgotPwd(obj).subscribe(response => {
      this.errorMsg = response.P_ERROR;
      this.router.navigate(['/marine-login']);
      this.spinnerService.isBusy = false;
      this.router.navigate(['/marine-login']);
    }, error => {
      this.errorMsg = error.errMessage;
      this.router.navigate(['/marine-login']);
      this.spinnerService.isBusy = false;
      this.router.navigate(['/marine-login']);
    });
  }
  homePage() {

  }
}
