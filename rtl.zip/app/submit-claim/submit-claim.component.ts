import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { AppUtil } from '../services/app-util';

@Component({
  selector: 'app-submit-claim',
  templateUrl: './submit-claim.component.html',
  styleUrls: ['./submit-claim.component.scss']
})
export class SubmitClaimComponent implements OnInit {

  public regnLocList: Array<any>;
  appUtilObj: AppUtil = new AppUtil();
  showMsg: boolean = false;
  anyLoc: any;
  txnId: any;
  srNo: any;
  polNo: any;
  lobCode: any;
  startDate: any;
  postDate: any;
  insuredData: any;
  registrationNo: any;
  placeOfAccdnt: any;
  mobile: any;
  email: any;
  policeRefNo: any;
  towingYN: number = 0;
  clmRefNo: any;
  routeData: any;
  date: Date = new Date();
  transId: any;
  tranSrNo: any;
  anyDate: any;
  searchBy: any;
  errorMsg: string = '';
  testRegisterationNo: string = "";
  constructor(public route: ActivatedRoute,
    public router: Router,
    private agentService: AgentHttpclientService,
    private session: SessionStorageService,
  ) {
    this.route.queryParams.subscribe(params => {
      this.routeData = params
      this.txnId = params["id"];
      this.srNo = params["srNo"];
      this.polNo = params["value"];
      this.lobCode = params["lobCode"];
      this.policeRefNo = params["policeRefNo"];
      if (params["acciDate"] != undefined) {
        this.anyDate = new Date(params["acciDate"]);
        // this.postDate= this.anyDate;
        this.postDate = params["acciDate"];
        this.startDate = {
          "day": this.anyDate.getDate(),
          "month": (this.anyDate.getMonth() + 1),
          "year": this.anyDate.getFullYear(),
          "formatted": this.appUtilObj.appendZero(this.anyDate.getDate()) + '/' + this.appUtilObj.appendZero((this.anyDate.getMonth() + 1)) + '/' + this.anyDate.getFullYear(),
        };
      }
      if (params["acciDate"] != undefined) {
        this.anyDate = new Date(params["acciDate"]);
        // this.postDate= this.anyDate;
        this.postDate = params["acciDate"];
      }
      //this.placeOfAccdnt = params["accidentLoc"];
      if (params["accidentLoc"] != undefined) {
        this.anyLoc = params["accidentLoc"];
      }
      if (params["towingYN"] != undefined) {
        this.towingYN = params["towingYN"];
      }
      this.email = params["emailId"];
      this.testRegisterationNo = params["vehRegnNo"];
      this.mobile = params["mobileNo"];
    });

  }

  ngOnInit() {
    let v_regLoc = { "type": "REGN_LOC" };
    this.agentService.getGeoList(v_regLoc)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.regnLocList = arr;
        this.placeOfAccdnt = this.anyLoc;
      })
    this.getPolicyVehicleInfo();
  }

  getPolicyVehicleInfo() {
    let postData = {
      transId: this.txnId,
      tranSrNo: this.srNo
    }
    //this.loaderService.isBusy = true;
    this.agentService.getPolVehicleInfo(postData).subscribe(data => {
      $('.container').show();
      if (this.testRegisterationNo != undefined || this.testRegisterationNo != null) {
        this.registrationNo = this.testRegisterationNo;
      }
      else {
        this.registrationNo = data.regnNo;
      }

    }, error => {
      this.errorMsg = this.appUtilObj.displayError(error["_body"], null);
      $('.container').show();
    });
  }
  insuredClaimData() {
    let insuredData = {
      policyNo: this.polNo,
      lobCode: this.lobCode,
      acciDate: this.postDate,
      policeRefNo: this.policeRefNo,
      emailId: this.email,
      mobileNo: this.mobile,
      vehRegnNo: this.registrationNo,
      accidentLoc: this.placeOfAccdnt,
      towingYN: this.towingYN,
      txnId: this.txnId,
      srNo: this.srNo,
      searchBy: this.routeData["searchBy"],
      value: this.routeData["value"],
      Is_I_Insured: true
    }

    this.router.navigate(['upload-claim-docs'], { queryParams: insuredData, skipLocationChange: true });

  }

  changeAccidentDate(event: any) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsg = false;
    }
    this.startDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
    this.postDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
  }

  onDateInput(event) {

    if (event != undefined) {
      if (event.target.classList.contains('invaliddate')) {
        this.showMsg = true;
      } else {
        this.showMsg = false;
        if (event.target.value != '') {
          this.startDate = event.target.value;
        }
      }
    }
  }
  goToPreviousPage() {
    this.router.navigate(['find-active-policy'], { queryParams: this.routeData, skipLocationChange: true });
  }
  towing() {

  }
}
