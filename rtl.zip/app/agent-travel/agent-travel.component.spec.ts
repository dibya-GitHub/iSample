import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentTravelComponent } from './agent-travel.component';

describe('AgentTravelComponent', () => {
  let component: AgentTravelComponent;
  let fixture: ComponentFixture<AgentTravelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentTravelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentTravelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
