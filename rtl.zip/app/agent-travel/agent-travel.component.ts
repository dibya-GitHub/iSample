import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { TravelInfo, TravelQuoteInfo } from 'src/app/agent-travel/classes/primaryInfo';
import { ApplicationConstants } from 'src/shared/application-constants';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { ErrorMessage } from "../../shared/error-message";
import { Tooltip } from "../../shared/tool-tip";
import { CountryList } from '../agent-travel/interface/agent';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { Customer } from "./interface/agent";
import { ECalendarValue } from 'ng2-date-picker';
@Component({
  selector: 'app-agent-travel',
  templateUrl: './agent-travel.component.html',
  styleUrls: ['./agent-travel.component.scss']
})
export class AgentTravelComponent implements OnInit {
  travelBoundType: any;
  showErrMsg: boolean;
  noOfChild: any;
  noOfAdults: any;
  //ToolTip
  public tooltipMessgae = new Tooltip();

  //Error Message
  public Err_msg = new ErrorMessage();

  public modelList: Array<any>;
  public acountryList: Array<any>;
  public travelType: Array<any>;
  public travelcount: Array<any>;
  public dat: any;
  public date = new Date();
  public boList: CountryList[];
  //public endDate;
  public tripId;
  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));
  custTypeId: any;
  isShowcivil: boolean;
  isShowdiv: boolean;
  isshowboundType: boolean;
  isShow: boolean;
  mobilePattern: string = '[3567]{1,1}[0-9]{7,7}';
  civilIdPattern = '(^\d{3}-\d{4}-\d{7}-\d{1}$)';
  ip: any;
  quoteNo: any;
  public routeObj: any;
  paramforTravelInfo: any;
  values = '';
  agentId: string;
  transId: string;
  tranSrNo: string;
  lobCode: String;
  quoteInfo: TravelQuoteInfo;
  traveQuoteInfo: TravelInfo;
  adult: Array<any>;
  child;
  mobileNoErrorMessage;
  civilIdErrorMessage;
  insuranceType: any;

  titleAlert: string = 'This field is required';
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  convertedStartDate: any;

  material = true;
  ng2datePickerConfig: any = {
    firstDayOfWeek: 'su',
    monthFormat: 'MMM, YYYY',
    disableKeypress: false,
    allowMultiSelect: false,
    closeOnSelect: true,
    closeOnSelectDelay: 0,
    openOnFocus: true,
    openOnClick: true,
    onOpenDelay: 0,
    closeOnEnter: true,
    weekDayFormat: 'ddd',
    appendTo: document.body,
    showNearMonthDays: true,
    showWeekNumbers: false,
    enableMonthSelector: true,
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    dayBtnFormat: 'DD',
    monthBtnFormat: 'MMM',
    hours12Format: 'hh',
    hours24Format: 'HH',
    meridiemFormat: 'A',
    minutesFormat: 'mm',
    minutesInterval: 1,
    secondsFormat: 'ss',
    secondsInterval: 1,
    showSeconds: false,
    showTwentyFourHours: true,
    timeSeparator: ':',
    multipleYearsNavigateBy: 10,
    showMultipleYearsNavigation: false,
    locale: moment.locale(),
    hideInputContainer: false,
    returnedValueType: ECalendarValue.Moment,
    unSelectOnClick: true,
    hideOnOutsideClick: true,
    numOfMonthRows: 3,
    format: 'DD/MM/YYYY'
  };
  constructor(private fb: UntypedFormBuilder, private agentService: AgentHttpclientService,
    private commonService: AgentUserService, public router: Router,
    private route: ActivatedRoute,
    private messageService: MessageService,
    private session: SessionStorageService,
    private spinnerService: LoaderService) { }
  customer: Customer[] = [
    { custId: 0, custType: 'Individual' },
    { custId: 1, custType: 'Company' },
  ];

  quoteForm = this.fb.group({
    boundType: [, Validators.required],
    customerType: [, Validators.required],
    insuredName: [, Validators.required],
    emailId: [, Validators.email],
    civilId: [, [Validators.required, Validators.pattern(/(^\d{3}-\d{4}-\d{7}-\d{1}$)/)]],
    mobileNo: [, [Validators.required, Validators.pattern(/(^5\d{8}$|^(05)\d{8}$)/)]],
    company: [, Validators.required],
    telephoneNo: [],
    residenceCountry: [],
    travelFromCountry: ['', Validators.required],
    travelType: [],
    policyStartDate: ['', Validators.required],
    totalDays: [, [Validators.required, Validators.pattern('^([1-9][0-9]{0,2}|1000)$')]],
    endDate: [],
    adultCount: ['', Validators.required],
    childCount: [''],
    promoCode: [],
    visaNo: [],
    sponsor: [],
    passportNo: ['', Validators.required],
    insuranceType: [],
    refNo: [],
  });



  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.quoteNo = this.commonService.getParamValue('quoteNo');

    this.agentId = this.session.get('agent')
    this.quoteForm.get('customerType').setValue(0);
    this.setCivilText();
    // this.getBoundTypes();

    if (this.transId != undefined) {
      this.getQuote();
      //this.getTravelQuoteInfo()

    }
    this.getBoundTypes();
    this.changeInboundTravelInfo();
    //this.getTraveltype();
    this.adult = Array(201).fill(0).map((x, i) => i); // [0,1,2,3,4]
    this.child = Array(201).fill(0).map((x, i) => i);
    this.mobileNoErrorMessage = this.commonService.mobileNoErrorMessage();
    this.civilIdErrorMessage = this.commonService.civilIdErrorMessage();
  }
  //mydatePicker
  setCivilText() {
    this.custTypeId = this.quoteForm.controls['customerType'].value
    if (this.custTypeId == '0') {
      this.isShowcivil = true;
      this.quoteForm.get('company').clearValidators();
      this.quoteForm.get('company').updateValueAndValidity();
      this.quoteForm.get('civilId').setValidators([Validators.required, Validators.pattern(/(^\d{3}-\d{4}-\d{7}-\d{1}$)/)]);
      this.quoteForm.controls['civilId'].updateValueAndValidity();
    } else {
      this.isShowcivil = false;
      this.isShow = true;
      this.quoteForm.controls['civilId'].clearValidators();
      this.quoteForm.controls['civilId'].updateValueAndValidity();
      this.quoteForm.get('company').setValidators([Validators.required]);
      this.quoteForm.get('company').updateValueAndValidity();

    }
  }

  getBoundTypes() {
    let paraType = { "paraType": "TRA_INS_TYPE" };
    this.agentService.getBoundTypes(paraType).subscribe(result => {
      let arr = [];
      for (let i = 0; i < result.appParamsArray.length; i++) {
        let id = result.appParamsArray[i].code;
        let text = result.appParamsArray[i].desc;

        let object = { id: id, text: text };
        arr.push(object);
      }
      this.modelList = arr;
    })
    this.getCountryList();
    // this.getTravelCount();
    this.setDate();
    this.quoteForm.get('residenceCountry').setValue('002');
    // this.quoteForm.get('boundType').setValue('0');
    //this.quoteForm.get('adultCount').setValue('0');
    // this.quoteForm.get('childCount').setValue('0');
    this.changeInboundTravelInfo();

  }

  getCountryList() {
    let paraType = { "type": "COUNTRY" };
    this.agentService.getCountryList(paraType).subscribe(result => {
      let arr = [];
      for (let i = 0; i < result.appCodesArray.length; i++) {
        let id = result.appCodesArray[i].code;
        let text = result.appCodesArray[i].desc;
        let object = { id: id, text: text };
        arr.push(object);
      }
      this.acountryList = arr;
    })
  }

  getTraveltype() {
    let paraType;
    let insType = this.quoteForm.controls['boundType'].value
    if (insType == '0') {
      paraType = { "paraType": "TRAVEL_TYPE" };
    } else {
      paraType = { "paraType": "TRAVEL_INBOU" };
    }

    this.agentService.getBoundTypes(paraType).subscribe(result => {
      let arr = [];
      for (let i = 0; i < result.appParamsArray.length; i++) {
        if (result.appParamsArray[i].code == '003') {
        } else {
          let id = result.appParamsArray[i].code;
          let text = result.appParamsArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
      }
      this.travelType = arr;
    })
  }
  setDate(): void {
    // Set today date using the patchValue function
    let date = new Date();
    this.quoteForm.patchValue({
      policyStartDate: moment().format('DD/MM/YYYY'),
    });
  }
  setEndDate(): void {
    // Set today date using the patchValue function
    let date = new Date();
    this.quoteForm.patchValue({
      policyEndDate: {
        date: {
          year: date.getFullYear() + 1,
          month: date.getMonth() + 1,
          day: date.getDate() - 1
        }
      }
    });
  }

  tripTypeChanged() {
    let travelId = this.quoteForm.controls['travelType'].value;
    let insType = this.quoteForm.controls['boundType'].value;
    let depDate = this.quoteForm.controls['policyStartDate'].value;
    if (travelId == '001') {
      this.tripId = travelId;
      this.isShowdiv = true;
      this.quoteForm.patchValue({
        totalDays: ''
      });
      this.onDepatureDateChanged(depDate);
    } else if (travelId == '002' && insType == '0') {
      this.tripId = travelId;
      this.isShowdiv = false;
      this.quoteForm.patchValue({
        totalDays: '365',
      });
      this.onStartDateChanged(depDate);
    } else {
      this.tripId = travelId;
      this.isShowdiv = false;
      this.quoteForm.patchValue({
        totalDays: '180',
      });
      this.onDepatureDateChanged(depDate);
    }
  }
  onDepatureDateChanged(event) {
    if (this.tripId == '001' || this.tripId == '003') {
      let timestamp = new Date(event.epoc * 1000).getTime();
      if (event.epoc == undefined) {
        timestamp = new Date().getTime();
      }
    }
    this.changeReturnDate();
  }
  onStartDateChanged(event) {
    let timestamp = new Date(event.epoc * 1000).getTime();
    if (event.epoc == undefined) {
      timestamp = new Date().getTime();
    }
    this.changeReturnDate();
  }

  changeReturnDate() {
    setTimeout(() => {

      let insType = this.quoteForm.controls['boundType'].value;
      let depDate = this.quoteForm.controls['policyStartDate'].value;
      if (depDate) {
        depDate = this.quoteForm.controls['policyStartDate'].value;
        if (this.tripId == '001') {
          if (depDate) {
            // let tempDate = this.depDate.month + '/' + this.depDate.day + '/' + this.depDate.year;
            let time: any;
            if (this.quoteForm.get('totalDays').value == '' || this.quoteForm.get('totalDays').value == undefined || this.quoteForm.get('totalDays').value == null || this.quoteForm.get('totalDays').value <= 0 || this.quoteForm.get('totalDays').value > 90) {
              this.quoteForm.patchValue({
                endDate: ''
              })
            } else {
              time = (86400000 * this.quoteForm.get('totalDays').value) - 86400000;
              let newDate = new Date().getTime();
              let retdate = new Date(newDate + time);
              this.quoteForm.patchValue({
                endDate: [this.appendZero(retdate.getDate()) + '/' + this.appendZero(retdate.getMonth() + 1) + '/' + retdate.getFullYear()]
              })
            }
          }

        } else if (this.tripId == '002' && insType == '0') {
          if (depDate) {
            let tempDate = new Date();
            let time = (86400000 * 365) - 86400000;
            let newDate = new Date(tempDate).getTime();
            let retdate = new Date(newDate + time);
            this.quoteForm.patchValue({
              endDate: [this.appendZero(retdate.getDate()) + '/' + this.appendZero(retdate.getMonth() + 1) + '/' + retdate.getFullYear()]
            })
          }
        } else {
          if (depDate) {
            let numberOfDays = 180;
            let startDate = new Date();
            let returnDate = new Date(
              startDate.getFullYear(),
              startDate.getMonth(),
              startDate.getDate() - 1 + numberOfDays,
            );
            this.quoteForm.patchValue({
              endDate: [this.appendZero(returnDate.getDate()) + '/' + this.appendZero(returnDate.getMonth() + 1) + '/' + returnDate.getFullYear()]
            })
          }
        }

      } else {
        this.quoteForm.patchValue({
          endDate: ''
        })
      }
    }, 100);

  }
  appendZero(temp: any) {
    if (temp < 10) {
      return '0' + temp;
    }
    return temp;
  }


  proceedQuote() {
    if (this.quoteForm.controls['boundType'].value === "1") {
      this.quoteForm.get('civilId').clearValidators();
      this.quoteForm.controls['civilId'].updateValueAndValidity();
    }
    this.noOfAdults = this.quoteForm.controls['adultCount'].value;
    this.noOfChild = this.quoteForm.controls['childCount'].value;
    var covidType = this.quoteForm.controls['insuranceType'].value;
    if (covidType === "1" && this.quoteForm.controls['emailId'].value == null) {
      this.messageService.add({ severity: 'warn', summary: 'Warning Message', detail: 'Please Enter Email Id' });
    } else {
      if (this.noOfAdults == '0') {
        this.showErrMsg = true;
      } else {
        this.showErrMsg = false;
      }
      if (this.quoteForm.valid && this.showErrMsg == false) {

        this.spinnerService.isBusy = true;
        let quoteFrm = this.quoteForm.value;
        let pStart = quoteFrm.policyStartDate;
        this.convertedStartDate = pStart
        const paramForcreateQuote = {
          lobCode: "08",
          portal: this.session.get('portaltype'),
          userId: this.session.get('username'),
          bundleYN: "",
          sourceMkting: "",
          campaignMkting: "",
          ipAddress: this.ip,
          polStartDate: moment(this.convertedStartDate).format('DD/MM/YYYY HH:mm')
        };
        if (this.transId == undefined || this.transId == null) {
          this.agentService.createQuote(paramForcreateQuote).subscribe(result => {
            const respFromCreateQuote = result;
            this.quoteNo = result.quoteNo;
            this.transId = result.transId;
            this.tranSrNo = result.tranSrNo;

            if (result.respCode == 2000) {
              this.updateInsureInfos(result.transId, result.tranSrNo);
            }
          });

        } else {
          this.updateInsureInfos(this.transId, this.tranSrNo);
        }
      }
      else {
        this.validateAllFormFields(this.quoteForm);
        console.error('InvalidForm');
      }
    }

  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warning Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }


  setObjectForTravelInfo(transId, tranSrNo) {
    var insType = this.quoteForm.controls['boundType'].value;
    if (insType == '0') {
      this.paramforTravelInfo = {
        'orgCountry': this.quoteForm.controls['residenceCountry'].value,
        'tripType': this.quoteForm.controls['travelType'].value,
        'daysOfTravel': this.quoteForm.controls['totalDays'].value,
        'noOfAdults': this.quoteForm.controls['adultCount'].value,
        'noOfChild': this.quoteForm.controls['childCount'].value,
        'noOfSeniorCtzns': '0',
        'noOfInfants': '0',
        'tranSrNo': tranSrNo,
        'transId': transId,
        'userId': this.session.get('username'),
        'insuranceType': this.quoteForm.controls['insuranceType'].value
      }
    } else {
      this.paramforTravelInfo = {
        'orgCountry': this.quoteForm.controls['travelFromCountry'].value,
        'destCountry': this.quoteForm.controls['residenceCountry'].value,
        'tripType': this.quoteForm.controls['travelType'].value,
        'daysOfTravel': this.quoteForm.controls['totalDays'].value,
        'noOfAdults': this.quoteForm.controls['adultCount'].value,
        'noOfChild': this.quoteForm.controls['childCount'].value,
        'noOfSeniorCtzns': '0',
        'noOfInfants': '0',
        'tranSrNo': tranSrNo,
        'transId': transId,
        'userId': this.session.get('username'),
        'insuranceType': this.quoteForm.controls['insuranceType'].value
      }

    }
  }


  changeInboundTravelInfo() {
    let insType;
    if (this.transId != undefined || this.transId != null) {
      insType = this.travelBoundType;
    } else {
      insType = this.quoteForm.controls['boundType'].value;
    }
    if (insType == '0') {
      this.isshowboundType = true;
      this.isShowcivil = true;
      this.quoteForm.get('civilId').setValidators([Validators.required, Validators.pattern((/^\d{3}-\d{4}-\d{7}-\d{1}$/))]);
      this.quoteForm.get('passportNo').clearValidators()
      this.quoteForm.get('company').clearValidators()
      this.quoteForm.get('travelFromCountry').clearValidators()
      this.quoteForm.controls['civilId'].updateValueAndValidity();
      this.quoteForm.controls['passportNo'].updateValueAndValidity();
      this.quoteForm.controls['company'].updateValueAndValidity();
      this.quoteForm.controls['travelFromCountry'].updateValueAndValidity();
      this.getTraveltype();
      this.quoteForm.get('travelType').setValue('001');
      this.tripTypeChanged();
    } else {
      this.quoteForm.controls['passportNo'].setValidators([Validators.required]);
      this.quoteForm.controls['travelFromCountry'].setValidators([Validators.required]);
      this.isshowboundType = false;
      this.isShowcivil = true;
      this.isShow = false;
      this.quoteForm.controls['passportNo'].updateValueAndValidity();
      this.quoteForm.get('civilId').clearValidators()
      this.quoteForm.controls['civilId'].updateValueAndValidity();
      this.quoteForm.controls['travelFromCountry'].updateValueAndValidity();
      this.getTraveltype();
      this.quoteForm.get('travelType').setValue('001');
      this.tripTypeChanged();
    }

  }

  getQuote() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getQuotInfo(data).subscribe((result: any) => {
      // this.quoteInfo=result;
      this.quoteForm.patchValue({
        insuredName: result.insName,
        customerType: result.companyYn,
        civilId: result.civilId,
        passportNo: result.civilId,
        sponsor: result.bundleYN,
        mobileNo: result.mobileNo,
        emailId: result.emailId,
        insuranceType: undefined == result.insuranceType ? "0" : "1",
        visaNo: result.refNo,
        boundType: result.inboundYn,
        policyStartDate: {
          date: {
            year: moment(result.polStartDate, 'DD/MM/YYYY HH:mm').year(),
            month: moment(result.polStartDate, 'DD/MM/YYYY HH:mm').month() + 1,
            day: moment(result.polStartDate, 'DD/MM/YYYY HH:mm').date(),
          }
        },

      });
      this.travelBoundType = this.quoteForm.get("boundType").value;
      this.changeInboundTravelInfo();
      this.getTravelQuoteInfo();
    })
  }
  getTravelQuoteInfo() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getQuoteTravelInfo(data).subscribe(result => {
      //this.traveQuoteInfo=result;
      this.quoteForm.patchValue({
        travelType: result.tripType,
        totalDays: result.daysOfTravel,
        adultCount: result.noOfAdults,
        childCount: result.noOfChild,
        travelFromCountry: result.orgCountry,
      })
      this.setCivilText();
      if (result.tripType == '001') {
        this.changeReturnDate()
      } else {
        this.tripTypeChanged();
      }

    })

  }

  updateInsureInfos(transId, tranSrNo) {
    let pStart = moment(this.convertedStartDate).format('DD/MM/YYYY 00:00');
    let pEndDate = moment(this.quoteForm.value.endDate[0], 'DD/MM/YYYY HH:mm').format("DD/MM/YYYY HH:mm");
    const dataToSend = {
      'transId': transId,
      'tranSrNo': tranSrNo,
      'mapId': 'AGENT_TRAVEL_POL_SCR_1',
      'inboundYN': this.quoteForm.controls['boundType'].value,
      'emailId': this.quoteForm.controls['emailId'].value,
      'mobileNo': this.quoteForm.controls['mobileNo'].value,
      'insName': this.quoteForm.controls['insuredName'].value.toUpperCase(),
      'srcType': 'A',
      'modeOfPay': 'CC',
      'agentId': this.agentId,
      'marketingAgent': '',
      'companyYn': this.quoteForm.controls['customerType'].value,
      'facYn': '0',
      'userId': this.session.get('username'),
      'promoCode': this.quoteForm.controls['promoCode'].value,
      'telephoneNo': this.quoteForm.controls['telephoneNo'].value,
      'refNo': '',
      'bundleYN': '',
      'civilId': this.quoteForm.controls['civilId'].value,
      'company': this.quoteForm.controls['company'].value,
      'polStartDate': pStart,
      'polEndDate': pEndDate,
      'insuranceType': this.quoteForm.controls['insuranceType'].value

      // 'customerName':this.quoteForm.controls['customerType'].value
    };
    if (dataToSend.companyYn != '1') {
      dataToSend.civilId = this.quoteForm.controls['civilId'].value
    } else {
      dataToSend.civilId = this.quoteForm.controls['company'].value
    }
    if (dataToSend.insuranceType === "1") {
      let insType = this.quoteForm.controls['boundType'].value
      if (insType == '0') {
        dataToSend.insuranceType = 'TR_OUT_COVID';
      } else {
        dataToSend.insuranceType = 'TR_IN_COVID';
        dataToSend.civilId = this.quoteForm.controls['passportNo'].value;
        dataToSend.bundleYN = this.quoteForm.controls['sponsor'].value;
        dataToSend.refNo = this.quoteForm.controls['visaNo'].value;
      }
    } else {
      if (this.quoteForm.controls['boundType'].value === "1") {
        dataToSend.civilId = this.quoteForm.controls['passportNo'].value;
        dataToSend.bundleYN = this.quoteForm.controls['sponsor'].value;
        dataToSend.refNo = this.quoteForm.controls['visaNo'].value;
      }
      dataToSend.insuranceType = '';
    }
    this.session.set('travelCovid', dataToSend.insuranceType);
    //this.loaderService.isBusy = true;
    this.agentService.updateInsuredInfo(dataToSend).subscribe(result => {
      const respInsuredInfo = result;
      if (result.respCode == 2000) {
        this.setObjectForTravelInfo(transId, tranSrNo);
        this.agentService.updateTravelInfo(this.paramforTravelInfo).subscribe(result => {
          const respTravelInfo = result;
          if (result.respCode == 2000) {
            const strPostData = {
              'transId': transId,
              'tranSrNo': tranSrNo,
              'portal': 'A',
              'userId': this.session.get('username'),
              'lobCode': '08',
              'company': '002'
            }
            this.agentService.calculatePricing(strPostData).subscribe(result => {
              if (result.respCode == 2000) {
                this.router.navigate(['scheme'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'quoteNo': this.quoteNo, 'lobCode': ApplicationConstants.LOB_TRAVEL }, skipLocationChange: true });
              }
            }, error => {
              let errorMsg = error.error.errMessage;
              let obj = {
                "transId": this.transId,
                "tranSrNo": this.tranSrNo,
                "quoteNo": this.quoteNo,
                "errorMsg": errorMsg
              };
              this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

            })
          }
        }, err => {
          throw err
        }

        )
      }
    })

  }

}

