export class AppParamsArray {
	code: string;
	desc: string;
	value: string;
	descAr?: any;
}


