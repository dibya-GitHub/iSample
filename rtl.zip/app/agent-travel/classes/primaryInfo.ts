export class TravelQuotation {
	respCode: number;
	quoteNo: string;
	childData: any;
	errMessage: string;
	tranSrNo: string;
	transId: string;
}


export class TravelInfo {
	company: String;
	transId: String;
	tranSrNo: String;
	userId: String;
	orgCountry: String;
	destCountry: String;
	tripType: String;
	daysOfTravel: String;
	noOfAdults: String;
	noOfInfants: String;
	noOfChild: String;
	noOfSeniorCtzns: String;
	wntrSptsExtYN: String;
	respCode: number;
	errMessage: String;
	destCountryDesc: String;
	tripTypeDesc: String;
	teritorialLimit: String;
	boundType: String;
	portal: String;
	lobCode: String;
	adultdata: Array<TravellerDetails>
	childData: Array<TravellerDetails>
}

export class TravelQuoteInfo {

	insName: string;
	insNameAr?: string;
	mobileNo: string;
	civilId: string;
	insuranceType: string;
	poBox: string;
	emailId: string;
	address: string;
	polStartDate;
	polEndDate;
	nationality: string;
	companyYn: string
	city: String;
	transRemark: String;
	vatRefNo: any;
	occupationtype: any;
	covernoteno: any;
	taxRefNo: any;
	coverNoteNumber: any;
}

export class TravellerDetails {
	trvlrName: String;
	relation: string;
	gender: String;
	dob: any;
	trvlrAge;
	passptNo: String;
	wntrSptsExtYN: String;
	transId: String;
	tranSrNo: String;
	srNo: String;
	nationality: String;
	category: String;
	userId: String;
	adultYN: String;
}