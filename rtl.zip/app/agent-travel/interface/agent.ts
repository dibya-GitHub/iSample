
import { AppParamsArray } from '../classes/travel';
export interface BoundType {
	appParamsArray: Array<AppParamsArray>;
	respCode: string;
	errMessage: string;
}
export interface Customer {
	custId: number;
	custType: string;
}
export interface CountryList {
	appCodesArray: Array<AppParamsArray>;
	respCode: string;
	errMessage: string;
}


