import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { Search } from 'src/shared/classes/search';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-policy-history',
  templateUrl: './policy-history.component.html',
  styleUrls: ['./policy-history.component.scss']
})
export class PolicyHistoryComponent implements OnInit {
  selTransId;
  selTranSrNo;
  policyNo;
  policyHistoryList;
  customerInfo: any;
  vehicleInfo: any;
  coversDetails: any;
  travelInfo: any;
  travelersDetails: any;
  homeInfo: any;
  homeDetails: any;
  otherDed: any;
  otherFees: any;
  otherLoad: any;
  otherTax: any;
  otherDisc: any;
  summaryInfo: any;
  customerInfo1: any;
  vehicleInfo1: any;
  coversDetails1: any;
  travelInfo1: any;
  travelersDetails1: any;
  homeInfo1: any;
  homeDetails1: any;
  otherDed1: any;
  otherFees1: any;
  otherLoad1: any;
  otherDisc1: any;
  otherTax1: any;
  summaryInfo1: any;
  policyInfo
  documentType = [];
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  showContent: any;
  lobCode: any;
  documentList: any;
  filteredList: any[] = [];
  transType: any;
  endMotPrintList = [
    new Search('POL_CN', 'Broker Debit/Credit Note'),
    new Search('POL_DN', 'Policy Debit/Credit/Receipts'),
    new Search('POL_SCH', 'Motor Policy Schedule'),
  ];
  prodCode: any;
  schCode: any;
  lobType: any;
  divnCode: any;
  
  constructor(
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
  ) { }

  ngOnInit() {
    var transId = this.commonService.getParamValue('transId');
    let params = { "transId": transId };
    this.agentService.getPolicyHistory(params)
      .subscribe(result => {
        this.policyHistoryList = result.policyList
      });
  }

  getDocumentList() {
    let param = { "lobCode": this.lobCode, "docType": this.transType, "divnCode": this.divnCode, "productCode": this.prodCode, "schemes": this.schCode }
    this.agentService.getDocumentList(param)
      .subscribe(result => {
        this.documentList = result.documentList;
        var array = this.documentList;
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].key == 'POL_DN' || array[i].key == 'POL_CN' || array[i].key == 'POL_SCH') {
            this.filteredList.push(array[i]);
          }
        }
      });
  }

  getPolicyDetails(policy, policyDiv) {
    var params = { "transId": policy.transId, "tranSrNo": policy.tranSrNo, "lobCode": policy.lobCode };
    this.lobCode = policy.lobCode;
    policyDiv.style.display = "block";
    this.getContentdetails(policy.transId, policy.tranSrNo);

    this.agentService.viewPolicyDetails(params)
      .subscribe(result => {
        this.otherDed = result.otherDed.othersArray;
        this.otherDisc = result.otherDisc.othersArray;
        this.otherFees = result.otherFees.othersArray;
        this.otherLoad = result.otherLoad.othersArray;
        this.otherTax = result.otherTax.othersArray;

        this.coversDetails = result.coversDetails;
        this.customerInfo = result.customerInfo;
        this.vehicleInfo = result.vehicleInfo;
        this.travelInfo = result.travelInfo;
        this.travelersDetails = result.travelersDetails;
        this.homeInfo = result.homeInfo;
        this.homeDetails = result.homeDetails;
        this.summaryInfo = result.summaryInfo
        this.prodCode = result.customerInfo.prodCode;
        this.schCode = result.customerInfo.prodCode;
        this.lobType = result.customerInfo.lobCode;
        this.divnCode = result.customerInfo.divnCode

      });
    var params1;
    if (parseInt(policy.tranSrNo) == 1) {
      params1 = { "transId": policy.transId, "tranSrNo": parseInt(policy.tranSrNo) - 1, "lobCode": policy.lobCode };
    } else
      params1 = { "transId": policy.transId, "tranSrNo": parseInt(policy.tranSrNo) + 1, "lobCode": policy.lobCode };
    policyDiv.style.display = "block";
    this.agentService.viewPolicyDetails(params1)
      .subscribe(result => {
        this.otherDed1 = result.otherDed.othersArray;
        this.otherDisc1 = result.otherDisc.othersArray;
        this.otherFees1 = result.otherFees.othersArray;
        this.otherLoad1 = result.otherLoad.othersArray;
        this.otherTax1 = result.otherTax.othersArray;

        this.coversDetails1 = result.coversDetails;
        this.customerInfo1 = result.customerInfo;
        this.vehicleInfo1 = result.vehicleInfo;
        this.travelInfo1 = result.travelInfo;
        this.travelersDetails1 = result.travelersDetails;
        this.homeInfo1 = result.homeInfo;
        this.homeDetails1 = result.homeDetails;
        this.summaryInfo1 = result.summaryInfo
        this.prodCode = result.customerInfo1.prodCode;
        this.schCode = result.customerInfo1.prodCode;
        this.lobType = result.customerInfo1lobCode;
        this.divnCode = result.customerInfo1.divnCode
        this.getDocumentList();

      }, error => {
        this.coversDetails1 = null;
        this.customerInfo1 = null;
        this.vehicleInfo1 = null;
        this.travelInfo1 = null;
        this.travelersDetails1 = null;
        this.homeInfo1 = null;
        this.homeDetails1 = null;
        this.summaryInfo1 = null
      });
  }
  getContentdetails(transId, tranSrNo) {
    let editparam = {
      "transId": transId,
      "tranSrNo": tranSrNo,
    };
    this.agentService.getPolicyContentDetls(editparam).subscribe(response => {
      this.showContent = response.contentPolicyDetails;
    },
      error => {
      });
  }

  openDocumentsList(myModel, custName) {
    myModel.className = 'modal show';
    this.selTransId = custName.transId;
    this.selTranSrNo = custName.tranSrNo;
    this.transType = custName.srcType;
    this.getDocumentList();


  }
  closemodel(myModel) {
    myModel.className = 'modal hide';
  }

  printDocument() {
    for (var i = 0; i < this.documentType.length; i++) {
      this.getReport(this.documentType[i])
    }
  }

  getReport(reportType) {
    this.commonService.getReportDocs(this.selTransId, this.selTranSrNo, reportType, this.policyNo, this.transType);
  }

  checkdocumentType(event) {
    if (event.target.checked) {
      this.documentType.push(event.target.value);
    } else {
      this.documentType.splice(this.documentType.indexOf(event.target.value), 1);
    }
  }
}
