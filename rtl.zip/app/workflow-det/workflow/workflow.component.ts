import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentHttpclientService } from 'src/app/services/agent-httpclient.service';
import { ApplicationConstants } from 'src/shared/application-constants';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';

@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styleUrls: ['./workflow.component.scss']
})
export class WorkflowComponent implements OnInit {
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  quoteNo: any;
  tcReqDate: any;
  transactionType: any;
  requiredBy: any;
  transactionRemarks: any;
  requestedOn: any;
  type: any;
  requestReason: any;
  tcRefId: any;
  tcRefSrNo: any;
  transId: any;
  tranSrNo: any;
  tranRemarks: any;
  canShowTransDetails = false;
  showhowRateInfo = false;
  policyAddlInfo: any;
  coverList: any;
  deductList: any;
  taxFlag: any;
  errorMsg: any;
  showApproveBtn = false;
  showWfApproveBtn = false;

  constructor(private agentService: AgentHttpclientService,
    private commonService: AgentUserService, private router: Router,
    public loaderService: LoaderService,
    private session: SessionStorageService) { }

  ngOnInit() {
    this.taxFlag = false;
    var transId = this.commonService.getParamValue('transId');
    var tranSrNo = this.commonService.getParamValue('tranSrNo');
    var params = { "transId": transId, "tranSrNo": tranSrNo };
    this.agentService.getPolicyReqDetails(params)
      .subscribe(result => {
        this.tcRefId = result.tcRefId;
        this.tcRefSrNo = result.tcRefSrNo;
        this.transId = result.transId;
        this.tranSrNo = result.tranSrNo;
        this.quoteNo = result.quoteNo;
        this.transactionType = result.transactionType;
        this.requestReason = result.requestReason;
        this.requestedOn = result.requestedOn;
        this.requiredBy = result.requiredBy;
        this.transactionRemarks = result.transactionRemarks;
        this.tranRemarks = result.tranRemarks;
        this.type = result.type;
        if ("POL" === result.transType || "REN" === result.transType || ApplicationConstants.ENDORSE_TYPE_CANCELLATION === result.endType
          || ApplicationConstants.ENDORSE_TYPE_REINST === result.endType)
          this.showhowRateInfo = true;
        if (result.endType !== '' && result.endType !== null && result.endType !== 'null' && result.endType !== undefined)
          $("#reqTitle").html("Endorsement Approval Request");
        if ("01" === result.lobCode && "1" === result.activeWf) {
          this.showApproveBtn = false;
          this.showWfApproveBtn = true;
        } else {
          this.showApproveBtn = true;
          this.showWfApproveBtn = false;
        }
      });
    this.loaderService.isBusy = false;
  }

  submitForm(flag: String) {
    if ("Close" == flag) {
      window.close();
    } else if ("Details" == flag) {
      this.loaderService.isBusy = true;
      let detailParams = {
        transId: this.transId,
        tranSrNo: this.tranSrNo
      };
      this.agentService.getPendingTranPolicyDetails(detailParams)
        .subscribe(
          result => {
            this.policyAddlInfo = result.polInfo;
            console.log(this.policyAddlInfo)
            this.coverList = result.coverList;
            this.deductList = result.deductList;
            this.taxFlag = result.taxApplFlag;
          },

          err => {
          });
      this.loaderService.isBusy = false;
      this.canShowTransDetails = true;
    } else if ("finalApprove" == flag) {
      this.loaderService.isBusy = true;
      let path = window.opener.location.pathname.substr(0, window.opener.location.pathname.lastIndexOf('/'));
      window.opener.location = path + "/workflow-addlInfo?transId=" + this.transId + "&tranSrNo=" + this.tranSrNo + "&quoteNo=" + this.quoteNo;
      window.close();
    } else {
      this.loaderService.isBusy = true;
      let passingParams = { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'tcRefId': this.tcRefId, 'tcRefSrNo': this.tcRefSrNo, 'qicFlag': flag, 'userId': this.session.get('username'), 'tcRemarks': $("#remarks").val() }
      this.agentService.approveWorkflowRequest(passingParams).subscribe(result => {
        if (result.respCode == 2000) {
          window.opener.location.reload();
          this.loaderService.isBusy = false;
          window.close();
        }
      }, error => {
        this.loaderService.isBusy = false;
        let param = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo,
          "errMessage": error.error.errMessage
        };
        this.agentService.insertErrorMsg(param).subscribe(response => {
          this.errorMsg = param.errMessage;
          $("#workflow-div").hide();
          $("#workflowErrdiv").show();
        });
      });
    }
  }

  loadUploadedDocs() {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=1000,height=400,left=100%,top=100%`;
    var winRef = window.open('viewdocument?transId=' + this.transId + '&page=workflow-dash', 'Pending Quote Docs', param);
  }
}