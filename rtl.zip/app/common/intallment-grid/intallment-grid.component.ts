import { Component, Inject, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { AgentUserService } from "../../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../../services/agent-httpclient.service';

@Component({
  selector: 'app-intallment-grid',
  templateUrl: './intallment-grid.component.html',
  styleUrls: ['./intallment-grid.component.scss']
})
export class IntallmentGridComponent implements OnInit {

  public installAccess: string = this.session.get("installAccess");
  public installmentList: Array<any>;
  transId: string;
  tranSrNo: number;
  constructor(private session: SessionStorageService,
    private agentService: AgentHttpclientService, private commonService: AgentUserService) { }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    if ('1' === this.installAccess) {
      let obj = {
        transId: this.commonService.getParamValue('transId'),
        tranSrNo: this.commonService.getParamValue('tranSrNo')
      };
      this.agentService.displayInstallment(obj).subscribe(response => {
        this.installmentList = response.list;
      })
    }
  }
  updateInstallmentNo(installNo: string, event) {
    let paidStatus = '0';
    if (event.target.checked) {
      paidStatus = '1'
    } else {
      paidStatus = '0'
    }
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      instNo: installNo,
      paidStatus: paidStatus
    };
    this.agentService.updateInstallmentNo(obj).subscribe(res => {

    });
  }
}
