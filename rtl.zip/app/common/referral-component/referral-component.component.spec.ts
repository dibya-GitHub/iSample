import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferralComponentComponent } from './referral-component.component';

describe('ReferralComponentComponent', () => {
  let component: ReferralComponentComponent;
  let fixture: ComponentFixture<ReferralComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReferralComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferralComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
