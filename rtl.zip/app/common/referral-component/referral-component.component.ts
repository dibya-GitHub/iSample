import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AgentUserService } from "../../../shared/services/agent-user.service";

@Component({
  selector: 'app-referral-component',
  templateUrl: './referral-component.component.html',
  styleUrls: ['./referral-component.component.scss']
})
export class ReferralComponentComponent implements OnInit {
  transId: string;
  tranSrNo: string;
  quoteNo: string;
  errorMsg: string;
  lobCode: string;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  constructor(
    private agentService: AgentUserService,
    private router: Router) { }

  ngOnInit() {
    this.transId = this.agentService.getParamValue('transId');//this.route.snapshot.paramMap.get('transId')//"1397780"//"1397225";
    this.tranSrNo = this.agentService.getParamValue('tranSrNo');
    this.quoteNo = this.agentService.getParamValue('quoteNo');
    this.errorMsg = this.agentService.getParamValue('errMessage');
    this.getQuoteInformation();
  }

  getQuoteInformation() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      mapId: 'AGENT_HOME_POL_SCR_1'
    }
    let date = new Date();
    this.agentService.getQuoteInformation(postData).subscribe((quoteInfo: any) => {
      this.lobCode = quoteInfo.lobCode
    }, error => {

    });
  }


}
