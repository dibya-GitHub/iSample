import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReloadAdditionalChargesComponent } from './reload-additional-charges.component';

describe('ReloadAdditionalChargesComponent', () => {
  let component: ReloadAdditionalChargesComponent;
  let fixture: ComponentFixture<ReloadAdditionalChargesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReloadAdditionalChargesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReloadAdditionalChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
