import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { ReloadCharges } from '../../../shared/classes/scheme';
import { AgentUserService } from "../../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../../services/agent-httpclient.service';

@Component({
  selector: 'app-reload-additional-charges',
  templateUrl: './reload-additional-charges.component.html',
  styleUrls: ['./reload-additional-charges.component.scss']
})
export class ReloadAdditionalChargesComponent implements OnInit {
  showTab: boolean = false;
  reloadAddlCharges: UntypedFormGroup;
  reloadList: UntypedFormArray;
  otherInfo: ReloadCharges;
  otherArry: any;
  discriptionList: any[] = [];
  companyCode: string = this.session.get("companyCode");
  transId: string;
  tranSrNo: number;
  schCode: string;
  prodCode: string;
  endType: string;
  @Input() agentAuthDetails: any[] = [];
  @Input() netPremium: any;

  selected_Desc: string;
  selectedDesCode: string;
  public mode: string;
  public isDetEnable: boolean = false;
  public isDisEnable: boolean = false;
  public isLoadEnable: boolean = false;
  public isFeeEnable: boolean = false;
  public deleteValue: number = 0;

  groupCode: string = this.session.get("groupCode");
  userFilter: any = this.session.get("userFilter");

  agentCode: string = this.session.get("agent");
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  years = ['1', '2', '3', '4', '5'];
  constructor(
    private fb: UntypedFormBuilder,
    private session: SessionStorageService,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private router: Router,
    private loaderService: LoaderService,
    private messageService: MessageService) {
    this.reloadAddlCharges = this.fb.group({
      reloadList: this.fb.array([])
    })

  }
  addNewRow(status): void {
    this.reloadList = this.reloadAddlCharges.get('reloadList') as UntypedFormArray;
    if ('add' == status) {
      this.mode = 'add';
      var arrayLength = this.reloadList.length - 2;
      // this.saveRow(arrayLength,'INS');
      // this.createItem();
      this.reloadList.push(this.createItem());

    } else {
      // this.editItem();
      this.reloadList.push(this.editItem());
    }
    this.showTab = true;
  }
  createItem(): UntypedFormGroup {
    return this.fb.group({
      type: '',
      description: '',
      rate: [undefined],
      value: '',
      selectedDesc: '',
      mode: 'add',
      typeDesc: ''
    });
  }

  editItem(): UntypedFormGroup {
    return this.fb.group({
      type: '',
      description: '',
      rate: [undefined],
      value: '',
      selectedDesc: '',
      mode: 'edit',
      typeDesc: ''
    });
  }

  saveRow(index, mode) {
    var arrayControl = this.reloadAddlCharges.get('reloadList') as UntypedFormArray;
    var item = arrayControl.at(index).value;
    let obj = {
      'mode': mode,
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'refCode': this.selectedDesCode,
      'desc': this.selected_Desc,
      'rate': item.rate,
      'value': item.value,
      'type': item.type,
      'userId': this.session.get("username")
    };
    this.agentService.insertQuoteOtherInfo(obj).subscribe((response: any) => {
      arrayControl.controls[index].get('mode').setValue('edit');
      let typeDesc;
      switch (item.type) {
        case 'DED':
          typeDesc = 'Deductibles'; break;
        case 'LOAD':
          typeDesc = 'Loadings'; break;
        case 'DISC':
          typeDesc = 'Discounts'; break;
        case 'FEES':
          typeDesc = 'Fees'; break;
      }
      arrayControl.at(index).patchValue({
        selectedDesc: this.selected_Desc,
        typeDesc: typeDesc
      });
      this.messageService.add({ severity: 'success', summary: 'Saved Successfully' });

    }, error => {
      this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Error in Save' });
    });

  }

  deleteRow(index) {
    this.reloadList = this.reloadAddlCharges.get('reloadList') as UntypedFormArray;
    var item = this.reloadList.at(index).value;
    var type = '';
    var code: any = item.description.split('_');
    if ('Deductibles' == item.typeDesc) {
      type = "DED";
    } else if ('Loadings' == item.typeDesc) {
      type = "LOAD";
    } else if ('Discounts' == item.typeDesc) {
      type = "DISC";
    } else if ('Fees' == item.typeDesc) {
      type = "FEES";
    }
    let obj = {
      'mode': 'DEL',
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'refCode': code[0],
      'type': type

    }
    this.agentService.insertQuoteOtherInfo(obj).subscribe(response => {
      this.reloadList.removeAt(index);
      if (this.reloadList.length == 0) {
        this.showTab = false
      }
      this.messageService.add({ severity: 'success', summary: 'Deleted Successfully' });

      //  this.getAddtionalCharges();
    }, error => {
      this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Error in Delete' });
    });

  }

  updateRow(index, mode) {
    var arrayControl = this.reloadAddlCharges.get('reloadList') as UntypedFormArray;
    var item = arrayControl.at(index).value;
    var code: any = item.description.split('_');
    var type = '';
    if ('Deductables' == item.type) {
      type = "DED";
    } else if ('Loading' == item.type) {
      type = "LOAD";
    } else if ('Discounts' == item.type) {
      type = "DISC";
    } else if ('Fees' == item.type) {
      type = "FEES";
    }
    let obj = {
      'mode': mode,
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'refCode': code[0],
      'rate': item.rate,
      'value': item.value,
      'type': type,
      'userId': this.session.get("username")

    }
    this.agentService.insertQuoteOtherInfo(obj).subscribe(response => {
      this.messageService.add({ severity: 'success', summary: 'Updated Successfully' });
    }, error => {
      this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Error in Update' });
    });
  }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.schCode = this.commonService.getParamValue('schCode');
    this.prodCode = this.commonService.getParamValue('prodCode');
    this.endType = this.commonService.getParamValue('endType');
    // this.transId='643159';
    // this.tranSrNo=0;
    this.getAddtionalCharges();
    this.getAgentAuthDtls();
    if (this.prodCode == undefined) {
      const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
      this.agentService.getQuotInfo(data).subscribe((result: any) => {
        if (result != null && result != undefined) {
          this.prodCode = result.prodCode;
          this.schCode = result.schCode;
        }
      });
    }

  }
  getAddtionalCharges() {
    let obj = {
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'endType': ''
    };
    this.agentService.getAddtionalOtherInfo(obj).subscribe(response => {
      this.mode = 'edit';
      this.otherArry = response.additionalInfo;
      for (var i = 0; i < this.otherArry.length; i++) {
        const index = i;
        const item = this.otherArry[index];
        let typeDesc;
        switch (item.type) {
          case 'DED':
            typeDesc = 'Deductibles'; break;
          case 'LOAD':
            typeDesc = 'Loadings'; break;
          case 'DISC':
            typeDesc = 'Discounts'; break;
          case 'FEES':
            typeDesc = 'Fees'; break;
        }
        this.otherArry[index].typeDesc = typeDesc;
        this.addNewRow('edit');
      }
      this.setDefaultValues();

    });
  }

  setDefaultValues() {
    for (var i = 0; i < this.otherArry.length; i++) {
      this.otherInfo = new ReloadCharges();
      let index = i;
      this.otherInfo = this.otherArry[i];
      if ('DED' == this.otherInfo.type) {
        this.otherInfo.type = "Deductables";
      } else if ('LOAD' == this.otherInfo.type) {
        this.otherInfo.type = "Loading";
      } else if ('DISC' == this.otherInfo.type) {
        this.otherInfo.type = "DISC";
      } else if ('FEES' == this.otherInfo.type) {
        this.otherInfo.type = "Fees";
      }
      const controlArray = <UntypedFormArray>this.reloadAddlCharges.get('reloadList');

      controlArray.controls[index].patchValue({
        type: this.otherInfo.type,
        selectedDesc: this.otherInfo.selectedDesc,
        description: this.otherInfo.description,
        rate: this.otherInfo.rate,
        value: this.otherInfo.optionalValue,
        typeDesc: this.otherInfo.typeDesc
      });
      controlArray.controls[index].get('type').setValue(this.otherInfo.type);
      controlArray.controls[index].get('selectedDesc').setValue(this.otherInfo.selectedDesc);
      controlArray.controls[index].get('description').setValue(this.otherInfo.description);
      controlArray.controls[index].get('rate').setValue(this.otherInfo.rate);
      controlArray.controls[index].get('value').setValue(this.otherInfo.optionalValue);
    }
    this.loaderService.isBusy = false;
  }
  getDiscriptionList(event, index) {
    this.loaderService.isBusy = true;
    // let selectedDesc = event.target['options']
    // [event.target['options'].selectedIndex].text;
    let obj = {
      'type': event.target.value,
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'prodCode': this.prodCode,
      'schCode': this.schCode

      // 'type':event.target.value,
      // 'transId':'643159',
      // 'tranSrNo':'0',
      // 'prodCode':'0110',
      // 'schCode':'0152'
    };
    this.agentService.getDiscriptionList(obj).subscribe(response => {
      this.discriptionList[index] = response.discriptionList;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  // updateValue(val:string){
  //   var arr=val.split(',');
  //   this.reloadList.patchValue({rate: arr[0],value:arr[1]
  //    });
  // }


  public updateValue(event, index) {
    let val = event.target.value;
    this.selected_Desc = event.target['options']
    [event.target['options'].selectedIndex].text;
    var arr = val.split('_');
    this.selectedDesCode = arr[0];
    const controlArray = <UntypedFormArray>this.reloadAddlCharges.get('reloadList');
    controlArray.controls[index].get('rate').setValue(0);
    controlArray.controls[index].get('value').setValue(0);
  }

  updateDiscount(event, index) {
    let val = event.target.value;
    var arr = val.split('_');
    this.selectedDesCode = arr[0];
    const controlArray = <UntypedFormArray>this.reloadAddlCharges.get('reloadList');
    if (controlArray.controls[index].get('type').value == 'DISC') {
      controlArray.controls[index].get('value').setValue((this.netPremium * (arr[0] / 100)).toFixed(2));
    } else {
      controlArray.controls[index].get('value').setValue(0);
    }
  }
  updateRates(event, index) {
    let val = event.target.value;
    var arr = val.split('_');
    this.selectedDesCode = arr[0];
    const controlArray = <UntypedFormArray>this.reloadAddlCharges.get('reloadList');
    if (controlArray.controls[index].get('type').value == 'DISC') {
      controlArray.controls[index].get('rate').setValue(((arr[0] / this.netPremium) * 100).toFixed(2));
    }
  }
  getAgentAuthDtls() {
    let param = {
      "groupCode": this.userFilter.CUST_GROUP_CODE,
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "agentCode": this.agentCode
    };
    this.agentService.getAgentAuthDtls(param)
      .subscribe(result => {
        this.agentAuthDetails = result;
        if (result.DED_ENABLE == "1")
          this.isDetEnable = true;
        if (result.DISC_ENABLE == '1')
          this.isDisEnable = true;
        if (result.LOAD_ENABLE == "1")
          this.isLoadEnable = true;
        if (result.FEES_ENABLE == "1")
          this.isFeeEnable = true
      }, error => {
      })
  }
}
/////  if(("DED".equals(scheme.getType()) && isDetEnable ) || ("LOAD".equals(scheme.getType()) && isLoadEnable)
//|| ("DISC".equals(scheme.getType()) && isDiscEnable) || ("FEES".equals(scheme.getType()) && isFeesEnable)){

