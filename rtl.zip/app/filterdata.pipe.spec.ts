import { FilterdataPipe } from './filterdata.pipe';

describe('FilterdataPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterdataPipe();
    expect(pipe).toBeTruthy();
  });
});
