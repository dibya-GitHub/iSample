import { Component, Input, OnInit } from '@angular/core';
import * as moment from 'moment';


@Component({
  selector: 'app-progress-bar',
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.Scss']
})
export class ProgressBarComponent implements OnInit {
  //startDateShow: string;
  //endDateShow: string;
  renewDateShow: string;
  numberOfdays: number;
  todayDate = new Date();
  constructor() { }
  @Input('startDate') startDateShow: string;
  set startDate(startDate: string) {
    this.startDateShow = startDate;
  }
  @Input('endDate') endDateShow: string;
  set endDate(endDate: string) {
    this.endDateShow = endDate;
  }
  // appUtilObj: AppUtil = new AppUtil();
  ngOnChanges(changes) {
    this.changed()

    let getstartDate = this.startDateShow;
    let startDate = moment(getstartDate, "DD/MM/YYYY HH:mm").toISOString();
    // let startDate = moment(getstartDate)
    // this.startDateShow = getstartDate;
    let getEndDate = this.endDateShow;
    let endDate = moment(getEndDate, "DD/MM/YYYY HH:mm").toISOString();
    // this.endDateShow = moment(getEndDate);

    let renew = new Date(endDate).getTime() - new Date(startDate).getTime();
    let aa = (renew * 30) / 100;
    this.numberOfdays =
      (new Date(endDate).getTime() - new Date(startDate).getTime()) /
      (1000 * 60 * 60 * 24);
    let getRenewalday: number = Math.round(this.numberOfdays - 90);

    let getRenewDate =
      new Date(startDate).getTime() + getRenewalday * 1000 * 60 * 60 * 24;
    let renewDate = new Date(getRenewDate);
    this.renewDateShow = this.GetFormattedDate(renewDate);
    // this.policyTenureStatus(startDate);
  }

  public changed() {

  }

  ngOnInit() {
    this.ngOnChanges;
  }

  GetFormattedDate(date) {
    let todayTime = new Date();
    let month = ("0" + (date.getMonth() + 1)).slice(-2);
    let day = date.getDate();
    let year = date.getFullYear();
    return day + "/" + month + "/" + year;
  }

  policyTenureStatus(startdate) {
    //let todayDate = new Date("2018-09-18T09:00:00");
    let todayDate = new Date(this.todayDate);
    let completedDays: number = ((todayDate.getTime() - startdate.getTime()) / (1000 * 60 * 60 * 24));
    let onePercent: number = (this.numberOfdays * 1) / 100;
    let totalCompletedDuration: number = Math.round(completedDays / onePercent);

    if (totalCompletedDuration < 0) {

    } else {
      let moveSmiley = totalCompletedDuration * .53;

      if (moveSmiley < 26) {
        let el = <HTMLElement>document.querySelector(".moversmiley");
        let smiley: number = 22.3 + moveSmiley;
        el.style.left = smiley + '%';
      } else {
        let el = <HTMLElement>document.querySelector(".moversmiley");
        let smileygreater: number = 22.3 + moveSmiley;
        el.style.left = smileygreater + '%';

      }
    }
  }

  changeStartDate() {
    let getstart = '2017-09-18T09:00:00';

    let startDate = new Date(getstart);
    this.policyTenureStatus(startDate);
  }
}
