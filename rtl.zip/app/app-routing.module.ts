import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdditionalHomeInfoComponent } from './home/additional-home-info/additional-home-info.component';
import { HomeComponent } from './home/home.component';
//import { UserLoginComponent } from './user-login/user-login.component';
import { SchemePlansComponent } from './scheme-plans/scheme-plans.component';
import { ConfirmQuoteComponent } from './confirm-quote/confirm-quote.component';
import { ViewDocumentComponent } from './view-document/view-document.component';
import { ViewPolicyComponent } from './view-policy/view-policy.component';
import { RouterModule, Routes } from '@angular/router';
import { EndorsementsComponent } from './endorsements/endorsements.component';
import { AgentDashboardComponent } from 'src/app/agent-dashboard/agent-dashboard.component';
import { NonFinancialEndorsementComponent } from './non-financial-endorsement/non-financial-endorsement.component';
import { PrimaryMotorInfoComponent } from './motor-insurance/primary-motor-info/primary-motor-info.component';
import { AdditionalInfoScreenComponent } from './motor-insurance/additional-info-screen/additional-info-screen.component';
import { ReferralComponentComponent } from './common/referral-component/referral-component.component';
import { AgentTravelComponent } from 'src/app/agent-travel/agent-travel.component';
import { AddTravelInfoComponent } from 'src/app/add-travel-info/add-travel-info.component';
import { PolicyCancelationEndorsmentComponent } from 'src/app/policy-cancelation-endorsment/policy-cancelation-endorsment.component';
import { AgentLoginComponent } from './agent-login/agent-login/agent-login.component';
import { MarineLoginComponent } from './agent-login/marine-login/marine-login.component';
import { ForgotPasswordComponent } from './agent-login/forgot-password/forgot-password.component';
import { FirstScreenMotorComponent } from './motor-insurance/first-screen-motor/first-screen-motor.component';
import { ViewClaimComponent } from 'src/app/view-claim/view-claim.component';
import { PolicyHistoryComponent } from './policy-history/policy-history.component';
import { EndorsementApproveComponent } from './endorsement-approve/endorsement-approve.component';
import { AddCoverEndorsmentComponent } from 'src/app/add-cover-endorsment/add-cover-endorsment.component';
import { SummaryInfoComponent } from './summary-info/summary-info.component';
import { AddCoverSummaryEndComponent } from 'src/app/add-cover-summary-end/add-cover-summary-end.component';
import { AddCoverConfirmEndComponent } from 'src/app/add-cover-confirm-end/add-cover-confirm-end.component';
import { PremiumAdjustmentEndorsementComponent } from './premium-si-adjustment-endorsement/premium-si-adjustment-endorsement.component';
import { AdditionalSiAdjustmentEndorsementComponent } from './additional-discounts-si-adjustment-endorsement/additional-discounts-si-adjustment-endorsement.component';
import { PremiumSiAdjustmentEndorsementSummary } from './premium-si-endorsement-summary/premium-si-endorsement-summary.component';
import { ExtensionPolicyEndorsementComponent } from './extension-policy/extension-policy-endorsement.component';
import { AdditionalExtensionEndorsementComponent } from './additional-extension-endorsement/additional-extension-endorsement.component';
import { ExtensionSummaryEndorsement } from './extension-summary-endorsement/extension-summary-endorsement.component';
import { PolicyCancelSummEndComponent } from 'src/app/policy-cancel-summ-end/policy-cancel-summ-end.component';
import { CertificateEndorsementComponent } from './certificate-endorsement/certificate-endorsement/certificate-endorsement.component';
import { FleetCertificateProceedComponent } from './fleet-certificate-proceed/fleet-certificate-proceed.component';
import { ChangeInVehParamEndorsementComponent } from './change-in-vehicleParameter-end/change-in-veh-param-endorsement/change-in-veh-param-endorsement.component';
import { ChangeOwnershipComponent } from './change-ownership-endorsement/change-ownership-endorsement.component';
import { SessionTimeoutComponent } from 'src/app/session-timeout/session-timeout.component';
import { PolicyThankYouComponent } from './policy-thank-you/policy-thank-you.component';
import { QuoteDashboardComponent } from './quote-dashboard/quote-dashboard.component';
import { PolicyRenewalDashboardComponent } from './policy-renewal-dashboard/policy-renewal-dashboard.component';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { EndorsmentApprovalComponent } from './endorsment-approval/endorsment-approval.component';
import { PCraftBasicInfoComponent } from './pleasure-craft/p-craft-basic-info/p-craft-basic-info.component';
import { PCraftAdditionalInfo } from 'src/app/pleasure-craft/p-craft-additional-info/p-craft-additional-info.component';
import { MarineInfoComponent } from './marine-insurance/marine-info/marine-info.component';
import { MarineCreateCertificateComponent } from './marine-insurance/marine-create-certificate/marine-create-certificate.component';
import { MarineAddlInfoComponent } from './marine-insurance/marine-addl-info/marine-addl-info.component';
import { MarineUploadInfoComponent } from './marine-insurance/marine-upload-info/marine-upload-info.component';
import { IntimateClaimsComponent } from './claim-intimation/intimate-claims/intimate-claims.component';
import { ReportClaimComponent } from './Qic-Claims/report-claim/report-claim.component';
import { TpClaimComponent } from './NonQic-Claims/tp-claim/tp-claim.component';
import { FindActivePolicyComponent } from './find-active-policy/find-active-policy.component';
import { SubmitClaimComponent } from './submit-claim/submit-claim.component';
import { UploadClaimsDocumentsComponent } from './ClaimsUpload/upload-claims-documents/upload-claims-documents.component';
import { ClaimsThankyouComponent } from './claims-thankyou/claims-thankyou.component';
import { WorkflowComponent } from './workflow-det/workflow/workflow.component';
import { WorkflowAddlInfoScreenComponent } from './workflow-addl-info-screen/workflow-addl-info-screen.component';

const appRoutes: Routes = [
  {
    path: '',
    component: AgentLoginComponent
  },
  {
    path: 'login',
    pathMatch: 'full',
    component: AgentLoginComponent
  },
  {
    path: 'marine-login',
    pathMatch: 'full',
    component: MarineLoginComponent
  },
  {
    path: 'scheme',
    component: SchemePlansComponent
  },
  {
    path: 'agentdashboard',
    component: AgentDashboardComponent
  },
  {
    path: 'motor',
    component: PrimaryMotorInfoComponent
  },
  {
    path: 'firstScreenMotor',
    component: FirstScreenMotorComponent
  },
  {
    path: 'motoraddlinfo',
    component: AdditionalInfoScreenComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'travel',
    component: AgentTravelComponent
  },
  {
    path: 'viewdocument',
    component: ViewDocumentComponent
  },
  {
    path: 'endorsements',
    component: EndorsementsComponent
  },
  {
    path: 'nonfinancialendt',
    component: NonFinancialEndorsementComponent
  },
  {
    path: 'changeownershipendt',
    component: ChangeOwnershipComponent
  },
  {
    path: 'quoteconfirm',
    component: ConfirmQuoteComponent
  },
  {
    path: 'refferal',
    component: ReferralComponentComponent
  },
  {
    path: 'traveladdlinfo',
    component: AddTravelInfoComponent
  },
  {
    path: 'reset',
    component: ForgotPasswordComponent
  },
  {
    path: 'homeaddlinfo',
    component: AdditionalHomeInfoComponent
  },
  {
    path: 'motoraddlinfo',
    component: AdditionalInfoScreenComponent
  },
  {
    path: 'policycancelendt',
    component: PolicyCancelationEndorsmentComponent
  },
  {
    path: 'viewPolicy',
    component: ViewPolicyComponent
  },
  {
    path: 'edatavalidation',
    component: FirstScreenMotorComponent
  },
  {
    path: 'viewClaim',
    component: ViewClaimComponent
  },
  {
    path: 'viewHistory',
    component: PolicyHistoryComponent
  },
  {
    path: 'endtconfirmation',
    component: EndorsementApproveComponent
  },
  {
    path: 'addcoverendt',
    component: AddCoverEndorsmentComponent
  },
  {
    path: 'summary',
    component: SummaryInfoComponent
  },
  {
    path: 'addcoverendtsummary',
    component: AddCoverSummaryEndComponent
  },
  {
    path: 'addcoverendtconfirm',
    component: AddCoverConfirmEndComponent
  },
  {
    path: 'adjustpremiumendt',
    component: PremiumAdjustmentEndorsementComponent
  },
  {
    path: 'addladjustsiendt',
    component: AdditionalSiAdjustmentEndorsementComponent
  },
  {
    path: 'adjustpremiumendtsumm',
    component: PremiumSiAdjustmentEndorsementSummary
  },
  {
    path: 'extensionendt',
    component: ExtensionPolicyEndorsementComponent
  },
  {
    path: 'addextendt',
    component: AdditionalExtensionEndorsementComponent
  },
  {
    path: 'extpolicyendtsumm',
    component: ExtensionSummaryEndorsement
  },
  {
    path: 'policycancelEndtsumm',
    component: PolicyCancelSummEndComponent
  },
  {
    path: 'certificateendt',
    component: CertificateEndorsementComponent
  },
  {
    path: 'fleetendt',
    component: FleetCertificateProceedComponent
  },
  {
    path: 'vehicleparamendt',
    component: ChangeInVehParamEndorsementComponent
  },
  {
    path: 'sessiontimeout',
    component: SessionTimeoutComponent
  },
  {
    path: 'quoteDashboard',
    component: QuoteDashboardComponent
  },
  {
    path: 'policyRenewalDashboard',
    component: PolicyRenewalDashboardComponent
  },
  {
    path: 'myDashboard',
    component: MyDashboardComponent
  },
  {
    path:'claimIntimate',
    component:IntimateClaimsComponent
  },
  {
    path:'report-claim',
    component:ReportClaimComponent
  },
  {
    path:'tp-claim',
    component:TpClaimComponent
  },
  {
    path:'find-active-policy',
    component:FindActivePolicyComponent
  },
  {
    path:'submit-claim',
    component:SubmitClaimComponent
  },
  {
    path:'upload-claim-docs',
    component: UploadClaimsDocumentsComponent
  },
  {
    path:'claim-thankyou',
    component:ClaimsThankyouComponent
  },
  {
    path: 'thankyou',
    component: PolicyThankYouComponent
  },
  {
    path: 'endorsmentApproval',
    component: EndorsmentApprovalComponent
  },
  {
    path: 'marine_hull',
    component: PCraftBasicInfoComponent
  },
  {
    path: 'marineaddlInfo',
    component: PCraftAdditionalInfo
  },
  {
    path: 'marine-insurance',
    component: MarineInfoComponent
  },
  {
    path: 'create-certificate',
    component: MarineCreateCertificateComponent
  },
  {
    path: 'Marine-addl-Info',
    component: MarineAddlInfoComponent
  },
  {
    path: 'Marine-upload-Info',
    component: MarineUploadInfoComponent
  },
  {
    path: 'work-flow',
    component: WorkflowComponent
  },
  {
    path: 'workflow-addlInfo',
    component: WorkflowAddlInfoScreenComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
