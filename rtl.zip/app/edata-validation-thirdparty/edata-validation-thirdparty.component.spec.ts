import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EdataValidationThirdpartyComponent } from './edata-validation-thirdparty.component';

describe('EdataValidationThirdpartyComponent', () => {
  let component: EdataValidationThirdpartyComponent;
  let fixture: ComponentFixture<EdataValidationThirdpartyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EdataValidationThirdpartyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EdataValidationThirdpartyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
