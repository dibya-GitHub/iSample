import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { ErrorMessage } from 'src/shared/error-message';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { Tooltip } from 'src/shared/tool-tip';
import { ValidatorService } from 'src/shared/validator-service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-edata-validation-thirdparty',
  templateUrl: './edata-validation-thirdparty.component.html',
  styleUrls: ['./edata-validation-thirdparty.component.scss']
})
export class EdataValidationThirdpartyComponent implements OnInit {

  public spin: Boolean = false;
  //ToolTip
  public tooltipMessgae = new Tooltip();

  //Error Message
  public Err_msg = new ErrorMessage();

  public validator = new ValidatorService();
  edataError: string;
  edataForm: UntypedFormGroup;
  edataVehForm: UntypedFormGroup;
  public edataVehiInfoFlag: boolean = false;
  quoteNo: string;

  vehMidValue: any;
  chassisNo: string;
  transId: string;
  tranSrNo: string;
  edataTransmission: string;
  vehRegion: string;
  insName: string;
  mobileNo: string;
  emailId: string;
  errorMsg: string = '';


  VehModalYearError;
  vehMakeError;
  vehModalError;
  vehTrimError;
  vehBodyTypeError;
  vehEngSizeError;


  public edataVehMake: string = '';
  public edataVehModal: string = '';
  public edataTrim: string = '';
  public edataEngineSize: string = '';
  public edataBodyType: string = '';
  public edataModalYear: string = '';
  public modelList: Array<any>;
  public makeList: Array<any>;
  public edataTrimList: Array<any>;
  public edataBodyTypeList: Array<any>;
  public edataEngineSizeList: Array<any>;
  yearArray: any = [];
  userFilter: any = this.session.get("userFilter");

  ip: string;
  userId: string = this.session.get("username");
  agentRoleId: string = this.session.get("USER_ROLE_ID");
  userType: string = this.session.get("usertype");
  portalType: string = this.session.get("portaltype");
  companyCode: string = this.session.get("companyCode");

  formSubmitAttempt: boolean = false;

  constructor(private session: SessionStorageService,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private router: Router,
    private fb: UntypedFormBuilder,
    private messageService: MessageService,
    private spinnerService: LoaderService) {
    this.edataForm = this.fb.group({
      chassisNo: [''],
      insName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      mobileNo: ['', Validators.compose([Validators.required, Validators.pattern(/(^5\d{8}$|^(05)\d{8}$)/)])]
    });
  }
  createEdataVehForm() {
    this.edataVehForm = this.fb.group({
      vehModelYear: [this.edataModalYear],
      vehMake: [this.edataVehMake],
      vehModel: [this.edataVehModal],
      vehTrim: [this.edataTrim],
      vehBodyType: [this.edataBodyType],
      vehEngSize: [this.edataEngineSize],
      vehModelYearCode: '',
      vehMakeCode: '',
      vehModelCode: '',
      vehTrimCode: '',
      vehBodyTypeCode: '',
      vehEngSizeCode: ''
    });
  }
  ngOnInit() {
    this.spinnerService.isBusy = false;
    this.commonService.getIPAddress().subscribe(data => {
      this.ip = data.ip;
    });
    let year = new Date().getFullYear();
    for (let i = year; i > (year - 5); i--) {
      this.yearArray.push(i);
    }
  }
  onClickSubmit(form) {

    this.formSubmitAttempt = true;
    if (this.edataForm.valid) {
      this.spin = true;
      this.spinnerService.isBusy = false;
      this.chassisNo = form.chassisNo;
      this.insName = form.insName;
      this.mobileNo = form.mobileNo;
      this.emailId = form.emailId
      var param = {
        "chassisNo": form.chassisNo,
        "companyCode": this.companyCode,
        "portal": this.portalType,
        "userId": this.userId,
        "ipAddress": this.ip
      };
      this.agentService.getEdataInfo(param)
        .subscribe(response => {
          var erroMsg = response.errorMsg;
          if (erroMsg == null) {
            this.chassisNo = response.chassisNo;
            this.transId = response.transId;
            this.tranSrNo = response.transSrNo;
            this.getHeaderInformation();
            this.agentService.getEdataVehicleInfo(response.chassisNo)
              .subscribe(response => {
                this.spinnerService.isBusy = false;
                this.edataVehMake = response.VD_VEH_MAKE;
                this.edataVehModal = response.VD_VEH_MODEL;
                this.edataModalYear = response.VD_MODEL_YEAR;
                this.edataTrim = response.VD_TRIM;
                this.edataEngineSize = response.VD_ENGINE_SIZE == null ? '' : response.VD_ENGINE_SIZE;
                this.edataBodyType = response.VD_BODY_TYPE;
                this.edataTransmission = response.VD_TRANSMISSION;
                this.vehRegion = response.VD_MFG_REGION;
                this.vehMidValue = response.VD_VEH_MID_VALUE
                this.createEdataVehForm();
                if ('1' === response.VD_GCC_SPEC_YN && (this.vehMidValue == null || this.vehMidValue === 0)) {
                  this.edataVehiInfoFlag = true;
                  if (this.validator.validateString(this.edataVehMake) && !this.validator.validateString(this.edataVehModal)) {
                    this.agentService.getEdataCode('MOT_VEH_MAKE', this.edataVehMake).
                      subscribe(data => {
                        this.edataVehMake = data.edataCode;
                        this.getVehModalList(this.edataVehMake, '');
                      });
                  }

                  if (!this.validator.validateString(this.edataTrim) && (this.validator.validateString(this.edataModalYear)
                    && this.validator.validateString(this.edataVehMake) && this.validator.validateString(this.edataVehModal))) {
                    this.loadEdataTypeList();
                  }
                  if (!this.validator.validateString(this.edataBodyType)) {
                    this.agentService.getEdataBodyTypeList('MOT_BODY_TYP').subscribe(data => {
                      this.edataBodyTypeList = data.bodyTypeList;
                    });

                  }
                  if (!this.validator.validateString(this.edataEngineSize) && (this.validator.validateString(this.edataModalYear)
                    && this.validator.validateString(this.edataVehMake) && this.validator.validateString(this.edataVehModal)
                    && this.validator.validateString(this.edataTrim) && this.validator.validateString(this.edataBodyType))) {
                    this.loadEdataTypeList();

                  }
                } else {

                  // this.router.navigate(['motor'],{queryParams: {'transId': this.transId,
                  // 'tranSrNo':this.tranSrNo,'quoteNo':this.quoteNo,'edataFlag':true,
                  //   insName:this.insName,mobileNo:this.mobileNo,emailId:this.emailId},skipLocationChange: true });
                }


              });

          } else {

            //    this.edataError=erroMsg;
            //    this.router.navigate(['motor'],{queryParams: {'edataFlag':false,'edataError': this.edataError,
            //    insName:this.insName,mobileNo:this.mobileNo,emailId:this.emailId},skipLocationChange: true });
            //  
          }

        }, error => {

        });
    }

    else {
      this.validateAllFormFields(this.edataForm);
      console.error('InvalidForm');
    }

  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true })
      }
    });
  }

  getHeaderInformation() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getHeaderInformation(param)
      .subscribe(data => {
        this.quoteNo = data.REFNO;
      });
  }

  getVehicleMake() {
    let v_make = {
      "makeFliterYn": this.userFilter.CUST_MAKE_FILTER_YN,
      "groupCode": this.userFilter.CUST_GROUP_CODE
    };
    this.agentService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.makeList = arr;
      });
  }

  getVehModalList(event, controlName) {
    let v_model = { "type": "MOT_VEH_MOD", "refCode": event.target.value };
    this.agentService.getVehicleModel(v_model)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.modelList = arr;
        if (controlName != '')
          this.setEdataValue(event, controlName);
      });
  }
  loadEdataTrimList(event, controlName) {
    let param = {
      'year': this.edataModalYear,
      'make': this.edataVehMake,
      'model': event.target.value

    };
    this.agentService.getEdataEngineSizelist(param).subscribe(response => {
      this.edataEngineSizeList = response.engineSizeList;
    });
    this.setEdataValue(event, controlName);
  }

  loadEdataEngSizeList(event, controlName) {
    this.spinnerService.isBusy = true;
    let param = {
      'year': this.edataModalYear,
      'make': this.edataVehMake,
      'model': this.edataVehModal,
      'trim': event.target.value,
      'bodyType': this.edataBodyType
    };
    this.agentService.getEdataEngineSizelist(param).subscribe(response => {
      this.edataEngineSizeList = response.engineSizeList;
      this.spinnerService.isBusy = false;
    });
    this.setEdataValue(event, controlName);
  }

  loadEdataTypeList() {
    this.spinnerService.isBusy = true;
    if (this.validator.validateString(this.edataTrim)) {
      let param = {
        'year': this.edataModalYear,
        'make': this.edataVehMake,
        'model': this.edataVehModal,
        'trim': this.edataTrim,
        'bodyType': this.edataBodyType
      };
      this.agentService.getEdataEngineSizelist(param).subscribe(response => {
        this.edataEngineSizeList = response.engineSizeList;
      });
    } else {
      let param = {
        'year': this.edataModalYear,
        'make': this.edataVehMake,
        'model': this.edataVehModal
      };
      this.agentService.getEdataTrimList(param).subscribe(response => {
        this.edataTrimList = response.trimList;
        this.spinnerService.isBusy = false;
      });

    }
  }

  setEdataValue(event, controlName) {
    let selectedCode = event.target.value;
    let selectedDesc = event.target['options']
    [event.target['options'].selectedIndex].text;
    this.edataVehForm.get(controlName).setValue(selectedDesc);
    this.edataVehForm.get(controlName + "Code").setValue(selectedCode);

  }


  submitEdataVehForm(form) {
    if (!this.validator.validateString(form.vehModelYear)) {
      this.VehModalYearError = "Pleast Select Manu Year";
      return false;
    }
    if (!this.validator.validateString(form.vehMake)) {
      this.vehMakeError = "Pleast Select Vehicle Make";
      return false;
    }
    if (!this.validator.validateString(form.vehModel)) {
      this.vehModalError = "Pleast Select Vehicle Modal";
      return false;
    }
    if (!this.validator.validateString(form.vehTrim)) {
      this.vehTrimError = "Pleast Select Vehicle Trim";
      return false;
    }
    if (!this.validator.validateString(form.vehBodyType)) {
      this.vehBodyTypeError = "Pleast Select Vehicle Body Typer";
      return false;
    }
    if (!this.validator.validateString(form.vehEngSize)) {
      this.vehEngSizeError = "Pleast Select Engine Sizer";
      return false;
    }
    this.spinnerService.isBusy = true;
    let param = {
      'chassisNo': this.chassisNo,
      'vehModelYear': form.vehModelYear,
      'vehMake': form.vehMake,
      'vehModel': form.vehModel,
      'vehTrim': form.vehTrim,
      'vehBodyType': form.vehBodyType,
      'vehEngSize': form.vehEngSize,
      'vehTransmission': this.edataTransmission,
      'vehRegion': this.vehRegion
    };
    this.errorMsg = null;
    this.agentService.eDataEvaluation(param).subscribe(response => {

      if (response.vehMidValue != null) {
        this.vehMidValue = response.vehMidValue;
      } else {
        this.vehMidValue = 0.00;
      }
      let param = {
        vehMake: form.vehMakeCode,
        vehModel: form.vehModelCode,
        vehBodyType: form.vehBodyTypeCode,
        manfYear: form.vehModelYear.code,
        sumAssured: this.vehMidValue,
        transId: this.transId,
        tranSrNo: this.tranSrNo
      };

      this.agentService.updateEdataVehicleInfo(param).subscribe(response => {
        // this.router.navigate(['motor'],{queryParams: {'transId': this.transId,
        // 'tranSrNo':this.tranSrNo,'quoteNo':this.quoteNo,'edataFlag':true,
        //   insName:this.insName,mobileNo:this.mobileNo,emailId:this.emailId},skipLocationChange: true });
      });

    }, error => {
      this.errorMsg = error.error.errMessage
    })
  }

  get f() { return this.edataForm.controls; }

}
