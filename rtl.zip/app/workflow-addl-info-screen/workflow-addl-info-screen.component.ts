import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { PrimaryInfo } from 'src/app/motor-insurance/classes/primary-info';
import { AgentHttpclientService } from 'src/app/services/agent-httpclient.service';
import { ErrorMessage } from "src/shared/error-message";
import { LoaderService } from "src/shared/loader-service/loader.service";
import { AgentUserService } from "src/shared/services/agent-user.service";
import { Tooltip } from "src/shared/tool-tip";

@Component({
  selector: 'app-workflow-addl-info-screen',
  templateUrl: './workflow-addl-info-screen.component.html',
  styleUrls: ['./workflow-addl-info-screen.component.scss']
})

export class WorkflowAddlInfoScreenComponent implements OnInit {
  //Error Message
  public Err_msg = new ErrorMessage();
  //ToolTip
  public tooltipMessgae = new Tooltip();

  file: File;
  docCodeValue;
  public colorList: any;
  public plateList: Array<any>;
  public vehPlateList: Array<any>;
  public vehShapeList: Array<any>;
  public bankList: Array<any>;
  public cityList: Array<any>;

  public countryList: Array<any>;
  public weightList: Array<any>;

  public occupationList: Array<any>;
  public nationalityList: Array<any>;
  public genderList: Array<any>;
  public langList: Array<any>;
  public contactList: Array<any>;
  public relationList: Array<any>;
  public plateTypes: Array<any>;
  is_disabled: string;
  quoteNo: string;
  polStartDate: string;
  polEndDate: string;
  policyIssueDate: string;
  civilId: string;
  currencyCode: string;
  makeDesc: string;
  modelDesc: string;
  sumInsured: any;
  insName: string;
  titleAlert: string = 'This field is required';
  defaultArr = [];
  validChassisNo: boolean = true;
  errorMsg: string;
  city: string;
  basicinfo: PrimaryInfo;
  transId: string;
  tranSrNo: string;
  instYN: string;
  //session
  userId: string = this.session.get("username");
  agentRoleId: string = this.session.get("USER_ROLE_ID");
  agentCode: string = this.session.get("agent");
  userType: string = this.session.get("usertype");
  portalType: string = this.session.get("portaltype");
  companyCode: string = this.session.get("companyCode");
  lobCode: string = '01';

  public installAccess: string = this.session.get("installAccess");
  userFilter: any = this.session.get("userFilter");

  additionalInfo: UntypedFormGroup;

  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  isEndorsement = false;
  policyNo: any;
  companyYn: any;
  initialPremium: any;

  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private spinnerService: LoaderService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService
  ) {
    this.additionalInfo = this.fb.group({
      chassisNo: ['', Validators.required],
      engineNo: ['', Validators.required],
      regnNo: '',
      colorArr: '',
      countryArr: ['', Validators.required],
      weightArr: ['', Validators.required],
      financedYn: '0',
      financedBankArr: '',
      insNameAr: '',
      address: '',
      poBox: ['', Validators.required],
      cityArr: ['', Validators.required],
      occupationArr: '',
      plateChar: '',
      genderArr: '',
      cardRefNo: '',
      trafficLoc: ['', Validators.required],
      orangeCardNo: '',
      aaaCardNo: '',
      tcfNo: ['', Validators.required],
      tplLimit: ['', Validators.required],
      vatRefNo: '',
      vehPlateCode: '',
      mileage: ''
    })

  }

  ngOnInit() {
    this.spinnerService.isBusy = true;
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.getHeaderInformation();
    this.getAdditionalInfo();
    let defarr = [];
    let id;
    let text;
    let object = { id: "", text: "--select--" };
    defarr.push(object);
  }

  dropDownService() {
    this.getCityList();
    this.getColorList();
    this.getBankList();
    this.getOccupationList();
    this.getGenderList();
    this.getWeightList();
    this.getCountryList();
    this.getRelationList();
    this.getPlateTypeList();
    this.getvehiclePlateTypeList();
  }

  getPlateType() {
    let params = { "type": "PLATE_CHAR" }
    this.agentService.getPlateType(params).subscribe(result => {
      this.plateTypes = result;
    })
  }

  getAdditionalInfo() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "mapId": "MOT_AGENT_POL_SCR_2"
    };
    this.agentService.getAddlInsuredInfo(obj).subscribe(result => {
      this.city = result.city;
      this.basicinfo = result;
      this.instYN = result.instYN;
      this.additionalInfo.patchValue({
        insNameAr: result.insNameAr,
        address: result.address,
        poBox: result.poBox,
        cityArr: (result.city) || '',
        cardRefNo: '',
        vatRefNo: (result.vatRefNo ? result.vatRefNo : undefined)
      });
      this.companyYn = this.session.get('companyYn');
      this.setValidationForVat();

      let param = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "mapId": "MOT_AGENT_RISK_SCR_2"
      };
      this.agentService.getVehicleInfo(param)
        .subscribe(result => {
          this.basicinfo = result;
          if (!(this.basicinfo.financedBank) || (this.basicinfo.financedBank === 'select')) {
            this.additionalInfo.patchValue({
              financedYn: '0',
              financedBankArr: ''
            });
            this.is_disabled = 'true';
            this.disabledBankList('0');
          }
          else {
            this.additionalInfo.patchValue({
              financedYn: '1',
              financedBankArr: this.basicinfo.financedBank
            });
            this.is_disabled = null;
            this.disabledBankList('1');
          }
          this.additionalInfo.patchValue({
            chassisNo: this.basicinfo.chassisNo,
            engineNo: this.basicinfo.engineNo,
            regnNo: this.basicinfo.regnNo,
            trafficLoc: this.basicinfo.trafficLoc || '',
            orangeCardNo: this.basicinfo.orangeCardNo,
            plateChar: this.basicinfo.plateChar,
            aaaCardNo: this.basicinfo.aaaCardNo,
            tplLimit: this.basicinfo.tplLimit,
            tcfNo: this.basicinfo.tcfNo,
            countryArr: this.basicinfo.manfCountry || '',
            vehPlateCode: this.basicinfo.vehPlateCode,
            mileage: this.basicinfo.mileage
          });
          this.dropDownService();
        }, error => {

        });

    });

  }

  validateChassisNo(val: string) {
    if (val != null && val != "") {
      this.spinnerService.isBusy = true;
      let param = {
        "chassisNo": val,
        "transId": this.transId,
        "company": this.companyCode
      };
      this.agentService.valDupChassisNo(param)
        .subscribe(result => {
          if ("1" == result.validYN) {
            this.validChassisNo = true;
            let param = {
              "company": this.companyCode,
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "civilId": this.civilId,
              "chassisNo": val
            }

            this.agentService.allowChassisNo(param)
              .subscribe(result => {
                this.validChassisNo = true;
                this.spinnerService.isBusy = false;
              }, error => {
                this.errorMsg = error.error.errMessage;
                this.validChassisNo = false;
                this.spinnerService.isBusy = false;
              })
          } else {
            this.validChassisNo = false;
            this.spinnerService.isBusy = false;
          }
        }, error => {

          this.spinnerService.isBusy = false;
          this.errorMsg = error.error.errMessage;
          this.validChassisNo = false;
          let param = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": this.quoteNo,
            "errMessage": error.error.errMessage
          };
          this.agentService.insertErrorMsg(param).subscribe(response => {
            let obj = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
            };
            this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
          });
        });
    }
  }

  validateChassisNoPkg(val: string) {
    if (val != null && val != "") {
      this.spinnerService.isBusy = true;
      let param = {
        "chassisNo": val,
        "transId": this.transId,
        "company": this.companyCode,
        "tranSrNo": this.tranSrNo
      };
      this.agentService.valDupChassisNoPkg(param)
        .subscribe(result => {
          if ("1" == result.validYN) {
            this.validChassisNo = true;
          } else {
            this.validChassisNo = false;
            this.spinnerService.isBusy = false;
          }
        }, error => {

          this.spinnerService.isBusy = false;
          this.errorMsg = error.error.errMessage;
          this.validChassisNo = false;
          let param = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": this.quoteNo,
            "errMessage": error.error.errMessage
          };
          this.agentService.insertErrorMsg(param).subscribe(response => {
            let obj = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
            };
            this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
          });
        });
    }
  }

  disabledBankList(value: string) {
    const bank = this.additionalInfo.get('financedBankArr');
    if (value == "1") {
      bank.setValidators([Validators.required]);
      this.is_disabled = null;
    } else {
      this.is_disabled = 'true';
      this.additionalInfo.get("financedBankArr").setValue("");
      bank.clearValidators();
    }
    bank.updateValueAndValidity();
  }

  setValidationForVat() {
    const vat = this.additionalInfo.get('vatRefNo');
    if (this.companyYn == "1") {
      vat.setValidators(Validators.required);
    } else {
      vat.clearValidators();
    }
    vat.updateValueAndValidity();
  }

  changeToUpper(value: string) {
    let chassisNo = value.toUpperCase();
    this.additionalInfo.patchValue({ chassisNo: chassisNo });
  }

  getCountryList() {
    let param = { "type": "COUNTRY" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.manfCountry) {
            array.push(object);
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("countryArr").value === '') {
          let obj = { id: '', text: '' };
          array.push(obj)
        }
        this.countryList = arr;
      });
  }

  getRelationList() {
    let param = { "type": "RELATION" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.relationList = arr;
      });
  }

  getWeightList() {
    let param = { "type": "WEIGHT" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.vehWeight) {
            array.push(object);
            this.additionalInfo.patchValue({
              weightArr: array
            });
          }
          arr.push(object);
        }
        if (this.additionalInfo.get("weightArr").value === '') {
          this.additionalInfo.patchValue({
            weightArr: array || ''
          });
        }
        this.weightList = arr;
      });

  }

  getHeaderInformation() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getHeaderInformation(param)
      .subscribe(data => {
        this.civilId = data.CIVILID;
        this.quoteNo = data.REFNO;
        this.polStartDate = data.POLSTARTDATE;
        this.polEndDate = data.POLENDDATE;
        this.makeDesc = data.MAKEDESC;
        this.modelDesc = data.MODELDESC;
        this.sumInsured = data.SUMINSURED;
        this.insName = data.INSUREDNAME;
        this.currencyCode = data.QPI_CURRENCY;
        this.policyIssueDate = data.ISSUEDATE;
        this.initialPremium = data.ORGPREM;
      });
  }



  getGenderList() {
    let param = { "paraType": "GENDER" };
    this.agentService.getApplParam(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appParamsArray.length; i++) {
          let id = result.appParamsArray[i].code;
          let text = result.appParamsArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.gender) {
            this.additionalInfo.patchValue({
              genderArr: id || ''
            });
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("genderArr").value === '') {
          this.additionalInfo.patchValue({
            genderArr: ''
          });
        }
        this.genderList = arr;
      });
  }
  getOccupationList() {
    let param = { "type": "OCCUPATION" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.occupation) {
            this.additionalInfo.patchValue({
              occupationArr: id || ''
            });
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("occupationArr").value === '') {
          this.additionalInfo.patchValue({
            occupationArr: ''
          });
        }
        this.occupationList = arr;
      });
  }

  getPlateTypeList() {
    this.agentService.getApplicationRefCodes('PLATE_CHAR', '002').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.plateList = tmpArr;
    });
  }

  getvehiclePlateTypeList() {
    this.agentService.getApplicationCodes('MOT_PLAT_TYP').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.vehPlateList = tmpArr;
    });
  }

  getBankList() {
    let param = { "type": "BANK" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.financedBank) {
            array.push(object);
            this.is_disabled = null;
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("financedBankArr").value === '') {
          let obj = { id: '', text: '' };
          array.push(obj);
        }
        this.bankList = arr;
      });
  }


  getColorList() {
    let param = { "type": "MOT_VEH_COL" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.vehColor) {
            array.push(object);
            this.additionalInfo.patchValue({
              colorArr: array || ''
            });
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("colorArr").value === '') {
          let obj = { id: '', text: '' };
          array.push(obj)
          this.additionalInfo.patchValue({
            colorArr: array || ''
          });
        }
        this.colorList = arr;
      });
  }


  getCityList() {
    let param = { "type": "STATE", "refCode": "002" };
    this.agentService.getVehicleModel(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.city) {
            array.push(object);
          }
          arr.push(object);

        }
        this.cityList = arr;
      });
  }

  onClickSubmit(mode: string) {
    if (this.additionalInfo.valid) {
      this.spinnerService.isBusy = true;
      this.validateChassisNo(this.basicinfo.chassisNo);
      this.validateChassisNoPkg(this.basicinfo.chassisNo);
      this.callRecalcularProcedure();
      this.basicinfo = this.additionalInfo.value;
      if (this.basicinfo.colorArr != null)
        this.basicinfo.vehColor = this.basicinfo.colorArr[0].id;
      this.basicinfo.manfCountry = this.basicinfo.countryArr;
      this.basicinfo.vehWeight = this.basicinfo.weightArr[0].id;
      this.basicinfo.city = this.basicinfo.cityArr;
      if (this.basicinfo.financedBankArr != null)
        this.basicinfo.financedBank = this.basicinfo.financedBankArr;

      this.basicinfo.occupation = this.basicinfo.occupationArr; //[0].id;
      this.basicinfo.gender = this.basicinfo.genderArr; // [0].id;
      this.basicinfo.mapId = "MOT_AGENT_POL_SCR_2";
      this.basicinfo.transId = this.transId;
      this.basicinfo.tranSrNo = this.tranSrNo;
      this.basicinfo.lobCode = "01";

      this.agentService.updateInsuredInfo(this.basicinfo).subscribe(updateInfoResult => {

        this.basicinfo.mapId = "MOT_AGENT_RISK_SCR_2";
        this.agentService.updateVehicleInfo(this.basicinfo).subscribe(updateVehicleInfo => {
          if (!this.validChassisNo) {
            let param = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "errMessage": this.errorMsg,
              "quoteNo": this.quoteNo
            };
            this.agentService.insertErrorMsg(param).subscribe(response => {
              let obj = {
                "transId": this.transId,
                "tranSrNo": this.tranSrNo,
                "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
              };
              this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

            });
          }
          this.callRecalcularProcedure();
          let obj = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "lobCode": this.lobCode,
            "mode": mode,
            "quoteNo": this.quoteNo,
            "instYN": this.instYN,
            "policyNo": this.policyNo,
            "from": "wfQuote",
            "initialPremium": this.initialPremium
          };
          this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
        });
      });
    } else {
      this.validateAllFormFields(this.additionalInfo);
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  callRecalcularProcedure() {
    let params = {
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'agentId': this.session.get('agent')
    }
    this.agentService.getRecalculte(params).subscribe(result => {
      this.spinnerService.isBusy = false;
    }, error => {
      let errorMsglet = error.error.errMessage;
      let obj = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "quoteNo": this.quoteNo,
        "errorMsg": errorMsglet
      };
      this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

    });
  }


}