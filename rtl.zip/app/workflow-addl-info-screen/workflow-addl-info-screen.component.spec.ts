import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkflowAddlInfoScreenComponent } from './workflow-addl-info-screen.component';

describe('WorkflowAddlInfoScreenComponent', () => {
  let component: WorkflowAddlInfoScreenComponent;
  let fixture: ComponentFixture<WorkflowAddlInfoScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkflowAddlInfoScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkflowAddlInfoScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
