import { DatePipe } from "@angular/common";
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-policy-thank-you',
  templateUrl: './policy-thank-you.component.html',
  styleUrls: ['./policy-thank-you.component.scss']
})
export class PolicyThankYouComponent implements OnInit {
  transId: String;
  tranSrNo: string;
  companyCode: string;
  bean: any;
  policyDetails: any;
  printCreditAccess: string;
  mode: string = 'Approve';
  datePipe: DatePipe;
  constructor(
    private session: SessionStorageService,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.datePipe = new DatePipe('en-US');
    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      if (params["respCode"] == 2000) {
        this.confirmPolicy();
      } else {
        let path = window.location.pathname.substr(0, window.location.pathname.lastIndexOf('/'));
        let obj = {
          errMsg: params['errMessage']
        }
        this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
        return false;
      }
    });

  }

  ngOnInit() {

    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
  }

  confirmPolicy() {
    let reqParam = { "transId": this.transId, "tranSrNo": this.tranSrNo, "mode": this.mode };
    this.agentService.fetchConfirmData(reqParam).subscribe(response => {
      if (response.respCode == 2000) {
        this.bean = response;
      }
    }, error => {
    });
  }

  hasPrintAccess() {
    return ("1" == this.session.get("printCreditAccess"));
  }

  GenerateReport(reportType) {
    this.commonService.getReport(this.transId, this.tranSrNo, reportType, this.session.get("portaltype"), this.bean.transType, "", "");
  }

  fnClose() {
    this.router.navigate(['agentdashboard']);
  }
}
