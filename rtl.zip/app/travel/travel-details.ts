export class TravelDetailsInfo {
    tripType: String;
    daysOfTravel: String;
    noOfAdults: String;
    noOfInfants: String;
    noOfChild: String;
    noOfSeniorCtzns: String;
    teritorialLimit: String;
    winSport: String;
}