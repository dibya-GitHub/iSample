import { CurrencyPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as moment from 'moment';
import { ApplicationConstants } from 'src/shared/application-constants';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { AgGridLinkComponent } from '../ag-grid-link/ag-grid-link.component';
import { ECalendarValue } from 'ng2-date-picker';
import { SessionStorageService } from 'angular-web-storage';

@Component({
  selector: 'app-quote-dashboard',
  templateUrl: './quote-dashboard.component.html',
  styleUrls: ['./quote-dashboard.component.scss'],
  providers: [CurrencyPipe]
})
export class QuoteDashboardComponent implements OnInit {
  columnDefs = [];
  rowData: any[];
  gridApi: any;
  gridColumnApi: any;
  filterOptions: UntypedFormGroup;
  resultOptions: any;
  users: any[];
  
  public myDatePickerOptions: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };
  showEnquiryDateErr: boolean;
  searchText: any;
  rowSelection: any[] = [];
  selectedQuote: any;
  canShowIssuePolicy = true;
  material = true;
  ng2datePickerConfig: any = {
    firstDayOfWeek: 'su',
    monthFormat: 'MMM, YYYY',
    disableKeypress: false,
    allowMultiSelect: false,
    closeOnSelect: true,
    closeOnSelectDelay: 0,
    openOnFocus: true,
    openOnClick: true,
    onOpenDelay: 0,
    closeOnEnter: true,
    weekDayFormat: 'ddd',
    appendTo: document.body,
    showNearMonthDays: true,
    showWeekNumbers: false,
    enableMonthSelector: true,
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    dayBtnFormat: 'DD',
    monthBtnFormat: 'MMM',
    hours12Format: 'hh',
    hours24Format: 'HH',
    meridiemFormat: 'A',
    minutesFormat: 'mm',
    minutesInterval: 1,
    secondsFormat: 'ss',
    secondsInterval: 1,
    showSeconds: false,
    showTwentyFourHours: true,
    timeSeparator: ':',
    multipleYearsNavigateBy: 10,
    showMultipleYearsNavigation: false,
    locale: moment.locale(),
    hideInputContainer: false,
    returnedValueType: ECalendarValue.Moment,
    unSelectOnClick: true,
    hideOnOutsideClick: true,
    numOfMonthRows: 3,
    format: 'DD/MM/YYYY'
  };
  constructor(
    private fb: UntypedFormBuilder,
    private agentService: AgentUserService,
    private currPipe: CurrencyPipe,
    private loaderService: LoaderService,
    private router: Router,
    private session: SessionStorageService,

  ) { }

  ngOnInit() {
    const context = this;
    this.columnDefs = [
      {
        field: 'quoteNo',
        headerName: 'Quote No',
        sortable: false,
        checkboxSelection: false,
        resizable: true,
        cellStyle: { textAlign: 'left' }
      },
      {
        field: 'policyNo',
        headerName: 'Policy No',
        sortable: true,
        filter: true,
        resizable: true,
        enableRowGroup: true,
        cellRendererFramework: AgGridLinkComponent,
        cellRendererParams: {
          click: (data) => {
            context.materialPolicyClicked(data);
          }
        }
      },
      {
        field: 'policyType',
        headerName: 'Policy Type',
        sortable: true,
        filter: true,
        resizable: true,
        cellStyle: { textAlign: 'right' }, enableRowGroup: true,
      },
      {
        field: 'insName',
        headerName: 'Assured Name',
        sortable: true,
        resizable: true,
        tooltipField: '',
        enableRowGroup: true,
      },
      {
        field: 'chassisNo',
        headerName: 'Chassis Number',
        sortable: true,
        resizable: true,
        tooltipField: '',
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'vehicleMakeModel',
        headerName: 'Vehicle',
        sortable: true,
        resizable: true,
        cellStyle: { textAlign: 'right' },
        enableRowGroup: true,
      },
      {
        field: 'fromDate',
        headerName: 'From Date',
        sortable: true,
        headerTooltip: 'Policy From Date',
        cellStyle: { textAlign: 'right' },
        enableRowGroup: true,
        resizable: true,
        valueFormatter: (params) => {
          return moment(params.value).format('DD/MM/YYYY');
        }
      },
      {
        field: 'toDate',
        headerName: 'To Date',
        sortable: true,
        tooltipField: 'thContractDesc',
        headerTooltip: 'Policy To Date',
        resizable: true,
        enableRowGroup: true,
        valueFormatter: (params) => {
          return moment(params.value).format('DD/MM/YYYY');
        }
      },
      {
        field: 'grossPremium',
        headerName: 'Gross Premium',
        sortable: true,
        cellStyle: { textAlign: 'left' },
        tooltipField: '',
        resizable: true,
        enableRowGroup: true,
        valueFormatter: (params) => {
          return context.currencyFormatter(params);
        }
      },
      {
        field: 'dueDays',
        headerName: 'Due Days',
        sortable: true,
        cellStyle: { width: '130px', height: '31px', textAlign: 'left' },
        resizable: true,
        enableRowGroup: true
      },
      {
        field: 'userName',
        headerName: 'Producer Name',
        sortable: true,
        cellStyle: { textAlign: 'center' },
        resizable: true,
        enableRowGroup: true
      },
      {
        field: 'status',
        headerName: 'Status',
        sortable: true,
        resizable: true,
        enableRowGroup: true,
        cellStyle: { textAlign: 'center' },
      },
      {
        field: '',
        headerName: 'Select',
        headerCheckboxSelection: false,
        headerCheckboxSelectionFilteredOnly: true,
        resizable: true,
        checkboxSelection: true,
        cellStyle: { textAlign: 'center' },
      }
    ];
    this.filterOptions = this.fb.group({
      enquiryFrom: [moment().subtract(7, 'd').format('DD/MM/YYYY'), Validators.required],
      enquiryTo: [moment().format('DD/MM/YYYY'), Validators.required],
      user: ['']
    });
    this.resultOptions = {
      materializedCount: '30',
      pendingCount: '34',
      materializedPremium: '30000',
      pendingPremium: '52909'
    };
    this.retrieveQuoteData();
    this.getAgentUsers();
    this.loaderService.isBusy = false;
  }

  currencyFormatter(params) {
    return this.currPipe.transform(params.value, 'AED ');
  }

  onGridSizeChanged(params) {
    const gridWidth = document.getElementById('treatyGrid').offsetWidth;
    const columnsToShow = [];
    const columnsToHide = [];
    let totalColsWidth = 0;
    const allColumns = params.columnApi.getAllColumns();
    for (let i = 0; i < allColumns.length; i++) {
      const column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  onRowSelected(event) {
    const rowCount = event.api.getSelectedNodes().length;

    if (rowCount && event && event.node && event.node.selected) {
      this.selectedQuote = event.node.data;
      // this.checkCanIssuePolicy(event);
    } else if (rowCount === 0) {
      this.selectedQuote = undefined;
    }
    this.checkCanIssuePolicy(event);
  }

  checkCanIssuePolicy(event) {
    const rowCount = event.api.getSelectedNodes().length;
    if (rowCount && this.selectedQuote && this.selectedQuote.policyNo) {
      this.canShowIssuePolicy = false;
    } else {
      this.canShowIssuePolicy = true;
    }
  }

  onEnquiryDateChanged(event, flag) {
    let fromDate;
    let toDate;
    if (flag === 'To') {
      if (this.filterOptions.get('enquiryFrom').value) {
        const fromControl = this.filterOptions.get('enquiryFrom');
        if (fromControl.value.formatted) {
          fromDate = fromControl.value.formatted;
        } else {
          const date = fromControl.value.date;
          fromDate = date.day + '/' + date.month + '/' + date.year;
        }
      }
      toDate = event.formatted;
    } else {
      if (this.filterOptions.get('enquiryTo').value) {
        const toControl = this.filterOptions.get('enquiryTo');
        if (toControl.value.formatted) {
          toDate = toControl.value.formatted;
        } else {
          const date = toControl.value.date;
          toDate = date.day + '/' + date.month + '/' + date.year;
        }
      }
      fromDate = event.formatted;
    }
    if (fromDate && toDate) {
      const isBefore = moment(toDate, 'DD/MM/YYYY').isBefore(moment(fromDate, 'DD/MM/YYYY'));
      if (isBefore) {
        this.showEnquiryDateErr = true;
      } else {
        this.showEnquiryDateErr = false;
      }
    }
  }

  searchTextChanged() {
    if (this.searchText || this.searchText === '') {
      this.gridApi.setQuickFilter(this.searchText);
    }
  }

  getAgentUsers() {
    const agentId = JSON.parse(this.session.get('agent'));
    this.agentService.getAgentUsers(agentId).subscribe((res: any) => {
      this.users = res.userInfo;
    },
      err => {
      }
    );
  }

  retrieveQuoteData() {
    this.loaderService.isBusy = true;
    if (this.filterOptions.valid) {
      const agentId = JSON.parse(this.session.get('agent'));
      const formData = JSON.parse(JSON.stringify(this.filterOptions.value));
      this.agentService.getQuotationInfo(agentId, formData).subscribe((res: any) => {
          this.rowData = res.quoteDetails;
          this.resultOptions = res.quoteSummaryInfo;
          this.loaderService.isBusy = false;
        },
          err => {
            this.loaderService.isBusy = false;
          }
        );
    } else {
      alert('Invalid form. Check all madantory fields are given.');
      this.loaderService.isBusy = false;

    }
  }

  issuePolicy() {
    if (!this.selectedQuote) {
      return;
    }
    const data = this.selectedQuote;
    const obj = {
      transId: data.transId,
      tranSrNo: data.tranSrNo,
      quoteNo: data.quoteNo,
      editYn: "1",
      openPolicyNo: data.openPolNo
    };

    if (ApplicationConstants.LOB_MOTOR === data.lobCode) {
      this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
    } else if (ApplicationConstants.LOB_TRAVEL === data.lobCode) {
      this.router.navigate(['travel'], { queryParams: obj, skipLocationChange: true });
    } else if (ApplicationConstants.LOB_HOME === data.lobCode) {
      this.router.navigate(['home'], { queryParams: obj, skipLocationChange: true });
    } else if (ApplicationConstants.LOB_MARINE_HULL == data.lobCode) {
      this.router.navigate(['marine_hull'], { queryParams: obj, skipLocationChange: true });
    } else if (ApplicationConstants.LOB_MARINE_INSURANCE === data.lobCode) {
      this.router.navigate(['create-certificate'], { queryParams: obj, skipLocationChange: true });
    }
  }

  materialPolicyClicked(data) {
    const param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
      width=0,height=0,left=-1000,top=-1000`;
    window.open('/viewHistory?transId=' + data.transId, 'History', param);
  }

  exportExcel() {
    this.gridApi.exportDataAsExcel({ fileName: 'Quote_Log_' + moment().format('DD_MM_YYYY HH_mm_ss') });
  }

}
