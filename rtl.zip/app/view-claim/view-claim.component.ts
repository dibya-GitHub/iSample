import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { Search } from '../../shared/classes/search';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-view-claim',
  templateUrl: './view-claim.component.html',
  styleUrls: ['./view-claim.component.scss']
})
export class ViewClaimComponent implements OnInit {
  ratioList: any;
  arr: Array<any>;
  vechId: any;
  lobCode: any;

  searchMessage: string;
  viewCliamForm;
  claims: any;
  isShowClaim: boolean;
  policyNo: any;
  claimCount: any
  claimPremium: any;
  claimRatio: any;
  claim_OS: any;
  claimPaid: any;
  claimIncurred: any;
  data: any
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';


  policysearchList = [
    new Search('TPI_POLICY_NO', 'policyNo'),
    new Search('TPI_POL_REF_NO', 'Ref No'),
    new Search('TPI_QUOT_NO', 'Quote No'),
    new Search('TPI_MOBILE_NO', 'Mobile No'),
    new Search('TPI_REG_NO', 'Plate No'),
    new Search('TPI_CIVIL_ID', 'Civil ID'),
    new Search('TPI_CHASSIS_NO', 'Chassis No'),
    new Search('TPI_ENGINE_NO', 'Engine No'),
    new Search('TPI_CERT_NO', 'Certificate No')
  ];

  constructor(
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    public router: Router,
    private route: ActivatedRoute,
    private session: SessionStorageService,
    private loaderService: LoaderService) { }

  ngOnInit() {
    this.lobCode = this.commonService.getParamValue('lobCode');
    var tranSrNo = this.commonService.getParamValue('tranSrNo');
    var transId = this.commonService.getParamValue('transId');
    this.policyNo = this.commonService.getParamValue('policyNo')
    this.loadClaimDetails()
    this.claimForm();
  }

  claimForm() {
    this.viewCliamForm = new UntypedFormGroup({
      claimsearchname: new UntypedFormControl('', [Validators.required]),
      claimsearchvalue: new UntypedFormControl(this.policyNo, [Validators.required]),
    })
  }

  searchClaim() {
    if (this.viewCliamForm.valid) {
      this.isShowClaim = true;
      var data = this.viewCliamForm.value;
      let params = { "SearchBy": '', "searchValue": data.claimsearchvalue, "userId": this.session.get('username') };
      this.agentService.getClaimInfo(params).subscribe(result => {
        this.claims = result.claimList;
        for (var i = 0; i < this.claims.length; i++) {
          this.data = this.claims[i].policyNo;
        }
        this.agentService.getClaimRatioList(this.data).subscribe(result => {
          this.ratioList = result.lossRatioList;
        })
      })
    } else {
      this.validateAllFormFields(this.viewCliamForm)
      console.error('InvalidForm')
    }

  }

  loadClaimDetails() {
    let params = { "SearchBy": '', "searchValue": this.policyNo, "userId": this.session.get('username') };
    this.agentService.getClaimInfo(params).subscribe(result => {
      this.claims = result.claimList;
    })

  }


  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

}
