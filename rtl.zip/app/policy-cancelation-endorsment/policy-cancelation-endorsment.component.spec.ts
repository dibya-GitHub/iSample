import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyCancelationEndorsmentComponent } from './policy-cancelation-endorsment.component';

describe('PolicyCancelationEndorsmentComponent', () => {
  let component: PolicyCancelationEndorsmentComponent;
  let fixture: ComponentFixture<PolicyCancelationEndorsmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolicyCancelationEndorsmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyCancelationEndorsmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
