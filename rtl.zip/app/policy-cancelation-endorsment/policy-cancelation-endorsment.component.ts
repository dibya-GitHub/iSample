import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AdditionalHomeInfo } from '../home/interfaces/additional-home-info';
import { HomeInsurancePlanService } from '../home/services/home-insurance-plan.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { TravelDetailsInfo } from '../travel/travel-details';

@Component({
  selector: 'policy-cancel-endorsment',
  templateUrl: './policy-cancelation-endorsment.component.html',
  styleUrls: ['./policy-cancelation-endorsment.component.scss']
})
export class PolicyCancelationEndorsmentComponent implements OnInit {
  
  relationList: any;
  travelIfoarr: any;
  addlInfoForm: UntypedFormArray;
  genderList: any;
  childinfo: UntypedFormArray;
  travelersInfo: UntypedFormGroup;
  adultinfo: UntypedFormArray;
  noOfChild: number;
  noOfAdult: number;
  agentPremium: any;
  endorseType: any;
  policyCancelForm: UntypedFormGroup;

  endorsedData: any;
  vechileShape: Array<any>;
  plateTypes: Array<any>;
  travelInfo: any;
  quoteNo: any;

  transId;
  transSNo;
  customerInfo: any;
  vehicleInfo: any;
  adultTravellerDetails: any = [];
  infantTravellerDetails: any = [];
  childTravellerDetails: any = [];
  seniorTravellerDetails: any = [];
  nationalityList: any;
  cityList: any;
  languageList: any;
  lobCode;
  financed: boolean = false;
  changeOwnershipForm: UntypedFormGroup;
  additionalHomeInfo: AdditionalHomeInfo = new AdditionalHomeInfo();
  travelDetailsinfo: TravelDetailsInfo = new TravelDetailsInfo();
  public sumInclusiveMandatory: any[] = [];
  optionalCovers: any[] = [];
  public discounts: any[] = [];
  public deductables: any[] = [];
  public loading: any[] = [];
  public fees: any[] = [];
  public tax: any[] = [];
  agentCommissionPercent;
  agentCommisionValue;
  agentCommissionTax;
  netPremium;
  display = 'none';
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';

  constructor(
    private router: Router,
    public route: ActivatedRoute,
    private fb: UntypedFormBuilder,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
    ) {

  }
  createFormGroup() {
    return new UntypedFormGroup({
      plateType: new UntypedFormControl("",),
      vehShape: new UntypedFormControl(""),
      regNo: new UntypedFormControl()
    });
  }
  createTravelFrm() {
    this.travelersInfo = this.fb.group({
      adultinfo: this.fb.array([]),
      childinfo: this.fb.array([]),
    });

  }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId')//"1397780"//"1397225";
    this.transSNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    this.endorseType = this.commonService.getParamValue('endType');
    this.policyCancelForm = this.createFormGroup();
    this.createTravelFrm();
    this.getQuoteTravelInfo();
    this.getCoverSummary();
    this.getPlateType();
    this.getVehicleShape();
    this.getEndorsementDetails();
    this.getAgentNetPremium();
    if (this.endorseType == undefined) {
      this.endorseType = '008'
    }
  }

  getEndorsementDetails() {
    let params = { "trans_Id": this.transId, "trans_Sno": this.transSNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {
        this.customerInfo = result.customerInfo;
        this.travelDetailsinfo = result.travelInfo;
        this.vehicleInfo = result.vehicleInfo;
        this.policyCancelForm.patchValue({
          plateType: this.vehicleInfo.vehUsageDesc,
          vehShape: this.vehicleInfo.vehBodyTypeDesc
        });

      });
  }
  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.transSNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            this.sumInclusiveMandatory.push(array[i]);
          }
          else {
            this.optionalCovers.push(array[i]);
          }
        }
      });
  }


  getPlateType() {
    let params = { "type": "PLATE_CHAR" }
    this.agentService.getPlateType(params).subscribe(result => {
      this.plateTypes = result;
    })
  }
  getVehicleShape() {
    let params = { "type": "MOT_QCB_SHAP" }
    this.agentService.VechicleShape(params).subscribe(result => {
      this.vechileShape = result;
    })
  }

  submitForm(type) {
    this.endorsedData = this.policyCancelForm.value;
    this.loaderService.isBusy = true;
    if (type == 'save') {
      this.updateData(this.endorsedData);

    }
    else if (type == 'approve') {
      this.updateData(this.endorsedData);
      const obj = {
        transId: this.transId,
        tranSrNo: this.transSNo,
        endType: this.endorseType,
        userId: this.session.get("agent")
      }
      this.agentService.endProceedToConfirm(obj)
        .subscribe(result => {
          this.router.navigate(['policycancelEndtsumm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.transSNo, 'policyNo': this.customerInfo.policyNo, 'lobCode': this.lobCode, 'endorseType': this.endorseType }, skipLocationChange: true });
          this.loaderService.isBusy = false;
        });

    }
    else if (type == 'cancel') {
      const params = {
        transId: this.transId,
        tranSrNo: this.transSNo
      }
      this.agentService.cancelEndorsement(params)
        .subscribe(result => {
        });
      this.router.navigate(['agentdashboard']);
    }

  }


  updateData(endorsedData) {
    const obj = {
      transId: this.transId,
      tranSrNo: this.transSNo,
      mapId: "END_POL_CANCL_SCR1",
      vehBodyTypeDesc: this.policyCancelForm.get('vehShape').value,
      regNo: this.policyCancelForm.get('regNo').value,
      userId: this.session.get("agent")
    }
    this.agentService.updateVehicleInfo(obj)
      .subscribe(result => {
        if (result.respCode == 2000) {
          let params = {
            endTypeDesc: this.endorseType,
            transId: this.transId,
            tranSrNo: this.transSNo,
            mapId: "END_POL_CANCL_SCR2",
            userId: this.session.get("agent")
          }
          this.agentService.updateEndorsedInfo(params).subscribe(result => {
          });
        }

      });
  }

  getAgentNetPremium() {
    this.agentService.getAgentNetPremium({ "transId": this.transId, "tranSrNo": this.transSNo }).subscribe(result => {
      this.netPremium = result.PREMIUM;
    })
  }
  getQuoteTravelInfo() {
    const data = { "transId": this.transId, "tranSrNo": this.transSNo }
    this.agentService.getQuoteTravelInfo(data).subscribe(result => {
      this.noOfAdult = Number(result.noOfAdults);
      this.noOfChild = Number(result.noOfChild);
      if (this.noOfAdult > 0) {
        this.addAdultRow(this.noOfAdult);
      }
      if (this.noOfChild > 0) {
        this.addChildRow(this.noOfChild);
      }
    })
    this.getGenderType();
    this.getNationalityType();
    this.getRelationList();
    this.getTravelersInfo();
  }

  //---------------Travelinfo------------------//

  addAdultRow(len: number): any {
    for (var i = 1; i <= len; i++) {
      this.adultinfo = this.travelersInfo.get('adultinfo') as UntypedFormArray;
      this.createAdult();
      this.adultinfo.push(this.createAdult());
    }
  }

  addChildRow(len: number): any {
    for (var i = 1; i <= len; i++) {
      this.childinfo = this.travelersInfo.get('childinfo') as UntypedFormArray;
      this.createChild();
      this.childinfo.push(this.createChild());
    }
  }

  createAdult(): UntypedFormGroup {
    return this.fb.group({
      trvlrName: '',
      relation: '',
      gender: '',
      dob: [],
      nationality: '',
      passptNo: '',
      wntrSptsExtYN: [],
      transId: this.transId,
      tranSrNo: this.transSNo,

    });
  }
  createChild(): UntypedFormGroup {
    return this.fb.group({
      trvlrName: '',
      relation: '',
      gender: '',
      dob: '',
      nationality: '',
      passptNo: '',
      wntrSptsExtYN: '',
      transId: this.transId,
      tranSrNo: this.transSNo,
    });
  }

  getGenderType() {
    this.agentService.getGenderList({ "paraType": "GENDER" }).subscribe(resp => {
      this.genderList = resp;
    })
  }
  getNationalityType() {
    this.agentService.getNationalityList({ "type": "NATIONALITY" }).subscribe(resp => {
      this.nationalityList = resp;
    })
  }
  loadTravelersValues() {
    const controlArray1 = <UntypedFormArray>this.travelersInfo.get('adultinfo');
    const controlArray2 = <UntypedFormArray>this.travelersInfo.get('childinfo');
    var adult = 0;
    var child = 0;
    for (var i = 0; i < this.travelIfoarr.length; i++) {
      let date = new Date(this.travelIfoarr[i].dob)
      if (this.travelIfoarr[i].category == '8002') {
        controlArray1.controls[child].get('trvlrName').setValue(this.travelIfoarr[i].trvlrName);
        controlArray1.controls[child].get('relation').setValue(this.travelIfoarr[i].relation);
        controlArray1.controls[child].get('gender').setValue(this.travelIfoarr[i].gender);
        controlArray1.controls[child].get('nationality').setValue(this.travelIfoarr[i].nationality);
        controlArray1.controls[child].get('passptNo').setValue(this.travelIfoarr[i].passptNo);
        controlArray1.controls[child].get('wntrSptsExtYN').setValue(this.travelIfoarr[i].wntrSptsExtYN);
        controlArray1.controls[child].patchValue({
          dob: {
            date: {
              year: date.getFullYear(),
              month: date.getMonth() + 1,
              day: date.getDate()
            }
          }
        });
        child++;
      }
      if (this.travelIfoarr[i].category == '8003') {
        controlArray2.controls[adult].get('trvlrName').setValue(this.travelIfoarr[i].trvlrName);
        controlArray2.controls[adult].get('relation').setValue(this.travelIfoarr[i].relation);
        controlArray2.controls[adult].get('gender').setValue(this.travelIfoarr[i].gender);
        controlArray2.controls[adult].get('nationality').setValue(this.travelIfoarr[i].nationality);
        controlArray2.controls[adult].get('passptNo').setValue(this.travelIfoarr[i].passptNo);
        controlArray2.controls[adult].get('wntrSptsExtYN').setValue(this.travelIfoarr[i].wntrSptsExtYN);
        controlArray2.controls[adult].patchValue({
          dob: {
            date: {
              year: date.getFullYear(),
              month: date.getMonth() + 1,
              day: date.getDate()
            }
          }
        });
        adult++;
      }
    }
  }
  getTravelersInfo() {
    let param = { "transId": this.transId, "tranSrNo": this.transSNo };
    this.agentService.getTravelerDetls(param).subscribe(response => {
      if (response["travelerArray"] != "" && response["travelerArray"] != null && response["travelerArray"] != undefined) {
        this.travelIfoarr = response["travelerArray"];
        this.loadTravelersValues();
      }
    });

  }
  getRelationList() {
    this.agentService.getRelationType({ "type": "RELATION" }).subscribe(resp => {
      this.relationList = resp;
    })
  }
}
