import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SessionStorageService } from 'angular-web-storage';
import * as $ from 'jquery';
import { MessageService } from 'primeng/api';
import { ErrorMessage } from 'src/shared/error-message';
import { ApiConstants } from '../../shared/api-constants';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { Home } from '../home/home';
import { AdditionalHomeInfo } from '../home/interfaces/additional-home-info';
import { HomeInsurancePlanService } from '../home/services/home-insurance-plan.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-summary-info',
  templateUrl: './summary-info.component.html',
  styleUrls: ['./summary-info.component.scss']
})
export class SummaryInfoComponent implements OnInit {
  file: File;
  tmpParms: any;
  additionalHomeInfo: AdditionalHomeInfo = new AdditionalHomeInfo();
  currency: any = ApiConstants.CURRENCY;
  formSubmitAttempt: boolean;
  title = 'retail-portal';
  additionalInfoForm: UntypedFormGroup;
  sendPayLinkForm: UntypedFormGroup;
  disableBank: string;
  transId: any;
  tranSrNo: any;
  quoteNo: any;
  lobCode: any;
  cityList: any = [];
  zoneList: any = [];
  streetList: any = [];
  buildingAge: any = [];
  bulTypeList: any = [];
  bankList: any = [];
  nationalityList: any = [];
  occupationList: any = [];
  civilId: string;
  polStartDate: any;
  polEndDate: any;
  insuredName: string;
  address1: string;
  address2: string;
  address1B: string;
  address2B: string;
  poBox: string;
  poboxB: string;
  city: string;
  cityB: string;
  premium: any;
  coverSummaryList: any = [];
  taxes: any = [];
  discounts: any = [];
  deductables: any = [];
  fees: any = [];
  load: any = [];
  homeData: Home = new Home();
  docCodeValue: string = '';
  disableBuildingInfo: string;
  agentCommisionValue;
  agentCommissionPercent;
  agentCommissionTax;
  regPaymentInfo: any;
  pgReqUrl: any;
  accept: boolean;
  printCreditAccess: string;
  taxflag: any;
  userId: string = this.session.get("username");
  public controls;
  paymentOptionsArray: any[] = [];
  termsAndConditionText: any;
  checkboxVal: boolean;
  pg_param: any;
  encRequest: any;
  accessCode: any;
  pgeReqUrl: any;
  prodCode: any;

  public installAccess: string = this.session.get("installAccess");
  public instYN: string = null;

  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  navigateFrom: any;
  documents: any;
  policyNo: any;
  isEndorsement: boolean;
  emailId: any;
  payLinkAccess: any;
  public Err_msg = new ErrorMessage();


  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private modalService: NgbModal,
    private fb: UntypedFormBuilder,
    public loaderService: LoaderService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
    public homeInsurancePlanService: HomeInsurancePlanService,
  ) {

  }
  ngOnInit() {
    this.disableBank = "true";
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    this.polStartDate = this.commonService.getParamValue('polStartDate');
    this.polEndDate = this.commonService.getParamValue('polEndDate');
    this.instYN = this.commonService.getParamValue('instYN');
    this.navigateFrom = this.commonService.getParamValue('from');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.emailId = this.session.get('emailId');
    this.payLinkAccess = this.session.get('payLinkAccess');
    if (this.policyNo) {
      this.isEndorsement = true;
    }
    this.getCoverSummary();
    this.getDiscDedLoadFeesSumm();
    this.getPremiumSummary();
    this.getPaymentOption();
    this.getTaxFlag();
    // this.getDocumentsList();
    this.getHeaderInformation();
    this.printCreditAccess = this.session.get('printCreditAccess');
    window.scroll(0, 0);
    this.createSendPayLinkForm();

  }
  createSendPayLinkForm() {
    this.sendPayLinkForm = this.fb.group({
      emailId: [undefined, [Validators.required, Validators.email]],
    });
  }
  getFormattedDate(date) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    return this.appendZero(day) + "/" + this.appendZero(month) + "/" + this.appendZero(year);
  }
  appendZero(temp: any) {
    if (temp < 10) {
      return '0' + temp;
    }
    return temp;
  }

  hasPrintAccess() {
    return ("1" == this.session.get("printCreditAccess"));
  }

  getTaxFlag() {
    let paraType = { "paraType": "TAX_APPL_YN" };
    this.agentService.getTaxFlag(paraType).subscribe(response => {
      var array = response["appParamsArray"];

      for (var i = 0; i < array.length; i++) {
        this.taxflag = array[i].value;
      }

    });

  }

  getDocumentsList() {
    const transId = '2';
    this.agentService.getDocumentsList(transId)
      .subscribe(
        res => {
          this.documents = res.documents;
        },
        err => {
          // Error handle..
        }
      );
  }

  viewDoc(doc: any) {
    this.agentService.viewDocument(doc.docId)
      .subscribe(
        res => {
          // Response..

        },
        err => {
          // Error handle..
        }
      );
  }

  downloadDoc(doc: any) {

  }

  goToPreviousPage() {

    if (this.navigateFrom && this.navigateFrom === 'dashboard') {
      this.router.navigate(['myDashboard']);
    } else {
      let editQuoteYn = (this.navigateFrom && 'wfQuote' === this.navigateFrom) ? "0" : "1";
      let obj = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        lobCode: this.lobCode,
        polStartDate: this.polStartDate,
        polEndDate: this.polEndDate,
        policyNo: this.policyNo,
        editQuoteYn: editQuoteYn
      }
      if ('01' === this.lobCode && this.navigateFrom && 'wfQuote' === this.navigateFrom) {
        this.router.navigate(['workflow-addlInfo'], { queryParams: obj, skipLocationChange: true });
      } else if (this.lobCode == '04') {
        this.router.navigate(['homeaddlinfo'], { queryParams: obj, skipLocationChange: true });
      } else if (this.lobCode == '08') {
        this.router.navigate(['traveladdlinfo'], { queryParams: obj, skipLocationChange: true });
      } else if (this.lobCode == '01') {
        this.router.navigate(['motoraddlinfo'], { queryParams: obj, skipLocationChange: true });
      } else if (this.lobCode == '06') {
        this.router.navigate(['marineaddlInfo'], { queryParams: obj, skipLocationChange: true });
      }
    }

  }

  getZone(val) {
    this.agentService.getApplicationRefCodes('ZONE_AREA', val).subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.zoneList = tmpArr;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  getAdditionalInfo() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "mapId": "AGENT_HOME_POL_SCR_2"
    };
    this.agentService.getAddlInsuredInfo(obj).subscribe(result => {
      //   this.city=result.city;
      this.additionalHomeInfo = result;
      this.additionalInfoForm.patchValue({
        arabicInsuredName: result.insNameAr,
        address1: result.address1,
        address2: result.address2,
        address3: result.address3,
        city: result.city,
        nationality: result.nationality,
        poBox: result.poBox

      });

      let param = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "mapId": "HOME_RISK_SCR_2"
      };
      this.agentService.getHomeInfo(param)
        .subscribe(homeResponse => {
          this.additionalInfoForm.patchValue({
            address1B: homeResponse.address,
            address2B: homeResponse.desc,
            occup: homeResponse.occupation,
            poBoxB: homeResponse.poBox,
            cityB: homeResponse.city,
            zoneArea: homeResponse.zoneArea,
            streetBlock: homeResponse.streetBlock,
            bldngType: homeResponse.bldngType,
            bldngAge: homeResponse.bldngAge,
            financedBank: homeResponse.financedBank
          });
          this.getZone(homeResponse.city);
        }, error => {

        });

    });

  }

  cancelEndorsement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });
  }

  getCoverSummary() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }

    this.agentService.getCoverSummary(postData)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I') {
            array[i].premium = 'Inclusive';
            this.coverSummaryList.push(array[i]);
          } else if (array[i].type == 'M') {
            if (array[i].premium > 0) {
              this.coverSummaryList.splice(j, 0, array[i]);
            }
            j++;
          } else {
            this.coverSummaryList.push(array[i]);
          }
        }

      });

  }

  getDiscDedLoadFeesSumm() {

    let taxesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "TAX"
    };
    this.agentService.getDiscDedLoadFeesSumm(taxesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.taxes.push(data[k]);
        }
      }

    }, error => {

      this.loaderService.isBusy = false;
    });

    let dedPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DED"
    };
    this.agentService.getDiscDedLoadFeesSumm(dedPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.deductables.push(data[k]);
        }
      }
    }, error => {

      this.loaderService.isBusy = false;
    });

    let discountPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DISC"
    };
    this.agentService.getDiscDedLoadFeesSumm(discountPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.discounts.push(data[k]);
        }
      }
    }, error => {

      this.loaderService.isBusy = false;
    });

    let feesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "FEES"
    };
    this.agentService.getDiscDedLoadFeesSumm(feesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.fees.push(data[k]);
        }
      }
    }, error => {

      this.loaderService.isBusy = false;
    });

    let loadPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "LOAD"
    };
    this.agentService.getDiscDedLoadFeesSumm(loadPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.load.push(data[k]);
        }
      }
    }, error => {

      this.loaderService.isBusy = false;
    });
  }

  getPremiumSummary() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.agentService.getNetPremium(postData).subscribe(response => {

      this.agentCommisionValue = response.AGENT_FC;
      this.agentCommissionPercent = response.AGENT_PERCENT;
      this.agentCommissionTax = response.QPI_ACOMM_TAX;
      this.premium = response.PREMIUM;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }



  onSubmit() {
    this.formSubmitAttempt = true;
  }
  saveData(type) {
    if (this.lobCode == '04') {
      this.submitHomeForm(type);
    } else if (this.lobCode == '08' || this.lobCode == '01' || this.lobCode == ApiConstants.MARINE_HULL_LOBCODE) {
      this.saveQuoteOrApprove(type);
    }

  }
  submitHomeForm(type) {

    if (type == 'saveQuote') {

      const obj = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        lobCode: this.lobCode,

        mode: 'saveQuote'
      }

      this.router.navigate(['quoteconfirm'], { queryParams: obj, skipLocationChange: true });
    }
    else if (type == 'approve') {

      const obj = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        lobCode: this.lobCode,

        portal: ApiConstants.PORTAL,
        userId: this.userId,
        agentId: ''
      }
      this.agentService.approvePolicy(obj).subscribe(approvePolicyResponse => {
        if (approvePolicyResponse.respCode == 2000) {
          const obj = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            quoteNo: this.quoteNo,
            lobCode: this.lobCode,

            mode: 'Approve'
          }

          this.router.navigate(['quoteconfirm'], { queryParams: obj, skipLocationChange: true });

        }

      }, error => {
        let param = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo,
          "errMessage": error.error.errMessage
        };
        this.agentService.insertErrorMsg(param).subscribe(response => {
          let obj = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
          };
          this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
        });

        // this.router.navigate(['refferal'], { queryParams: obj })
      });

    }
    else {
      const obj = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        quoteNo: this.quoteNo,
        lobCode: this.lobCode,

        mode: 'sendPayLink'
      }

      this.router.navigate(['quoteconfirm'], { queryParams: obj, skipLocationChange: true });
    }

  }

  getHeaderInformation() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getHeaderInformation(param)
      .subscribe(data => {
        this.civilId = data.CIVILID;
        this.quoteNo = data.REFNO;
        this.prodCode = data.PRODCODE;
        this.polStartDate = data.POLSTARTDATE;
        this.polEndDate = data.POLENDDATE;
      });
  }

  saveQuoteOrApprove(flag: String) {
    this.loaderService.isBusy = true;
    if (flag == 'approve') {
      (<HTMLInputElement>document.getElementById("approvePolicy")).disabled = true;
      let editQuoteYn = (this.navigateFrom && 'wfQuote' === this.navigateFrom) ? "0" : "1";
      let aproveParams = { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode': flag, 'lobCode': this.lobCode, 'userId': this.session.get('username'), 'portal': this.session.get("portaltype"), 'editQuoteYn': editQuoteYn }
      this.agentService.approveAgentPolicy(aproveParams).subscribe(result => {
        if (result.respCode == 2000) {
          const obj = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            lobCode: this.lobCode,
            quoteNo: this.quoteNo,
            mode: 'Approve',
            portal: this.session.get("portaltype")
          }
          //this.loaderService.isBusy = false;
          this.router.navigate(['quoteconfirm'], { queryParams: obj, skipLocationChange: true });
        }
      }, error => {
        let param = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo,
          "errMessage": error.error.errMessage
        };
        this.agentService.insertErrorMsg(param).subscribe(response => {
          let obj = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo,
            "errMessage": error.error.errMessage
          };
          //this.loaderService.isBusy = false;
          this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
        });
      });
    } else if (flag == 'payment') {
      // flag = 'saveQuote';
      this.router.navigate(['quoteconfirm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode': 'sendPayLink', 'quoteNo': this.quoteNo }, skipLocationChange: true });
    }
    else {
      this.router.navigate(['quoteconfirm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode': flag, 'quoteNo': this.quoteNo }, skipLocationChange: true });
    }
  }
  openLg(content) {
    this.modalService.open(content, { size: 'lg', backdrop: 'static', keyboard: true });
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  sendPayLinkSubmit() {
    if (this.sendPayLinkForm.valid) {
      let value = this.sendPayLinkForm.value;
      this.emailId = value.emailId;
      this.session.set('emailId', this.emailId);
      if (this.emailId) {
        this.sendPayLink();

      }

    } else {
      this.validateAllFormFields(this.sendPayLinkForm);
    }

  }

  sendPayLink() {
    this.loaderService.isBusy = true;
    if (this.emailId == "undefined") {
    } else {
      let editQuoteYn = (this.navigateFrom && 'wfQuote' === this.navigateFrom) ? "0" : "1";
      this.agentService.sendPayLink({ transId: this.transId, tranSrNo: this.tranSrNo, emailId: this.emailId, 'editQuoteYn': editQuoteYn, 'lobCode': this.lobCode })
        .subscribe(
          res => {
            this.modalService.dismissAll();
            const obj = {
              transId: this.transId,
              tranSrNo: this.tranSrNo,
              quoteNo: this.quoteNo,
              lobCode: this.lobCode,
              mode: 'sendPayLink'
            };
            this.loaderService.isBusy = false;
            this.router.navigate(['quoteconfirm'], { queryParams: obj, skipLocationChange: true });
          },
          err => {
            this.modalService.dismissAll();
            let param = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "quoteNo": this.quoteNo,
              "errMessage": err.error.errMessage
            };
            this.agentService.insertErrorMsg(param).subscribe(response => {
              this.loaderService.isBusy = false;
              let obj = {
                "transId": this.transId,
                "tranSrNo": this.tranSrNo,
                "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
              };
              this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
            });

          }
        );
    }
  }

  getReport(type, reportForm) {
    this.loaderService.isBusy = true;
    if ("PROP_FORM" === reportForm) {
      let editQuoteYn = (this.navigateFrom && 'wfQuote' === this.navigateFrom) ? "0" : "1";
      let param = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "userId": this.session.get('username'),
        "portal": this.session.get("portaltype"),
        "editQuoteYn": editQuoteYn
      };
      this.agentService.generateAndUploadProposalForm(param).subscribe(response => {
        this.loaderService.isBusy = true;
        if (response.respCode == 2000) {
          this.commonService.getReport(this.transId, this.tranSrNo, type, this.session.get("portaltype"), "", "", "");
          this.loaderService.isBusy = false;
        }
      }, error => {
        let param = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo,
          "errMessage": error.error.errMessage
        };
        this.agentService.insertErrorMsg(param).subscribe(response => {
          //this.loaderService.isBusy = false;
          this.router.navigate(['refferal'], { queryParams: param, skipLocationChange: true });
        });
      });
    } else {
      this.commonService.getReport(this.transId, this.tranSrNo, type, this.session.get("portaltype"), "", "", "");
      this.loaderService.isBusy = false;
    }
  }


  getPaymentOption() {
    let postData = { transId: this.transId, tranSrNo: this.tranSrNo };
    this.agentService.getPaymentOption(postData).subscribe(response => {
      this.paymentOptionsArray = response.payOptsArray;
      this.termsAndConditionText = response.payOptsArray[0].paymCond;

    });
  }

  acceptedTermCondition() {
    this.checkBundledForms();
  }
  checkBundledForms() {
    if (this.checkboxVal == false) {
      this.submit();
    }
    else {
      alert("Please check to proceed");
    }

  }


  openCoverPdf(coverCode) {
    this.loaderService.isBusy = true;
    let params = {
      "coverCode": coverCode
    }
    this.commonService.getCoverDocUrl(params);
    this.loaderService.isBusy = false;
  }

  submit() {
    if (this.accept == true) {
      this.regPayment();
    } else {
      //this.checkAcceptTermsCondition();
    }
  }

  regPayment() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      premium: this.premium,
      paymtType: "CC",
      userId: this.userId,
      portal: this.session.get("portaltype")
    };
    this.agentService.registerPayment(postData).subscribe(data => {
      this.regPaymentInfo = data;
      this.pg_param = data.PG_PARAM;
      this.encRequest = data.encRequest;
      this.accessCode = data.accessCode;
      this.pgeReqUrl = data.pgReqUrl;
      this.pgReqUrl = "./ccavRequestHandler.jsp"//this.regPaymentInfo.pgReqUrl;
      setTimeout(() => {
        window.localStorage.clear();
        $("#payment_confirmation").submit();
      }, 5000);
    }, error => {
      try {
        let err = error.json();
        if (err.respCode == "6001") {
          let obj = {
            errMsg: err.errMessage
          }
          this.router.navigate(['referral'], { queryParams: obj, skipLocationChange: true });
        } else {
          // this.errorMsg = this.appUtilObj.displayError(error["_body"], this.quoteNo);
        }
        //this.loaderService.isBusy = false;
      } catch (err) {
        //this.loaderService.isBusy = false;
      }
    })
  }
  checkTerms(event) {
    if (event) {
      this.accept = true;
      this.checkboxVal = false;
    } else {
      this.accept = false;
      this.checkboxVal = true;
    }
  }

}
