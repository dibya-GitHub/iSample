import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from "src/shared/loader-service/loader.service";
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../services/agent-httpclient.service';
@Component({
  selector: 'app-fleet-certificate-proceed',
  templateUrl: './fleet-certificate-proceed.component.html',
  styleUrls: ['./fleet-certificate-proceed.component.scss']
})
export class FleetCertificateProceedComponent implements OnInit {

  company;
  transId;
  tranSrNo;
  lobCode;
  policyNo;
  docCodeValue;
  file: File;
  tmpParms: any;
  customerInfo: any;
  vehicleInfo: any;
  driversInfo: any;
  dataArr: UntypedFormArray;
  companyCode: string = this.session.get("companyCode");
  schCode;
  prodCode;
  endType;
  fleetProd;
  fleetSch;
  fleetVehicleList: any;
  confirmCheck: boolean;
  showApprove: boolean;
  vehicleShapes: Array<any>;
  plateTypes: Array<any>;
  constructor(private router: Router, public route: ActivatedRoute, private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private loaderService: LoaderService,
    private fb: UntypedFormBuilder, private session: SessionStorageService) { }


  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.schCode = this.commonService.getParamValue('schCode');
    this.prodCode = this.commonService.getParamValue('prodCode');
    this.endType = this.commonService.getParamValue('endType');

    this.getEndorsementDetails();
    this.getFleetVehicleList();
  }


  getEndorsementDetails() {
    let params = { "trans_Id": this.transId, "trans_Sno": this.tranSrNo, "endorseType": '016' };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {

        this.customerInfo = result.customerInfo;
        if (this.customerInfo.companyYn == '0') {
          this.customerInfo.companyType = 'Individual';
        }
        else {
          this.customerInfo.companyType = 'Company';
        }
        this.vehicleInfo = result.vehicleInfo;
        this.driversInfo = result.driversInfo;
        this.fleetProd = this.customerInfo.fleetProd;
        this.fleetSch = this.customerInfo.fleetSch;

      });
  }

  getFleetVehicleList() {
    let params = { "transId": this.transId, "mode": 'fleet' };
    this.agentService.getFleetvehicleList(params)
      .subscribe(result => {
        this.fleetVehicleList = result.fleetVehicleList;

      });
  }


  approveEndorsement() {
    //this.getProdSchDetails();
    this.endtProceedtoBuy();
  }

  endtProceedtoBuy() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo, "userId": this.session.get("username") }
    this.agentService.endtFleetProceedtoBuy(param)
      .subscribe(result => {
        this.showApprove = true;
        // let obj = { "transId": this.transId, "tranSrNo": this.tranSrNo, "policyNo": this.policyNo };
        //this.router.navigate(['endorsement-confirm'], { queryParams: obj,skipLocationChange: true  });
        this.confirmCheck = true;
      });
  }




  previousPage() {
    this.loaderService.isBusy = true;
    let obj = { "transId": this.transId, "tranSrNo": this.tranSrNo, "lobCode": this.lobCode, "policyNo": this.policyNo, "endType": this.endType, "schCode": this.schCode, "prodCode": this.prodCode };
    this.router.navigate(['certificateendt'], { queryParams: obj, skipLocationChange: true });
    this.loaderService.isBusy = false;
  }


  cancelEndrosement() {
    this.loaderService.isBusy = true;
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.loaderService.isBusy = false;
        this.router.navigate(['agentdashboard']);
      });

  }
  closeEndorsement() {
    this.loaderService.isBusy = true;
    this.router.navigate(['agentdashboard']);
  }

  getReport(reportType, fromId: String, toId: String) {
    this.loaderService.isBusy = true;
    this.commonService.getFleetReport(this.transId, this.tranSrNo - 1, reportType, this.session.get("portaltype"), "END", fromId, toId, this.fleetProd, this.fleetSch);
  }

  pageChange(newPage: number) {
    this.router.navigate(['agentdashboard'], { queryParams: { page: newPage }, skipLocationChange: true });
  }
}
