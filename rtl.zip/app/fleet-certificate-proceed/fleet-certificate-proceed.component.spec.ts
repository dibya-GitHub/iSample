import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FleetCertificateProceedComponent } from './fleet-certificate-proceed.component';

describe('FleetCertificateProceedComponent', () => {
  let component: FleetCertificateProceedComponent;
  let fixture: ComponentFixture<FleetCertificateProceedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FleetCertificateProceedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FleetCertificateProceedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
