
export class EndorsedData {
    transId: string;
    tranSrNo: string;
    address1:string ;
    address2: string ;
    emailId: string;
    mobileNo: string;
    poBox: string ;
    city: string;
    nationality: string;
    reason: string;
    occupation : string;
    constructor()
    { }
  }