import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { endAdultAgeValidator, endChildAgeValidator } from 'src/app/add-travel-info/ValidateAge';
import { EndorsedData } from '../../shared/classes/EndorsedData';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AdditionalHomeInfo } from '../home/interfaces/additional-home-info';
import { HomeInsurancePlanService } from '../home/services/home-insurance-plan.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { TravelDetailsInfo } from '../travel/travel-details';

@Component({
  selector: 'app-change-ownership-endorsement',
  templateUrl: './change-ownership-endorsement.component.html',
  styleUrls: ['./change-ownership-endorsement.component.scss']
})
export class ChangeOwnershipComponent implements OnInit {
  adultError: boolean;
  reportType: any;

  public reasonEndrosement: string;
  public reasonError: string = null;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  transId;
  transSNo;
  policyNo: any;
  customerInfo: any;
  vehicleInfo: any;
  travelInfo: any;
  travellerInfo: any;
  bankList: any = [];
  colorList: any = [];
  adultTravellerDetails: any = [];
  infantTravellerDetails: any = [];
  childTravellerDetails: any = [];
  seniorTravellerDetails: any = [];
  nationalityList: any;
  occupationList: Array<any>;
  cityList: any;
  languageList: any;
  lobCode;
  financed: boolean = false;
  enableCompany: any = 0;
  relationList: any;
  additionalHomeInfo: AdditionalHomeInfo = new AdditionalHomeInfo();
  travelDetailsinfo: TravelDetailsInfo = new TravelDetailsInfo();
  endorsedData: EndorsedData = new EndorsedData();
  public sumInclusiveMandatory: any[] = [];
  optionalCovers: any[] = [];
  public discounts: any[] = [];
  public deductables: any[] = [];
  public loading: any[] = [];
  public fees: any[] = [];
  public tax: any[] = [];
  coverInfo: any[] = [];
  disableBank: string;
  agentCommissionPercent;
  agentCommisionValue;
  agentCommissionTax;
  netPremium;
  display = 'none';
  driverList: any = [];
  driversInfo: any;
  arr = [];
  mobileNoerrorMessage: any;
  testSrNo: any = 0;
  insNameAr: string;
  travelFrom: any;
  changeOwnershipForm = new UntypedFormGroup({
    emiratesId: new UntypedFormControl(""),
    insName: new UntypedFormControl("", Validators.required),
    insNameAr: new UntypedFormControl(""),
    customerType: new UntypedFormControl(""),
    cardAuthCode: new UntypedFormControl(""),
    address1: new UntypedFormControl("", Validators.required),
    address2: new UntypedFormControl(""),
    mobileNo: new UntypedFormControl("", [Validators.required, Validators.pattern(/(^5\d{8}$|^(05)\d{8}$)/)]),
    poBox: new UntypedFormControl("", Validators.required),
    cityP: new UntypedFormControl(""),
    nationality: new UntypedFormControl(""),
    occupation: new UntypedFormControl(""),
    emailId: new UntypedFormControl(""),
    reason: new UntypedFormControl("", Validators.required),

  });

  VehicleInfoForm = new UntypedFormGroup({
    financedStatus: new UntypedFormControl(""),
    financedBank: new UntypedFormControl(""),
    trafficLoc: new UntypedFormControl("", Validators.required),
    tcfNo: new UntypedFormControl("", Validators.required),
    orangeCardNo: new UntypedFormControl(""),
    aaaCardNo: new UntypedFormControl(""),
    vehColor: new UntypedFormControl(""),
    mapId: new UntypedFormControl('END_CHANGE_OWNERSHIP_VEHICLE_INFO')
  });

  customerTypes = [
    { id: "0", value: "Individual" },
    { id: "1", value: "Company" }
  ]


  TravelInforForm: UntypedFormGroup;

  driverForm: UntypedFormGroup;
  public myDatePickerOptions: IAngularMyDpOptions = {

    // other options...
    dateFormat: 'dd/mm/yyyy',
    //disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };

  constructor(private router: Router, public route: ActivatedRoute,
    private homeInsurancePlanService: HomeInsurancePlanService,
    private agentService: AgentHttpclientService,
    private messageService: MessageService,
    private commonService: AgentUserService, private fb: UntypedFormBuilder, private session: SessionStorageService) {
    this.getCity();
  }


  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.transSNo = params["tranSrNo"];
      this.lobCode = params["lobCode"];
      this.policyNo = params["policyNo"];
      this.reportType = params["reportType"];
    });

    this.driverForm = this.fb.group({
      itemRows: this.fb.array([this.initItemRows()])
    });

    this.TravelInforForm = this.fb.group({
      travelRows: this.fb.array([]),
      childRows: this.fb.array([]),
      infantRows: this.fb.array([]),
      seniorCitizens: this.fb.array([])

    });

    this.mobileNoerrorMessage = this.commonService.mobileNoErrorMessage();
    //this.getNationalityList();
    //this.getCityList();
    this.getColorList();
    this.getBankOfFinance();
    this.getEndorsementDetails();
    this.getCoverSummary();
    //this.getCoverSummary();
    this.getDiscDedLoadFeesSumm();
    this.getRelationList();
    this.getOccupationList();
    this.getNationalityType()
  }

  genderList = [
    { code: "1", desc: "Male" },
    { code: "2", desc: "Female" }
  ]


  trafficLocList = [
    { id: "002", value: "Dubai" },
    { id: "003", value: "Abudhabi" }
  ]

  // getCountryList(travelCode){
  //  // alert("travelCode isss"+travelCode);
  //   let paraType ={"type":"COUNTRY"};
  //   this.agentService.getCountryList(paraType).subscribe(result=>{
  //    let arr = [];
  //    for (let i = 0; i < result.appCodesArray.length; i++) {
  //      let id = result.appCodesArray[i].code; 
  //      let text = result.appCodesArray[i].desc;
  //      if(travelCode == id)
  //       {
  //         this.travelFrom = text;
  //         break;
  //       }
  //      } 
  //      })
  // }

  loadAgentDoc(reportType) {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=1000,height=400,left=100%,top=100%`;
    var winRef = window.open('/viewdocument?transId=' + this.transId + '&tranSrNo=' + this.transSNo + '&reportType=' + reportType + '&policyNo=' + this.policyNo, 'Product Category', param);
  }
  getColorList() {
    let v_color = { "type": "MOT_VEH_COL" };
    this.agentService.getGeoList(v_color)
      .subscribe(result => {
        this.colorList = result.appCodesArray;
      });
  }
  enableBankList(financed) {
    if (financed == "  Yes  " || financed == "Yes") {
      this.disableBank = null;

    }
    else {
      this.disableBank = "true";
    }
  }

  getBankOfFinance() {
    this.agentService.getApplicationCodes('BANK').subscribe(data => {
      let tmpArr = data.appCodesArray.reverse();
      this.bankList = tmpArr;
    });
  }


  initItemRows() {
    return this.fb.group({
      driverName: '',
      driverAge: '',
      licenseNo: '',
      licenseAge: '',
      relation: ''
    });
  }
  addNewRow(): void {
    const control = <UntypedFormArray>this.driverForm.controls['itemRows'];
    // add new formgroup
    control.push(this.initItemRows());
  }

  deleteRow(index) {
    // control refers to your formarray
    const control = <UntypedFormArray>this.driverForm.controls['itemRows'];
    // remove the chosen row
    control.removeAt(index);
  }

  getRelationList() {
    let param = { "type": "RELATION" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        this.relationList = result.appCodesArray;

      });
  }

  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  getEndorsementDetails() {
    let params = { trans_Id: this.transId, trans_Sno: this.transSNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {
        this.customerInfo = result.customerInfo;
        this.travelInfo = result.travelInfo;
        // this.customerInfo = result.customerInfo;//
        this.changeOwnershipForm.patchValue({
          address1: this.customerInfo.address,

          address2: this.customerInfo.address2,
          emailId: this.customerInfo.emailId,
          mobileNo: this.customerInfo.mobileNo,
          poBox: this.customerInfo.poBox,

          cityP: this.customerInfo.city,
          financedStatus: this.financed,
          companyYn: this.customerInfo.companyYn,
          emiratesId: this.customerInfo.civilId,
          insName: this.customerInfo.insName,
          insNameAr: this.customerInfo.insNameAr,
          cardRefNo: this.customerInfo.cardRefNo
        });
        if (this.lobCode == '01') {
          this.vehicleInfo = result.vehicleInfo;
          this.driversInfo = result.driversInfo;
          this.VehicleInfoForm.patchValue({
            trafficLoc: this.vehicleInfo.trafficLoc,
            tcfNo: this.vehicleInfo.tcfNo,
            orangeCardNo: this.vehicleInfo.orangeCardNo,
            aaaCardNo: this.vehicleInfo.aaaCardNo,
            vehColor: this.vehicleInfo.vehColor,
            financedStatus: this.vehicleInfo.financedYn,
            financedBank: this.vehicleInfo.financedBank
          });
          if (this.vehicleInfo.financedYn == '1')
            this.financed = true;
          this.loadDefaultValues();

          this.changeOwnershipForm.patchValue({
            customerType: this.customerInfo.companyYn,
            nationality: this.vehicleInfo.nationality
          });

        }
        else {
          if (this.customerInfo.companyYn == '0') {
            this.customerInfo.companyType = 'Individual';
          }
          else {
            this.customerInfo.companyType = 'Company';
          }
        }
        //alert("civil id isss.."+this.customerInfo.civilId);
      });
    if (this.lobCode == '04') {
      let obj = {
        transId: this.transId,
        tranSrNo: this.transSNo

      }
      this.homeInsurancePlanService.getQuoteHomeInfo(obj).subscribe((response: any) => {
        this.additionalHomeInfo.address1B = response.address;
        this.additionalHomeInfo.address2B = response.address1;
        this.additionalHomeInfo.cityB = response.cityDesc;
        this.additionalHomeInfo.poboxB = response.poBox;
        this.additionalHomeInfo.zoneArea = response.zoneAreaDesc;
        this.additionalHomeInfo.streetBlock = response.streetBlockDesc;
        this.additionalHomeInfo.bldngAge = response.bldngAge;
        this.additionalHomeInfo.bldngType = response.bldngTypeDesc;
        this.additionalHomeInfo.financedBankYn = response.financedBankYn;
        this.additionalHomeInfo.financedBank = response.financedBankDesc;

      });
    }
    else if (this.lobCode == '08') {
      this.changeOwnershipForm.patchValue({
        //  occupation: this.travelInfo.occupation
      });
      let params = {
        transId: this.transId,
        tranSrNo: this.transSNo
      }
      this.agentService.getTravelerDetls(params).subscribe(response => {
        if (response["travelerArray"] != "" && response["travelerArray"] != null && response["travelerArray"] != undefined) {
          var data = response["travelerArray"];
          this.setTravelData(data);
          this.setChildData(data);
          this.setInfantData(data);
          this.setSeniorData(data);
          // this.loadTravellerDetails(data);
        }
      });

    }

  }


  updateCompany(customerType) {
    if (customerType == '1') {
      this.enableCompany = true;
    }
    else {
      this.enableCompany = false;
    }
  }

  loadDefaultValues() {
    for (var i = 0; i < this.driversInfo.length; i++) {
      const controlArray = <UntypedFormArray>this.driverForm.get('itemRows');
      controlArray.controls[i].get('driverName').setValue(this.driversInfo[i].driverName);
      controlArray.controls[i].get('driverAge').setValue(this.driversInfo[i].driverAge);
      controlArray.controls[i].get('licenseNo').setValue(this.driversInfo[i].licenseNo);
      controlArray.controls[i].get('licenseAge').setValue(this.driversInfo[i].licenseAge);
      controlArray.controls[i].get('relation').setValue(this.driversInfo[i].relation);
    }
  }


  setTravelData(data) {
    let control = <UntypedFormArray>this.TravelInforForm.controls['travelRows'];
    data.forEach(x => {
      //    this.adultSrNo= x.srNo
      if (x.category == '8003') {
        var date = new Date(x.dob);
        control.push(this.fb.group({
          name: [x.trvlrName, Validators.required],
          travelRelation: [x.relation, Validators.required],
          genderVal: x.gender,
          dateOfBirth: [date, [Validators.required, endAdultAgeValidator]],
          nationality: x.nationality,
          passport: [x.passptNo, Validators.required],
          winterSport: x.wntrSptsExtYN
        }))
      }
    })
  }

  getOccupationList() {

    this.agentService.getApplicationCodes('OCCUPATION').subscribe(data => {
      let tmpArr = data.appCodesArray;
      this.occupationList = this.sortedArray(tmpArr);
    });
    /*  let param={"type": "OCCUPATION"};
      this.agentService.getGeoList(param)
      .subscribe(result => {  
        this.occupationList=result.appCodesArray;
      });*/
  }

  setChildData(data) {
    this.testSrNo = this.testSrNo + 1;
    let control = <UntypedFormArray>this.TravelInforForm.controls['childRows'];
    data.forEach(x => {
      // this.childSrNo= x.srNo
      if (x.category == '8002') {
        var date = new Date(x.dob).toLocaleDateString();
        control.push(this.fb.group({
          //  company: x.company, 
          //  projects: this.setProjects(x)
          //sNo : this.testSrNo,
          //  sNo: x.srNo,
          name: [x.trvlrName, Validators.required],
          travelRelation: [x.relation, Validators.required],
          genderVal: x.gender,
          dateOfBirth: [date, [Validators.required, endChildAgeValidator]],
          nationality: x.nationality,
          passport: [x.passptNo, [Validators.required]],
          winterSport: x.wntrSptsExtYN


        }))
      }

    })

  }

  setInfantData(data) {
    let control = <UntypedFormArray>this.TravelInforForm.controls['infantRows'];
    data.forEach(x => {
      this.testSrNo = this.testSrNo + 1;
      if (x.category == '8001') {
        control.push(this.fb.group({
          sNo: this.testSrNo,
          name: x.trvlrName,
          travelRelation: x.relation,
          genderVal: x.gender,
          dateOfBirth: new Date(x.dob),
          nationality: x.nationality,
          passport: x.passptNo,
          winterSport: x.wntrSptsExtYN
        }))
      }
    })

  }

  setSeniorData(data) {
    let control = <UntypedFormArray>this.TravelInforForm.controls['seniorCitizens'];
    data.forEach(x => {
      this.testSrNo = this.testSrNo + 1;
      if (x.category == '8004') {
        control.push(this.fb.group({
          sNo: this.testSrNo,
          name: x.trvlrName,
          travelRelation: x.relation,
          genderVal: x.gender,
          dateOfBirth: new Date(x.dob),
          nationality: x.nationality,
          passport: x.passptNo,
          winterSport: x.wntrSptsExtYN
        }))
      }

    })

  }

  /*getNationalityList() {
    let v_nationality = { "type": "NATIONALITY" };
    this.agentService.getGeoList(v_nationality)
      .subscribe(result => {
        this.nationalityList = result.appCodesArray;
      });
  }*/

  getNationalityType() {
    this.agentService.getNationalityList({ "type": "NATIONALITY" }).subscribe(resp => {
      this.nationalityList = resp.appCodesArray;
    })
  }


  /*getCityList() {
    let v_city = { "type": "AREA" };
    this.agentService.getGeoList(v_city)
      .subscribe(result => {
        this.cityList = result.appCodesArray;
      });
  }*/


  getCity() {

    this.agentService.getApplicationRefCodes('STATE', '002').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.cityList = tmpArr;
    });
  }



  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.transSNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            this.sumInclusiveMandatory.push(array[i]);
          }
          else {
            this.optionalCovers.push(array[i]);
          }
        }
      });
  }
  getNetPremium() {
    let param = { "transId": this.transId, "tranSrNo": this.transSNo };
    this.agentService.getNetPremium(param)
      .subscribe(response => {
        this.agentCommisionValue = response.AGENT_FC;
        this.agentCommissionPercent = response.AGENT_PERCENT;
        this.agentCommissionTax = response.QPI_ACOMM_TAX;
        this.netPremium = response.PREMIUM;
      });
  }

  getDiscDedLoadFeesSumm() {
    var summArr = ["DISC", "LOAD", "DED", "FEES", "TAX"];
    var k = 0;
    for (var i = 0; i < summArr.length; i++) {
      var type = summArr[i];
      let param = { "transId": this.transId, "tranSrNo": this.transSNo, "type": type };
      this.agentService.getDiscDedLoadFeesSumm(param)
        .subscribe(response => {
          //var arr=["DISC","LOAD","DED","FEES"];    
          if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
            var data = response["othersArray"];
            if (type == "DISC") {
              for (k = 0; k < data.length; k++) {
                this.discounts.push(data[k]);
              }
            } else if (type == "LOAD") {
              for (k = 0; k < data.length; k++) {
                this.loading.push(data[k]);
              }
            } else if (type == "DED") {
              for (k = 0; k < data.length; k++) {
                this.deductables.push(data[k]);
              }
            } else if (type == "FEES") {
              for (k = 0; k < data.length; k++) {
                this.fees.push(data[k]);
              }
            } else if (type == "TAX") {
              for (k = 0; k < data.length; k++) {
                this.tax.push(data[k]);
              }
            }
          }
          this.getNetPremium();
        });
    }
  }

  onSubmit() {

  }
  updateData(endorsedData) {
    const obj = {
      transId: this.transId,
      tranSrNo: this.transSNo,
      lobCode: this.lobCode,
      mobileNo: this.endorsedData.mobileNo,
      emailId: this.endorsedData.emailId,
      nationality: this.endorsedData.nationality,
      occupation: this.endorsedData.occupation,
      city: this.endorsedData.city,
      address: this.endorsedData.address1,
      address1: this.endorsedData.address2,
      poBox: this.endorsedData.poBox,
      transRemark: this.endorsedData.reason,
      custCode: this.session.get("agent"),
      cardRefNo: this.endorsedData.cardAuthCode,
      insName: this.endorsedData.insName,
      insNameAr: this.endorsedData.insNameAr,
      civilId: this.endorsedData.emiratesId,
      companyYn: this.endorsedData.customerType,
      mapId: "ENDORSE_SCR1"
    }
    this.agentService.updateEndorsedInfo(obj)
      .subscribe(result => {
      });

    if (this.lobCode == '01') {
      this.updateVehcleInfo();
    }
    else if (this.lobCode == '08') {

      this.updateTravelInfo();
    }

  }

  updateVehcleInfo() {
    this.agentService.updateVehicleInfo(this.VehicleInfoForm.value)
      .subscribe(result => {
        this.insertAdditionalDriverInfo();
      });
  }

  updateTravelInfo() {
    this.arr.push(this.TravelInforForm.value);
    this.agentService.insertTravelInfo(this.arr)
      .subscribe(result => {
        /* if("approve"== mode){
             this.endtProceedtoBuy()
         }else{
           this.router.navigate(['agent-dashboard']);
         }*/
      });
  }
  insertAdditionalDriverInfo() {
    let arr = [];
    for (var i = 0; i < this.driverForm.get('itemRows').value.length; i++) {
      this.driversInfo = this.driverForm.get('itemRows').value[i];
      this.driversInfo.transId = this.transId;
      this.driversInfo.tranSrNo = this.transSNo;
      arr.push(this.driversInfo);
    }
    this.agentService.insertAdditionalDriverInfo(arr)
      .subscribe(result => {
      });
  }


  submitForm(type) {
    // const controlArray = <FormArray> this.TravelInforForm.get('travelRows');
    // const controlArrayChild = <FormArray> this.TravelInforForm.get('childRows');

    // this.travelInfo = this.TravelInforForm.value;
    // this.adultError=false;
    // if(this.travelInfo.travelRows.length > 0){
    //   for (var i = 0; i < this.travelInfo.travelRows.length; i++) {
    //     if(controlArray.controls[i].get('name').value == "" || controlArray.controls[i].get('name').value == null){
    //       this.adultError=true;
    //       controlArray.controls[i].get('nameErrMsg').setValue('Enter Name');      
    //     }else if( !this.adultError && (controlArray.controls[i].get('travelRelation').value == "" || controlArray.controls[i].get('travelRelation').value == null)){
    //      this.adultError=true;
    //      controlArray.controls[i].get('relErrMsg').setValue('Enter relation');   
    //    }else  if(!this.adultError && (controlArray.controls[i].get('dateOfBirth').value == "" || controlArray.controls[i].get('dateOfBirth').value == null)){
    //      this.adultError=true;
    //      controlArray.controls[i].get('dobErrMsg').setValue('Enter DateOfBirth'); 
    //    }else if( !this.adultError && (controlArray.controls[i].get('passport').value == "" || controlArray.controls[i].get('passport').value == null)){
    //      this.adultError=true;
    //      controlArray.controls[i].get('passErrMsg').setValue('Enter PassportNo');   
    //    }

    //  }
    // }

    // if(this.travelInfo.childRows.length > 0 && !this.adultError){

    //   for (var i = 0; i < this.travelInfo.childRows.length; i++) {
    //     if(controlArrayChild.controls[i].get('name').value == "" || controlArrayChild.controls[i].get('name').value == null){
    //       this.adultError=true;
    //     }else{
    //      this.adultError=false;
    //     }
    //     if(controlArrayChild.controls[i].get('travelRelation').value == "" || controlArrayChild.controls[i].get('travelRelation').value == null){
    //      this.adultError=true;
    //    }
    //    else{
    //      this.adultError=false;
    //    }
    //    if(controlArrayChild.controls[i].get('dateOfBirth').value == "" || controlArrayChild.controls[i].get('dateOfBirth').value == null){
    //      this.adultError=true;
    //    }
    //    else{
    //      this.adultError=false;
    //    }
    //    if(controlArrayChild.controls[i].get('passport').value == "" || controlArrayChild.controls[i].get('passport').value == null){
    //      this.adultError=true;
    //    }
    //    else{
    //      this.adultError=false;
    //    }
    //   }

    // }

    if (this.changeOwnershipForm.valid) {
      this.endorsedData = this.changeOwnershipForm.value;

      if (type == 'save') {

        this.updateData(this.endorsedData);
        this.router.navigate(['agentdashboard']);
      }
      else if (type == 'approve') {
        this.updateData(this.endorsedData);
        const obj = {
          transId: this.transId,
          tranSrNo: this.transSNo,
          userId: this.session.get("username")
        }
        this.agentService.proceedToBuyEndorsement(obj)
          .subscribe(result => {
            let obj = { "transId": this.transId, "tranSrNo": this.transSNo, "policyNo": this.policyNo };
            this.router.navigate(['endtconfirmation'], { queryParams: obj, skipLocationChange: true });
          });

      }
    } else {
      this.validateAllFormFields(this.changeOwnershipForm);
    }

  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.transSNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }

  convertYear(jsonDate) {
    return jsonDate.date.year;
  }
  convertMonth(jsonDate) {
    return jsonDate.date.month - 1;
  }
  convertDay(jsonDate) {
    return jsonDate.date.day;
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  sortedArray(tmpArr: any) {
    return tmpArr.sort((n1, n2) => {
      if (n1.desc > n2.desc) {
        return 1;
      }

      if (n1.desc < n2.desc) {
        return -1;
      }
      return 0;
    });
  }
}
