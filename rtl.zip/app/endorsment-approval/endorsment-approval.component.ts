import { Component, OnInit } from "@angular/core";
import { UntypedFormBuilder } from "@angular/forms";
import { AgentUserService } from "src/shared/services/agent-user.service";

@Component({
    selector: 'app-endorsment-approval',
    templateUrl: './endorsment-approval.component.html',
    styleUrls: ['endorsment-approval.component.scss']
})
export class EndorsmentApprovalComponent implements OnInit {

    requestInfoForm: any;
    transId: string;
    detailedPolicyData: any;
    documents: any[];
    constructor(private fb: UntypedFormBuilder,
        private agentService: AgentUserService) {
    }

    ngOnInit(): void {
        this.documents = [{
            fileName: 'file naem one is one.png',
            docType: 'IIMG',
            remarks: 'license image',
            uploadedOn: new Date(),
            uploadedBy: 'Katherine'
        },
        {
            fileName: 'file naem two is one.png',
            docType: 'IIMG',
            remarks: 'license image with long remarks. this is really a big remarks compared with previous one. this is not enough to test the large string values that is why i am growing. license image with long remarks. this is really a big remarks compared with previous one. this is not enough to test the large string values that is why i am growing. ',
            uploadedOn: new Date(),
            uploadedBy: 'Katherine'
        }
        ];

        this.requestInfoForm = this.fb.group({
            policyNo: ['', { disabled: true }],
            transType: ['', { disabled: true }],
            reqBy: ['', { disabled: true }],
            reqOn: ['', { disabled: true }],
            type: ['', { disabled: true }],
            reason: ['', { disabled: true }],
            remarks: ['', { disabled: false }]
        });
    }

    // Fetch request Details
    // getRequestDetails() {
    //     this.agentService.getRequestDetails(this.transId, this.trans)
    //     .subscribe(
    //         res => {
    //             this.setFormValues(res.form);
    //         },
    //         err => {
    //             // Error handle
    //         }
    //     );
    // }

    // Update values
    setFormValues(value) {
        this.requestInfoForm.patchValue(value);
    }
    viewDetails(){
        
    }
    // view policy details
    // viewDetails() {
    //     this.agentService.getPolicyDetailedView(this.transId)
    //     .subscribe(
    //         res => {
    //             this.detailedPolicyData = res.policyData;
    //         },
    //         err => {
    //             // Error handle
    //         }
    //     );
    // }

    // Approve the policy
    approve() {

    }

    // Reject the policy
    reject() {

    }

    // Navigate to the documents page.
    viewDocs() {

    }

}
