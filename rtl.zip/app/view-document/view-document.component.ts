import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { AgentUserService } from "../../shared/services/agent-user.service";

@Component({
  selector: 'app-view-document',
  templateUrl: './view-document.component.html',
  styleUrls: ['./view-document.component.scss']
})
export class ViewDocumentComponent implements OnInit {

  viewdocuments: any;
  dmsTypeList: any;
  file: File;
  docCodeValue;
  policyNo;
  reportType;
  transId;
  tranSrNo;
  lobCode;
  page;
  photoName: any;
  allowedExtensions: any = [];
  fileExtension: any;
  fileExtensionError: boolean = false;
  fileExtensionMessage: any;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';

  constructor(
    private agentService: AgentUserService,
    private session: SessionStorageService,
    private messageService: MessageService
  ) { }

  ngOnInit() {
    debugger;
    this.policyNo = this.agentService.getParamValue('policyNo');
    this.reportType = this.agentService.getParamValue('reportType');
    this.transId = this.agentService.getParamValue('transId');
    this.tranSrNo = this.agentService.getParamValue('tranSrNo');
    this.lobCode = this.agentService.getParamValue('lobCode');
    this.page = this.agentService.getParamValue('page');
    this.getDMSTypeList();
    this.getDocument();
  }

  getDocument() {
    var params = { "trans_Id": this.transId, "typeOfReport": this.reportType, "userId": this.session.get("username") };
    let arr = [];
    this.agentService.getDocInfoByType(params)
      .subscribe(result => {
        for (let i = 0; i < result.documentInfoList.length; i++) {
          let docTrans_Idx = result.documentInfoList[i].docTrans_Idx;
          let docRefNo = result.documentInfoList[i].docRefNo;
          let docType = result.documentInfoList[i].docType;
          let docName = result.documentInfoList[i].docName;
          let docUrl = result.documentInfoList[i].docUrl;
          let docCreatedUser = result.documentInfoList[i].docCreatedUser;
          let docCreatedDate = result.documentInfoList[i].docCreatedDate;
          let object = {
            docTrans_Idx: docTrans_Idx, docRefNo: docRefNo, docType: docType, docName: docName,
            docUrl: docUrl, docCreatedUser: docCreatedUser, docCreatedDate: docCreatedDate, policyNo: this.policyNo
          };
          arr.push(object);
        }
        this.viewdocuments = arr;
      });

  }

  getFileUrl(url) {
    var params = { "fileUrl": url, "userRole": this.session.get("USER_ROLE_ID") };
    var Url;
    this.agentService.getFileUrl(params)
      .subscribe(result => {
        Url = result.fileUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
      width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(Url, 'Document View', param);
      });

  }

  getDMSTypeList() {
    var params = { "type": this.reportType };
    this.agentService.getDMSTypeList(params)
      .subscribe(result => {
        this.dmsTypeList = result.dmsTypeList;
      });
  }

  uploadDocuments(event: any) {
    //this.getDocumentCodeBeforeUpload(event.target.id);
    const fileList: FileList = event.target.files;
    var fileDetail = event.target.files[0];
    this.photoName = fileDetail.name;
    this.allowedExtensions = ["jpeg", "jpg", "bmp", "gif", "png", "pdf"];
    this.fileExtension = this.photoName.split('.').pop();

    if (this.isInArray(this.allowedExtensions, this.fileExtension)) {
      this.fileExtensionError = false;
      this.fileExtensionMessage = "";
    } else {
      this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
      this.fileExtensionError = true;
      alert(this.fileExtensionMessage);
      return;
    }
    if (fileList.length > 0) {
      this.file = fileList[0];
      var reader = new FileReader();
      var that = this;
      reader.onload = function () {
        that.upload(event);
      }
      reader.readAsDataURL(fileList[0]);
    }
  }

  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('lobCode', this.lobCode);
    formData.append('docCode', this.docCodeValue);
    formData.append('docType', "POL");
    formData.append('userId', this.session.get("username"));
    var uploadDocumentReponse = this.agentService.uploadDocuments(formData).subscribe(data => {
      //this.toastr.success("Uploaded SuccessFully");
      this.messageService.add({ severity: 'success', summary: 'success Message', detail: 'File Uploaded Successfully' });
    });
  }
  getDocCodeValue(event) {
    this.docCodeValue = event.target.value;
  }

  uploaddialog(myModel) {
    myModel.className = 'modal show';
    //this.modalService.open(myModel, { size: 'lg' }); 
  }
  closemodel() {
    this.getDocument();
    //location.reload(true);
  }

  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }
}