import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-footer',
  templateUrl: './agent-footer.component.html',
  styleUrls: ['./agent-footer.component.scss']
})
export class AgentFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
