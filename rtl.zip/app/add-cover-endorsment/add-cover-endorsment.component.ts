import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { HomeInsurancePlanService } from 'src/app/home/services/home-insurance-plan.service';
import { ApplicationConstants } from 'src/shared/application-constants';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { LoaderService } from 'src/shared/loader-service/loader.service';

@Component({
  selector: 'add-cover-endorsment',
  templateUrl: './add-cover-endorsment.component.html',
  styleUrls: ['./add-cover-endorsment.component.scss']
})
export class AddCoverEndorsmentComponent implements OnInit {
  enableCompany: boolean;
  editFlag: boolean;
  prodCode: any;
  schCode: any;
  reportType: any = 'POL';
  coverSumArry: any[] = [];
  totalPrem: any;
  addlCoverInfoList: any[] = [];
  coverInfo: any;
  CustomerInfoForm: UntypedFormGroup;
  VehicleInfoForm: UntypedFormGroup;
  travelersInfo: UntypedFormGroup;
  HomeInfoForm: UntypedFormGroup;
  netPremium: any;
  vechileShape: any;
  plateTypes: any;
  optionalCovers: any;
  sumInclusiveMandatory: any[] = [];
  vehicleInfo: any;
  travelDetailsinfo: any;
  customerInfo: any;
  endorseType: any;
  quoteNo: any;
  lobCode: any;
  transSNo: any;
  transId: any;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';


  customerTypes = [
    { id: "0", value: "Individual" },
    { id: "1", value: "Company" }
  ]

  constructor(
    private router: Router,
    public route: ActivatedRoute,
    private homeInsurancePlanService: HomeInsurancePlanService,
    private agentService: AgentHttpclientService,
    private messageService: MessageService,
    private commonService: AgentUserService, private fb: UntypedFormBuilder,
    private session: SessionStorageService,
    private loaderService: LoaderService) { }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.transSNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    this.endorseType = this.commonService.getParamValue('endType');
    this.schCode = this.commonService.getParamValue('schCode');
    this.prodCode = this.commonService.getParamValue('prodCode');

    // this.policyCancelForm = this.createFormGroup();
    this.getEndorsementDetails();
    if (this.endorseType == '004') {
      this.getCoverSummary();
    } else if (this.endorseType == '005') {
      this.getDelCoverSumm();
    }

    this.getPlateType();
    this.getVehicleShape();
    this.getAgentNetPremium();
    this.createForm();
    this.getAdditionalCoverInfo()
  }

  createForm() {
    this.CustomerInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.transSNo,
      transRemark: [, Validators.required],
      userId: this.session.get("username"),
      custCode: this.session.get("agent"),
      portal: this.session.get("portaltype"),
      taxRefNo: [],
      insName: '',
      mapId: 'END_CUS_INFO_UDATE',
      companyYn: '',
      civilId: '',
      customerType: ''
    });
    this.VehicleInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.transSNo,
      userId: this.session.get("username"),
      mapId: 'END_VEHICLE_INFO_UDATE',
      chassisNo: ['', Validators.required],
      engineNo: '',
      regnNo: '',
      licenceNo: '',
      trafficLoc: ['', Validators.required],
      tcfNo: ['', Validators.required],
      orangeCardNo: '',
      aaaCardNo: '',
      vehColor: '',
      financedYn: '',
      driverList: this.fb.array([])
    });

    this.HomeInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.transSNo,
      userId: this.session.get("username"),
      mapId: 'END_BULDING_INFO_UDATE',
      bldngAge: '',
      bldngType: '',
      zoneArea: '',
      city: '',
      streetBlock: '',
      poBox: ['', Validators.required],
      address: ['', Validators.required],
      address1: '',
      financedBank: '',
      financedBankYn: ''
    });

    this.travelersInfo = this.fb.group({
      adultinfo: this.fb.array([]),
      childinfo: this.fb.array([]),
    });

  }


  getEndorsementDetails() {
    this.loaderService.isBusy = true;
    let params = { "trans_Id": this.transId, "trans_Sno": this.transSNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {
        //  if (!Validator.validateString(endorsement.getCustomerType()) || !Validator.validateString(endorsement.getCivilId()))
        // editCustType = true;
        this.customerInfo = result.customerInfo;
        if (this.customerInfo.companyYn == null || this.customerInfo.civilId == null) {
          this.editFlag = false;
        }
        else if (this.customerInfo.companyYn == '1') {

          this.editFlag = true;
          if (this.customerInfo.companyYn == '0') {
            this.customerInfo.companyType = 'Individual';
          } else {
            this.customerInfo.companyType = 'Company';
          }
          // this.customerInfo.companyType = 'Company';
        }

        this.travelDetailsinfo = result.travelInfo;
        this.vehicleInfo = result.vehicleInfo;
        this.CustomerInfoForm.patchValue({
          insName: this.customerInfo.insName,
          // transRemark:this.customerInfo.transRemark,
          companyYn: this.customerInfo.companyYn
        });

        this.loaderService.isBusy = false;
      });
  }
  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.transSNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            this.sumInclusiveMandatory.push(array[i]);
          }
          else {
            this.optionalCovers.push(array[i]);
          }
        }
      });
  }



  getPlateType() {
    let params = { "type": "PLATE_CHAR" }
    this.agentService.getPlateType(params).subscribe(result => {
      this.plateTypes = result;
    })
  }
  getVehicleShape() {
    let params = { "type": "MOT_QCB_SHAP" }
    this.agentService.VechicleShape(params).subscribe(result => {
      this.vechileShape = result;
    })
  }

  getAgentNetPremium() {
    this.agentService.getAgentNetPremium({ "transId": this.transId, "tranSrNo": this.transSNo }).subscribe(result => {
      this.netPremium = result.PREMIUM;
    })
  }

  getAdditionalCoverInfo() {
    let totPrem: any = 0.00;
    let param = { "transId": this.transId, "tranSrNo": this.transSNo };
    this.agentService.getAddlCoverInfo(param)
      .subscribe(response => {
        var array = response["coverList"];
        for (var i = 0; i < array.length; i++) {
          if (array[i].PPI_INCLUDE_YN === '1')
            totPrem = +array[i].PPI_PREMIUM;
          this.addlCoverInfoList.push(array[i]);
        }
        this.totalPrem = totPrem;
      });
  }

  addRemoveCoverInfo(coverId, event) {
    var isenable = 0;
    if (event.target.checked) {
      isenable = 1;
    }
    let param = {
      "transId": this.transId,
      "tranSrNo": this.transSNo,
      "value": isenable,
      "refCode": coverId
    };
    this.agentService.addRemoveCover(param).subscribe(resp => {
      this.totalPrem = resp.totalPremium;
    })

  }
  proceedEndorsement() {
    if (this.CustomerInfoForm.valid) {
      this.loaderService.isBusy = true;
      this.agentService.updateInsuredInfo(this.CustomerInfoForm.value)
        .subscribe(result => {
          if (result.respCode == 2000) {
            let obj = {
              transId: this.transId,
              tranSrNo: this.transSNo,
              userId: this.session.get("agent"),
              endType: this.endorseType
            }
            this.agentService.endtProceedtoBuy(obj)
              .subscribe(result => {
                if (this.endorseType == '004') {
                  this.router.navigate(['addcoverendtsummary'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.transSNo, 'policyNo': this.customerInfo.policyNo, 'lobCode': ApplicationConstants.LOB_MOTOR, 'endType': this.endorseType, 'reportType': this.reportType }, skipLocationChange: true });
                } else {
                  this.router.navigate(['addcoverendtconfirm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.transSNo, 'policyNo': this.customerInfo.policyNo, 'lobCode': ApplicationConstants.LOB_MOTOR, 'endType': this.endorseType }, skipLocationChange: true });
                }
                this.loaderService.isBusy = false;
              });
            //this.router.navigate(['add-cover-summary'],{queryParams:{'transId':this.transId,'tranSrNo':this.transSNo,'policyNo':this.customerInfo.policyNo,'lobCode':ApplicationConstants.LOB_MOTOR,'endType': this.endorseType}});
          }
        });
    } else {
      this.validateAllFormFields(this.CustomerInfoForm);
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  getDelCoverSumm() {
    let totPrem: any = 0.00;
    let param = { "transId": this.transId, "tranSrNo": this.transSNo };
    this.agentService.getDelCoveSumm(param)
      .subscribe(response => {
        var array = response["coverList"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].PPI_INCLUDE_YN === '1')
            totPrem = +array[i].PPI_PREMIUM;
          this.coverSumArry.push(array[i]);
        }
        this.totalPrem = totPrem;
      });
  }


  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.transSNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }
  updateCompany(customerType) {
    //alert("customerType issss"+customerType);
    if (customerType == '1') {
      this.enableCompany = true;
    }
    else {
      this.enableCompany = false;
    }
  }
}
