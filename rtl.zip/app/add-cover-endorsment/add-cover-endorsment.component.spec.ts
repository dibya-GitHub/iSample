import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCoverEndorsmentComponent } from './add-cover-endorsment.component';

describe('AddCoverEndorsmentComponent', () => {
  let component: AddCoverEndorsmentComponent;
  let fixture: ComponentFixture<AddCoverEndorsmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddCoverEndorsmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCoverEndorsmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
