import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SessionStorageService } from 'angular-web-storage';
import { ApplicationConstants } from 'src/shared/application-constants';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { LoaderService } from 'src/shared/loader-service/loader.service';
@Component({
  selector: 'app-add-cover-confirm-end',
  templateUrl: './add-cover-confirm-end.component.html',
  styleUrls: ['./add-cover-confirm-end.component.scss']
})
export class AddCoverConfirmEndComponent implements OnInit {
  premCoverInfo: any;
  taxcover: any[] = [];
  quoteNo: any;
  endType: any;
  addlCoverInfoList: any[] = [];
  optionalCovers: any[] = [];
  sumInclusiveMandatory: any[] = [];
  customerInfo: any;
  policyNo: any;
  lobCode: any;
  tranSrNo: any;
  transId: any;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  polTaxList: Array<any>
  editFlag: any;
  reportType: string;
  policyTaxUpadateFrm: UntypedFormGroup;
  public flag: string = "";
  constructor(
    private router: Router,
    public route: ActivatedRoute,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private fb: UntypedFormBuilder,
    private session: SessionStorageService,
    private loaderService: LoaderService,
    private modalService: NgbModal) { }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    this.endType = this.commonService.getParamValue('endType');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.reportType = this.commonService.getParamValue('reportType');
    this.getCoverSummary();
    this.getOptionalCover();
    this.getPremCoverInfo();
    this.getTaxCover();
    this.getEditTaxFlag();
    ///this.updateTaxForm();
  }
  updateTaxForm(polTax, comTax) {
    this.policyTaxUpadateFrm = new UntypedFormGroup({
      agentTaxfc: new UntypedFormControl(comTax),
      poilcytaxFc: new UntypedFormControl(polTax)
    });
  }

  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            this.sumInclusiveMandatory.push(array[i]);
          }
        }
      });
  }

  getOptionalCover() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getOptionalCover(param).subscribe(response => {
      var array = response["optionalList"];
      let j = 0;
      var permiumRange = 0;
      for (var i = 0; i < array.length; i++) {
        this.optionalCovers.push(array[i]);
      }
    });
  }


  getTaxCover() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getTaxCover(param).subscribe(response => {
      var array = response["Taxlist"];
      let j = 0;
      var permiumRange = 0;
      for (var i = 0; i < array.length; i++) {
        this.taxcover.push(array[i]);
      }
    });
  }
  getPremCoverInfo() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getPremCoverInfo(param).subscribe(response => {
      this.premCoverInfo = response;
      /* var array =  response["PremiumList"];
       for (var i = 0; i < array.length; i++) {
             this.premCoverInfo.push(array[i]);
         }*/
    });
  }


  ConfirmEndorsement() {
    this.loaderService.isBusy = true;
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      userId: this.session.get("agent"),
      endType: this.endType
    }
    this.agentService.endProceedToConfirm(obj)
      .subscribe(result => {
        let params = { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'policyNo': this.policyNo, 'lobCode': ApplicationConstants.LOB_MOTOR, 'endType': this.endType }
        this.router.navigate(['endtconfirmation'], { queryParams: params, skipLocationChange: true });
        this.loaderService.isBusy = false;
      });
    //this.router.navigate(['add-cover-summary'],{queryParams:{'transId':this.transId,'tranSrNo':this.transSNo,'policyNo':this.customerInfo.policyNo,'lobCode':ApplicationConstants.LOB_MOTOR,'endType': this.endorseType}});
  }

  back() {
    let params = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      lobCode: this.lobCode,
      endType: this.endType,
      reportType: this.reportType
    }
    if (this.endType == '004' || this.endType == '017') {
      this.router.navigate(['addcoverendtsummary'], { queryParams: params, skipLocationChange: true });
    } else {
      this.router.navigate(['addcoverendt'], { queryParams: params, skipLocationChange: true });
    }

  }

  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }

  openLg(content) {
    this.modalService.open(content, { size: 'lg', backdrop: 'static', keyboard: true });
    this.loadPolicyTax();
  }

  loadPolicyTax() {
    let agentTaxFc;
    let policytaxFc;
    let params = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.agentService.getPolicyTax(params)
      .subscribe(result => {
        this.polTaxList = result.Taxlist;
        for (var i = 0; this.polTaxList.length > i; i++) {
          if (this.polTaxList[i].QPTTYPE == 'ACOMM') {
            agentTaxFc = this.polTaxList[i].QPTVALUEFC;
          } else {
            policytaxFc = this.polTaxList[i].QPTVALUEFC;
          }

        }
        this.updateTaxForm(policytaxFc, agentTaxFc);
      });

  }

  saveOrEditTax() {

  }
  getEditTaxFlag() {
    let params = {
      userId: this.session.get('username')
    }
    this.agentService.getEditFlagTax(params).subscribe(resp => {
      this.editFlag = resp.editFlag;
    });
  }
}
