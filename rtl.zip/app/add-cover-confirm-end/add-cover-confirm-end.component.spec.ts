import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCoverConfirmEndComponent } from './add-cover-confirm-end.component';

describe('AddCoverConfirmEndComponent', () => {
  let component: AddCoverConfirmEndComponent;
  let fixture: ComponentFixture<AddCoverConfirmEndComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddCoverConfirmEndComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCoverConfirmEndComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
