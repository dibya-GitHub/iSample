import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-p-craft-confirmation',
  templateUrl: './p-craft-confirmation.component.html',
  styleUrls: ['./p-craft-confirmation.component.scss']
})
export class PCraftConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
