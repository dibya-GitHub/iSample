import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PCraftConfirmationComponent } from './p-craft-confirmation.component';

describe('PCraftConfirmationComponent', () => {
  let component: PCraftConfirmationComponent;
  let fixture: ComponentFixture<PCraftConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PCraftConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PCraftConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
