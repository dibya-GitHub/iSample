import { Component, Inject, OnInit } from "@angular/core";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { NgbModal, NgbModalConfig } from "@ng-bootstrap/ng-bootstrap";
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from "primeng/api";
import { zip } from 'rxjs';
import { AgentHttpclientService } from "src/app/services/agent-httpclient.service";
import { ErrorMessage } from "src/shared/error-message";
import { LoaderService } from "src/shared/loader-service/loader.service";
import { AgentUserService } from "src/shared/services/agent-user.service";
import { Tooltip } from "src/shared/tool-tip";
import { ApiConstants } from './../../../shared/api-constants';

@Component({
   selector: 'app-p-craft-additional-info',
   templateUrl: './p-craft-additional-info.component.html',
   styleUrls: ['./p-craft-additional-info.component.scss'],
   providers: [NgbModalConfig, NgbModal]
})
export class PCraftAdditionalInfo implements OnInit {
   pCraftAdditionalForm: UntypedFormGroup;
   public tooltipMessage = new Tooltip();
   public Err_msg = new ErrorMessage();
   titleAlert: string = 'This field is required';

   portOfRegistryInfo: any[];
   motorEngineInfo: any[];
   CrusingAreaInfo: any[];
   vesselDinghies: string;
   cityInfo: any[];
   occupationInfo: any[];
   nationallityInfo: any[];
   transId: any;
   tranSrNo: any;
   prodCode: any;
   schCode: any;
   lobCode = ApiConstants.MARINE_HULL_LOBCODE;
   agentAuthDetails: any;
   isDetEnable: boolean;
   isDisEnable: boolean;
   isLoadEnable: boolean;
   isFeeEnable: boolean;
   driverEnable: boolean;
   agentCode: string = this.session.get("agent");
   userFilter: any = this.session.get("userFilter");

   constructor(
      private fb: UntypedFormBuilder,
      private agentService: AgentHttpclientService,
      private commonService: AgentUserService,
      private router: Router,
      private messageService: MessageService,
      private loaderService: LoaderService,
      private session: SessionStorageService
   ) { }
   ngOnInit() {
      this.loaderService.isBusy = true;
      this.transId = this.commonService.getParamValue('transId');
      this.tranSrNo = this.commonService.getParamValue('tranSrNo');
      this.lobCode = this.commonService.getParamValue('lobCode');
      this.prodCode = this.commonService.getParamValue('prodCode');
      this.schCode = this.commonService.getParamValue('schCode');
      this.createForm();
      this.getCraftAdditionalInfo();
      this.getAgentAuthDtls();

   }
   createForm() {
      this.pCraftAdditionalForm = this.fb.group({
         // pleasure craft Additional Information of Yatch

         vesselName: ['', Validators.required],
         regNo: ['', Validators.required],
         motorEngin: [undefined, Validators.required],
         builderName: [''],
         vesselDinghies: [''],
         engineCapacity: ['', Validators.required],
         engineNo: ['', Validators.required],
         portOfRegistry: [undefined, Validators.required],
         crusingArea: [undefined, Validators.required],
         makeOfMainEngine: [''],
         noOfEngines: ['', Validators.required],
         //Additional Customer Details
         address1: [''],
         poBox: [''],
         occupation: [''],
         city: [''],
         nationality: [''],
         cardRefNo: [''],
      });
   }
   getAgentAuthDtls() {
      let param = {
         "groupCode": this.userFilter.CUST_GROUP_CODE,
         "transId": this.transId,
         "tranSrNo": this.tranSrNo,
         "agentCode": this.agentCode
      };
      this.agentService.getAgentAuthDtls(param)
         .subscribe(result => {
            this.agentAuthDetails = result;
            if (result.DED_ENABLE == "1")
               this.isDetEnable = true;
            if (result.DISC_ENABLE == '1')
               this.isDisEnable = true;
            if (result.LOAD_ENABLE == "1")
               this.isLoadEnable = true;
            if (result.FEES_ENABLE)
               this.isFeeEnable = true
            if (result.DRV_ENABLE == "1")
               this.driverEnable = true;
            this.loaderService.isBusy = false;

         }, error => {
            this.loaderService.isBusy = false;

         })
   }
   onClickAdditionalFormSubmit() {
      if (this.pCraftAdditionalForm.valid) {

         this.loaderService.isBusy = true;
         const yatchDataForm = new FormData();
         let data = this.pCraftAdditionalForm.getRawValue();
         const updateInsData = {
            cardRefNo: data.cardRefNo,
            address1: data.address1,
            poBox: data.poBox,
            city: data.city,
            nationality: data.nationality,
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            mapId: "PL_CRAFT_AGENT_POL_SCR_2"
         };
         this.agentService.updateInsuredInfo(updateInsData).subscribe(updatedInfoResponse => {
            const updateBoatData = {
               transId: this.transId,
               tranSrNo: this.tranSrNo,
               mapId: "PL_CRAFT_AGENT_RISK_SCR_2",
               vesselName: data.vesselName,
               engineNo: data.engineNo,
               regNo: data.regNo,
               portOfRegistry: data.portOfRegistry,
               motorEngin: data.motorEngin,
               crusingArea: data.crusingArea,
               engineCapacity: data.engineCapacity,
               noOfEngines: data.noOfEngines,
               vesselDinghies: data.vesselDinghies,
               makeOfMainEngine: data.makeOfMainEngine
            };

            this.agentService.updateBoatInfo(updateBoatData).subscribe(updateBoatInfoResponse => {
               const obj = {
                  transId: this.transId,
                  tranSrNo: this.tranSrNo,
                  lobCode: this.lobCode,
                  quoteNo: this.session.get('quoteNo')
               }
               this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
               this.loaderService.isBusy = false;

            }, error => {
               this.loaderService.isBusy = false;
            })
         }, error => {
            this.loaderService.isBusy = false;
         })

      } else {
         this.loaderService.isBusy = false;
         this.validateAllFormFields(this.pCraftAdditionalForm);
      }
   }
   getQuoteData() {
      let params = {
         transId: this.transId,
         tranSrNo: this.tranSrNo,
         mapId: "PL_CRAFT_AGENT_POL_SCR_1"
      };
      // this.getCraftAdditionalInfo();
      this.agentService.getBasicInfo(params).subscribe((getQuotedata: any) => {

         this.pCraftAdditionalForm.patchValue({
            vesselName: getQuotedata.vesselName,
            engineNo: getQuotedata.engineNo,
            regNo: getQuotedata.regNo,
            engineCapacity: getQuotedata.engineCapacity,
            noOfEngines: getQuotedata.noOfEngines,
            vesselDinghies: getQuotedata.vesselDinghies,
            makeOfMainEngine: getQuotedata.makeOfMainEngine
         });
         this.pCraftAdditionalForm.get('portOfRegistry').setValue(getQuotedata.portOfRegistry);
         this.pCraftAdditionalForm.get('motorEngin').setValue(getQuotedata.typeOfEngine);
         this.pCraftAdditionalForm.get('crusingArea').setValue(getQuotedata.crusingArea);
      });
      this.agentService.getQuoteInformation(params).subscribe((data: any) => {
         this.pCraftAdditionalForm.patchValue({
            address1: data.address,
            poBox: data.poBox,
            cardRefNo: data.cardRefNo
         });
         this.pCraftAdditionalForm.get('occupation').setValue(data.occupation);
         this.pCraftAdditionalForm.get('city').setValue(data.city);
         this.pCraftAdditionalForm.get('nationality').setValue(data.nationality);
         this.loaderService.isBusy = false;
      });
   }
   validateAllFormFields(formGroup: UntypedFormGroup) {
      window.scrollTo(0, 0);
      this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
      Object.keys(formGroup.controls).forEach(field => {
         const control = formGroup.get(field);
         if (control instanceof UntypedFormControl) {
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
         } else if (control instanceof UntypedFormGroup) {
            this.validateAllFormFields(control);
         }
      });
   }
   getCraftAdditionalInfo() {
      zip(
         this.agentService.getApplicationCodes('REG_PORT'),
         this.agentService.getApplicationCodes('HULL_ENGINE'),
         this.agentService.getApplicationCodes('HULL_AREA'),
         this.agentService.getApplicationCodes('NATIONALITY'),
         this.agentService.getApplicationCodes('OCCUPATION'),
         this.agentService.getApplicationRefCodes('STATE', '002'),
      ).subscribe(([reg_port, hull_engine, hull_area, nationallity, occupation, city]: any) => {
         this.portOfRegistryInfo = reg_port.appCodesArray;
         this.motorEngineInfo = hull_engine.appCodesArray;
         this.CrusingAreaInfo = hull_area.appCodesArray;
         this.nationallityInfo = nationallity.appCodesArray;
         this.occupationInfo = occupation.appCodesArray;
         this.cityInfo = city.appCodesArray;
         if (this.transId != undefined && this.transId != undefined) {
            this.getQuoteData();
         }
      })

   }
   goToSchemePage() {
      let obj = {
         transId: this.transId,
         tranSrNo: this.tranSrNo,
         lobCode: this.lobCode
      };
      if (this.lobCode == "06") {
         this.router.navigate(['scheme'], { queryParams: obj, skipLocationChange: true });
      }
   }
}
