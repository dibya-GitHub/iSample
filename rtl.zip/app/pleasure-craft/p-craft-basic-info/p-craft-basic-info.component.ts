import { Component, OnInit } from "@angular/core";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { NgbModal, NgbModalConfig } from "@ng-bootstrap/ng-bootstrap";
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { MessageService } from "primeng/api";
import { zip } from 'rxjs';
import { AgentHttpclientService } from "src/app/services/agent-httpclient.service";
import { ErrorMessage } from "src/shared/error-message";
import { LoaderService } from "src/shared/loader-service/loader.service";
import { AgentUserService } from "src/shared/services/agent-user.service";
import { Tooltip } from "src/shared/tool-tip";
import { ApiConstants } from './../../../shared/api-constants';

@Component({
  selector: 'app-p-craft-basic-info',
  templateUrl: './p-craft-basic-info.component.html',
  styleUrls: ['./p-craft-basic-info.component.scss'],
  providers: [NgbModalConfig, NgbModal]
})
export class PCraftBasicInfoComponent implements OnInit {

  yatchInfoForm: UntypedFormGroup;
  transId: any;
  tranSrNo: any;
  quoteNo: any;
  policyNo: any;
  duration: any;

  public tooltipMessage = new Tooltip();
  public Err_msg = new ErrorMessage();
  date: Date = new Date();
  disableFields: boolean = false;
  titleAlert: string = 'This field is required';
  disableTrailer: string;
  public myDatePickerOptions: IAngularMyDpOptions = {
    inline: false,
    // editableDateField: true,
    // indicateInvalidDate: true,
    // openSelectorOnInputClick: true,
    // showInputField: true,
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    }
  };

  yearsOfBuilt: any[] = [];
  civilIdPatternError: string;
  classificationSocietyInfo: any[];
  hullMarinaInfo: any[];
  tplInfo: any[];
  usageInfo: any[];
  materialOfHull: any[];
  vesselTypeInfo: any[];
  message: any;
  modifyFromDate: boolean = false;
  modifyToDate: boolean = true;
  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private messageService: MessageService,
    private agentService: AgentHttpclientService,
  ) {

  }

  ngOnInit(): void {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.getPolicyDuration();
    this.createForm();
    this.calcyearsOfBuilt();
    this.setDate();
    this.getYachtInfo();
    // this.wizardHelperService.submitFn = async (args: any): Promise<boolean> => {
    //   this.message = args;
    //   return new Promise<boolean>((resolve, reject) => {
    //     this.onSubmit().then(res => {
    //       resolve(res);
    //     })
    //       .catch(err => {
    //         reject(err);
    //       });
    //   });
    // };

  }
  calcyearsOfBuilt() {
    var dt = new Date();
    var date = dt.getFullYear() + 1;
    for (let i = 22; i > 0; --i) {
      this.yearsOfBuilt.push({ code: date - i, desc: date - i });
    }

  }
  createForm() {
    this.yatchInfoForm = this.fb.group({
      customerTypeId: ['', Validators.required],
      assuredName: ['', Validators.required],
      emailId: ['', Validators.email],
      civilId: ['', Validators.compose([Validators.required, Validators.pattern(/^\d{3}-\d{4}-\d{7}-\d{1}$/)])],
      mobileNo: ['', Validators.compose([Validators.required, Validators.pattern(/(^5\d{8}$|^(05)\d{8}$)/)])],
      policyStartDate: [null, Validators.required],
      policyEndDate: [null, Validators.required],

      // pleasure craft
      builtYear: ['', Validators.required],
      passengerCapacity: ['', Validators.required],
      classificationSocity: [''],
      vesselValue: ['', Validators.required],
      hullMaterial: ['', Validators.required],
      vesselUsage: ['', Validators.required],
      marina: ['', Validators.required],
      thirdPartyLimit: ['', Validators.required],
      lengthOA: ['', Validators.required],
      speed: ['', Validators.required],
      vesselType: ['', Validators.required],
      trailer: [undefined, Validators.required],
      trailerVal: ['', Validators.required],
      driverAge: ['', Validators.required],
    });
    this.getAgentFilterInfo();

  }
  setDate(): void {
    var date = new Date();
    var today = new Date();
    var year = today.getFullYear();
    var month = today.getMonth();
    var day = today.getDate();
    var toDate = new Date(year + 1, month + 1, day - 1, 23, 59);
    this.yatchInfoForm.patchValue({
      policyStartDate: new Date(), policyEndDate: toDate
    });
  }

  setTrailerValue(value: string) {
    if (value == "0") {
      this.yatchInfoForm.get('trailerVal').setValue("0");
    } else {
      this.yatchInfoForm.get('trailerVal').setValue("");
    }
  }

  getPolicyDuration() {
    let strPostData = {
      lobCode: ApiConstants.MARINE_HULL_LOBCODE,
    }
    this.agentService.getPolicyDuration(strPostData).subscribe(response => {
      if (response.respCode == 2000) {
        this.duration = response.duration;
      }

    }, (error) => {
      //let errorMsg=JSON.parse(error["_body"]).errMessage;
      let errorMsg = error.error.errMessage;

    });
  }
  updateEndDate(event) {
    var endDate = new Date(event);
    var year = endDate.getFullYear();
    var month = endDate.getMonth();
    var day = endDate.getDate();
    //var toDate = new Date(year + 1, month + 1, day - 1, 23, 59);
    var toDate = new Date(year, (month) + Number(this.duration), day - 1, 23, 59);
    this.yatchInfoForm.patchValue({ policyEndDate: toDate })
  }

  // changeValidation(value: string) {
  //   const type = this.yatchInfoForm.get('civilId');
  //   type.clearValidators();
  //   if (value == "1") {
  //     type.setValidators([Validators.required, Validators.pattern('^[a-zA-Z0-9]+$')]);
  //     this.civilIdPatternError = "Only Alpha Numeric Allowed";
  //   } else {
  //     type.setValidators([Validators.required, Validators.pattern(this.commonService.civilIdLength())]);
  //     this.civilIdPatternError = "Civil Id  should be 18 digits";
  //   }
  //   type.updateValueAndValidity();
  // }
  getYachtInfo() {
    zip(
      this.agentService.getApplicationCodes('HULL_MARINA'),
      this.agentService.getApplicationCodes('VESSEL_TYPE'),
      this.agentService.getApplicationCodes('HULLMATERIAL'),
      this.agentService.getApplicationCodes('HULL_SOCIETY'),

      this.agentService.getApplicationCodes('HULL_USAGE'),
      this.agentService.getApplicationCodes('HULL_TPL'),

    ).subscribe(([hullMarina, vesseltype, materialofhull, classificationsociety, vesselUsage, tpl]: any) => {
      this.hullMarinaInfo = hullMarina.appCodesArray;
      this.vesselTypeInfo = vesseltype.appCodesArray;
      this.materialOfHull = materialofhull.appCodesArray;
      this.classificationSocietyInfo = classificationsociety.appCodesArray;
      this.usageInfo = vesselUsage.appCodesArray;
      this.tplInfo = tpl.appCodesArray;
    })
    if (this.transId != undefined && this.transId != undefined) {
      this.getQuoteData();
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true })
      }
    });
  }
  getQuoteData() {
    let params = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    };
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "mapId": "MOT_AGENT_POL_SCR_1"
    };
    this.agentService.getQuotInfo(obj).subscribe((result: any) => {
      // this.quoteInfo=result;
      this.yatchInfoForm.patchValue({
        assuredName: result.insName,
        customerTypeId: result.customerType,
        civilId: result.civilId,
        mobileNo: result.mobileNo,
        emailId: result.emailId,
        policyStartDate: moment(result.polStartDate, 'DD/MM/YYYY HH:mm').toISOString(),
        policyEndDate: moment(result.polEndDate, 'DD/MM/YYYY HH:mm').toISOString(),

      });
    })
    this.agentService.getBasicInfo(params).subscribe((getQuotedata: any) => {
      let builtValue = parseInt(getQuotedata.builtYear);
      this.yatchInfoForm.patchValue({
        passengerCapacity: getQuotedata.passengerCapacity,
        classificationSocity: getQuotedata.classificationSocity,
        vesselValue: getQuotedata.vesselValue,
        lengthOA: getQuotedata.lengthOA,
        speed: getQuotedata.speed,
        trailer: getQuotedata.trailer,
        trailerVal: getQuotedata.trailerVal,
        driverAge: getQuotedata.driverAge,
        builtYear: builtValue,
        hullMaterial: getQuotedata.hullMaterial,
        vesselUsage: getQuotedata.vesselUsage,
        vesselType: getQuotedata.vesselType,
        marina: getQuotedata.marina,
        thirdPartyLimit: getQuotedata.thirdPartyLimit,
      });
      //this.yatchInfoForm.get('builtYear').setValue(getQuotedata.builtYear);
      /* this.yatchInfoForm.get('builtYear').setValue(getQuotedata.builtYear);
       this.yatchInfoForm.get('hullMaterial').setValue(getQuotedata.hullMaterial);
       this.yatchInfoForm.get('classificationSocity').setValue(getQuotedata.classificationSocity);
       this.yatchInfoForm.get('vesselUsage').setValue(getQuotedata.vesselUsage);
       this.yatchInfoForm.get('marina').setValue(getQuotedata.marina);
       this.yatchInfoForm.get('thirdPartyLimit').setValue(getQuotedata.thirdPartyLimit);
       this.yatchInfoForm.get('vesselType').setValue(getQuotedata.vesselType);*/
    });
  }
  getAgentFilterInfo() {
    let obj = {
      "userRoleId": this.session.get('USER_ROLE_ID'),
      "lobCode": ApiConstants.MARINE_HULL_LOBCODE
    };
    this.agentService.getAgentFilterInfo(obj).subscribe(data => {
      if (data.UAU_FM_DATE_MODIFY_YN && data.UAU_TO_DATE_MODIFY_YN) {
        this.modifyFromDate = ('0' === data.UAU_FM_DATE_MODIFY_YN);
        this.modifyToDate = ('0' === data.UAU_TO_DATE_MODIFY_YN);
      }
    });
  }
  onClickSubmit() {
    if (this.yatchInfoForm.valid) {
      this.loaderService.isBusy = true;
      if (this.transId != null && this.transId != undefined) {
        const yatchDataForm = new FormData();
        let data = this.yatchInfoForm.getRawValue();

        let pStart = moment(this.yatchInfoForm.value.policyStartDate).format('DD/MM/YYYY HH:mm')
        let pEndDate = moment(this.yatchInfoForm.value.policyEndDate).format('DD/MM/YYYY HH:mm')
        const yatchData = {
          builtYear: data.builtYear,
          passengerCapacity: data.passengerCapacity,
          classificationSocityList: data.classificationSocity,
          mobileNo: data.mobileNo,
          polStartDate: pStart,
          polEndDate: pEndDate,
          agentId: this.session.get("agent"),
          mapId: "PL_CRAFT_AGENT_POL_SCR_1",
          insName: data.assuredName.toUpperCase(),
          civilId: data.civilId,
          emailId: data.emailId,
          companyYn: data.customerTypeId,
          transId: this.transId,
          tranSrNo: this.tranSrNo

        };
        if (yatchData.companyYn != '1') {
          yatchData.civilId = this.yatchInfoForm.controls['civilId'].value
        }
        this.agentService.updateInsuredInfo(yatchData).subscribe(updatedInfoResponse => {
          const updateBoatInfoData = {
            builtYear: data.builtYear,
            passengerCapacity: data.passengerCapacity,
            classificationSocity: data.classificationSocity,
            vesselValue: data.vesselValue,
            hullMaterial: data.hullMaterial,
            vesselUsage: data.vesselUsage,
            marina: data.marina,
            thirdPartyLimit: data.thirdPartyLimit,
            lengthOA: data.lengthOA,
            speed: data.speed,
            vesselType: data.vesselType,
            trailer: data.trailer,
            trailerVal: data.trailerVal,
            driverAge: data.driverAge,
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            mapId: "PL_CRAFT_AGENT_RISK_SCR_1"
          };
          this.agentService.updateBoatInfo(updateBoatInfoData).subscribe(updateBoatInfoResponse => {

            const obj = {
              transId: this.transId,
              tranSrNo: this.tranSrNo,
              userId: this.session.get("username"),
              portal: ApiConstants.PORTAL,
              lobCode: ApiConstants.MARINE_HULL_LOBCODE
            };
            this.agentService.calculatePricing(obj).subscribe(calculatePricingData => {

              this.loaderService.isBusy = false;
              if (calculatePricingData.respCode == 2000) {
                let schemeObj = {
                  transId: this.transId,
                  tranSrNo: this.tranSrNo,
                  lobCode: ApiConstants.MARINE_HULL_LOBCODE
                };
                this.router.navigate(['scheme'], { queryParams: schemeObj, skipLocationChange: true });
                this.loaderService.isBusy = false;
              }
            }, error => {

              let errorMsg = error.error.errMessage;
              let obj = {}
              if (this.tranSrNo > 0) {
                obj = {
                  "transId": this.transId,
                  "tranSrNo": this.tranSrNo,
                  "policyNo": this.policyNo,
                  "quoteNo": this.quoteNo,
                  "errorMsg": errorMsg
                };
              }
              else {
                obj = {
                  "transId": this.transId,
                  "tranSrNo": this.tranSrNo,
                  "quoteNo": this.quoteNo,
                  "errorMsg": errorMsg
                };
              }
              this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
              this.loaderService.isBusy = false;
            });

          }, error => {
            this.loaderService.isBusy = false;
          })
        }, error => {
          this.loaderService.isBusy = false;
        });

      } else {
        const yatchDataForm = new FormData();
        let data = this.yatchInfoForm.getRawValue();
        let pStart = moment(data.policyStartDate).format('DD/MM/YYYY HH:mm')
        let pEndDate = moment(data.policyEndDate).format('DD/MM/YYYY HH:mm')
        data.trailer = data.trailer == "" ? "1" : "0";
        data.trailerValue = data.trailer;
        const postData = {
          lobCode: ApiConstants.MARINE_HULL_LOBCODE,
          portal: this.session.get("portaltype"),
          userId: this.session.get("username"),
          polStartDate: moment(new Date()).format('DD/MM/YYYY HH:mm'),
        };
        const yatchData = {
          builtYear: data.builtYear,
          passengerCapacity: data.passengerCapacity,
          classificationSocityList: data.classificationSocity,
          mobileNo: data.mobileNo,
          insName: data.assuredName.toUpperCase(),
          emailId: data.emailId,
          polStartDate: pStart,
          polEndDate: pEndDate,
          civilId: data.civilId,
          agentId: this.session.get("agent"),
          companyYn: (data.customerTypeId) || '',
          mapId: "",
          transId: "",
          tranSrNo: ""
        };
        if (yatchData.companyYn != '1') {
          yatchData.civilId = this.yatchInfoForm.controls['civilId'].value
        }
        const updateBoatInfoData = {
          builtYear: data.builtYear,
          passengerCapacity: data.passengerCapacity,
          classificationSocity: data.classificationSocity,
          vesselValue: data.vesselValue,
          hullMaterial: data.hullMaterial,
          vesselUsage: data.vesselUsage,
          marina: data.marina,
          thirdPartyLimit: data.thirdPartyLimit,
          lengthOA: data.lengthOA,
          speed: data.speed,
          vesselType: data.vesselType,
          trailer: data.trailer,
          trailerVal: data.trailerVal,
          driverAge: data.driverAge,
          mapId: "",
          transId: "",
          tranSrNo: ""
        };

        this.agentService.createQuote(postData).subscribe(createQuoteResponse => {
          yatchData.transId = createQuoteResponse.transId;
          yatchData.tranSrNo = createQuoteResponse.tranSrNo;
          yatchData.mapId = "PL_CRAFT_AGENT_POL_SCR_1";
          this.quoteNo = createQuoteResponse.quoteNo;
          this.agentService.updateInsuredInfo(yatchData).subscribe(updatedInfoResponse => {
            updateBoatInfoData.transId = createQuoteResponse.transId;
            updateBoatInfoData.tranSrNo = createQuoteResponse.tranSrNo;
            updateBoatInfoData.mapId = "PL_CRAFT_AGENT_RISK_SCR_1";
            this.agentService.updateBoatInfo(updateBoatInfoData).subscribe(updateBoatInfoResponse => {

              const obj = {
                transId: createQuoteResponse.transId,
                tranSrNo: createQuoteResponse.tranSrNo,
                userId: this.session.get("username"),
                portal: ApiConstants.PORTAL,
                lobCode: ApiConstants.MARINE_HULL_LOBCODE
              };
              this.agentService.calculatePricing(obj).subscribe(calculatePricingData => {

                this.loaderService.isBusy = false;
                if (calculatePricingData.respCode == 2000) {
                  let schemeObj = {
                    transId: createQuoteResponse.transId,
                    tranSrNo: createQuoteResponse.tranSrNo,
                    lobCode: ApiConstants.MARINE_HULL_LOBCODE

                  };
                  this.router.navigate(['scheme'], { queryParams: schemeObj, skipLocationChange: true });
                  this.loaderService.isBusy = false;

                }
              }, error => {
                let errorMsg = error.error.errMessage;
                let obj = {
                  "transId": this.transId,
                  "tranSrNo": this.tranSrNo,
                  "quoteNo": createQuoteResponse.quoteNo,
                  "errorMsg": errorMsg
                };
                this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
              });

            }, error => {
              this.loaderService.isBusy = false;
            })
          }, error => {
            this.loaderService.isBusy = false;
          });
        }, error => {
          this.loaderService.isBusy = false;
        })
      }
    }
    else {
      this.loaderService.isBusy = false;
      this.validateAllFormFields(this.yatchInfoForm);
    }
  }
  changeValidation(value: string) {
    this.session.set('companyYn', value);
    const type = this.yatchInfoForm.get('civilId');
    type.clearValidators();
    if (value == "1") {
      type.setValidators([Validators.required]);
      this.civilIdPatternError = "Only Alpha Numeric Allowed";
    } else {
      type.setValidators([Validators.required, Validators.pattern(/^\d{3}-\d{4}-\d{7}-\d{1}$/)]);
      this.civilIdPatternError = "Emirates Id should be XXX-XXXX-XXXXXXX-X format";
    }
    type.updateValueAndValidity();
  }
}
