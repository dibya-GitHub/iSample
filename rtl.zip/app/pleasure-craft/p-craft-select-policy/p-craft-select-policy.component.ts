import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-p-craft-select-policy',
  templateUrl: './p-craft-select-policy.component.html',
  styleUrls: ['./p-craft-select-policy.component.scss']
})
export class PCraftSelectPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
