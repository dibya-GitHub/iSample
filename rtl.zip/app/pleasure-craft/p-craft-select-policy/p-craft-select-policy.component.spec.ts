import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PCraftSelectPolicyComponent } from './p-craft-select-policy.component';

describe('PCraftSelectPolicyComponent', () => {
  let component: PCraftSelectPolicyComponent;
  let fixture: ComponentFixture<PCraftSelectPolicyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PCraftSelectPolicyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PCraftSelectPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
