import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { ApplicationConstants } from 'src/shared/application-constants';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-confirm-quote',
  templateUrl: './confirm-quote.component.html',
  styleUrls: ['./confirm-quote.component.scss']
})
export class ConfirmQuoteComponent implements OnInit {
  transId: string = '1398609';
  tranSrNo: string = '1';
  companyCode: string;
  bean: any;
  policyDetails: any;
  printCreditAccess: string;
  mode: string;
  pay: boolean;
  dohaCountryCode = ApplicationConstants.DOHA_COUNTRY_CODE;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  constructor(private session: SessionStorageService,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService, private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.companyCode = this.session.get('companyCode');
    this.mode = this.commonService.getParamValue('mode');
    //this.pay =  this.commonService.getParamValue('pay');
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.printCreditAccess = this.session.get('printCreditAccess');
    let reqParam = null;
    if ("sendPayLink" == this.mode) {
      reqParam = { "transId": this.transId, "tranSrNo": this.tranSrNo, "mode": 'saveQuote' };
    }
    else {
      reqParam = { "transId": this.transId, "tranSrNo": this.tranSrNo, "mode": this.mode };
    }

    this.agentService.fetchConfirmData(reqParam).subscribe(response => {
      if (response.respCode == 2000) {
        this.bean = response;
        // alert("this.bean.quoteNo**"+this.bean.quoteNo);
      }
    }, error => {
    });
    window.scroll(0, 0);
  }


  hasPrintAccess() {
    return ("1" == this.session.get("printCreditAccess"));
  }

  GenerateReport(reportType) {
    this.commonService.getReport(this.transId, this.tranSrNo, reportType, this.session.get("portaltype"), this.bean.transType, "", "");
  }

  fnClose() {
    this.router.navigate(['agentdashboard']);
  }
}
