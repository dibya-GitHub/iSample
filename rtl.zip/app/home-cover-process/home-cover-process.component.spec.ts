import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeCoverProcessComponent } from './home-cover-process.component';

describe('HomeCoverProcessComponent', () => {
  let component: HomeCoverProcessComponent;
  let fixture: ComponentFixture<HomeCoverProcessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeCoverProcessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeCoverProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
