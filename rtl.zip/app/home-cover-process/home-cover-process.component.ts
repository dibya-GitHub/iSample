import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Cover } from '../../shared/classes/cover';

@Component({
  selector: 'app-home-cover-process',
  templateUrl: './home-cover-process.component.html',
  styleUrls: ['./home-cover-process.component.scss']
})
export class HomeCoverProcessComponent implements OnInit {
  @Input() detail: Cover;
  @Input() homeSIListArray: any[] = [];
  @Output() stateChange: EventEmitter<Cover> = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  updateHomeContentSI(event) {
    this.detail.newSumAssured = event.target.value;
    this.stateChange.emit(this.detail);
  }
}
