import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntimateClaimsComponent } from './intimate-claims.component';

describe('IntimateClaimsComponent', () => {
  let component: IntimateClaimsComponent;
  let fixture: ComponentFixture<IntimateClaimsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntimateClaimsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntimateClaimsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
