import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intimate-claims',
  templateUrl: './intimate-claims.component.html',
  styleUrls: ['./intimate-claims.component.scss']
})
export class IntimateClaimsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
