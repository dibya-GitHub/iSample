import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { UntypedFormBuilder, UntypedFormControl, Validators, UntypedFormGroup, UntypedFormArray } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { DriverDetails } from '../motor-insurance/classes/driver-details';
import { ViewChild } from '@angular/core';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { LoaderService } from 'src/shared/loader-service/loader.service';
@Component({
  selector: 'app-extension-policy-endorsement',
  templateUrl: './extension-policy-endorsement.component.html',
  styleUrls: ['./extension-policy-endorsement.component.scss']
})
export class ExtensionPolicyEndorsementComponent implements OnInit {

  company;
  transId;
  tranSrNo;
  lobCode;
  policyNo;
  docCodeValue;
  file: File;
  tmpParms: any;
  customerInfo: any;
  vehicleInfo: any;
  homeInfo: any;
  travelInfo: any;
  nationalityList: any;
  colorList: any;
  cityList: any;
  streetList: any;
  zoneList: any;
  buldingTypeList: any;
  languageList: any;
  relationList: any;
  driversInfo: any;
  CustomerInfoForm: UntypedFormGroup;
  VehicleInfoForm: UntypedFormGroup;
  HomeInfoForm: UntypedFormGroup;
  driverList: UntypedFormArray;
  driverInfo: DriverDetails;
  civilIdErrorMessage;
  mobileNoerrorMessage;

  dataArr: UntypedFormArray;
  travelDetailsinfo: any;
  childinfo: UntypedFormArray;
  adultinfo: UntypedFormArray;
  noOfAdult: number;
  noOfChild: number;
  totalChildren: number;
  totalAdults: number;
  genderList: Array<any>;
  travelersInfo: UntypedFormGroup;
  arr = [];
  companyCode: string = this.session.get("companyCode");
  travlDetails: Array<any>;
  optionalCovers: any[] = [];
  discounts: any[] = [];
  deductables: any[] = [];
  loading: any[] = [];
  fees: any[] = [];
  tax: any[] = [];
  coverInfo: any[] = [];
  sumInclusiveMandatory: any[] = [];
  netPremium: any;
  schCode;
  prodCode;
  endType;

  vehicleShapes: Array<any>;
  plateTypes: Array<any>;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    public route: ActivatedRoute,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private loaderService: LoaderService,
    private session: SessionStorageService
  ) { }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.schCode = this.commonService.getParamValue('schCode');
    this.prodCode = this.commonService.getParamValue('prodCode');
    this.endType = this.commonService.getParamValue('endType');
    this.civilIdErrorMessage = this.commonService.civilIdErrorMessage();
    this.mobileNoerrorMessage = this.commonService.mobileNoErrorMessage();
    this.getNationalityList();
    this.getCityList();
    this.getEndorsementDetails();
    this.createForm();
    this.getColorList();
    this.getZoneList();
    this.getStreetList();
    this.getBuildingtypetList();
    this.getRelationList();
    this.getQuoteTravelInfo();
    this.getGenderType();
    this.getNationalityType();
    this.getTravlersDetails();
    this.getCoverInfo();
    this.getCoverSummary();
    this.getDiscDedLoadFeesSumm();
    this.getPlateType();
    this.getVehicleShape();
  }

  trafficLocList = [
    { id: "002", value: "Dubai" },
    { id: "003", value: "Abudhabi" }
  ]

  customerTypes = [
    { id: "0", value: "Individual" },
    { id: "1", value: "Company" }
  ]

  financeStatusList = [
    { id: "1", value: "Yes" },
    { id: "0", value: "No" }
  ]


  buildingAgeList = [
    { id: "1", value: "1" },
    { id: "2", value: "2" },
    { id: "3", value: "3" },
    { id: "4", value: "4" },
    { id: "5", value: "5" },
    { id: "6", value: "6" },
    { id: "7", value: "7" },
    { id: "8", value: "8" },
    { id: "9", value: "9" },
    { id: "10", value: "10" },
  ]

  createForm() {
    this.CustomerInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      transRemark: '',

      userId: this.session.get("username"),
      custCode: this.session.get("agent"),
      portal: this.session.get("portaltype"),
      ipAddress: '',
      //   companyYn: '',
      telephoneNo: '',
      interest: '',
      producerCode: '',
      collectorCode: '',
      taxRefNo: '',
      // civilId: ['', Validators.compose([Validators.required, Validators.pattern(this.agentService.civilIdLength())])],
      insName: ['', Validators.required],
      insNameAr: '',
      //  mobileNo: ['', Validators.compose([Validators.required, Validators.pattern(this.agentService.checkMobileNo())])],
      //   address: '',
      //   address2: '',
      //   poBox: ['', Validators.required],
      //  emailId: ['', [Validators.email]],
      //  city: '',
      //  nationality: '',
      mapId: 'END_CUS_INFO_UDATE'

    });
    this.VehicleInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      userId: this.session.get("username"),
      mapId: 'END_VEHICLE_INFO_UDATE',
      chassisNo: '',
      regnNo: '',
      plateType: '',
      vehicleShape: ''
    });

    /* this.HomeInfoForm = this.fb.group({
       transId: this.transId,
       tranSrNo: this.tranSrNo,
       userId: this.session.get("username"),
       mapId: 'END_BULDING_INFO_UDATE',
       bldngAge: '',
       bldngType: '',
       zoneArea: '',
       city: '',
       streetBlock: '',
       poBox: ['', Validators.required],
       address: ['', Validators.required],
       address1: '',
       financedBank: '',
       financedBankYn: ''
     });
 
     this.travelersInfo = this.fb.group({
       adultinfo: this.fb.array([]),
       childinfo: this.fb.array([]),
     });*/

  }
  getPlateType() {
    let params = { "type": "PLATE_CHAR" }
    this.agentService.getPlateType(params).subscribe(result => {
      this.plateTypes = result;
    })
  }
  getVehicleShape() {
    let params = { "type": "MOT_QCB_SHAP" }
    this.agentService.VechicleShape(params).subscribe(result => {
      this.vehicleShapes = result;
    })
  }

  getEndorsementDetails() {
    let params = { "trans_Id": this.transId, "trans_Sno": this.tranSrNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {
        this.customerInfo = result.customerInfo;
        if (this.customerInfo.companyYn == '0') {
          this.customerInfo.companyType = 'Individual';
        }
        else {
          this.customerInfo.companyType = 'Company';
        }
        this.vehicleInfo = result.vehicleInfo;
        this.homeInfo = result.homeInfo;
        this.travelInfo = result.travelInfo;
        this.driversInfo = result.driversInfo;
        this.CustomerInfoForm.patchValue({
          //    companyYn: this.customerInfo.companyYn,
          telephoneNo: this.customerInfo.telephoneNo,
          interest: this.customerInfo.interest,
          producerCode: this.customerInfo.producerCode,
          collectorCode: this.customerInfo.collectorCode,
          taxRefNo: this.customerInfo.taxRefNo,
          insName: this.customerInfo.insName,
          insNameAr: this.customerInfo.insNameAr,
          // transRemark: this.customerInfo.transRemark,

        });

        if ("01" == this.lobCode) {
          this.VehicleInfoForm.patchValue({
            regnNo: this.vehicleInfo.regnNo,
            chassisNo: this.vehicleInfo.chassisNo,
            plateType: this.vehicleInfo.plateChar,
            vehicleShape: this.vehicleInfo.vehBodyType
          });
        }
      });
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }


  approveEndorsement(mode) {
    if (this.CustomerInfoForm.valid) {
      this.loaderService.isBusy = true;
      this.agentService.updateInsuredInfo(this.CustomerInfoForm.value)
        .subscribe(result => {
          if ("01" == this.lobCode) {
            this.updateVehcleInfo(mode);
          }
          let obj = { "transId": this.transId, "tranSrNo": this.tranSrNo, "lobCode": this.lobCode, "policyNo": this.policyNo, "endType": this.endType, "schCode": this.schCode, "prodCode": this.prodCode };
          this.router.navigate(['addextendt'], { queryParams: obj, skipLocationChange: true });
          this.loaderService.isBusy = false;
        });
    } else {
      this.validateAllFormFields(this.CustomerInfoForm);
    }
  }


  updateVehcleInfo(mode) {
    this.agentService.updateVehicleInfo(this.VehicleInfoForm.value)
      .subscribe(result => {
        //   this.insertAdditionalDriverInfo(mode);

      });
  }



  endtProceedtoBuy() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo, "userId": this.session.get("username") }
    this.agentService.endtProceedtoBuy(param)
      .subscribe(result => {
        let obj = { "transId": this.transId, "tranSrNo": this.tranSrNo, "policyNo": this.policyNo };
        this.router.navigate(['confirmendt'], { queryParams: obj, skipLocationChange: true });
      });
  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }
  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  getNationalityList() {
    let v_nationality = { "type": "NATIONALITY" };
    this.agentService.getGeoList(v_nationality)
      .subscribe(result => {
        this.nationalityList = result.appCodesArray;
      });
  }

  getCityList() {
    let v_city = { "type": "STATE" };
    this.agentService.getGeoList(v_city)
      .subscribe(result => {
        this.cityList = result.appCodesArray;
      });
  }

  getColorList() {
    let v_color = { "type": "MOT_VEH_COL" };
    this.agentService.getGeoList(v_color)
      .subscribe(result => {
        this.colorList = result.appCodesArray;
      });
  }

  getZoneList() {
    let zone = { "type": "ZONE_AREA" };
    this.agentService.getGeoList(zone)
      .subscribe(result => {
        this.zoneList = result.appCodesArray;
      });
  }

  getStreetList() {
    let street = { "type": "STREET_BLOCK" };
    this.agentService.getGeoList(street)
      .subscribe(result => {
        this.streetList = result.appCodesArray;
      });
  }
  getBuildingtypetList() {
    let bldType = { "type": "BUILDING_TYP" };
    this.agentService.getGeoList(bldType)
      .subscribe(result => {
        this.buldingTypeList = result.appCodesArray;
      });
  }



  uploadDocuments(event: any) {

    this.getDocumentCodeBeforeUpload(event.target.id);
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
      var reader = new FileReader();
      var that = this;
      reader.onload = function () {
        that.upload(event);
      }
      reader.readAsDataURL(fileList[0]);
    }

  }

  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('lobCode', this.lobCode);
    formData.append('docCode', this.docCodeValue);
    formData.append('docType', "POL");
    formData.append('userId', this.session.get("username"));
    var uploadDocumentReponse = this.commonService.uploadDocuments(formData);
  }

  getDocumentCodeBeforeUpload(event) {
    if (event == "emiratesId") {
      this.docCodeValue = "004";
    } else if (event == "mail") {
      this.docCodeValue = "038";
    } else if (event == "passport") {
      this.docCodeValue = "006";
    } else if (event == "proposalForm") {
      this.docCodeValue = "039";
    } else if (event == "highValueItem") {
      this.docCodeValue = "050";
    } else if (event == "others") {
      this.docCodeValue = "";
    } else if (event == "receipt") {
      this.docCodeValue = "049";
    }
  }

  loadAgentDoc(reportType) {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=1000,height=400,left=100%,top=100%`;
    var winRef = window.open('/viewdocument?transId=' + this.transId + '&tranSrNo=' + this.tranSrNo + '&reportType=' + reportType + '&policyNo=' + this.policyNo, 'Product Category', param);
  }
  createItem(): UntypedFormGroup {
    return this.fb.group({
      driverName: '',
      driverAge: '',
      licenseNo: '',
      licenseAge: '',
      relation: ''

    });
  }

  addNewRow(): void {
    this.createItem();
    this.driverList = this.VehicleInfoForm.get('driverList') as UntypedFormArray;
    this.driverList.push(this.createItem());
  }

  deleteRow(index) {
    this.driverList = this.VehicleInfoForm.get('driverList') as UntypedFormArray;
    this.driverList.removeAt(index);
  }

  getRelationList() {
    let param = { "type": "RELATION" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        this.relationList = result.appCodesArray;
      });
  }


  //---------------Travelinfo------------------//

  addAdultRow(len: number): any {
    for (var i = 1; i <= len; i++) {
      this.adultinfo = this.travelersInfo.get('adultinfo') as UntypedFormArray;
      this.createAdult();
      this.adultinfo.push(this.createAdult());
    }
  }

  addChildRow(len: number): any {
    for (var i = 1; i <= len; i++) {

      this.childinfo = this.travelersInfo.get('childinfo') as UntypedFormArray;
      this.createChild();
      this.childinfo.push(this.createChild());
    }
  }

  createAdult(): UntypedFormGroup {
    return this.fb.group({
      trvlrName: '',
      relation: '',
      gender: '',
      dob: [],
      nationality: '',
      passptNo: '',
      wntrSptsExtYN: [],
      transId: this.transId,
      tranSrNo: this.tranSrNo,

    });
  }
  createChild(): UntypedFormGroup {
    return this.fb.group({
      trvlrName: '',
      relation: '',
      gender: '',
      dob: '',
      nationality: '',
      passptNo: '',
      wntrSptsExtYN: '',
      transId: this.transId,
      tranSrNo: this.tranSrNo,
    });
  }

  getQuoteTravelInfo() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getQuoteTravelInfo(data).subscribe(result => {
      this.noOfAdult = Number(result.noOfAdults);
      this.noOfChild = Number(result.noOfChild);
      if (this.noOfAdult > 0) {
        this.addAdultRow(this.noOfAdult);
      }
      if (this.noOfChild > 0) {
        this.addChildRow(this.noOfChild);
      }
    });

  }

  getGenderType() {
    this.agentService.getGenderList({ "paraType": "GENDER" }).subscribe(resp => {
      this.genderList = resp;
    })
  }
  getNationalityType() {
    this.agentService.getNationalityList({ "type": "NATIONALITY" }).subscribe(resp => {
      this.nationalityList = resp;
    })
  }
  loadTravlInfo() {
    for (var i = 0; i < this.travlDetails.length; i++) {
      const controlArray = <UntypedFormArray>this.travelersInfo.get('adultinfo');
      controlArray.controls[i].get('trvlrName').setValue(this.travlDetails[i].trvlrName);
      controlArray.controls[i].get('relation').setValue(this.travlDetails[i].relation);
      controlArray.controls[i].get('gender').setValue(this.travlDetails[i].gender);
      controlArray.controls[i].get('dob').setValue(this.travlDetails[i].dob);
      controlArray.controls[i].get('nationality').setValue(this.travlDetails[i].nationality);
      controlArray.controls[i].get('passptNo').setValue(this.travlDetails[i].passptNo);
      controlArray.controls[i].get('wntrSptsExtYN').setValue(this.travlDetails[i].wntrSptsExtYN);
    }
  }


  getTravlersDetails() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getTravelerDetls(data).subscribe(resp => {
      this.travlDetails = resp.travelerArray;
      this.loadTravlInfo();
    });
  }



  getCoverInfo() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverInfo(param)
      .subscribe(response => {
        if (response["coversArray"] != "" && response["coversArray"] != null && response["coversArray"] != undefined) {
          var array = response["coversArray"];
          for (var i = 0; i < array.length; i++) {
            this.coverInfo.push(array[i]);
          }
        }
      });
  }

  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            if (array[i].type == 'I') {
              array[i].premium = 'Inclusive';
              this.sumInclusiveMandatory.push(array[i]);

            } else {

              if (array[i].premium > 0) {
                this.sumInclusiveMandatory.splice(j, 0, array[i]);
              }
              j++;
            }
          }
          else {
            this.optionalCovers.push(array[i]);
          }
        }

      });

  }

  getNetPremium() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getNetPremium(param)
      .subscribe(response => {
        // this.agentCommisionValue = response.AGENT_FC;
        // this.agentCommissionPercent = response.AGENT_PERCENT;
        // this.agentCommissionTax = response.QPI_ACOMM_TAX;
        this.netPremium = response.PREMIUM;

      });
  }

  getDiscDedLoadFeesSumm() {
    var summArr = ["DISC", "LOAD", "DED", "FEES", "TAX"];
    var k = 0;
    for (var i = 0; i < summArr.length; i++) {
      var type = summArr[i];
      let param = { "transId": this.transId, "tranSrNo": this.tranSrNo, "type": type };
      this.agentService.getDiscDedLoadFeesSumm(param)
        .subscribe(response => {
          //var arr=["DISC","LOAD","DED","FEES"];    
          if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
            var data = response["othersArray"];
            if (type == "DISC") {
              for (k = 0; k < data.length; k++) {
                this.discounts.push(data[k]);
              }
            } else if (type == "LOAD") {
              for (k = 0; k < data.length; k++) {
                this.loading.push(data[k]);
              }
            } else if (type == "DED") {
              for (k = 0; k < data.length; k++) {
                this.deductables.push(data[k]);
              }
            } else if (type == "FEES") {
              for (k = 0; k < data.length; k++) {
                this.fees.push(data[k]);
              }
            } else if (type == "TAX") {
              for (k = 0; k < data.length; k++) {
                this.tax.push(data[k]);
              }
            }
          }
          this.getNetPremium();
        });
    }
  }


}
