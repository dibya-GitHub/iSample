import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from "../../../shared/services/agent-user.service";
import { DriverDetails } from '../../motor-insurance/classes/driver-details';
import { AgentHttpclientService } from '../../services/agent-httpclient.service';

@Component({
  selector: 'app-certificate-endorsement',
  templateUrl: './certificate-endorsement.component.html',
  styleUrls: ['./certificate-endorsement.component.scss']
})
export class CertificateEndorsementComponent implements OnInit {


  company;
  transId;
  tranSrNo;
  lobCode;
  policyNo;
  docCodeValue;
  file: File;
  tmpParms: any;
  duration: any;
  customerInfo: any;
  vehicleInfo: any;
  homeInfo: any;
  travelInfo: any;
  driversInfo: any;
  driverList: UntypedFormArray;
  driverInfo: DriverDetails;
  dataArr: UntypedFormArray;
  VehicleInfoForm: UntypedFormGroup;
  arr = [];
  companyCode: string = this.session.get("companyCode");

  schCode;
  prodCode;
  endType;
  fleetVehicleList: any;
  showVeh: boolean;

  vehMakeDesc: any;
  vehModelDesc: any;
  manfYear: any;
  financedYn: any;
  bankList: any;
  vehBodyTypeDesc: any;
  vehUsageDesc: any;
  seatingCty: any;
  psgrLiabSeatCty: any;
  vehCylindersDesc: any;
  vehColorDesc: any;
  orgVehicleValue: any;
  vehWeightDesc: any;
  geoAreaDesc: any;
  chassisNo: any;
  engineNo: any;
  plateCharDesc: any;
  regnNo: any;
  tplLimit: any;
  certNo: any;
  private myDatePickerOptions: IAngularMyDpOptions = {
    // other options...
    dateFormat: 'dd/mm/yyyy',
  };

  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  constructor(private router: Router, public route: ActivatedRoute, private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private loaderService: LoaderService,
    private fb: UntypedFormBuilder, private session: SessionStorageService) { }


  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.schCode = this.commonService.getParamValue('schCode');
    this.prodCode = this.commonService.getParamValue('prodCode');
    this.endType = this.commonService.getParamValue('endType');
    this.createForm();
    this.getBankOfFinance();
    this.getEndorsementDetails();
    this.getFleetVehicleList();
  }
  createForm() {
    this.VehicleInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      userId: this.session.get("username"),
      mapId: 'END_VEHICLE_FLEET_UDATE',
      recStatus: 'U',
      financedBank: '',
      tcfNo: '',
      trafficLoc: '',
      certFromdate: '',
      certTodate: '',
      remarks: '',
      riskSNo: '',
      chassisNo: '',
      engineNo: '',
      errMessage: '',
      financedYn: '',
      firstRegYear: '',
      gccSpecYN: '',
      geoArea: '',
      geoAreaDesc: '',
      insName: '',
      manfYear: '',
      ncdYear: '',
      psgrLiabSeatCty: '',
      regnNo: '',
      respCode: '',
      riskSrNo: '',
      seatingCty: '',
      sumAssured: '',
      tplLimit: '',
      trafficLocDesc: '',
      vehAge: '',
      vehBodyType: '',
      vehBodyTypeDesc: '',
      vehColor: '',
      vehColorDesc: '',
      vehCylinders: '',
      vehCylindersDesc: '',
      vehMake: '',
      vehMakeDesc: '',
      vehModel: '',
      vehModelDesc: '',
      vehUsage: '',
      vehUsageDesc: '',
      orgVehicleValue: '',
      vehWeightDesc: '',
      plateCharDesc: '',
      certNo: ''
    });
  }
  trafficLocList = [
    { id: "002", value: "Dubai" },
    { id: "003", value: "Abudhabi" }
  ]
  getBankOfFinance() {
    this.agentService.getApplicationCodes('BANK').subscribe(data => {
      let tmpArr = data.appCodesArray.reverse();
      this.bankList = tmpArr;
    });
  }
  getEndorsementDetails() {
    let params = { "trans_Id": this.transId, "trans_Sno": this.tranSrNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {
        this.customerInfo = result.customerInfo;
        if (this.customerInfo.companyYn == '0') {
          this.customerInfo.companyType = 'Individual';
        }
        else {
          this.customerInfo.companyType = 'Company';
        }
      });
  }

  getFleetVehicleList() {
    let params = { "transId": this.transId, "mode": 'certificate' };
    this.agentService.getFleetvehicleList(params)
      .subscribe(result => {
        this.fleetVehicleList = result.fleetVehicleList;
      });
  }


  setvehicleDetails(veh) {
    this.loaderService.isBusy = true;
    this.showVeh = true;
    let params = { "transId": this.transId, "tranSrNo": this.tranSrNo, "riskSrNo": veh.tranSrNo };
    this.commonService.getQuoteVehicleInfo(params)
      .subscribe(result => {
        this.vehMakeDesc = result.vehMakeDesc;
        this.vehModelDesc = result.vehModelDesc;
        this.manfYear = result.manfYear;
        if (result.financedYn == '0') {

        }
        else {

        }
        this.vehBodyTypeDesc = result.vehBodyTypeDesc;
        this.vehUsageDesc = result.vehUsageDesc;
        this.seatingCty = result.seatingCty;
        this.psgrLiabSeatCty = result.psgrLiabSeatCty;
        this.vehCylindersDesc = result.vehCylindersDesc;
        this.vehColorDesc = result.vehColorDesc;
        this.orgVehicleValue = result.orgVehicleValue;
        this.vehWeightDesc = result.vehWeightDesc;
        this.geoAreaDesc = result.geoAreaDesc;
        this.chassisNo = result.chassisNo;
        this.engineNo = result.engineNo;
        this.plateCharDesc = result.plateCharDesc;
        this.regnNo = result.regnNo;
        this.tplLimit = result.tplLimit;
        this.certNo = result.certNo;
        var date = veh.certFromdate;
        var date1 = veh.certTodate;
        //this.VehicleInfoForm.certFromdate = veh.certFromdate;
        this.VehicleInfoForm.patchValue({
          certFromdate: moment(date, 'DD/MM/YYYY HH:mm').toISOString(),
          certTodate: moment(date1, 'DD/MM/YYYY HH:mm').toISOString(),
          vehBodyTypeDesc: result.vehBodyTypeDesc,
          vehUsageDesc: result.vehUsageDesc,
          seatingCty: result.seatingCty,
          psgrLiabSeatCty: result.psgrLiabSeatCty,
          vehCylindersDesc: result.vehCylindersDesc,
          vehColorDesc: result.vehColorDesc,
          orgVehicleValue: result.orgVehicleValue,
          vehWeightDesc: result.vehWeightDesc,
          geoAreaDesc: result.geoAreaDesc,
          chassisNo: result.chassisNo,
          engineNo: result.engineNo,
          plateCharDesc: result.plateCharDesc,
          regnNo: result.regnNo,
          tplLimit: result.tplLimit,
          certNo: result.certNo,
          vehMakeDesc: result.vehMakeDesc,
          vehModelDesc: result.vehModelDesc,
          manfYear: result.manfYear
        });
        /*let fromDate = moment(date,"DD/MM/YYYY HH:mm").toDate();
        let toDate = moment(date1,"DD/MM/YYYY HH:mm").toDate();

        this.VehicleInfoForm.patchValue({
          certFromdate: {
            date: {
              year: fromDate.getFullYear(),
              month: fromDate.getMonth() + 1,
              day: fromDate.getDate()
            }
          }
        });
        this.VehicleInfoForm.patchValue({
          certTodate: {
            date: {
              year: toDate.getFullYear(),
              month: toDate.getMonth() + 1,
              day: toDate.getDate()
            }
          }
        });*/
        this.VehicleInfoForm.patchValue({
          financedBank: result.financedBank,
          tcfNo: result.tcfNo,
          trafficLoc: result.trafficLoc,
          riskSNo: veh.tranSrNo
        });
        this.loaderService.isBusy = false;

      });
  }



  setToTime(event) {
    var endDate = new Date(event);
    var year = endDate.getFullYear();
    var month = endDate.getMonth();
    var day = endDate.getDate();
    var hour = 0, minute = 0;
    var toDate = new Date(year, month, day, 23, 59);
    this.VehicleInfoForm.patchValue({ certTodate: moment(toDate, 'DD/MM/YYYY HH:mm').toISOString() })
  }

  setFromTime(event) {
    var endDate = new Date(event);
    var today = new Date();
    var year = endDate.getFullYear();
    var month = endDate.getMonth();
    var day = endDate.getDate();
    var hour = 0, minute = 0;
    if (day == today.getDate() && month == today.getMonth() && year == today.getFullYear()) {
      hour = new Date().getHours();
      minute = new Date().getMinutes();
    }
    var toDate = new Date(year, month, day, hour, minute);
    this.VehicleInfoForm.patchValue({ certFromdate: moment(toDate, 'DD/MM/YYYY HH:mm').toISOString() })
  }

  proceed() {
    let obj = { "transId": this.transId, "tranSrNo": this.tranSrNo, "policyNo": this.policyNo };
    this.router.navigate(['fleetendt'], { queryParams: obj, skipLocationChange: true });
  }


  endtProceedtoBuy() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo, "userId": this.session.get("username") }
    this.agentService.endtProceedtoBuy(param)
      .subscribe(result => {
        let obj = { "transId": this.transId, "tranSrNo": this.tranSrNo, "policyNo": this.policyNo };
        this.router.navigate(['confirmendt'], { queryParams: obj, skipLocationChange: true });

      });
  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }
  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }
  saveData() {
    this.showVeh = false;
    let endate = this.VehicleInfoForm.value.certTodate;
    let stdate = this.VehicleInfoForm.value.certFromdate;
    let startDate = moment(this.VehicleInfoForm.value.certFromdate).format('DD/MM/YYYY HH:mm');
    let endDate = moment(this.VehicleInfoForm.value.certTodate).format('DD/MM/YYYY HH:mm');
    let pStart = moment(this.VehicleInfoForm.value.certFromdate).format('DD/MM/YYYY HH:mm')
    let pEndDate = moment(this.VehicleInfoForm.value.certTodate).format('DD/MM/YYYY HH:mm')
    //let startDate = new Date(stdate.date.year, stdate.date.month - 1, stdate.date.day);
    //let endDate = new Date(endate.date.year, endate.date.month - 1, endate.date.day);
    this.VehicleInfoForm.patchValue({
      certFromdate: pStart,
      certTodate: pEndDate,
    });
    this.agentService.updateVehicleInfo(this.VehicleInfoForm.value)
      .subscribe(result => {
        this.getFleetVehicleList();
      });
  }
  closeSave() {
    this.showVeh = false;
  }
}
