import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificateEndorsementComponent } from './certificate-endorsement.component';

describe('CertificateEndorsementComponent', () => {
  let component: CertificateEndorsementComponent;
  let fixture: ComponentFixture<CertificateEndorsementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificateEndorsementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificateEndorsementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
