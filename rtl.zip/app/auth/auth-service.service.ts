import { Injectable, Inject } from '@angular/core';
//import {tokenNotExpired} from 'angular2-jwt';
import { SessionStorageService } from 'angular-web-storage';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {
  constructor(private session: SessionStorageService) {
  }
  public getToken(): string {
    return this.session.get("access_token");
  }
  public getTokenV2(): string {
    return this.session.get("token");
  }

  // public isAuthenticated(): void {
  //   // get the token
  //   const token = this.getToken();
  //   // return a boolean reflecting 
  //   // whether or not the token is expired
  //   return tokenNotExpired(token);
  // }
}
