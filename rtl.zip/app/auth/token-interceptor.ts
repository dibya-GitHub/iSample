import {
  HttpEvent,
  HttpHandler,
  HttpHeaderResponse,
  HttpInterceptor,
  HttpProgressEvent,
  HttpRequest,
  HttpResponse,
  HttpSentEvent,
  HttpUserEvent
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from 'rxjs';
import { AuthServiceService } from './auth-service.service';
import { tap } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class TokenInterceptor implements HttpInterceptor {

  constructor(
    public auth: AuthServiceService,
    private router: Router,
    private session: SessionStorageService
  ) { }

  addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {
    const requestUrl = req.url.split('/');
    const urlValue = (requestUrl.indexOf("token") > -1);
    if (urlValue === true) {
      // req = req.clone({ setParams: { companyCode: 'QIC' } });
      req = req.clone({ setHeaders: { Authorization: 'Basic ' + token } })
      req = req.clone({ setHeaders: { company: '002' } });
      req = req.clone({ setHeaders: { 'Content-Type': 'application/x-www-form-urlencoded' } });

    } else {
      req = req.clone({ setHeaders: { Authorization: 'Bearer ' + token } })
    }
    return req;
  }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpSentEvent
    | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    let authToken;
    const requestUrl = request.url.split('/');
    const urlValue = (requestUrl.indexOf("token") > -1);
    if (urlValue === true) {
      authToken = this.auth.getTokenV2();
    } else {
      authToken = this.auth.getToken();
    }
    return next.handle(this.addToken(request, authToken))
      .pipe(tap((event: HttpEvent<any>) => {
      }, (err: any) => {

        if (err.error.responseCode == 401 || err.error.respCode == 401) {
          window.sessionStorage.clear();
          this.router.navigate(['sessiontimeout'], { skipLocationChange: true });
        }
      }));
  }
}