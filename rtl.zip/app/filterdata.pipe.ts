import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterdata',
  pure: false
})
export class FilterdataPipe implements PipeTransform {
  transform(items: any[], value: string, label: string) {
    if (!items || !value) {
      return items
    }
    return items.filter(res => {
      if (res.regnNo && res.regnNo != null) {
        return res.regnNo.toLowerCase().indexOf(value.toLowerCase()) !== -1 || res.tranSrNo.toLowerCase().indexOf(value.toLowerCase()) !== -1 || res.chassisNo.toLowerCase().indexOf(value.toLowerCase()) !== -1
      } else {
        return res.tranSrNo.toLowerCase().indexOf(value.toLowerCase()) !== -1 || res.chassisNo.toLowerCase().indexOf(value.toLowerCase()) !== -1
      }
    });
  }
}
