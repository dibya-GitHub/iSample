import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentHttpclientService } from 'src/app/services/agent-httpclient.service';
import { AppUtil } from 'src/app/services/app-util';


@Component({
  selector: 'app-tp-claim',
  templateUrl: './tp-claim.component.html',
  styleUrls: ['./tp-claim.component.scss']
})
export class TpClaimComponent implements OnInit {
  showMsg: boolean = false;
  public makeList: Array<any>;
  public modelList: Array<any>;
  locations: any[];
  startDate: any;
  postDate: any;
  registrationNo: any;
  public regnLocList: Array<any>;
  groupCode: string = this.session.get("groupCode");
  userFilter: any = this.session.get("userFilter");
  placeOfAccdnt: any;
  mobile: any;
  routeData: any;

  email: any;
  policeRefNo: any;
  appUtilObj: AppUtil = new AppUtil();
  errorMsg: string = '';
  date: Date = new Date();
  // mu declarations
  public vehicle_makes: Array<any>;
  dropDownload = true;
  claimantName: any;
  policy_number: any;
  manfYear: any;
  vehMaker: any;
  vehModels: any;
  accidentPlace: any;
  anyDate: any;
  myErrorMess: any;
  currentPathName: string;
  cusYear: number;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private session: SessionStorageService,
    private agentService: AgentHttpclientService,
  ) {
    this.route.queryParams.subscribe(params => {
      this.policeRefNo = params["policeRefNo"];
      this.email = params["email"];
      this.mobile = params["mobile"];
      this.registrationNo = params["registrationNo"];
      this.manfYear = params["manfYear"];
      this.claimantName = params["claimantName"];
      this.policy_number = params["policy_number"];
      if (params["postDate"] != undefined) {
        this.anyDate = new Date(params["postDate"]);
        // this.postDate=this.anyDate;
        this.postDate = params["postDate"];
        this.startDate = {
          "day": this.anyDate.getDate(),
          "month": (this.anyDate.getMonth() + 1),
          "year": this.anyDate.getFullYear(),
          "formatted": this.appUtilObj.appendZero(this.anyDate.getDate()) + '/' + this.appUtilObj.appendZero((this.anyDate.getMonth() + 1)) + '/' + this.anyDate.getFullYear(),
        };
        //, "formatted": "05.01.2017", "momentObj": "2017-01-04T23:00:00.000Z"
      }
      if (params["vehMakerid"] != undefined) {
        this.vehMaker = [{ id: params["vehMakerid"], text: params["vehMakerText"] }]
      }
      if (params["vehModelsid"] != undefined) {
        this.vehModels = [{ id: params["vehModelsid"], text: params["vehModelsText"] }]
      }
      if (params["placeOfAccdnt"] != undefined) {
        this.accidentPlace = params["placeOfAccdnt"];
      }
      else {
        this.accidentPlace = "";
      }
    });

    this.currentPathName = window.location.pathname;

  }

  ngOnInit() {
    let v_regLoc = { "type": "REGN_LOC" };
    this.agentService.getGeoList(v_regLoc)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.regnLocList = arr;
        this.placeOfAccdnt = this.accidentPlace;
      })
    let v_make = {
      "makeFliterYn": this.userFilter.CUST_MAKE_FILTER_YN,
      "groupCode": this.userFilter.CUST_GROUP_CODE
    };
    this.agentService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.makeList = arr;
      });
  }

  getModelList(event) {
    let make_var = event.id;
    let v_model = { "type": "MOT_VEH_MOD", "refCode": make_var };
    this.agentService.getVehicleModel(v_model)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.modelList = arr;
      });
  }
  addVehicleMake(event) {
  }
  changeAccidentDate(event: any) {
    if (this.startDate != undefined || this.startDate == null) {
      this.showMsg = false;
    }
    this.startDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
    this.postDate = this.appUtilObj.getUTCDate(event.epoc * 1000);
  }

  passTpClaimData() {
    let postData = {
      policeRefNo: this.policeRefNo,
      accidentDate: this.postDate,
      emailId: this.email,
      mobileNo: this.mobile,
      vehRegnNo: this.registrationNo,
      vehLocation: this.placeOfAccdnt,
      vehMake: this.vehMaker[0].id,
      vehModel: this.vehModels[0].id,
      vehMakerText: this.vehMaker[0].text,
      vehModelsText: this.vehModels[0].text,
      modelYear: this.manfYear,
      name: this.claimantName,
      policy_number: this.policy_number,
      "is_I_Insured": false
      // userId:'online',
      // portal:'D'
    }
    this.router.navigate(['upload-claim-docs'], { queryParams: postData, skipLocationChange: true });
  }
}
