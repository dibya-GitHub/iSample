import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TpClaimComponent } from './tp-claim.component';

describe('TpClaimComponent', () => {
  let component: TpClaimComponent;
  let fixture: ComponentFixture<TpClaimComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TpClaimComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TpClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
