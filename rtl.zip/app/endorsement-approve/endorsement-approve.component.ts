import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-endorsement-approve',
  templateUrl: './endorsement-approve.component.html',
  styleUrls: ['./endorsement-approve.component.scss']
})
export class EndorsementApproveComponent implements OnInit {

  transId;
  tranSrNo;
  lobCode;
  policyNo;
  policyInfo;
  currencyCode;
  documentList;
  documentType = [];
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  constructor(private router: Router, public route: ActivatedRoute, private agentService: AgentHttpclientService,
    private commonService: AgentUserService, private fb: UntypedFormBuilder, private session: SessionStorageService) { }


  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.transId = params["transId"];
      this.tranSrNo = params["tranSrNo"];
      this.lobCode = params["lobCode"];
      this.policyNo = params["policyNo"];
    });
    this.getPolicyInfo();
    this.currencyCode = this.commonService.currencyCode();
  }

  getPolicyInfo() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getPolicyInfo(param)
      .subscribe(result => {
        this.policyInfo = result;
        this.getDocumentList();
      });

  }

  getDocumentList() {
    let param = { "lobCode": this.policyInfo.lobCode, "docType": this.policyInfo.srcType, "divnCode": this.policyInfo.divnCode, "productCode": this.policyInfo.prodCode, "schemes": this.policyInfo.schCode }
    this.agentService.getDocumentList(param)
      .subscribe(result => {
        this.documentList = result.documentList;
      });
  }

  openDocumentsList(myModel) {
    myModel.className = 'modal show';
  }
  closemodel(myModel) {
    myModel.className = 'modal hide';
  }

  closeEndConfirm() {
    this.router.navigate(['agentdashboard']);
  }

  checkdocumentType(event) {
    if (event.target.checked) {
      this.documentType.push(event.target.value);
    } else {
      this.documentType.splice(this.documentType.indexOf(event.target.value), 1);
    }
  }

  printDocument() {
    for (var i = 0; i < this.documentType.length; i++) {
      this.getReport(this.documentType[i])
    }
  }

  getReport(reportType) {
    this.commonService.getReport(this.transId, this.tranSrNo, reportType, this.session.get("portaltype"), this.policyInfo.transType, "", "");
  }
}
