import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EndorsementApproveComponent } from './endorsement-approve.component';

describe('EndorsementApproveComponent', () => {
  let component: EndorsementApproveComponent;
  let fixture: ComponentFixture<EndorsementApproveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EndorsementApproveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EndorsementApproveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
