import { DecimalPipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { AgentHttpclientService } from 'src/app/services/agent-httpclient.service';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { MarineInsuranceService } from '../services/marine-insurance.service';
import { ECalendarValue } from 'ng2-date-picker';

@Component({
  selector: 'app-marine-create-certificate',
  templateUrl: './marine-create-certificate.component.html',
  styleUrls: ['./marine-create-certificate.component.scss'],
  providers: [DecimalPipe]
})
export class MarineCreateCertificateComponent implements OnInit {
  createCertificateForm: UntypedFormGroup;
  shipmentForm: UntypedFormGroup
  policyNo;
  userId;
  portal;
  transId;
  tranSrNo;
  quoteNo;
  editYn;
  prodCode;
  schCode;
  material = true;
  ng2datePickerConfig: any = {
    firstDayOfWeek: 'su',
    monthFormat: 'MMM, YYYY',
    disableKeypress: false,
    allowMultiSelect: false,
    closeOnSelect: true,
    closeOnSelectDelay: 0,
    openOnFocus: true,
    openOnClick: true,
    onOpenDelay: 0,
    closeOnEnter: true,
    weekDayFormat: 'ddd',
    appendTo: document.body,
    showNearMonthDays: true,
    showWeekNumbers: false,
    enableMonthSelector: true,
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    dayBtnFormat: 'DD',
    monthBtnFormat: 'MMM',
    hours12Format: 'hh',
    hours24Format: 'HH',
    meridiemFormat: 'A',
    minutesFormat: 'mm',
    minutesInterval: 1,
    secondsFormat: 'ss',
    secondsInterval: 1,
    showSeconds: false,
    showTwentyFourHours: true,
    timeSeparator: ':',
    multipleYearsNavigateBy: 10,
    showMultipleYearsNavigation: false,
    locale: moment.locale(),
    hideInputContainer: false,
    returnedValueType: ECalendarValue.Moment,
    unSelectOnClick: true,
    hideOnOutsideClick: true,
    numOfMonthRows: 3,
    format: 'DD/MM/YYYY'
  };
  siCurrencylist: any;
  premiumCurrList: any;
  departmentTypeList: any;
  facPoolsList: any;
  conveyanceTypeList: any
  portFromList: any;
  portToList: any;
  valuationList: any;
  PremExchRate: any;
  siExchRate: any;
  bankofFinanceList: any;
  goodsPopupList: any;
  vesselList: any;
  selectedGoodItem
  goodsList: UntypedFormArray;
  goodsBean;
  disableAddRow = false;
  modifyToDate = true;
  disableFac: string;
  disableBank: string;
  enableVessel: string;
  billLadPatchDate;
  lcPatchDate;
  poPatchDate;
  invoicePatchDate
  custCode: any;
  limitCustYN: any;
  limitDeptYn: any;
  constructor(
    public router: Router,
    public route: ActivatedRoute,
    private currPipe: DecimalPipe,
    public fb: UntypedFormBuilder,
    public loaderService: LoaderService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    public agentService: AgentHttpclientService,
    public marineService: MarineInsuranceService,

  ) {
    this.route.queryParams.subscribe((params: any) => {
      if (params.policyNo) {
        this.policyNo = params.policyNo
      } else {
        this.tranSrNo = params.tranSrNo,
          this.transId = params.transId,
          this.quoteNo = params.quoteNo
        this.editYn = 1
        this.policyNo = params.openPolicyNo
      }

    });
    this.userId = this.session.get('LoginID')
    this.portal = this.session.get('portaltype')
  }

  ngOnInit() {
    this.loaderService.isBusy = true
    this.createForm();
    this.createShipmentForm();
    this.getSIDropdown();
    this.getPremiumDropdown();
    this.getValuation();
    this.getConveyance();
    this.getDepartMent();
    this.getBankDD();
    this.getVesselDD();
    this.getPortFrom();
    this.getPortTo();
    this.getGoodsList();
    if (this.editYn == 1) {
      this.getCertQuoteInfo();
    } else {
      this.getDetails();
      this.setLCBank('');
    }
  }


  getDetails() {
    let obj = {
      policyNo: this.policyNo,
      userId: this.userId,
      portal: this.portal

    }
    this.marineService.createCertificate(obj).subscribe(res => {
      let data = res.quoteInfo;
      this.prodCode = data.product;
      this.schCode = data.scheme;
      this.custCode = data.custCode;
      this.limitCustYN = res.limitCustYN;
      this.limitDeptYn = res.limitDeptYn;
      this.createCertificateForm.patchValue({
        quoteNo: data.quoteNo,
        openPolicyNo: data.openPolicyNo,
        custCode: data.custCode,
        insName: data.insName,
        uwYear: data.uwYear,
        transactionRemarks: data.transactionRemarks,
        interest: data.interest,
        premCurr2: data.premCurr2,
        premCurr1: data.premCurr,
        sICurr1: data.siCurr,
        sICurr2: data.sICurr2,
        premCurr: data.premCurr,
        siCurr: data.siCurr,
        facPool: data.facPool,
        schCode: data.schCode,
        address1: data.address1,
        poBox: data.poBox,
        consigneeName: data.consigneeName,
        nationality: data.nationality,
        settlingAgent: data.settlingAgent,
        mapId: data.mapId,
        transId: data.transId,
        tranSrNo: data.tranSrNo,
        customerName: data.customerName,
        agentName: data.agentName,
        polStartDate: moment(data.polStartDate, 'DD/MM/YYYY HH:mm').toISOString(),
        polEndDate: moment(data.polEndDate, 'DD/MM/YYYY HH:mm').toISOString(),
      })
      if (data.facOption == '0') {
        this.createCertificateForm.get('facOption').setValue("0");
        this.disableFac = "true";
      } else {
        this.createCertificateForm.get('facOption').setValue("1");
        this.disableFac = null;
      }
      this.shipmentForm.patchValue({
        transId: data.transId,
        tranSrNo: data.tranSrNo
      })
      this.getExchangeRate(data.siCurr, 'SI');
      this.getExchangeRate(data.premCurr, 'PREM');
      this.quoteNo = data.quoteNo
      this.tranSrNo = data.tranSrNo
      this.transId = data.transId
      this.loaderService.isBusy = false;
    })
  }


  getCertQuoteInfo() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
    }
    this.marineService.retreiveCertificateInfo(obj).subscribe(res => {
      let data = res.quoteInfo
      let riskInfo = res.riskInfo
      this.prodCode = data.product
      this.schCode = data.scheme
      this.custCode = data.custCode
      this.limitCustYN = res.limitCustYN
      this.limitDeptYn = res.limitDeptYn
      this.getExchangeRate(data.siCurr, 'SI');
      this.getExchangeRate(data.premCurr, 'PREM');
      this.createCertificateForm.patchValue({
        accountgenYn: data.accountgenYn,
        consigneeName: riskInfo.consigneeName,
        departmentType: riskInfo.departmentType,
        agencyComm: data.agencyComm,
        agentId: data.agentId,
        agentName: data.agentName,
        agentyn: data.agentyn,
        address1: data.address1,
        busType: data.busType,
        custCode: data.custCode,
        customerName: data.customerName,
        discounts: data.discounts,
        divnCode: data.divnCode,
        facOption: data.facOption,
        feesCharges: data.feesCharges,
        grossPremium: data.grossPremium,
        insCode: data.insCode,
        insName: data.insName,
        inwardComm: data.inwardComm,
        loadings: data.loadings,
        netPremium: data.netPremium,
        netPremium1: data.netPremium1,
        openPolicyNo: this.policyNo,
        openPolicyYn: data.openPolicyYn,
        policyType: data.policyType,
        poBox: data.poBox,
        premCurr: data.premCurr,
        premCurrName: data.premCurrName,
        product: data.product,
        productName: data.productName,
        quoteNo: data.quoteNo,
        scheme: data.scheme,
        schemeName: data.schemeName,
        settlingAgent: data.settlingAgent,
        siCurr: data.siCurr,
        siCurrName: data.siCurrName,
        srcType: data.srcType,
        subAgencyComm: data.subAgencyComm,
        sumInsured: data.sumInsured,
        transactionRemarks: data.transactionRemarks,
        tranSrNo: this.tranSrNo,
        transId: this.transId,
        polStartDate: moment(data.polStartDate, 'DD/MM/YYYY HH:mm').toISOString(),
        polEndDate: moment(data.polEndDate, 'DD/MM/YYYY HH:mm').toISOString(),
      })
      if (riskInfo.sailingDate) {
        this.shipmentForm.patchValue({
          sailingDate: moment(riskInfo.sailingDate, 'DD/MM/YYYY HH:mm').toISOString(),
        })
      }
      if (riskInfo.lcDate) {
        this.shipmentForm.patchValue({
          lcDate: moment(riskInfo.lcDate, 'DD/MM/YYYY HH:mm').toISOString(),
        })
      }
      this.shipmentForm.patchValue({
        billLadDate: riskInfo.billLadDate,
        billLadNo: riskInfo.billLadNo,
        voyageFrom: riskInfo.voyageFrom,
        voyageTo: riskInfo.voyageTo,
        vesselDesc: riskInfo.vesselDesc,
        conveyanceType: riskInfo.conveyanceType,
        consigneeName: riskInfo.consigneeName,
        departmentType: riskInfo.departmentType,
        portFrom: riskInfo.portFrom,
        portTo: riskInfo.portTo,
        valuationCode: riskInfo.valuationCode,
        valuationPerc: riskInfo.valuationPerc,
        vesselCode: riskInfo.vesselCode,
        purchaseOrderDate: riskInfo.purchaseOrderDate,
        purchaseOrderNo: riskInfo.purchaseOrderNo,
        invoiceDate: riskInfo.invoiceDate,
        invoiceNo: riskInfo.invoiceNo,
        bankOption: riskInfo.bankOption,
        bankCode: riskInfo.bankCode,
        lcNo: riskInfo.lcNo,
        tranSrNo: this.tranSrNo,
        transId: this.transId,
        additionalDetails: riskInfo.cvrRemarks,
        bankName: riskInfo.bankName,
        companyCode: riskInfo.companyCode,
        conveyanceDesc: riskInfo.conveyanceDesc,
        cumInvoiceFc: riskInfo.cumInvoiceFc,
        cvrCode: riskInfo.cvrCode,
        cvrRemarks: riskInfo.cvrRemarks,
        depositPrem: riskInfo.depositPrem,
        destCity: riskInfo.destCity,
        dfltBankCode: riskInfo.dfltBankCode,
        flex01: riskInfo.flex01,
        flex02: riskInfo.flex02,
        flex04: riskInfo.flex04,
        goodsFlag: riskInfo.goodsFlag,
        // goodsList: riskInfo.goodsList,
        limitPerLoc: riskInfo.limitPerLoc,
        limitPerShip: riskInfo.limitPerShip,
        limitPership: riskInfo.limitPership,
        mapId: riskInfo.mapId,
        mfgYear: riskInfo.mfgYear,
        minPrem: riskInfo.minPrem,
        openPolicyNo: riskInfo.openPolicyNo,
        orgCity: riskInfo.orgCity,
        policyEndDate: riskInfo.policyEndDate,
        policyStartDate: riskInfo.policyStartDate,
        portFlag: riskInfo.portFlag,
        recStatus: riskInfo.recStatus,
        referenceNo: riskInfo.referenceNo,
        riskSrNo: riskInfo.riskSrNo,
        siCurr: riskInfo.siCurr,
        status: riskInfo.status,
        sumInsured: riskInfo.sumInsured,
        txnRemarks: riskInfo.txnRemarks,
        userId: riskInfo.userId,
        variancePerc: riskInfo.variancePerc,
        vesselName: riskInfo.vesselCode,
      });
      if (riskInfo.bankOption == 1) {
        this.setLCBank('Yes');
      } else {
        this.setLCBank('');
      }
      if (data.facOption == 1) {
        this.setFacOption('Yes');
      } else {
        this.setFacOption('');
      }
      this.lcPatchDate = riskInfo.lcDate;
      this.poPatchDate = riskInfo.purchaseOrderDate;
      this.billLadPatchDate = riskInfo.billLadDate;
      this.invoicePatchDate = riskInfo.invoiceDate;
      let invDates = moment(riskInfo.invoiceDate, 'DD/MM/YYYY').toDate();
      let purDates = moment(riskInfo.purchaseOrderDate, 'DD/MM/YYYY').toDate();
      // let lcDates = moment(riskInfo.lcDate, 'DD/MM/YYYY').toDate();
      let BillDates = moment(riskInfo.billLadDate, 'DD/MM/YYYY').toDate();
      if (this.invoicePatchDate) {
        this.shipmentForm.patchValue({
          invoiceDate: {
            date: {
              year: moment(invDates, 'DD/MM/YYYY').year(),
              month: moment(invDates, 'DD/MM/YYYY').month() + 1,
              day: moment(invDates, 'DD/MM/YYYY').date(),
            }
          }
        })
      }
      if (this.billLadPatchDate) {
        this.shipmentForm.patchValue({
          billLadDate: {
            date: {
              year: moment(BillDates, 'DD/MM/YYYY').year(),
              month: moment(BillDates, 'DD/MM/YYYY').month() + 1,
              day: moment(BillDates, 'DD/MM/YYYY').date(),
            }
          }
        })
      }
      // if (this.lcPatchDate) {
      //   this.shipmentForm.patchValue({
      //     lcDate: {
      //       date: {
      //         year: moment(lcDates, 'DD/MM/YYYY').year(),
      //         month: moment(lcDates, 'DD/MM/YYYY').month() + 1,
      //         day: moment(lcDates, 'DD/MM/YYYY').date(),
      //       }
      //     }
      //   })
      // }
      if (this.poPatchDate) {
        this.shipmentForm.patchValue({
          purchaseOrderDate: {
            date: {
              year: moment(purDates, 'DD/MM/YYYY').year(),
              month: moment(purDates, 'DD/MM/YYYY').month() + 1,
              day: moment(purDates, 'DD/MM/YYYY').date(),
            }
          }
        })
      }
      if (data.facOption == '0') {
        this.createCertificateForm.get('facOption').setValue("0");
        this.disableFac = "true";
      } else {
        this.createCertificateForm.get('facOption').setValue("1");
        this.disableFac = null;
      }
      let goodData = []
      goodData = res.details
      if (goodData.length > 0) {
        for (let i = 0; i < goodData.length; i++) {
          this.addNewRow('add');
        }
        this.shipmentForm.patchValue({
          goodsList: goodData
        });
      }
    })
  }

  createForm() {
    this.createCertificateForm = this.fb.group({
      insName: ['', Validators.required],
      premCurr: ['', Validators.required],
      customerName: ['', Validators.required],
      address1: ['', Validators.required],
      siCurr: ['', Validators.required],
      custCode: '',
      refNo: '',
      uwYear: '2021',
      transactionRemarks: '',
      interest: '',
      premCurr2: '',
      sICurr2: '',
      facOption: '',
      facPool: '',
      poBox: '',
      consigneeName: '',
      departmentType: '',
      nationality: '',
      settlingAgent: 'Qatar Insurance Company\nP O Box 4066, Dubai, U.A.E.. Tel: 00971 4 2224045 Fax: 00971 4 2238974\nEmail: cargoclaims@qicuae.com',
      mapId: '',
      transId: '',
      tranSrNo: '',
      accountgenYn: '',
      agencyComm: '',
      agentId: '',
      agentName: '',
      agentyn: '',
      busType: '',
      discounts: '',
      divnCode: '',
      feesCharges: '',
      grossPremium: '',
      insCode: '',
      inwardComm: '',
      loadings: '',
      modeOfPay: '',
      netPremium: '',
      netPremium1: '',
      openPolicyNo: '',
      openPolicyYn: '',
      polEndDate: '',
      polStartDate: '',
      policyNo: '',
      policyType: '',
      premCurrName: '',
      product: '',
      productName: '',
      quoteNo: '',
      scheme: '',
      schemeName: '',
      siCurrName: '',
      srcType: '',
      subAgencyComm: '',
      sumInsured: '',
    });

  }

  createShipmentForm() {
    this.shipmentForm = this.fb.group({
      lcNo: ['', Validators.required],
      conveyanceType: ['', Validators.required],
      portFrom: ['', Validators.required],
      portTo: ['', Validators.required],
      valuationCode: ['', Validators.required],
      bankCode: '',
      sailingDate: '',
      conveyanceDesc: '',
      vesselCode: '',
      vesselName: '',
      orgCity: '',
      destCity: '',
      valuationPerc: '',
      variancePerc: '',
      additionalDetails: '',
      purchaseOrderNo: '',
      purchaseOrderDate: '',
      invoiceNo: '',
      invoiceDate: '',
      mfgYear: '',
      referenceNo: '',
      departmentType: '',
      consigneeName: '',
      txnRemarks: '',
      bankOption: '',
      bankName: '',
      lcDate: '',
      billLadNo: '',
      billLadDate: '',
      flex04: '',
      riskSrNo: '',
      transId: '',
      tranSrNo: '',
      mapId: '',
      userId: this.userId,
      siCurr: '',
      status: '',
      policyStartDate: '',
      policyEndDate: '',
      openPolicyNo: '',
      recStatus: '',
      goodsList: this.fb.array([]),
      divnCode: '',
      deptCode: '',
      voyageFrom: '',
      voyageTo: '',
      vesselDesc: '',
      // schemeCode: '',
      // code: "031013",
      // desc: "A/C Spares Etc.",
      // invAmt: "12",
      // cumInvoiceFc: "",
      // sumInsured: "13.44",
      // srNo: "1"
    })
  }

  getSIDropdown() {
    let obj = {
      policyNo: this.policyNo,
      type: 'APPL_SICUR'
    }
    this.marineService.getvaluationDD(obj).subscribe(res => {
      this.siCurrencylist = res.typeList
    })
  }

  getPremiumDropdown() {
    let obj = {
      policyNo: this.policyNo,
      type: 'APPL_PREMCUR'
    }
    this.marineService.getvaluationDD(obj).subscribe(res => {
      this.premiumCurrList = res.typeList
    })
  }

  getValuation() {
    let obj = {
      policyNo: this.policyNo,
      type: 'APPL_BASIS'
    }
    this.marineService.getvaluationDD(obj).subscribe(res => {
      this.valuationList = res.typeList
    })
  }

  getConveyance() {
    this.agentService.getApplicationCodes('CONV_TYPE').subscribe(res => {
      this.conveyanceTypeList = res.appCodesArray
    })
  }
  getDepartMent() {
    this.agentService.getApplicationCodes('DEPT_TYPE').subscribe(res => {
      this.departmentTypeList = res.appCodesArray
    })
  }

  getBankDD() {
    this.agentService.getApplicationCodes('BANK').subscribe(res => {
      this.bankofFinanceList = res.appCodesArray
    })
  }

  getVesselDD() {
    this.agentService.getApplicationCodes('VESSEL').subscribe(res => {
      this.vesselList = res.appCodesArray
    })
  }

  getGoodsList() {
    let obj = {
      policyNo: this.policyNo,
    }
    this.marineService.getGoodsList(obj).subscribe(res => {
      this.goodsPopupList = res.goodsList
    })
  }

  getPortFrom() {
    let obj = {
      policyNo: this.policyNo,
      type: 'PORT_FROM'
    }
    this.marineService.getPortDD(obj).subscribe(res => {
      this.portFromList = res.ports
    })
  }
  getPortTo() {
    let obj = {
      policyNo: this.policyNo,
      type: 'PORT_TO'
    }
    this.marineService.getPortDD(obj).subscribe(res => {
      this.portToList = res.ports
    })
  }

  createItem(): UntypedFormGroup {
    let count = this.goodsList.length;
    return this.fb.group({
      code: null,
      desc: null,
      invAmt: null,
      cumInvoiceFc: null,
      sumInsured: null,
      srNo: count + 1,
    });
  }

  addNewRow(mode: string): void {
    this.goodsList = this.shipmentForm.get('goodsList') as UntypedFormArray;
    this.createItem();
    this.goodsList.push(this.createItem());
  }

  deleteRow(index) {
    this.goodsList = this.shipmentForm.get('goodsList') as UntypedFormArray;
    this.goodsList.removeAt(index);
    this.disableAddRow = false;
    if (this.goodsList.length == 0) {
      // this.showFlag = false
    }
  }

  selectedGood(data) {
    this.selectedGoodItem = data
  }

  addGoodsData() {
  }

  onClickSubmit() {
    this.loaderService.isBusy = true;
    (<HTMLInputElement>document.getElementById("proceedBtn")).disabled = true;
    let sailingDate
    let billdate
    let poDate
    let invoiceDate
    let lcDate
    if (this.createCertificateForm.valid) {
      if (this.shipmentForm.valid) {
        let sendCertData = this.createCertificateForm.value
        let sendShipData = this.shipmentForm.value
        if (this.shipmentForm.get('billLadDate').value) {
          billdate = this.shipmentForm.get('billLadDate').value
          if (billdate.formatted) {
            sendShipData.billLadDate = billdate.formatted
          } else {
            sendShipData.billLadDate = this.billLadPatchDate
          }
        }
        if (this.shipmentForm.get('purchaseOrderDate').value) {
          poDate = this.shipmentForm.get('purchaseOrderDate').value
          if (poDate.formatted) {
            sendShipData.purchaseOrderDate = poDate.formatted
          } else {
            sendShipData.purchaseOrderDate = this.poPatchDate
          }
        }
        if (this.shipmentForm.get('invoiceDate').value) {
          invoiceDate = this.shipmentForm.get('invoiceDate').value
          if (invoiceDate.formatted) {
            sendShipData.invoiceDate = invoiceDate.formatted
          } else {
            sendShipData.invoiceDate = this.invoicePatchDate
          }
        }
        // if (this.shipmentForm.get('lcDate').value) {
        //   lcDate = this.shipmentForm.get('lcDate').value
        //   if (lcDate.formatted) {
        //     sendShipData.lcDate = lcDate.formatted
        //   } else {
        //     sendShipData.lcDate = this.lcPatchDate
        //   }
        // }
        let tempStartDate
        let tempEndDate
        if (this.createCertificateForm.get('polStartDate').value) {
          tempStartDate = this.createCertificateForm.value.polStartDate;
          let pStart = moment(this.createCertificateForm.value.polStartDate).format('DD/MM/YYYY HH:mm')
          sendCertData.polStartDate = pStart
          sendShipData.policyStartDate = pStart
          if (pStart == "Invalid date") {
            sendCertData.polStartDate = tempStartDate
            sendShipData.policyStartDate = tempStartDate
          }
        }
        if (this.createCertificateForm.get('polEndDate').value) {
          tempEndDate = this.createCertificateForm.value.polEndDate
          let pEndDate = moment(this.createCertificateForm.value.polEndDate).format('DD/MM/YYYY HH:mm')
          sendCertData.polEndDate = pEndDate
          sendShipData.policyEndDate = pEndDate
          if (pEndDate == "Invalid date") {
            sendCertData.polEndDate = tempEndDate
            sendShipData.policyEndDate = tempEndDate
          }
        }
        if (this.shipmentForm.get('sailingDate').value) {
          sailingDate = this.shipmentForm.get('sailingDate').value
          sendShipData.sailingDate = moment(sailingDate).format('DD/MM/YYYY HH:mm');
        }
        if (this.shipmentForm.get('lcDate').value) {
          lcDate = this.shipmentForm.get('lcDate').value
          sendShipData.lcDate = moment(lcDate).format('DD/MM/YYYY HH:mm');
        }
        sendCertData.deptCode = this.session.get('departmentCode');
        sendCertData.divnCode = this.session.get('divisionCode');
        sendCertData.mapId = "AGENT_CERT_POL_SCR";
        sendCertData.accountgenYn = "1";
        sendShipData.openPolicyNo = this.policyNo;
        sendShipData.userId = this.userId;
        sendCertData.schCode = this.schCode;
        for (let vessel of this.vesselList) {
          if (vessel.code == sendShipData.vesselName) {
            sendShipData.vesselName = vessel.desc;
            sendShipData.vesselCode = vessel.code;
            break;
          }
        }

        this.marineService.getInvoiceCount(sendShipData).subscribe(res => {
          this.loaderService.isBusy = false
          let invCount = res.exist;
          if (invCount != 0) {
            if (window.confirm("Invoice number exists for other certificate .Do you want to proceed ?")) {
              this.marineService.updateQuotaDetails(sendCertData).subscribe(updateQuotaDetails => {
                sendShipData.departmentType = sendCertData.departmentType;
                sendShipData.consigneeName = sendCertData.consigneeName;
                this.marineService.insertShiptmentDetails(sendShipData).subscribe(res => {
                  this.loaderService.isBusy = false
                  if (res.respCode !== 2000) {
                    this.messageService.add({ severity: 'success', summary: 'Success Message', detail: res.errMessage });
                  }
                  this.getCalculatePricing();
                }, err => {
                  let obj = {
                    errMsg: err.error.errMessage
                  }
                  this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
                  (<HTMLInputElement>document.getElementById("proceedBtn")).disabled = false;
                })
              }, error => {
                //let errorMsg=JSON.parse(error["_body"]).errMessage;
                let errorMsg = error.error.errMessage;
                this.loaderService.isBusy = false;
                (<HTMLInputElement>document.getElementById("proceedBtn")).disabled = false;
              });
            } else {

            }
          } else {
            this.marineService.updateQuotaDetails(sendCertData).subscribe(updateQuotaDetails => {
              sendShipData.departmentType = sendCertData.departmentType;
              sendShipData.consigneeName = sendCertData.consigneeName;
              this.marineService.insertShiptmentDetails(sendShipData).subscribe(res => {
                this.loaderService.isBusy = false
                if (res.respCode !== 2000) {
                  this.messageService.add({ severity: 'success', summary: 'Success Message', detail: res.errMessage });
                }
                this.getCalculatePricing();
              }, err => {
                let obj = {
                  errMsg: err.error.errMessage
                }
                this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
                (<HTMLInputElement>document.getElementById("proceedBtn")).disabled = false;
              })
            }, error => {
              //let errorMsg=JSON.parse(error["_body"]).errMessage;
              let errorMsg = error.error.errMessage;
              this.loaderService.isBusy = false;
              (<HTMLInputElement>document.getElementById("proceedBtn")).disabled = false;
            });
          }
        }, err => {
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
        })

      } else {
        this.validateAllFormFields(this.shipmentForm);
        this.loaderService.isBusy = false;
        (<HTMLInputElement>document.getElementById("proceedBtn")).disabled = false;
      }
    } else {
      this.validateAllFormFields(this.createCertificateForm);
      this.loaderService.isBusy = false;
      (<HTMLInputElement>document.getElementById("proceedBtn")).disabled = false;
    }
  }

  getCalculatePricing() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      portal: this.portal,
      userId: this.userId,
      quote: this.quoteNo,
      policy: this.policyNo,
      schemeCode: this.schCode,
      productCode: this.prodCode
    }
    this.marineService.calculatePricing(obj).subscribe(res => {
      this.loaderService.isBusy = true;
      if (res.respCode == 2000) {
        const obj = {
          transId: this.transId,
          tranSrNo: this.tranSrNo,
          portal: this.portal,
          userId: this.userId,
          quote: this.quoteNo,
          policy: this.policyNo,
          schemeCode: this.schCode,
          productCode: this.prodCode,
          custCode: this.custCode,
          limitCustYN: this.limitCustYN,
          limitDeptYn: this.limitDeptYn,
        }
        this.loaderService.isBusy = false;
        this.router.navigate(['Marine-addl-Info'], { queryParams: obj, skipLocationChange: true });
      } else {
        let errorMsg = res.errMessage;
        let param = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo,
          "errMessage": errorMsg
        };
        this.commonService.insertErrorMsg(param).subscribe(response => {
          let obj = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": this.quoteNo
          };
          this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
        });
      }
      this.loaderService.isBusy = false;
      /*if (res.respCode == 5002) {
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: res.errMessage });
        let errorMsg = res.errMessage;
        let obj = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo,
          "errorMsg": errorMsg
        };
        this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
      } else
        this.router.navigate(['Marine-addl-Info'], { queryParams: obj });*/
    }, (error: HttpErrorResponse) => {
      let param = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "quoteNo": this.quoteNo,
        "errMessage": error.error.errMessage
      };
      this.commonService.insertErrorMsg(param).subscribe(response => {
        let obj = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo
        };
        this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
      });
    })
  }

  validDateChanged(evt) {
    let fromDate = evt.date
    let numberOfDays = 365;
    let startDate = new Date(fromDate.month + '/' + fromDate.day + '/' + fromDate.year);
    let returnDate = new Date(
      startDate.getFullYear(),
      startDate.getMonth(),
      startDate.getDate() - 1 + numberOfDays,
    );
    this.createCertificateForm.patchValue({
      polEndDate: this.appendZero(returnDate.getDate()) + '/' + this.appendZero(returnDate.getMonth() + 1) + '/' + returnDate.getFullYear()
    })
  }

  appendZero(temp: any) {
    if (temp < 10) {
      return '0' + temp;
    }
    return temp;
  }

  setFromTime(event) {
    let endDate = new Date(event);
    let year = endDate.getFullYear();
    let month = endDate.getMonth();
    let day = endDate.getDate();
    let hour = 0, minute = 0;
    if (day == new Date().getDate() && month == new Date().getMonth() && year == new Date().getFullYear()) {
      hour = new Date().getHours();
      minute = new Date().getMinutes();
    }
    let startDate = new Date(year, month, day, hour, minute);
    this.shipmentForm.patchValue({ sailingDate: startDate })
  }

  setLcTime(event) {
    let endDate = new Date(event);
    let year = endDate.getFullYear();
    let month = endDate.getMonth();
    let day = endDate.getDate();
    let hour = 0, minute = 0;
    if (day == new Date().getDate() && month == new Date().getMonth() && year == new Date().getFullYear()) {
      hour = new Date().getHours();
      minute = new Date().getMinutes();
    }
    let date = new Date(year, month, day, hour, minute);
    this.shipmentForm.patchValue({ lcDate: date })
  }

  updateEndDate(event) {
    let endDate = new Date(event);
    let year = endDate.getFullYear();
    let month = endDate.getMonth();
    let day = endDate.getDate();
    let duration = '12'
    //----
    let hour = 0, minute = 0;
    if (day == new Date().getDate() && month == new Date().getMonth() && year == new Date().getFullYear()) {
      hour = new Date().getHours();
      minute = new Date().getMinutes();
    }
    let startDate = new Date(year, month, day, hour, minute);
    this.createCertificateForm.patchValue({ polStartDate: startDate })
    //----
    //let toDate = new Date(year, month + 13, day - 1, 23, 59);
    let toDate = new Date(year, (month) + Number(duration), day - 1, 23, 59);
    this.createCertificateForm.patchValue({ polEndDate: toDate })
  }

  setFacOption(value: string) {
    if (value == "  Yes  " || value == "Yes") {
      this.disableFac = null;
      this.createCertificateForm.get('facOption').setValue("1");
    }
    else {
      this.createCertificateForm.get('facOption').setValue("0");
      this.disableFac = "true";
    }
  }

  setLCBank(value: string) {
    if (value == "  Yes  " || value == "Yes") {
      this.disableBank = null;
      this.shipmentForm.get('bankOption').setValue("1");
      this.shipmentForm.controls["lcNo"].setValidators(Validators.required);
      this.shipmentForm.controls["lcNo"].updateValueAndValidity();
    }
    else {
      this.disableBank = "true";
      this.shipmentForm.get('bankOption').setValue("0");
      this.shipmentForm.get('bankCode').setValue("");
      this.shipmentForm.get('lcNo').setValue("");
      this.shipmentForm.get('lcDate').setValue("");
      this.shipmentForm.controls["lcNo"].clearValidators();
      this.shipmentForm.controls["lcNo"].updateValueAndValidity();

    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true })
      }
    });
  }


  getBasisValuation(evt) {
    let code = evt.target.value
    let obj = {
      policyNo: this.policyNo,
      valuationCode: evt.target.value
    }
    this.marineService.getValuationCode(obj, code).subscribe(res => {
      this.shipmentForm.patchValue({
        valuationPerc: res.baseVal
      })

    })
  }

  disableVessel(evt) {
    this.enableVessel = null
    /* if (evt.target.value == '01') {
      this.enableVessel = 'true'
    } else {
      this.enableVessel = null
    } */
  }

  defaultKeyValue(evt, id, list) {
    let value: any = "";
    value = list.find((x: any) => x.key == evt.target.value);
    $("#" + id).val(value.value);
  }

  defaultVesselValue(evt, id, list) {
    let value: any = "";
    value = list.find((x: any) => x.code == evt.target.value);
    $("#" + id).val(value.desc);
  }

  getCurrencyRates(evt, tab) {
    this.loaderService.isBusy = true;
    let code = evt.target.value
    let obj = {
      currCode: evt.target.value,
    }
    this.marineService.getCurrencyRates(obj, code).subscribe(res => {
      if (tab == "SI") {
        this.siExchRate = "Exchange Rate: " + res.rate;
      } else {
        this.PremExchRate = "Exchange Rate: " + res.rate;
      }
      this.loaderService.isBusy = false;
    })
  }

  getExchangeRate(rate, tab) {
    this.loaderService.isBusy = true;
    let obj = {
      currCode: rate,
    }
    this.marineService.getCurrencyRates(obj, rate).subscribe(res => {
      if (tab == "SI") {
        this.siExchRate = "Exchange Rate: " + res.rate;
      } else {
        this.PremExchRate = "Exchange Rate: " + res.rate;
      }
      this.loaderService.isBusy = false;

    })
  }

  updateSumValue(index) {
    this.goodsList = this.shipmentForm.get('goodsList') as UntypedFormArray;
    let amount = parseFloat(this.goodsList.value[index].invAmt);
    if (amount) {
      let markValue: any = this.shipmentForm.get('valuationPerc').value;
      let totalValue = parseFloat(((markValue / 100) * amount).toFixed(2))
      let sumInsured = amount + totalValue
      this.goodsList.value[index]['sumInsured'] = sumInsured
      var siValue = this.currPipe.transform(sumInsured, '1.2-2');
      this.goodsList.controls[index].get('sumInsured').setValue(siValue);
    } else {
      this.goodsList.controls[index].get('sumInsured').setValue(0)
    }
  }
}
