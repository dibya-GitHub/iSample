import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarineCreateCertificateComponent } from './marine-create-certificate.component';

describe('MarineCreateCertificateComponent', () => {
  let component: MarineCreateCertificateComponent;
  let fixture: ComponentFixture<MarineCreateCertificateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarineCreateCertificateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarineCreateCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
