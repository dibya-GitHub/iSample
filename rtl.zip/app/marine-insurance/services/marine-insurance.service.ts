import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiUrls } from 'src/shared/api-urls';

@Injectable({
  providedIn: 'root'
})
export class MarineInsuranceService {
  public requestOption;
  public baseUrl = environment.baseUrl;
  uploadedData: any;

  constructor(
    public http: HttpClient,
    private session: SessionStorageService
  ) { }

  // ---------- Product List ----------//
  getProductDropdown(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_PRODUCTLIST + '?company=' + this.session.get('companyCode'), body)
  }

  getPolicyInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_MARINE_INFO + '?company=' + this.session.get('companyCode'), body)
  }

  createCertificate(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_CREATE_CERTIFICATE + '?company=' + this.session.get('companyCode'), body)
  }

  getDropdown(data) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_APPL_CODES + '?company=' + this.session.get('companyCode'), data);
  }

  getvaluationDD(data) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_MARINE_TYPES + '?company=' + this.session.get('companyCode'), data);
  }

  getPortDD(data) {
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_PORT + '?company=' + this.session.get('companyCode'), data);
  }

  getGoodsList(data) {
    return this.http.post<any>(this.baseUrl + 'getGoodsName?company=' + this.session.get('companyCode'), data);
  }

  updateQuotaDetails(data) {
    return this.http.post<any>(this.baseUrl + 'updateQuoteInfo?company=' + this.session.get('companyCode'), data);
  }

  getInvoiceCount(data) {
    return this.http.post<any>(this.baseUrl + 'getExistingInvNo?company=' + this.session.get('companyCode'), data);
  }

  insertShiptmentDetails(data) {
    return this.http.post<any>(this.baseUrl + 'shipmentDetails?company=' + this.session.get('companyCode'), data);
  }

  updateShiptmentDetails(data) {
    return this.http.put<any>(this.baseUrl + 'shipmentDetails?company=' + this.session.get('companyCode'), data);
  }

  calculatePricing(data) {
    return this.http.post<any>(this.baseUrl + 'calcMarinePrem?company=' + this.session.get('companyCode'), data);
  }

  getCoverDetails(data) {
    return this.http.post<any>(this.baseUrl + 'getCoversInfo?company=' + this.session.get('companyCode'), data);
  }

  getInvoiceDetails(data) {
    return this.http.post<any>(this.baseUrl + 'loadInvoiceDetails?company=' + this.session.get('companyCode'), data);
  }

  approvePolicy(data) {
    return this.http.post<any>(this.baseUrl + 'approvePolicy?company=' + this.session.get('companyCode'), data);
  }

  uploadCertificate(data) {
    return this.http.post<any>(this.baseUrl + 'upldCertDoc?company=' + this.session.get('companyCode'), data);
  }

  searchCertificate(batchId, data?) {
    return this.http.post<any>(this.baseUrl + 'getCertByBatchId?company=' + this.session.get('companyCode') + '&batchId=' + batchId, data);
  }

  approveCertificate(data) {
    return this.http.post<any>(this.baseUrl + 'approveCertificate?company=' + this.session.get('companyCode'), data);
  }

  confirmAgentQuote(data) {
    return this.http.post<any>(this.baseUrl + 'confirmAgentQuote?company=' + this.session.get('companyCode'), data);
  }

  getUploadCount(data) {
    return this.http.post<any>(this.baseUrl + 'getDocCount?company=' + this.session.get('companyCode'), data);
  }

  getValuationCode(data, code) {
    return this.http.post<any>(this.baseUrl + 'getBasisVal?company=' + this.session.get('companyCode') + '&valuationCode=' + code + '&policyNo=' + data.policyNo, data);
  }

  getCurrencyRates(data, code) {
    return this.http.post<any>(this.baseUrl + 'getCurrencyRates?company=' + this.session.get('companyCode') + '&currencyCode=' + code, data);

  }

  getCertificateAfterUpload(data) {
    return this.http.post<any>(this.baseUrl + 'getPolValues?company=' + this.session.get('companyCode'), data);
  }

  getPrintBatch(data) {
    return this.http.post<any>(this.baseUrl + 'printBatch?company=' + this.session.get('companyCode'), data);
  }

  getCertificateInfo(data) {
    return this.http.post<any>(this.baseUrl + 'getCertificateInfo?company=' + this.session.get('companyCode'), data);
  }

  updateCertificateInfo(data) {
    return this.http.post<any>(this.baseUrl + 'updateCertificateInfo?company=' + this.session.get('companyCode'), data);
  }

  retreiveCertificateInfo(data) {
    return this.http.post<any>(this.baseUrl + 'getCertificate?company=' + this.session.get('companyCode'), data);
  }


}
