import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarineUploadInfoComponent } from './marine-upload-info.component';

describe('MarineUploadInfoComponent', () => {
  let component: MarineUploadInfoComponent;
  let fixture: ComponentFixture<MarineUploadInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarineUploadInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarineUploadInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
