import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { MarineInsuranceService } from '../services/marine-insurance.service';

@Component({
  selector: 'app-marine-upload-info',
  templateUrl: './marine-upload-info.component.html',
  styleUrls: ['./marine-upload-info.component.scss']
})
export class MarineUploadInfoComponent implements OnInit {
  policyNo;
  userId;
  portal;
  transId;
  tranSrNo;
  certificateList: any = [];
  totCommission = 0.00;
  totPremium = 0.00;
  totSumInsured = 0.00;
  coverInfoForm: UntypedFormGroup;
  clickEventsubscription: Subscription;
  receivedData
  batchId;
  emailId;
  agentId;
  params;
  prodCode;
  schCode;
  verifiedArray: any = [];
  shipmentForm: UntypedFormGroup;
  showEdit = true;
  showPopUp = false;
  selectedAll = false;
  siCurrencylist: any;
  premiumCurrList: any;
  facPoolsList: any;
  conveyanceTypeList: any
  portFromList: any;
  portToList: any;
  valuationList: any;
  bankofFinanceList: any;
  deptTypeList: any;
  goodsPopupList: any;
  vesselList: any;
  selectedGoodItem
  goodsList: UntypedFormArray;
  public myDatePickerOptions: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  }
  public poDate: any;
  public invDate: any;
  public lcDate: any;
  public blDate: any;
  public sailDate: any;
  invoicePatchdate;
  poPatchDate;
  lcPatchDate;
  blPatchDate;
  sailPatchDate;
  printSingle;
  printCreditAccess: any;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public fb: UntypedFormBuilder,
    public loaderService: LoaderService,
    public agentService: AgentUserService,
    public commonService: AgentUserService,
    private session: SessionStorageService,
    private messageService: MessageService,
    public marineService: MarineInsuranceService,
  ) {
    this.route.queryParams.subscribe((params: any) => {
      this.params = params
      this.policyNo = params.policyNo;
      if (params.batchId !== undefined || params.batchId !== null) {
        this.batchId = params.batchId
      }
      if (params.prodCode !== undefined || params.prodCode !== null) {
        this.prodCode = params.prodCode
      }
      if (params.schCode !== undefined || params.schCode !== null) {
        this.schCode = params.schCode
      }
    });

    this.userId = this.session.get('LoginID')
    this.portal = this.session.get('portaltype')
    this.agentId = this.session.get('agent')
  }

  ngOnInit() {

    this.loaderService.isBusy = true
    this.createForm();
    this.createShipmentForm();
    this.receivedData = this.marineService.uploadedData
    this.getSIDropdown();
    this.getValuation();
    this.getConveyance();
    this.getVesselDD();
    this.getPortFrom();
    this.getPortTo();
    this.getBankDD();
    this.getDeptList();
    this.getGoodsList();
    this.printCreditAccess = this.session.get("printCreditAccess");
    if (this.receivedData) {
      this.batchId = this.receivedData.uploadInfos[0].batchId
    }
    if (this.receivedData.pageStatus == "UnApproved" || this.receivedData.pageStatus == "unapproved") {
      this.showEdit = true;
    } else {
      this.showEdit = false
    }
    if (this.receivedData.uploadInfos != undefined && this.receivedData.uploadInfos.length != 0) {
      this.certificateList = this.receivedData.uploadInfos
      this.certificateList.map(v => Object.assign(v, { checked: false }))
    }
    this.totCommission = this.receivedData.totCommission;
    this.totPremium = this.receivedData.totPremium;
    this.totSumInsured = this.receivedData.totSumInsured;
  }

  getDetails() {
    this.loaderService.isBusy = true
    let obj = {
      policyNo: this.policyNo,
      agentId: this.agentId
    }
    this.marineService.getCertificateAfterUpload(obj).subscribe(res => {
      let data = res.bean;
      this.coverInfoForm.patchValue({
        customerName: data.openInsuredName,
        transId: data.openTransId,
        tranSrNo: data.openTranSrNo,
        productName: data.productName,
        openPolicyNo: this.policyNo,
        schemeName: data.schemeName,
        batchId: this.batchId,
        emailId: data.emailId,
      })
      this.tranSrNo = data.tranSrNo
      this.transId = data.transId
      this.loaderService.isBusy = false
    })
  }

  createForm() {
    this.coverInfoForm = this.fb.group({
      batchId: this.batchId,
      customerName: undefined,
      mapId: undefined,
      transId: undefined,
      tranSrNo: undefined,
      agentId: undefined,
      agentName: undefined,
      openPolicyNo: undefined,
      polEndDate: undefined,
      polStartDate: undefined,
      emailId: undefined,
      policyNo: undefined,
      product: undefined,
      productName: undefined,
      schemeName: undefined,
    });
    this.getDetails();
  }

  search() {
    this.loaderService.isBusy = true
    this.marineService.searchCertificate(this.batchId, this.params).subscribe(res => {
      this.certificateList = res.uploadInfos;
      this.totCommission = res.totCommission;
      this.totPremium = res.totPremium;
      this.totSumInsured = res.totSumInsured;

    })
  }

  approve() {
    this.certificateList.map(element => {
      let tempData = element.certTransId
      this.verifiedArray.push(tempData)
    });
    let obj = {
      transId: this.params.transId,
      tranSrNo: this.params.tranSrNo,
      portal: this.params.portal,
      userId: this.params.userId,
      batchId: this.batchId,
      verified: this.verifiedArray.toString(),
      certificates: ''
    }
    this.loaderService.isBusy = true;
    if (this.verifiedArray != undefined && this.verifiedArray.length != 0) {
      this.marineService.approveCertificate(obj).subscribe(approveResponse => {
        this.showEdit = false;
        this.messageService.add({ severity: 'success', summary: 'Approved Successfully' });
        this.search();
        this.loaderService.isBusy = false;
        $("#closeSummary").click();

      }, error => {
        if (error.error.responseCode == 504) {
          alert("Process is taking time, please try again after some time or re-query the Batch -" + this.batchId);
          this.router.navigate(['agentdashboard']);
          location.reload();
        } else {
          this.loaderService.isBusy = true;
          let param = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": this.batchId,
            "errMessage": error.error.errMessage
          };
          this.agentService.insertErrorMsg(param).subscribe(response => {
            let obj = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "quoteNo": (this.batchId) ? this.batchId : this.policyNo
            };
            this.loaderService.isBusy = false;
            this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
          });
        }
      })
    } else {
      alert("Please Check all the certificates");
      this.loaderService.isBusy = false;
      // this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check all the certificates' });
    }
  }

  print() {
    this.loaderService.isBusy = true;
    let data = this.printSingle;
    if ($("#schdule").prop('checked'))
      this.commonService.getReport(data.certTransId, '0', 'Schedule', this.session.get("portaltype"), 'POL', "", "");
    if ($("#debitNote").prop('checked'))
      this.commonService.getReport(data.certTransId, '0', 'Receipt', this.session.get("portaltype"), 'POL', "", "");
    if ($("#creditNote").prop('checked'))
      this.commonService.getReport(data.certTransId, '0', 'Credit', this.session.get("portaltype"), 'POL', "", "");
    this.loaderService.isBusy = false;
    $("#closePrintSingle").click()
  }

  printAll() {
    this.loaderService.isBusy = true
    let obj = {
      batchId: this.batchId
    }
    let sendObj = {
      divnCode: this.session.get("divisionCode"),
      departmentCode: this.session.get("departmentCode"),
      compCode: this.session.get("companyCode"),
      lobCode: "03",
      reportType: "MARINE_CERT",
      batchId: this.batchId,
      schCode: this.prodCode,
      prodCode: this.schCode,
      tranType: "POL"
    }
    this.marineService.getPrintBatch(obj).subscribe(res => {
      this.loaderService.isBusy = false
      if ($("#schduleBulk").prop('checked')) {
        this.agentService.getReportUrl(sendObj)
      }
      if ($("#debitNoteBulk").prop('checked')) {
        sendObj.reportType = "POL_DN"
        this.agentService.getReportUrl(sendObj);
      }
      if ($("#creditNoteBulk").prop('checked')) {
        sendObj.reportType = "POL_CN"
        this.agentService.getReportUrl(sendObj);
      }
      $("#closePrintBulk").click()
    })
  }

  getSIDropdown() {
    let obj = {
      policyNo: this.policyNo,
      type: 'APPL_SICUR'
    }
    this.marineService.getvaluationDD(obj).subscribe(res => {
      this.siCurrencylist = res.typeList
    })
  }

  getValuation() {
    let obj = {
      policyNo: this.policyNo,
      type: 'APPL_BASIS'
    }
    this.marineService.getvaluationDD(obj).subscribe(res => {
      this.valuationList = res.typeList
    })
  }

  getConveyance() {
    this.agentService.getApplicationCodes('CONV_TYPE').subscribe(res => {
      this.conveyanceTypeList = res.appCodesArray
    })
  }

  getVesselDD() {
    this.agentService.getApplicationCodes('VESSEL').subscribe(res => {
      this.vesselList = res.appCodesArray
    })
  }

  getGoodsList() {
    let obj = {
      policyNo: this.policyNo,
    }
    this.marineService.getGoodsList(obj).subscribe(res => {
      this.goodsPopupList = res.goodsList
    })
  }

  getPortFrom() {
    let obj = {
      policyNo: this.policyNo,
      type: 'PORT_FROM'
    }
    this.marineService.getPortDD(obj).subscribe(res => {
      this.portFromList = res.ports
    })
  }
  getPortTo() {
    let obj = {
      policyNo: this.policyNo,
      type: 'PORT_TO'
    }
    this.marineService.getPortDD(obj).subscribe(res => {
      this.portToList = res.ports
    })
  }

  getBankDD() {
    this.agentService.getApplicationCodes('BANK').subscribe(res => {
      this.bankofFinanceList = res.appCodesArray
    })
  }

  getDeptList() {
    this.agentService.getApplicationCodes('DEPT_TYPE').subscribe(res => {
      this.deptTypeList = res.appCodesArray
    })
  }

  checkVerify(evt, data) {
    debugger;
    if (evt.target.checked) {
      this.selectedAll = false;
      this.showPopUp = true;
      this.verifiedArray.push(data.certTransId)
      this.selectedCertificate(data);
    } else {
      this.verifiedArray.pop(data.certTransId)
      this.showPopUp = false;
    }
    if (this.verifiedArray.length > 1) {
      (<HTMLInputElement>document.getElementById("print")).disabled = true;
      (<HTMLInputElement>document.getElementById("goodsModal")).disabled = true;
      (<HTMLInputElement>document.getElementById("printAll")).disabled = true;
    }
  }

  CheckAllOptions(evt) {
    if (evt.target.checked == true) {
      this.certificateList.forEach(val => { val.checked = true });
      this.selectedAll = true;
      this.showPopUp = false;
    } else {
      this.certificateList.forEach(val => { val.checked = false });
      this.selectedAll = false;
      this.showPopUp = false;
    }
  }

  selectedCertificate(data) {
    let obj = {
      certTransId: data.certTransId
    }
    const control = <UntypedFormArray>this.shipmentForm.controls['goodsList'];
    for (let i = control.length - 1; i >= 0; i--) {
      control.removeAt(i)
    }
    this.marineService.getCertificateInfo(obj).subscribe(res => {
      let data = res.uploadInfo;
      this.poPatchDate = data.orderDate
      this.invoicePatchdate = data.invoiceDate
      this.lcPatchDate = data.lcDate
      this.blPatchDate = data.blDate
      this.sailPatchDate = data.sailDate
      if (data.orderDate) {
        let newPoDate = data.orderDate.split('/')
        this.poDate = { date: { year: parseInt(newPoDate[2]), month: parseInt(newPoDate[1]), day: parseInt(newPoDate[0]) } };
      }
      if (data.invoiceDate) {
        let newInvDate = data.invoiceDate.split('/')
        this.invDate = { date: { year: parseInt(newInvDate[2]), month: parseInt(newInvDate[1]), day: parseInt(newInvDate[0]) } };
      }
      if (data.lcDate) {
        let newlcDate = data.lcDate.split('/')
        this.lcDate = { date: { year: parseInt(newlcDate[2]), month: parseInt(newlcDate[1]), day: parseInt(newlcDate[0]) } };
      }
      if (data.blDate) {
        let newblDate = data.blDate.split('/')
        this.blDate = { date: { year: parseInt(newblDate[2]), month: parseInt(newblDate[1]), day: parseInt(newblDate[0]) } };
      }
      if (data.sailDate) {
        let newsailDate = data.sailDate.split('/')
        this.sailDate = { date: { year: parseInt(newsailDate[2]), month: parseInt(newsailDate[1]), day: parseInt(newsailDate[0]) } };
      }
      this.shipmentForm.patchValue({
        additionalDesc: data.additionalDesc,
        address1: data.address1,
        basisValCode: data.basisValCode,
        batchId: data.batchId,
        certNo: data.certNo,
        certTransId: data.certTransId,
        code: data.code,
        commission: data.commission,
        convDesc: data.convDesc,
        convType: data.convType,
        custCode: data.custCode,
        desc: data.desc,
        goodsDesc: data.goodsDesc,
        invAmt: data.invAmt,
        invoiceAmt: data.invoiceAmt,
        invoiceNo: data.invoiceNo,
        openPolicyNo: data.openPolicyNo,
        openTranSrNo: data.openTranSrNo,
        openTransId: data.openTransId,
        orderNo: data.orderNo,
        portFmCode: data.portFmCode,
        portFromName: data.portFromName,
        portToCode: data.portToCode,
        portToName: data.portToName,
        portal: data.portal,
        premium: data.premium,
        productCode: data.productCode,
        schemeCode: data.schemeCode,
        siCurrCode: data.siCurrCode,
        srNo: data.srNo,
        sumInsured: data.sumInsured,
        userId: data.userId,
        valPerc: data.valPerc,
        verifyYN: data.verifyYN,
        vesselCode: data.vesselCode,
        vesselName: data.vesselName,
        cumInvoiceFc: data.cumInvoiceFc,
        referenceNo: data.referenceNo,
        bankYN: data.bankYN,
        bankCode: data.bankCode,
        deptType: data.deptType,
        lcNo: data.lcNo,
        blNo: data.blNo,
        consigneeName: data.consigneeName,
        // goodsList: data.goodsList,
      })
      this.getBasisValuation(data.basisValCode)
      let goodData = res.goodsList
      if (goodData.length > 0) {
        for (let i = 0; i < goodData.length; i++) {
          this.addNewRow('add');
        }
        this.shipmentForm.patchValue({
          goodsList: goodData
        });
      }
    })
  }

  printSingleCert(data) {
    this.printSingle = data;
  }

  createShipmentForm() {
    this.shipmentForm = this.fb.group({
      additionalDesc: '',
      address1: '',
      basisValCode: ['', Validators.required],
      batchId: '',
      certNo: '',
      certTransId: '',
      code: '',
      commission: '',
      convDesc: '',
      convType: ['', Validators.required],
      custCode: '',
      desc: '',
      goodsDesc: '',
      invAmt: '',
      invoiceAmt: '',
      invoiceDate: '',
      invoiceNo: '',
      openPolicyNo: '',
      openTranSrNo: '',
      openTransId: '',
      orderDate: '',
      orderNo: '',
      portFmCode: ['', Validators.required],
      portFromName: '',
      portToCode: ['', Validators.required],
      portToName: '',
      portal: '',
      premium: '',
      productCode: '',
      schemeCode: '',
      siCurrCode: ['', Validators.required],
      srNo: '',
      sumInsured: '',
      userId: '',
      valPerc: '',
      verifyYN: '',
      vesselCode: '',
      vesselName: '',
      cumInvoiceFc: '',
      referenceNo: '',
      bankYN: '',
      bankCode: '',
      deptType: '',
      lcNo: '',
      lcDate: '',
      blNo: '',
      consigneeName: '',
      blDate: '',
      sailDate: '',
      goodsList: this.fb.array([]),
    })
  }

  createItem(): UntypedFormGroup {
    return this.fb.group({
      code: null,
      desc: null,
      invAmt: null,
      cumInvoiceFc: null,
      sumInsured: null,
      srNo: null
    });
  }

  addNewRow(mode: string): void {
    this.goodsList = this.shipmentForm.get('goodsList') as UntypedFormArray;
    this.createItem();
    this.goodsList.push(this.createItem());
  }

  deleteRow(index) {
    this.goodsList = this.shipmentForm.get('goodsList') as UntypedFormArray;
    this.goodsList.removeAt(index);
    // this.disableAddRow = false;
    if (this.goodsList.length == 0) {
      // this.showFlag = false
    }
  }

  getBasisValuation(evt) {
    let obj = {
      policyNo: this.policyNo,
      valuationCode: evt
    }
    this.marineService.getValuationCode(obj, evt).subscribe(res => {
      this.shipmentForm.patchValue({
        valPerc: res.baseVal
      })

    })
  }

  updateSumValue(index) {
    this.goodsList = this.shipmentForm.get('goodsList') as UntypedFormArray;
    let amount = parseInt(this.goodsList.value[index].invAmt);
    if (amount) {
      let markValue: any = this.shipmentForm.get('valPerc').value;
      let totalValue = parseFloat(((markValue / 100) * amount).toFixed(2))
      let sumInsured = amount + totalValue
      this.goodsList.value[index]['sumInsured'] = sumInsured
      this.goodsList.controls[index].get('sumInsured').setValue(sumInsured)
    } else {
      this.goodsList.controls[index].get('sumInsured').setValue(0)
    }
  }

  updateShipmentDetails() {

    let poDate, invoiceDate, sailDate, lcDate, blDate
    if (this.shipmentForm.valid) {
      if (this.shipmentForm.get('orderDate').value) {
        poDate = this.shipmentForm.get('orderDate').value
        if (poDate.formatted) {
          this.shipmentForm.patchValue({
            orderDate: poDate.formatted,
          })
        } else {
          this.shipmentForm.patchValue({
            orderDate: this.poPatchDate,
          })
        }
      }
      if (this.shipmentForm.get('invoiceDate').value) {
        invoiceDate = this.shipmentForm.get('invoiceDate').value
        if (invoiceDate.formatted) {
          this.shipmentForm.patchValue({
            invoiceDate: invoiceDate.formatted,
          })
        } else {
          this.shipmentForm.patchValue({
            invoiceDate: this.invoicePatchdate,
          })
        }
      }
      if (this.shipmentForm.get('lcDate').value) {
        lcDate = this.shipmentForm.get('lcDate').value
        if (lcDate.formatted) {
          this.shipmentForm.patchValue({
            lcDate: lcDate.formatted,
          })
        } else {
          this.shipmentForm.patchValue({
            lcDate: this.lcPatchDate,
          })
        }
      }
      if (this.shipmentForm.get('blDate').value) {
        blDate = this.shipmentForm.get('blDate').value
        if (blDate.formatted) {
          this.shipmentForm.patchValue({
            blDate: blDate.formatted,
          })
        } else {
          this.shipmentForm.patchValue({
            blDate: this.blPatchDate,
          })
        }
      }
      if (this.shipmentForm.get('sailDate').value) {
        sailDate = this.shipmentForm.get('sailDate').value
        if (sailDate.formatted) {
          this.shipmentForm.patchValue({
            sailDate: sailDate.formatted,
          })
        } else {
          this.shipmentForm.patchValue({
            sailDate: this.sailPatchDate,
          })
        }
      }
      this.shipmentForm.value.userId = this.userId
      this.loaderService.isBusy = true
      this.marineService.updateCertificateInfo(this.shipmentForm.value).subscribe(res => {
        this.loaderService.isBusy = false;
        // this.showEdit = false
        this.search();
        $("#close").click()
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Updated successfully' });
      }, (error: HttpErrorResponse) => {
        let errorMsg = error.error.errMessage;
        let obj = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.policyNo,
          "errMessage": errorMsg
        };
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: errorMsg });
        // this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
        this.loaderService.isBusy = false;
        alert("Error Occured while updating" + errorMsg);
      })
    } else {
      this.validateAllFormFields(this.shipmentForm);
      this.loaderService.isBusy = false
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  setLCBank(event) {
    
  }
}
