import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { AgentHttpclientService } from 'src/app/services/agent-httpclient.service';
import { Search } from 'src/shared/classes/search';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { MarineInsuranceService } from '../services/marine-insurance.service';


@Component({
  selector: 'app-marine-addl-info',
  templateUrl: './marine-addl-info.component.html',
  styleUrls: ['./marine-addl-info.component.scss']
})
export class MarineAddlInfoComponent implements OnInit {
  transId;
  tranSrNo;
  quoteNo
  coverData;
  invoiceData;
  grandTotal;
  termsAndConditionses;
  userId;
  portal;
  objData;
  showSavedInfo = false;
  showApprovedInfo = false;
  bean;
  openPolNo;
  prodCode;
  schCode;
  uploadCount;
  fileTypeList;
  myInputVariable: ElementRef;
  lobCode = '03';
  uploadForm: UntypedFormGroup;
  uploadSuccess = false
  accept: boolean;
  checkboxVal: boolean;
  termsPolNo;
  siCurrName;
  premCurrName;
  custCode: any;
  limitCustYN: any;
  constructor(
    public route: ActivatedRoute,
    public marineService: MarineInsuranceService,
    private session: SessionStorageService,
    public loaderService: LoaderService,
    private messageService: MessageService,
    public router: Router,
    public commonService: AgentUserService,
    public agentService: AgentHttpclientService,
    public fb: UntypedFormBuilder,

  ) {
    this.route.queryParams.subscribe((params: any) => {
      this.tranSrNo = params.tranSrNo
      this.transId = params.transId
      this.quoteNo = params.quote
      this.openPolNo = params.policy
      this.prodCode = params.productCode
      this.schCode = params.schemCode
      this.custCode = params.custCode
      this.limitCustYN = params.limitCustYN
    });
    this.userId = this.session.get('LoginID')
    this.portal = this.session.get('portaltype')
  }

  fileUploadList = [
    new Search('024', 'Invoice'),
    new Search('092', 'Purchase Order'),
    new Search('030', 'Pro_Forma_Invoice'),
    new Search('093', 'Email'),
  ];

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.getCoverDetails();
    this.getRiskDetails();
    //this.getFileTypeList();
    this.createForm();
    this.objData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      portal: this.portal,
      userId: this.userId
    }
    window.scroll(0, 0);
    this.getCertQuoteInfo();
  }

  getCoverDetails() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "S"
    }

    this.marineService.getCoverDetails(obj).subscribe(res => {
      this.coverData = res.coversArray
      this.loaderService.isBusy = false
    })
  }

  getRiskDetails() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      prodCode: this.prodCode,
      schCode: this.schCode

    }
    this.marineService.getInvoiceDetails(obj).subscribe(res => {
      this.invoiceData = res.riskInfo;
      this.grandTotal = res.grandTotal;
      this.termsAndConditionses = res.termsAndConditionses;
      this.loaderService.isBusy = false
    })
  }

  getFileTypeList() {
    this.agentService.getApplicationCodes('DOC_TYPE').subscribe(res => {
      this.fileTypeList = res.appCodesArray
    })
  }

  createForm() {
    this.uploadForm = this.fb.group({
      uploadData: '',
      docValue: '',
      remarks: '',
      uploadData1: '',
      docValue1: '',
      remarks1: '',
      uploadData2: '',
      docValue2: '',
      remarks2: '',
      uploadData3: '',
      docValue3: '',
      remarks3: '',
    })

  }

  upload(event: any, files?: any, doc?: any) {
    this.loaderService.isBusy = true
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];
    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('portal', this.portal);
    formData.append('lobCode', this.lobCode);
    formData.append('docType', "POL");
    formData.append('userId', this.userId);
    formData.append('menu', '231');
    formData.append('remarks', this.uploadForm.get('remarks').value);
    formData.append('docCode', this.uploadForm.get('docValue').value);
    this.commonService.uploadDocuments(formData).subscribe(res => {
      this.uploadSuccess = true
    })
  }

  upload1(event: any, files?: any, doc?: any) {
    this.loaderService.isBusy = true
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];
    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('portal', this.portal);
    formData.append('lobCode', this.lobCode);
    formData.append('docType', "POL");
    formData.append('userId', this.userId);
    formData.append('menu', '231');
    formData.append('remarks', this.uploadForm.get('remarks1').value);
    formData.append('docCode', this.uploadForm.get('docValue1').value);
    this.commonService.uploadDocuments(formData).subscribe(res => {
      this.uploadSuccess = true
    })
  }

  upload2(event: any, files?: any, doc?: any) {
    this.loaderService.isBusy = true
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];
    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('portal', this.portal);
    formData.append('lobCode', this.lobCode);
    formData.append('docType', "POL");
    formData.append('userId', this.userId);
    formData.append('menu', '231');
    formData.append('remarks', this.uploadForm.get('remarks2').value);
    formData.append('docCode', this.uploadForm.get('docValue2').value);
    this.commonService.uploadDocuments(formData).subscribe(res => {
      this.uploadSuccess = true
    })
  }

  upload3(event: any, files?: any, doc?: any) {
    this.loaderService.isBusy = true
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];
    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('portal', this.portal);
    formData.append('lobCode', this.lobCode);
    formData.append('docType', "POL");
    formData.append('userId', this.userId);
    formData.append('menu', '231');
    formData.append('remarks', this.uploadForm.get('remarks3').value);
    formData.append('docCode', this.uploadForm.get('docValue3').value);
    this.commonService.uploadDocuments(formData).subscribe(res => {
      this.uploadSuccess = true
    })
  }


  back() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      quoteNo: this.quoteNo,
      editYn: "1",
      openPolicyNo: this.openPolNo
    };
    this.router.navigate(['create-certificate'], { queryParams: obj, skipLocationChange: true });
  }

  saveQuote() {
    this.router.navigate(['quoteconfirm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode': 'saveQuote', 'quoteNo': this.quoteNo }, skipLocationChange: true });
  }

  printDraft() {
    this.loaderService.isBusy = true;
    this.commonService.getReport(this.transId, this.tranSrNo, "POL_DRAFT", this.session.get("portaltype"), "QOT", null, null);
  }

  approve() {
    //if (this.uploadSuccess == true) {
    this.loaderService.isBusy = true
    this.marineService.approvePolicy(this.objData).subscribe(res => {
      if (res.respCode == 2000) {
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: res.errMessage });
        let errorMsg = res.errMessage;
        let obj = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo
        };
        this.marineService.confirmAgentQuote(this.objData).subscribe(res => {
          this.bean = res
        })
        this.showSavedInfo = true;
        this.showApprovedInfo = true;
        window.scroll(10, 0);
        this.loaderService.isBusy = false;
      }

    }, error => {
      this.loaderService.isBusy = false;
      let param = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "quoteNo": this.quoteNo,
        "errMessage": error.error.errMessage
      };
      this.commonService.insertErrorMsg(param).subscribe(response => {
        let obj = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "quoteNo": this.quoteNo
        };
        this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
      });
    });
    /*} else {
      this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Upload Document' });
      alert('Please upload document')
    }*/
  }

  loadAgentDoc(reportType) {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=1000,height=400,left=100%,top=100%`;
    var winRef = window.open('viewdocument?transId=' + this.transId + '&reportType=&policyNo=' + this.quoteNo + '&page=dash', 'Product Category', param);
  }

  GenerateReport(reportType) {
    this.loaderService.isBusy = true;
    this.commonService.getReport(this.transId, this.tranSrNo, reportType, this.session.get("portaltype"), 'POL', "", "");
    this.loaderService.isBusy = false;
  }

  fnClose() {
    this.router.navigate(['marine-insurance']);
  }

  getDocCount() {
    let strPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.marineService.getUploadCount(strPostData).subscribe(response => {
      if (response.respCode == 2000) {
        this.uploadCount = response.count;
        if (this.uploadCount != "0") {
          this.approve();
        } else {
          let errMess = "Please upload one document"
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: errMess });
          alert('Please upload one document')
        }
      }
    }, (error: HttpErrorResponse) => {
    });
  }

  checkMarineTerms(event) {
    if (event) {
      this.accept = true;
      this.checkboxVal = false;
    } else {
      this.accept = false;
      this.checkboxVal = true;
    }
  }
  getCertQuoteInfo() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
    }
    this.marineService.retreiveCertificateInfo(obj).subscribe(res => {
      let data = res.quoteInfo;
      this.termsPolNo = data.openPolicyNo;
      this.siCurrName = data.siCurrName;
      this.premCurrName = data.premCurrName;
    })
  }

  hasPrintAccess() {
    return ("1" == this.session.get("printCreditAccess"));
  }

}
