import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarineAddlInfoComponent } from './marine-addl-info.component';

describe('MarineAddlInfoComponent', () => {
  let component: MarineAddlInfoComponent;
  let fixture: ComponentFixture<MarineAddlInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarineAddlInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarineAddlInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
