import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { MarineInsuranceService } from '../services/marine-insurance.service';

@Component({
  selector: 'app-marine-info',
  templateUrl: './marine-info.component.html',
  styleUrls: ['./marine-info.component.scss']
})
export class MarineInfoComponent implements OnInit {
  productList: any = [];
  sendObj: any;
  agentId;
  showDate = false;
  showUpload = false;
  currPolicyNo: any
  policyForm: UntypedFormGroup;
  showUploadButton = false;
  fileData: FileList;
  quoteData;
  userId;
  portal;
  divisionCode;
  deptCode;
  ip;
  batchIdList
  @ViewChild('myInput')
  myInputVariable: ElementRef;
  paramsData;
  showSearchBy = false;
  batchId;
  prodArr: any[] = [];
  fileUrl: any;
  logId: any;

  constructor(
    public router: Router,
    private fb: UntypedFormBuilder,
    private sanitizer: DomSanitizer,
    public loaderService: LoaderService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    public marineService: MarineInsuranceService,
  ) {
    this.loaderService.isBusy = false;
    this.agentId = this.session.get('agent');
    this.userId = this.session.get('LoginID')
    this.portal = this.session.get('portaltype')
    this.divisionCode = this.session.get('divisionCode')
    this.deptCode = this.session.get("departmentCode")
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.getPolicyDD();
    this.policyForm = this.fb.group({
      product: [undefined],
      fromDate: [undefined],
      toDate: [undefined],
      prodArr: [undefined],
    });
    this.commonService.getIPAddress().subscribe(data => {
      this.ip = data.ip;
    });
  }

  getPolicyDD() {
    this.loaderService.isBusy = true;
    let obj = {
      agentId: this.agentId,
      userId: this.session.get("username")
    }
    /*this.marineService.getProductDropdown(obj).subscribe((res: any) => {
      this.loaderService.isBusy = true
      this.productList = res.marineCertList;
      this.loaderService.isBusy = false

    })*/
    this.marineService.getProductDropdown(obj)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.marineCertList.length; i++) {
          let id = result.marineCertList[i].key;
          let text = result.marineCertList[i].info1 + "--" + result.marineCertList[i].key + "--" + result.marineCertList[i].info2;
          let object = { id: id, text: text };
          arr.push(object);
        }
        this.productList = arr;
        console.log(this.productList)
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        alert("Process is taking time, please try again after some time");
        this.router.navigate(['agentdashboard']);
      });
  }

  getPolicyInfo(evt) {
    this.loaderService.isBusy = true;
    this.currPolicyNo = evt.id
    let obj = {
      agentId: this.agentId,
      policyNo: evt.id

    }
    this.marineService.getPolicyInfo(obj).subscribe((res: any) => {
      this.quoteData = res.quoteInfo
      this.batchIdList = res.batchIds
      this.showDate = false
      this.showSearchBy = false;
      this.showUploadButton = false
      if (res.quoteInfo.uploadCertificate == '0') {
        this.showUpload = false
      } else {
        this.showUpload = true
      }
      this.paramsData = {
        transId: this.quoteData.transId,
        tranSrNo: this.quoteData.tranSrNo,
        portal: this.portal,
        userId: this.userId,
        prodCode: this.quoteData.product,
        schCode: this.quoteData.scheme,
        ipAddress: this.ip,
        policyNo: this.currPolicyNo,
        menu: 231,
        batchId: this.batchId
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  getBatchId(evt) {
    this.batchId = evt.target.value
  }

  createCertificate() {
    let params = {
      policyNo: this.currPolicyNo,
    }
    this.router.navigate(['create-certificate'], { queryParams: params, skipLocationChange: true });
  }



  uploadCertificate(evt) {
    this.fileData = evt
    let sendData = {
      fileObject: this.fileData,
      transId: this.quoteData.transId,
      tranSrNo: this.quoteData.tranSrNo,
      portal: this.portal,
      userId: this.userId,
      prodCode: this.quoteData.product,
      deptCode: this.deptCode,
      divnCode: this.divisionCode,
      ipAddress: this.ip,
      policyNo: this.currPolicyNo,
      menu: 231,
    }
    this.marineService.uploadCertificate(sendData).subscribe(res => {

    })
  }

  previewImage(element) {
    var reader = new FileReader();
    reader.readAsDataURL(element.files[0]);
    if (element.files[0].size / 1024 / 1024 > 1) {

    }
  }
  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];
    if (file.size >= 200000 && !file.name.includes('.xlsx')) {
      alert("File Size is Larger than Expected. kidly upload file in '.xlsx' format");
      $('#excelUpload').val('');
    } else {
      this.loaderService.isBusy = true;
      let formData: FormData = new FormData();
      formData.append('fileObject', file, file.name);
      formData.append('transId', this.quoteData.transId);
      formData.append('tranSrNo', this.quoteData.tranSrNo);
      formData.append('portal', this.portal);
      formData.append('prodCode', this.quoteData.product);
      formData.append('deptCode', this.deptCode);
      formData.append('divnCode', this.divisionCode);
      formData.append('ipAddress', this.ip);
      formData.append('policyNo', this.currPolicyNo);
      formData.append('userId', this.userId);
      formData.append('menu', '231');
      this.marineService.uploadCertificate(formData).subscribe(res => {
        this.marineService.uploadedData = res;
        if (!res.errMessage) {
          this.router.navigate(['Marine-upload-Info'], { queryParams: this.paramsData, skipLocationChange: true });
          this.myInputVariable.nativeElement.value = "";
          this.loaderService.isBusy = false;
        } else {
          alert(res.errMessage);
          if (res.errorText != null) {
            this.logId = res.errMessage.split("-")[2];
            const blob = new Blob([res.errorText], { type: 'application/octet-stream' });
            this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
            this.loaderService.isBusy = false;
          }
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: res.errMessage });
          this.myInputVariable.nativeElement.value = "";
        }
      }, error => {
        this.myInputVariable.nativeElement.value = "";
        alert("Process is taking time, please try again after some time or re-query the uploaded batch files");
        this.router.navigate(['agentdashboard']);
        this.loaderService.isBusy = false
      })
    }
  }

  downloadSample() {

  }
  createUpload() {
    this.showUploadButton = true;
    this.showSearchBy = false;
  }
  searchUpload() {
    this.showSearchBy = true;
    this.showUploadButton = false
  }

  search() {
    this.marineService.searchCertificate(this.batchId, this.paramsData).subscribe(res => {
      this.marineService.uploadedData = res;
      this.router.navigate(['Marine-upload-Info'], { queryParams: this.paramsData, skipLocationChange: true });
    })
  }
}
