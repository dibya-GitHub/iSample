import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarineInfoComponent } from './marine-info.component';

describe('MarineInfoComponent', () => {
  let component: MarineInfoComponent;
  let fixture: ComponentFixture<MarineInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarineInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarineInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
