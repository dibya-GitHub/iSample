import { Component, Input, NgZone, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { AgentUserService } from "../../shared/services/agent-user.service";

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.scss']
})
export class UploadDocumentsComponent implements OnInit {
  skipperIdImageURL: string = "";
  drivingLicenseImageURL: string = "";
  vehRegistrationImageURL: string = "";
  emiratesIdImageURL: string = "";

  passPortImageURL: string = "";
  medicalReportImageURL: string = "";
  mailImageURL: string = "";

  receiptImageURL: string = "";
  proposalFormImageURL: string = "";
  highValueItemImageURL: string = "";
  othersImageURL: string = "";

  imageInfoArray = [];
  totalUplploadedDocuments: any = 0;
  imageURL: any = "";
  photoName: any;
  allowedExtensions: any = [];
  fileExtension: any;

  fileExtensionError: boolean = false;
  fileExtensionMessage: any;

  @Input() transId: string;
  @Input() tranSrNo: string;
  @Input() lobCode;
  docCodeValue: string = '';
  file: File;
  tmpParms: any;
  constructor(
    public zone: NgZone,
    private agentService: AgentUserService,
    private session: SessionStorageService,
  ) { }
  ngOnInit() {

  }

  onFilesChange(fileList) {
    let doc = fileList.evt.target.parentElement.parentElement.getElementsByTagName("input")[0].id;
    this.getDocumentCodeBeforeUpload(doc);
    this.fileExtensionError = false;
    this.fileExtensionMessage = "";
    let files = fileList.valid_files
    this.zone.run(() => {
      if (files.length > 0) {
        let file: File = files[0];

        var reader = new FileReader();
        var that = this;
        if ('01' === this.lobCode) {
          if (doc == "emiratesId") {
            this.imageInfoArray.splice(0, 1, { event: event, files: files, doc: doc });
          } else if (doc == "vehRegistration") {
            this.imageInfoArray.splice(1, 1, { event: event, files: files, doc: doc });
          } else {
            this.imageInfoArray.splice(2, 1, { event: event, files: files, doc: doc });
          }
        } else if ('08' === this.lobCode) {
          if (doc == "emiratesId") {
            this.imageInfoArray.splice(0, 1, { event: event, files: files, doc: doc });
          } else if (doc == "passPort") {
            this.imageInfoArray.splice(1, 1, { event: event, files: files, doc: doc });
          } else if (doc == 'medicalReport') {
            this.imageInfoArray.splice(2, 1, { event: event, files: files, doc: doc });
          } else {
            this.imageInfoArray.splice(3, 1, { event: event, files: files, doc: doc });
          }
        } else if ('04' === this.lobCode) {
          if (doc == "emiratesId") {
            this.imageInfoArray.splice(0, 1, { event: event, files: files, doc: doc });
          } else if (doc == 'receipt') {
            this.imageInfoArray.splice(1, 1, { event: event, files: files, doc: doc });
          } else if (doc == 'mail') {
            this.imageInfoArray.splice(2, 1, { event: event, files: files, doc: doc });
          } else if (doc == 'proposalForm') {
            this.imageInfoArray.splice(3, 1, { event: event, files: files, doc: doc });
          } else if (doc == 'highValueItem') {
            this.imageInfoArray.splice(4, 1, { event: event, files: files, doc: doc });
          } else {
            this.imageInfoArray.splice(5, 1, { event: event, files: files, doc: doc });
          }
        }

        this.totalUplploadedDocuments = this.imageInfoArray.length;

        reader.onload = function () {
          that.imageURL = reader.result;
          that.uploadDoc(event, files, doc);
        }
        reader.readAsDataURL(files[0]);
      }

    });

  }

  uploadDoc(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();



    this.getBase64(file);

    if (file.type == 'application/pdf') {
      this.imageURL = './assets/images/Pdf-File-icon.png'
    }


    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('lobCode', this.lobCode);
    formData.append('docCode', this.docCodeValue);
    formData.append('docType', "POL");
    formData.append('userId', this.session.get("username"));
    var uploadDocumentReponse = this.agentService.uploadDocuments(formData);

    if (event.target.id == "emiratesId" || doc == "emiratesId") {
      this.emiratesIdImageURL = this.imageURL;
    } else if (event.target.id == "vehRegistration" || doc == "vehRegistration") {
      this.vehRegistrationImageURL = this.imageURL;
    } else if (event.target.id == "drivingLicense" || doc == "drivingLicense") {
      this.drivingLicenseImageURL = this.imageURL;
    } else if (event.target.id == "passPort" || doc == "passPort") {
      this.passPortImageURL = this.imageURL;
    } else if (event.target.id == "mail" || doc == "mail") {
      this.mailImageURL = this.imageURL;
    } else if (event.target.id == "medicalReport" || doc == "medicalReport") {
      this.medicalReportImageURL = this.imageURL;
    } else if (event.target.id == "receipt" || doc == "receipt") {
      this.receiptImageURL = this.imageURL;
    } else if (event.target.id == "proposalForm" || doc == "proposalForm") {
      this.proposalFormImageURL = this.imageURL;
    } else if (event.target.id == "highValueItem" || doc == "highValueItem") {
      this.highValueItemImageURL = this.imageURL;
    } else if (event.target.id == "others" || doc == "others") {
      this.othersImageURL = this.imageURL;
    } else if (event.target.id == "skipperId" || doc == "skipperId") {
      this.skipperIdImageURL = this.imageURL;
    }
  }

  getBase64(file) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
    };
    reader.onerror = function (error) {
    };
  }

  getDocumentCodeBeforeUpload(event) {
    if (event == "emiratesId") {
      this.docCodeValue = "004";
    } else if (event == "mail") {
      this.docCodeValue = "038";
    } else if (event == "proposalForm") {
      this.docCodeValue = "039";
    } else if (event == "highValueItem") {
      this.docCodeValue = "050";
    } else if (event == "others") {
      this.docCodeValue = "";
    } else if (event == "receipt") {
      this.docCodeValue = "049";
    } else if (event == "medicalReport") {
      this.docCodeValue = "048";
    } else if (event == "passPort") {
      this.docCodeValue = "006";
    } else if (event == "vehRegistration") {
      this.docCodeValue = "008";
    } else if (event == "drivingLicense") {
      this.docCodeValue = "007";
    }

  }

  // uploadDocuments(event: any) {

  //       this.getDocumentCodeBeforeUpload(event.target.id);
  //       const fileList: FileList = event.target.files;
  //       if (fileList.length > 0) {
  //         this.file = fileList[0];
  //         var reader = new FileReader();
  //         var that = this;
  //         reader.onload = function () {

  //           that.upload(event);
  //         }
  //         reader.readAsDataURL(fileList[0]);
  //       }

  //     }

  uploadPicture(event: any) {
    let Id = event.target.id;


    this.getDocumentCodeBeforeUpload(event.target.id);

    var fileDetail = event.target.files[0];
    this.photoName = fileDetail.name;

    this.allowedExtensions = ["jpeg", "jpg", "bmp", "gif", "png", "pdf"];
    this.fileExtension = this.photoName.split('.').pop();

    if (this.isInArray(this.allowedExtensions, this.fileExtension)) {
      this.fileExtensionError = false;
      this.fileExtensionMessage = "";
    } else {
      this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
      this.fileExtensionError = true;
      return;
    }

    this.zone.run(() => {
      let fileList: FileList = event.target.files;
      if (fileList.length > 0) {
        let file: File = fileList[0];
        if (file.size > 2097152) {
          alert("2mb or below size image can upload!");
          this.fileExtensionMessage = "2mb or below size image can upload!"
          this.fileExtensionError = true;
          return;
        }
        var reader = new FileReader();
        var that = this;
        if (Id == "fileOne") {
          this.imageInfoArray.splice(0, 1, { event: event, fileList: fileList, id: Id });
        } else if (Id == "fileTwo") {
          this.imageInfoArray.splice(1, 1, { event: event, fileList: fileList, id: Id });
        } else {
          this.imageInfoArray.splice(2, 1, { event: event, fileList: fileList, id: Id });
        }


        this.totalUplploadedDocuments = this.imageInfoArray.length;
        reader.onload = function () {
          that.imageURL = reader.result;
          that.uploadDoc(event);
        }
        reader.readAsDataURL(fileList[0]);
      }
    });
  }

  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

  // upload(event: any, files?: any, doc?: any) {
  //   let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
  //   let file: File = files && files.length > 0 ? files[0] : fileList[0];

  //   let formData: FormData = new FormData();
  //   formData.append('fileObject', file, file.name);
  //   formData.append('transId', this.transId);
  //   formData.append('tranSrNo', this.tranSrNo);
  //   formData.append('lobCode', this.lobCode);
  //   formData.append('docCode', this.docCodeValue);
  //   formData.append('docType', "POL");
  //   formData.append('userId', "evan");
  //   var uploadDocumentReponse = this.agentService.uploadDocuments(formData);

  // }

  loadAgentDoc(reportType) {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
        width=800,height=200,left=100%,top=100%`;
    var winRef = window.open('/viewdocument?transId=' + this.transId + '&reportType=' + reportType, 'Product Category', param);
  }

}
