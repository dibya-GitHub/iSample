import { CurrencyPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as moment from 'moment';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';
import { LoaderService } from 'src/shared/loader-service/loader.service';

@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  styleUrls: ['./my-dashboard.component.scss'],
  providers: [CurrencyPipe]
})
export class MyDashboardComponent implements OnInit {
  columnDefs = [];
  traceInfoColumnDefs = [];
  rowData: any[];
  statusRowData: any[];
  gridApi: any;
  statusGridApi: any;
  gridColumnApi: any;
  statusGridColumnApi: any;
  users: any[];
  public myDatePickerOptions: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };
  showEnquiryDateErr: boolean;
  searchText: any;
  rowSelection: any[] = [];
  selectedQuote: any;
  myRequests: 10;
  result: any = {};
  isPendingSelected: boolean;
  isRequestSelected = true;
  canShowStatusTrackingInfo = false;
  editQuoteYn = false;
  selected = false;

  constructor(
    private fb: UntypedFormBuilder,
    private agentService: AgentUserService,
    private agentHtppClientService: AgentHttpclientService,
    private currPipe: CurrencyPipe,
    private modalService: NgbModal,
    private router: Router,
    private loaderService: LoaderService,
  ) { }

  ngOnInit() {
    const context = this;
    this.columnDefs = [
      {
        field: '',
        headerName: 'Select',
        headerCheckboxSelection: false,
        headerCheckboxSelectionFilteredOnly: true,
        checkboxSelection: true,
        cellStyle: { textAlign: 'center' },
        rowWidth: 50,
        resizable: true,
        enableRowGroup: false,
      },
      {
        field: 'quoteNo',
        headerName: 'Quote No',
        sortable: false,
        resizable: true,
        checkboxSelection: false,
        cellStyle: { textAlign: 'left' }
      },
      {
        field: 'insName',
        headerName: 'Customer Name',
        sortable: true,
        filter: true,
        resizable: true,
        enableRowGroup: true
      },
      {
        field: 'status',
        headerName: 'Status',
        sortable: true,
        filter: true,
        resizable: true,
        cellStyle: { textAlign: 'right' }, enableRowGroup: true,
      },
      {
        field: 'requestDt',
        headerName: 'Requested On',
        sortable: true,
        resizable: true,
        tooltipField: '',
        enableRowGroup: true,
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';

          } else if (params.value) {
            let reqdt = moment(params.value).format('DD/MM/YYYY HH:MM');//Utils.formatMilliSecToDate(params.value);
            //let conreqdt = moment(reqdt).format(dateTimeFormat)
            return '<span title="' + reqdt + '">' + reqdt + '</span>';
            //return Utils.formatMilliSecToDate(parseInt(params.value));

          }

        }
      }
    ];
    this.traceInfoColumnDefs = [
      {
        field: 'reqUid',
        headerName: 'Req By',
        sortable: true,
        resizable: true,
        filter: true
      },
      {
        field: 'reqDt',
        headerName: 'Requested Date',
        resizable: true,
        sortable: false,
        enableRowGroup: false,
        // valueFormatter: (params) => {
        //   if (params && params.value) {
        //     return moment(params.value).format('DD/MM/YYYY');
        //   } else {
        //     return;
        //   }
        // }
      },
      {
        field: 'respUid',
        headerName: ' Resp User / Role',
        sortable: true,
        resizable: true,
        filter: true,
        enableRowGroup: false
      },
      {
        field: 'respDt',
        headerName: 'Response Date',
        resizable: true,
        sortable: true,
        enableRowGroup: false,
        // valueFormatter: (params) => {
        //     return moment(params.value).format('DD/MM/YYYY');
        // }
      },
      {
        field: 'respRemarks',
        headerName: 'Remarks',
        sortable: true,
        resizable: true,
        filter: true,
        enableRowGroup: false
      },
      {
        field: 'status',
        headerName: 'Status',
        sortable: true,
        filter: true,
        resizable: true,
        enableRowGroup: false
      }
    ];
    if (true) {
      this.retrieveMyDashboardData();
    }
  }

  currencyFormatter(params) {
    return this.currPipe.transform(params.value, 'AED ');
  }

  onGridSizeChanged(params, columnApi, api) {
    const gridWidth = document.getElementById('treatyGrid').offsetWidth;
    const columnsToShow = [];
    const columnsToHide = [];
    let totalColsWidth = 0;
    const allColumns = columnApi.getAllColumns();
    for (let i = 0; i < allColumns.length; i++) {
      const column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    columnApi.setColumnsVisible(columnsToShow, true);
    columnApi.setColumnsVisible(columnsToHide, false);
    api.sizeColumnsToFit();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onStatusGridReady(params) {
    this.statusGridApi = params.api;
    this.statusGridColumnApi = params.columnApi;
    this.statusGridApi.sizeColumnsToFit();
  }

  onRowSelected(event) {
    if (this.selected)
      this.selected = false;
    else
      this.selected = true;
    if (event.node.selected) {
      this.selectedQuote = event.node.data;
      this.canShowStatusTrackingInfo = false;
      this.statusRowData = [];
      if ("01" === this.selectedQuote.lobCode)
        this.editQuoteYn = true;
      else
        this.editQuoteYn = false;
    }
  }

  searchTextChanged() {
    if (this.searchText || this.searchText === '') {
      this.gridApi.setQuickFilter(this.searchText);
    }
  }

  retrieveMyDashboardData() {
    this.loaderService.isBusy = true;
    this.agentService.getMyDashboardInfo()
      .subscribe(
        res => {
          this.result = res;
          this.onMenuClick('MY_REQ');
          this.loaderService.isBusy = false;
          // this.resultOptions = res.quoteSummaryInfo;
        },
        err => {
          this.rowData = [];
          this.loaderService.isBusy = false;

        }
      );
  }

  onMenuClick(menuId) {
    this.selected = false;
    this.canShowStatusTrackingInfo = false;
    this.statusRowData = [];
    if (menuId === 'MY_REQ') {
      this.rowData = this.result.requestInfo;
      this.isRequestSelected = true;
      this.isPendingSelected = false;
    } else {
      this.rowData = this.result.pendingActionsInfo;
      this.isRequestSelected = false;
      this.isPendingSelected = true;
    }
  }

  trackStatus() {
    const data = this.selectedQuote;
    let obj = {
      transId: data.transId,
      tranSrNo: data.tranSrNo,
      quoteNo: data.quoteNo
    };
    this.canShowStatusTrackingInfo = true;
    this.agentService.getStatusTrackingInfo(data.transId)
      .subscribe((res: any) => {
        this.statusRowData = res.statusInfo;
      },
        err => {
        });
  }





  openPolicyDet() {
    const data = this.selectedQuote;
    let obj = {
      transId: data.transId,
      tranSrNo: data.tranSrNo,
      quoteNo: data.quoteNo
    };
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
width=1000,height=0,left=-1000,top=-1000`;
    var winRef = window.open('./work-flow?transId=' + obj.transId + '&tranSrNo=' + obj.tranSrNo, 'workflow', param);
  }

  moveToPendingAction() {

    let data;
    const obj = {
      transId: data.transId,
      tranSrNo: data.tranSrNo,
      lobCode: data.lobCode,
      quoteNo: data.quoteNo,
      polStartDate: data.polStartDate,
      polEndDate: data.polEndDate,
      instYN: data.instYN,
      from: 'dashboard'
    };

    // transId=784056&tranSrNo=0&lobCode=01&mode=%20&quoteNo=1920089905

    this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
  }

  fetchingQuoteData() {
    const data = this.selectedQuote;
    let params = { "transId": data.policyTransId, "tranSrNo": data.policyTranSrNo };
    this.agentHtppClientService.checkTrimCode(params)
      .subscribe(result => {
        if (result.vesselCode != null) {
          let obj = {
            transId: data.policyTransId,
            tranSrNo: data.policyTranSrNo,
            specVal: "1",
            isOldVessel: false,
            oldTrimId: result.vesselCode
          };
          this.router.navigate(['/firstScreenMotor'], { queryParams: obj, skipLocationChange: true });
        } else {
          let obj = {
            transId: data.policyTransId,
            tranSrNo: data.policyTranSrNo,
            quoteNo: data.quoteNo,
            editYn: "1",
          };
          this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
        }
      },
        error => {
          alert("Error");
        });
  }

}
