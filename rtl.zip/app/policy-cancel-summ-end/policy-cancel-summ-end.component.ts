import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-policy-cancel-summ-end',
  templateUrl: './policy-cancel-summ-end.component.html',
  styleUrls: ['./policy-cancel-summ-end.component.scss']
})
export class PolicyCancelSummEndComponent implements OnInit {
  policyNo: any;
  premCoverInfo: any;
  taxcover: any;
  optionalCovers: any;
  sumInclusiveMandatory: any[] = [];
  endType: any;
  transId: any;
  tranSrNo: any;
  quoteNo: any;
  lobCode: any;
  coverSummaryList: any = [];
  taxes: any = [];
  discounts: any = [];
  deductables: any = [];
  fees: any = [];
  load: any = [];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public loaderService: LoaderService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
  ) { }

  ngOnInit() {
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    this.endType = this.commonService.getParamValue('endType');
    this.policyNo = this.commonService.getParamValue('policyNo');


    this.getCoverSummary();
    this.getPremCoverInfo();
    // this.getDiscDedLoadFeesSumm();

  }

  /*getCoverSummary() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }

    this.agentService.getCoverSummary(postData)
      .subscribe(response => {
        var array = response["coversArray"];
        for (var i = 0; i < array.length; i++) {
                this.coverSummaryList.push(array[i]);
        }

      });

  }
  getCoverSummary(){
    let param={"transId": this.transId,"tranSrNo":this.tranSrNo};
    this.agentService.getCoverSummary(param)
    .subscribe(response => {
      var array =  response["coversArray"];
      let j = 0;
      for (var i = 0; i < array.length; i++) {
        if (array[i].type == 'I' || array[i].type == 'M') {  
                this.sumInclusiveMandatory.push(array[i]);
          }
          else{
            this.optionalCovers.push(array[i]);
          }
        }
    });
  }

  getDiscDedLoadFeesSumm() {

    let taxesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "TAX"
    };
    this.agentService.getDiscDedLoadFeesSumm(taxesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.taxes.push(data[k]);
        }
      }

    }, error => {

      this.loaderService.isBusy = false;
    });

    let dedPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DED"
    };
    this.agentService.getDiscDedLoadFeesSumm(dedPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.deductables.push(data[k]);
        }
      }
    }, error => {

      this.loaderService.isBusy = false;
    });

    let discountPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DISC"
    };
    this.agentService.getDiscDedLoadFeesSumm(discountPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.discounts.push(data[k]);
        }
      }
    }, error => {

      this.loaderService.isBusy = false;
    });

    let feesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "FEES"
    };
    this.agentService.getDiscDedLoadFeesSumm(feesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.fees.push(data[k]);
        }
      }
    }, error => {

      this.loaderService.isBusy = false;
    });

    let loadPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "LOAD"
    };
    this.agentService.getDiscDedLoadFeesSumm(loadPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.load.push(data[k]);
        }
      }
    }, error => {
  
      this.loaderService.isBusy = false;
    });
  }*/

  goToPreviousPage() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      lobCode: this.lobCode,
      endorseType: this.endType,
    }
    this.router.navigate(['policycancelendt'], { queryParams: obj, skipLocationChange: true });
    /*if(this.lobCode == '04')
      {
        this.router.navigate(['additional-home-info'], { queryParams: obj, skipLocationChange: true });
      }
    else if(this.lobCode == '08')
      {
        
        this.router.navigate(['add-TravelInfo'], { queryParams: obj, skipLocationChange: true });
      }
    else if(this.lobCode == '01')
      {
        this.router.navigate(['motor-additional-info'], { queryParams: obj, skipLocationChange: true });
      }
 */
  }



  getCoverSummary() {

    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          this.sumInclusiveMandatory.push(array[i]);
        }
      });
  }

  getOptionalCover() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getOptionalCover(param).subscribe(response => {
      var array = response["optionalList"];
      let j = 0;
      var permiumRange = 0;
      for (var i = 0; i < array.length; i++) {
        this.optionalCovers.push(array[i]);
      }
    });
  }


  getTaxCover() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getTaxCover(param).subscribe(response => {
      var array = response["Taxlist"];
      let j = 0;
      var permiumRange = 0;
      for (var i = 0; i < array.length; i++) {
        this.taxcover.push(array[i]);
      }
    });
  }
  getPremCoverInfo() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getPremCoverInfo(param).subscribe(response => {
      this.premCoverInfo = response;
      /* var array =  response["PremiumList"];
       for (var i = 0; i < array.length; i++) {
             this.premCoverInfo.push(array[i]);
         }*/

    });
  }

  ConfirmEndorsement() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      userId: this.session.get("agent"),
      endType: this.endType
    }
    this.agentService.endtProceedtoBuy(obj)
      .subscribe(result => {
        let params = { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'policyNo': this.policyNo, 'lobCode': this.lobCode, 'endType': this.endType }
        this.router.navigate(['confirmendt'], { queryParams: params, skipLocationChange: true });

      });
    //this.router.navigate(['add-cover-summary'],{queryParams:{'transId':this.transId,'tranSrNo':this.transSNo,'policyNo':this.customerInfo.policyNo,'lobCode':ApplicationConstants.LOB_MOTOR,'endType': this.endorseType}});
  }

  back() {
    let params = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      lobCode: this.lobCode,
      endType: this.endType
    }
    this.router.navigate(['policycancelendt'], { queryParams: params, skipLocationChange: true });

  }

  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }
}
