import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentHttpclientService } from '../services/agent-httpclient.service';


@Component({
  selector: 'app-find-active-policy',
  templateUrl: './find-active-policy.component.html',
  styleUrls: ['./find-active-policy.component.scss']
})
export class FindActivePolicyComponent implements OnInit {

  activePolicyArray: any[];
  txnNo: any;
  srNo: any;
  policyNo: any;
  lob: any;
  lobCode: any;
  searchBy: any;
  searchValue: any;
  emiratedId: any;
  selectOrConfirm: string;
  errorMessage: string = '';
  showDiv: boolean = false;
  errorMsg: string = '';
  routeData: any;
  constructor(public route: ActivatedRoute,
    public router: Router,
    private agentService: AgentHttpclientService,
    private session: SessionStorageService,

  ) {
    this.route.queryParams.subscribe((params:any) => {
      this.routeData = params;
      this.searchValue = params.value
      this.searchBy = params.searchBy
      let datas = { "searchBy": this.searchBy, "value": this.searchValue, "agentId": this.session.get("agent"), "deptCode": this.session.get("departmentCode"), "userId": this.session.get("username") };
      this.agentService.getActCLaimPolicy(datas).subscribe(data => {
        if (data.errMessage == "No Records Found") {
          this.errorMessage = data.errMessage;
          this.showDiv = true;
        } else {
          this.activePolicyArray = data.activePolicyArray;
          this.errorMessage = '';
        }
        this.showDiv = true;
        $('.container').show();
      }, error => {
        this.errorMessage = "No Records Found";
        this.showDiv = true;
        $('.container').show();
      });
    }, error => {
    });
  }
  ngOnInit() {
    window.scrollTo(0, 0);
    $('.container').hide();
  }
  setSrAndTxn(txn_id: any, sr_no: any, polNo: any, lobCOde: any) {
    this.txnNo = txn_id;
    this.srNo = sr_no;
    this.lob = lobCOde;
  }
  getClaim(txn_id: any, sr_no: any, polNo: any) {
    this.txnNo = txn_id;
    this.srNo = sr_no;
    this.submitClaim();
  }
  submitClaim() {
    let obj = {
      id: this.txnNo,
      srNo: this.srNo,
      searchBy: this.searchBy,
      value: this.searchValue,
      lobCode: this.lob
    }
    if (this.txnNo === undefined && this.srNo === undefined)
      alert('Please select a policy');
    else
      this.router.navigate(['submit-claim'], { queryParams: obj, skipLocationChange: true });
  }
  goToPreviousPage() {
    this.router.navigate(['report-claim'], { queryParams: this.routeData, skipLocationChange: true });
  }
}
