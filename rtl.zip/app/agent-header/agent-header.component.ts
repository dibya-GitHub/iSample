import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../services/agent-httpclient.service';

declare function loadimage(): any;

@Component({
  selector: 'app-agent-header',
  templateUrl: './agent-header.component.html',
  styleUrls: ['./agent-header.component.scss']
})
export class AgentHeaderComponent implements OnInit {
  Url;
  file: File;
  docCodeValue;
  dashboardUrl;
  onlyMarineFlag: boolean;
  activeLobList: any;
  roleId: any;
  constructor(
    private session: SessionStorageService,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private router: Router,
    private loadingService: LoaderService

  ) { }
  loginUserName = this.session.get("loginUserName");
  profileUrl = this.session.get("profileUrl");
  lastLogin = this.session.get("lastLogin");
  ngOnInit() {
    this.roleId = this.session.get("USER_ROLE_ID");
    loadimage();
    this.dashboardUrl = this.session.get("dashboardUrl");
    if (this.dashboardUrl != "FleetCustomer") {
      let params = { "empUserId": this.session.get("agent"), "userId": this.session.get("username"), "empDivnCode": this.session.get("divisionCode"), empDeptCode: this.session.get("departmentCode") };
      this.onlyMarineFlag = false;
      this.agentService.getProducts(params)
        .subscribe(result => {
          this.activeLobList = result.activeLobList;
          if (this.activeLobList != null && this.activeLobList[0].info1 === "03" && this.roleId != "A_HULL_MGR") {
            this.onlyMarineFlag = true;
          } else {
            this.onlyMarineFlag = false;
          }
        });
    }

  }


  /* getDocument() {
     var params = { "trans_Id": this.session.get("agent"), "typeOfReport": 'POL' };
     this.commonService.getDocInfoByType(params)
       .subscribe(result => {
         for (let i = 0; i < result.documentInfoList.length; i++) {
           let docUrl = result.documentInfoList[i].docUrl;
           this.getFileUrl(docUrl);
         }
       });
 
   }*/

  getFileUrl(url) {
    var params = { "fileUrl": url, "userRole": this.session.get("USER_ROLE_ID") };
    this.commonService.getFileUrl(params)
      .subscribe(result => {
        this.profileUrl = result.fileUrl;
      });
  }

  uploadDocuments(event: any) {
    //this.getDocumentCodeBeforeUpload(event.target.id);
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
      var reader = new FileReader();
      var that = this;
      reader.onload = function () {
        that.upload(event);
      }
      reader.readAsDataURL(fileList[0]);
    }
  }

  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.session.get("agent"));
    formData.append('tranSrNo', "0");
    formData.append('lobCode', "01");
    formData.append('docCode', "039");
    formData.append('docType', "POL");
    formData.append('userId', this.session.get("username"));
    var uploadDocumentReponse = this.commonService.uploadDocuments(formData);
    setTimeout(() => {
      this.getDocument();
    }, 1000);
  }

  getDocument() {
    var params = { "trans_Id": this.session.get("agent"), "typeOfReport": 'POL', "userId": this.session.get("username") };
    this.commonService.getDocInfoByType(params)
      .subscribe(result => {
        for (let i = 0; i < result.documentInfoList.length; i++) {
          let docUrl = result.documentInfoList[i].docUrl;
          this.getFileUrl(docUrl);
        }
      });

  }

  logoClick() {
    if (this.dashboardUrl == "FleetCustomer") {
      this.commonService.newEvent('clicked')
    } else if (this.dashboardUrl == "fleetendt") {
      this.commonService.newEvent('clicked')
    } else {
      this.router.navigate(['/agentdashboard']);
    }
  }

  logout() {
    this.loadingService.isBusy = true;
    const loginUserId = this.session.get('LoginID');
    this.commonService.agentLogout({ "empUserId": loginUserId }).subscribe((response: any) => {
      if ("2000" === response.respCode) {
        let param = {
          "token_type_hint": "access_token",
          "token": this.session.get("access_token")
        };
        this.commonService.revokeToken(param).subscribe(response => {
          this.loadingService.isBusy = false;
          if (this.onlyMarineFlag) {
            this.router.navigate(['/marine-login']);
          } else {
            this.router.navigate(['/']);
          }
        })
      }
    })
  }
}
