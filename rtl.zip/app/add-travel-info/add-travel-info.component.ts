import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { MessageService } from 'primeng/api';
import { TravelInfo } from 'src/app/agent-travel/classes/primaryInfo';
import { ApplicationConstants } from 'src/shared/application-constants';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-add-travel-info',
  templateUrl: './add-travel-info.component.html',
  styleUrls: ['./add-travel-info.component.scss']
})
export class AddTravelInfoComponent implements OnInit {
  isCovidYN: boolean;
  showWinter: string;
  showChild: boolean;
  public date = new Date();
  winSprtsYN: boolean = false;
  netpremium = 0;
  travelIfoarr: any;
  sumInclusiveMandatory = [];
  agentTax: any;
  agentFc: any;
  agentPremium: String;
  discounts: any[] = [];
  load: any[] = [];
  dedectable: any[] = [];
  fees: any[] = [];
  tax: any[] = [];
  adultArray = [];
  travellerDetailsArray = [];
  travelInfo: TravelInfo;
  lobCode;
  public routeObj: any;


  addlInfoForm: UntypedFormGroup;
  adultdata: UntypedFormArray;
  childData: UntypedFormArray;
  transId;
  tranSrNo;
  totalChildren: number;
  totalAdults: number;
  setWinterSports: any;
  len: number;
  dateofBirth: Date;
  lob: String;
  relationList: Array<any>;
  genderList: Array<any>;
  nationalityList: Array<any>;
  cityList: Array<any>;
  occupationList: Array<any>;
  premiumList: Array<any>;
  Dob = [];
  isShowRecalc: boolean;
  quoteNo;
  insCovidType: any;
  ishowdiv: boolean;
  docCodeValue;
  file: File;
  userId;
  aduldDob: any;
  adultError: boolean;
  formSubmit: boolean = false;
  template: string = '<img class="custom-spinner-template" src="./assets/images/lg.comet-spinner.gif" alt="loading gif">';

  dateTmp: Date = new Date(new Date().setDate(new Date().getDate() - 1));

  //mydatePicker
  public myDatePickerOptions: IAngularMyDpOptions = {

    // other options...
    dateFormat: 'dd/mm/yyyy',
    //disableUntil: { year: this.dateTmp.getFullYear(), month: this.dateTmp.getMonth() + 1, day: this.dateTmp.getDate() }
  };


  constructor(private frmbuild: UntypedFormBuilder,
    private route: ActivatedRoute, private router: Router,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private spinnerService: LoaderService) { }


  ngOnInit() {

    this.spinnerService.isBusy = true;
    this.userId = this.session.get('username');
    this.transId = this.commonService.getParamValue('transId')//"1397780"//"1397225";
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    //this.setDate();
    this.getQuote();
    this.getQuoteInformation();
    this.getRelationList();
    this.getGenderType();
    this.getNationalityType();
    this.getCityTypes();
    this.geTOccupationTypes();
    this.getDiscDedLoadFeesSumm();
    this.getPremiumSummary();
    this.getAgentNetPremium();
    this.getCoverSummary();

    this.addlInfoForm = this.frmbuild.group({
      adultdata: this.frmbuild.array([]),
      childData: this.frmbuild.array([]),
      arabicinsuredname: [],
      address: [, [Validators.required]],
      pobox: [, Validators.required],
      coverNoteNumber: [],
      city: ['', Validators.required],
      occupation: '',
      vatRefNo: [],
      remarks: []
    });
    window.scroll(0, 0);
    this.showWinter = this.session.get('travelCovid');
    if (this.showWinter != "") {
      this.isCovidYN = false
    } else {
      this.isCovidYN = true
    }
  }

  createAdultForm(): UntypedFormGroup {
    return this.frmbuild.group({
      trvlrName: ['', Validators.required],
      relation: ['', Validators.required],
      gender: '',
      dob: [, Validators.required],
      nationality: [''],
      passptNo: [, Validators.required],
      wntrSptsExtYN: '',
      adultYN: '',
      isAdultEditable: [true],
      relationName: '',
      nationalityName: '',
      genderName: ''
    });
  }

  createChildForm(): UntypedFormGroup {
    return this.frmbuild.group({
      trvlrName: [, Validators.required],
      relation: ['', Validators.required],
      gender: '',
      dob: [, Validators.required],
      nationality: '',
      passptNo: [, Validators.required],
      wntrSptsExtYN: '',
      adultYN: '',
      isChildEditable: [true],
      relationName: '',
      nationalityName: '',
      genderName: ''
    });
  }
  addAdultForm(len: number): any {
    for (var i = 1; i <= len; i++) {
      //this.createAdultForm();
      this.adultdata = this.addlInfoForm.get('adultdata') as UntypedFormArray;
      this.adultdata.push(this.createAdultForm());
    }
  }
  saveAdultForm(item: UntypedFormGroup): any {
    this.spinnerService.isBusy = true;
    this.formSubmit = true;
    if (item.valid) {
      this.relationList.map((data: any) => {
        if (data.code == item.value.relation) {
          item.get('relationName').setValue(data.desc);
        }
      });
      this.nationalityList.map((data: any) => {
        if (data.code == item.value.nationality) {
          item.get('nationalityName').setValue(data.desc);
        }
      });
      this.genderList.map((data: any) => {
        if (data.code == item.value.gender) {
          item.get('genderName').setValue(data.desc);
        }
      });

      item.get('isAdultEditable').setValue(false);
      this.spinnerService.isBusy = false;
    } else {
      this.spinnerService.isBusy = false;
      this.validateAllFormFields(item);
    }
  }
  saveChildForm(item: UntypedFormGroup): any {
    this.spinnerService.isBusy = true;
    this.formSubmit = true;
    if (item.valid) {
      this.relationList.map((data) => {
        if (data.code == item.value.relation) {
          item.get('relationName').setValue(data.desc);
        }
      });
      this.nationalityList.map((data) => {
        if (data.code == item.value.nationality) {
          item.get('nationalityName').setValue(data.desc);
        }
      });
      this.genderList.map((data) => {
        if (data.code == item.value.gender) {
          item.get('genderName').setValue(data.desc);
        }
      });
      item.get('isChildEditable').setValue(false);
      this.spinnerService.isBusy = false;
    } else {
      this.spinnerService.isBusy = false;
      this.validateAllFormFields(item);
    }
  }
  editAdultForm(item: UntypedFormGroup) {
    item.get('isAdultEditable').setValue(true);
  }
  editChildForm(item: UntypedFormGroup) {
    item.get('isChildEditable').setValue(true);

  }
  addChildForm(len: number): any {
    for (var i = 1; i <= len; i++) {
      this.childData = this.addlInfoForm.get('childData') as UntypedFormArray;
      this.childData.push(this.createChildForm());
    }
  }
  getQuoteInformation() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      mapId: 'AGENT_HOME_POL_SCR_1'
    }
    let date = new Date();
    this.agentService.getQuoteInformation(postData).subscribe(quoteInfo => {
      this.quoteNo = quoteInfo.quoteNo;
    }, error => {

    });
  }
  getQuote() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getQuotInfo(data).subscribe(result => {
      if (result != null && result != undefined) {
        this.addlInfoForm.patchValue({
          arabicinsuredname: result.insNameAr,
          address: result.address,
          pobox: result.poBox,
          city: (result.city) || '',
          remarks: result.transRemark,
          vatRefNo: result.taxRefNo
        });
        this.getTravelAddInfo(data);
      }
    });
    this.winSportsFlagYN();
    this.getTravelInfo();
  }

  getTravelAddInfo(data) {
    data.mapId = 'TRAVEL_RISK_SCR_2';
    this.agentService.getTravelAddInfo(data).subscribe(res => {
      if (res) {
        this.addlInfoForm.patchValue(res);
      }
    });
  }

  getTravelInfo() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getQuoteTravelInfo(data).subscribe(result => {
      //this.setWinterSports = result.wntrSptsExtYN;
      this.totalAdults = Number(result.noOfAdults);
      this.totalChildren = Number(result.noOfChild);

      if (result.respCode == 2000) {
        if (this.totalAdults > 0) {
          this.addAdultForm(this.totalAdults);
        }
        if (this.totalChildren > 0) {
          this.showChild = true;
          this.addChildForm(this.totalChildren);
        } else {
          this.showChild = false
        }
      }
      this.getTravelersInfo();
    })
  }

  getRelationList() {
    this.agentService.getRelationType({ "type": "RELATION" }).subscribe(resp => {
      this.relationList = resp.appCodesArray;
    })
  }

  getGenderType() {
    this.agentService.getGenderList({ "paraType": "GENDER" }).subscribe(resp => {
      this.genderList = resp.appParamsArray;
    })
  }
  getNationalityType() {
    this.agentService.getNationalityList({ "type": "NATIONALITY" }).subscribe(resp => {
      this.nationalityList = resp.appCodesArray;
    })
  }
  getCityTypes() {
    this.agentService.getCityList({ "type": "STATE", "refCode": "002" }).subscribe(resp => {
      this.cityList = resp.appCodesArray;
    })
  }
  geTOccupationTypes() {
    this.agentService.getOccupationType({ "type": "OCCUPATION" }).subscribe(resp => {
      this.occupationList = resp.appCodesArray;
    })
  }

  getDiscDedLoadFeesSumm() {
    let summArr = ["DISC", "LOAD", "DED", "FEES", "TAX"];
    var k = 0;
    for (let i = 0; i < summArr.length; i++) {
      var type = summArr[i];
      let params = { "transId": this.transId, "tranSrNo": this.tranSrNo, "type": type };
      this.agentService.getDiscDedLoadFeesSumm(params).subscribe(response => {
        if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
          var data = response["othersArray"];
          if (type == "DISC") {
            for (k = 0; k < data.length; k++) {
              this.discounts.push(data[k]);
            }
          } else if (type == 'LOAD') {
            for (k = 0; k < data.length; k++) {
              this.load.push(data[k]);
            }
          } else if (type == 'DED') {
            for (k = 0; k < data.length; k++) {
              this.dedectable.push(data[k]);
            }
          } else if (type == 'FEES') {
            for (k = 0; k < data.length; k++) {
              this.fees.push(data[k]);
            }
          } else {
            if (type == 'TAX') {
              for (k = 0; k < data.length; k++) {
                this.tax.push(data[k]);
              }
            }
          }

        }
      })
    }
  }

  getPremiumSummary() {
    this.agentService.getPremiumSummary({ "transId": this.transId, "tranSrNo": this.tranSrNo }).subscribe(result => {
      this.premiumList = result;
    })

  }
  getAgentNetPremium() {
    this.agentService.getAgentNetPremium({ "transId": this.transId, "tranSrNo": this.tranSrNo }).subscribe(result => {
      this.agentPremium = result.PREMIUM;
      this.agentFc = result.AGENT_FC;
      this.agentTax = result.QPI_ACOMM_TAX;
    })
  }

  onSubmit() {
    this.formSubmit = true;
    this.travellerDetailsArray = [];
    if (this.addlInfoForm.valid) {
      this.spinnerService.isBusy = true;
      this.travelInfo = this.addlInfoForm.value;
      for (var i = 0; i < this.travelInfo.adultdata.length; i++) {

        let da = this.travelInfo.adultdata[i].dob;
        if (da.formatted != undefined) {
          this.travelInfo.adultdata[i].dob = moment(da.formatted).format('DD/MM/YYYY HH:mm');
        } else if (da.date != undefined) {
          this.travelInfo.adultdata[i].dob = {
            date: {
              year: da.date.year,
              month: da.date.month,
              day: da.date.day
            }
          };
          let cal = this.travelInfo.adultdata[i].dob.date.year + "/" + this.travelInfo.adultdata[i].dob.date.month + "/" + this.travelInfo.adultdata[i].dob.date.day;
          let dt = moment(cal).format("DD/MM/YYYY HH:mm");
          this.travelInfo.adultdata[i].dob = dt;
        } else {
          this.travelInfo.adultdata[i].dob = da;
        }
        if (this.travelInfo.adultdata[i].dob == 'Invalid date') {
          this.travelInfo.adultdata[i].dob = {
            date: {
              year: da.date.year,
              month: da.date.month,
              day: da.date.day
            }
          };
          let cal = this.travelInfo.adultdata[i].dob.date.year + "/" + this.travelInfo.adultdata[i].dob.date.month + "/" + this.travelInfo.adultdata[i].dob.date.day;
          let dt = moment(cal).format("DD/MM/YYYY HH:mm");
          this.travelInfo.adultdata[i].dob = dt;
        }
        this.travelInfo.adultdata[i].transId = this.transId;
        this.travelInfo.adultdata[i].tranSrNo = this.tranSrNo;
        this.travelInfo.adultdata[i].category = '8003';
        this.travelInfo.adultdata[i].adultYN = '1';
        this.travelInfo.adultdata[i].userId = this.session.get('username');

        if (this.travelInfo.adultdata[i].wntrSptsExtYN) {
          this.travelInfo.adultdata[i].wntrSptsExtYN = '1'
        } else {
          this.travelInfo.adultdata[i].wntrSptsExtYN = '0'
        }
        this.travellerDetailsArray.push(this.travelInfo.adultdata[i])
      }
      for (var i = 0; i < this.travelInfo.childData.length; i++) {
        let da = this.travelInfo.childData[i].dob;
        if (da.formatted != undefined) {
          this.travelInfo.childData[i].dob = moment(da.formatted).format('DD/MM/YYYY HH:mm');
        } else if (da.date != undefined) {
          this.travelInfo.childData[i].dob = {
            date: {
              year: da.date.year,
              month: da.date.month,
              day: da.date.day
            }
          }
          let cal = this.travelInfo.childData[i].dob.date.year + "/" + this.travelInfo.childData[i].dob.date.month + "/" + this.travelInfo.childData[i].dob.date.day;
          let dt = moment(cal).format("DD/MM/YYYY HH:mm");
          this.travelInfo.childData[i].dob = dt;
        } else {
          this.travelInfo.childData[i].dob = da;
        }
        if (this.travelInfo.childData[i].dob == 'Invalid date') {
          this.travelInfo.childData[i].dob = {
            date: {
              year: da.date.year,
              month: da.date.month,
              day: da.date.day
            }
          };
          let cal = this.travelInfo.childData[i].dob.date.year + "/" + this.travelInfo.childData[i].dob.date.month + "/" + this.travelInfo.childData[i].dob.date.day;
          let dt = moment(cal).format("DD/MM/YYYY HH:mm");
          this.travelInfo.childData[i].dob = dt;
        }
        this.travelInfo.childData[i].transId = this.transId;
        this.travelInfo.childData[i].tranSrNo = this.tranSrNo;
        this.travelInfo.childData[i].category = '8002';
        this.travelInfo.childData[i].adultYN = '0';
        this.travelInfo.childData[i].userId = this.session.get('username');
        if (this.travelInfo.childData[i].wntrSptsExtYN) {
          this.travelInfo.childData[i].wntrSptsExtYN = '1'

        } else {
          this.travelInfo.childData[i].wntrSptsExtYN = '0'

        }
        this.travellerDetailsArray.push(this.travelInfo.childData[i]);
      }
      this.agentService.insertTravelInfo(this.travellerDetailsArray).subscribe(result => {
        if (result.respCode == 2000) {
          let params = {
            'insNameAr': this.addlInfoForm.controls['arabicinsuredname'].value,
            'address': this.addlInfoForm.controls['address'].value,
            'poBox': this.addlInfoForm.controls['pobox'].value,
            'city': this.addlInfoForm.controls['city'].value,
            'transRemark': this.addlInfoForm.controls['remarks'].value,
            //'nojoomVocherCode': this.addlInfoForm.controls['vatRefNo'].value,
            'transId': this.transId,
            'tranSrNo': this.tranSrNo,
            'vatRefNo': this.addlInfoForm.controls['vatRefNo'].value,
            'mapId': 'TRAVEL_AGENT_ADDLINFO_SCR01',
            'userId': this.session.get('username')
          };
          this.agentService.updateInsInfo(params).subscribe(result => {
            if (result.respCode == 2000) {
              const travelInfo = {
                coverNoteNumber: this.addlInfoForm.get('coverNoteNumber').value,
                occupation: this.addlInfoForm.get('occupation').value,
                mapId: 'TRAVEL_RISK_SCR_2',
                transId: this.transId,
                tranSrNo: this.tranSrNo
              };
              this.agentService.updateTravelAddInfo(travelInfo)
                .subscribe(res => {
                  const obj = {
                    transId: this.transId,
                    tranSrNo: this.tranSrNo,
                    lobCode: this.lobCode,
                    quoteNo: this.quoteNo
                  };
                  this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
                }, err => {
                  this.spinnerService.isBusy = false;
                });
              /*     if (flag == 'approve') {
                   let aproveParams = { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode': flag, 'lobCode': '08', 'userId': this.session.get('username'), 'portal': this.session.get("portaltype") }
                     this.agentService.approveAgentPolicy(aproveParams).subscribe(result => {
                       if (result.respCode == 2000) {
       
                       }
                     });
                   }
                   this.router.navigate(['quote-confirm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode':  flag} });*/
            }
          });

        }
      }, err => {
        this.spinnerService.isBusy = false;
        if (err.error.respCode == "6001") {
          let obj = {
            errMsg: err.error.errMessage
          }

          let objs = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            quoteNo: this.quoteNo,
            "errMessage": err.error.errMessage
          };
          // this.agentService.insertErrorMsg(objs).subscribe(response => {
          this.router.navigate(['refferal'], { queryParams: objs, skipLocationChange: true });
          // });
        } else {
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
        }
      });
    } else {
      this.spinnerService.isBusy = false;
      this.validateAllFormFields(this.addlInfoForm);
      // this.markFormGroupTouched(this.addlInfoForm);
    }

  }

  /*saveQuoteOrApprove(flag: String) {
    const controlArray = <FormArray> this.addlInfoForm.get('adultdata');

    this.travelInfo = this.addlInfoForm.value;
    for (var i = 0; i < this.travelInfo.adultdata.length; i++) {
     if(controlArray.controls[i].get('trvlrName').value == "" || controlArray.controls[i].get('trvlrName').value == null){
       this.adultError=true;
     }else{
      this.adultError=false;
     }
     if(controlArray.controls[i].get('relation').value == "" || controlArray.controls[i].get('relation').value == null){
      this.adultError=true;
    }
    else{
      this.adultError=false;
    }
    if(controlArray.controls[i].get('dob').value == "" || controlArray.controls[i].get('dob').value == null){
      this.adultError=true;
    }
    else{
      this.adultError=false;
    }
    if(controlArray.controls[i].get('passptNo').value == "" || controlArray.controls[i].get('passptNo').value == null){
      this.adultError=true;
    }
    else{
      this.adultError=false;
    }
  }
    if (this.addlInfoForm.valid) {
      this.loaderService.isBusy = true;
      this.travelInfo = this.addlInfoForm.value;
      for (var i = 0; i < this.travelInfo.adultdata.length; i++) {

        let da = this.travelInfo.adultdata[i].dob;
        let date = new Date(this.convertYear(this.travelInfo.adultdata[i].dob), this.convertMonth(this.travelInfo.adultdata[i].dob), this.convertDay(this.travelInfo.adultdata[i].dob));
        this.travelInfo.adultdata[i].dob = date;
        this.travelInfo.adultdata[i].transId = this.transId;
        this.travelInfo.adultdata[i].tranSrNo = this.tranSrNo;
        this.travelInfo.adultdata[i].category = '8003';
        this.travelInfo.adultdata[i].userId = this.session.get('username');

        if (this.travelInfo.adultdata[i].wntrSptsExtYN) {
          this.travelInfo.adultdata[i].wntrSptsExtYN = '1'
        } else {
          this.travelInfo.adultdata[i].wntrSptsExtYN = '0'
        }
        this.travellerDetailsArray.push(this.travelInfo.adultdata[i])
      }


      for (var i = 0; i < this.travelInfo.childData.length; i++) {

        let da = this.travelInfo.childData[i].dob;
        let date = new Date(this.convertYear(this.travelInfo.childData[i].dob), this.convertMonth(this.travelInfo.childData[i].dob), this.convertDay(this.travelInfo.childData[i].dob));
        this.travelInfo.childData[i].dob = date;
        this.travelInfo.childData[i].transId = this.transId;
        this.travelInfo.childData[i].tranSrNo = this.tranSrNo;
        this.travelInfo.childData[i].category = '8002';
        this.travelInfo.childData[i].userId = this.session.get('username');
        if (this.travelInfo.childData[i].wntrSptsExtYN) {
          this.travelInfo.childData[i].wntrSptsExtYN = '1'

        } else {
          this.travelInfo.childData[i].wntrSptsExtYN = '0'

        }
        this.travellerDetailsArray.push(this.travelInfo.childData[i]);
      }

      this.agentService.insertTravelInfo(this.travellerDetailsArray).subscribe(result => {
        if (result.respCode == 2000) {
          let params = {
            'insName': this.addlInfoForm.controls['arabicinsuredname'].value,
            'address': this.addlInfoForm.controls['address'].value,
            'poBox': this.addlInfoForm.controls['pobox'].value,
            'city': this.addlInfoForm.controls['city'].value,
            'transRemark': this.addlInfoForm.controls['remarks'].value,
            //'nojoomVocherCode': this.addlInfoForm.controls['vatRefNo'].value,
            'transId': this.transId,
            'tranSrNo': this.tranSrNo,
            'mapId': 'TRAVEL_AGENT_ADDLINFO_SCR01',
            'userId': this.session.get('username')
          }
          this.agentService.updateInsInfo(params).subscribe(result => {
            if (result.respCode == 2000) {
              if (flag == 'approve') {
                let aproveParams = { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode': flag, 'lobCode': '08', 'userId': this.session.get('username'), 'portal': this.session.get("portaltype") }
                this.agentService.approveAgentPolicy(aproveParams).subscribe(result => {
                  if (result.respCode == 2000) {

                  }
                });
              }
              this.router.navigate(['quote-confirm'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'mode': flag } });
            }
          });

        }
      });


    } else {

      this.markFormGroupTouched(this.addlInfoForm);
      console.error("AdditionalForm Not Valid");
    }

  }*/

  convertYear(jsonDate) {
    return jsonDate.date.year;
    // return jsonDate.year;
  }
  convertMonth(jsonDate) {
    return jsonDate.date.month - 1;
    // return jsonDate.month - 1;
  }
  convertDay(jsonDate) {
    return jsonDate.date.day;
    // return jsonDate.day;
  }

  recalculatePremium() {
    this.spinnerService.isBusy = true;
    let params = {
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'agentId': this.session.get('agent')
    }
    this.agentService.getRecalculte(params).subscribe(result => {

      if (result.respCode = 2000) {
        this.isShowRecalc = false;
      }
      this.spinnerService.isBusy = false;
    }, error => {
      let errorMsg = error.error.errMessage;
      let obj = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "quoteNo": this.quoteNo,
        "errorMsg": errorMsg
      };
      this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

    })
  }


  backToScheme() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "lobCode": ApplicationConstants.LOB_TRAVEL,
      "quoteNo": this.quoteNo
    };
    this.router.navigate(['scheme'], { queryParams: obj, skipLocationChange: true });
  }


  enableRecalculateYN(index, event: any) {
    const controlArray = <UntypedFormArray>this.addlInfoForm.get('adultdata');
    let flg = controlArray.controls[index].get('wntrSptsExtYN').value
    if (flg == false) {
      this.isShowRecalc = true;
    }

  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        const controlArray = <UntypedFormArray>this.addlInfoForm.get('adultdata');
        controlArray.markAsTouched;
      } else if (control instanceof UntypedFormGroup) {
        control.markAsTouched({ onlySelf: true });
        this.validateAllFormFields(control);
      }
    });
  }
  public markFormGroupTouched(formGroup: UntypedFormGroup) {

    Object.values(formGroup.controls).forEach(control => {
      if (control instanceof UntypedFormControl) {
        control.markAsTouched();
      }
      else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      }
    });
  }

  uploadPicture(event: any) {

    this.getDocumentCodeBeforeUpload(event.target.id);
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
      var reader = new FileReader();
      var that = this;
      reader.onload = function () {
        that.upload(event);
      }
      reader.readAsDataURL(fileList[0]);
    }

  }



  getDocumentCodeBeforeUpload(event) {
    if (event == "passPort") {
      this.docCodeValue = "006";
    } else if (event == "emiratesId") {
      this.docCodeValue = "004";
    } else if (event == "mail") {
      this.docCodeValue = "038";
    } else if (event == "medicalReport") {
      this.docCodeValue = "048";
    } else if (event == "others") {
      this.docCodeValue = "";
    }
  }



  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('lobCode', this.lobCode);
    formData.append('docCode', this.docCodeValue);
    formData.append('docType', "POL");
    formData.append('userId', this.userId);
    var uploadDocumentReponse = this.commonService.uploadDocuments(formData);

  }
  setDate(): void {
    let date = new Date();
    this.addlInfoForm.patchValue({
      dob: {
        date: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      }
    });
  }

  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            if (array[i].type == 'I') {
              array[i].premium = 'Inclusive';
              this.sumInclusiveMandatory.push(array[i]);
            } else {
              if (array[i].premium > 0) {
                this.netpremium += Number(array[i].premium);
                this.sumInclusiveMandatory.splice(j, 0, array[i]);
              }
              j++;
            }
          }
        }
      });
  }

  getTravelersInfo() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getTravelerDetls(param).subscribe(response => {
      if (response["travelerArray"] != "" && response["travelerArray"] != null && response["travelerArray"] != undefined) {
        this.travelIfoarr = response["travelerArray"];
        this.loadTravelersValues();
      }
    });
  }

  loadTravelersValues() {
    const controlArray1 = <UntypedFormArray>this.addlInfoForm.get('childData');
    const controlArray2 = <UntypedFormArray>this.addlInfoForm.get('adultdata');
    var adult = 0;
    var child = 0;
    for (var i = 0; i < this.travelIfoarr.length; i++) {
      let date = new Date(
        moment(this.travelIfoarr[i].dob, 'DD/MM/YYYY').year(),
        moment(this.travelIfoarr[i].dob, 'DD/MM/YYYY').month(),
        moment(this.travelIfoarr[i].dob, 'DD/MM/YYYY').date()
      );
      if (this.travelIfoarr[i].category == '8002') {
        controlArray1.controls[child].get('trvlrName').setValue(this.travelIfoarr[i].trvlrName);
        controlArray1.controls[child].get('relation').setValue(this.travelIfoarr[i].relation);
        controlArray1.controls[child].get('gender').setValue(this.travelIfoarr[i].gender);
        controlArray1.controls[child].get('nationality').setValue(this.travelIfoarr[i].nationality);
        controlArray1.controls[child].get('passptNo').setValue(this.travelIfoarr[i].passptNo);
        controlArray1.controls[child].get('adultYN').setValue("0");
        controlArray1.controls[child].get('wntrSptsExtYN').setValue((this.travelIfoarr[i].wntrSptsExtYN == 1));
        controlArray1.controls[child].patchValue({
          dob: {
            date: {
              year: moment(date, 'DD/MM/YYYY HH:mm').year(),
              month: moment(date, 'DD/MM/YYYY HH:mm').month() + 1,
              day: moment(date, 'DD/MM/YYYY HH:mm').date(),
            }
          }
        });
        child++;
      }
      if (this.travelIfoarr[i].category == '8003') {
        controlArray2.controls[adult].get('trvlrName').setValue(this.travelIfoarr[i].trvlrName);
        controlArray2.controls[adult].get('relation').setValue(this.travelIfoarr[i].relation);
        controlArray2.controls[adult].get('gender').setValue(this.travelIfoarr[i].gender);
        controlArray2.controls[adult].get('nationality').setValue(this.travelIfoarr[i].nationality);
        controlArray2.controls[adult].get('passptNo').setValue(this.travelIfoarr[i].passptNo);
        controlArray2.controls[adult].get('adultYN').setValue("1");
        controlArray2.controls[adult].get('wntrSptsExtYN').setValue((this.travelIfoarr[i].wntrSptsExtYN == 1));
        controlArray2.controls[adult].patchValue({
          dob: {
            date: {
              year: moment(date, 'DD/MM/YYYY HH:mm').year(),
              month: moment(date, 'DD/MM/YYYY HH:mm').month() + 1,
              day: moment(date, 'DD/MM/YYYY HH:mm').date(),
            }
          }
        });
        adult++;
      }
    }
  }


  enableRecalYN(index, event: any) {
    const controlArray = <UntypedFormArray>this.addlInfoForm.get('childData');
    let flg = controlArray.controls[index].get('wntrSptsExtYN').value
    if (flg == false) {
      this.isShowRecalc = true;
    }
  }

  winSportsFlagYN() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getWinSportsFlgYN(param).subscribe(resp => {
      if (resp.winSprtsFlag == '1') {
        this.winSprtsYN = true;
      }
    })
  }
}





