import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTravelInfoComponent } from './add-travel-info.component';

describe('AddTravelInfoComponent', () => {
  let component: AddTravelInfoComponent;
  let fixture: ComponentFixture<AddTravelInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddTravelInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTravelInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
