import { AbstractControl } from "@angular/forms";




/*export function adultAgeValidator(control: AbstractControl): { [key: string]: boolean } | null {
  let dob = control.value
  let todaydate: any = new Date();
  if (dob != null && dob != undefined) {
    dob = new Date(dob.formatted);
    var age = Math.floor((todaydate - dob) / (365.25 * 24 * 60 * 60 * 1000));
    if (age < 18) {
      return { 'ageRange': true };
    } else if (age > 70) {
      return { 'ageRange': true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function childAgeValidator(control: AbstractControl): { [key: string]: boolean } | null {

  let dob = control.value
  let todaydate: any = new Date();
  if (dob != null && dob != undefined) {
    dob = new Date(dob.formatted);
    var age = Math.floor((todaydate - dob) / (365.25 * 24 * 60 * 60 * 1000));
    if (age > 18) {
      return { 'ageRange': true };
    } else {
      return { 'ageRange': true };
    }
  }
  return null;
}*/





export function adultAgeValidator(control: AbstractControl): { [key: string]: boolean } | null {
  let dob = control.value;
  let birthDate: any;
  if (dob == '' || dob == undefined) {
    return null;
  }
  else {
    if (dob.epoc == undefined) {
      birthDate = new Date(dob.epoc * 1000);
    } else {
      if (dob.date != undefined) {
        dob = dob.date.month + "/" + dob.date.day + "/" + dob.date.year;
        birthDate = new Date(dob);
      } else {
        let parts = dob.split('/');
        birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }
    }
    let age: any;
    let today = new Date();
    //let birthDate = new Date(timestamp);
    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    if (age < 18) {
      return { 'ageRange': true };
    } else if (age > 65) {
      return { 'ageRange': true };
    }
    else {
      return null;
    }
  }

}



export function childAgeValidator(control: AbstractControl): { [key: string]: boolean } | null {
  let dob = control.value;
  let birthDate: any;
  if (dob == '' || dob == undefined) {
    return null;
  }
  else {
    if (dob.epoc == undefined) {
      birthDate = new Date(dob.epoc * 1000);
    } else {
      if (dob.date != undefined) {
        dob = dob.date.month + "/" + dob.date.day + "/" + dob.date.year;
        birthDate = new Date(dob);
      } else {
        let parts = dob.split('/');
        birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
      }
    }
    let age: any;
    let today = new Date();
    //let birthDate = new Date(timestamp);
    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    if (age > 18) {
      return { 'ageRange': true };
    }
    else {
      return null;
    }
  }

}

export function endChildAgeValidator(control: AbstractControl): { [key: string]: boolean } | null {
  let dob = control.value;
  let birthDate: any;
  if (dob == '' || dob == undefined) {
    return null;
  }
  else {
    let date = new Date(dob).toLocaleDateString();
    birthDate = new Date(date);
    let age: any;
    let today = new Date();
    //let birthDate = new Date(timestamp);
    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    if (age > 18) {
      return { 'ageRange': true };
    }
    else {
      return null;
    }

  }

}


export function endAdultAgeValidator(control: AbstractControl): { [key: string]: boolean } | null {
  let dob = control.value;
  let birthDate: any;
  if (dob == '' || dob == undefined) {
    return null;
  }
  else {
    let date = new Date(dob).toLocaleDateString();
    birthDate = new Date(date);
    let age: any;
    let today = new Date();
    //let birthDate = new Date(timestamp);
    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    if (age < 18) {
      return { 'ageRange': true };
    } else if (age > 65) {
      return { 'ageRange': true };
    }
    else {
      return null;
    }
  }

}


