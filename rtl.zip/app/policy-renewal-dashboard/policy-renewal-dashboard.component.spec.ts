import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyRenewalDashboardComponent } from './policy-renewal-dashboard.component';

describe('PolicyRenewalDashboardComponent', () => {
  let component: PolicyRenewalDashboardComponent;
  let fixture: ComponentFixture<PolicyRenewalDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolicyRenewalDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyRenewalDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
