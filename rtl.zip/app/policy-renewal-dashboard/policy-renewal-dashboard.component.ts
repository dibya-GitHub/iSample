import { CurrencyPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import * as moment from 'moment';
import { AgentUserService } from 'src/shared/services/agent-user.service';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { SessionStorageService } from 'angular-web-storage';
import { ECalendarValue } from 'ng2-date-picker';

@Component({
  selector: 'app-policy-renewal-dashboard',
  templateUrl: './policy-renewal-dashboard.component.html',
  styleUrls: ['./policy-renewal-dashboard.component.scss'],
  providers: [CurrencyPipe]
})
export class PolicyRenewalDashboardComponent implements OnInit {
  renewYn: boolean = true;
  columnDefs = [];
  rowData: any[];
  gridApi: any;
  gridColumnApi: any;
  filterOptions: UntypedFormGroup;
  resultOptions: any;
  public myDatePickerOptions: IAngularMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };
  showEnquiryDateErr: boolean;
  searchText: any;
  users: any[];
  selectedPolicy: any;
  material = true;
  ng2datePickerConfig: any = {
    firstDayOfWeek: 'su',
    monthFormat: 'MMM, YYYY',
    disableKeypress: false,
    allowMultiSelect: false,
    closeOnSelect: true,
    closeOnSelectDelay: 0,
    openOnFocus: true,
    openOnClick: true,
    onOpenDelay: 0,
    closeOnEnter: true,
    weekDayFormat: 'ddd',
    appendTo: document.body,
    showNearMonthDays: true,
    showWeekNumbers: false,
    enableMonthSelector: true,
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    dayBtnFormat: 'DD',
    monthBtnFormat: 'MMM',
    hours12Format: 'hh',
    hours24Format: 'HH',
    meridiemFormat: 'A',
    minutesFormat: 'mm',
    minutesInterval: 1,
    secondsFormat: 'ss',
    secondsInterval: 1,
    showSeconds: false,
    showTwentyFourHours: true,
    timeSeparator: ':',
    multipleYearsNavigateBy: 10,
    showMultipleYearsNavigation: false,
    locale: moment.locale(),
    hideInputContainer: false,
    returnedValueType: ECalendarValue.Moment,
    unSelectOnClick: true,
    hideOnOutsideClick: true,
    numOfMonthRows: 3,
    format: 'DD/MM/YYYY'
  };
  constructor(
    private router: Router,
    private currPipe: CurrencyPipe,
    private fb: UntypedFormBuilder,
    private agentService: AgentUserService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
  ) { }

  ngOnInit() {
    const context = this;
    this.columnDefs = [
      {
        field: 'policyNo',
        headerName: 'Policy No',
        sortable: false,
        resizable: true,
        cellStyle: { textAlign: 'left' }
      },
      {
        field: 'policyType',
        headerName: 'Policy Type',
        sortable: true,
        filter: true,
        resizable: true,
        enableRowGroup: true,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'insName',
        headerName: 'Assured Name',
        sortable: true,
        resizable: true,
        enableRowGroup: true,
        tooltipField: '',
      },
      {
        field: 'chassisNo',
        headerName: 'Chassis Number',
        sortable: true,
        resizable: true,
        filter: true,
        tooltipField: '',
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'vehicleMakeModel',
        headerName: 'Vehicle',
        sortable: true,
        resizable: true,
        filter: true,
        enableRowGroup: true,
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'fromDate',
        headerName: 'From Date',
        sortable: true,
        resizable: true,
        enableRowGroup: true,
        headerTooltip: 'Policy From Date',
        cellStyle: { textAlign: 'right' },
        valueFormatter: (params) => {
          return moment(params.value).format('DD/MM/YYYY');
        }
      },
      {
        field: 'toDate',
        headerName: 'To Date',
        sortable: true,
        resizable: true,
        enableRowGroup: true,
        tooltipField: 'toDate',
        headerTooltip: 'Policy To Date',
        valueFormatter: (params) => {
          return moment(params.value).format('DD/MM/YYYY');
        }
      },
      {
        field: 'grossPremium',
        headerName: 'Gross Premium',
        valueFormatter: (params) => {
          return context.currencyFormatter(params);
        },
        sortable: true,
        resizable: true,
        filter: true,
        enableRowGroup: true,
        cellStyle: { textAlign: 'left' },
        tooltipField: 'grossPremium',
      },
      {
        field: 'dueDays',
        headerName: 'Due Days',
        sortable: true,
        resizable: true,
        filter: true,
        enableRowGroup: true,
        cellStyle: { width: '130px', height: '31px', textAlign: 'left' },
      },
      {
        field: 'userName',
        headerName: 'Producer Name',
        sortable: true,
        resizable: true,
        enableRowGroup: true,
        filter: true,
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'status',
        headerName: 'Status',
        sortable: true,
        resizable: true,
        filter: true,
        enableRowGroup: true,
        cellStyle: { textAlign: 'center' },
      },
      {
        field: '',
        headerName: 'Select',
        headerCheckboxSelection: false,
        headerCheckboxSelectionFilteredOnly: true,
        resizable: true,
        checkboxSelection: function (params) {
          if (params.data.status != null) {
            if (params.data.status == 'Pending') {
              return true;
            } else {
              return false;
            }
          }
        },
        cellStyle: { textAlign: 'center' },
      }
    ];
    this.filterOptions = this.fb.group({
      enquiryFrom: [moment().subtract(7, 'd').format('DD/MM/YYYY'), Validators.required],
      enquiryTo: [moment().format('DD/MM/YYYY'), Validators.required],
      user: ['']
    });
    this.resultOptions = {
      totalPolicies: '34',
      renewed: '30',
      expired: '34',
      pending: '15',
      premium: '54366988',
      renewedPremium: '65756',
      expiredPremium: '9888',
      pendingPremium: '7654432'
    };
    this.retrievePolicyData();

    this.getAgentUsers();
  }

  currencyFormatter(params) {
    return this.currPipe.transform(params.value, 'AED ');
  }

  onGridSizeChanged(params) {
    const gridWidth = document.getElementById('treatyGrid').offsetWidth;
    const columnsToShow = [];
    const columnsToHide = [];
    let totalColsWidth = 0;
    const allColumns = params.columnApi.getAllColumns();
    for (let i = 0; i < allColumns.length; i++) {
      const column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  onRowSelected(event) {
    const rowCount = event.api.getSelectedNodes().length;

    if (rowCount) {
      this.selectedPolicy = event.node.data;
    } else if (rowCount === 0) {
      this.selectedPolicy = undefined;
    }
  }

  onEnquiryDateChanged(event, flag) {
    let fromDate;
    let toDate;
    if (flag === 'To') {
      if (this.filterOptions.get('enquiryFrom').value) {
        fromDate = this.filterOptions.get('enquiryFrom').value.formatted;
      }
      toDate = event.formatted;
    } else {
      if (this.filterOptions.get('enquiryTo').value) {
        toDate = this.filterOptions.get('enquiryTo').value.formatted;
      }
      fromDate = event.formatted;
    }
    if (fromDate && toDate) {
      const isBefore = moment(toDate, 'DD/MM/YYYY').isBefore(moment(fromDate, 'DD/MM/YYYY'));
      if (isBefore) {
        this.showEnquiryDateErr = true;
      } else {
        this.showEnquiryDateErr = false;
      }
    }
  }

  searchTextChanged() {
    if (this.searchText || this.searchText === '') {
      this.gridApi.setQuickFilter(this.searchText);
    }
  }

  getAgentUsers() {
    const agentId = JSON.parse(this.session.get('agent'));
    this.agentService.getAgentUsers(agentId).subscribe((res: any) => {
      this.users = res.userInfo;
    },
      err => {
      }
    );
  }

  retrievePolicyData() {
    this.loaderService.isBusy = true;
    if (this.filterOptions.valid) {
      const agentId = JSON.parse(this.session.get('agent'));
      const formData = JSON.parse(JSON.stringify(this.filterOptions.value));
      this.agentService.getPolicyList(agentId, formData)
        .subscribe((res: any) => {
          this.rowData = res.renewalPolicyDetails;
          this.resultOptions = res.renewalPolicySummaryInfo;
          this.loaderService.isBusy = false;
        },
          err => {
            this.loaderService.isBusy = false;
          }
        );
    } else {
      alert('Invalid form. Check all madantory fields are given.');
      this.loaderService.isBusy = false;
    }
  }

  renewPolicy() {
    if (!this.selectedPolicy) {
      return;
    }
    const data = this.selectedPolicy;
    const obj = {
      transId: data.transId,
      transSNo: data.tranSrNo,
      policyNo: data.policyNo,
      lobCode: data.lobCode,
      polStartDate: moment(data.fromDate).format('DD/MM/YYYY HH:mm'),
      polEndDate: moment(data.toDate).format('DD/MM/YYYY HH:mm'),
      schCode: data.schCode,
      prodCode: data.prodCode
    };
    this.router.navigate(['endorsements'], { queryParams: obj, skipLocationChange: true });
  }

  exportExcel() {
    this.gridApi.exportDataAsExcel({ fileName: 'Policy_Due_for_Renewal_Log_' + moment().format('DD_MM_YYYY HH_mm_ss') });
  }

}
