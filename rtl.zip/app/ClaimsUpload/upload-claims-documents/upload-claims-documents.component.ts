
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AgentHttpclientService } from 'src/app/services/agent-httpclient.service';
import { AppUtil } from 'src/app/services/app-util';
import { LoaderService } from 'src/shared/loader-service/loader.service';
import { AgentUserService } from 'src/shared/services/agent-user.service';

@Component({
  selector: 'app-upload-claims-documents',
  templateUrl: './upload-claims-documents.component.html',
  styleUrls: ['./upload-claims-documents.component.scss']
})
export class UploadClaimsDocumentsComponent implements OnInit {
  docCodeValue: string = '';
  appUtilObj: AppUtil = new AppUtil();
  respCode?: string;
  errMessage?: string;
  uploadDriversDivClass: string = "";
  vechileRegistrationDivClass: string = "";
  uploadPoliceReportDivClass: string = "";
  photoName: any;
  allowedExtensions: any = [];
  fileExtension: any;
  fileExtensionError: boolean = false;
  fileExtensionMessage: any;
  imageURL: any = "";
  transId: string;
  clmRefNo: string;
  tranSrNo: string;
  driverLicenseImageURL: string = "";
  driverLicenseFrontImageURL: string = "";
  driverLicenseBackImageURL: string = "";
  policeReportImageURL: string = "";
  emiratesIdImageURL: string = "";
  licenseImageURL: string = "";
  vlicenseFrontImageURL: string = "";
  vlicenseBackImageURL: string = "";
  agencyQuotationImageURL: string = "";
  errorMsg: string = '';
  uploadedDocumentsLength: number = 0;
  totalNumberOfDocuments: number = 5;
  errorMessage: string;
  checkboxValue: boolean = false;

  policeRefNo: string = "";
  lobCode: any;
  postDate: string = "";
  placeOfAccdnt: string = "";
  email: string = "";
  mobile: string = "";
  registrationNo: string = "";
  vehMakerid: string = "";
  vehModelsid: string = "";
  vehMakerText: string = "";
  vehModelsText: string = "";
  manfYear: string = "";
  claimantName: string = "";
  policy_number: string = "";
  Is_I_Insured: any;

  //for i insured
  acciDate: any;
  emailId: any;
  accidentLoc: any;
  mobileNo: any;
  vehRegnNo: any;
  towingYN: any;
  id: any;
  srNo: any;
  polNo: any;
  searchBy: any;
  value: any;
  currentPathName: string;
  accidentDate: any;
  vehLocation: any;
  vehMake: any;
  vehModel: any;
  modelYear: any;
  name: any;
  myErrorMess: any;
  claimDocsImageArray = new Array(5);
  uploadCall: boolean = false;
  uploadNameFlag: boolean = false;
  txnId: any;
  routeData: any;
  fileNameList = [];
  myMap = new Map();
  map1 = new Map();
  policeReportList = [];
  driverLicenseFrontList = [];
  driverLicenseBackList = [];
  vehicleLicenseFront = [];
  vehicleLicenseBack = [];

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private agentService: AgentHttpclientService,
    private commonService: AgentUserService,
    private loaderService: LoaderService,
    private session: SessionStorageService
  ) {
    this.route.queryParams.subscribe(params => {
      this.Is_I_Insured = params["Is_I_Insured"];
      if (!this.Is_I_Insured) {

        //this.clmRefNo = params["clmRefNo"];
        this.lobCode = params["lobCode"];
        this.policeRefNo = params["policeRefNo"];
        this.accidentDate = params["accidentDate"];
        // this.postDate = params["postDate"];
        this.vehLocation = params["vehLocation"];
        this.emailId = params["emailId"];
        this.mobileNo = params["mobileNo"];
        this.vehRegnNo = params["vehRegnNo"];
        this.vehMake = params["vehMake"];
        this.vehModel = params["vehModel"];
        this.vehMakerText = params["vehMakerText"];
        this.vehModelsText = params["vehModelsText"];
        this.modelYear = params["modelYear"];
        this.name = params["name"];
        this.policy_number = params["policy_number"];

      } else {
        this.polNo = params["policyNo"];
        this.acciDate = params["acciDate"];
        this.policeRefNo = params["policeRefNo"];
        this.emailId = params["emailId"];
        this.mobileNo = params["mobileNo"];
        this.accidentLoc = params["accidentLoc"];
        this.vehRegnNo = params["vehRegnNo"];
        this.towingYN = params["towingYN"];
        this.id = params["txnId"];
        this.srNo = params["srNo"];
        this.searchBy = params["searchBy"];
        this.value = params["value"];
        // this.routeData = params["routeData"];
      }
    });

    this.currentPathName = window.location.pathname;
  }

  ngOnInit() {
  }

  goToPreviousPage() {
    if (!this.Is_I_Insured) {
      var obj = {
        "policeRefNo": this.policeRefNo,
        "postDate": this.accidentDate,
        "placeOfAccdnt": this.vehLocation,
        "email": this.emailId,
        "mobile": this.mobileNo,
        "registrationNo": this.vehRegnNo,
        "vehMakerid": this.vehMake,
        "vehModelsid": this.vehModel,
        "vehMakerText": this.vehMakerText,
        "vehModelsText": this.vehModelsText,
        "manfYear": this.modelYear,
        "claimantName": this.name,
        "policy_number": this.policy_number,
        "clmRefNo": ""
      }
      this.router.navigate(['tp-claim'], { queryParams: obj, skipLocationChange: true });
    } else {

      var iObj = {
        "policeRefNo": this.policeRefNo,
        "acciDate": this.acciDate,
        "accidentLoc": this.accidentLoc,
        "emailId": this.emailId,
        "mobileNo": this.mobileNo,
        "vehRegnNo": this.vehRegnNo,
        "towingYN": this.towingYN,
        "id": this.id,
        "srNo": this.srNo,
        "polNo": this.polNo,
        "searchBy": this.searchBy,
        "value": this.value
      }
      this.router.navigate(['submit-claim'], { queryParams: iObj, skipLocationChange: true });
    }
  }

  getDocumentCodeBeforeUpload(event) {
    if (event == "policeReport") {
      this.docCodeValue = "013";
    } else if (event == "driverLicenseFront") {
      this.docCodeValue = "007";
    } else if (event == "driverLicenseBack") {
      this.docCodeValue = "00701";
    } else if (event == "vehicleLicense") {
      this.docCodeValue = "008";
    } else if (event == "vehicleLicenseFront" || event == "vCardFront") {
      this.docCodeValue = "008";
    } else if (event == "vehicleLicenseBack" || event == "vCardBack") {
      this.docCodeValue = "043";
    }
    return this.docCodeValue;
  }

  upload(event: any, files?: any, doc?: any, docCode?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    let fileNameFlag = true;
    if (!this.uploadNameFlag) {
      for (var i = 0; i < this.fileNameList.length; i++) {
        if (file.name == this.fileNameList[i]) {
          alert('Same file already been selected, Please rename the file and upload');
          fileNameFlag = false;
        }
      }
    }
    if (fileNameFlag) {
      if (this.docCodeValue === "013") {
        this.policeReportList.push(file.name);
        if (this.policeReportList.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "007") {
        this.driverLicenseFrontList.push(file.name);
        if (this.driverLicenseFrontList.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "00701") {
        this.driverLicenseBackList.push(file.name);
        if (this.driverLicenseBackList.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "008") {
        this.vehicleLicenseFront.push(file.name);
        if (this.vehicleLicenseFront.length === 1) {
          fileNameFlag = true;
        }
      } else if (this.docCodeValue === "043") {
        this.vehicleLicenseBack.push(file.name);
        if (this.vehicleLicenseBack.length === 1) {
          fileNameFlag = true;
        }
      }
    }
    if (fileNameFlag) {
      if (this.docCodeValue === "013") {
        if (this.policeReportList.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.policeReportList[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.policeReportList.shift();
        }
      } else if (this.docCodeValue === "007") {
        if (this.driverLicenseFrontList.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            //if(this.driverLicenseFrontList[i] === this.fileNameList[i]){
            var index = this.fileNameList.indexOf(this.driverLicenseFrontList[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
            //  this.fileNameList.splice(this.driverLicenseFrontList[0],1);
            //}
          }
          this.driverLicenseFrontList.shift();
        }
      } else if (this.docCodeValue === "00701") {
        if (this.driverLicenseBackList.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.driverLicenseBackList[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.driverLicenseBackList.shift();
        }
      } else if (this.docCodeValue === "008") {
        if (this.vehicleLicenseFront.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.vehicleLicenseFront[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.vehicleLicenseFront.shift();
        }
      } else if (this.docCodeValue === "043") {
        if (this.vehicleLicenseBack.length > 1) {
          for (var i = 0; i < this.fileNameList.length; i++) {
            var index = this.fileNameList.indexOf(this.vehicleLicenseBack[0]);
            if (index !== -1) {
              this.fileNameList.splice(index, 1);
            }
          }
          this.vehicleLicenseBack.shift();
        }
      }
      for (var i = 0; i < this.fileNameList.length; i++) {
        if (file.name === this.fileNameList[i]) {
          this.fileNameList.splice(i, 1);
        }
      }
      this.fileNameList.push(file.name);
    }

    let uniqueChars = this.fileNameList.filter((c, index) => {
      return this.fileNameList.indexOf(c) === index;
    });
    this.fileNameList = uniqueChars

    if (file.type == 'application/pdf') {
      this.imageURL = './assets/images/Pdf-File-icon.png'
    }
    formData.append('fileObject', file, file.name);
    //formData.append('transId', this.transId);
    formData.append('transId', this.clmRefNo);

    formData.append('tranSrNo', "0");
    formData.append('lobCode', this.lobCode);
    formData.append('docType', "CLM");
    formData.append('docCode', ((docCode) ? docCode : this.docCodeValue));
    formData.append('userId', this.session.get("username"));
    if (fileNameFlag) {
      if (this.uploadCall) {
        var uploadDocumentReponse = this.commonService.uploadDocuments(formData).subscribe(data => {
        }, error => {
          let err = error.json();
          this.errorMsg = err.errMessage;
        });
      }
    }


    if (!this.uploadCall && fileNameFlag) {

      if (event.target.id == "policeReport" || doc == "policeReport") {
        if (this.policeReportImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.policeReportImageURL = this.imageURL;
      } else if (event.target.id == "driverLicenseFront" || doc == "driverLicenseFront") {
        if (this.driverLicenseFrontImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.driverLicenseFrontImageURL = this.imageURL;
      } else if (event.target.id == "driverLicenseBack" || doc == "driverLicenseBack") {
        if (this.driverLicenseBackImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.driverLicenseBackImageURL = this.imageURL;
      } else if (event.target.id == "vCardFront" || doc == "vCardFront") {
        if (this.vlicenseFrontImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        // test
        this.vlicenseFrontImageURL = this.imageURL;

      } else if (event.target.id == "vCardBack" || doc == "vCardBack") {
        if (this.vlicenseBackImageURL == '') {
          this.uploadedDocumentsLength++;
        }
        this.vlicenseBackImageURL = this.imageURL;

      }
    }

  }

  onClick(e) {
    event.target["value"] = '';
  }


  onFilesChange(fileList) {
    let doc = fileList.id;
    this.getDocumentCodeBeforeUpload(doc);
    this.fileExtensionError = false;
    this.fileExtensionMessage = "";
    let files = fileList.valid_files
    if (files.length > 0) {
      let file: File = files[0];
      if (doc == "policeReport") {
        this.claimDocsImageArray.splice(0, 1, { event: event, files: files, doc: doc });
      } else if (doc == "driverLicenseFront") {
        this.claimDocsImageArray.splice(1, 1, { event: event, files: files, doc: doc });
      } else if (doc == "driverLicenseBack") {
        this.claimDocsImageArray.splice(2, 1, { event: event, files: files, doc: doc });
      } else if (doc == "vCardFront") {
        this.claimDocsImageArray.splice(3, 1, { event: event, files: files, doc: doc });
      } else if (doc == "vCardBack") {
        this.claimDocsImageArray.splice(4, 1, { event: event, files: files, doc: doc });
      }

      var reader = new FileReader();
      var that = this;
      reader.onload = function () {
        that.imageURL = reader.result;
        that.upload(event, files, doc);
      }
      reader.readAsDataURL(files[0]);
      if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
        this.errorMessage = '';
      }
    }

  }

  invalidFiles(files) {
    //files.preventDefault();
    if (files && files.length > 0) {
      this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
      this.fileExtensionError = true;
    }
  }

  /*- checks if word exists in array -*/
  isInArray(array, word) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

  uploadPicture(event: any) {
    let Id = event.target.id;
    this.getDocumentCodeBeforeUpload(event.target.id);
    if (event.target.files && (event.target.files.length > 0) && event.target.files[0]) {

      var fileDetail = event.target.files[0];
      this.photoName = fileDetail.name;

      this.allowedExtensions = ["jpeg", "jpg", "bmp", "gif", "png", "pdf"];
      this.fileExtension = this.photoName.split('.').pop();
      if (this.isInArray(this.allowedExtensions, this.fileExtension)) {
        this.fileExtensionError = false;
        this.fileExtensionMessage = "";
      } else {
        this.fileExtensionMessage = "Only .jpeg, .jpg, .bmp, .gif, .png, .pdf allowed!!"
        this.fileExtensionError = true;
        return;
      }

      let fileList: FileList = event.target.files;
      if (fileList.length > 0) {
        let file: File = fileList[0];

        var reader = new FileReader();

        var that = this;
        if (Id == "policeReport") {
          this.claimDocsImageArray.splice(0, 1, { event: event, fileList: fileList, doc: Id });
        } else if (Id == "driverLicenseFront") {
          this.claimDocsImageArray.splice(1, 1, { event: event, fileList: fileList, doc: Id });
        } else if (Id == "driverLicenseBack") {
          this.claimDocsImageArray.splice(2, 1, { event: event, fileList: fileList, doc: Id });
        } else if (Id == "vCardFront") {
          this.claimDocsImageArray.splice(3, 1, { event: event, fileList: fileList, doc: Id });
        } else if (Id == "vCardBack") {
          this.claimDocsImageArray.splice(4, 1, { event: event, fileList: fileList, doc: Id });
        }
        reader.onload = function () {
          that.imageURL = reader.result;
          that.upload(event);
        }
        reader.readAsDataURL(fileList[0]);
        if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
          this.errorMessage = '';
        }
      }
    } else {
      return;
    }
  }

  // function to go to the summary page
  // submitClaimDocs(){
  //   this.router.navigate(['thank-you'], {skipLocationChange: true });
  // }

  submitClaimDocs() {
    this.loaderService.isBusy = true;
    if (this.uploadedDocumentsLength < this.totalNumberOfDocuments) {
      this.errorMessage = "Please upload all the documents!";
      return;
    } else {
      if (this.Is_I_Insured) {
        let insuredClaimData = {
          policyNo: this.polNo,
          accidentDate: this.acciDate,
          policeRefNo: this.policeRefNo,
          emailId: this.emailId,
          mobileNo: this.mobileNo,
          vehRegnNo: this.vehRegnNo,
          accidentLoc: this.accidentLoc,
          towingYN: this.towingYN,
          portal: 'A',
          userId: this.session.get("username")
        }
        this.agentService.registerClaim(insuredClaimData).subscribe(data => {
          if (data.respCode == "2000") {
            //this.router.navigate(['upload-claim-docs'], { queryParams: obj,skipLocationChange: true });
            this.clmRefNo = data.clmRefNo;
            //this.router.navigate(['thankyou'], { skipLocationChange: true });

            this.uploadCall = true;
            this.uploadNameFlag = true;
            let i;
            if (this.claimDocsImageArray.length > 0) {

              for (i = 0; i < this.claimDocsImageArray.length; i++) {
                let event = this.claimDocsImageArray[i].event;
                let files = this.claimDocsImageArray[i].files;
                let doc = this.claimDocsImageArray[i].doc;

                const docCode = this.getDocumentCodeBeforeUpload(doc);
                this.upload(event, files, doc, docCode);

                //this.upload();
              }
              this.router.navigate(['claim-thankyou'], { skipLocationChange: true });
            }
          } else {
            this.errorMessage = data.errMessage;
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.errorMessage = this.appUtilObj.displayError(error["_body"], null);
          if (this.errorMessage == '') {
            let a = JSON.parse(error["_body"])
            this.errorMessage = a.errMessage;
          }
        });

      } else if (!this.Is_I_Insured) {
        // }

        // to submit docs for the TP claim
        // if(!this.Is_I_Insured){

        let tpClaimData = {
          policeRefNo: this.policeRefNo,
          vehLocation: this.vehLocation,
          accidentDate: this.accidentDate,
          emailId: this.emailId,
          mobileNo: this.mobileNo,
          vehRegnNo: this.vehRegnNo,
          vehMake: this.vehMake,
          vehModel: this.vehModel,
          modelYear: this.modelYear,
          name: this.name,
          policyNo: this.policy_number,
          portal: 'A',
          userId: this.session.get("username")
        }

        this.agentService.registerTpClaim(tpClaimData).subscribe(data => {

          if (data.respCode == "2000") {
            this.clmRefNo = data.clmRefNo;
            this.uploadCall = true;
            this.uploadNameFlag = true;
            let i;
            if (this.claimDocsImageArray.length > 0) {
              for (i = 0; i < this.claimDocsImageArray.length; i++) {
                let event = this.claimDocsImageArray[i].event;
                let files = this.claimDocsImageArray[i].files;
                let doc = this.claimDocsImageArray[i].doc;

                const docCode = this.getDocumentCodeBeforeUpload(doc);
                this.upload(event, files, doc, docCode);
                //this.upload();
              }
              this.router.navigate(['claim-thankyou'], { skipLocationChange: true });
            }
          } else {
            this.errorMessage = data.errMessage;
          }
        }, error => {
          this.errorMessage = this.appUtilObj.displayError(error["_body"], null);
          if (this.errorMessage == '') {
            let a = JSON.parse(error["_body"])
            this.errorMessage = a.errMessage;
          }
        });
      }
    }
  }

  changeCheckboxStatus(event) {
    if (event.target.checked) {
      this.errorMessage = "";
      this.checkboxValue = true;
    } else {
      this.checkboxValue = false;
    }
  }
}
