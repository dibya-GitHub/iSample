import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadClaimsDocumentsComponent } from './upload-claims-documents.component';

describe('UploadClaimsDocumentsComponent', () => {
  let component: UploadClaimsDocumentsComponent;
  let fixture: ComponentFixture<UploadClaimsDocumentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadClaimsDocumentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadClaimsDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
