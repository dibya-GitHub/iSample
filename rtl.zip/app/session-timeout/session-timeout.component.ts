import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
// declare var jQuery: $;
import { Router } from '@angular/router';
import { timer } from 'rxjs';

@Component({
  selector: 'app-session-timeout',
  templateUrl: './session-timeout.component.html',
  styleUrls: ['./session-timeout.component.scss']
})
export class SessionTimeoutComponent implements OnInit {

  // id: NodeJS.Timer;
  countdown: number;
  cc: number;
  constructor(private router: Router) { }
  ngOnInit() {
    window.localStorage.clear();
    // this.startCountdownTimer();
    // var num:number = 0; 
  }
  ngAfterViewInit() {
    $(window).trigger('resize').trigger('scroll');
  }

  // startCountdownTimer() {
  //   const interval = 1000;
  //   const duration = 60;
  //   const stream$ = timer(30, interval).finally(() => { this.router.navigateByUrl('/marine-login'); })
  //     .takeUntil(timer(60000))
  //     .map(value => duration - value);
  //   stream$.subscribe(value => this.countdown = value);
  // }
}