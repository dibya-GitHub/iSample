import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { ApiConstants } from '../../../shared/api-constants';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { AgentUserService } from "../../../shared/services/agent-user.service";
import { AgentHttpclientService } from '../../services/agent-httpclient.service';
import { Home } from '../home';
import { AdditionalHomeInfo } from '../interfaces/additional-home-info';
import { HomeInsurancePlanService } from '../services/home-insurance-plan.service';
@Component({
  selector: 'app-additional-home-info',
  templateUrl: './additional-home-info.component.html',
  styleUrls: ['./additional-home-info.component.scss']
})
export class AdditionalHomeInfoComponent implements OnInit {
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  policyStartDate: any;
  policyEndDate: any;
  file: File;
  tmpParms: any;
  additionalHomeInfo: AdditionalHomeInfo = new AdditionalHomeInfo();
  currency: any = ApiConstants.CURRENCY;
  formSubmitAttempt: boolean;
  title = 'retail-portal';
  additionalInfoForm: UntypedFormGroup;
  homeContentList: UntypedFormArray
  disableBank: string;
  transId: any;
  tranSrNo: any;
  quoteNo: any;
  lobCode: any;
  cityList: any = [];
  zoneList: any = [];
  streetList: any = [];
  buildingAge: any = [];
  bulTypeList: any = [];
  bankList: any = [];
  nationalityList: any = [];
  occupationList: any = [];
  googleResults: any[];
  selectedGoogleResult: any;
  whereAddressInfo: any;
  civilId: string;
  polStartDate: any;
  polEndDate: any;
  insuredName: string;
  address1: string;
  address2: string;
  address1B: string;
  address2B: string;
  poBox: string;
  poboxB: string;
  city: string;
  cityB: string;
  premium: any;
  coverSummaryList: any = [];
  taxes: any = [];
  discounts: any = [];
  deductables: any = [];
  fees: any = [];
  homeData: Home = new Home();
  docCodeValue: string = '';
  disableBuildingInfo: string;
  agentCommisionValue;
  agentCommissionPercent;
  agentCommissionTax;
  quoteIssueDate: any;
  policyNo: any;
  // Content Block

  addRowData: any = [];
  storeTmpRowData: any = [];
  index
  contentsList: any = [];
  contentArray: any = []
  contentsListSize
  disableAddRow = false;
  showContent = true;
  homeContentBean = [];
  data: any;

  createFormGroup() {
    return this.fb.group({
      arabicInsuredName: '',
      address1: ['', Validators.required],
      address2: '',
      address3: '',
      poBox: [undefined, Validators.required],
      city: [undefined, Validators.required],
      nationality: [undefined],
      occup: [undefined],
      zoneArea: [undefined, Validators.required],
      transRemark: '',
      taxRefNo: '',
      buildingLocation: '',
      address1B: ['', Validators.required],
      address2B: '',
      poBoxB: ['', Validators.required],
      cityB: ['', Validators.required],
      streetBlock: '',
      bldngAge: '',
      bldngType: '',
      financedBank: '',
      financedStatus: '',
      homeContentList: this.fb.array([])
    });
  }

  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    public loaderService: LoaderService,
    private spinnerService: LoaderService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
    public homeInsurancePlanService: HomeInsurancePlanService,
  ) {
    this.additionalInfoForm = this.createFormGroup();

  }

  createItem(): UntypedFormGroup {
    return this.fb.group({
      contentType: null,
      contentDetls: null,
      value: null,
    });
  }
  ngOnInit() {
    this.loaderService.isBusy = true;

    this.disableBank = "true";
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.polStartDate = this.commonService.getParamValue('polStartDate');
    this.polEndDate = this.commonService.getParamValue('polEndDate');
    this.policyNo = this.commonService.getParamValue('policyNo');
    if (this.transId) {
      this.getAdditionalInfo();
    }
    else {
      this.additionalInfoForm.patchValue({
        bldngAge: '1'
      });
    }
    this.policyStartDate = this.getFormattedDate(new Date(this.commonService.getParamValue('polStartDate')));
    this.policyEndDate = this.getFormattedDate(new Date(this.commonService.getParamValue('polEndDate')));
    this.getCity();
    this.getNationality();
    this.getOccupationList();
    this.getStreetBlock();
    this.getBuildingType();
    this.getBankOfFinance();
    this.getAgeOfBuilding();
    //this.getQuoteInformation();
    this.getCoverSummary();
    this.getDiscDedLoadFeesSumm();
    this.getPremiumSummary();
    this.getContentType();
    this.onLoad();
    this.getContentdetails();

    this.disableBuildingInfo = "true";
  }

  onLoad() {
    let reqparam = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getHomeConentServantInfo(reqparam).subscribe(response => {
      if (0 === response.contentSumInsured) {
        this.showContent = false;
      }
    },
      error => {
      });
  }

  addNewRow(mode: string): void {
    this.homeContentList = this.additionalInfoForm.get('homeContentList') as UntypedFormArray;
    this.createItem();
    this.homeContentList.push(this.createItem());
    this.disableAddRow = true;
  }

  insContentDetails() {
    this.homeContentBean = [];
    for (let i = 0; i < this.homeContentList.value.length; i++) {
      let tempvalue = this.homeContentList.value[i]
      if (tempvalue.contentType !== null) {
        let obj = {
          "transId": this.transId,
          "tranSrNo": this.tranSrNo,
          "userId": this.session.get('username').replace(/['"]+/g, ''),
          "contentType": tempvalue.contentType,
          "contentDetls": tempvalue.contentDetls,
          "value": tempvalue.value,
          "srNo": i + 1,
        };
        this.homeContentBean.push(obj);
      }
    }
    this.disableAddRow = false
    this.messageService.add({ severity: 'success', summary: '', detail: 'Content added successfully' });
  }

  saveContentDetails() {
    this.agentService.insContentDetls(this.homeContentBean).subscribe(response => {
      // this.bean = response;
    },
      error => {
      });
  }

  getContentdetails() {
    let editparam = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
    };
    this.agentService.getContentDetls(editparam).subscribe(response => {
      this.data = response.contentDetails;
      for (let i = 0; i < this.data.length; i++) {
        this.addNewRow('add');
      }
      this.additionalInfoForm.patchValue({
        homeContentList: this.data
      });
    },
      error => {
      });
  }


  deleteRow(index) {
    this.homeContentList = this.additionalInfoForm.get('homeContentList') as UntypedFormArray;
    this.homeContentList.removeAt(index);
    this.disableAddRow = false;
    this.homeContentBean.splice(index, 1)

    if (this.homeContentList.length == 0) {
      // this.showFlag = false
    }
  }

  appendZero(temp: any) {
    if (temp < 10) {
      return '0' + temp;
    }
    return temp;
  }

  goToPreviousPage() {
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      lobCode: this.lobCode,
      policyStartDate: new Date(this.polStartDate),
      policyEndDate: new Date(this.polEndDate)
    }
    this.router.navigate(['scheme'], { queryParams: obj, skipLocationChange: true });
  }

  checkBuildingLocation(flag) {
    this.disableBuildingInfo = null;
    if (flag == "  Yes  " || flag == "Yes") {
      this.additionalInfoForm.patchValue({
        address1B: this.additionalInfoForm.get('address1').value,
        address2B: this.additionalInfoForm.get('address2').value,
        poBoxB: this.additionalInfoForm.get('poBox').value,
        cityB: this.additionalInfoForm.get('city').value,
      });
      if (this.additionalInfoForm.get('city').value != "") {
        this.additionalInfoForm.patchValue({
          zoneArea: this.getZone(this.additionalInfoForm.get('city').value)
        });
      }

    }
    else {
      this.additionalInfoForm.patchValue({
        address1B: '',
        address2B: '',
        poBoxB: '',
        cityB: '',
        zoneArea: ''
      });
    }
  }


  enableBankList(financed) {
    if (financed == "  Yes  " || financed == "Yes") {
      this.disableBank = null;

    }
    else {
      this.disableBank = "true";
    }
  }

  getContentType() {
    this.agentService.getApplicationCodes('CONTENT_TYPE').subscribe(data => {
      this.contentArray = data.appCodesArray;
    })
  }

  getCity() {
    this.agentService.getApplicationRefCodes('STATE', '002').subscribe((data: any) => {
      const tmpArr = data.appCodesArray.reverse();;
      this.cityList = tmpArr;
    }, error => {
    });
  }

  getZone(val) {
    if (val) {
      this.agentService.getApplicationRefCodes('ZONE_AREA', val).subscribe(data => {
        const tmpArr = data.appCodesArray.reverse();
        this.zoneList = tmpArr;
      }, error => {
        this.zoneList = [];
      });
    }
  }

  onChange(id) {
    const newVal = id.target.value;
    this.agentService.getApplicationRefCodes('ZONE_AREA', newVal).subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.zoneList = tmpArr;
    }, error => {
      this.zoneList = [];
    });
  }

  getNationality() {
    this.agentService.getApplicationCodes('NATIONALITY').subscribe(data => {

      const tmpArr = data.appCodesArray;

      this.nationalityList = this.sortedArray(tmpArr);
    }, error => {
    });
  }

  getOccupationList() {
    this.agentService.getApplicationCodes('OCCUPATION').subscribe(data => {
      let tmpArr = data.appCodesArray;
      this.occupationList = this.sortedArray(tmpArr);
    }, error => {
    });

  }

  getStreetBlock() {
    this.agentService.getApplicationCodes('STREET_BLOCK').subscribe(data => {
      let tmpArr = data.appCodesArray.reverse();
      this.streetList = tmpArr;
    }, error => {
    });
  }

  getBuildingType() {
    this.agentService.getApplicationCodes('BUILDING_TYP').subscribe(data => {
      let tmpArr = data.appCodesArray.reverse();
      this.bulTypeList = tmpArr;
    }, error => {
    });
  }

  getAgeOfBuilding() {
    for (let i = 1; i <= 11; i++) {
      if (i == 11) {
        this.buildingAge.push('Above 10 Years');
        break;
      }
      this.buildingAge.push(i);
    }
  }

  getBankOfFinance() {
    this.agentService.getApplicationCodes('BANK').subscribe(data => {
      let tmpArr = data.appCodesArray.reverse();
      this.bankList = this.sortedArray(tmpArr);
    }, error => {
    });
  }

  // getQuoteInformation() {
  //   let postData = {
  //     transId: this.transId,
  //     tranSrNo: this.tranSrNo,
  //     mapId: 'HOME_POL_SCR_1'
  //   }

  //   this.agentService.getQuoteInformation(postData).subscribe(quoteInfo => {
  //     this.civilId = quoteInfo.civilId;
  //     this.quoteNo = quoteInfo.quoteNo;
  //     this.insuredName = quoteInfo.insName;
  //     this.quoteIssueDate =  this.getFormattedDate(new Date(quoteInfo.quotIssDate));

  //   }, error => {
  //     this.loaderService.isBusy = false;
  //   });
  // }

  getFormattedDate(date) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    return this.appendZero(day) + "/" + this.appendZero(month) + "/" + this.appendZero(year);
  }

  getAdditionalInfo() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "mapId": "AGENT_HOME_POL_SCR_2"
    };
    this.agentService.getAddlInsuredInfo(obj).subscribe(result => {
      //   this.city=result.city;
      this.additionalHomeInfo = result;
      this.additionalInfoForm.patchValue({
        arabicInsuredName: result.insNameAr,
        address1: result.address1,
        address2: result.address2,
        address3: result.address3,
        city: (result.city) ? result.city : '',
        nationality: (result.nationality) ? result.nationality : '',
        poBox: result.poBox,
        transRemark: result.transRemark,
        taxRefNo: result.vatRefNo

      });

      let param = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "mapId": "HOME_RISK_SCR_2"
      };
      this.agentService.getHomeInfo(param)
        .subscribe(homeResponse => {
          if (homeResponse.financedBank == 'undefined' || homeResponse.financedBank == '' || homeResponse.financedBank == null) {
            this.additionalInfoForm.patchValue({ financedStatus: 'No' });
          }
          else {
            this.additionalInfoForm.patchValue({ financedStatus: 'Yes' });
            this.disableBank = null;
          }
          this.additionalInfoForm.patchValue({
            address1B: homeResponse.address,
            address2B: homeResponse.desc,
            occup: (homeResponse.occupation) ? homeResponse.occupation : '',
            poBoxB: homeResponse.poBox,
            cityB: (homeResponse.city) ? homeResponse.city : '',
            zoneArea: (homeResponse.zoneArea) ? homeResponse.zoneArea : '',
            streetBlock: (homeResponse.streetBlock) ? homeResponse.streetBlock : '',
            bldngType: (homeResponse.bldngType) ? homeResponse.bldngType : '',
            bldngAge: (homeResponse.bldngAge) ? homeResponse.bldngAge : '',
            financedBank: (homeResponse.financedBank) ? homeResponse.financedBank : ''
          });
          this.getZone(homeResponse.city);
        }, error => {

        });

    });

  }

  getCoverSummary() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }

    this.agentService.getCoverSummary(postData)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {

          if (array[i].type == 'I' || array[i].type == 'M') {
            if (array[i].type == 'I') {
              array[i].premium = 'Inclusive';
              this.coverSummaryList.push(array[i]);
            } else {
              if (array[i].premium > 0) {
                this.coverSummaryList.splice(j, 0, array[i]);
              }
              j++;
            }
          }
        }

      });

  }

  getDiscDedLoadFeesSumm() {

    let taxesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "TAX"
    };
    this.agentService.getDiscDedLoadFeesSumm(taxesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.taxes.push(data[k]);
        }
      }

    }, error => {

    });

    let dedPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DED"
    };
    this.agentService.getDiscDedLoadFeesSumm(dedPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.deductables.push(data[k]);
        }
      }
    }, error => {

    });

    let discountPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "DISC"
    };
    this.agentService.getDiscDedLoadFeesSumm(discountPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.discounts.push(data[k]);
        }
      }
    }, error => {

    });

    let feesPostData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      type: "FEES"
    };
    this.agentService.getDiscDedLoadFeesSumm(feesPostData).subscribe(response => {
      if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
        var data = response["othersArray"];
        for (var k = 0; k < data.length; k++) {
          this.fees.push(data[k]);
        }
      }
    }, error => {

    });
  }

  getPremiumSummary() {
    let postData = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    }
    this.agentService.getNetPremium(postData).subscribe(response => {
      this.agentCommisionValue = response.AGENT_FC;
      this.agentCommissionPercent = response.AGENT_PERCENT;
      this.agentCommissionTax = response.QPI_ACOMM_TAX;
      this.premium = response.PREMIUM;
    }, error => {
    });
  }

  getDocumentCodeBeforeUpload(event) {
    if (event == "emiratesId") {
      this.docCodeValue = "004";
    } else if (event == "mail") {
      this.docCodeValue = "038";
    } else if (event == "passport") {
      this.docCodeValue = "006";
    } else if (event == "proposalForm") {
      this.docCodeValue = "039";
    } else if (event == "highValueItem") {
      this.docCodeValue = "050";
    } else if (event == "others") {
      this.docCodeValue = "";
    } else if (event == "receipt") {
      this.docCodeValue = "049";
    }
  }

  uploadDocuments(event: any) {

    this.getDocumentCodeBeforeUpload(event.target.id);
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
      var reader = new FileReader();
      var that = this;
      reader.onload = function () {

        that.upload(event);
      }
      reader.readAsDataURL(fileList[0]);
    }

  }



  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('lobCode', this.lobCode);
    formData.append('docCode', this.docCodeValue);
    formData.append('docType', "POL");
    formData.append('userId', "evan");
    var uploadDocumentReponse = this.commonService.uploadDocuments(formData);

  }

  updateData(homeData) {
    this.additionalHomeInfo.transId = this.transId;
    this.additionalHomeInfo.tranSrNo = this.tranSrNo;
    this.additionalHomeInfo.address1 = homeData.address1;
    this.additionalHomeInfo.address2 = homeData.address2;
    this.additionalHomeInfo.address3 = homeData.address3;
    this.additionalHomeInfo.poBox = homeData.poBox;
    this.additionalHomeInfo.city = homeData.city;
    this.additionalHomeInfo.nationality = homeData.nationality;
    this.additionalHomeInfo.insNameAr = homeData.arabicInsuredName;
    this.additionalHomeInfo.transRemark = homeData.transRemark;
    this.additionalHomeInfo.vatRefNo = homeData.taxRefNo;
    this.additionalHomeInfo.mapId = "AGENT_HOME_POL_SCR_2";

    this.agentService.updateInsuredInfo(this.additionalHomeInfo).subscribe(updateInsuredInfoResponse => {
      this.additionalHomeInfo.mapId = "HOME_RISK_SCR_2";
      this.additionalHomeInfo.poBox = homeData.poBoxB;
      this.additionalHomeInfo.occupation = homeData.occup;
      this.additionalHomeInfo.address = homeData.address1B;
      this.additionalHomeInfo.desc = homeData.address2B;
      this.additionalHomeInfo.city = homeData.cityB;
      this.additionalHomeInfo.zoneArea = homeData.zoneArea;
      this.additionalHomeInfo.streetBlock = homeData.streetBlock;
      this.additionalHomeInfo.bldngAge = homeData.bldngAge;
      this.additionalHomeInfo.bldngType = homeData.bldngType;
      this.additionalHomeInfo.financedBank = homeData.financedBank;
      // this.homeInsurancePlanService.updateHomeInfo(this.additionalHomeInfo).subscribe(updateHomeInfoResponse => {
      this.agentService.updateHomeInfo(this.additionalHomeInfo).subscribe(updateHomeInfoResponse => {
        const obj = {
          transId: this.transId,
          tranSrNo: this.tranSrNo,
          lobCode: this.lobCode,
          quoteNo: this.quoteNo,
          polStartDate: this.polStartDate,
          polEndDate: this.polEndDate,
          policyNo: this.policyNo
        }
        this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
      }, error => {

        this.loaderService.isBusy = false;
      });
    }, error => {

    });

  }

  onSubmit() {
    this.formSubmitAttempt = true;
    if (this.additionalInfoForm.valid) {
      this.spinnerService.isBusy = true;
      this.homeData = this.additionalInfoForm.value;
      this.updateData(this.homeData);
      this.saveContentDetails();
    } else {
      this.validateAllFormFields(this.additionalInfoForm);
      console.error('InvalidForm');
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true })
      }
    });
  }

  sortedArray(tmpArr: any) {
    return tmpArr.sort((n1, n2) => {
      if (n1.desc > n2.desc) {
        return 1;
      }

      if (n1.desc < n2.desc) {
        return -1;
      }
      return 0;
    });
  }
}
