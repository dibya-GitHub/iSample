import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { ApiConstants } from '../../shared/api-constants';
import { ErrorMessage } from "../../shared/error-message";
import { LoaderService } from '../../shared/loader-service/loader.service';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { Tooltip } from "../../shared/tool-tip";
import { AgentHttpclientService } from "../services/agent-httpclient.service";
import { Home } from './home';
import { HomeInfo } from './interfaces/home-info';
import { HomeInsurancePlanService } from './services/home-insurance-plan.service';
@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

    //ToolTip
    public tooltipMessgae = new Tooltip();

    //Error Message
    public Err_msg = new ErrorMessage();

    userType: string = this.session.get("usertype");
    transId: any;
    tranSrNo: any;
    duration: any;
    test = "test tooltip";
    currency: any = ApiConstants.CURRENCY;
    quoteNo: any;
    policyNo: any;
    editYn: any;
    formSubmitAttempt: boolean;
    // emailRegEx = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';
    mobilePattern = '(^[5]\d{8}$)|(^([0][5])\d{8}$)';

    policyDuration = 365;
    countList: any = [];
    questionList: any = [];
    answerList: any[] = [{ isSelected: false }, { isSelected: false }, { isSelected: false }];
    toDate = this.calculatePolicyToDate(this.policyDuration);
    policyEndDate: any;
    homeInfo: HomeInfo = new HomeInfo();
    homeData: Home = new Home();
    disableFromDate: boolean = true;
    disableToDate: boolean = true;
    minDate: Date;
    maxDate: Date;
    dateError: any = { isError: false, errorMessage: '' };
    template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
    userForm = new UntypedFormGroup({
        insuredname: new UntypedFormControl("", Validators.required),
        email: new UntypedFormControl("", Validators.email),
        civilId: new UntypedFormControl("", Validators.compose([Validators.required, Validators.pattern(/^\d{3}-\d{4}-\d{7}-\d{1}$/)])),
        mobileNo: new UntypedFormControl("", Validators.compose([Validators.required, Validators.pattern(/(^5\d{8}$|^(05)\d{8}$)/)])),
        promoCode: new UntypedFormControl(""),
        polStartDate: new UntypedFormControl(null, Validators.required),
        polToDate: new UntypedFormControl(null),
        sumInsured1: new UntypedFormControl("0", Validators.compose([Validators.required, Validators.pattern('^[0-9]*$')])),
        sumInsured2: new UntypedFormControl("0", Validators.compose([Validators.required, Validators.pattern('^[0-9]*$')])),
        totChild: new UntypedFormControl("", Validators.required),
        totAdult: new UntypedFormControl("", Validators.required),
        uwQuesResult: new UntypedFormControl("")
    });

    public myDatePickerOptions: IAngularMyDpOptions = {
        dateFormat: 'dd/mm/yyyy'
    };
    isEndorsement: boolean;

    constructor(
        private router: Router,
        public commonService: AgentUserService,
        public loaderService: LoaderService,
        private spinnerService: LoaderService,
        private messageService: MessageService,
        private session: SessionStorageService,
        private agentService: AgentHttpclientService,
        public homeInsurancePlanService: HomeInsurancePlanService,
    ) {
        this.agentService.getCount().subscribe(getCountResponse => {
            if (getCountResponse.respCode == 2000) {
                this.countList = getCountResponse.count;
            }
        }, error => {
            this.loaderService.isBusy = false;
        });

        this.agentService.getUWQuestions().subscribe(data => {
            if (data.respCode == 2000) {
                this.questionList = data.UWQuestions;
            }

        }, error => {
            this.loaderService.isBusy = false;
        });
    }

    ngOnInit() {
        if (this.session.get('companyCode') == null) {
            this.session.set("companyCode", "002");
        }
        this.transId = this.commonService.getParamValue('transId');
        this.tranSrNo = this.commonService.getParamValue('tranSrNo');
        this.quoteNo = this.commonService.getParamValue('quoteNo');
        this.policyNo = this.commonService.getParamValue('policyNo');
        this.editYn = this.commonService.getParamValue('editYn');
        if (this.policyNo) {
            this.isEndorsement = true;
        }

        if (this.transId != undefined && this.transId != undefined) {
            this.getQuoteData();
        }
        else {
            this.setDate();
            this.userForm.patchValue({
                totChild: '0',
                totAdult: '0',

            });
        }
        this.getAgentFilterInfo();
        this.getPolicyDuration();

    }

    getAgentFilterInfo() {
        let obj = {
            "userRoleId": this.session.get('USER_ROLE_ID'),
            "lobCode": ApiConstants.HOME_INSURANCE_LOBCODE
        };
        this.agentService.getAgentFilterInfo(obj).subscribe(data => {
            if ('1' == data.UAU_FM_DATE_MODIFY_YN) {
                this.disableFromDate = false;
            }
            if ('1' == data.UAU_TO_DATE_MODIFY_YN) {
                this.disableToDate = false;
            }

            var backDate = data.UAU_MAX_BACK_DATE_DAYS;
            var futureDate = data.UAU_MAX_FUTURE_DATE_DAYS;
            var years = new Date().getFullYear();
            var month = new Date().getMonth();
            var days = new Date().getDate();
            this.minDate = new Date(years, month, days - backDate, 23, 59);
            this.maxDate = new Date(years, month, days + futureDate, 23, 59);
        });
    }
    updateEndDate(event) {
        var endDate = new Date(event);
        var year = endDate.getFullYear();
        var month = endDate.getMonth();
        var day = endDate.getDate();
        var hour = 0, minute = 0;
        if (day == new Date().getDate() && month == new Date().getMonth() && year == new Date().getFullYear()) {
            hour = new Date().getHours();
            minute = new Date().getMinutes();
        }
        let startDate = new Date(year, month, day, hour, minute);
        this.userForm.patchValue({ polStartDate: startDate })
        var toDate = new Date(year, (month) + Number(this.duration), day - 1, 23, 59);
        this.userForm.patchValue({ polToDate: toDate })
    }

    setDate(): void {
        // Set today date using the patchValue function
        var date = new Date();

        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth();
        var day = today.getDate();
        var toDate = new Date(year + 1, month, day - 1, 23, 59);
        this.userForm.patchValue({
            polStartDate: new Date(), polToDate: toDate
        });

    }
    getQuoteData() {
        let params = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            mapId: 'AGENT_HOME_POL_SCR_1'
        };
        this.agentService.getQuotInsInfo(params).subscribe((getQuotedata: any) => {
            let par = {
                transId: this.transId,
                tranSrNo: this.tranSrNo,
                mapId: 'AGENT_HOME_RISK_SCR_1'
            }
            this.agentService.getHomeInfo(par).subscribe(response => {

                this.userForm.patchValue({
                    civilId: getQuotedata.civilId,
                    email: getQuotedata.emailId,
                    mobileNo: getQuotedata.mobileNo,
                    sumInsured1: response.persnlblngsVal,
                    sumInsured2: response.contentsVal,
                    totChild: response.noOfChild,
                    totAdult: response.noOfDomstServDriv,
                    insuredname: getQuotedata.insName,
                    promoCode: getQuotedata.promoCode,
                    /*polStartDate: new Date(getQuotedata.polStartDate),/*{
                        date: {
                            year: new Date(getQuotedata.polStartDate).getFullYear(),
                            month: new Date(getQuotedata.polStartDate).getMonth() + 1,
                            day: new Date(getQuotedata.polStartDate).getDate()
                        }
                    }*/
                    /*  polToDate: new Date(getQuotedata.polEndDate)/*{
                          date: {
                              year: new Date(getQuotedata.polEndDate).getFullYear(),
                              month: new Date(getQuotedata.polEndDate).getMonth() + 1,
                              day: new Date(getQuotedata.polEndDate).getDate()
                          }
  
                      }*/
                    polStartDate: moment(getQuotedata.polStartDate, 'DD/MM/YYYY HH:mm').toISOString(),
                    polToDate: moment(getQuotedata.polEndDate, 'DD/MM/YYYY HH:mm').toISOString(),
                });
                this.answerList[0].isSelected = (response.uwAnsOne === '1');
                this.answerList[1].isSelected = (response.uwAnsTwo === '1');
                this.answerList[2].isSelected = (response.uwAnsThree === '1');
                var today = moment(new Date(), 'DD/MM/YYYY HH:mm');
                let convertedFromDate1 = new Date(
                    moment(getQuotedata.polStartDate, 'DD/MM/YYYY').year(),
                    moment(getQuotedata.polStartDate, 'DD/MM/YYYY').month(),
                    moment(getQuotedata.polStartDate, 'DD/MM/YYYY').date()
                );
                let convertedDate2 = new Date(
                    moment(today, 'DD/MM/YYYY').year(),
                    moment(today, 'DD/MM/YYYY').month(),
                    moment(today, 'DD/MM/YYYY').date()
                );

                if (this.editYn === "1" && convertedFromDate1 < convertedDate2) {
                    this.userForm.patchValue({
                        polStartDate: moment(new Date(), 'DD/MM/YYYY HH:mm').toISOString(),
                    });
                    this.updateEndDate(new Date());
                }
            }, error => {
                this.loaderService.isBusy = false;
            });

        }, error => {
            this.loaderService.isBusy = false;
        });


    }

    getPolicyDuration() {
        let strPostData = {
            lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
        }
        this.agentService.getPolicyDuration(strPostData).subscribe(response => {
            if (response.respCode == 2000) {
                this.duration = response.duration;
            }
        }, (error) => {
            //let errorMsg=JSON.parse(error["_body"]).errMessage;
            let errorMsg = error.error.errMessage;
        });
    }


    myTooltipOptions = {
        'placement': 'top',
        'show-delay': 500
    }

    getFormattedDate(date) {
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear();
        const mins = date.getMinutes();
        const hours = date.getHours();
        return this.appendZero(day) + "/" + this.appendZero(month) + "/" + this.appendZero(year) + " " + this.appendZero(hours) + ":" + this.appendZero(mins);
    }



    onSubmit() {
        this.formSubmitAttempt = true;
        if (this.userForm.valid) {
            this.spinnerService.isBusy = true;
            this.homeData = this.userForm.value;
            let pStart = moment(this.userForm.value.polStartDate).format('DD/MM/YYYY HH:mm')
            let pEndDate = moment(this.userForm.value.polToDate).format('DD/MM/YYYY HH:mm')
            this.loaderService.isBusy = true;
            if (this.transId != null && this.transId != undefined) {
                this.homeInfo.transId = this.transId;
                this.homeInfo.tranSrNo = this.tranSrNo;
                this.homeInfo.mapId = "AGENT_HOME_POL_SCR_1";
                this.homeInfo.emailId = this.homeData.email;
                this.homeInfo.promoCode = this.homeData.promoCode;
                this.homeInfo.mobileNo = this.homeData.mobileNo;
                this.homeInfo.civilId = this.homeData.civilId;
                this.homeInfo.modeOfPay = "CC";
                this.homeInfo.insName = this.homeData.insuredname.toUpperCase();
                this.homeInfo.custCode = this.session.get("agent");
                this.homeInfo.insCode = this.session.get("agent");
                this.homeInfo.agentId = this.session.get("agent");
                this.homeInfo.polStartDate = pStart;//convertedStartDate;
                this.homeInfo.polEndDate = pEndDate;//convertedToDate;
                this.homeInfo.srcType = this.userType
                this.agentService.updateInsuredInfo(this.homeInfo).subscribe(updateInsuredInfoResponse => {
                    this.homeInfo.mapId = "AGENT_HOME_RISK_SCR_1";
                    this.homeInfo.contentsVal = this.homeData.sumInsured2;
                    this.homeInfo.persnlblngsVal = this.homeData.sumInsured1;
                    this.homeInfo.noOfDomstServDriv = this.homeData.totAdult;
                    this.homeInfo.noOfChild = this.homeData.totChild;
                    this.homeInfo.uwAnsOne = (this.answerList[0].isSelected) ? '1' : '0';
                    this.homeInfo.uwAnsTwo = (this.answerList[1].isSelected) ? '1' : '0';
                    this.homeInfo.uwAnsThree = (this.answerList[2].isSelected) ? '1' : '0';
                    this.agentService.updateHomeInfo(this.homeInfo).subscribe(updateHomeInfoResponse => {
                        const postData = {
                            transId: this.homeInfo.transId,
                            tranSrNo: this.homeInfo.tranSrNo,
                            userId: ApiConstants.USER_ID,
                            portal: ApiConstants.PORTAL,
                            lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
                        };

                        this.agentService.calculatePricing(postData).subscribe(data => {
                            this.loaderService.isBusy = false;
                            if (data.respCode == 2000) {
                                const obj = {
                                    quoteNo: this.homeInfo.quoteNo,
                                    transId: this.homeInfo.transId,
                                    tranSrNo: this.homeInfo.tranSrNo,
                                    lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
                                    assured: this.homeData.insuredname,
                                    civilId: this.homeData.civilId,
                                    policyStartDate: pStart,//convertedStartDate,
                                    policyEndDate: pEndDate//convertedToDate
                                }

                                this.router.navigate(['scheme'], { queryParams: obj, skipLocationChange: true });
                                this.spinnerService.isBusy = false;
                            }
                        }, error => {

                            let errorMsg = error.error.errMessage;
                            let obj = {}
                            if (this.tranSrNo > 0) {
                                obj = {
                                    "transId": this.homeInfo.transId,
                                    "tranSrNo": this.homeInfo.tranSrNo,
                                    "policyNo": this.policyNo,
                                    "quoteNo": this.quoteNo,
                                    "errorMsg": errorMsg
                                };
                            }
                            else {
                                obj = {
                                    "transId": this.homeInfo.transId,
                                    "tranSrNo": this.homeInfo.tranSrNo,
                                    "quoteNo": this.quoteNo,
                                    "errorMsg": errorMsg
                                };
                            }

                            this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
                            this.loaderService.isBusy = false;
                        });
                    }, error => {

                        this.loaderService.isBusy = false;
                    });
                }, error => {
                    this.loaderService.isBusy = false;
                });

            }
            else {

                const postData = {
                    lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
                    portal: this.session.get("portaltype"),
                    userId: this.session.get("username"),
                    insName: this.homeData.insuredname.toUpperCase(),
                    civilId: this.homeData.civilId,
                    polStartDate: moment(new Date()).format('DD/MM/YYYY HH:mm'),
                    prodShortDesc: 'HOME'
                };


                this.agentService.createQuote(postData).subscribe(createQuoteResponse => {

                    this.homeInfo.transId = createQuoteResponse.transId;
                    this.homeInfo.tranSrNo = createQuoteResponse.tranSrNo;
                    this.homeInfo.quoteNo = createQuoteResponse.quoteNo;
                    this.homeInfo.mapId = "AGENT_HOME_POL_SCR_1";
                    this.homeInfo.emailId = this.homeData.email;
                    this.homeInfo.promoCode = this.homeData.promoCode;
                    this.homeInfo.mobileNo = this.homeData.mobileNo;
                    this.homeInfo.civilId = this.homeData.civilId;
                    this.homeInfo.insName = this.homeData.insuredname.toUpperCase();
                    this.homeInfo.agentId = this.session.get("agent");
                    this.homeInfo.modeOfPay = "CC";
                    this.homeInfo.polStartDate = pStart;//convertedStartDate;
                    this.homeInfo.polEndDate = pEndDate;//convertedToDate;
                    this.agentService.updateInsuredInfo(this.homeInfo).subscribe(updateInsuredInfoResponse => {
                        this.homeInfo.mapId = "AGENT_HOME_RISK_SCR_1";
                        this.homeInfo.persnlblngsVal = this.homeData.sumInsured1;
                        this.homeInfo.contentsVal = this.homeData.sumInsured2;
                        this.homeInfo.noOfDomstServDriv = this.homeData.totAdult;
                        this.homeInfo.noOfChild = this.homeData.totChild;
                        this.agentService.updateHomeInfo(this.homeInfo).subscribe(updateHomeInfoResponse => {
                            const postData = {
                                transId: this.homeInfo.transId,
                                tranSrNo: this.homeInfo.tranSrNo,
                                userId: this.session.get("username"),
                                portal: this.session.get("portaltype"),
                                lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
                                agentId: this.homeInfo.agentId,
                                civilId: this.homeInfo.civilId,
                                insName: this.homeInfo.insName.toUpperCase()
                            }
                            this.agentService.calculatePricing(postData).subscribe(data => {
                                this.loaderService.isBusy = false;
                                if (data.respCode == 2000) {

                                    const obj = {
                                        quoteNo: this.quoteNo,
                                        transId: this.homeInfo.transId,
                                        tranSrNo: this.homeInfo.tranSrNo,
                                        lobCode: ApiConstants.HOME_INSURANCE_LOBCODE,
                                        assured: this.homeData.insuredname,
                                        civilId: this.homeData.civilId,
                                        policyStartDate: pStart,//convertedStartDate,
                                        policyEndDate: pEndDate//convertedToDate
                                    }

                                    this.router.navigate(['scheme'], { queryParams: obj, skipLocationChange: true });

                                }
                            }, error => {
                                let errorMsg = error.error.errMessage;
                                let obj = {
                                    "transId": this.homeInfo.transId,
                                    "tranSrNo": this.homeInfo.tranSrNo,
                                    "quoteNo": this.homeInfo.quoteNo,
                                    "errorMsg": errorMsg
                                };
                                this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
                                // this.loaderService.isBusy = false;
                            });
                        }, error => {

                            this.loaderService.isBusy = false;
                        });
                    }, error => {
                        this.loaderService.isBusy = false;
                    });
                }, error => {
                    this.loaderService.isBusy = false;
                });

            }

        } else {
            this.validateAllFormFields(this.userForm);
            console.error('InvalidForm');
        }

    }

    cancelEndorsement() {
        let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
        this.agentService.cancelEndrosement(param)
            .subscribe(result => {
                this.router.navigate(['agentdashboard']);
            });
    }

    validateAllFormFields(formGroup: UntypedFormGroup) {
        window.scrollTo(0, 0);
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof UntypedFormControl) {
                control.markAsTouched({ onlySelf: true })
            }
        });
    }

    compareTwoDates(fromDate, toDate) {
        if (fromDate.setHours(0, 0, 0, 0) >= toDate.setHours(0, 0, 0, 0)) {
            this.dateError = { isError: true, errorMessage: 'Policy End date must be greater than Policy Start date' };
        }
        else {
            this.dateError = { isError: false, errorMessage: '' };
        }
    }

    calculatePolicyToDate(policyDuration) {
        const todate = new Date(new Date().getTime() + (policyDuration * 24 * 60 * 60 * 1000));
        const day = todate.getDate() - 1;
        const month = todate.getMonth() + 1;
        const year = todate.getFullYear();
        const hours = todate.getHours();
        const minutes = todate.getMinutes();
        return day + "/" + month + "/" + year + " " + hours + ":" + minutes;
    }

    onStartDateChanged(event) {
        let d: Date = new Date(event.jsdate.getTime());
        d.setDate(d.getDate() - 1);
        this.userForm.patchValue({
            polToDate: {
                date: {
                    year: d.getFullYear() + 1,
                    month: d.getMonth() + 1,
                    day: d.getDate()
                }
            }
        })
    }

    appendZero(temp: any) {
        if (temp < 10) {
            return '0' + temp;
        }
        return temp;
    }
}
