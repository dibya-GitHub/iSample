export class HomeInfo {
    transId: string;
    tranSrNo: string;
    userId: string;
    mapId: string;
    contentsVal: string;
    persnlblngsVal: string;
    noOfDomstServDriv: string;
    emailId: string;
    mobileNo: string;
    promoCode: any;
    civilId: string;
    insName: string;
    noOfChild: string;
    custCode: string;
    insCode: string;
    agentId: string;
    polStartDate;
    polEndDate;
    srcType : string;
    uwAnsOne: string;
    uwAnsTwo: string;
    uwAnsThree: string;
    quoteNo:string;
    modeOfPay: string;
    constructor()
    { }
  }
  