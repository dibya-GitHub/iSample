export class AdditionalHomeInfo {
    transId: number;
    tranSrNo: number;
    userId: string;
    mapId: string;
    startDate: Date;
    endDate: Date;
    address1: string;
    address1B: string;
    address2:string;
    address2B:string;
    address3 : string;
    address : string;
    desc : string;
    buildAddress: string;
    poBox: string;
    poboxB: string;
    city: any;
    cityB: any;
    zoneArea: string;
    streetBlock: string;
    bldngAge: string;
    bldngType: string;
    financedBank: any;
    insName: string;
    insNameAr: string;
    civilId: string;
    mobileNo: string;
    nationality: any;
    polHoldAddr: string;
    country: string;
    occupation:string;
    financedBankYn:string;
    portal: string;
    lobCode:string;
    transRemark: string;
    vatRefNo: string;
    constructor()
    { }
  }