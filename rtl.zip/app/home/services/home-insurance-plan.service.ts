import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ApiUrls } from '../../../shared/api-urls';
import { ApiHeadersService } from '../../../shared/services/api-header.service';

@Injectable({
  providedIn: 'root'
})
export class HomeInsurancePlanService {

  public requestOption;
  public baseUrl = environment.baseUrl;

  constructor(public http: HttpClient , public apiHeadersService: ApiHeadersService, private session: SessionStorageService,) {
  this.requestOption = this.apiHeadersService.requestOption;
  //alert(JSON.stringify(this.requestOption));
 }

  updateHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_HOME_INFO_URL + '?company=' + this.session.get('companyCode') , body, this.requestOption);
  }

  getQuoteHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_HOME_INFO, body, this.requestOption);
  }



  /*GetApplicationParameter(refType: any): Observable<any> {
    const postData = {
      paraType: refType
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_PARAM, postData, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }

    getHomeInfo(body:any){   
    return this.http.post<any>(this.baseUrl + ApiUrls.GET_HOME_INFO+'?company='+this.session.get('companyCode'),body);
    
  }
  updatePolicyDuration(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_POLICY_DURATION, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }
  getQuoteHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_HOME_INFO, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }
  getPolicyHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_HOME_INFO, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }
  insContentDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_CONTENT_DETAILS, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }
  getContentDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_CONTENT_DETAILS, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }
  insServantDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_SERVENT_DETAILS, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }
  getServantDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_SERVENT_DETAILS, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }
  getHomeConentServantInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_HOME_CONTENT_SERVENT_INFO, body, this.requestOption).map((response: Response) => {
      return response.json();
    });
  }*/
}
