import { NumbersOnlyDirectiveDirective } from './numbers-only-directive.directive';

describe('NumbersOnlyDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new NumbersOnlyDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
