import { GeographicalLimit } from '../classes/geographicalLimit';
import { VehicleCylinder } from '../classes/vehicleCylinder';
import { VehicleMake } from '../classes/vehicleMake';
import { VehicleModel } from '../classes/vehicleModel';
import { VehicleType } from '../classes/vehicleTypes';
// import { UsageArray } from '../classes/vehicleUsage';


export interface VehicleTypes {
   errMessage: string;
   respCode: string;
   typeArray: Array<VehicleType>
}

export interface VehicleMakes {
   respCode: string;
   errMessage: string;
   makeArray: Array<VehicleMake>
}

export interface VehicleModels {
   respCode: string;
   errMessage: string;
   appCodesArray: Array<VehicleModel>
}

export interface VehicleCylinders {
   errMessage: string;
   respCode: string;
   appCodesArray: Array<VehicleCylinder>
}

//    export interface RegistrationLocationList {
//     errMessage: string;
//     respCode: string;
//     appCodesArray: Array<RegistrationLocation>
//    }

export interface GeographicalLimits {
   errMessage: string;
   respCode: string;
   appCodesArray: Array<GeographicalLimit>
}


export interface UsageArray {
   usageArray: Array<UsageArray>;
   respCode: string;
   errMessage: string;
}

export interface appParamArray {
   appParamsArray: Array<GeographicalLimit>;
   respCode: string;
   errMessage: string;
}

export interface Quotation {
   quoteNo: string;
   transId: string;
   tranSrNo: string;
   respCode: any;
   errMessage: string;
}

export interface CoverSummary {
   transId: string;
   tranSrNo: string;
   coverCode: string;
   coverDesc: string;
   coverDocYN: string;
   helptext: string;
   premium: string;
   errMessage: string;
}

export interface DiscountDeductibleSummary {
   code: string;
   desc: string;
   helptext: string;
   value: string;
   errMessage: string;
}

