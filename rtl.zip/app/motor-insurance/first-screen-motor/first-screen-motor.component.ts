import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { ErrorMessage } from '../../../shared/error-message';
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { AgentUserService } from '../../../shared/services/agent-user.service';
import { Tooltip } from '../../../shared/tool-tip';
import { ValidatorService } from '../../../shared/validator-service';
import { AgentHttpclientService } from '../../services/agent-httpclient.service';

@Component({
  selector: 'app-first-screen-motor',
  templateUrl: './first-screen-motor.component.html',
  styleUrls: ['./first-screen-motor.component.scss']
})
export class FirstScreenMotorComponent implements OnInit {
  errorMsg: any;
  validChassisNo: boolean;
  date = new Date();
  public spin: Boolean = false;
  // ToolTip
  public tooltipMessgae = new Tooltip();

  // Error Message
  public Err_msg = new ErrorMessage();

  public validator = new ValidatorService();
  edataError: string;
  chassisForm: UntypedFormGroup;
  vehModelDetailsForm: UntypedFormGroup;
  specificationForm: UntypedFormGroup;
  specDetailForm: UntypedFormGroup;
  public edataVehiInfoFlag = false;
  withoutChesisno: boolean = false;
  editVehTrim: boolean = false;
  quoteNo: string;
  chassisNo: string;
  transId: string;
  tranSrNo: string;
  specVal: string;
  vehTrim: string;
  oldTrimId: string;
  editmake: string;
  editModel: string;
  editModelYear: string;
  VehModalYearError;
  vehMakeError;
  vehModalError;
  vehTrimError;
  vehBodyTypeError;
  vehEngSizeError;
  public isOldVessel = true;
  public modelList: Array<any>;
  public makeList: Array<any>;
  public specificationsList: Array<any>;
  yearArray: any = [];
  userFilter: any = this.session.get('userFilter');
  ip: string;
  userId: string = this.session.get('username');
  agentRoleId: string = this.session.get('USER_ROLE_ID');
  userType: string = this.session.get('usertype');
  portalType: string = this.session.get('portaltype');
  companyCode: string = this.session.get('companyCode');

  formSubmitAttempt = false;
  @ViewChild('someModal') someModal: ElementRef;
  canShowSpecification: boolean;
  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private activeRoute: ActivatedRoute,
    private spinnerService: LoaderService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
  ) {

  }

  ngOnInit() {
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (params.isOldVessel == "true") {
        this.isOldVessel = true;
      } else {
        this.isOldVessel = false;
        this.specVal = params.specVal;
        this.transId = params.transId;
        this.tranSrNo = params.tranSrNo;
        this.oldTrimId = params.oldTrimId;
        //this.createSpecDetForm();
        this.specDetailForm = this.fb.group({
          make: [''],
          model: [''],
          modelYear: [''],
          vehTrim: ['']
        });
      }

    });

    this.chassisForm = this.fb.group({
      chassisNo: ['', Validators.required]
    });
    this.commonService.getIPAddress().subscribe(data => {
      this.ip = data.ip;
    });
    const year = new Date().getFullYear();
    for (let i = year; i > (year - 5); i--) {
      this.yearArray.push(i);
    }
    if (this.specVal === "1") {
      this.editVehicleDetails();
      this.loadTrimValues();
    }
  }


  onClickSubmit(form) {
    this.formSubmitAttempt = true;
    if (this.chassisForm.valid) {
      this.spin = true;
      this.chassisNo = form.chassisNo;
      const param = {
        'chassisNo': form.chassisNo,
        'companyCode': this.companyCode,
        'portal': this.portalType,
        'userId': this.userId,
        'ipAddress': this.ip
      };
      this.spinnerService.isBusy = true;
      this.agentService.getVehicleInfoFromChassisNo(param)
        .subscribe(response => {

          if (response.errMessage != 'Success') {
            this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: response.errMessage });
            // timer(3000).subscribe(res =>);
            // this.router.navigate(['motor'], {
            //   queryParams: { errMsg: response.errMessage }
            // });
          } else {

            let obj = response;
            obj.vehMake = (obj.vehMake == null) ? "" : obj.vehMake;
            obj.vehModel = (obj.vehModel == null) ? "" : obj.vehModel;
            obj.vehModelYear = (obj.vehModelYear == null) ? "" : obj.vehModelYear;
            this.initModelDetailsForm(obj);
          }
        }, err => {
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
          this.spinnerService.isBusy = false;
        });
    } else {
      this.validateAllFormFields(this.chassisForm);
      console.error('InvalidForm');
    }

  }
  isAllCompleted(resolve) {
    if (this.withoutChesisno) {
      if (this.yearArray && this.makeList) {
        resolve();
      }
    }
    else {
      if (this.yearArray && this.makeList && this.modelList) {
        resolve();
      }
    }
  }
  getSelectOptions(vehicleInfo): Promise<any> {

    return new Promise((resolve, reject) => {
      this.agentService.getModelYears().subscribe(
        res => {
          this.yearArray = res.modelyearArray;
          this.isAllCompleted(resolve);
        }, err => reject(err));
      this.agentService.getVehicleMakeList().subscribe(
        res => {
          this.makeList = res.vehMakeArray;
          this.isAllCompleted(resolve);
        }, err => reject(err));
      if (!this.withoutChesisno) {
        this.agentService.getVehicleModelList(vehicleInfo).subscribe(
          res => {
            this.modelList = res.vehModelArray;
            this.isAllCompleted(resolve);
          }, err => {
            this.modelList = [];
            this.isAllCompleted(resolve);
          });
      } else if (!this.editVehTrim) {
        let strPostData = {
          vehMake: this.editmake
        }
        this.agentService.getVehicleModelList(strPostData).subscribe(
          res => {
            this.modelList = res.vehModelArray;
            this.isAllCompleted(resolve);
          }, err => {
            this.modelList = [];
            this.isAllCompleted(resolve);
          });
      }


      // return new Promise((resolve, reject) => {
      //   const yearsService = this.agentService.getModelYears();
      //   const makeService = this.agentService.getVehicleMakeList();
      //   const modelService = this.agentService.getVehicleModelList(vehicleInfo);
      //   // let specService;
      //   // //  = of(vehicleInfo).pipe(
      //   // //   map
      //   // // );
      //   // if (vehicleInfo.vehModelYear && vehicleInfo.vehMake && vehicleInfo.vehModel) {
      //   //   const request = Object.assign({}, vehicleInfo, { chassisNo: this.chassisNo});
      //   //   specService = this.agentService.getSpecifications(request);
      //   // }
      //   zip(yearsService, makeService, modelService)
      //     .pipe(
      //       map(([yearsList, makeList, modelList]) => ({ yearsList, makeList, modelList })),
      //     )
      //     .subscribe(res => {
      //       // set options to the select controls.
      //       let errorMsg;
      //       if ((res.yearsList.respCode === '1001' && (errorMsg = res.yearsList.errMessage)) ||
      //         (res.makeList.respCode === '1001' && (errorMsg = res.makeList.errMessage)) ||
      //         (res.modelList.respCode === '1001' && (errorMsg = res.modelList.errMessage))) {
      //         // this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: response.errMessage });
      //         // timer(3000).subscribe(res =>);
      //         this.router.navigate(['motor'], {
      //           queryParams: { errMsg: errorMsg }
      //         });
      //       } else {
      //         this.yearArray = res.yearsList.modelyearArray;
      //         this.makeList = res.makeList.vehMakeArray;
      //         this.modelList = res.modelList.vehModelArray;
      //       }
      //       resolve();
      //     },
      //       err => {
      //         reject(err);
      //       });
    });
  }

  initModelDetailsForm(vehicleData: any) {
    this.getSelectOptions(vehicleData)
      .then(res => {
        this.edataVehiInfoFlag = true;
        this.vehModelDetailsForm = this.fb.group({
          vehModelYear: ['', Validators.required],
          vehMake: ['', Validators.required],
          vehModel: ['', Validators.required],
          admeId: ['']
        });
        this.vehModelDetailsForm.patchValue(vehicleData);
        this.spinnerService.isBusy = false;
      }).catch(err => {
        this.spinnerService.isBusy = false;
      });
  }

  initEditModelDetailsForm(vehicleData: any) {
    this.spinnerService.isBusy = true;
    this.getSelectOptions(vehicleData)
      .then(res => {
        this.specDetailForm.patchValue({
          make: vehicleData.make,
          modelYear: vehicleData.modelyear,
          model: vehicleData.model,
          vehTrim: this.oldTrimId,
          transId: this.transId,
          tranSrNo: this.tranSrNo
        });
        this.specDetailForm.get('modelYear').disable();
        this.specDetailForm.get('make').disable();
        this.specDetailForm.get('model').disable();
        this.spinnerService.isBusy = false;
      }).catch(err => {
        this.spinnerService.isBusy = false;
      });
  }

  InitSpecificationForm(vehicleDetailsForm) {
    if (this.vehModelDetailsForm.valid) {
      this.spinnerService.isBusy = true;
      this.getVehicleSpecificationDetails()
        .then(res => {
          this.specificationForm = this.fb.group(
            {
              admeId: ['', Validators.required]
            }
          );
          this.edataVehiInfoFlag = false;
          this.canShowSpecification = true;
          this.spinnerService.isBusy = false;
        }).catch(err => {
          this.spinnerService.isBusy = false;
        });
    } else {
      this.validateAllFormFields(this.vehModelDetailsForm);
    }
  }

  getVehicleSpecificationDetails(): Promise<any> {
    return new Promise((resolve, reject) => {
      const request = Object.assign({}, this.vehModelDetailsForm.value, { chassisNo: this.chassisNo, withoutChassisNoFlag: this.withoutChesisno });
      // delete request.admeId;
      this.spinnerService.isBusy = true;
      this.agentService.getSpecifications(request)
        .subscribe(res => {
          if (res.respCode === '1001') {
            this.router.navigate(['motor'], {
              queryParams: { errMsg: res.errMessage }, skipLocationChange: true
            });
          } else {
            this.specificationsList = res.specification;
            // this.vehModelDetailsForm.patchValue({ admeId: '' });
            const specCntrl = this.vehModelDetailsForm.get('admeId');
            specCntrl.setValidators([Validators.required]);
            specCntrl.updateValueAndValidity();
            this.vehModelDetailsForm.get('vehModelYear').disable();
            this.vehModelDetailsForm.get('vehMake').disable();
            this.vehModelDetailsForm.get('vehModel').disable();
            this.canShowSpecification = true;
          }
          this.spinnerService.isBusy = false;
          resolve({});
        }, err => {
          this.router.navigate(['motor'], {
            queryParams: request, skipLocationChange: true
          });
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
          this.spinnerService.isBusy = false;
          reject(err);
        });
    });
  }


  onSubmit() {
    if (this.vehModelDetailsForm.valid) {
      if (this.canShowSpecification) {
        this.getTransactionId();
      } else {
        this.getVehicleSpecificationDetails();
      }
    } else {
      this.validateAllFormFields(this.vehModelDetailsForm);
    }
  }
  clickMe() {
    let obj = {
      "vehMake": "", "vehModelYear": "", "vehModel": ""
    }
    this.withoutChesisno = true;
    this.initModelDetailsForm(obj);
  }
  getTransactionId() {
    if (this.vehModelDetailsForm.valid) {
      this.spinnerService.isBusy = true;
      if (this.withoutChesisno) {
        this.vehModelDetailsForm.get('vehModelYear').enable();
        this.vehModelDetailsForm.get('vehMake').enable();
        this.vehModelDetailsForm.get('vehModel').enable();
      }

      let request = {
        chassisNo: this.chassisNo,
        admeId: this.vehModelDetailsForm.value.admeId,
        portal: this.portalType,
        userId: this.userId,
        ipAddress: this.ip,
        vehMake: this.vehModelDetailsForm.get('vehMake').value,
        vehModel: this.vehModelDetailsForm.get('vehModel').value,
        vehModelYear: this.vehModelDetailsForm.get('vehModelYear').value
      };
      request = Object.assign({}, request, { chassisNo: this.chassisNo, withoutChassisNoFlag: this.withoutChesisno });
      this.agentService.getQuoteData(request)
        .subscribe(res => {
          if (res.respCode === '1001') {
            res.withoutChassisNoFlag = this.withoutChesisno;
            this.router.navigate(['motor'], { queryParams: res, skipLocationChange: true });
          } else {
            if (this.withoutChesisno) {
              res.withoutChassisNoFlag = this.withoutChesisno;
              this.router.navigate(['motor'], { queryParams: res, skipLocationChange: true });
            } else {
              this.router.navigate(['motor'], { queryParams: { transId: res.transId, tranSrNo: res.tranSrNo, sumAssured: res.vehicleValue }, skipLocationChange: true });
            }
          }
          this.spinnerService.isBusy = false;
        }, err => {
          this.spinnerService.isBusy = false;
        });
    } else {
      this.validateAllFormFields(this.vehModelDetailsForm);
    }
  }

  updateModelList() {
    const vehDetails = this.vehModelDetailsForm.value;
    if (vehDetails.vehMake) {
      this.spinnerService.isBusy = true;
      this.agentService.getVehicleModelList(vehDetails)
        .subscribe(res => {
          this.vehModelDetailsForm.patchValue({ vehModel: '', admeId: '' });
          this.modelList = res.vehModelArray;
          this.specificationsList = [];
          this.spinnerService.isBusy = false;
        }, err => {
          this.modelList = [];
          this.vehModelDetailsForm.patchValue({ vehMake: '', admeId: '' });
          this.spinnerService.isBusy = false;
        });
    }
  }


  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      }
    });
  }
  validateChassisNo(val: string) {

    if (val != null && val != "") {
      this.spinnerService.isBusy = true;
      let param = {
        "chassisNo": val,
        "transId": this.transId,
        "company": this.companyCode
      };
      this.agentService.valDupChassisNo(param)
        .subscribe(result => {
          if ("1" == result.validYN) {
            this.validChassisNo = true;
            let param = {
              "company": this.companyCode,
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "civilId": "",
              "chassisNo": val
            }

            this.agentService.allowChassisNo(param)
              .subscribe(result => {
                this.validChassisNo = true;
                this.spinnerService.isBusy = false;
              }, error => {
                this.errorMsg = error.error.errMessage;
                this.validChassisNo = false;
                this.spinnerService.isBusy = false;
              })
          } else {
            this.validChassisNo = false;
            this.spinnerService.isBusy = false;
          }
        }, error => {

          this.spinnerService.isBusy = false;
          this.errorMsg = error.error.errMessage;
          this.validChassisNo = false;
        });
    }
  }

  onItemChange(value) {
    if (value == 'ThirdParty') {
      this.router.navigate(['motor'], { queryParams: { insType: 'thirdParty' }, skipLocationChange: true });
    }
  }

  loadTrimValues() {
    const request = Object.assign({}, { transId: this.transId, tranSrNo: this.tranSrNo, editTrim: "1", withoutChassisNoFlag: true });
    // delete request.admeId;
    this.spinnerService.isBusy = true;
    this.agentService.getSpecifications(request)
      .subscribe(res => {
        if (res.respCode === '1001') {
          this.router.navigate(['motor'], {
            queryParams: { errMsg: res.errMessage }, skipLocationChange: true
          });
        } else {
          this.specificationsList = res.specification;
          this.canShowSpecification = true;
        }
        this.spinnerService.isBusy = false;
      }, err => {
        this.router.navigate(['motor'], {
          queryParams: request, skipLocationChange: true
        });
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
        this.spinnerService.isBusy = false;
      });
  }

  editVehicleDetails() {
    const request = Object.assign({}, { transId: this.transId, tranSrNo: this.tranSrNo });
    // delete request.admeId;
    this.spinnerService.isBusy = true;
    this.agentService.getVehDetails(request)
      .subscribe(res => {
        if (res.respCode === '2000') {
          this.editmake = res.vehDatas.key;
          this.editModel = res.vehDatas.value;
          this.editModelYear = res.vehDatas.info1;
        }
        let obj = {
          "make": this.editmake, "modelyear": this.editModelYear, "model": this.editModel
        }
        this.editVehTrim = false;
        this.withoutChesisno = true;
        this.initEditModelDetailsForm(obj);
        this.spinnerService.isBusy = false;
      }, err => {
        this.router.navigate(['motor'], {
          queryParams: request, skipLocationChange: true
        });
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
        this.spinnerService.isBusy = false;
      });
  }

  createSpecDetForm() {
    this.specDetailForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      vehTrim: this.oldTrimId,
    });
  }
  updateTrimValues() {
    this.spinnerService.isBusy = true;
    /*this.specDetailForm.patchValue({
      vehTrim: this.specDetailForm.value.vehTrim,
      transId: this.transId,
      tranSrNo: this.tranSrNo
    });*/
    let obj = {
      "vehTrim": this.specDetailForm.value.vehTrim, "transId": this.transId, "tranSrNo": this.tranSrNo
    }

    this.agentService.updateTrimValues(obj)
      .subscribe(result => {
        if (result.respCode === '2000') {
          let obj = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            quoteNo: this.quoteNo,
            editYn: "1",
          };
          this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
        }
        this.spinnerService.isBusy = false;
      }, err => {
        this.router.navigate(['motor'], {
          // queryParams: request
        });
        this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: err.error.errMessage });
        this.spinnerService.isBusy = false
      });
  }
}
