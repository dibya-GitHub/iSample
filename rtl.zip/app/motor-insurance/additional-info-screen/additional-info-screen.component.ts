import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { MessageService } from 'primeng/api';
import { DriverDetails } from 'src/app/motor-insurance/classes/driver-details';
import { ErrorMessage } from "../../../shared/error-message";
import { LoaderService } from "../../../shared/loader-service/loader.service";
import { AgentUserService } from "../../../shared/services/agent-user.service";
import { Tooltip } from "../../../shared/tool-tip";
import { AgentHttpclientService } from '../../services/agent-httpclient.service';
import { PrimaryInfo } from '../classes/primary-info';


@Component({
  selector: 'app-additional-info-screen',
  templateUrl: './additional-info-screen.component.html',
  styleUrls: ['./additional-info-screen.component.scss']
})
export class AdditionalInfoScreenComponent implements OnInit {
  showFlag: boolean = false;

  //ToolTip
  // public ChassisNo =Tooltip.ADD_INFO_ChassisNo;

  //Error Message
  public Err_msg = new ErrorMessage();

  //ToolTip
  public tooltipMessgae = new Tooltip();

  file: File;
  disabledName = false;
  docCodeValue;
  public colorList: any;
  public plateList: Array<any>;
  public vehPlateList: Array<any>;
  public vehShapeList: Array<any>;
  public bankList: Array<any>;
  public cityList: Array<any>;

  public countryList: Array<any>;
  public weightList: Array<any>;

  public occupationList: Array<any>;
  public nationalityList: Array<any>;
  public genderList: Array<any>;
  public langList: Array<any>;
  public contactList: Array<any>;
  public relationList: Array<any>;
  public plateTypes: Array<any>;
  is_disabled: string;
  is_Chassis_disabled: string;
  quoteNo: string;
  polStartDate: string;
  polEndDate: string;
  policyIssueDate: string;
  civilId: string;
  currencyCode: string;
  makeDesc: string;
  modelDesc: string;
  sumInsured: any;
  insName: string;
  eDataChassisNo: string;
  chassisNo: String;
  public sumInclusiveMandatory: any[] = [];
  public discounts: any[] = [];
  public deductables: any[] = [];
  public loading: any[] = [];
  public fees: any[] = [];
  public tax: any[] = [];
  public installmentDetails: any[] = [];
  titleAlert: string = 'This field is required';
  defaultArr = [];
  agentCommissionPercent;
  agentCommisionValue;
  agentCommissionTax;
  netPremium;
  validChassisNo: boolean = true;
  errorMsg: string;
  showAgentBlock: boolean = false;
  showChasisError = false
  chassiErr: any;
  city: string;

  basicinfo: PrimaryInfo;
  driverInfo: DriverDetails;
  driverInfoArray: any;
  transId: string;
  tranSrNo: string;
  reloadAddtionalCharge: boolean = false;
  driverEnable: boolean = false;
  enableDMSUpload: string;
  //boolean
  isDetEnable: boolean = false;
  isDisEnable: boolean = false;
  isLoadEnable: boolean = false;
  isFeeEnable: boolean = false;

  instYN: string;
  //session
  userId: string = this.session.get("username");
  agentRoleId: string = this.session.get("USER_ROLE_ID");
  agentCode: string = this.session.get("agent");
  userType: string = this.session.get("usertype");
  portalType: string = this.session.get("portaltype");
  companyCode: string = this.session.get("companyCode");
  lobCode: string = '01';

  public installAccess: string = this.session.get("installAccess");
  userFilter: any = this.session.get("userFilter");

  public agentAuthDetails: any[] = [];

  additionalInfo: UntypedFormGroup;
  driverList: UntypedFormArray;

  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  isEndorsement = false;
  policyNo: any;
  companyYn: any;
  disableAdd: any;
  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private spinnerService: LoaderService,
    private messageService: MessageService,
    private commonService: AgentUserService,
    private session: SessionStorageService,
    private agentService: AgentHttpclientService,
  ) {
    this.additionalInfo = this.fb.group({
      chassisNo: ['', Validators.required],
      engineNo: ['', Validators.required],
      regnNo: '',
      colorArr: '',
      countryArr: ['', Validators.required],
      weightArr: ['', Validators.required],
      financedYn: '0',
      financedBankArr: '',
      insNameAr: '',
      address: '',
      poBox: ['', Validators.required],
      cityArr: ['', Validators.required],
      occupationArr: '',
      plateChar: '',
      genderArr: '',
      cardRefNo: '',
      trafficLoc: ['', Validators.required],
      orangeCardNo: '',
      aaaCardNo: '',
      tcfNo: ['', Validators.required],
      tplLimit: ['', Validators.required],
      vatRefNo: '',
      vehPlateCode: '',
      mileage: '',
      driverList: this.fb.array([])
    })
  }
  createItem(): UntypedFormGroup {
    return this.fb.group({
      driverName: '',
      driverAge: '',
      licenseNo: '',
      licenseAge: '',
      relation: ''
    });
  }


  ngOnInit() {
    this.spinnerService.isBusy = true;
    this.transId = this.commonService.getParamValue('transId');//this.route.snapshot.paramMap.get('transId')//"1397780"//"1397225";
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.getHeaderInformation();
    this.getAdditionalInfo();
    this.getAgentAuthDtls();
    this.getCoverSummary();
    this.getDiscDedLoadFeesSumm();
    let defarr = [];
    let id;
    let text;
    let object = { id: "", text: "--select--" };
    defarr.push(object);
  }

  dropDownService() {
    this.getCityList();
    this.getColorList();
    this.getBankList();
    this.getOccupationList();
    this.getGenderList();
    this.getWeightList();
    this.getCountryList();
    this.getRelationList();
    this.getPlateTypeList();
    this.getvehiclePlateTypeList();
  }

  getPlateType() {
    let params = { "type": "PLATE_CHAR" }
    this.agentService.getPlateType(params).subscribe(result => {
      this.plateTypes = result;
    })
  }

  getAdditionalInfo() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "mapId": "MOT_AGENT_POL_SCR_2"
    };
    this.agentService.getAddlInsuredInfo(obj).subscribe(result => {
      this.city = result.city;
      this.basicinfo = result;
      this.instYN = result.instYN;
      this.additionalInfo.patchValue({
        insNameAr: result.insNameAr,
        address: result.address,
        poBox: result.poBox,
        cityArr: (result.city) || '',
        cardRefNo: '',
        vatRefNo: (result.vatRefNo ? result.vatRefNo : undefined)
      });
      this.companyYn = this.session.get('companyYn');
      this.setValidationForVat();

      let param = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "mapId": "MOT_AGENT_RISK_SCR_2"
      };
      this.agentService.getVehicleInfo(param)
        .subscribe(result => {
          this.basicinfo = result;
          this.eDataChassisNo = this.basicinfo.chassisNo;
          if (!(this.basicinfo.financedBank) || (this.basicinfo.financedBank === 'select')) {
            this.additionalInfo.patchValue({
              financedYn: '0',
              financedBankArr: ''
            });
            this.is_disabled = 'true';
            this.disabledBankList('0');
          }
          else {
            this.additionalInfo.patchValue({
              financedYn: '1',
              financedBankArr: this.basicinfo.financedBank
            });
            this.is_disabled = null;
            this.disabledBankList('1');
          }
          this.additionalInfo.patchValue({
            chassisNo: this.basicinfo.chassisNo,
            engineNo: this.basicinfo.engineNo,
            regnNo: this.basicinfo.regnNo,
            trafficLoc: this.basicinfo.trafficLoc || '',
            orangeCardNo: this.basicinfo.orangeCardNo,
            plateChar: this.basicinfo.plateChar,
            aaaCardNo: this.basicinfo.aaaCardNo,
            tplLimit: this.basicinfo.tplLimit,
            tcfNo: this.basicinfo.tcfNo,
            countryArr: this.basicinfo.manfCountry || '',
            vehPlateCode: this.basicinfo.vehPlateCode,
            mileage: this.basicinfo.mileage
            //  financedBankArr : this.basicinfo.financedBank
          });
          // this.edataChassisNoValidation(this.basicinfo.chassisNo);
          this.getDriverDetails();
          this.dropDownService();
        }, error => {

        });

    });

  }

  getDriverDetails() {
    let param = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo
    };
    this.agentService.getDriverDetails(param)
      .subscribe(result => {
        this.driverInfoArray = result.driverArray;
        for (var i = 1; i <= this.driverInfoArray.length; i++) {
          this.driverInfo = new DriverDetails();
          this.driverInfo = this.driverInfoArray[i - 1];
          this.addNewRow('edit');
        }
        this.showAgentBlock = true;
        this.loadDefaultValues();
        this.spinnerService.isBusy = false;
      });
  }
  loadDefaultValues() {
    for (var i = 1; i <= this.driverInfoArray.length; i++) {
      this.driverInfo = new DriverDetails();
      this.driverInfo = this.driverInfoArray[i - 1];
      var index = i - 1;
      const controlArray = <UntypedFormArray>this.additionalInfo.get('driverList');
      controlArray.controls[index].get('driverName').setValue(this.driverInfo.driverName);
      controlArray.controls[index].get('driverAge').setValue(this.driverInfo.driverAge);
      controlArray.controls[index].get('licenseNo').setValue(this.driverInfo.licenseNo);
      controlArray.controls[index].get('licenseAge').setValue(this.driverInfo.licenseAge);
      controlArray.controls[index].get('relation').setValue(this.driverInfo.relation);
    }
  }
  edataChassisNoValidation(val: string) {
    if (val === undefined) {
      this.is_Chassis_disabled = null;
    }
    if (val != null && val != "") {
      let param = {
        "company": this.companyCode,
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "chassisNo": val
      }
      this.agentService.checkEdataChassisFlow(param)
        .subscribe(result => {
          if (result.eData == 1) {
            this.is_Chassis_disabled = 'true';
            //this.additionalInfo.controls['chassisNo'].disable();
          } else {
            this.is_Chassis_disabled = null;
            // this.additionalInfo.controls['chassisNo'].enable();
          }
        }, error => {
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: error.error.errMessage });
          this.spinnerService.isBusy = false;
        });
    }
  }
  validateChassisNo(val: string) {
    if (val != null && val != "") {
      this.spinnerService.isBusy = true;
      let param = {
        "chassisNo": val,
        "transId": this.transId,
        "company": this.companyCode
      };
      this.agentService.valDupChassisNo(param)
        .subscribe(result => {
          if ("1" == result.validYN) {
            this.validChassisNo = true;
            let param = {
              "company": this.companyCode,
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "civilId": this.civilId,
              "chassisNo": val
            }

            this.agentService.allowChassisNo(param)
              .subscribe(result => {
                this.validChassisNo = true;
                this.spinnerService.isBusy = false;
              }, error => {
                this.errorMsg = error.error.errMessage;
                this.validChassisNo = false;
                this.spinnerService.isBusy = false;
              })
          } else {
            this.validChassisNo = false;
            this.spinnerService.isBusy = false;
          }
        }, error => {

          this.spinnerService.isBusy = false;
          this.errorMsg = error.error.errMessage;
          this.validChassisNo = false;
          let param = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": this.quoteNo,
            "errMessage": error.error.errMessage
          };
          this.agentService.insertErrorMsg(param).subscribe(response => {
            let obj = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
            };
            this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
          });
        });
    }
  }

  validateChassisNoPkg(val: string) {
    if (val != null && val != "") {
      this.spinnerService.isBusy = true;
      let param = {
        "chassisNo": val,
        "transId": this.transId,
        "company": this.companyCode,
        "tranSrNo": this.tranSrNo
      };
      this.agentService.valDupChassisNoPkg(param)
        .subscribe(result => {
          if ("1" == result.validYN) {
            this.validChassisNo = true;
          } else {
            this.validChassisNo = false;
            this.spinnerService.isBusy = false;
          }
        }, error => {

          this.spinnerService.isBusy = false;
          this.errorMsg = error.error.errMessage;
          this.validChassisNo = false;
          let param = {
            "transId": this.transId,
            "tranSrNo": this.tranSrNo,
            "quoteNo": this.quoteNo,
            "errMessage": error.error.errMessage
          };
          this.agentService.insertErrorMsg(param).subscribe(response => {
            let obj = {
              "transId": this.transId,
              "tranSrNo": this.tranSrNo,
              "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
            };
            this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
          });
        });
    }
  }

  showAgentDiv(mode: string) {
    this.showAgentBlock = true;
    this.addNewRow(mode);
  }

  addNewRow(mode: string): void {
    this.driverList = this.additionalInfo.get('driverList') as UntypedFormArray;
    this.createItem();
    this.driverList.push(this.createItem());
    this.showFlag = true;
  }

  deleteRow(index) {
    this.driverList = this.additionalInfo.get('driverList') as UntypedFormArray;
    this.driverList.removeAt(index);
    if (this.driverList.length == 0) {
      this.showFlag = false
    }
  }
  disabledBankList(value: string) {

    const bank = this.additionalInfo.get('financedBankArr');
    if (value == "1") {
      bank.setValidators([Validators.required]);
      this.is_disabled = null;
    } else {
      this.is_disabled = 'true';
      this.additionalInfo.get("financedBankArr").setValue("");
      bank.clearValidators();
    }
    bank.updateValueAndValidity();
  }
  setValidationForVat() {
    const vat = this.additionalInfo.get('vatRefNo');
    if (this.companyYn == "1") {
      vat.setValidators(Validators.required);
    } else {
      vat.clearValidators();
    }
    vat.updateValueAndValidity();
  }

  changeToUpper(value: string) {
    let chassisNo = value.toUpperCase();
    this.additionalInfo.patchValue({ chassisNo: chassisNo });
  }


  getAgentAuthDtls() {
    let param = {
      "groupCode": this.userFilter.CUST_GROUP_CODE,
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "agentCode": this.agentCode
    };
    this.agentService.getAgentAuthDtls(param)
      .subscribe(result => {
        this.agentAuthDetails = result;
        if (result.DED_ENABLE == "1")
          this.isDetEnable = true;
        if (result.DISC_ENABLE == '1')
          this.isDisEnable = true;
        if (result.LOAD_ENABLE == "1")
          this.isLoadEnable = true;
        if (result.FEES_ENABLE)
          this.isFeeEnable = true
        if (result.DRV_ENABLE == "1")
          this.driverEnable = true;

        this.enableDMSUpload = result.DMS_ENABLE_YN;
      }, error => {

      })
  }

  getCountryList() {
    let param = { "type": "COUNTRY" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.manfCountry) {
            array.push(object);
            /* this.additionalInfo.patchValue({
               countryArr:array
             });*/
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("countryArr").value === '') {
          let obj = { id: '', text: '' };
          array.push(obj)
          /*  this.additionalInfo.patchValue({
              countryArr:array
           });*/
        }
        this.countryList = arr;
      });
  }

  getRelationList() {
    let param = { "type": "RELATION" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.relationList = arr;
      });
  }

  getWeightList() {
    let param = { "type": "WEIGHT" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.vehWeight) {
            array.push(object);
            this.additionalInfo.patchValue({
              weightArr: array
            });
          }
          arr.push(object);
        }
        if (this.additionalInfo.get("weightArr").value === '') {
          // let obj = { id: '', text: '' };
          // array.push(obj)
          this.additionalInfo.patchValue({
            weightArr: array || ''
          });
        }
        this.weightList = arr;
      });

  }



  getDiscDedLoadFeesSumm() {
    var summArr = ["DISC", "LOAD", "DED", "FEES", "TAX"];
    var k = 0;
    for (var i = 0; i < summArr.length; i++) {
      var type = summArr[i];
      let param = { "transId": this.transId, "tranSrNo": this.tranSrNo, "type": type };
      this.agentService.getDiscDedLoadFeesSumm(param)
        .subscribe(response => {
          //var arr=["DISC","LOAD","DED","FEES"];    
          if (response["othersArray"] != "" && response["othersArray"] != null && response["othersArray"] != undefined) {
            var data = response["othersArray"];
            if (type == "DISC") {
              for (k = 0; k < data.length; k++) {
                this.discounts.push(data[k]);
              }
            } else if (type == "LOAD") {
              for (k = 0; k < data.length; k++) {
                this.loading.push(data[k]);
              }
            } else if (type == "DED") {
              for (k = 0; k < data.length; k++) {
                this.deductables.push(data[k]);
              }
            } else if (type == "FEES") {
              for (k = 0; k < data.length; k++) {
                this.fees.push(data[k]);
              }
            } else if (type == "TAX") {
              for (k = 0; k < data.length; k++) {
                this.tax.push(data[k]);
              }
            }
          }
          this.getNetPremium();
        });
    }
  }
  getCoverSummary() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getCoverSummary(param)
      .subscribe(response => {
        var array = response["coversArray"];
        let j = 0;
        for (var i = 0; i < array.length; i++) {
          if (array[i].type == 'I' || array[i].type == 'M') {
            if (array[i].type == 'I') {
              array[i].premium = 'Inclusive';
              this.sumInclusiveMandatory.push(array[i]);
            } else {
              if (array[i].premium > 0) {
                this.sumInclusiveMandatory.splice(j, 0, array[i]);
              }
              j++;
            }
          }
        }
      });
  }

  getNetPremium() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getNetPremium(param)
      .subscribe(response => {
        this.agentCommisionValue = response.AGENT_FC;
        this.agentCommissionPercent = response.AGENT_PERCENT;
        this.agentCommissionTax = response.QPI_ACOMM_TAX;
        this.netPremium = response.PREMIUM;

      });
  }
  getHeaderInformation() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getHeaderInformation(param)
      .subscribe(data => {
        this.civilId = data.CIVILID;
        this.quoteNo = data.REFNO;
        this.polStartDate = data.POLSTARTDATE;
        this.polEndDate = data.POLENDDATE;
        this.makeDesc = data.MAKEDESC;
        this.modelDesc = data.MODELDESC;
        this.sumInsured = data.SUMINSURED;
        this.insName = data.INSUREDNAME;
        this.currencyCode = data.QPI_CURRENCY;
        this.policyIssueDate = data.ISSUEDATE;
      });
  }



  getGenderList() {
    let param = { "paraType": "GENDER" };
    this.agentService.getApplParam(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appParamsArray.length; i++) {
          let id = result.appParamsArray[i].code;
          let text = result.appParamsArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.gender) {
            // array.push(object);
            this.additionalInfo.patchValue({
              genderArr: id || ''
            });
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("genderArr").value === '') {
          // let obj = { id: '', text: '' };
          // array.push(obj)
          this.additionalInfo.patchValue({
            genderArr: ''
          });
        }
        this.genderList = arr;
      });
  }
  getOccupationList() {
    let param = { "type": "OCCUPATION" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.occupation) {
            // array.push(object);
            this.additionalInfo.patchValue({
              occupationArr: id || ''
            });
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("occupationArr").value === '') {
          // let obj = { id: '', text: '' };
          // array.push(obj)
          this.additionalInfo.patchValue({
            occupationArr: ''
          });
        }
        this.occupationList = arr;
      });
  }

  getPlateTypeList() {
    this.agentService.getApplicationRefCodes('PLATE_CHAR', '002').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.plateList = tmpArr;
    });
  }

  getvehiclePlateTypeList() {
    this.agentService.getApplicationCodes('MOT_PLAT_TYP').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.vehPlateList = tmpArr;
    });
  }

  getBankList() {
    let param = { "type": "BANK" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.financedBank) {
            array.push(object);
            /*  this.additionalInfo.patchValue({
                financedBankArr:array,
                 financedYn:'1'
              });*/
            this.is_disabled = null;
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("financedBankArr").value === '') {
          let obj = { id: '', text: '' };
          array.push(obj)
          /* this.additionalInfo.patchValue({
            financedBankArr:array,
             financedYn:'0'
          });*/
        }
        this.bankList = arr;
      });
  }


  getColorList() {
    let param = { "type": "MOT_VEH_COL" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.basicinfo.vehColor) {
            array.push(object);
            this.additionalInfo.patchValue({
              colorArr: array || ''
            });
          }
          arr.push(object);

        }
        if (this.additionalInfo.get("colorArr").value === '') {
          let obj = { id: '', text: '' };
          array.push(obj)
          this.additionalInfo.patchValue({
            colorArr: array || ''
          });
        }
        this.colorList = arr;
      });
  }


  getCityList() {
    let param = { "type": "STATE", "refCode": "002" };
    this.agentService.getVehicleModel(param)
      .subscribe(result => {
        let arr = [];
        let array = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          if (id == this.city) {
            array.push(object);
            /*  this.additionalInfo.patchValue({
                 cityArr:array
              });*/
          }
          arr.push(object);

        }
        /*  if( this.additionalInfo.get("cityArr").value === ''){      
                          let obj = { id: '', text: '' };
                          array.push(obj)
                          this.additionalInfo.patchValue({
                            cityArr:array
                         });
          }*/

        this.cityList = arr;
      });
  }

  onClickSubmit(mode: string) {

    if (this.additionalInfo.valid) {
      this.spinnerService.isBusy = true;
      //this.edataChassisNoValidation(this.basicinfo.chassisNo);
      this.validateChassisNo(this.basicinfo.chassisNo);
      this.validateChassisNoPkg(this.basicinfo.chassisNo);
      let postData = {
        transId: this.transId,
        tranSrNo: this.tranSrNo,
        chassisNo: this.additionalInfo.get("chassisNo").value
      }
      this.agentService.checkChassisNoEditWhileChassiflow(postData)
        .subscribe(result => {
          if (result.validYN) {
            this.chassiErr = result.validYN;
            this.showChasisError = true
          } else {
            this.validChassisNo = false;
            this.spinnerService.isBusy = false;
            this.callRecalcularProcedure();
            this.basicinfo = this.additionalInfo.value;
            if (this.basicinfo.colorArr != null)
              this.basicinfo.vehColor = this.basicinfo.colorArr[0].id;
            this.basicinfo.manfCountry = this.basicinfo.countryArr;
            this.basicinfo.vehWeight = this.basicinfo.weightArr[0].id;
            this.basicinfo.city = this.basicinfo.cityArr;
            if (this.basicinfo.financedBankArr != null)
              this.basicinfo.financedBank = this.basicinfo.financedBankArr;

            //  if( this.basicinfo.occupationArr != null)
            this.basicinfo.occupation = this.basicinfo.occupationArr; //[0].id;
            //  if( this.basicinfo.genderArr !=null)
            this.basicinfo.gender = this.basicinfo.genderArr; // [0].id;
            this.basicinfo.mapId = "MOT_AGENT_POL_SCR_2";
            this.basicinfo.transId = this.transId;
            this.basicinfo.tranSrNo = this.tranSrNo;
            this.basicinfo.lobCode = "01";

            this.agentService.updateInsuredInfo(this.basicinfo).subscribe(updateInfoResult => {

              this.basicinfo.mapId = "MOT_AGENT_RISK_SCR_2";
              this.agentService.updateVehicleInfo(this.basicinfo).subscribe(updateVehicleInfo => {
                if (!this.validChassisNo) {
                  let param = {
                    "transId": this.transId,
                    "tranSrNo": this.tranSrNo,
                    "errMessage": this.errorMsg,
                    "quoteNo": this.quoteNo
                  };
                  this.agentService.insertErrorMsg(param).subscribe(response => {
                    let obj = {
                      "transId": this.transId,
                      "tranSrNo": this.tranSrNo,
                      "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
                    };
                    this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

                  });
                }
                if (this.basicinfo.driverList != null && this.basicinfo.driverList.length > 0) {
                  for (var i = 0; i < this.basicinfo.driverList.length; i++) {
                    this.basicinfo.driverList[i].transId = this.transId;
                    this.basicinfo.driverList[i].tranSrNo = this.tranSrNo;
                  }
                  this.agentService.insertAdditionalDriverInfo(this.basicinfo.driverList).subscribe(updateVehicleInfo => {
                   /*  if(mode == 'approve'){
                    this.basicinfo.userId=this.userId;
                    this.basicinfo.lobCode=this.lobCode;
                    this.basicinfo.mode=mode;
                    this.agentService.approveAgentPolicy(this.basicinfo).subscribe(response =>{   
                      let obj={
                       "transId":this.transId,
                       "tranSrNo":this.tranSrNo,
                       "mode":mode
                      };
                      this.router.navigate(['quote-confirm'], { queryParams: obj});
                      },error =>{
                        let obj={
                          "transId": this.transId,
                          "tranSrNo": this.tranSrNo,
                          "quoteNo":this.quoteNo,
                          "errorMsg":JSON.parse(error["_body"]).errMessage
                        };
                        this.router.navigate(['refferal-page'], { queryParams: obj});
                      });
                    }*/ if ('back' === mode) {
                      this.getSchemePage();
                    }
                    else {
                      this.callRecalcularProcedure();
                      let obj = {
                        "transId": this.transId,
                        "tranSrNo": this.tranSrNo,
                        "lobCode": this.lobCode,
                        "mode": mode,
                        "quoteNo": this.quoteNo,
                        "instYN": this.instYN,
                        policyNo: this.policyNo
                      };
                      this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
                    }
                  });
                } else {
                 /* if(mode == 'approve'){
                  this.basicinfo.userId=this.userId;
                  this.basicinfo.lobCode=this.lobCode;
                  this.basicinfo.mode=mode;
                    this.agentService.approveAgentPolicy(this.basicinfo).subscribe(response =>{              
                      let obj={
                        "transId":this.transId,
                        "tranSrNo":this.tranSrNo,
                        "mode":mode
                       };
                       this.router.navigate(['quote-confirm'], { queryParams: obj});

                  },error =>{
                    let obj={
                      "transId": this.transId,
                      "tranSrNo": this.tranSrNo,
                      "quoteNo":this.quoteNo,
                      "errorMsg":JSON.parse(error["_body"]).errMessage
                    };
                    this.router.navigate(['refferal-page'], { queryParams: obj})
                  });
                  }else*/if ('back' === mode) {
                    this.getSchemePage();
                  } else {
                    this.callRecalcularProcedure();
                    let obj = {
                      "transId": this.transId,
                      "tranSrNo": this.tranSrNo,
                      "lobCode": this.lobCode,
                      "mode": mode,
                      "quoteNo": this.quoteNo,
                      "instYN": this.instYN,
                      policyNo: this.policyNo
                    };
                    this.router.navigate(['summary'], { queryParams: obj, skipLocationChange: true });
                  }
                }
              });

            });
          }
        }, error => {
          this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: error.error.errMessage });
          this.spinnerService.isBusy = false;
        });

    } else {
      this.validateAllFormFields(this.additionalInfo);
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  getDocumentCodeBeforeUpload(event) {
    if (event == "emiratesId") {
      this.docCodeValue = "004";
    } else if (event == "vehRegistration") {
      this.docCodeValue = "008";
    } else if (event == "drivingLicense") {
      this.docCodeValue = "007";
    }
  }

  uploadPicture(event: any) {

    this.getDocumentCodeBeforeUpload(event.target.id);
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
      var reader = new FileReader();
      var that = this;
      reader.onload = function () {

        that.upload(event);
      }
      reader.readAsDataURL(fileList[0]);
    }

  }



  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('lobCode', this.lobCode);
    formData.append('docCode', this.docCodeValue);
    formData.append('docType', "POL");
    formData.append('userId', this.userId);
    var uploadDocumentReponse = this.commonService.uploadDocuments(formData);

  }

  getSchemePage() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "lobCode": this.lobCode,
      "quoteNo": this.quoteNo,
      policyNo: this.policyNo
    };
    this.router.navigate(['scheme'], { queryParams: obj, skipLocationChange: true });
  }

  loadAgentDoc(reportType) {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=800,height=200,left=100%,top=100%`;
    var winRef = window.open('/viewdocument?transId=' + this.transId + '&reportType=' + reportType, 'Product Category', param);
  }

  getReport(type) {
    this.commonService.getReport(this.transId, this.tranSrNo, type, this.session.get("portaltype"), "", "", "");
  }
  callRecalcularProcedure() {
    let params = {
      'transId': this.transId,
      'tranSrNo': this.tranSrNo,
      'agentId': this.session.get('agent')
    }
    this.agentService.getRecalculte(params).subscribe(result => {
      this.spinnerService.isBusy = false;
    }, error => {
      let errorMsglet = error.error.errMessage;
      let obj = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "quoteNo": this.quoteNo,
        "errorMsg": errorMsglet
      };
      this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

    });
  }
}

