import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalInfoScreenComponent } from './additional-info-screen.component';

describe('AdditionalInfoScreenComponent', () => {
  let component: AdditionalInfoScreenComponent;
  let fixture: ComponentFixture<AdditionalInfoScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalInfoScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalInfoScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
