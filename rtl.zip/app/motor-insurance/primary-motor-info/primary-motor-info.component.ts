import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { IAngularMyDpOptions } from 'angular-mydatepicker';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { timer } from 'rxjs';
import { ApplicationConstants } from 'src/shared/application-constants';
import { ErrorMessage } from "../../../shared/error-message";
import { LoaderService } from '../../../shared/loader-service/loader.service';
import { AgentUserService } from "../../../shared/services/agent-user.service";
import { Tooltip } from "../../../shared/tool-tip";
import { AgentHttpclientService } from "../../services/agent-httpclient.service";
import { PrimaryInfo } from '../classes/primary-info';
import { ECalendarValue } from 'ng2-date-picker';
@Component({
  selector: 'app-primary-motor-info',
  templateUrl: './primary-motor-info.component.html',
  styleUrls: ['./primary-motor-info.component.scss'],
  providers: [NgbModalConfig, NgbModal]
})
export class PrimaryMotorInfoComponent {
  sumInsuredRange: any;

  public invalidMoment = new Date();
  public min: Date;
  public max: Date;
  //ToolTip
  public tooltipMessgae = new Tooltip();

  //Error Message
  public Err_msg = new ErrorMessage();

  primaryInfo: UntypedFormGroup;
  public makeList: Array<any>;
  public modelList: Array<any>;
  public vehicleTypeList: Array<any>;
  public vehUsageList: Array<any>;
  public cylinderList: Array<any>;
  public geoAreaList: Array<any>;
  public yearArray: any = [];
  public regnLocList: Array<any>;
  public nationalityList: Array<any>;
  public countryList: Array<any>;
  public importCountryList: Array<any>;
  bodyTypeList: any;
  noClaimOptions: any[];
  selfDeclarationsOptions: any[];

  @ViewChild('content') public templateref: ElementRef;
  selectedValue: string;
  dob: any;
  titleAlert: string = 'This field is required';
  ip: any = '';
  basicInfo: PrimaryInfo;
  quoteNo: any;
  date: Date = new Date();
  settings = {
    bigBanner: false,
    timePicker: false,
    format: 'dd-MM-yyyy hh:mm',
    defaultOpen: false
  }
  civilIdPatternError: string;
  eflag: string;
  edataError: string = null;
  public edataFlag: boolean = false;
  updateFlag: boolean = false;
  //session parameter
  currentYear: any;
  userId: string = this.session.get("username");
  agentRoleId: string = this.session.get("USER_ROLE_ID");
  agentCode: string = this.session.get("agent");
  divisionCode: string = this.session.get("divisionCode");
  departCode: string = this.session.get("departmentCode");
  userType: string = this.session.get("usertype");
  portalType: string = this.session.get("portaltype");
  companyCode: string = this.session.get("companyCode");
  lobCode: string = '01';
  duration: any;
  public transId: any;
  tranSrNo: any;
  editYn: any;
  sumAssured: any;
  //public mode:string;
  public installAccess: string = this.session.get("installAccess");
  groupCode: string = this.session.get("groupCode");
  userFilter: any = this.session.get("userFilter");

  //
  endType: string;
  disableFields: boolean = false;
  public modifyFromDate: boolean = false;
  public modifyToDate: boolean = false;
  public placeholder: string = 'DD/MM/YYYY';
  public myDatePickerOptions: IAngularMyDpOptions = {
    // indicateInvalidDate: true,
    // showInputField: true,
    // showTodayBtn: false,
    showSelectorArrow: false,
    openSelectorTopOfInput: false,
    selectorWidth: "312px",
    dateFormat: 'dd/mm/yyyy',
    disableSince: {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate() + 1
    }
  };

  myOptions = {
    'placement': 'top',
    'show-delay': 500
  }
  isEndorsement = false;
  policyNo: any;
  withoutChassisNoFlag: boolean = false;
  withoutChesis: any;
  // sumInsuredRange: any;

  
  material = true;
  ng2datePickerConfig: any = {
    firstDayOfWeek: 'su',
    monthFormat: 'MMM, YYYY',
    disableKeypress: false,
    allowMultiSelect: false,
    closeOnSelect: true,
    closeOnSelectDelay: 0,
    openOnFocus: true,
    openOnClick: true,
    onOpenDelay: 0,
    closeOnEnter: true,
    weekDayFormat: 'ddd',
    appendTo: document.body,
    showNearMonthDays: true,
    showWeekNumbers: false,
    enableMonthSelector: true,
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    dayBtnFormat: 'DD',
    monthBtnFormat: 'MMM',
    hours12Format: 'hh',
    hours24Format: 'HH',
    meridiemFormat: 'A',
    minutesFormat: 'mm',
    minutesInterval: 1,
    secondsFormat: 'ss',
    secondsInterval: 1,
    showSeconds: false,
    showTwentyFourHours: true,
    timeSeparator: ':',
    multipleYearsNavigateBy: 10,
    showMultipleYearsNavigation: false,
    locale: moment.locale(),
    hideInputContainer: false,
    returnedValueType: ECalendarValue.Moment,
    unSelectOnClick: true,
    hideOnOutsideClick: true,
    numOfMonthRows: 3,
    format: 'DD/MM/YYYY'
  };
  updateEndDate(event) {
    var endDate = new Date(event);
    var year = endDate.getFullYear();
    var month = endDate.getMonth();
    var day = endDate.getDate();
    //----
    var hour = 0, minute = 0;
    if (day == new Date().getDate() && month == new Date().getMonth() && year == new Date().getFullYear()) {
      hour = new Date().getHours();
      minute = new Date().getMinutes();
    }
    let startDate = new Date(year, month, day, hour, minute);
    this.primaryInfo.patchValue({ polStartDate: startDate })
    //----
    //var toDate = new Date(year, month + 13, day - 1, 23, 59);
    var toDate = new Date(year, (month) + Number(this.duration), day - 1, 23, 59);
    this.primaryInfo.patchValue({ polEndDate: toDate })
  }


  constructor(
    private router: Router,
    public config: NgbModalConfig,
    private fb: UntypedFormBuilder,
    private loadingService: LoaderService,
    private activatedRoute: ActivatedRoute,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private messageService: MessageService,
    private agentService: AgentHttpclientService,
  ) {
    this.currentYear = new Date().getFullYear();
    config.backdrop = 'static';
    config.keyboard = false;
    var fullyear = new Date().getFullYear() + 1
    var lastone = +fullyear
      .toString()
      .split("")
      .pop();
    this.primaryInfo = this.fb.group({
      companyYn: ['', Validators.required],
      insName: ['', Validators.required],
      emailId: [''],
      civilId: ['', Validators.required],
      mobileNo: ['', Validators.compose([Validators.required, Validators.pattern(/(^5\d{8}$|^(05)\d{8}$)/)])],
      telephoneNo: '',
      polStartDate: [null, Validators.required],
      polEndDate: '',
      transRemark: '',
      interest: '',
      // veh_info: this.fb.group({
      makeArr: ['', Validators.required],
      modelArr: ['', Validators.required],
      manfYear: [this.currentYear, Validators.compose([Validators.required, Validators.pattern("^(1999|200[0-9]|201[0-9]|202[0-" + lastone + "])$")])],
      sumAssured: ['', Validators.required],
      bodyTypeArr: ['', Validators.required],
      vehUsageArr: ['', Validators.required],
      vehCylinders: ['', Validators.required],
      regnLoc: ['', Validators.required],
      seatingCty: ['', Validators.required],
      psgrLiabSeatCty: ['', Validators.required],
      // orgVehicleValue:['',Validators.required],
      firstRegDate: ['', Validators.required],
      driverAge: '',
      driverDob: ['', Validators.required],
      insDob: '',
      previousInsuranceValid: '',
      totalLoss: '',
      gccSpecYN: '',
      nationalityArr: '',
      promoCode: '',
      instYN: '',
      noClaimYear: '',
      selfDeclarationYear: '',
      isFirstTimeReg: '',
      isVehImported: '',
      importCountry: '',
      importCountryArr: '',
      mileage: ''
      //driverDob:[null, Validators.required],

    });
    //  });
  }

  ngOnInit() {

    //this.loaderService.isBusy = false;
    this.loadingService.isBusy = true;
    if (this.session.get('companyCode') == null) {
      this.session.set("companyCode", "002");
    }
    this.transId = this.commonService.getParamValue('transId');//this.route.snapshot.paramMap.get('transId')//"1397780"//"1397225";
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.sumAssured = this.commonService.getParamValue('sumAssured');
    this.endType = this.commonService.getParamValue('endType');
    this.edataFlag = this.commonService.getParamValue('edataFlag');
    this.edataError = this.commonService.getParamValue('edataError');
    this.withoutChassisNoFlag = this.commonService.getParamValue('withoutChassisNoFlag');
    this.editYn = this.commonService.getParamValue('editYn');
    if (this.withoutChassisNoFlag) {
      const admeId = this.commonService.getParamValue('admeId');
      if (admeId == "") {
        timer(1000).subscribe(val => this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: "Vehicle specification not found" }));
      }
      this.withoutChesis = {
        vehMake: this.commonService.getParamValue('vehMake'),
        vehModel: this.commonService.getParamValue('vehModel'),
        vehModelYear: this.commonService.getParamValue('modelYear'),
        vehicleValue: this.commonService.getParamValue('vehicleValue'),
        bodyType: this.commonService.getParamValue('bodyType'),
        vehCylinders: this.commonService.getParamValue('cylinders'),
        seatingCty: this.commonService.getParamValue('seats'),
        sumAssured: this.commonService.getParamValue('vehicleValue')
      }
    }
    this.policyNo = this.commonService.getParamValue('policyNo');
    if (this.policyNo) {
      this.isEndorsement = true;
    }
    const chassisErrMessage = this.commonService.getParamValue('errMessage');
    const chasMessage = this.commonService.getParamValue('errMsg');
    if (chassisErrMessage) {
      timer(2000).subscribe(val => this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: chassisErrMessage }));
    }
    if (chasMessage) {
      timer(2000).subscribe(val => this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: chasMessage }));
    }
    if (this.transId != null && this.transId != undefined) {
      this.edataFlag = true;
    }
    if (this.transId != null && this.transId != undefined) {
      let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
      this.agentService.getHeaderInformation(param)
        .subscribe(data => {
          this.getSumInsuredRange();
          //this.getVehicleDetails();

          this.quoteNo = data.REFNO;
          this.primaryInfo.patchValue({
            sumAssured: ''
          });

        });
    } else {
      this.edataFlag = false;
    }

    // this.mode=this.agentService.getParamValue('mode');
    this.quoteNo = this.commonService.getParamValue('quoteNo');
    // alert(this.quoteNo);

    if (this.tranSrNo > 0) {
      this.disableFields = true;
    }
    // this.loadingService.isBusy = true;
    this.dropDownService();
    this.getPolicyDuration();
    this.getAgentFilterInfo();
    this.commonService.getIPAddress().subscribe(data => {
      this.ip = data.ip;
    });

    this.activatedRoute.queryParams.subscribe((params: any) => {
      if (params.insType == "thirdParty") {
        this.primaryInfo.controls['sumAssured'].disable();
      }
    });
  }
  /*getVehicleDetails() {
    let param = { "transactionId": this.transId, "transactionSrNo": this.tranSrNo };
    this.agentService.getAutoDataRiskDetails(param).
      subscribe(response => {
      }, error => {
        this.sumInsuredRange = "";
      });
  }**/
  getSumInsuredRange() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.getSumInsuredRange(param).
      subscribe(response => {
        this.sumInsuredRange = response.desc;
      }, error => {
        this.sumInsuredRange = "";
      });
  }
  getAgentFilterInfo() {
    let obj = {
      "userRoleId": this.session.get('USER_ROLE_ID'),
      "lobCode": '01'
    };
    this.agentService.getAgentFilterInfo(obj).subscribe(data => {
      this.modifyFromDate = ('0' === data.UAU_FM_DATE_MODIFY_YN);
      this.modifyToDate = ('0' === data.UAU_TO_DATE_MODIFY_YN);
      //backDate Validation

      var backDate = data.UAU_MAX_BACK_DATE_DAYS;
      var futureDate = data.UAU_MAX_FUTURE_DATE_DAYS;
      var years = this.invalidMoment.getFullYear();
      var month = this.invalidMoment.getMonth();
      var days = this.invalidMoment.getDate();
      this.min = new Date(years, month, days - backDate, 23, 59);
      this.max = new Date(years, month, days + futureDate, 23, 59);
    });
  }

  cancelEndorsement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }

  backService() {

    if (this.transId != null && this.transId != undefined) {
      this.loadingService.isBusy = true;
      let obj = {
        "transId": this.transId,
        "tranSrNo": this.tranSrNo,
        "mapId": "MOT_AGENT_POL_SCR_1"
      };
      this.agentService.getInsuredInfo(obj).subscribe(data => {
        if (data.respCode == "2000") {
          this.primaryInfo.patchValue({
            polStartDate: moment(data.polStartDate, 'DD/MM/YYYY HH:mm').toISOString(),
            polEndDate: moment(data.polEndDate, 'DD/MM/YYYY HH:mm').toISOString(),
            insName: data.insName,
            civilId: data.civilId,
            mobileNo: data.mobileNo,
            telephoneNo: data.telephoneNo,
            emailId: data.emailId,
            transRemark: data.transRemark,
            interest: data.interest,
            nationalityArr: (data.nationality) || '',
            companyYn: (data.companyYn) || '',
            noClaimYear: (data.noClaimYear) || '',
            selfDeclarationYear: (data.selfDeclarationYear) || ''
          });
          //this.primaryInfo.valid

          // this.validateAllFormFields(this.primaryInfo)
          this.changeValidation(data.companyYn);
          // if (this.tranSrNo == 0)
          // this.setDate();
          if (this.transId != null && this.transId != undefined) {
            this.getVehicleInfo(this.transId, this.tranSrNo);
          }
          var today = moment(new Date(), 'DD/MM/YYYY HH:mm');
          let convertedFromDate1 = new Date(
            moment(data.polStartDate, 'DD/MM/YYYY').year(),
            moment(data.polStartDate, 'DD/MM/YYYY').month(),
            moment(data.polStartDate, 'DD/MM/YYYY').date()
          );
          let convertedDate2 = new Date(
            moment(today, 'DD/MM/YYYY').year(),
            moment(today, 'DD/MM/YYYY').month(),
            moment(today, 'DD/MM/YYYY').date()
          );
          if (this.editYn === "1" && convertedFromDate1 < convertedDate2) {
            this.primaryInfo.patchValue({
              polStartDate: moment(new Date(), 'DD/MM/YYYY HH:mm').toISOString(),
            });
            this.updateEndDate(new Date());
          }
        }
      }, error => {

      });
    }
  }
  onChange(event) {
    let data = event.target.value;
    this.changeValidation(data);
  }
  dropDownService() {
    this.loadingService.isBusy = true;
    this.getVehicleMake();
    this.getSelfDeclaraionDiscountData();
    this.getNoClaimDiscountData();
    this.getImportCountryList();
    //this.getVehicleType();
    //this.getCylinderList();
    //this.getGeoAreaList();
    //this.getRegLocationList();
    //this.getNationalityList();

  }



  getImportCountryList() {

    this.agentService.getApplicationCountryCodes('COUNTRY').subscribe(data => {
      const tmpArr = data.appCodesArray.reverse();
      this.importCountryList = tmpArr;
    })
  }

  getVehicleMake() {
    this.loadingService.isBusy = true;
    let v_make = {
      "makeFliterYn": this.userFilter.CUST_MAKE_FILTER_YN,
      "groupCode": this.userFilter.CUST_GROUP_CODE
    };
    this.agentService.getVehicleMake(v_make)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.makeArray.length; i++) {
          let id = result.makeArray[i].MAKECODE;
          let text = result.makeArray[i].MAKEDESC;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.makeList = arr;

        let v_type = { "userId": "online" };
        this.agentService.getVehicleType(v_type)
          .subscribe(result => {
            let arr = [];
            this.bodyTypeList = result.typeArray;
            for (let i = 0; i < result.typeArray.length; i++) {
              let id = result.typeArray[i].VEHTYPECODE;
              let text = result.typeArray[i].VEHTYPEDESC;
              let object = { id: id, text: text };
              arr.push(object);

            }
            this.vehicleTypeList = arr;
            let v_cylinder = { "type": "MOT_VEH_NOC" };
            this.agentService.getCylinderList(v_cylinder)
              .subscribe(result => {
                let arr = [];
                for (let i = 0; i < result.appCodesArray.length; i++) {
                  let id = result.appCodesArray[i].code;
                  let text = result.appCodesArray[i].desc;
                  let object = { id: id, text: text };
                  arr.push(object);

                }
                this.cylinderList = arr;
                let v_geoArea = { "type": "AREA" };
                this.agentService.getGeoList(v_geoArea)
                  .subscribe(result => {
                    let arr = [];
                    for (let i = 0; i < result.appCodesArray.length; i++) {
                      let id = result.appCodesArray[i].code;
                      let text = result.appCodesArray[i].desc;
                      let object = { id: id, text: text };
                      arr.push(object);

                    }
                    this.geoAreaList = arr;
                    let v_regLoc = { "type": "REGN_LOC" };
                    this.agentService.getGeoList(v_regLoc)
                      .subscribe(result => {
                        let arr = [];
                        for (let i = 0; i < result.appCodesArray.length; i++) {
                          let id = result.appCodesArray[i].code;
                          let text = result.appCodesArray[i].desc;
                          let object = { id: id, text: text };
                          arr.push(object);

                        }
                        this.regnLocList = arr;

                        let v_nationality = { "type": "NATIONALITY" };
                        this.agentService.getGeoList(v_nationality)
                          .subscribe(result => {
                            let arr = [];
                            for (let i = 0; i < result.appCodesArray.length; i++) {
                              let id = result.appCodesArray[i].code;
                              let text = result.appCodesArray[i].desc;
                              let object = { id: id, text: text };
                              arr.push(object);

                            }
                            this.nationalityList = arr;
                            if (this.transId == '' || this.transId == null)
                              this.setDate();
                            let year = new Date().getFullYear();
                            for (let i = year; i > (year - 5); i--) {
                              this.yearArray.push(i);
                            }
                            //          if(!this.edataFlag){
                            this.loadingService.isBusy = false;
                            //      this.modalService.open( this.templateref, { size: 'lg' });
                            // }

                            this.backService();

                          });
                      });
                  });

              });

          });
      });
  }
  getModelList(event) {
    this.loadingService.isBusy = true;
    let make_var = event.id;
    let v_model = { "type": "MOT_VEH_MOD", "refCode": make_var };
    this.agentService.getVehicleModel(v_model)
      .subscribe(result => {
        let arr = [];
        for (let i = 0; i < result.appCodesArray.length; i++) {
          let id = result.appCodesArray[i].code;
          let text = result.appCodesArray[i].desc;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.modelList = arr;
        this.loadingService.isBusy = false;
      });
  }


  // getVehicleType(){
  //   let v_type = { "userId": "online"};
  //   this.agentService.getVehicleType(v_type)
  //     .subscribe(result => {
  //       let arr = [];         
  //       for (let i = 0; i < result.typeArray.length; i++) {
  //         let id = result.typeArray[i].VEHTYPECODE;        
  //         let text = result.typeArray[i].VEHTYPEDESC;
  //         let object = { id: id, text: text };
  //         arr.push(object);

  //       }     
  //       this.vehicleTypeList = arr;
  //     });
  // }

  removeList(mode: string) {
    var array = [];
    this.primaryInfo.get(mode).setValue(array);

  }

  getUsageList(event) {
    let vehType_var = event.id;
    let v_usage = { "vehType": vehType_var };
    this.agentService.getUsageList(v_usage)
      .subscribe((result: any) => {
        let arr = [];
        for (let i = 0; i < result.usageArray.length; i++) {
          let id = result.usageArray[i].USAGECODE;
          let text = result.usageArray[i].USAGEDESC;
          let object = { id: id, text: text };
          arr.push(object);

        }
        this.vehUsageList = arr;
      });
  }

  getNoClaimDiscountData() {

    this.commonService.getStaticDropdownValues('NC_DISC_PERC')
      .subscribe((res: any) => {
        this.noClaimOptions = res.appParameterInfo;
      }, (err) => {
        // Error Handle
      });
  }

  getSelfDeclaraionDiscountData() {
    this.commonService.getStaticDropdownValues('SELF_DEC_PER')
      .subscribe((res: any) => {
        this.selfDeclarationsOptions = res.appParameterInfo;
      }, (err) => {
        // Error Handle
      });
  }

  // getCylinderList(){
  //   let v_cylinder={"type": "MOT_VEH_NOC"};
  //   this.agentService.getCylinderList(v_cylinder)
  //   .subscribe(result => {      
  //     let arr = [];         
  //     for (let i = 0; i < result.appCodesArray.length; i++) {
  //       let id = result.appCodesArray[i].code;        
  //       let text = result.appCodesArray[i].desc;
  //       let object = { id: id, text: text };
  //       arr.push(object);

  //     }    
  //     this.cylinderList = arr;
  //   });
  // }
  // getGeoAreaList(){
  //   let v_geoArea={"type": "AREA"};
  //   this.agentService.getGeoList(v_geoArea)
  //   .subscribe(result => {
  //     let arr = [];         
  //     for (let i = 0; i < result.appCodesArray.length; i++) {
  //       let id = result.appCodesArray[i].code;        
  //       let text = result.appCodesArray[i].desc;
  //       let object = { id: id, text: text };
  //       arr.push(object);

  //     }    
  //     this.geoAreaList = arr;
  //   });
  // }

  // getRegLocationList(){
  //   let v_regLoc={"type": "REGN_LOC"};
  //   this.agentService.getGeoList(v_regLoc)
  //   .subscribe(result => {
  //     let arr = [];         
  //     for (let i = 0; i < result.appCodesArray.length; i++) {
  //       let id = result.appCodesArray[i].code;        
  //       let text = result.appCodesArray[i].desc;
  //       let object = { id: id, text: text };
  //       arr.push(object);

  //     }    
  //     this.regnLocList = arr;
  //   });
  // }

  // getNationalityList(){

  //      let v_nationality={"type": "NATIONALITY"};
  //      this.agentService.getGeoList(v_nationality)
  //      .subscribe(result => {
  //        let arr = [];         
  //        for (let i = 0; i < result.appCodesArray.length; i++) {
  //          let id = result.appCodesArray[i].code;        
  //          let text = result.appCodesArray[i].desc;
  //          let object = { id: id, text: text };
  //          arr.push(object);

  //        }    
  //        this.nationalityList = arr;
  //      });
  //    } 

  // getEdataInfo(chassisNo){
  //   if(chassisNo == ""){
  //        alert("Please Enter Chassis No");  
  //   }else{
  //     this.loaderService.isBusy = true;
  //        var param={
  //          "chassisNo":chassisNo,
  //          "companyCode":this.companyCode,
  //          "portal":this.portalType,
  //          "userId":this.userId,
  //          "ipAddress":this.ip
  //         };
  //         this.agentService.getEdataInfo(param)
  //         .subscribe(response => {   
  //          // this.loaderService.isBusy = false;         
  //           var erroMsg=response.errorMsg;
  //           if(erroMsg == null){
  //             this.getVehicleInfo(response.transId,response.tranSrNo);
  //           }else{
  //             this.modalService.dismissAll();
  //             this.edataError=erroMsg;
  //           }

  //         },error => {

  //         });
  //       }
  //        //{"chassisNo":"JN8FY1NY1GX013255","companyCode":"002","portal":"A","userId":"asif","ipAddress":"0:0:0:0:0:0:0:1"}
  // }

  getVehicleInfo(id, srNo) {
    //this.edataFlag=true;
    var param = {
      transId: id,
      tranSrNo: srNo,
      mapId: "MOT_AGENT_RISK_SCR_1"
    };

    this.agentService.getVehicleInfo(param)
      .subscribe(response => {
        this.basicInfo = response;
        if (this.withoutChassisNoFlag) {
          this.basicInfo.vehMake = this.withoutChesis.vehMake;
          this.basicInfo.vehModel = this.withoutChesis.vehModel;
          this.basicInfo.vehBodyType = this.withoutChesis.bodyType;
          this.basicInfo.manfYear = this.withoutChesis.vehModelYear;
          this.basicInfo.sumAssured = this.withoutChesis.vehicleValue;
          this.basicInfo.vehCylinders = this.withoutChesis.vehCylinders;
          this.basicInfo.seatingCty = this.withoutChesis.seatingCty;
        }

        let id = this.basicInfo.vehMake;
        let text;
        let arr = [];
        for (var i = 0; i < this.makeList.length; i++) {
          var a = this.makeList[i].id;
          if (id == a) {
            text = this.makeList[i].text;
          }
        }
        console.log(this.makeList)
        var object = { id: id, text: text };
        arr.push(object);
        this.basicInfo.makeArr = arr;

        let v_model = { "type": "MOT_VEH_MOD", "refCode": this.basicInfo.vehMake };
        this.agentService.getVehicleModel(v_model)
          .subscribe(result => {
            let arr1 = [];
            let arr2 = [];
            for (let i = 0; i < result.appCodesArray.length; i++) {
              let id = result.appCodesArray[i].code;

              let text = result.appCodesArray[i].desc;
              let object = { id: id, text: text };
              arr1.push(object);
              if (id == this.basicInfo.vehModel) {
                let modelDesc = result.appCodesArray[i].desc;
                let selectedObject = { id: id, text: modelDesc };
                arr2.push(selectedObject);
                this.basicInfo.modelArr = arr2;
              }

            }
            this.modelList = arr1;
            let id = this.basicInfo.vehBodyType;
            let arr = [];
            for (var i = 0; i < this.vehicleTypeList.length; i++) {
              let a = this.vehicleTypeList[i].id;
              if (a == id) {
                let text = this.vehicleTypeList[i].text;
                let object = { id: id, text: text };
                arr.push(object)
                this.basicInfo.bodyTypeArr = arr;
              }
            }

            let v_usage = { "vehType": this.basicInfo.vehBodyType };
            this.agentService.getUsageList(v_usage)
              .subscribe((result: any) => {

                let arr1 = [];
                let arr2 = [];
                for (let i = 0; i < result.usageArray.length; i++) {
                  let id = result.usageArray[i].USAGECODE;
                  let text = result.usageArray[i].USAGEDESC;
                  let object = { id: id, text: text };
                  arr2.push(object);

                  if (id == this.basicInfo.vehUsage) {
                    let id = result.usageArray[i].USAGECODE;
                    let usageDesc = result.usageArray[i].USAGEDESC;
                    let selectedObject = { id: id, text: usageDesc };
                    arr1.push(selectedObject);
                    this.basicInfo.vehUsageArr = arr1;
                  }
                }
                this.vehUsageList = arr2;
                // alert('this.basicInfo.sumAssured is**'+this.basicInfo.sumAssured);
                this.primaryInfo.patchValue({
                  manfYear: this.basicInfo.manfYear,
                  sumAssured: this.basicInfo.sumAssured,
                  vehBodyType: this.basicInfo.vehBodyType,
                  vehCylinders: this.basicInfo.vehCylinders,
                  makeArr: this.basicInfo.makeArr,
                  modelArr: this.basicInfo.modelArr,
                  bodyTypeArr: this.basicInfo.bodyTypeArr,
                  vehUsageArr: this.basicInfo.vehUsageArr,
                  seatingCty: this.basicInfo.seatingCty,
                  psgrLiabSeatCty: this.basicInfo.seatingCty,
                  regnLoc: this.basicInfo.regnLoc,
                  gccSpecYN: this.basicInfo.gccSpecYN,
                  previousInsuranceValid: (this.basicInfo.previousInsuranceValid) || '',
                  totalLoss: (this.basicInfo.totalLoss) || '',
                  promoCode: this.basicInfo.promoCode,
                  driverAge: this.basicInfo.driverAge,
                  isFirstTimeReg: this.basicInfo.isFirstTimeReg,
                  isVehImported: this.basicInfo.isVehImported,
                  importCountry: this.basicInfo.importCountry
                  // firstRegDate: moment(this.basicInfo.firstRegDate, 'DD/MM/YYYY HH:mm'),
                  //driverDob: moment(this.basicInfo.driverDob, 'DD/MM/YYYY HH:mm'),
                });
                if (this.basicInfo.sumAssured == '' || this.basicInfo.sumAssured == null || this.basicInfo.sumAssured == undefined) {
                  this.primaryInfo.patchValue({
                    sumAssured: this.sumAssured
                  });
                }

                if (this.basicInfo.firstRegDate) {
                  this.primaryInfo.patchValue({
                    firstRegDate: {
                      date: {
                        year: moment(this.basicInfo.firstRegDate, 'DD/MM/YYYY HH:mm').year(),
                        month: moment(this.basicInfo.firstRegDate, 'DD/MM/YYYY HH:mm').month() + 1,
                        day: moment(this.basicInfo.firstRegDate, 'DD/MM/YYYY HH:mm').date(),
                      }
                    }
                  })
                }
                if (this.basicInfo.driverDob) {
                  this.primaryInfo.patchValue({
                    driverDob: {
                      date: {
                        year: moment(this.basicInfo.driverDob, 'DD/MM/YYYY HH:mm').year(),
                        month: moment(this.basicInfo.driverDob, 'DD/MM/YYYY HH:mm').month() + 1,
                        day: moment(this.basicInfo.driverDob, 'DD/MM/YYYY HH:mm').date(),
                      }
                    },
                    insDob: this.basicInfo.driverDob.formatted,
                  })
                }
                this.loadingService.isBusy = false;
              });

          });
      });

  }

  updateValue(value: String): void {
    this.primaryInfo.patchValue({ psgrLiabSeatCty: value });
  }

  setDate(): void {
    // Set today date using the patchValue function
    var date = new Date();

    var today = new Date();
    var year = today.getFullYear();
    var month = today.getMonth();
    var day = today.getDate();
    var toDate = new Date(year + 1, month + 1, day - 1, 23, 59);
    this.primaryInfo.patchValue({
      polStartDate: new Date(), polEndDate: toDate

    });
  }

  onKey(value: string) {
    let a = value.replace(/[^0-9]/g, '')
    this.primaryInfo.patchValue({ sumAssured: a });
  }

  updateSumValue(value: string) {
    //this.primaryInfo.patchValue({orgVehicleValue: value});
  }

  // clearDate(): void {
  //     // Clear the date using the patchValue function
  //     this.primaryInfo.patchValue({driverDob: null});
  // }  

  onClickSubmit() {

    if (this.primaryInfo.valid) {
      this.loadingService.isBusy = true;
      if (this.primaryInfo.get("companyYn").value == "0") {
        this.primaryInfo.get("telephoneNo").setValue("");
      } /*else {
        this.primaryInfo.get("driverAge").setValue("");
      }*/
      this.basicInfo = this.primaryInfo.value;
      let dvDob = this.basicInfo.driverDob.date;
      let regDate = this.basicInfo.firstRegDate.date;
      //let polstart = moment(this.basicInfo.polStartDate).format('DD-MM-YYYY HH:mm')
      //let polEnd = moment(this.basicInfo.polEndDate).format('DD-MM-YYYY HH:mm')
      //this.carDetails.vehMakeDesc = this.carDetails["vehMake"][0].text
      this.basicInfo.vehMake = this.basicInfo.makeArr[0].id;
      this.basicInfo.vehModel = this.basicInfo.modelArr[0].id;
      this.basicInfo.vehBodyType = this.basicInfo.bodyTypeArr[0].id;
      this.basicInfo.vehUsage = this.basicInfo.vehUsageArr[0].id;

      this.basicInfo.driverDob = new Date(dvDob.year, dvDob.month - 1, dvDob.day);
      this.basicInfo.firstRegDate = new Date(regDate.year, regDate.month - 1, regDate.day);
      this.basicInfo.driverDob = moment(this.basicInfo.driverDob).format('DD/MM/YYYY 00:00');
      this.basicInfo.firstRegDate = moment(this.basicInfo.firstRegDate).format('DD/MM/YYYY 00:00');
      //this.basicInfo.insDob = moment(this.basicInfo.driverDob).format('DD/MM/YYYY'),
      this.basicInfo.firstRegYear = moment(this.basicInfo.firstRegDate, 'DD/MM/YYYY').year();
      this.basicInfo.insDob = moment(this.basicInfo.driverDob, 'DD/MM/YYYY').format('DD/MM/YYYY'),
        //this.basicInfo.insDob = this.basicInfo.driverDob.formatted,
        this.basicInfo.polStartDate = moment(this.basicInfo.polStartDate).format('DD/MM/YYYY HH:mm')
      this.basicInfo.polEndDate = moment(this.basicInfo.polEndDate).format('DD/MM/YYYY HH:mm')
      this.basicInfo.driverAge = this.basicInfo.driverAge;
      if (this.basicInfo.nationalityArr != null) {
        this.basicInfo.nationality = this.basicInfo.nationalityArr;
      }
      if (this.edataFlag) {
        this.eflag = "1";
      } else {
        this.eflag = "0";
      }
      // if(this.basicInfo.driverDob != null)
      // this.basicInfo.driverDob=this.basicInfo.driverDob.date.month +"/"+ this.basicInfo.driverDob.date.day+ "/" +  this.basicInfo.driverDob.date.year;
      if (this.transId == null || this.transId == "") {
        let postData = {
          lobCode: ApplicationConstants.LOB_MOTOR,
          portal: this.portalType,
          location: "A",
          userId: this.userId,
          bundleYN: "0",
          sourceMkting: "",
          campaignMkting: "",
          agentId: this.session.get("agent"),
          insName: this.basicInfo.insName.toUpperCase(),
          civilId: this.basicInfo.civilId,
          eDataFlag: this.eflag,
          // prodShortDesc: insType,
          ipAddress: this.ip,
          polStartDate: moment(new Date()).format('DD/MM/YYYY HH:mm')
        };

        this.agentService.createQuote(postData).subscribe(result => {
          if (result.respCode == 2000) {
            this.quoteNo = result.quoteNo;
            this.basicInfo.transId = result.transId;
            this.basicInfo.tranSrNo = result.tranSrNo;
            //calling update method
            this.updateAdditionalInformation(result.quoteNo, result.transId, result.tranSrNo);
          }
        });
      } else {
        this.updateAdditionalInformation(this.quoteNo, this.transId, this.tranSrNo);
      }
    } else {
      this.validateAllFormFields(this.primaryInfo);
    }
  }

  updateAdditionalInformation(quoteNo, transId, tranSrNo) {
    if (this.edataFlag) {
      this.eflag = "1";
    } else {
      this.eflag = "0";
    }
    this.loadingService.isBusy = true;
    this.quoteNo = quoteNo;
    this.basicInfo.transId = transId;
    this.basicInfo.tranSrNo = tranSrNo;
    this.basicInfo.apprStatus = "P";
    if (this.basicInfo.vehUsage == "1002") {
      this.basicInfo.divnCode = "19";
    } else {
      this.basicInfo.divnCode = this.divisionCode;
    }
    this.basicInfo.deptCode = this.departCode;
    this.basicInfo.busType = "1";
    this.basicInfo.status = "A";
    this.basicInfo.modeOfPay = "CC";
    this.basicInfo.menu = "A";
    this.basicInfo.userId = this.userId;
    this.basicInfo.agentCode = this.agentCode;
    this.basicInfo.portal = this.portalType;
    this.basicInfo.srcType = this.userType;
    this.basicInfo.quotIssDate = new Date();
    this.basicInfo.eDataFlag = this.eflag;
    if (this.basicInfo.tranSrNo > 0) {
      this.basicInfo.mapId = "MOT_REN_AGENT_POL_SCR_1";
    } else {
      this.basicInfo.mapId = "MOT_AGENT_POL_SCR_1";
    }
    delete this.basicInfo.bodyTypeArr;
    this.basicInfo.lobCode = "01";
    this.agentService.updateInsuredInfo(this.basicInfo).subscribe(updateInfoResult => {
      //  this.basicInfo.firstRegAge = (new Date().getFullYear() - moment(this.basicInfo.firstRegDate).get('year')).toString();
      if (this.basicInfo.isFirstTimeReg == null) {
        this.basicInfo.isFirstTimeReg = ""
      }
      if (this.basicInfo.isVehImported == null) {
        this.basicInfo.isVehImported = ""
      }
      if (this.basicInfo.importCountry == null) {
        this.basicInfo.importCountry = ""
      }
      let regDate = new Date().getFullYear() - parseInt(this.basicInfo.manfYear);
      if (regDate <= 0) { regDate = 0 }
      this.basicInfo.vehAge = regDate.toString();
      if (this.tranSrNo > 0) {
        this.basicInfo.mapId = "MOT_AGENT_RISK_END_SCR_1";
      } else {
        this.basicInfo.mapId = "MOT_AGENT_RISK_SCR_1";
      }
      this.agentService.updateVehicleInfo(this.basicInfo).subscribe(updateVehicleInfo => {
        if (updateVehicleInfo.respCode == 2000) {
          this.loadingService.isBusy = true;
          this.calculatePricing();
          /* if (this.basicInfo.previousInsuranceValid == '0' || this.basicInfo.totalLoss == '1') {
            let param = {
              "transId": this.basicInfo.transId,
              "tranSrNo": this.basicInfo.tranSrNo,
              "quoteNo": this.quoteNo,
              "errMessage": this.basicInfo.previousInsuranceValid == '0' ? 'Previous Insurance is Not Valid' : 'Total Loss Vehicle',
            };
            this.agentService.insertErrorMsg(param).subscribe(response => {
              let obj = {
                "transId": this.basicInfo.transId,
                "tranSrNo": this.basicInfo.tranSrNo,
                "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo,
                "errMessage": this.basicInfo.previousInsuranceValid == '0' ? 'Previous Insurance is Not Valid' : 'Total Loss Vehicle',
              };
              this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

            });
          } else {
            if (this.basicInfo.transId != '' && this.basicInfo.tranSrNo != '' && this.basicInfo.sumAssured > 0 && this.basicInfo.tranSrNo == 0) {
              this.loadingService.isBusy = true;
              this.agentService.edataSumInsuredValidation(this.basicInfo.transId, this.basicInfo.tranSrNo, this.basicInfo.sumAssured, this.userId).
                subscribe(response => {
                  if (response.errMessage == null) {
                    this.calculatePricing();
                  } else {
                    let param = {
                      "transId": this.basicInfo.transId,
                      "tranSrNo": this.basicInfo.tranSrNo,
                      "quoteNo": this.quoteNo,
                      "errMessage": response.errMessage,
                    };
                    this.agentService.insertErrorMsg(param).subscribe(response => {
                      let obj = {
                        "transId": this.basicInfo.transId,
                        "tranSrNo": this.basicInfo.tranSrNo,
                        "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo
                      };
                      this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

                    });
                    // let obj = {
                    //   "transId": this.basicInfo.transId,
                    //   "tranSrNo": this.basicInfo.tranSrNo,
                    //   "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo,
                    //   "errorMsg": response.errMessage
                    // };
                    // this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
                  }
                }, error => {

                });
            } else {
              this.calculatePricing();
            }

          } */
        }
      }, error => {
        let obj = {
          "transId": this.basicInfo.transId,
          "tranSrNo": this.basicInfo.tranSrNo,
          "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo,
          "errorMsg": error.error.errMessage
        };
        this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });

      });
    }, error => {

    });
  }

  calculatePricing() {
    this.loadingService.isBusy = true;
    let strPostData = {
      transId: this.basicInfo.transId,
      tranSrNo: this.basicInfo.tranSrNo,
      portal: this.portalType,
      userId: this.userId,
      lobCode: this.lobCode
    }
    this.agentService.calculatePricing(strPostData).subscribe(response => {
      if (response.respCode == 2000) {
        let obj = {
          "transId": this.basicInfo.transId,
          "tranSrNo": this.basicInfo.tranSrNo,
          "lobCode": this.lobCode,
          "quoteNo": this.quoteNo,
          "instlYn": this.primaryInfo.get('instYN').value,
          policyNo: this.policyNo
        };
        this.router.navigate(['scheme'], { queryParams: obj, skipLocationChange: true });
      }

    }, (error: HttpErrorResponse) => {
      //let errorMsg=JSON.parse(error["_body"]).errMessage;
      let errorMsg = error.error.errMessage;
      let obj = {
        "transId": this.basicInfo.transId,
        "tranSrNo": this.basicInfo.tranSrNo,
        "quoteNo": (this.quoteNo) ? this.quoteNo : this.policyNo,
        "errorMsg": errorMsg
      };
      this.router.navigate(['refferal'], { queryParams: obj, skipLocationChange: true });
    });
  }

  getAge(dateString) {
    let parts = dateString.split('/');
    let age: any;
    let today = new Date();
    let birthDate = new Date(parts[2], parts[1] - 1, parts[0]);

    age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  addlScreen() {
    this.router.navigate(['motoraddlinfo'])
  }

  changeValidation(value: string) {
    const type = this.primaryInfo.get('civilId');
    type.clearValidators();
    if (value == "1") {
      type.setValidators([Validators.required]);
      this.civilIdPatternError = "Only Alpha Numeric Allowed";
    } else {
      type.setValidators([Validators.required, Validators.pattern(/^\d{3}-\d{4}-\d{7}-\d{1}$/)]);
      this.civilIdPatternError = "Emirates Id should be XXX-XXXX-XXXXXXX-X format";
    }
    type.updateValueAndValidity();
  }

  /*enableFieldValidation(value: string) {
    const driverAge = this.primaryInfo.get('driverAge');
    if (value == "0") {
      driverAge.setValidators([Validators.required]);

    } else {
      driverAge.clearValidators();
    }
    driverAge.updateValueAndValidity();
    this.changeValidation(value);
    //Validators.compose([Validators.required,Validators.pattern(this.agentService.civilIdLength())]
  }*/

  updateregyear(value: String): void {
    this.primaryInfo.patchValue({ firstRegYear: value });
  }
  driverDate: any;
  getDriverAge(dateString) {
    this.driverDate = dateString.jsdate;

    var today = new Date();
    var birthDate = this.driverDate;
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    this.primaryInfo.get('driverAge').setValue(age);
    return age;
  }

  getPolicyDuration() {
    this.loadingService.isBusy = true;
    let strPostData = {
      lobCode: this.lobCode
    }
    this.agentService.getPolicyDuration(strPostData).subscribe(response => {
      if (response.respCode == 2000) {
        this.duration = response.duration;
      }

    }, (error: HttpErrorResponse) => {
      //let errorMsg=JSON.parse(error["_body"]).errMessage;
      let errorMsg = error.error.errMessage;

    });
  }
}
