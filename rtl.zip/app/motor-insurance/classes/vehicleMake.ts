export class VehicleMake {
    MAKECODE: string;
    MAKEDESC: string;
    MAKEDESCAR?: string;
  }
  