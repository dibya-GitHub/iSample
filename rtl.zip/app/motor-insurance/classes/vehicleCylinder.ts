export class VehicleCylinder {
    code: string;
    desc: string;
    value: string;
    descAr?: string;
  }
  