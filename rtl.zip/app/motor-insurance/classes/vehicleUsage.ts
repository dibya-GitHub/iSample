export class UsageArray {
	USAGECODE: string;
	USAGEDESC: string;
	USAGEDESCAR: string;
}