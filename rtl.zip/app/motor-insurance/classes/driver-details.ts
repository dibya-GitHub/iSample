export class DriverDetails {

    driverName;
    driverAge;
    licenseNo;
    licenseAge;
    relation;
    transId;
    tranSrNo;
}
