export class GeographicalLimit {
  code: string;
  desc: string;
  value: string;
  descAr?: string;
}
