import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { DriverDetails } from '../motor-insurance/classes/driver-details';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

@Component({
  selector: 'app-non-financial-endorsement',
  templateUrl: './non-financial-endorsement.component.html',
  styleUrls: ['./non-financial-endorsement.component.scss']
})
export class NonFinancialEndorsementComponent implements OnInit {
  isShowDiv: boolean;
  cmpanyYn: any;
  custType: any;
  bankList: any = [];
  BankFinance: boolean;
  company;
  transId;
  tranSrNo;
  lobCode;
  policyNo;
  docCodeValue;
  file: File;
  tmpParms: any;
  customerInfo: any;
  vehicleInfo: any;
  homeInfo: any;
  travelInfo: any;
  nationalityList: Array<any>;
  colorList: any;
  plateTypes: any;
  plateCodes: any;
  cityList: any[] = [];
  streetList: Array<any>;
  zoneList: any;
  buldingTypeList: any;
  languageList: any;
  relationList: any;
  driversInfo: any;
  CustomerInfoForm: UntypedFormGroup;
  VehicleInfoForm: UntypedFormGroup;
  HomeInfoForm: UntypedFormGroup;
  driverList: UntypedFormArray;
  driverInfo: DriverDetails;
  civilIdErrorMessage;
  mobileNoerrorMessage;

  dataArr: UntypedFormArray;
  travelDetailsinfo: any;
  childinfo: UntypedFormArray;
  adultinfo: UntypedFormArray;
  noOfAdult: number;
  noOfChild: number;
  totalChildren: number;
  totalAdults: number;
  genderList: Array<any>;
  travelersInfo: UntypedFormGroup;
  arr = [];
  companyCode: string = this.session.get("companyCode");
  travlDetails: Array<any>;
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  insNameAr: string;
  // civilIdPatternError: any;
  @Input() netPremium: any;

  constructor(
    private router: Router,
    public route: ActivatedRoute,
    private fb: UntypedFormBuilder,
    public loaderService: LoaderService,
    private messageService: MessageService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
  ) { }


  ngOnInit() {

    this.loaderService.isBusy = false;
    this.transId = this.commonService.getParamValue('transId');
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.civilIdErrorMessage = this.commonService.civilIdErrorMessage();
    this.mobileNoerrorMessage = this.commonService.mobileNoErrorMessage();
    this.getNationalityList();
    this.getCityList();
    this.getEndorsementDetails();
    this.createForm();
    this.getColorList();
    this.getZoneList();
    this.getStreetList();
    this.getBuildingtypetList();
    this.getRelationList();
    this.getQuoteTravelInfo();
    this.getGenderType();
    this.getNationalityType();
    this.getTravlersDetails();
    this.getBankOfFinance();
    this.getPlateType();
    this.getVehPlateCode();

  }

  trafficLocList = [
    { id: "002", value: "Dubai" },
    { id: "003", value: "Abudhabi" }
  ]

  customerTypes = [
    { id: "0", value: "Individual" },
    { id: "1", value: "Company" }
  ]

  financeStatusList = [
    { id: "1", value: "Yes" },
    { id: "0", value: "No" }
  ]
  buildingAgeList = [
    { id: "1", value: "1" },
    { id: "2", value: "2" },
    { id: "3", value: "3" },
    { id: "4", value: "4" },
    { id: "5", value: "5" },
    { id: "6", value: "6" },
    { id: "7", value: "7" },
    { id: "8", value: "8" },
    { id: "9", value: "9" },
    { id: "10", value: "10" },
  ]

  createForm() {
    this.CustomerInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      transRemark: '',
      userId: this.session.get("username"),
      custCode: this.session.get("agent"),
      portal: this.session.get("portaltype"),
      ipAddress: '',
      companyYn: '',
      telephoneNo: '',
      interest: '',
      producerCode: '',
      collectorCode: '',
      taxRefNo: '',
      civilId: [''],
      insName: [''],
      insNameAr: '',
      mobileNo: ['', Validators.compose([Validators.required, Validators.pattern(this.commonService.checkMobileNo())])],
      address: '',
      address2: '',
      poBox: ['', Validators.required],
      emailId: ['', [Validators.email]],
      city: '',
      nationality: '',
      mapId: 'END_CUS_INFO_UDATE'
    });
    this.VehicleInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      userId: this.session.get("username"),
      mapId: 'END_VEHICLE_INFO_UDATE',
      chassisNo: ['', Validators.required],
      engineNo: '',
      regnNo: '',
      licenceNo: '',
      trafficLoc: ['', Validators.required],
      tcfNo: ['', Validators.required],
      orangeCardNo: '',
      aaaCardNo: '',
      vehColor: '',
      plateChar: '',
      vehPlateCode: '',
      financedYn: '',
      driverList: this.fb.array([]),
      financedBank: '',
      firstRegYear: '',
      firstRegDate: [undefined, Validators.required]
    });

    this.HomeInfoForm = this.fb.group({
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      userId: this.session.get("username"),
      mapId: 'END_BULDING_INFO_UDATE',
      bldngAge: '',
      bldngType: '',
      zoneArea: '',
      city: '',
      streetBlock: '',
      poBox: ['', Validators.required],
      address: ['', Validators.required],
      address1: '',
      financedBank: '',
      financedBankYn: ''
    });

    this.travelersInfo = this.fb.group({
      adultinfo: this.fb.array([]),
      childinfo: this.fb.array([]),
    });

  }

  getEndorsementDetails() {
    let params = { "trans_Id": this.transId, "trans_Sno": this.tranSrNo };
    this.agentService.getEndorseDetails(params)
      .subscribe(result => {

        this.customerInfo = result.customerInfo;
        this.cmpanyYn = result.customerInfo.companyYn
        this.vehicleInfo = result.vehicleInfo;
        if (this.vehicleInfo.firstRegDate !== null || this.vehicleInfo.firstRegDate !== undefined) {
          this.vehicleInfo.regDate = this.vehicleInfo.firstRegDate;
        }
        this.homeInfo = result.homeInfo;
        this.travelInfo = result.travelInfo;
        this.driversInfo = result.driversInfo;
        this.CustomerInfoForm.patchValue({
          companyYn: this.customerInfo.companyYn,
          telephoneNo: this.customerInfo.telephoneNo,
          interest: this.customerInfo.interest,
          producerCode: this.customerInfo.producerCode,
          collectorCode: this.customerInfo.collectorCode,
          taxRefNo: this.customerInfo.taxRefNo,
          civilId: this.customerInfo.civilId,
          insName: this.customerInfo.insName,
          insNameAr: this.customerInfo.insNameAr,
          mobileNo: this.customerInfo.mobileNo,
          address: this.customerInfo.address,
          address2: this.customerInfo.address2,
          poBox: this.customerInfo.poBox,
          emailId: this.customerInfo.emailId,
          city: this.customerInfo.city,
          nationality: this.customerInfo.nationality,
          transRemark: this.customerInfo.transRemark,

        });
        this.changeValidation(this.customerInfo.companyYn);
        // custType default if companyYn is null;

        if (this.customerInfo.companyYn == '0' || this.customerInfo.companyYn == null) {
          if (this.customerInfo.companyYn == null) {
            this.CustomerInfoForm.get('companyYn').setValue(0);
          } else {
            this.CustomerInfoForm.get('companyYn').setValue(this.customerInfo.companyYn);
          }
          this.isShowDiv = true;
        } else {
          this.isShowDiv = false;
        }

        if ("04" == this.lobCode) {
          this.HomeInfoForm.patchValue({
            bldngAge: this.homeInfo.bldngAge,
            bldngType: this.homeInfo.bldngType,
            zoneArea: this.homeInfo.zoneArea,
            city: this.homeInfo.city,
            streetBlock: this.homeInfo.streetBlock,
            poBox: this.homeInfo.poBox,
            address: this.homeInfo.address,
            financedBank: this.homeInfo.financedBank,
            financedBankYn: "Yes" == this.homeInfo.financedBankYn ? "1" : "0",

          });
          if (this.homeInfo.financedBankYn == 1) {
            this.BankFinance = true;
          } else {
            this.BankFinance = false;
          }
        }
        if ("01" == this.lobCode) {
          this.VehicleInfoForm.patchValue({
            chassisNo: this.vehicleInfo.chassisNo,
            engineNo: this.vehicleInfo.engineNo,
            regnNo: this.vehicleInfo.regnNo,
            licenceNo: this.vehicleInfo.licenceNo,
            trafficLoc: this.vehicleInfo.trafficLoc,
            tcfNo: this.vehicleInfo.tcfNo,
            orangeCardNo: this.vehicleInfo.orangeCardNo,
            aaaCardNo: this.vehicleInfo.aaaCardNo,
            vehColor: this.vehicleInfo.vehColor,
            plateChar: this.vehicleInfo.plateChar,
            vehPlateCode: this.vehicleInfo.vehPlateCode,
            financedYn: this.vehicleInfo.financedYn,
            nationality: this.vehicleInfo.nationalityDesc,

          });
          if (this.vehicleInfo.financedYn == 1) {
            this.BankFinance = true;
          } else {
            this.BankFinance = false;
          }
          for (var i = 0; i < this.driversInfo.length; i++) {
            this.addNewRow();
          }
          this.loadDefaultValues();
        }

      });

  }

  loadDefaultValues() {
    for (var i = 0; i < this.driversInfo.length; i++) {
      const controlArray = <UntypedFormArray>this.VehicleInfoForm.get('driverList');
      controlArray.controls[i].get('driverName').setValue(this.driversInfo[i].driverName);
      controlArray.controls[i].get('driverAge').setValue(this.driversInfo[i].driverAge);
      controlArray.controls[i].get('licenseNo').setValue(this.driversInfo[i].licenseNo);
      controlArray.controls[i].get('licenseAge').setValue(this.driversInfo[i].licenseAge);
      controlArray.controls[i].get('relation').setValue(this.driversInfo[i].relation);
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Check The Mandatory Fields' });
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }


  approveEndorsement(mode) {
    if (this.CustomerInfoForm.valid) {
      this.loaderService.isBusy = true;
      this.agentService.updateInsuredInfo(this.CustomerInfoForm.value)
        .subscribe(result => {
          if ("01" == this.lobCode) {
            this.updateVehcleInfo(mode);
          } else if ("04" == this.lobCode) {
            this.updateHomeInfo(mode);
          } else if ("08" == this.lobCode) {
            this.updateTravelInfo(mode);
          }

        });
    } else {
      this.validateAllFormFields(this.CustomerInfoForm);
    }
  }

  updateHomeInfo(mode) {
    this.agentService.updateHomeInfo(this.HomeInfoForm.value)
      .subscribe(result => {
        if ("approve" == mode) {
          this.endtProceedtoBuy()
        } else {
          this.router.navigate(['agentdashboard']);
        }
      });
  }

  updateVehcleInfo(mode) {
    let formData = this.VehicleInfoForm.getRawValue();
    var changed = false;
    if (this.vehicleInfo.regDate != null || this.vehicleInfo.regDate != undefined) {
      this.VehicleInfoForm.get('firstRegDate').setValue(this.vehicleInfo.regDate);
      changed = true;
    }
    if (this.VehicleInfoForm.get('firstRegDate').value === undefined || this.VehicleInfoForm.get('firstRegDate').value === null) {
      this.messageService.add({ severity: 'warn', summary: 'Warn Message', detail: 'Please Select First reg Date' });
    } else {
      let regDate = this.VehicleInfoForm.get('firstRegDate').value;
      if (!changed) {
        formData.firstRegDate = new Date(regDate.date.year, regDate.date.month - 1, regDate.date.day);
        formData.firstRegDate = moment(formData.firstRegDate).format('DD/MM/YYYY 00:00');
        formData.firstRegYear = regDate.date.year;
      } else {
        formData.firstRegDate = this.vehicleInfo.regDate;
        let yr = moment(regDate, 'DD/MM/YYYY').year();
        formData.firstRegYear = yr
      }

      this.agentService.updateVehicleInfo(formData)
        .subscribe(result => {
          this.insertAdditionalDriverInfo(mode);

        });
    }
    // if (this.vehicleInfo.firstRegDate === null) {
    //   let regDate = this.VehicleInfoForm.get('firstRegDate').value;
    //   formData.firstRegDate = new Date(regDate.date.year, regDate.date.month - 1, regDate.date.day);
    //   formData.firstRegDate = moment(formData.firstRegDate).format('DD/MM/YYYY 00:00');
    //   formData.firstRegYear = regDate.date.year;
    // } else {
    //   let date = this.vehicleInfo.firstRegDate;
    //   let yr = moment(date, 'DD/MM/YYYY').year();
    //   let month = moment(date, 'DD/MM/YYYY').month();
    //   let dt = moment(date, 'DD/MM/YYYY').date();
    //   formData.firstRegDate = new Date(yr, month, dt);
    //   formData.firstRegDate = moment(formData.firstRegDate).format('DD/MM/YYYY 00:00');
    //   formData.firstRegYear = moment(date, 'DD/MM/YYYY').year();
    // }

    // this.VehicleInfoForm.get('firstRegDate').value;

  }
  onfirstRegDateChanged(dateString) {
    this.VehicleInfoForm.get('firstRegDate').setValue(dateString.jsdate);
  }
  insertAdditionalDriverInfo(mode) {
    let arr = [];
    let driverArray: Array<DriverDetails>;
    for (var i = 0; i < this.VehicleInfoForm.get('driverList').value.length; i++) {
      this.driverInfo = this.VehicleInfoForm.get('driverList').value[i];
      this.driverInfo.transId = this.transId;
      this.driverInfo.tranSrNo = this.tranSrNo;
      arr.push(this.driverInfo);
    }
    driverArray = arr;
    this.agentService.insertAdditionalDriverInfo(driverArray)
      .subscribe(result => {
        if ("approve" == mode) {
          this.endtProceedtoBuy()
        } else {
          this.router.navigate(['agentdashboard']);
        }
      });
  }


  endtProceedtoBuy() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo, "userId": this.session.get("username") }
    this.agentService.endtProceedtoBuy(param)
      .subscribe(result => {
        let obj = { "transId": this.transId, "tranSrNo": this.tranSrNo, "policyNo": this.policyNo };
        this.router.navigate(['endtconfirmation'], { queryParams: obj, skipLocationChange: true });
        this.loaderService.isBusy = false;

      });
  }

  cancelEndrosement() {
    let param = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.cancelEndrosement(param)
      .subscribe(result => {
        this.router.navigate(['agentdashboard']);
      });

  }
  closeEndorsement() {
    this.router.navigate(['agentdashboard']);
  }

  getNationalityList() {
    let v_nationality = { "type": "NATIONALITY" };
    this.commonService.getGeoList(v_nationality)
      .subscribe(result => {
        this.nationalityList = result.appCodesArray;
      });
  }

  getCityList() {
    let v_city = { "type": "STATE", "refCode": "002" };
    this.agentService.getCityList(v_city)
      .subscribe(result => {
        this.cityList = result.appCodesArray;
      });
  }

  getColorList() {
    let v_color = { "type": "MOT_VEH_COL" };
    this.agentService.getGeoList(v_color)
      .subscribe(result => {
        this.colorList = result.appCodesArray;
      });
  }

  getPlateType() {
    let params = { "type": "PLATE_CHAR" }
    this.agentService.getPlateType(params).subscribe(result => {
      this.plateTypes = result.appCodesArray;
    })
  }

  getVehPlateCode() {
    let params = { "type": "MOT_PLAT_TYP" }
    this.agentService.getPlateType(params).subscribe(result => {
      this.plateCodes = result.appCodesArray;
    })
  }

  getZoneList() {
    let zone = { "type": "ZONE_AREA" };
    this.agentService.getGeoList(zone)
      .subscribe(result => {
        this.zoneList = result.appCodesArray;
      });
  }

  getStreetList() {
    let street = { "type": "STREET_BLOCK" };
    this.agentService.getGeoList(street)
      .subscribe(result => {
        this.streetList = result.appCodesArray;
      });
  }
  getBuildingtypetList() {
    let bldType = { "type": "BUILDING_TYP" };
    this.agentService.getGeoList(bldType)
      .subscribe(result => {
        this.buldingTypeList = result.appCodesArray;
      });
  }



  uploadDocuments(event: any) {

    this.getDocumentCodeBeforeUpload(event.target.id);
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
      var reader = new FileReader();
      var that = this;
      reader.onload = function () {

        that.upload(event);
      }
      reader.readAsDataURL(fileList[0]);
    }

  }

  upload(event: any, files?: any, doc?: any) {
    let fileList: FileList = files && files.length > 0 ? "" : event.target.files;
    let file: File = files && files.length > 0 ? files[0] : fileList[0];

    let formData: FormData = new FormData();
    formData.append('fileObject', file, file.name);
    formData.append('transId', this.transId);
    formData.append('tranSrNo', this.tranSrNo);
    formData.append('lobCode', this.lobCode);
    formData.append('docCode', this.docCodeValue);
    formData.append('docType', "POL");
    formData.append('userId', this.session.get("username"));
    var uploadDocumentReponse = this.commonService.uploadDocuments(formData);

  }

  getDocumentCodeBeforeUpload(event) {
    if (event == "emiratesId") {
      this.docCodeValue = "004";
    } else if (event == "mail") {
      this.docCodeValue = "038";
    } else if (event == "passport") {
      this.docCodeValue = "006";
    } else if (event == "proposalForm") {
      this.docCodeValue = "039";
    } else if (event == "highValueItem") {
      this.docCodeValue = "050";
    } else if (event == "others") {
      this.docCodeValue = "";
    } else if (event == "receipt") {
      this.docCodeValue = "049";
    }
  }

  loadAgentDoc(reportType) {
    var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=1000,height=400,left=100%,top=100%`;
    var winRef = window.open('/viewdocument?transId=' + this.transId + '&tranSrNo=' + this.tranSrNo + '&reportType=' + reportType + '&policyNo=' + this.policyNo, 'Product Category', param);
  }
  createItem(): UntypedFormGroup {
    return this.fb.group({
      driverName: '',
      driverAge: '',
      licenseNo: '',
      licenseAge: '',
      relation: ''

    });
  }

  addNewRow(): void {
    this.createItem();
    this.driverList = this.VehicleInfoForm.get('driverList') as UntypedFormArray;
    this.driverList.push(this.createItem());
  }

  deleteRow(index) {
    this.driverList = this.VehicleInfoForm.get('driverList') as UntypedFormArray;
    this.driverList.removeAt(index);
  }

  getRelationList() {
    let param = { "type": "RELATION" };
    this.agentService.getGeoList(param)
      .subscribe(result => {
        this.relationList = result.appCodesArray;
      });
  }


  //---------------Travelinfo------------------//

  addAdultRow(len: number): any {
    for (var i = 1; i <= len; i++) {
      this.adultinfo = this.travelersInfo.get('adultinfo') as UntypedFormArray;
      this.createAdult();
      this.adultinfo.push(this.createAdult());
    }
  }

  addChildRow(len: number): any {
    for (var i = 1; i <= len; i++) {

      this.childinfo = this.travelersInfo.get('childinfo') as UntypedFormArray;
      this.createChild();
      this.childinfo.push(this.createChild());
    }
  }

  createAdult(): UntypedFormGroup {
    return this.fb.group({
      trvlrName: '',
      relation: '',
      gender: '',
      dob: [],
      nationality: '',
      passptNo: '',
      wntrSptsExtYN: [],
      transId: this.transId,
      tranSrNo: this.tranSrNo,

    });
  }
  createChild(): UntypedFormGroup {
    return this.fb.group({
      trvlrName: '',
      relation: '',
      gender: '',
      dob: '',
      nationality: '',
      passptNo: '',
      wntrSptsExtYN: '',
      transId: this.transId,
      tranSrNo: this.tranSrNo,
    });
  }

  getQuoteTravelInfo() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getQuoteTravelInfo(data).subscribe(result => {
      this.noOfAdult = Number(result.noOfAdults);
      this.noOfChild = Number(result.noOfChild);
      if (this.noOfAdult > 0) {
        this.addAdultRow(this.noOfAdult);
      }
      if (this.noOfChild > 0) {
        this.addChildRow(this.noOfChild);
      }
    })

  }

  getGenderType() {
    this.agentService.getGenderList({ "paraType": "GENDER" }).subscribe(resp => {
      this.genderList = resp;
    })
  }
  getNationalityType() {
    this.agentService.getNationalityList({ "type": "NATIONALITY" }).subscribe(resp => {
      this.nationalityList = resp.appCodesArray;
    })
  }
  loadTravlInfo() {
    for (var i = 0; i < this.travlDetails.length; i++) {
      const controlArray = <UntypedFormArray>this.travelersInfo.get('adultinfo');
      controlArray.controls[i].get('trvlrName').setValue(this.travlDetails[i].trvlrName);
      controlArray.controls[i].get('relation').setValue(this.travlDetails[i].relation);
      controlArray.controls[i].get('gender').setValue(this.travlDetails[i].gender);
      controlArray.controls[i].get('dob').setValue(this.travlDetails[i].dob);
      controlArray.controls[i].get('nationality').setValue(this.travlDetails[i].nationality);
      controlArray.controls[i].get('passptNo').setValue(this.travlDetails[i].passptNo);
      controlArray.controls[i].get('wntrSptsExtYN').setValue(this.travlDetails[i].wntrSptsExtYN);
    }
  }


  getTravlersDetails() {
    const data = { "transId": this.transId, "tranSrNo": this.tranSrNo }
    this.agentService.getTravelerDetls(data).subscribe(resp => {
      this.travlDetails = resp.travelerArray;
      this.loadTravlInfo();
    });
  }

  updateTravelInfo(mode) {
    this.arr.push(this.travelersInfo.value);
    this.agentService.insertTravelInfo(this.arr)
      .subscribe(result => {
        if ("approve" == mode) {
          this.endtProceedtoBuy()
        } else {
          this.router.navigate(['agentdashboard']);
        }
      });
  }
  selectOption(id: number) {
    if (id == 1) {
      this.BankFinance = true;
    } else {
      this.BankFinance = false;
    }
  }
  //Bank
  getBankOfFinance() {
    this.agentService.getApplicationCodes('BANK').subscribe(data => {
      // let tmpArr = data.appCodesArray.reverse();
      this.bankList = data.appCodesArray;
    });
  }


  // changeCustType(type:String){
  // //this.custType=this.CustomerInfoForm.controls['companyYn'].value
  // if(type=='0'|| type== undefined){
  //   this.isShowDiv=true;
  // }else{
  //   this.isShowDiv=false;
  // }
  // }
  changeValidation(value: string) {

    const type = this.CustomerInfoForm.get('civilId');
    type.clearValidators();
    // if (value == "1") {
    //   type.setValidators([Validators.required]);
    //   this.civilIdPatternError = "Only Alpha Numeric Allowed";
    // } else {
    //   type.setValidators([Validators.required, Validators.pattern(/^\d{3}-\d{4}-\d{7}-\d{1}$/)]);
    //   this.civilIdPatternError = "Emirates Id should be XXX-XXXX-XXXXXXX-X format";
    // }
    // type.updateValueAndValidity();
  }
}
