import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchemePlansComponent } from './scheme-plans.component';

describe('SchemePlansComponent', () => {
  let component: SchemePlansComponent;
  let fixture: ComponentFixture<SchemePlansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchemePlansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchemePlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
