import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { ApplicationConstants } from 'src/shared/application-constants';
import * as _ from 'underscore';
import { Cover } from '../../shared/classes/cover';
import { PremRateChange } from '../../shared/classes/prem-rate-change';
import { SchemeOtherPrem } from '../../shared/classes/scheme-other-prem';
import { Covers } from '../../shared/interfaces/insurance-plan';
import { LoaderService } from '../../shared/loader-service/loader.service';
import { AgentUserService } from "../../shared/services/agent-user.service";
import { HomeInsurancePlanService } from '../home/services/home-insurance-plan.service';
import { AgentHttpclientService } from '../services/agent-httpclient.service';

declare function loadslick(): any;
declare var $:any;
@Component({
  selector: 'app-scheme-plans',
  templateUrl: './scheme-plans.component.html',
  styleUrls: ['./scheme-plans.component.scss'],
})
export class SchemePlansComponent implements OnInit {

  loggedInUserId: string;
  respCode;
  public installAccess: string = this.session.get("installAccess");
  template: string = '<img class="custom-spinner-template" src="./assets/images/logo_animation_100x100-1.gif" alt="loading gif">';
  policyNo: any;
  divnCode: any;
  userId: any;
  tempArray: any[];

  travelInsurance: boolean = false;
  pabInsurance: boolean = false;
  underProcess: boolean;
  transId: string;
  tranSrNo: number;
  lobCode: string;
  civilId: string;
  quoteNo: string;
  insuredName: string;
  imgName: string;
  errorMsg: string;
  rateErr: string;
  basicSchemeCode: string = "";
  currName: string;
  tdColSpan: number;
  //otherColSpan : number;
  divColSize: number;
  schemeCount: number = 0;
  discCount: number = 0;
  feesCount: number = 0;
  deductionCount: number = 0;
  loadingsCount: number = 0;
  schemes: any;
  productCode: any;
  schemesList: any[] = [];
  coversArray: any[] = [];
  subCvrsArray: Cover[] = [];
  schemeNetPremium: any[] = [];
  basicCovers: any[] = [];
  coversToShow: Cover[][];
  discountsToShow: SchemeOtherPrem[][];
  feesToShow: SchemeOtherPrem[][];
  deductibleToShow: SchemeOtherPrem[][];
  loadingChargeToShow: SchemeOtherPrem[][];
  processCovers = new Map<string, Cover>();
  processDiscounts = new Map<string, SchemeOtherPrem>();
  processFees = new Map<string, SchemeOtherPrem>();
  processDeductibles = new Map<string, SchemeOtherPrem>();
  processLoadingCharges = new Map<string, SchemeOtherPrem>();
  basicFeesArray: any[] = [];
  discountsArray: any[] = [];
  feesArray: any[] = [];
  deductiblesArray: any[] = [];
  loadingChargesArray: any[] = [];
  basicDiscountArray: any[] = [];
  basicDeductiblesArray: any[] = [];
  basicLoadingChargesArray: any[] = [];
  homeSIListArray: any[] = [];
  premRateChageArray: PremRateChange[] = [];
  polStartDate: any
  polEndDate: any;
  public chassisFlag: boolean = false;
  coversList: any;
  dedectableList: any;
  feesList: any;
  lodingList: any;
  discountList: any;
  dedectable: boolean = false;
  loading: boolean = false;
  fees: boolean = false;
  discount: boolean = false;
  dedactablevalue = [];
  loadingvalue = [];
  discountvalue = [];
  feesvalue = [];
  ProductDesc: String;
  instlYn: string;
  eDataFlag: boolean
  coversDetails: any = [];
  @ViewChild('trigger') tr: ElementRef;
  vehicleCount: any;
  taxApplYn: boolean = false;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private commonService: AgentUserService,
    private agentService: AgentHttpclientService,
    private homeInsurancePlanService: HomeInsurancePlanService,
  ) { }
  ngOnInit() {

    this.loaderService.isBusy = true;
    let intObj = setInterval(() => {
      if (this.tr.nativeElement && this.tr.nativeElement.value == (this.schemesList.length - 1)) {
        $("div.cross-arrow-box").parent().css("display", "none");
        if (this.lobCode == "04") {
          // $(".price_table_row2 > div:eq(2) > div").css({ "margin-top": "16px", 'padding-top': "18px" });
          // $(".price_table_row2 > div:eq(3) > div").css({ "margin-top": "12px", 'padding-top': "18px" });
          // $(".price_table_row2 > div:eq(2) > div").css("border-top", "solid 1px #ddd");
          // $(".price_table_row2 > div:eq(3) > div").css("border-top", "solid 1px #ddd");
        }
        if (this.lobCode == "06") {

          $(".price_table_row2").eq(9).css({ 'min-height': "50px", "padding-top": "14px" });
          $(".price_table_row2").eq(17).css({ 'min-height': "50px", "padding-top": "14px" });

          $(".price_table_row2").eq(10).css({ 'min-height': "110px", "padding-top": "44px" });
          $(".price_table_row2").eq(18).css({ 'min-height': "110px", "padding-top": "44px" });

          $(".price_table_row2").eq(11).css({ 'min-height': "72px", "padding-top": "14px" });
          $(".price_table_row2").eq(19).css({ 'min-height': "72px", "padding-top": "14px" });

          $(".price_table_row2").eq(12).css({ 'min-height': "89px", "padding-top": "24px" });
          $(".price_table_row2").eq(20).css({ 'min-height': "89px", "padding-top": "24px" });

          $(".price_table_row2").eq(13).css({ 'min-height': "70px", "padding-top": "24px" });
          $(".price_table_row2").eq(21).css({ 'min-height': "70px", "padding-top": "24px" });

          $(".price_table_row2").eq(14).css({ 'min-height': "113px", "padding-top": "34px" });
          $(".price_table_row2").eq(22).css({ 'min-height': "113px", "padding-top": "34px" });

          $(".price_table_row2").eq(15).css({ 'min-height': "80px", "padding-top": "24px" });
          $(".price_table_row2").eq(23).css({ 'min-height': "80px", "padding-top": "24px" });

          $(".price_table_row2").css("white-space", "normal");
        }

        clearInterval(intObj);
        loadslick();
        this.loaderService.isBusy = false;
      }
    }, 2000);
    this.quoteNo = this.commonService.getParamValue('quoteNo')


    this.transId = this.commonService.getParamValue('transId')//"1397780"//"1397225";
    this.tranSrNo = this.commonService.getParamValue('tranSrNo');
    this.lobCode = this.commonService.getParamValue('lobCode');
    this.insuredName = this.commonService.getParamValue('insuredName');
    this.civilId = this.commonService.getParamValue('civilId');
    this.polStartDate = this.commonService.getParamValue('policyStartDate');
    this.polEndDate = this.commonService.getParamValue('policyEndDate');
    this.policyNo = this.commonService.getParamValue('policyNo');
    this.imgName = (this.lobCode == ApplicationConstants.LOB_MOTOR ? 'icon-heading-car.png' : this.lobCode == ApplicationConstants.LOB_HOME ? 'icon-round-tv.png' : 'icon-travel-insurance.png');
    var schemesPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
    this.loggedInUserId = this.session.get("userId");
    this.currName = this.session.get("CurrencyName");
    this.divnCode = this.session.get('divisionCode');
    this.userId = this.session.get('username');

    this.getAllSchemes(schemesPostData);
    if ('01' == this.lobCode) {
      this.ProductDesc = "Motor";
      this.chkChassisExist();
    } else if ('04' == this.lobCode) {
      this.ProductDesc = "Home";
    } else if ('06' == this.lobCode) {
      this.ProductDesc = "Marine_Hull";
    } else if ('08' == this.lobCode) {
      this.ProductDesc = "Travel";
    }
    this.sumInsured();
    this.checkTaxApplYN();
  }

  sumInsured() {
    if (this.lobCode == '01') {
      let param = { "transId": this.transId, "tranSrNo": this.tranSrNo };
      this.getVehicleCount(param);
    }

  }

  checkTaxApplYN() {
    let param = {};
    this.agentService.getTaxApplYn(param).subscribe(resp => {
      if (resp.taxApplFlag == '1') {
        this.taxApplYn = false;
      } else {
        this.taxApplYn = true;
      }
    })

  }
  getVehicleCount(body) {
    this.agentService.getVehicleCount(body).subscribe((data) => {
      this.vehicleCount = data.count;
    })
  }

  chkChassisExist() {
    let params = {
      transId: this.transId,
      tranSrNo: this.tranSrNo
    };
    this.agentService.chkChassisExist(params).subscribe(data => {
      if ("Y" == data.chassisFlag)
        this.chassisFlag = true;
      else
        this.chassisFlag = false;
    });
  }

  getAllSchemes(schemesPostData: any) {
    //this.loaderService.isBusy = true;      
    this.agentService.getSchemes(schemesPostData).subscribe(schemeListResponse => {
      if (schemeListResponse.respCode == 2000) {
        this.schemesList = schemeListResponse.schemesArray;
        this.schemeCount = this.schemesList.length;
        //this.otherColSpan = (this.tdColSpan * this.schemeCount)+2; 
        if (2 == this.schemeCount) {
          this.divColSize = 4;//For covers descriptions div too
        } else if (3 == this.schemeCount) {
          this.divColSize = 3;
        } else if (4 == this.schemeCount) {
          this.divColSize = 2;
        } if (1 == this.schemeCount) {
          this.divColSize = 8;//For covers descriptions div too
        }

      }
      //used to get Covers
      this.agentService.getSchemeCovers(schemesPostData).subscribe(schemeResponse => {
        if (schemeResponse.respCode == 2000) {
          // this.schemes = this.schemesList;
          this.schemes = schemeResponse.schemesArray;
          this.schemesList = this.schemesList.sort((n1, n2) => {
            if (n1.dispOrder > n2.dispOrder) {
              return 1;
            }

            if (n1.dispOrder < n2.dispOrder) {
              return -1;
            }
            return 0;
          });

          let rateIndex = 0;
          for (let scheme of this.schemes) {
            //scheme.schDesc = scheme.schDesc.replace("/*/g","");
            if (scheme.premRateInfo.rate == 1) {
              this.premRateChageArray[rateIndex] = scheme.premRateInfo;
              rateIndex++;
            }
          }

          this.agentService.getAllCovers(schemesPostData).subscribe(coverResponse => {
            if (coverResponse.respCode == 2000) {
              this.coversArray = coverResponse.coversArray;

              if (this.coversArray.length > 0) {
                let schIndex = 0;
                for (let scheme of this.schemes) {

                  let index = 0;
                  this.schemesList[schIndex].premium = scheme.premium;
                  schIndex++;
                  this.basicCovers = scheme.coversArray;
                  this.basicFeesArray = scheme.feesArray;
                  this.basicDiscountArray = scheme.discountsArray;
                  this.basicDeductiblesArray = scheme.deductiblesArray;


                  this.basicLoadingChargesArray = scheme.loadingsArray;
                  this.homeSIListArray = scheme.homeSIList;
                  //   alert("homeSIListArray  is**"+JSON.stringify(this.homeSIListArray));      
                  for (var i = 0; i < this.basicCovers.length; i++) {
                    let viewKey = this.basicCovers[i].schCode + "c" + this.basicCovers[i].coverCode;
                    this.processCovers.set(viewKey, this.basicCovers[i]);
                  }
                  for (var i = 0; i < this.basicDiscountArray.length; i++) {
                    let viewKey = scheme.schCode + "o" + this.basicDiscountArray[i].code;
                    this.processDiscounts.set(viewKey, this.basicDiscountArray[i]);
                    this.discountsArray.push(this.basicDiscountArray[i]);
                  }
                  index = 0;
                  for (var i = 0; i < this.basicFeesArray.length; i++) {
                    let viewKey = scheme.schCode + "o" + this.basicFeesArray[i].code;
                    this.processFees.set(viewKey, this.basicFeesArray[i]);
                    this.feesArray[index++] = this.basicFeesArray[i];
                  }
                  // alert("in basicDeductiblesArray length**"+this.basicDeductiblesArray.length);  
                  var prevLength, currLength
                  if (schIndex == 1) {
                    prevLength = this.basicDeductiblesArray.length
                    currLength = this.basicDeductiblesArray.length
                  } else {
                    currLength = this.basicDeductiblesArray.length
                  }
                  if (prevLength !== currLength) {
                    if (prevLength > currLength) {
                      // if(this.lobCode == '04'){
                      //   let tempObj = {
                      //     "code": '0422',
                      //     "desc": '',
                      //     "helpText": null,
                      //     "value": '0',
                      //     "value1": null
                      //   }
                      //   this.basicDeductiblesArray.push(tempObj);
                      // }
                      index = 0;
                      for (var i = 0; i < this.basicDeductiblesArray.length; i++) {
                        // alert("in deduct**"+scheme.schCode); 
                        let viewKey = scheme.schCode + "o" + this.basicDeductiblesArray[i].code;
                        this.processDeductibles.set(viewKey, this.basicDeductiblesArray[i]);
                        const getDed = this.deductiblesArray.findIndex(v => v.code === this.basicDeductiblesArray[i].code)
                        if (getDed < 0) {
                          this.deductiblesArray[index++] = this.basicDeductiblesArray[i];
                        }
                        //  else {
                        //   this.deductiblesArray[index++] = this.basicDeductiblesArray[i];
                        // }
                      }
                    }
                    // else {
                    //   index = 0;
                    //   for (var i = 0; i < this.basicDeductiblesArray.length; i++) {
                    //     let viewKey = scheme.schCode + "o" + this.basicDeductiblesArray[i].code;
                    //     this.processDeductibles.set(viewKey, this.basicDeductiblesArray[i]);
                    //     const getDed = this.deductiblesArray.findIndex(v => v.code === this.basicDeductiblesArray[i].code)
                    //     if (getDed < 0) {
                    //       this.deductiblesArray[index++] = this.basicDeductiblesArray[i];
                    //     }
                    //   }
                    // }

                  } else {
                    index = 0;
                    for (var i = 0; i < this.basicDeductiblesArray.length; i++) {
                      let viewKey = scheme.schCode + "o" + this.basicDeductiblesArray[i].code;
                      this.processDeductibles.set(viewKey, this.basicDeductiblesArray[i]);
                      const getDed = this.deductiblesArray.findIndex(v => v.code === this.basicDeductiblesArray[i].code)
                      if (getDed < 0) {
                        this.deductiblesArray[index++] = this.basicDeductiblesArray[i];
                      }
                    }
                  }

                  index = 0;
                  for (var i = 0; i < this.basicLoadingChargesArray.length; i++) {
                    let viewKey = scheme.schCode + "o" + this.basicLoadingChargesArray[i].code;
                    this.processLoadingCharges.set(viewKey, this.basicLoadingChargesArray[i]);
                    this.loadingChargesArray[index++] = this.basicLoadingChargesArray[i];
                  }
                }
                //  alert("schIndex is**"+schIndex);
                //   alert("Loading arr len:"+this.deductiblesArray.length)         ;
                //-------------------  Start----------------------------------//

                // for(let scheme of this.schemesList){
                //    for()
                // }
                let cover = [];
                let dedectableArray = [];
                let feesArray = [];
                let loadingArray = [];
                let discountArray = [];
                for (var j = 0; j < this.schemesList.length; j++) {
                  let arr1 = [];
                  let arr2 = [];
                  let arr3 = [];
                  let arr4 = [];
                  let arr5 = [];

                  let obj = { "premium": this.schemes[j].premium, "helpText": this.schemes[j].schDesc, "type": "H" };
                  arr1.push(obj);
                  for (var i = 0; i < this.coversArray.length; i++) {
                    if (this.lobCode == '08') {
                      if (this.processCovers.get(this.schemesList[j].schCode + "c" + this.coversArray[i].coverCode) == undefined) {
                        arr1.push({
                          premium: "NA",
                          type: "U",
                          coverCode: this.coversArray[i].coverCode,
                          prodCode: this.coversArray[i].prodCode,
                          schCode: this.coversArray[i].schCode,
                          helpText: this.coversArray[i].helpText,
                        })
                      } else {
                        arr1.push(this.processCovers.get(this.schemesList[j].schCode + "c" + this.coversArray[i].coverCode));
                      }
                    } else {
                      arr1.push(this.processCovers.get(this.schemesList[j].schCode + "c" + this.coversArray[i].coverCode));
                    }

                  }
                  // for (var i = 0; i < this.coversArray.length; i++) {
                  //   arr1.push(this.processCovers.get(this.schemesList[j].schCode + "c" + this.coversArray[i].coverCode));
                  // }
                  for (var i = 0; i < this.feesArray.length; i++) {
                    let obj = this.processFees.get(this.schemesList[j].schCode + "o" + this.feesArray[i].code);

                    if (obj != undefined) {
                      let obj1 = { "premium": "", "helpText": "Fees" };
                      let obj2 = { "premium": obj.value, "helpText": obj.desc };
                      arr2.push(obj);
                      this.feesvalue.push(obj2);
                      //arr1.push(obj1);
                      //arr1.push(obj2);
                      this.fees = true;
                    }
                  }
                  for (var i = 0; i < this.discountsArray.length; i++) {
                    let obj = this.processDiscounts.get(this.schemesList[j].schCode + "o" + this.discountsArray[i].code);

                    if (obj != undefined) {
                      this.discount = true;
                      arr3.push(obj);
                      let obj1 = { "premium": "", "helpText": "Discounts" };
                      let obj2 = { "premium": obj.value, "helpText": obj.desc };
                      this.discountvalue.push(obj2);
                      //arr1.push(obj1);
                      //arr1.push(obj2);
                    }
                  }
                  for (var i = 0; i < this.deductiblesArray.length; i++) {
                    let obj = this.processDeductibles.get(this.schemesList[j].schCode + "o" + this.deductiblesArray[i].code);
                    if (obj != undefined) {
                      // alert("wen obj !undefined**"+obj.value+"text: "+obj.desc);
                      this.dedectable = true;
                      arr4.push(obj);
                      let obj1 = { "premium": "", "helpText": "Deductibles" };
                      let obj2 = { "premium": obj.value, "helpText": obj.desc };
                      this.dedactablevalue.push(obj2);
                    }
                  }
                  for (var i = 0; i < this.loadingChargesArray.length; i++) {
                    let obj = this.processLoadingCharges.get(this.schemesList[j].schCode + "o" + this.loadingChargesArray[i].code);
                    if (obj != undefined) {
                      this.loading = true;
                      arr5.push(obj);
                      let obj1 = { "premium": "", "helpText": "Loading" };
                      let obj2 = { "premium": obj.value, "helpText": obj.desc };
                      this.loadingvalue.push(obj2);
                      // arr1.push(obj1);
                      //arr1.push(obj2);
                    }
                  }
                  cover.push(arr1);
                  if (arr2.length > 0)
                    feesArray.push(arr2);
                  if (arr3.length > 0)
                    discountArray.push(arr3);
                  if (arr4.length > 0)
                    dedectableArray.push(arr4);
                  if (arr5.length > 0)
                    loadingArray.push(arr5);

                }
                this.coversList = cover;
                this.coversList.forEach((el, val) => {
                  el.filter((element, val) => {
                    if (element != null) {
                      this.coversDetails.push(element);
                    }
                  });
                });
                this.coversDetails = _.uniq(this.coversDetails, function (p) {
                  return p.coverCode;
                });
                let coverOrder = coverResponse.coversArray.map(obj => obj.coverCode);
                this.coversDetails = this.mapOrder(this.coversDetails, coverOrder, 'coverCode');
                this.feesList = feesArray;
                // let accArr;
                // discountArray.forEach(( arr ) => {
                //   if (accArr) {
                //     accArr = [];
                //   }
                //   accArr.push(...arr);
                // });
                // this.discountValueList = discountArray;
                let disArr = [];
                discountArray.forEach(arr => {
                  disArr.push(...(_.uniq(arr, false, (value) => value.code)));
                });
                // if (disArr && disArr.length) {
                //   disArr[0] = _.uniq(disArr[0], false, value => value.code);
                // }
                this.discountList = [_.uniq(disArr, false, (value) => value.code)];

                this.dedectableList = _.uniq(dedectableArray, false, (value) => value.code);

                this.lodingList = loadingArray;
                //alert("dedectableList length is**"+this.dedectableList.length);

                this.processDeductibles.forEach((value: SchemeOtherPrem, key: String) => {
                  // this.processDiscounts.get(key);
                });

                let reqParam = { "transId": this.transId, "tranSrNo": this.tranSrNo };
                this.agentService.getTravelSubCovers(reqParam).subscribe(SubCvrResp => {
                  if (SubCvrResp.respCode == 2000 || SubCvrResp.respCode == 1002) { //' 1002' -No Records Found
                    this.subCvrsArray = SubCvrResp.SubCovers;
                    this.coversToShow = [];
                    for (var c = 0; c < this.coversArray.length; c++) {
                      let cover = new Cover();
                      this.coversToShow[c] = [];

                      let tmpCvrArr = new Map();
                      let tmpSubCvrMap = new Map();
                      let tmpSubCvrArr: any[] = [];
                      //let tmpSubCvrDet : any[] =[];
                      let mapIndex = 0;
                      let subCvrKey;

                      for (let subCvr = 0; subCvr < this.subCvrsArray.length; subCvr++) {
                        if (this.subCvrsArray[subCvr].coverCode == this.coversArray[c].coverCode) {
                          subCvrKey = this.subCvrsArray[subCvr].coverCode + "|" + this.subCvrsArray[subCvr].schCode + "|" + this.subCvrsArray[subCvr].subCvrCode;
                          tmpCvrArr.set(this.subCvrsArray[subCvr].subCvrCode, this.subCvrsArray[subCvr]);
                          tmpSubCvrMap.set(subCvrKey, this.subCvrsArray[subCvr]);
                          //tmpSubCvrDet[subCvr] = this.subCvrsArray[subCvr] ;                           
                        }
                      }
                      tmpCvrArr.forEach((value: Covers, key: string) => {
                        tmpSubCvrArr[mapIndex] = tmpCvrArr.get(key);
                        mapIndex++;
                      });

                      this.tempArray = tmpSubCvrArr

                      for (var s = 0; s < this.schemesList.length; s++) {
                        let tmpSubCvrDet: any[] = [];
                        let viewKey = this.schemesList[s].schCode + "c" + this.coversArray[c].coverCode;
                        let coverObj = this.processCovers.get(viewKey);

                        for (let subCvr = 0; subCvr < tmpSubCvrArr.length; subCvr++) {
                          if (tmpSubCvrArr[subCvr] != undefined) {
                            subCvrKey = tmpSubCvrArr[subCvr].coverCode + "|" + this.schemesList[s].schCode + "|" + tmpSubCvrArr[subCvr].subCvrCode;
                            tmpSubCvrDet[subCvr] = tmpSubCvrMap.get(subCvrKey);
                          }
                        }
                        if (coverObj != null) {
                          cover.coverDesc = coverObj.coverDesc;
                          cover.helpText = coverObj.helpText;
                          if (s == 0) {
                            cover.subCvrArray = tmpSubCvrArr;
                          }
                          this.coversToShow[c][0] = cover;
                        } else {
                          //nothing 
                        }

                        this.coversToShow[c][s + 1] = this.processCovers.get(viewKey);
                        if (this.processCovers.get(viewKey) != undefined) {
                          this.coversToShow[c][s + 1].subCvrArray = tmpSubCvrDet;
                        }
                      }
                    }

                    // for (let i = 0; i < this.coversList.length; i++) {
                    //   for (let j = 0; j < this.coversList[i].length; j++) {
                    //     for (let k = 0; k < this.tempArray.length; k++) {
                    //       if (this.coversList[i][j].premium == "NA" && this.coversList[i][j].type === "U" ) {
                    //         if(this.coversList[i][j].coverCode == this.tempArray[k].coverCode){
                    //         this.coversList[i][j].subCvrArray = this.tempArray;
                    //         this.coversList[i][j].subCvrArray[k].premium = 'NA';
                    //         delete this.coversList[i][j].subCvrArray[k].subCvrCode
                    //         delete this.coversList[i][j].subCvrArray[k].schCode;
                    //         ;
                    //       }      
                    //       }

                    //     }
                    //   }
                    // }
                  }
                  this.loaderService.isBusy = false;
                },
                  error => {
                  });
                this.discountsToShow = [];
                this.discCount = this.discountsArray.length;
                for (var c = 0; c < this.discountsArray.length; c++) {
                  let disc = new SchemeOtherPrem();
                  this.discountsToShow[c] = [];
                  for (var s = 0; s < this.schemesList.length; s++) {
                    let viewKey = this.schemesList[s].schCode + "o" + this.discountsArray[c].code;
                    let discObj = this.processDiscounts.get(viewKey);
                    if (discObj != null) {
                      disc.desc = discObj.desc;
                      this.discountsToShow[c][0] = disc;
                    }
                    this.discountsToShow[c][(s + 1)] = this.processDiscounts.get(viewKey);
                  }
                }
                this.feesToShow = [];
                this.feesCount = this.feesArray.length;
                for (var c = 0; c < this.feesArray.length; c++) {
                  let fees = new SchemeOtherPrem();
                  this.feesToShow[c] = [];
                  for (var s = 0; s < this.schemesList.length; s++) {
                    let viewKey = this.schemesList[s].schCode + "o" + this.feesArray[c].code;
                    let feesObj = this.processFees.get(viewKey);
                    if (feesObj != null) {
                      fees.desc = feesObj.desc;
                      this.feesToShow[c][0] = fees;
                    }
                    this.feesToShow[c][(s + 1)] = this.processFees.get(viewKey);
                  }
                }

                this.deductibleToShow = [];
                this.deductionCount = this.deductiblesArray.length;
                for (var c = 0; c < this.deductiblesArray.length; c++) {
                  let ded = new SchemeOtherPrem();
                  this.deductibleToShow[c] = [];
                  for (var s = 0; s < this.schemesList.length; s++) {
                    let viewKey = this.schemesList[s].schCode + "o" + this.deductiblesArray[c].code;
                    let dedObj = this.processDeductibles.get(viewKey);
                    if (dedObj != null) {
                      ded.desc = dedObj.desc;
                      ded.helpText = dedObj.helpText;
                      this.deductibleToShow[c][0] = ded;
                    }
                    this.deductibleToShow[c][(s + 1)] = this.processDeductibles.get(viewKey);
                  }
                }

                this.loadingChargeToShow = [];
                this.loadingsCount = this.loadingChargesArray.length;
                for (var c = 0; c < this.loadingChargesArray.length; c++) {
                  let loading = new SchemeOtherPrem();
                  this.loadingChargeToShow[c] = [];
                  for (var s = 0; s < this.schemesList.length; s++) {
                    let viewKey = this.schemesList[s].schCode + "o" + this.loadingChargesArray[c].code;
                    let loadingObj = this.processLoadingCharges.get(viewKey);
                    if (loadingObj != null) {
                      loading.desc = loadingObj.desc;
                      this.loadingChargeToShow[c][0] = loading;
                    }
                    this.loadingChargeToShow[c][(s + 1)] = this.processLoadingCharges.get(viewKey);
                  }
                }


                /**********To Display & Verify in Console--Starts */
                /*for(var c=0;c<this.coversToShow.length;c++){                  
                  for(var s=0; s< (this.schemesList.length+1); s++){     
                  }
                } */
                /* for(var c=0;c<this.discountsToShow.length;c++){                  
                   for(var s=0; s< (this.schemesList.length+1); s++){     
                   }
                 }
                 for(var c=0;c<this.feesToShow.length;c++){                  
                   for(var s=0; s< (this.schemesList.length+1); s++){     
                   }
                 }
                 for(var c=0;c<this.deductibleToShow.length;c++){                  
                   for(var s=0; s< (this.schemesList.length+1); s++){     
                   }
                 }*/
                /**********To Display & Verify in Console--End */

                for (let scheme of this.schemes) {
                  for (let schemeCoversArray of scheme.coversArray) {
                    if (schemeCoversArray.coverCondtYN == "1" && (this.travelInsurance || this.pabInsurance)) {
                      let postData = {
                        "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": this.productCode, "schCode": schemeCoversArray.schCode,
                        "coverCode": schemeCoversArray.coverCode
                      }
                    }
                  }

                }
                this.underProcess = false;

              }
            }
          }, error => {
            this.exceptionHandler(error);
          });
        }
      },
        error => {
          this.exceptionHandler(error);
        });
      //this.loaderService.isBusy = false;  
    }, error => {
      this.exceptionHandler(error);
    });
  }


  isDiscountAvailable(discount: any, discountsArray: any[]) {
    if (discount && discountsArray) {
      const index = discountsArray.findIndex((value) => value.code === discount.code);
      return (index > -1) ? true : false;
    } else {
      return false;
    }
  }

  getDiscountValue(discount: any, discountsArray: any[]) {
    if (discount && discountsArray) {
      const dis = discountsArray.find((value) => value.code === discount.code);
      return dis.value;
    } else {
      return '';
    }
  }


  // updateHomePAB_SI(prodCode, schCode, coverCode, event){        
  //   let updateOptionalCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "lobCode": this.lobCode, "portal": ApplicationConstants.SRC_TYPE_AGENT, "prodCode": prodCode, "schCode":schCode, "coverCode": coverCode, "newValue": event.target.value};         
  //   this.agentService.updateHomePAB_SI(updateOptionalCoverData).subscribe(response => {      
  //     if (response.respCode == 2000) {
  //         let cvr :Cover;
  //         for(let i=0; i<this.schemesList.length; i++){
  //           cvr = this.schemesList[i];            
  //           if(prodCode == cvr.prodCode && schCode == cvr.schCode){              
  //             // this.schemesList[i].premium = response.premium; 
  //             let schemesPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo};  
  //             this.getAllSchemes(schemesPostData);
  //           }
  //         }          
  //     }      
  //   },
  //   error =>{
  //     this.exceptionHandler(error);
  //   });    
  // }

  fnChkPremDisplay(coverObj) {
    if ((coverObj.inclYN != '1') || (coverObj.inclYN == '1' && coverObj.type == 'M')
      || (coverObj.inclYN == '1' && coverObj.premium > 0))
      return true;
  }
  fnEnableCheckbox(coverObj) {
    if (coverObj.inclYN == '1' && coverObj.type != 'M' && coverObj.premium > 0)
      return 1; //chk cover and enable chkbox / enable radio and in selected mode and show prem
    else if (coverObj.inclYN != '1' && coverObj.type != 'M' && coverObj.premium > 0)
      return 2; //unchk cover and enable chkbox / enable radio and in de-selected mode and show prem
    else if (coverObj.inclYN == '1' && coverObj.type != 'M' && coverObj.premium == 0)
      return 3; //chk cover and disable chkbox (Basic covers) / show only 'tick' image
    else if (coverObj.inclYN == '1' && coverObj.type == 'M')
      return 4; //show Main Cover Premium 
  }
  getColor(j) {
    if (j != 0)
      //return (this.schemesList[j-1].schColor);
      return "#ffffff";
  }

  processRateCalc(minRate, maxRate, productCode, schemeCode, rateBox: HTMLInputElement) {
    this.rateErr = null;
    let value = rateBox.value;
    if (this.commonService.IsNumeric(value)) {
      if (value.indexOf(".") != -1 && value.length == 1) {
        this.rateErr = "Enter valid number";
      } else {
        if (Number(value) < minRate || Number(value) > maxRate) {
          this.rateErr = "Enter number between " + minRate + " and " + maxRate;
        } else {
          let reqParam = { "rate": value, "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": productCode, "schCode": schemeCode }
          this.agentService.processRateReCal(reqParam).subscribe(response => {
            if (response.respCode == 2000) {
              let schemesPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
              this.getAllSchemes(schemesPostData);
              //this.ngOnInit();
            }
          }, error => {
            this.exceptionHandler(error);
          });
        }
      }
    } else {
      this.rateErr = "Enter valid number";
    }
  }

  proceedToAdditionalInfo(prodCode, schCode) {
    let reqParam = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": prodCode, "schCode": schCode, "portal": ApplicationConstants.SRC_TYPE_AGENT };
    this.agentService.proceedToBuyPkgCall(reqParam).subscribe(response => {
      if (response.respCode == 2000) {
        let navPath = "";
        if (this.instlYn != undefined && this.instlYn != null && this.lobCode == ApplicationConstants.LOB_MOTOR) {
          var obj = {
            instYN: this.installAccess,
            transId: this.transId,
            tranSrNo: this.tranSrNo
          };
          this.agentService.callInstallmentProcedure(obj).subscribe(data => {

            navPath = "motoraddlinfo";
            this.router.navigate([navPath], { queryParams: { 'transId': this.transId, 'quoteNo': this.quoteNo, 'tranSrNo': this.tranSrNo, 'prodCode': prodCode, 'schCode': schCode, 'lobCode': this.lobCode, 'polStartDate': this.polStartDate, 'polEndDate': this.polEndDate, policyNo: this.policyNo }, skipLocationChange: true });
          });
        } else {
          if (this.lobCode == ApplicationConstants.LOB_MOTOR)
            navPath = "motoraddlinfo";
          else if (this.lobCode == ApplicationConstants.LOB_TRAVEL)
            navPath = "traveladdlinfo";
          else if (this.lobCode == ApplicationConstants.LOB_MARINE_HULL) {
            navPath = "marineaddlInfo";
            this.router.navigate([navPath], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'quoteNo': this.quoteNo, 'prodCode': prodCode, 'schCode': schCode, 'lobCode': this.lobCode, 'polStartDate': this.polStartDate, 'polEndDate': this.polEndDate, policyNo: this.policyNo }, skipLocationChange: true });
          } else if (this.lobCode == ApplicationConstants.LOB_HOME)
            navPath = "homeaddlinfo";
          //navPath   ="quote-confirm";
          //this.router.navigate(['quote-confirm', {'transId':this.transId,'tranSrNo':this.tranSrNo,'mode':'saveQuote1'}]);         
          this.router.navigate([navPath], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'quoteNo': this.quoteNo, 'prodCode': prodCode, 'schCode': schCode, 'lobCode': this.lobCode, 'polStartDate': this.polStartDate, 'polEndDate': this.polEndDate, policyNo: this.policyNo }, skipLocationChange: true });
        }
      }

    }, error => {
      this.exceptionHandler(error);
    });

  }


  getPrimaryInfo() {
    let obj = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      "quoteNo": this.quoteNo,
      policyNo: this.policyNo
    };
    if (this.lobCode == ApplicationConstants.LOB_MOTOR) {
      this.router.navigate(['motor'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCode == ApplicationConstants.LOB_HOME) {
      this.router.navigate(['home'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCode == ApplicationConstants.LOB_TRAVEL) {
      this.router.navigate(['travel'], { queryParams: obj, skipLocationChange: true });
    } else if (this.lobCode == ApplicationConstants.LOB_MARINE_HULL) {
      this.router.navigate(['marine_hull'], { queryParams: obj, skipLocationChange: true });
    }

  }


  exceptionHandler(errorMsg) {
    this.underProcess = false;
    this.errorMsg = errorMsg;
  }





  updateHomePAB_SI(scheme, cover1, value, id) {
    // alert("update home called")
    let updateOptionalCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "lobCode": this.lobCode, "portal": ApplicationConstants.SRC_TYPE_AGENT, "prodCode": scheme.prodCode, "schCode": scheme.schCode, "coverCode": cover1.coverCode, "newValue": value };
    this.agentService.updateHomePAB_SI(updateOptionalCoverData).subscribe(response => {
      if (response.respCode == 2000) {
        let schemesPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
        this.agentService.getSchemeCovers(schemesPostData).subscribe(schemeResponse => {
          if (schemeResponse.respCode == 2000) {
            let premium;
            let schemeList = schemeResponse.schemesArray[id];
            schemeList.coversArray.forEach((schemes, index1) => {
              if (schemes.type == 'O' && schemes.coverCode == cover1.coverCode) {
                premium = schemes.premium;
              }

            });
            this.coversList.forEach((scheme, index1) => {
              scheme.forEach((cover, index) => {
                if (id == index1) {
                  if (cover.type == 'O' && cover.coverCode == cover1.coverCode) {
                    cover.premium = premium;
                  }
                  if (index == 0) {
                    cover.premium = parseInt(cover.premium) + parseInt(premium) - parseInt(cover1.premium);
                  }

                }
              });
            });
          }

        });
      }
    },
      error => {
        this.exceptionHandler(error);
      });
  }



  // updateHomePAB_SI(scheme,cover,value){ 

  //   let updateOptionalCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "lobCode": this.lobCode, "portal": ApplicationConstants.SRC_TYPE_AGENT, "prodCode": scheme.prodCode, "schCode":scheme.schCode, "coverCode": cover.coverCode, "newValue": value};         
  //   this.agentService.updateHomePAB_SI(updateOptionalCoverData).subscribe(response => {      
  //     if (response.respCode == 2000) {

  //         let cvr :Cover;
  //         for(let i=0; i<this.schemesList.length; i++){
  //           cvr = this.schemesList[i];            
  //           if(scheme.prodCode == cvr.prodCode && scheme.schCode == cvr.schCode){     

  //             // this.schemesList[i].premium = response.premium; 
  //            //;let schemesPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo};  
  //             //this.getAllSchemes(schemesPostData);
  //            // this.ngOnInit();
  //           }
  //         }          
  //     }      
  //   },
  //   error =>{
  //     this.exceptionHandler(error);
  //   });    
  // }
  tranType: any;
  getReportt(reportType) {

    this.commonService.getReport(this.transId, this.tranSrNo, reportType, this.session.get("portaltype"),
      this.tranType,// Trantype
      'undefined', 'undefined' //risk sr no 
    );
    // this.AgentDashboardComponent.getReport(reportType);

  }

  enableSelectBox(id, checkId, scheme, cover, pre) {
    let selectId = id + "_" + pre;
    $("#" + selectId).prop("disabled", false);
    let premium = 0;
    this.coversList.forEach((scheme, index1) => {
      scheme.forEach((cover, index) => {
        if (id == index1) {
          if (index == 0) {
            if ($("#" + checkId).prop("checked") == true) {
              premium = parseInt(cover.premium) + parseInt(pre);
            } else if ($("#" + checkId).prop("checked") == false) {
              premium = parseInt(cover.premium) - parseInt(pre);
            }
            cover.premium = premium;
          }

        }
      });
    });
  }

  updateCoverStatus(id, checkId, scheme, cover, pre, lob) {
    this.loaderService.isBusy = true;
    let mode;
    if (checkId == true) {
      // alert("in iff**");
      mode = "1";
    } else if (checkId == false) {
      //  alert("in elsee**");
      mode = "0";
    }


    let updateOptionalCoverData = { "transId": this.transId, "tranSrNo": this.tranSrNo, "prodCode": scheme.prodCode, "schCode": scheme.schCode, "coverCode": cover.coverCode, "mode": mode };
    this.agentService.updateOptionalCover(updateOptionalCoverData).subscribe(response => {
      if (response.respCode == 2000) {
        let selectId = id + "_" + pre;
        $("#" + selectId).prop("disabled", false);
        let premium = 0;
        this.coversList.forEach((scheme, index1) => {
          scheme.forEach((cover, index) => {
            if (id == index1) {
              if (index == 0) {
                if (checkId == true) {
                  premium = parseInt(cover.premium) + parseInt(pre);
                } else if (checkId == false) {
                  premium = parseInt(cover.premium) - parseInt(pre);
                  $("select[id^='0']").prop('disabled', 'disabled');
                  $("select[id^='1']").prop('disabled', 'disabled');
                }
                cover.premium = premium;
              }

            }
          });
        });
        // window.location.reload();
        // this.ngOnInit();
        if (lob == '04') {
          // window.location.reload();
          this.loaderService.isBusy = true;
        }
        // let schemesPostData = { "transId": this.transId, "tranSrNo": this.tranSrNo };
        // this.getAllSchemes(schemesPostData);
      }
    },
      error => {
        this.exceptionHandler(error);
      });
  }

  getReport(type) {
    this.commonService.getReport(this.transId, this.tranSrNo, type, this.session.get("portaltype"), "", "", "");
  }
  updProdSchCode(prodCode, schCode) {
    this.loaderService.isBusy = true;
    const data = {
      "transId": this.transId,
      "tranSrNo": this.tranSrNo,
      'mapId': 'AGENT_UPD_PROD_SCH',
      "prodCode": prodCode,
      "schCode": schCode
    };

    this.agentService.updateInsInfo(data).subscribe(result => {
      if (result) {
        let params = {
          "transId": data.transId,
          "tranSrNo": data.tranSrNo,
          "reportType": 'QUOT_FORM',
          "tranType": 'QOT'
        }
        this.commonService.getReportUrl(params);
        this.loaderService.isBusy = false;

      }
    })
  }

  mapOrder(array, order, key) {
    array.sort(function (a, b) {
      var A = a[key], B = b[key];
      if (order.indexOf(A) > order.indexOf(B)) return 1;
      else return -1;
    });
    return array;
  };
}
