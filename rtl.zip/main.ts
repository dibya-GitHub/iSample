import { ModuleRegistry } from '@ag-grid-community/core';
import { AllModules } from '@ag-grid-enterprise/all-modules';
import { LicenseManager } from '@ag-grid-enterprise/core';
import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

LicenseManager.setLicenseKey('CompanyName=Qatar Insurance Company,LicensedGroup=Varunkumar Mungara,LicenseType=MultipleApplications,LicensedConcurrentDeveloperCount=1,LicensedProductionInstancesCount=0,AssetReference=AG-015448,ExpiryDate=2_June_2022_[v2]_MTY1NDEyNDQwMDAwMA==053eb35c47b4e8622a525ebf44d4d702');
ModuleRegistry.registerModules(AllModules);
if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
