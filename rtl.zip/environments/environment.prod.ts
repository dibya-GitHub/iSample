export const environment = {
  production: true,
  baseUrl: 'https://www.devapi.anoudapps.com/angularservices/',
  siteKey: '6Lf_4i0UAAAAAJPEeCj0_juPW5X38FQFghcFRDqP'
};