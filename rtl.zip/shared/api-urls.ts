export class ApiUrls {
    public static VERIFY_AGENT_LOGIN = 'agentPortalLogin';
    public static GET_AGENT_SCHEMES = 'getAgentSchemes';
    public static GET_SCHEMECOVERS_URL = 'getAgentSchemeCovers';
    public static GET_ALLCOVERS_URL = 'getAgentProdCovers';
    public static GET_TRAVEL_SUB_COVERS = 'getTravelSubCovers';
    public static UPDATE_OPTIONAL_COVER_URL = 'updateOptCover';
    public static PROCESS_RATE_RE_CALC = 'processPremRateReCal';
    public static GET_CONFIRM_SCREEN_DATA = 'confirmAgentQuote';
    public static GET_AGENT_SESSION_PROPS = 'getAgentSessionProps';
    public static PROCEED_TO_BUY_PKG = 'updProdSch';
    public static UPDATE_PABHOME_SI = 'updatePabHomeSumAssured';
    public static GET_LOB_LIST = 'getLobList';
    public static GET_QUOTE_DETAILS = 'getQuoteList';
    public static GET_POLICY_DETAILS = 'getPolList';
    public static GET_ACT_CLM_POLICY_DETAILS = 'getClaimPolList';
    public static GET_BUSINESS_DETAILS = 'getBusinessDetails';
    public static GET_REPORT_URL = 'getAnoudReports';
    public static GET_COVER_DOC_URL = 'getCovDoc';
    public static GET_USER_LIST = 'getUserList';
    public static GET_SCHEME_LIST = 'getSchemeList';
    public static GET_PRINT_REPORT_URL = 'printAgentReport';
    public static GET_DOC_INFO_URL = 'uploadDocInformation';
    public static GET_FILE_URL = 'getFileUrl';
    public static VIEW_POLICY_DETAILS = 'viewPolicy';
    public static GET_POL_APPR_REQ = 'getPolicyRequestDet';
    public static GET_POLICY_REQ = 'getPolicyRequest';
    public static UPD_USER_AGENT_MSG = 'updateUserMsg';
    public static GET_USER_AGENT_MSG = 'getUserMsg';
    public static GET_POLICY_BUSINESS_DETAILS = 'getPolicyBusinessDetails';
    public static AGENT_RESET_PWD = 'empResetPassword';
    public static AGENT_LOGOUT = 'empLogOut';


    // Endorsment //
    public static GET_ENDORSEMENT_TYPE = 'getEndorsementTypes';
    public static GET_ENDORSEMENT_REN_DATES = 'getEndorsementRenDates';
    public static VALIDATE_ENDORSEMENT_DATES = 'validateEndorseDates';
    public static GET_CAL_TYPE = 'getCalculationTypes';
    public static CHECK_END_DATA = 'checkEndorsedData';
    public static CALL_END_PACKAGE = 'callEndorsePackage';
    public static UPDATE_ENDORSE_BASIC_DETAILS = 'callEndorsePackage';
    public static GET_END_DETAILS = 'getEndorseDetails';
    public static END_PROCEED_TO_BUY = "endtProceedtoBuy";
    public static END_FLEET_PROCEED_TO_BUY = "fleetApprove";
    public static CANCEL_ENDORSEMENT = "cancelEndrosement";
    public static GET_DMS_TYPE_LIST = "getDMSTypeList";
    public static GET_SCH_PROD_DETAILS = "getSchemeProdDetails";



    public static GET_CURRENCY_TYPE_URL = 'getCurencyType';
    public static GET_COUNT_URL = 'getCount';
    public static GET_UWQUESTIONS_URL = 'getUWQuestions';
    public static CREATE_QUOTE_URL = 'createQuote';
    public static UPDATE_INSURED_INFO_URL = 'updateInsInfo';
    public static UPDATE_HOME_INFO_URL = 'updHomeInfo';
    public static CALCULATE_PRICING_URL = 'calcPricing';
    public static GET_ALL_COVERS_URL = 'getAllCovers';
    public static GET_QUOTE_HOME_INFO = 'getQuoteHomeInfo';
    public static GET_APPL_REF_CODES = 'getApplRefCodes';
    public static GET_APPL_CODES = 'getApplCodes';
    public static GET_APPL_COUNTRY_CODES = 'getApplCountryCodes';
    public static GET_QUOT_INFO = 'getQuotInfo';
    public static GET_HEADER_INFO = 'getHeaderInformation';
    public static GET_COVER_SUMMARY = 'getCovSumm';
    public static GET_PREMIUM_SUMMARY = 'getNetPremSumm';
    public static GET_DISC_DED_LOAD_FEES_SUMMARY_URL = 'getDiscDedLoadFeesSumm';
    public static UPLOAD_DOCUMENTS = 'upldDoc';

    public static APPROVE_POLICY = 'approvePolicy';
    public static MOTOR_MAKE_LIST = "getFilterdVehMake";
    public static MOTOR_MODEL_LIST = "getApplRefCodes";
    public static MOTOR_BODY_LIST = "getVehType";
    public static MOTOR_USAGE_LIST = "getVehUsage";
    public static MOTOR_APPL_LIST = "getApplCodes";
    public static CREATE_QUOTATION = "createQuote";
    public static UPDATE_INSURED_INFO = "updateInsInfo";
    public static UPDATE_VEHICLE_INFO = "updateVehInfo";
    public static CALCULATE_PRICING = "calcPricing";
    public static GET_QUOTE_INFO = "getQuotInfo";
    public static MOTOR_APPL_PARAM_LIST = "getApplParam";
    public static GET_DIS_DUCT_SUMMARY = "getDiscDedLoadFeesSumm";
    public static GET_VEH_INFO = "getVehicleInfo";
    public static GET_NET_PREMIUM = "getAgentNetPremSumm";
    public static INSERT_ADDL_DRIVER_INFO = "insertAddlDriverInfo";
    public static APPROVE_AGENT_POLICY = "approveAgentPolicy";
    public static VAL_DUP_CHASSIS_NO = "valDupChassisNo";
    public static CHECK_CHASSIS_FLOW = "valChassisNoWhileChassisFlow";
    public static CHECK_EDATA_CHASSIS_NO = "checkEdataChassisFlow";
    public static VALIDATE_PKG_DUP_CHASSIS_NO = 'valDupChassisNoPkg'
    public static ALLOW_CHASSIS_NO = "allowChassisNo";
    public static GET_AGENT_AUTH_DTLS = "getAgentAuthDetails";
    public static UPLOAD_DOC = "upldDoc";
    public static GET_INSURED_DTLS = "getQuotInsInfo";
    public static GET_CERT_QUOT_DTLS = "getcertQuoteInfo";
    public static GET_EDATA_VEH_INFO = "getEdataVehicleInfo";
    public static UPDATE_EDATA_VEH_INFO = "updateEdataVehInfo";
    public static GET_EDATA_CODE = "getEdataCode";
    public static GET_EDATA_BODY_TYPE_LIST = "getEdataBodyTypeList";
    public static UPDATE_VEHICLE_TRIM_DET = "updateVehTrim";
    public static APPR_WF_REQ = 'approveWorkflowReq';
    public static GET_PI_POL_DTLS = 'getPendingInfoPolDetails';
    public static GEN_AND_UPLD_PROPFORM = 'generateAndUploadProposalForm';

    public static UPDATE_INSTALL_FLAG = "updateInstFlag";
    public static GET_ISTALLMENT_DETLS = "dispInst";
    public static INSERT_ERROR_MSG = "insertErrorLog"
    public static CHECK_POLICY_FOR_RENEWAL = "chkPolicyForRenewal";
    public static CHECK_CHASSIS_EXISTS = "chkChassisExists";
    public static GET_QUOT_INS_INFO = 'getQuotInsInfo';
    public static GET_DISCRIPTION_DETLS = "getDiscriptionList";
    public static GET_HOME_INFO = 'getHomeInfo';
    public static GET_POLICY_INFO = 'getPolInfo';
    public static GET_DOC_LIST = 'getDocumentList';
    public static GET_POL_DURATION = 'getPolDuration';

    public static GET_DRIVER_DETLS = "getDriverDetls";
    public static INSERT_OTHER_DETLS = "insertQuoteOtherInfo";
    public static GET_OTHER_DETLS = "getAddtionalOtherInfo";
    public static PROCEED_TO_BUY = 'endtProceedtoBuy';

    public static GET_TRAVEL_DETAILS = 'getTravelerDetls';
    public static GET_APP_CODES_COUNTRY = 'getApplCountryCodes';


    // ------Travel---------------//

    public static GET_APP_CODES = 'getApplCodes';
    public static GET_APP_REF_CODES = 'getApplRefCodes';
    public static GET_APP_PARAM = 'getApplParam';
    public static QUOTE_URL = 'createQuote';
    public static UPDATE_TRAVEL_INFO_URL = 'updTravelInfo';
    public static UPDATE_TRAVEL_ADDL_INFO_URL = 'updTravelAdditionalInfo';
    public static GET_TRAVEL_ADDL_INFO_URL = 'getTravelAdditionalInfo';
    public static GET_QUOTE_TRAVEL_INFO = 'getQuoteTravelInfo';
    public static GET_DISC_LOAD_SUM = 'getDiscDedLoadFeesSumm';
    public static GET_PREM_SUMM = 'getCovSumm';
    public static GET_AGENT_PREM = 'getAgentNetPremSumm';
    public static GET_BOUND_TYPE = 'getApplParam';
    public static GET_COUNTRY_LIST = 'getApplCodes';
    public static INS_TRAVEL_INFO = 'insTravelerDetls';
    public static ADJUST_POLICY_PKG = 'adjustPolicy';
    public static GET_AGENT_FILTER = 'getAgentFilterInfo';
    public static GET_AGENT_USER_NAME = "getUserName";
    public static GET_AGENT_TOKEN = "token";

    public static AGENT_FORGOT_PWD = "empForgetPassword";
    public static EXCEL_EXPORT_URL = 'excelExport';
    public static GET_POLICY_HISTORY = 'getHistoryDetails';
    public static EDATA_SUM_INSURED_VALIDATION = 'edataSumInsuredValidation';
    public static GET_COVER_INFO = 'getCoversInfo';
    public static GET_CLAIM_INFO = 'getAgentPolicyClaimsInfo';
    public static GET_CLAIM_RATIO_INFO = 'getAgentClaimsLossRatio';
    public static GET_ADDL_COVER_INFO = 'getAddlCoverList';
    public static DEL_ADDL_COVER = 'deleteAddlCovers';
    public static INCL_EXCL_COVER = 'includeExcludeCover';
    public static GET_OPT_COVER = 'getOptionalCovers';
    public static GET_TAX_COVER = 'getApplTaxes';
    public static GET_PREM_COVER_INFO = 'getPremiumInfo';
    public static END_PRCED_CONFRM = 'endtProceedToConfirm';
    public static GET_DEL_COVER_INFO = 'getDelCoverSumm';
    public static GET_FLEET_POLICY_LIST = 'getFleetPolicyList';
    public static GET_AGENT_DASH_URL = 'getAgentDashboardUrl';
    public static GET_FLEET_VEH_LIST = 'getFleetvehicleList';
    public static GET_FLEET_VEHICLE_INFO = 'getFleetvehicleList';

    public static GET_VEH_DETAILS = 'getQuotVehicleInfo';
    public static GET_POL_TAX_LIST = 'getPolicyTaxes';
    public static GET_EDIT_FLAG = 'getEditTaxFlag';
    public static GET_WIN_SPRTS_FLAG = 'getWinSprtsYN';
    public static GET_TAX_APPL_FLAG = "getTaxApplYN"

    public static GET_EDATA_QUOTE_INFO = 'eDataQuoteInfo';
    public static GET_EDATA_ENGINE_SIZE = 'eDataEngineSizeList';
    public static EDATA_TRIM_LIST = 'eDataTrimList';
    public static EDATA_EVALUATION = 'eDataEvaluation';
    public static CALL_INST_PROC = 'callAgentInstProc'
    public static DISP_INST_DETLS = 'displayInstallments';
    public static UPDATE_INST_DETLS = 'updateInstallStatus';
    public static GET_ADME_ID = 'getAdmeId';
    public static UPDATE_POL_DURATION = "updatePolicyDuration";

    public static GET_VECHILE_INFO_BY_CHASSIS = 'autoDataVehicleInfo';
    public static GET_MODEL_YEAR = 'autoDataYear';
    public static GET_MAKE_LIST = 'autoDataMake';
    public static GET_MODEL_LIST = 'autoDataModel';
    public static GET_SPECIFICATIONS = 'autoDataSpecification';
    public static GET_AUTODATA_VEH_DETAILS = 'autoDataVehDetails';
    public static GET_QUOTE = 'autoDataQuoteDetails';

    // For Payment //

    public static REG_PAYMENT = 'regPaymt';
    public static GET_PAYMENT_OPTIONS_URL = 'getPaymtOpt';
    public static GET_AGENT_LIST = 'getCustomerList';
    public static UPDATE_AGENT_COMMISSON = 'updAgentCommInfo';

    // For New changes //

    public static GET_AGENT_USERS = 'agentUserInfo';
    public static GET_QUOTES = 'quotationInfo';
    public static GET_POLICIES = 'renewalPolicyInfo';
    public static GET_MY_DASHBOARD = 'myDashboardInfo';
    public static GET_STATUS_TRACK_INFO = 'requestTrackStatus';

    public static GET_DROPDOWN_VALUES = 'parameterInfo';
    public static GET_REQUEST_DETAILS = 'endorsementApprovalRequestDetails';
    public static GET_POLICY_DETAIL_VIEW = 'parameterInfo';
    public static UPDATE_POLICY_APPROVE = 'parameterInfo';
    public static UPDATE_POLICY_REJECT = 'parameterInfo';
    public static GET_DOCS = 'getUploadedDocumentList';
    public static VIEW_DOCS = 'viewDocument';
    public static GET_YACHT_INFO = 'yachtInfo';
    public static SEND_PAY_LINK = 'sendPayLink';
    // public static G = 'agentUserInfo';

    // for Pleasure Craft
    public static UPDATE_BOAT_INFO = 'updateBoatInfo';
    public static GET_PRODUCTS = 'getProducts';
    public static GET_BOAT_QUOTE_RISK_INFO = 'getBoatQuoteRiskInfo';

    //Home Content Block
    public static GET_HOME_CONTENT_SERVENT_INFO = 'getHomeConentServantInfo';
    public static INSERT_CONTENT_DETAILS = 'insContentDetls';
    public static GET_CONTENT_DETAILS = 'getContentDetls';
    public static GET_POLICY_CONTENT_DETAILS = 'getPolicyContentDetls';

    //Marine insurance
    public static GET_PRODUCTLIST = 'getMarineProducts';
    public static GET_MARINE_INFO = 'getMarinePolInfo';
    public static GET_CREATE_CERTIFICATE = 'createCertificate';
    public static GET_MARINE_TYPES = 'getMarineTypes';
    public static GET_PORT = 'getPorts';

    //Claims Intimation

    public static CALL_OD_REG_CLAIMS = 'registerODClaims'
    public static CALL_TP_REG_CLAIMS = 'registerTPClaims'
    public static GET_CLM_VEH_INFO = 'getPolVehicleInfo'
}



