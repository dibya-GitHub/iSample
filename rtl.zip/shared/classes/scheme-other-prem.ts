export class SchemeOtherPrem {
  code: string;
  desc: string;
  helpText: string;
  value: string;
  errMessage: string
}
