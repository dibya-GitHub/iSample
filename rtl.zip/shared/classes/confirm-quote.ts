export class ConfirmQuote {
  quoteNo: string;
  quoteIssueDt: string;
  quoteValidDays: string;
  emailId: string;
  lobCode: string;
  mobileNo: string;
  insuredName: string;
  prodDesc: string;
  schDesc: string;
  currDesc: string;
  compName: string;
  address1: string;
  address2: string;
  address3: string;
  compEmail: string;
  compTelephone: string;
  premium: string;
  respCode: string;
  errMessage: string;
}
