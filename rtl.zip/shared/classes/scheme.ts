export class Scheme {
  schCode: string;
  schDesc: string;
  helpText: string;
  schColor: string;
  errMessage: string;
}

export class ReloadCharges {
  optionalCode: string;
  description: string;
  descriptionValue: string;
  optionalValue: string;
  type: string;
  transId: string;
  tranSrNo: number;
  endType: string;
  rate: string;
  selectedDesc: string
  typeDesc: string;
}
