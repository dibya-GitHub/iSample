export class Product {
    key: string;
    value: string;
    info1: string;
}