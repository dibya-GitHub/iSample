export class Search {
  constructor(public id: string, public name: string) { }
}