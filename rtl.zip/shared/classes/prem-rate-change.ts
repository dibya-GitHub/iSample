export class PremRateChange {
	prodCode: string;
	schCode: string;
	minRate: string;
	maxRate: string;
	rate: string;
	type: string;
	include: string;
}
