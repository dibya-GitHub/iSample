
export class EndorsedData {
  transId: string;
  tranSrNo: string;
  address1: string;
  address2: string;
  emailId: string;
  mobileNo: string;
  poBox: string;
  city: string;
  nationality: string;
  reason: string;
  cardAuthCode: string;
  insName: string;
  insNameAr: string;
  customerType: string;
  emiratesId: string;
  occupation: string;
  constructor() { }
}