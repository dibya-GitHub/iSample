export class Quote {
    quoteNo?: string;
    lobDesc?: string;
    insName?: string;
    quotIssDate?: string;
    transId?: string;
    tranSrNo?: string;
    policyNo?: string;
    polStartDate?: string;
    polEndDate?: string;
    lobCode?: String;
    prodCode?: String;
    schCode?: String;
}