export class Test {
    tes1: Array<string>;
    tes2: Array<number>;
}