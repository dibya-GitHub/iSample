export class Business {
   key: string;
   value: string;
   info1: string;
   info2: string;
}