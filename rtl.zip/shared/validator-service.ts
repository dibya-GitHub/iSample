export class ValidatorService {
  flag: boolean = true;

  validateString(inputString: string) {
    if (inputString == null || "" === inputString || "select" === inputString
      || "null" === inputString) {
      this.flag = false;
    } else {
      this.flag = true;
    }
    return this.flag;
  }
}