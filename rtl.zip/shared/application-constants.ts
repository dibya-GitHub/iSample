import { Inject } from '@angular/core';
export class ApplicationConstants {
    public static DOHA_COUNTRY_CODE = '001';
    public static DUBAI_COUNTRY_CODE = '002';
    public static KUWAIT_COUNTRY_CODE = '005';
    public static OMAN_COUNTRY_CODE = '006';
    public static SESSION_SRC_TYPE_AGENT = "A";
    public static SRC_TYPE_AGENT = "A";
    public static LOB_MOTOR = "01";
    public static LOB_HOME = "04";
    public static LOB_TRAVEL = "08";
    public static LOB_MARINE_HULL = "06";
    public static LOB_MARINE_INSURANCE = "03";


    public static DUBAI_CIVIL_ID_LENGTH = '^[0-9-]{18,18}$';
    public static DOHA_CIVIL_ID_LENGTH = '^[0-9-]{11,11}$';
    public static KUWAIT_CIVIL_ID_LENGTH = '^[0-9-]{12,12}$';
    public static OMAN_CIVIL_ID_LENGTH = '^[0-9-]{9,9}$';


    public static DOHA_MOBILE_LENGTH = '^[0-9]{8,8}$';
    public static DUBAI_MOBILE_LENGTH = '^[0-9]{10,10}$';
    public static KUWAIT_MOBILE_LENGTH = '^[0-9]{8,8}$';
    public static OMAN_MOBILE_LENGTH = '^[0-9]{8,8}$';

    public static DOHA_MOBILE_STARTS_WITH = '[3567]{1,1}[0-9]{8,8}'
    public static DUBAI_MOBILE_STARTS_WITH = '[05]{1,1}[0-9]{8,8}'
    public static KUWAIT_MOBILE_STARTS_WITH = '[569]{1,1}[0-9]{8,8}'
    public static OMAN_MOBILE_STARTS_WITH = '[135789]{1,1}[0-9]{8,8}'


    public static DOHA_CURR_CODE = "QAR";
    public static OMAN_CURR_CODE = "OMR";
    public static DUBAI_CURR_CODE = "AED";

    public static ENDORSE_TYPE_NON_FINANCIAL = "001";
    public static ENDORSE_TYPE_RENEWAL = "002";
    public static ENDORSE_TYPE_EXTENSION = "003";
    public static ENDORSE_TYPE_ADD_COVER = "004";
    public static ENDORSE_TYPE_DEL_COVER = "005";
    public static ENDORSE_TYPE_ADD_VEHICLE = "006";
    public static ENDORSE_TYPE_DEL_VEHICLE = "007";
    public static ENDORSE_TYPE_CANCELLATION = "008";
    public static ENDORSE_TYPE_CHANGE_OWNER = "009";
    public static ENDORSE_TYPE_CHANGE_SI = "010";
    public static ENDORSE_TYPE_REINST = "011";
    public static ENDORSE_TYPE_BROKER_COMM = "012";
    public static ENDORSE_TYPE_ADJUST_PREMSI = "013";
    public static ENDORSE_TYPE_FLEET_CERT = "016";
    public static ENDORSE_TYPE_CERT_INDIVIDUAL = "024";
    public static ENDORSE_TYPE_VEH_PARAMS = "017";
    public static ENDORSE_TYPE_TP_TO_OD = "018";
    public static ENDORSE_TYPE_CHANGE_IN_PERIOD = "019";
    public static ENDORSE_TYPE_CHANGE_VEHICLE_USAGE = "022";


}
