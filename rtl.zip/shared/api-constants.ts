export class ApiConstants {
  public static CAR_INSURANCE_LOBCODE = '01';
  public static HOME_INSURANCE_LOBCODE = '04';
  public static CYCLE_INSURANCE_LOBCODE = '04';
  public static TRAVEL_INSURANCE_LOBCODE = '08';
  public static PAB_INSURANCE_LOBCODE = '08';
  public static USER_ID = 'evan';
  public static PORTAL = 'A';
  public static LOCATION = 'A';
  public static COMPANY = '002';
  public static CURRENCY = 'AED';
  public static MARINE_HULL_LOBCODE = '06';
}
