import { TestBed, inject } from '@angular/core/testing';

import { ApiHeadersService } from './api-header.service';

describe('ApiHeaderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiHeadersService]
    });
  });

  it('should be created', inject([ApiHeadersService], (service: ApiHeadersService) => {
    expect(service).toBeTruthy();
  }));
});
