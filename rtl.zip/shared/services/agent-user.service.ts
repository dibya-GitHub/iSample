import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { Observable, Subject, map } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApplicationConstants } from "../../shared/application-constants";
import { ErrorMessage } from "../../shared/error-message";
import { ApiUrls } from '../api-urls';
import { LoaderService } from '../loader-service/loader.service';
import { ApiHeadersService } from '../services/api-header.service';

@Injectable({
  providedIn: 'root'
})
export class AgentUserService {

  public requestOption;
  public baseUrl = environment.baseUrl;
  public headers;
  public searchHeaders;
  public searchOption;
  private _subject = new Subject<any>();
  //this.session.get("access_token")
  // public accessControl = new Headers({ 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' })

  public urlParams: any;
  public encodedKey = 'MTEzNzE2OmI0OTllMTRiLTc4YWYtNDYwZi1iMjJmLWU0ZGMzMDRjMmU3NA==';
  public edataEncodeKey = 'MzJjZDgwNmYtNjExYy00YzMxLWEyNjEtNDhlNmZiOTMwZDI1OmJjM2Q4M2U5LWY4YzAtNDE4YS05MjA2LTgyNGMzNGRlYzM3Nw==';

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    public loaderService: LoaderService,
    private session: SessionStorageService,
    private apiHeadersService: ApiHeadersService,

  ) {

    const headers = new Headers();
    headers.append("Authorization", "Basic " + this.encodedKey);
    headers.append('company', '002');
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    this.requestOption = { headers: headers };

  }

  verifyAgentLogin(body: any) {
    let data = new URLSearchParams();
    data.set('username', body.username);
    data.set('password', body.password);
    data.set('portalType', body.portalType);
    data.set('grant_type', body.grant_type);
    data.set('scope', body.scope);
    data.set('key', body.key);
    return this.http.post("https://www.devapi.anoudapps.com/auth/oauth/v2/token", data.toString(), this.searchOption);
  }

  getRefershToken(body: any) {
    let data = new URLSearchParams();
    data.set('refresh_token', body.refresh_token);
    data.set('grant_type', body.grant_type);
    data.set('scope', body.scope);
    return this.http.post("https://www.devapi.anoudapps.com/auth/oauth/v2/token", data.toString(), this.searchOption);
  }
  revokeToken(body: any) {
    let data = new URLSearchParams();
    data.set('token_type_hint', body.token_type_hint);
    data.set('token', body.token);
    return this.http.post("https://www.devapi.anoudapps.com/auth/oauth/v2/token/revoke", data.toString(), this.searchOption);
  }

  agentLogout(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.AGENT_LOGOUT + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  resetPassword(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.AGENT_RESET_PWD + '?company=' + this.session.get('companyCode'), body)
      .pipe(map((response: Response) => {
        return response.json();

      }));
  }

  getHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_HOME_INFO + '?company=' + this.session.get('companyCode'), body)
  }

  // getVehicleMake(body : any) :Observable<VehicleMakes>  {
  //   this.searchHeaders = new Headers({ 'Authorization': 'Bearer '+this.session.get('access_token'),'Content-Type': 'application/json', })
  //   this.searchOption = new RequestOptions({ headers: this.searchHeaders }) 
  //   return this.http.get(this.baseUrl+ ApiUrls.MOTOR_MAKE_LIST+'?company='+this.session.get('companyCode')+'&groupCode='+body.groupCode+'&makeFliterYn='+body.makeFliterYn,this.searchOption)
  //   .pipe(map((response: Response) => {
  //    return response.json();

  // }));
  // }

  getVehicleModel(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.MOTOR_MODEL_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getVehicleType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.MOTOR_BODY_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getUsageList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.MOTOR_USAGE_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  // ---------- Product List ----------//
  getProducts(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_LOB_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)

  }

  // ---------- Scheme List ----------//
  getSchemeList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_SCHEME_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)

  }

  // ---------- User List ----------//
  getUserList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_USER_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)

  }

  // ---------- Quote search ----------// 
  getQuote(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_DETAILS + '?company=' + this.session.get('companyCode') + '&agentId=' + this.session.get('agent'), body, this.searchOption)

  }
  // ---------- Policy search ----------// 

  getPolicy(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_DETAILS + '?company=' + this.session.get('companyCode'), body, this.searchOption)

  }

  // ---------- Get Business ----------// 
  getBusiness(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_BUSINESS_DETAILS + '?company=' + this.session.get('companyCode'), body, this.searchOption)

  }

  // ---------- Get getPolicyBusiness ----------// 
  getPolicyBusiness(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_BUSINESS_DETAILS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  downloadFile(url, data, success) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    let token = this.session.get('access_token')
    token = token.slice(1, -1);
    xhr.setRequestHeader("Authorization", "Bearer " + token);
    //xhr.setRequestHeader("Authorization", "Bearer " + this.session.get('access_token'));
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.responseType = "arraybuffer";
    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4) {
        if (success) success(xhr.response);
      }
    };
    xhr.send(JSON.stringify(data));
  }
  // ---------- Get getReportUrl ----------// 
  getReportUrl(body: any) {

    var url = this.baseUrl + ApiUrls.GET_REPORT_URL + '?company=' + this.session.get('companyCode');
    //  + '&transId=' + body.transId + '&tranSrNo='+ body.tranSrNo + '&reportType=' + body.reportType + '&tranType=' + body.tranType;
    // var url = this.baseUrl + ApiUrls.GET_REPORT_URL + '?company=' + this.session.get('companyCode') + '&transId=837652&tranSrNo=0&reportType=Schedule&tranType=POL';
    // var data = 'transId=' + body.transId + '&tranSrNo='+ body.tranSrNo + '&docType='+ body.docType + '&reportType=' + body.reportType + '&tranType=' + body.tranType;
    // var data = body
    this.downloadFile(url, body, function (res) {
      // res = JSON.parse(res);
      // var i, l, d, array;
      //   d = res.FileData;
      //   l = d.length;
      //   array = new Uint8Array(l);
      //   for ( i = 0; i < l; i++){
      //       array[i] = d.charCodeAt(i);
      //   }
      // const blob = new Blob([res.FileDataAsString], {type: res.MimeType});
      const blob = new Blob([res], { type: 'application/pdf' });

      var url = URL.createObjectURL(blob);
      window.open(url);
    });
    const context = this;



  }

  excelExport(body: any) {
    let that = this;
    var url = this.baseUrl + ApiUrls.EXCEL_EXPORT_URL + '?divisionCode=' + body.divisionCode
      + '&departmentCode=' + body.departmentCode + '&lobCode=' + body.lobCode
      + '&startDate=' + body.startDate + '&endDate=' + body.endDate
      + '&agent=' + body.agent + '&company=' + this.session.get('companyCode') + "&userId=" + body.userId + "&schemes=" + body.schemes + "&loginUserName=" + body.loginUserName + "&reportType=" + body.reportType;
    downloadFile(url, function (blob) {
      var url = URL.createObjectURL(blob);
      window.open(url);
    });
    function downloadFile(url, success) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      let token = this.session.get('access_token')
      token = token.slice(1, -1);
      xhr.setRequestHeader("Authorization", "Bearer " + token);
      xhr.responseType = "blob";
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          if (success) success(xhr.response);
        }
      };
      xhr.send(null);
    }

  }


  // ---------- Get ReportUrl ----------// 
  PrintReportUrl(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_PRINT_REPORT_URL + '?company=' + this.session.get('companyCode'), body, this.requestOption)

  }

  // ---------- Get DocInfoByType ----------// 
  getDocInfoByType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_DOC_INFO_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  // ---------- Get FileUrl ----------// 
  getFileUrl(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_FILE_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ---------- View  Policy Details ----------// 
  viewPolicyDetails(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.VIEW_POLICY_DETAILS + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }


  // ---------- Get EndorsementType  Details ----------// 
  getEndorsementType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_ENDORSEMENT_TYPE + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ---------- Get CallculationType  Details ----------// 
  getCallculationType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_CAL_TYPE + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ----------  checkEndorsedData  Details ----------// 
  checkEndorsedData(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.CHECK_END_DATA + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ----------  Call EndorsePackage  Details ----------// 
  callEndorsePackage(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.CALL_END_PACKAGE + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ----------  Get EndorseDetails  Details ----------// 
  getEndorseDetails(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_END_DETAILS + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  getQuoteVehicleInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEH_DETAILS + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ----------  Get Policy Request ----------// 
  getPolicyRequest(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_REQ + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ---------- Update User Message  ----------// 
  updateAgentMessage(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPD_USER_AGENT_MSG + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ---------- Get Policy History   ----------// 
  getPolicyHistory(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_HISTORY + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ---------- Get User Message  ----------// 
  getUserMessage(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_USER_AGENT_MSG + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ---------- cancelEndrosement ----------// 

  cancelEndrosement(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.CANCEL_ENDORSEMENT + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  // ---------- updateHomeInfo ----------// 

  /*updateHomeInfo(body :any):Observable<any>{
   this.searchHeaders = new Headers({ 'Authorization': 'Bearer '+this.session.get('access_token'),'Content-Type': 'application/json', })
   this.searchOption = new RequestOptions({ headers: this.searchHeaders }) 
   return this.http.post(this.baseUrl + ApiUrls.UPDATE_HOME_INFO_URL+'?company='+this.session.get('companyCode'),body,this.searchOption)
   .pipe(map((response : Response) =>{
     return response.json();
   })); 
  }*/

  // ---------- get DMS Type List ----------// 

  getDMSTypeList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_DMS_TYPE_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getPolicyInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POLICY_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  getDocumentList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_DOC_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }



  getSchemes(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_AGENT_SCHEMES + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getSchemeCovers(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_SCHEMECOVERS_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getAllCovers(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_ALLCOVERS_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getTravelSubCovers(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_TRAVEL_SUB_COVERS + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  updateOptionalCover(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_OPTIONAL_COVER_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  updateHomePAB_SI(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_PABHOME_SI + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  processRateReCal(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.PROCESS_RATE_RE_CALC + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  fetchConfirmData(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_CONFIRM_SCREEN_DATA + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getAgentSessionProps(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_AGENT_SESSION_PROPS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  proceedToBuyPkgCall(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.PROCEED_TO_BUY_PKG + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  IsNumeric(strString) {
    var strValidChars = "0123456789.";
    var strChar;
    for (let i = 0; i < strString.length; i++) {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
        return false;
    }
    return true;
  }

  getParamValue(paramName) {
    let paramVal;
    this.route.queryParams.subscribe(params => {
      paramVal = params[paramName];
    });
    return paramVal;
  }


  // This service method is used to fetch the no. of Children/Servants/Drivers.
  getCount() {
    let body = {};
    return this.http.post(this.baseUrl + ApiUrls.GET_COUNT_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }
  // This service method is used to fetch the questions related to home lob.
  getUWQuestions() {
    let body = {};
    return this.http.post(this.baseUrl + ApiUrls.GET_UWQUESTIONS_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  updateInsuredInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSURED_INFO_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  updateHomeInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_HOME_INFO_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }


  getApplicationRefCodes(refType: any, referenceCode: any): Observable<any> {
    const postData = {
      type: refType,
      refCode: referenceCode
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_REF_CODES + '?company=' + this.session.get('companyCode'), postData, this.searchOption);
  }

  getApplicationCodes(refType: any): Observable<any> {
    const postData = {
      type: refType
    }
    return this.http.post(this.baseUrl + ApiUrls.GET_APPL_CODES + '?company=' + this.session.get('companyCode'), postData, this.searchOption);
  }

  getQuoteInformation(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOT_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getHeaderInformation(body: any) {
    return this.http.get(this.baseUrl + ApiUrls.GET_HEADER_INFO + '?company=' + this.session.get('companyCode') + '&transId=' + body.transId + "&tranSrNo=" + body.tranSrNo, this.searchOption);
  }

  getPremiumSummary(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_PREMIUM_SUMMARY + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }




  getCylinderList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.MOTOR_APPL_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }



  //This method is used to approve & create Policy no.
  approvePolicy(body: any) {
    // this.searchHeaders = new Headers({ 'Authorization': 'Bearer ' + this.session.get('access_token'), 'Content-Type': 'application/json', })
    // this.searchOption = new RequestOptions({ headers: this.searchHeaders })
    return this.http.post(this.baseUrl + ApiUrls.APPROVE_POLICY + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  //This method is used to fetch quotation details by mapId
  getQuotInsInfo(body: any) {
    // this.searchHeaders = new Headers({ 'Authorization': 'Bearer ' + this.session.get('access_token'), 'Content-Type': 'application/json', })
    // this.searchOption = new RequestOptions({ headers: this.searchHeaders })
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOT_INS_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }



  getReport(tranId, transSno, reportType, portaltype, tranType, fromRiskSrNo, toRiskSrNo) {
    var params;
    if ("QUOT_SCH" == reportType) {
      params = { "transId": tranId, "tranSrNo": transSno, "tranType": "QOT", "reportType": "QUOT_SCH" };
    } else if ("QOT" === reportType) {
      params = { "transId": tranId, "tranSrNo": transSno, "tranType": reportType, "reportType": "PROP_FORM" };
    } else {
      params = { "transId": tranId, "tranSrNo": transSno, "reportType": reportType, "tranType": tranType, "param1": fromRiskSrNo, "param2": toRiskSrNo };
    }
    var Url;
    this.getReportUrl(params);

  }

  getReportDocs(tranId, transSno, reportType, policyNo, tranType) {
    var params;
    params = { "transId": tranId, "tranSrNo": transSno, "reportType": reportType, "tranType": tranType, "policyNo": '', "histParam": '1' };
    var Url;
    this.getReportUrl(params);

  }

  getFleetReport(tranId, transSno, reportType, portaltype, tranType, fromRiskSrNo, toRiskSrNo, prod, sch) {
    var params = { "transId": tranId, "tranSrNo": transSno, "reportType": reportType, "tranType": tranType, "param1": fromRiskSrNo, "param2": toRiskSrNo, lobCode: "01", divnCode: this.session.get('divisionCode'), prodCode: prod, schCode: sch };
    var Url;
    this.getReportUrl(params);

  }

  getGeoList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.MOTOR_APPL_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getApplParam(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.MOTOR_APPL_PARAM_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getIPAddress(): Observable<any> {
    return this.http.get('https://api.ipify.org/?format=json').pipe(map((response: Response) => {
      const ipJson = JSON.parse(response['_body']);
      return ipJson;
    }));
  }

  createQuote(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.CREATE_QUOTATION + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  endtProceedtoBuy(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.END_PROCEED_TO_BUY + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  endtFleetProceedtoBuy(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.END_FLEET_PROCEED_TO_BUY + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  updateVehicleInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_VEHICLE_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }
  calculatePricing(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.CALCULATE_PRICING + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  insertErrorMsg(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_ERROR_MSG + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  /*getQuoteInformation(body :any){
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_INFO+'?company='+this.session.get('companyCode'),body)
    .pipe(map((response : Response) =>{
      return response.json();
    })); 
  }*/
  getCoverSummary(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_COVER_SUMMARY + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getDiscDedLoadFeesSumm(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_DIS_DUCT_SUMMARY + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getEdataTrimList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.EDATA_TRIM_LIST + '?company=' + this.session.get('companyCode') +
      "&year=" + body.year + "&make=" + encodeURI(body.make) + "&model=" + encodeURI(body.model), body, this.searchOption)
  }
  eDataEvaluation(body) {
    return this.http.post(this.baseUrl + ApiUrls.EDATA_EVALUATION + '?company=' + this.session.get('companyCode'),
      body, this.searchOption);
  }

  updateEdataVehicleInfo(body) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_EDATA_VEH_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getEdataVehicleInfo(chassisNo: string): Observable<any> {
    return this.http.get(this.baseUrl + ApiUrls.GET_EDATA_VEH_INFO + '?company=' + this.session.get('companyCode') + '&chassisNo=' + chassisNo, this.searchOption)
  }
  getEdataCode(acType: string, edataDesc: string): Observable<any> {
    return this.http.get(this.baseUrl + ApiUrls.GET_EDATA_CODE + '?company=' + this.session.get('companyCode') + '&acType=' + acType + "&edataDesc=" + edataDesc, this.searchOption)
  }
  getEdataBodyTypeList(acType: string): Observable<any> {
    return this.http.get(this.baseUrl + ApiUrls.GET_EDATA_BODY_TYPE_LIST + '?company=' + this.session.get('companyCode') + '&acType=' + acType, this.searchOption)
  }
  getVehicleInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_VEH_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }
  getNetPremium(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_NET_PREMIUM + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }
  insertAdditionalDriverInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_ADDL_DRIVER_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getCoverInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_COVER_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  approveAgentPolicy(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.APPROVE_AGENT_POLICY + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  valDupChassisNo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.VAL_DUP_CHASSIS_NO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }
  allowChassisNo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.ALLOW_CHASSIS_NO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }
  getAgentAuthDtls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_AGENT_AUTH_DTLS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }
  getInsuredInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_INSURED_DTLS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getAddlInsuredInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_INSURED_DTLS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  updateInstFlag(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSTALL_FLAG + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  dispInst(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_ISTALLMENT_DETLS + '?company=' + this.session.get('companyCode'), body)
  }

  civilIdLength() {
    let company = this.session.get('companyCode');
    if (ApplicationConstants.DOHA_COUNTRY_CODE == company) {
      return ApplicationConstants.DOHA_CIVIL_ID_LENGTH;
    } else if (ApplicationConstants.DUBAI_COUNTRY_CODE == company) {
      return ApplicationConstants.DUBAI_CIVIL_ID_LENGTH;
    } else if (ApplicationConstants.KUWAIT_COUNTRY_CODE == company) {
      return ApplicationConstants.KUWAIT_CIVIL_ID_LENGTH;
    } else if (ApplicationConstants.OMAN_COUNTRY_CODE == company) {
      return ApplicationConstants.OMAN_CIVIL_ID_LENGTH;
    }

  }

  checkMobileNo() {
    let company = this.session.get('companyCode');
    if (ApplicationConstants.DOHA_COUNTRY_CODE == company) {
      return ApplicationConstants.DOHA_MOBILE_STARTS_WITH;
    } else if (ApplicationConstants.DUBAI_COUNTRY_CODE == company) {
      return ApplicationConstants.DUBAI_MOBILE_STARTS_WITH;
    } else if (ApplicationConstants.KUWAIT_COUNTRY_CODE == company) {
      return ApplicationConstants.KUWAIT_MOBILE_STARTS_WITH;
    } else if (ApplicationConstants.OMAN_COUNTRY_CODE == company) {
      return ApplicationConstants.OMAN_MOBILE_STARTS_WITH;
    }

  }


  civilIdErrorMessage() {
    let company = this.session.get('companyCode');
    if (ApplicationConstants.DOHA_COUNTRY_CODE == company) {
      return ErrorMessage.DOHA_CIVIL_ID_ERROR_MESSAGE;
    } else if (ApplicationConstants.DUBAI_COUNTRY_CODE == company) {
      return ErrorMessage.DUBAI_CIVIL_ID_ERROR_MESSAGE;
    } else if (ApplicationConstants.KUWAIT_COUNTRY_CODE == company) {
      return ErrorMessage.KUWAIT_CIVIL_ID_ERROR_MESSAGE;
    } else if (ApplicationConstants.OMAN_COUNTRY_CODE == company) {
      return ErrorMessage.OMAN_CIVIL_ID_ERROR_MESSAGE;
    }

  }

  mobileNoErrorMessage() {
    let company = this.session.get('companyCode');
    if (ApplicationConstants.DOHA_COUNTRY_CODE == company) {
      return ErrorMessage.DOHA_MOBILE_NO_ERROR_MESSAGE;
    } else if (ApplicationConstants.DUBAI_COUNTRY_CODE == company) {
      return ErrorMessage.DUBAI_MOBILE_NO_ERROR_MESSAGE;
    } else if (ApplicationConstants.KUWAIT_COUNTRY_CODE == company) {
      return ErrorMessage.KUWAIT_MOBILE_NO_ERROR_MESSAGE;
    } else if (ApplicationConstants.OMAN_COUNTRY_CODE == company) {
      return ErrorMessage.OMAN_MOBILE_NO_ERROR_MESSAGE;
    }

  }


  currencyCode() {
    let company = this.session.get('companyCode');
    if (ApplicationConstants.DOHA_COUNTRY_CODE == company) {
      return ApplicationConstants.DOHA_CURR_CODE;
    } else if (ApplicationConstants.DUBAI_COUNTRY_CODE == company) {
      return ApplicationConstants.DUBAI_CURR_CODE;
    } else if (ApplicationConstants.OMAN_COUNTRY_CODE == company) {
      return ApplicationConstants.OMAN_CURR_CODE;
    }

  }


  getDiscriptionList(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_DISCRIPTION_DETLS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getAddtionalOtherInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_OTHER_DETLS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  insertQuoteOtherInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INSERT_OTHER_DETLS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getDriverDetails(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_DRIVER_DETLS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  getBoundTypes(body): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_PARAM + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  getCountryList(body): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body, this.searchOption)

  }
  updateTravelInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_TRAVEL_INFO_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }



  getQuotInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getQuoteTravelInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_QUOTE_TRAVEL_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getRelationType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getGenderList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_PARAM + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getNationalityList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }
  getCityList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_REF_CODES + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }
  getOccupationType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getAgentNetPremium(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_AGENT_PREM + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  insertTravelInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INS_TRAVEL_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  updateInsInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSURED_INFO_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }


  checkPolicyForRenewal(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CHECK_POLICY_FOR_RENEWAL + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }



  chkChassisExist(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CHECK_CHASSIS_EXISTS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getRecalculte(body): any {
    return this.http.post(this.baseUrl + ApiUrls.ADJUST_POLICY_PKG + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  uploadDocuments(formData: any) {
    this.loaderService.isBusy = true;
    let that = this;
    const xhr: XMLHttpRequest = new XMLHttpRequest();
    return Observable.apply(new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', this.baseUrl + ApiUrls.UPLOAD_DOCUMENTS + '?company=' + this.session.get('companyCode'), true);
      let key = this.apiHeadersService.encodedKey;
      xhr.setRequestHeader("Authorization", "Bearer " + this.session.get('access_token'));
      xhr.onreadystatechange = function () {
        that.loaderService.isBusy = false;
        if (xhr.readyState === 4) {
          if (xhr.status === 202) {
            resolve(JSON.parse(xhr.response));
          } else {
            reject(xhr.response);
          }
        }
      };
      xhr.send(formData);
    }));

  }


  /*getHomeInfo(body:any){
    this.searchHeaders = new Headers({ 'Authorization': 'Bearer '+this.session.get('access_token'),'Content-Type': 'application/json', })
    this.searchOption = new RequestOptions({ headers: this.searchHeaders }) 
    return this.http.post(this.baseUrl + ApiUrls.GET_HOME_INFO+'?company='+this.session.get('companyCode'),body,this.searchOption)
    .pipe(map((response : Response) =>{
      return response.json();
  }));
  }*/

  getFleetVehicleList(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_FLEET_VEHICLE_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  // This service method is used to update the endorsed information.
  updateEndorsedInfo(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.UPDATE_INSURED_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  proceedToBuyEndorsement(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.PROCEED_TO_BUY + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  cancelEndorsement(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.CANCEL_ENDORSEMENT + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }


  getTravelerDetls(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.GET_TRAVEL_DETAILS + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  getAgentFilterInfo(body: any) {
    return this.http.get(this.baseUrl + ApiUrls.GET_AGENT_FILTER + '?company=' + this.session.get('companyCode') + '&userRoleId=' + body.userRoleId + '&lobCode=' + body.lobCode, this.searchOption)
  }

  // getUserName(body:any){
  //   this.searchHeaders = new Headers({ 'Authorization': 'Bearer '+this.session.get('access_token'),'Content-Type': 'application/json', })
  //   this.searchOption = new RequestOptions({ headers: this.searchHeaders }) 
  //   return this.http.get(this.baseUrl + ApiUrls.GET_AGENT_USER_NAME +'?company='+this.session.get('companyCode')+'&userId='+body.userId+'&userType='+body.userType,this.searchOption).pipe(map((response: Response) => {
  //     return response.json();
  //   }));
  // }
  //------------------Policy Cancel Endorsment---------------//

  getPlateType(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  VechicleShape(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_APP_CODES + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  agentForgotPwd(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.AGENT_FORGOT_PWD + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }
  edataSumInsuredValidation(transId, tranSrNo, sumAssured) {
    return this.http.get(this.baseUrl + ApiUrls.EDATA_SUM_INSURED_VALIDATION + '?company=' + this.session.get('companyCode') + "&transId=" + transId + "&tranSrNo=" + tranSrNo
      + "&sumAssured=" + sumAssured, this.searchOption)
  }


  //----------------claim Search-------------------//

  getClaimInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_CLAIM_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)

  }


  getClaimRatioList(body: any): Observable<any> {
    return this.http.get(this.baseUrl + ApiUrls.GET_CLAIM_RATIO_INFO + '?company=' + this.session.get('companyCode') + '&policyNo=' + body, this.searchOption)

  }

  //--------------Endrosment AddDelCoverInfo-------///
  getAddlCoverInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_ADDL_COVER_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  deleteAddlCover(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.DEL_ADDL_COVER + '?company=' + this.session.get('companyCode'), body, this.searchOption)
  }

  addRemoveCover(body: any) {
    return this.http.post(this.baseUrl + ApiUrls.INCL_EXCL_COVER + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getOptionalCover(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_OPT_COVER + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }
  getTaxCover(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_TAX_COVER + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }
  getPremCoverInfo(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_PREM_COVER_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  endProceedToConfirm(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.END_PRCED_CONFRM + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getDelCoveSumm(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_DEL_COVER_INFO + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  // ---------- Fleet Policy List ----------//
  getFleetPolicies(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_FLEET_POLICY_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption);

  }

  // ---------- getAgentDashboardUrl List ----------//
  getAgentDashboardUrl(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_AGENT_DASH_URL + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  // ---------- getFleetvehicleList List ----------//
  getFleetvehicleList(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_FLEET_VEH_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getPolicyTax(body: any): Observable<any> {
    return this.http.post(this.baseUrl + ApiUrls.GET_POL_TAX_LIST + '?company=' + this.session.get('companyCode'), body, this.searchOption);
  }

  getAgentUsers(agentId: any) {
    return this.http.get(this.baseUrl + ApiUrls.GET_AGENT_USERS + '?agentId=' + agentId + '&company=' + this.session.get('companyCode'), this.searchOption);
  }

  getQuotationInfo(agentId: string, requestBody: any) {
    return this.http.get(this.baseUrl + ApiUrls.GET_QUOTES +
      '?agentId=' + agentId +
      '&userId=' + requestBody.user +
      '&enquiryFromDate=' + requestBody.enquiryFrom +
      '&enquiryToDate=' + requestBody.enquiryTo +
      '&company=' + this.session.get('companyCode'), this.searchOption)
  }

  getPolicyList(agentId: string, requestBody: any) {
    return this.http.get(this.baseUrl + ApiUrls.GET_POLICIES +
      '?agentId=' + agentId +
      '&userId=' + requestBody.user +
      '&enquiryFromDate=' + requestBody.enquiryFrom +
      '&enquiryToDate=' + requestBody.enquiryTo +
      '&company=' + this.session.get('companyCode'), this.searchOption)
  }

  getMyDashboardInfo() {
    const userName = this.session.get('username');
    const roleId = this.session.get('USER_ROLE_ID');
    const agentId = this.session.get('agent');
    return this.http.get(this.baseUrl + ApiUrls.GET_MY_DASHBOARD + '?userName=' + userName + '&userAgentId=' + agentId + '&roleId=' + roleId + '&company=' + this.session.get('companyCode'), this.searchOption)
  }

  getStatusTrackingInfo(transId: string) {
    const userName = this.session.get('username');
    const roleId = this.session.get('USER_ROLE_ID');
    return this.http.get(this.baseUrl + ApiUrls.GET_STATUS_TRACK_INFO + '?transId=' + transId + '&company=' + this.session.get('companyCode'), this.searchOption)
  }

  getStaticDropdownValues(paraCode) {
    return this.http.get(this.baseUrl + ApiUrls.GET_DROPDOWN_VALUES + '?paraCode=' + paraCode + '&company=' + this.session.get('companyCode'), this.searchOption)
  }

  getRequestDetails(transId: string, transSno: string, userId: string) {

    return this.http.get(this.baseUrl + ApiUrls.GET_REQUEST_DETAILS + '?transId=' + transId + '&tranSlNo=' + transSno + '&userId=' + userId + '&company=' + this.session.get('companyCode'), this.searchOption)
  }

  getPolicyDetailedView(transId: string, transSno: string, userId: string) {

    return this.http.get(this.baseUrl + ApiUrls.GET_REQUEST_DETAILS + '?paraCode=' + transId + '&tranSlNo=' + transSno + '&userId=' + userId + '&company=' + this.session.get('companyCode'), this.searchOption)
  }

  newEvent(event) {
    this._subject.next(event);
  }

  get events$() {
    return this._subject.asObservable();
  }

  getCoverDocUrl(body: any) {
    var url = this.baseUrl + ApiUrls.GET_COVER_DOC_URL + '?company=' + this.session.get('companyCode') + '&coverCode=' + body.coverCode;
    this.downloadFile(url, body, function (res) {
      const blob = new Blob([res], { type: 'application/pdf' });
      var url = URL.createObjectURL(blob);
      window.open(url);
    });
    const context = this;
  }
}
