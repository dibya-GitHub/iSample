import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiHeadersService {
  public headers;
  public requestOption;
  public requestOptionEdata;
  public edataHeaders;
  //public encodedKey = window["ENCODE_KEY"];
  //public encodedKey = 'MjhjMzVmM2QtOTljMS00NDExLTk3YzctYmE4OTEzMmJhOTkyOjgyZTkwZmJhLWMzYjMtNGZiMC04NjM5LTdiOGQ1ZWYxZDEzMA==';
  //public edataEncodeKey='MjhjMzVmM2QtOTljMS00NDExLTk3YzctYmE4OTEzMmJhOTkyOjgyZTkwZmJhLWMzYjMtNGZiMC04NjM5LTdiOGQ1ZWYxZDEzMA==';
  public encodedKey = 'MTEzNzE2OmI0OTllMTRiLTc4YWYtNDYwZi1iMjJmLWU0ZGMzMDRjMmU3NA==';
  public edataEncodeKey = 'MzJjZDgwNmYtNjExYy00YzMxLWEyNjEtNDhlNmZiOTMwZDI1OmJjM2Q4M2U5LWY4YzAtNDE4YS05MjA2LTgyNGMzNGRlYzM3Nw==';
  //public encodedKey = 'MjhjMzVmM2QtOTljMS00NDExLTk3YzctYmE4OTEzMmJhOTkyOjgyZTkwZmJhLWMzYjMtNGZiMC04NjM5LTdiOGQ1ZWYxZDEzMA==';
  //public edataEncodeKey='MjhjMzVmM2QtOTljMS00NDExLTk3YzctYmE4OTEzMmJhOTkyOjgyZTkwZmJhLWMzYjMtNGZiMC04NjM5LTdiOGQ1ZWYxZDEzMA==';

  public token: any;
  //userName = '32cd806f-611c-4c31-a261-48e6fb930d25';
  //password = 'bc3d83e9-f8c0-418a-9206-824c34dec377';


  constructor(public http: HttpClient) {
    //window["ENCODE_KEY"] = '';
    this.headers = new Headers();
    this.headers.append("Authorization", "Basic " + this.encodedKey);
    this.headers.append('company', '002');
    this.headers.append('Content-Type', 'application/x-www-form-urlencoded');

    this.requestOption = { headers: this.headers };

    this.edataHeaders = new Headers();
    this.edataHeaders.append("Authorization", "Basic " + this.edataEncodeKey);
    this.edataHeaders.append('company', '002');
    this.edataHeaders.append('Content-Type', 'application/json');
    this.requestOptionEdata = { headers: this.edataHeaders };
  }
}
