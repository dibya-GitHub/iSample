import { TestBed, inject } from '@angular/core/testing';

import { AgentUserService } from './agent-user.service';

describe('AgentUserService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AgentUserService]
    });
  });

  it('should be created', inject([AgentUserService], (service: AgentUserService) => {
    expect(service).toBeTruthy();
  }));
});
