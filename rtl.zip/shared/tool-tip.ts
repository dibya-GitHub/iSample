import { Inject } from '@angular/core';


export class Tooltip {
    public MOTOR_EMIRATES_ID = "Enter Valid Emirates ID of 18 Digits";
    public MOTOR_COMPANY_ID = "Enter Company Id";
    public MOTOR_MOB_NUMBER = "Enter Valid Mobile No of 9 Digits, Start with 5";
    public MOTOR_MAKE = "Select the Manufacturer of your Vehicle";
    public MOTOR_YOM = "Enter the Manufactured Year of your Vehicle";
    public MOTOR_SUM_INSURED = "Enter the Value of your Vehicle";
    public MOTOR_BODY_TYPE = "Select Body Type from the list";
    public MOTOR_VEHICLE_USAGE = "How do you use your Vehicle";
    public MOTOR_NOC = "Select Number of Cylinders";
    public MOTOR_REGISTRATION_LOCATION = "Select Location of Registration";
    public MOTOR_SEATING_CAPACITY = "Enter Actual Seating Capacity of your Vehicle";
    public MOTOR_PAB = "Enter No of Passengers required Personal Accident Benefit Cover";
    public MOTOR_DRIVER_AGE = "Driver Age";
    public MOTOR_DRIVER_DOB = "Driver Dob";
    public MOTOR_FIRST_REGION = "Enter the Registration date of your Vehicle";
    public ADD_INFO_ChassisNo = "Enter the ChassisNo of your Vehicle";
    public TRAVEL_EMIRATES_ID = "Enter Valid Emirates ID of 18 Digits";
    public TRAVEL_MOB_NUMBER = "Enter Valid Mobile No of 9 Digits, Start with 5";
    public TRAVEL_PASSPORT = "Enter Passport Number";
    public TRAVEL_COR = "You must have been a resident of this country for at least 3 months";
    public TRAVEL_TRIP_TYPE = "Single trip travel insurance is suitable cover if you are taking just one holiday or trip. If you plan to travel more than 2 times per year, you may wish to consider an Annual multi-trip policy.";
    public TRAVEL_DEP_DATE = "Please use the Calendar function to select the date you would like your policy to start.";
    public HOME_EMIRATES_ID = "Enter Valid Emirates ID of 18 Digits";
    public HOME_MOB_NUMBER = "Enter Valid Mobile No of 9 Digits, Start with 5";
    public HOME_BUILDING = "Enter approx. value of your Building";
    public HOME_C_G = "Enter Total Appx value of your Contents/Goods";
    public HOME_CHILDREN = "Applicable for Personal Accident Benefit Cover";
    public HOME_DOMESTIC = "Applicable for Personal Accident Benefit Cover";
    public MOTOR_NO_CLIAM_BONUS = "Number of years without any claims.";
    public MOTOR_SELF_DECLARATIONS = "Number of years for self declartion discount.";

    // PLEASURE CRAFT
    public BUILT_YEAR = 'Enter the Year of Build';
    public PASS_CAPACITY = 'Enter Passenger Capacity';
    public CLASS_SOCIETY = 'Select Classification Society';
    public YACHT_VALUE = 'Enter Yacht Value';
    public HULL_MATERIAL = 'Select Material of Hull';
    public VESSEL_USAGE = 'Enter Vessel Usage';
    public MARINA = 'Select Marina';
    public LENGTH_OA = 'Enter Length O.A(ft)';
    public SPEED = 'Enter Speed (Knots)';
    public SKIPPERS_AGE = 'Enter Skippers Age';
    public VESSELTYPE = 'Select Vessel Type';
    public TRAILER_VALUE = 'Enter Trailer Value';
    public THIRD_PARTY_LIMIT = 'Enter Third Party Limit';
    public VESSEL_NAME = 'Enter the Vessel Name';
    public ENGINE_NO = 'Enter the Engine Number';
    public REG_NO = 'Enter the Registration Number';
    public PORT_OF_REGISTRY = 'Select Port of Registry';
    public MOTOR_ENGINE = 'Select Motor(Engine)';
    public CRUSING_AREA = 'Select Cruising Area';
    public BUILDER_NAME = 'Enter Builder Name';
    public MAKE_OF_MAIN_ENGINE = 'Enter Make of Main Engine';
    public ENGINE_CAPACITY = 'Enter Capacity of the Engine';
    public NO_OF_ENGINES = 'Enter No of Engines';

    public ADDRESS1 = 'Enter Address1';
    public POBOX = 'Enter po Box';
    public CITY = 'Enter City';
    public CARD_REF = 'Enter Card Reference Number';

}
