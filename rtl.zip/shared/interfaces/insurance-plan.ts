import { Cover } from '../classes/cover';
import { Product } from '../classes/product';
import { Scheme } from '../classes/scheme';

export interface LoginUser {
  empUserId: string,
  empUserName: string,
  empAgentId: string,
  empUserRoleId: string,
  empUserNo: string,
  empAdminYn: string,
  empLostLoginDate: string,
  empDivnCode: string,
  empDeptCode: string,
  empDeptName: string,
  empDivnName: string,
  loginStatus: string,
  respCode: number,
  errMessage: string,
  jwt: string
}

export interface Products {
  respCode: number;
  errMessage: string;
  prodArray: Array<Product>;
}

export interface Schemes {
  respCode: number;
  errMessage: string;
  schemesArray: Array<Scheme>;
}

export interface Covers {
  respCode: number;
  errMessage: string;
  coversArray: Array<Cover>;
}