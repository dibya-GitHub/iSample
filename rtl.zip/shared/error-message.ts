let fullyear = new Date().getFullYear();
export class ErrorMessage {

    public static DUBAI_CIVIL_ID_ERROR_MESSAGE = "Civil Id should be 18 digits";
    public static DOHA_CIVIL_ID_ERROR_MESSAGE = "Civil Id should be 11 digits";
    public static OMAN_CIVIL_ID_ERROR_MESSAGE = "Civil Id should be 9 digits";
    public static KUWAIT_CIVIL_ID_ERROR_MESSAGE = "Civil Id should be 8 digits";


    public static DOHA_MOBILE_NO_ERROR_MESSAGE = "Mobile No start width 3 or 5 or 6 or 7  & Length Should be 8 digit ";
    public static DUBAI_MOBILE_NO_ERROR_MESSAGE = "Mobile No start width 0 or 5  & Length Should be 9 digit ";
    public static OMAN_MOBILE_NO_ERROR_MESSAGE = "Mobile No start width 2 or 3 or 5 or 7 or 8 or 9 & Length Should be 8 digit ";
    public static KUWAIT_MOBILE_NO_ERROR_MESSAGE = "Mobile No start width 5 or 6 or 9 & Length Should be 8 digit ";

    public MOTOR_TYPE = "Select Insurance Type";
    public MOTOR_CHASSIS = "Enter Chassis Number";
    public MOTOR_INSURED = "Enter Insured Name";
    public MOTOR_MOBILE = "Enter Mobile No";
    public MOTOR_VMOB = "Mobile Number Should Start With 0(10 digits) or 5(9 digits)";
    public MOTOR_EMAIL = "Enter E-mail Address";
    public MOTOR_VEMAIL = "Enter Valid E-mail Address ";
    public MOTOR_MANF = "Enter Manufacture Year";
    public MOTOR_VMANF = "Manufacure Year should be between 1999 to " + fullyear;
    public MOTOR_VECH = "Select Vehicle Usage";
    public MOTOR_VCIVILID = "Emirates ID format should be XXX-XXXX-XXXXXXX-X";

    public HOME_ADD = "Address1 is required";
    public HOME_POB = "POBox is required ";
    public HOME_CITY = "City is required";
    public HOME_ZONE = "Zone is required";
    public HOME_STREET = "Street/Block is required";

    public HOME_ASSURED = " Assured Name is required";
    public HOME_EMI_ID = " Emirates Id is required";
    public HOME_VEMI_ID = " Emirates ID format should be XXX-XXXX-XXXXXXX-X";
    public HOME_BUILD = " Approx Building Value is required";
    public HOME_VBUILD = " Invalid Building Value";
    public HOME_GOODS = " Approx Contents Value is required";
    public HOME_VGOODS = " Invalid Content Value";

    public TRAVEL_INSURANCE = " Select Insurance Type";
    public TRAVEL_NAME = " Enter Insured Name";
    public TRAVEL_VEMAIL = "Enter Valid Email-ID";
    public TRAVEL_EMIRATESID = " Enter Emirates ID";
    public TRAVEL_COMPANYID = " Enter Company ID";
    public TRAVEL_PASSPORTNO = "Enter Passport Number";
    public TRAVEL_MOBILE = "Enter Mobile No";
    public TRAVEL_TELPHN = " Enter TelePhone No";
    public TRAVEL_FORM = "Select Travel From";
    public TRAVEL_DEPDATE = "Enter Valid Departure Date";
    public TRAVEL_POLDATE = "Enter Valid Policy Start Date";
    public TRAVEL_NOD = "Enter Total Days";
    public TRAVEL_VNOD = "Travel is Applicaple for Less Than 90 Days";
    public TRAVEL_ADULT = "Select Adult";
    public TRAVEL_MANDATORY = "Please select atleast one adult or child";
    public TRAVEL_CIVILID = "Emitrates Id should be XXX-XXXX-XXXXXXX-X";



    // pleasure craft Basic Info
    public BUILT_YEAR = 'Year of Build is required';
    public PASS_CAPACITY = 'Passenger Capacity is required';
    public CLASS_SOCIETY = 'Classification Society is required';
    public YACHT_VALUE = 'Yacht Value is required';
    public HULL_MATERIAL = 'Material of Hull is required';
    public VESSEL_USAGE = 'Vessel Usage is required';
    public MARINA = 'Marina is required';
    public LENGTH_OA = 'Length O.A(ft) is required';
    public SPEED = 'Speed (Knots) is required';
    public SKIPPERS_AGE = 'Skippers Age is required';
    public VESSELTYPE = 'Vessel Type is required';
    public TRAILER_VALUE = 'Trailer Value is required';
    public THIRD_PARTY_LIMIT = 'Third Party Limit is Required';
    public civilIdPatternError = 'Emirates ID format should be XXX-XXXX-XXXXXXX-X';
    // pleasure craft Additional Info

    public VESSEL_NAME = 'Vessel Name is required';
    public ENGINE_NO = 'Engine Number is required';
    public REG_NO = 'Registration Number is required';
    public PORT_OF_REGISTRY = 'Port of Registry is required';
    public MOTOR_ENGINE = 'Motor(Engine) is required';
    public CRUSING_AREA = 'Crusing Area is required';
    public BUILDER_NAME = 'Builder Name is required';
    public MAKE_OF_MAIN_ENGINE = 'Make of main Engine is required';
    public ENGINE_CAPACITY = 'Capacity of Engine is required';
    public NO_OF_ENGINES = 'No of Engines is required';
    public CARD_REF = 'Card Reference Number is required';

}


