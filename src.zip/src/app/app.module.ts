import { HTTP_INTERCEPTORS } from '@angular/common/http';
<<<<<<< HEAD
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { MessageService } from 'primeng/api';
=======
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { MessageService } from 'primeng/api';
import { EditorModule } from 'primeng/editor';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { ToastModule } from 'primeng/toast';
import { AuthInterceptor } from 'src/app/services/auth-interceptor';
import { SharedModule } from 'src/shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
<<<<<<< HEAD
import { ClaimBordereauxModule } from './modules/claim-bordereaux/claim-bordereaux.module';
import { MgaContractModule } from './modules/mga-contract/mga-contract.module';
import { PremiumBordereauxModule } from './modules/premium-bordereaux/premium-bordereaux.module';
import { ReportsModule } from './modules/reports/reports.module';
import { SmartReportModule } from './modules/smart-report/smart-report.module';
import { AccountingDashboardModule } from './modules/accounting/accounting-dashboard.module';
// import { EnquiryInfoComponent } from 'src/app/components/enquiry/enquiry-info.component';
// import { EnquiryDashboardComponent } from './components/enquiry-dashboard/enquiry-dashboard.component';
// import { EnquirySummaryComponent } from './components/enquiry-summary/enquiry-summary.component';
// import { GlobalSearchComponent } from './components/global-search/global-search.component';
// import { SearchResultComponent } from './components/search-result/search-result.component';
// import { SkeletonSummaryComponent } from './components/skeleton-summary/skeleton-summary.component';
// import { SkeletonComponent } from './components/skeleton/skeleton.component';
// import { WorkflowDashboardComponent } from './components/workflow-dashboard/workflow-dashboard.component';
// import { WorkflowDiagramComponent } from './components/workflow-diagram/workflow-diagram.component';
// import { WorkflowHistoryComponent } from './components/workflow-history/workflow-history.component';
// import { WorkflowOutwardComponent } from './components/workflow-outward/workflow-outward.component';
// import { SignedModule } from './modules/signed/signed.module';
// import { TechAccountingModule } from './modules/tech-accounting/tech-accounting.module';
// import { EnquiryDashboardService } from './services/enquiry-dashboard.service';
// import { WorkflowService } from './services/workflow.service';
// import { SkeletonService } from './services/skeleton.service';
@NgModule({
    declarations: [
        AppComponent,
        // EnquiryInfoComponent,
        // EnquiryDashboardComponent,
        // SkeletonComponent,
        // WorkflowDashboardComponent,
        // SkeletonSummaryComponent,
        // WorkflowDiagramComponent,
        // WorkflowHistoryComponent,
        // EnquirySummaryComponent,
        // GlobalSearchComponent,
        // SearchResultComponent,
        // WorkflowOutwardComponent,
=======
import { AccountingDashboardModule } from './modules/accounting/accounting-dashboard.module';


@NgModule({
    declarations: [
        AppComponent,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        SharedModule,
        RouterModule,
<<<<<<< HEAD
        ToastModule,
        AppRoutingModule,
        AccordionModule.forRoot(),
        // TechAccountingModule,
        TypeaheadModule,
        MgaContractModule,
        PremiumBordereauxModule,
        ClaimBordereauxModule,
        // SignedModule,
        ReportsModule,
        SmartReportModule,
        AccountingDashboardModule
    ],
    providers: [{ provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }, MessageService],
    bootstrap: [AppComponent],
    exports: [TypeaheadModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
=======
        AppRoutingModule,
        AccordionModule.forRoot(),
        TypeaheadModule,
        NgSelectModule,
        ToastModule,
        EditorModule,
        AccountingDashboardModule
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
        MessageService
    ],
    bootstrap: [AppComponent],
    exports: [TypeaheadModule]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
})
export class AppModule { }
