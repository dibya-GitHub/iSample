<<<<<<< HEAD
import { Component, HostListener, NgZone, OnInit, TemplateRef, ViewChild } from '@angular/core';
=======
import { Component, HostListener, NgZone, OnInit, TemplateRef, ViewChild, ElementRef } from '@angular/core';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { BnNgIdleService } from 'bn-ng-idle';
import * as $ from 'jquery';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ngxLoadingAnimationTypes } from 'ngx-loading';
import { AuthService } from 'src/app/services/auth.service';
import { LoginService } from 'src/shared/services/login.service';
import { BreadcrumbService } from 'xng-breadcrumb';
import { LoaderService } from './services/loader.service';


@Component({
  selector: 'inward-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'quantum-inward-ui';
  isDivisionAvailable = false;
  secondaryColour = 'red';
  loadingTemplate: any;
  public ngxLoadingAnimationTypes = ngxLoadingAnimationTypes;
  primaryColour = getComputedStyle(document.documentElement).getPropertyValue('--primary-color');
  @ViewChild('customLoadingTemplate') customLoadingTemplate: TemplateRef<any>;
  urlLocation: any;
  constructor(
    private breadcrumbService: BreadcrumbService,
    private bnIdle: BnNgIdleService,
    public auth: AuthService,
    private router: Router,
    private loginService: LoginService,
    private ngZone: NgZone,
    public loaderService: LoaderService,
<<<<<<< HEAD
    private session:SessionStorageService,
    private modalService: BsModalService
    ) {
=======
    private session: SessionStorageService,
    private modalService: BsModalService,
    private el: ElementRef
  ) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    //If it open on new Tab


    //   if (!sessionStorage.length) {
    //     localStorage.setItem('getSessionStorage', (Date.now()).toString());
    //   };
    //   let thisobj = this;
    //   window.addEventListener('storage', function (event) {
    //     if (event.key == 'getSessionStorage') {
    //       localStorage.setItem('sessionStorage', JSON.stringify(sessionStorage));
    //       localStorage.removeItem('sessionStorage');
    //     } else if (event.key == 'sessionStorage' && !sessionStorage.length) {
    //       var data = JSON.parse(event.newValue);
    //       for (var key in data) {
    //         sessionStorage.setItem(key, data[key]);
    //       }
    //       if (thisobj.auth.getAuthToken()) {
    //         thisobj.auth.isLoggedIn = true;
    //         thisobj.redirectToURL();
    //       }
    //     }
    //   });
    // }
    // redirectToURL() {

    //   this.router.navigate([this.router.url]).then(() => {

    //   });
  }
  ngOnInit() {
    this.breadcrumbService.set('', 'Dashboard');
    this.urlLocation = (location.href.indexOf('login') != -1) == true;
    if (this.urlLocation) {
      this.auth.isLoggedIn = false;
      sessionStorage.clear();
      this.modalService.hide();
      this.auth.clearToken();
    }
    this.bnIdle.startWatching(5400).subscribe((res) => {
      if (res) {
        this.loginService.setSessionExpiry('Session Expired, Please login to continue');
        this.auth.clearToken();
        this.session.clear();
        this.ngZone.run(() => {
          this.modalService.hide();
          this.router.navigate(['login']);
        });
      }
    });
  }
  divisionChanged(division) {

    this.isDivisionAvailable = true;
    if (division.companyTheme) {
      this.primaryColour = division.companyTheme;
    }
  }

  changeTheme() {
    $('html').toggleClass('theme-qatar-re');
  }

  @HostListener('contextmenu', ['$event'])
  onRightClick() {
    // event.preventDefault();
  }
  gotoDashBoard() {
    this.router.navigate(['/']);
  }
<<<<<<< HEAD
=======
  xngRedirecter(event) {
    if (event.target.innerText == 'Treaty QS') {
      this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
    }
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
}
