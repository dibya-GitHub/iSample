import { NgModule } from '@angular/core';
<<<<<<< HEAD
import { RouterModule, Routes } from '@angular/router';
=======
import { Routes, RouterModule } from '@angular/router';
import { ForgetPasswordComponent } from 'src/shared/components/forget-password/forget-password.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoginComponent } from 'src/shared/components/login/login.component';
import { SsoComponent } from 'src/shared/components/sso/sso.component';
import { AuthGuard } from './services/auth.guard';
<<<<<<< HEAD
// import { EnquiryDashboardComponent } from './components/enquiry-dashboard/enquiry-dashboard.component';
// import { EnquiryInfoComponent } from './components/enquiry/enquiry-info.component';
// import { SkeletonComponent } from 'src/app/components/skeleton/skeleton.component';
// import { WorkflowDashboardComponent } from './components/workflow-dashboard/workflow-dashboard.component';
// import { EnquirySummaryComponent } from './components/enquiry-summary/enquiry-summary.component';
// import { SkeletonSummaryComponent } from './components/skeleton-summary/skeleton-summary.component';
// import { GlobalSearchComponent } from './components/global-search/global-search.component';
// import { WorkflowOutwardComponent } from './components/workflow-outward/workflow-outward.component';
// import { UserDashboardGuard } from './services/user-dashboard.guard';
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

const routes: Routes = [
  {
    path: '',
    pathMatch: 'prefix',
    redirectTo: 'mga-contract',
    data: {
      breadcrumb: 'Home',
    },
<<<<<<< HEAD
  },
=======
  }, 
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  {
    path: 'login',
    pathMatch: 'prefix',
    component: LoginComponent,
    data: {
<<<<<<< HEAD
      breadcrumb: { skip: true }
    },
  },
  {
    path: 'reports',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/reports/reports.module').then((module) => module.ReportsModule),
    data: {
      breadcrumb: { skip: true }
    },

    canActivate: [AuthGuard]
  },
  {
    path: 'master',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/master/master.module').then((module) => module.MasterModule),
    data: { breadcrumb: { skip: true } },
    canActivate: [AuthGuard]
  },
  {
    path: 'appSetup',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/app-setup/app-setup.module').then((module) => module.AppSetupModule),
    data: { breadcrumb: { skip: true } },
    canActivate: [AuthGuard]
  },
  {
    path: 'customers-setup',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/customer/customer.module').then((module) => module.CustomerModule),
    data: {
      breadcrumb: { skip: true }
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'user-setup',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/user-setup/user-setup.module').then((module) => module.UserSetupModule),
    data: {
      breadcrumb: { skip: true }
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'templates-setup',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/templates-setup/templates-setup.module').then((module) => module.TemplatesSetupModule),
    data: {
      breadcrumb: { skip: true }
=======
      skipBreadcrumb: true
    },
  },
  {
    path: 'sso',
    component: SsoComponent,
    data: {
      skipBreadcrumb: true
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
  },
  {
<<<<<<< HEAD
    path: 'appCodes',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/app-codes/app-codes.module').then((module) => module.AppCodesModule),
    data: {
      breadcrumb: { skip: true }
=======
    path: 'forget-password',
    component: ForgetPasswordComponent,
    data: {
      skipBreadcrumb: true
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
  },
  {
<<<<<<< HEAD
    path: 'logs-setup',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/logs-setup/logs-setup.module').then((module) => module.LogsSetupModule),
    data: {
      breadcrumb: { skip: true }
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'number-setup',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/number-setup/number-setup.module').then((module) => module.NumberSetupModule),
    data: {
      breadcrumb: { skip: true }
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'treaty',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/treaty/treaty.module').then((module) => module.TreatyModule),
    data: {
      breadcrumb: 'Treaty'
=======
    path: 'master',
    loadChildren: () => import('./modules/master/master.module').then((module) => module.MasterModule),
    data: { breadcrumb: { skip: true } },
    canActivate: [AuthGuard]
  },
  {
    path: 'appSetup',
    loadChildren: () => import('./modules/app-setup/app-setup.module').then((module) => module.AppSetupModule),
    data: { breadcrumb: { skip: true } },
    canActivate: [AuthGuard]
  },
  {
    path: 'customers-setup',
    loadChildren: () => import('./modules/customer/customer.module').then((module) => module.CustomerModule),
    data: {
      breadcrumb: { skip: true }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
    canActivate: [AuthGuard]
  },
  {
<<<<<<< HEAD
    path: 'mga-contract',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/mga-contract/mga-contract.module').then((module) => module.MgaContractModule),
    data: {
      breadcrumb: 'Contract Dashboard'
=======
    path: 'user-setup',
    loadChildren: () => import('./modules/user-setup/user-setup.module').then((module) => module.UserSetupModule),
    data: {
      breadcrumb: { skip: true }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
    canActivate: [AuthGuard]
  },
  {
<<<<<<< HEAD
    path: 'premium-bordereaux',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/premium-bordereaux/premium-bordereaux.module').then((module) => module.PremiumBordereauxModule),
    data: {
      breadcrumb: 'Premium Bordereaux Dashboard'
=======
    path: 'templates-setup',
    loadChildren: () => import('./modules/templates-setup/templates-setup.module').then((module) => module.TemplatesSetupModule),
    data: {
      breadcrumb: { skip: true }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
    canActivate: [AuthGuard]
  },
  {
<<<<<<< HEAD
    path: 'claim-bordereaux',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/claim-bordereaux/claim-bordereaux.module').then((module) => module.ClaimBordereauxModule),
    data: {
      breadcrumb: 'Claim Bordereaux Dashboard'
=======
    path: 'appCodes',
    loadChildren: () => import('./modules/app-codes/app-codes.module').then((module) => module.AppCodesModule),
    data: {
      breadcrumb: { skip: true }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
    canActivate: [AuthGuard]
  },
  {
<<<<<<< HEAD
    path: 'product-master',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/product-master/product-master.module').then((module) => module.ProductMasterModule),
    data: {
      breadcrumb: 'product-master'
=======
    path: 'logs-setup',
    loadChildren: () => import('./modules/logs-setup/logs-setup.module').then((module) => module.LogsSetupModule),
    data: {
      breadcrumb: { skip: true }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
    canActivate: [AuthGuard]
  },
  {
<<<<<<< HEAD
    path: 'smart-report',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/smart-report/smart-report.module').then((module) => module.SmartReportModule),
    data: {
      breadcrumb: 'Smart Report'
=======
    path: 'number-setup',
    loadChildren: () => import('./modules/number-setup/number-setup.module').then((module) => module.NumberSetupModule),
    data: {
      breadcrumb: { skip: true }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    },
    canActivate: [AuthGuard]
  },
  {
<<<<<<< HEAD
    path: 'accounting',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/accounting/accounting-dashboard.module').then((module) => module.AccountingDashboardModule),
=======
    path: 'treaty',
    loadChildren: () => import('./modules/treaty/treaty.module').then((module) => module.TreatyModule),
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    data: {
      breadcrumb: 'Treaty Account Process'
    },
    canActivate: [AuthGuard]
  },
<<<<<<< HEAD
  // {
  //   path: 'policy',
  //   loadChildren: () => import('./modules/signed/signed.module').then((module) => module.SignedModule),
  //   data: {
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'tech-accounting',
  //   loadChildren: () => import('./modules/tech-accounting/tech-accounting.module').then((module) => module.TechAccountingModule),
  //   data: {
  //     breadcrumb: 'Technical Accounting',
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'inward-enquiry',
  //   component: EnquiryDashboardComponent,
  //   data: {
  //     // breadcrumb: { skip: true }
  //     breadcrumb: 'Inward-Enquiry'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'add-enquiry',
  //   component: EnquiryInfoComponent,
  //   data: {
  //     breadcrumb: 'New Enquiry'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'edit-enquiry',
  //   component: EnquiryInfoComponent,
  //   data: {
  //     breadcrumb: 'Edit Enquiry'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'view-enquiry',
  //   component: EnquirySummaryComponent,
  //   data: {
  //     breadcrumb: 'View Enquiry'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'view-skeleton',
  //   component: SkeletonSummaryComponent,
  //   data: {
  //     breadcrumb: 'View Skeleton'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'add-skeleton',
  //   component: SkeletonComponent,
  //   data: {
  //     breadcrumb: 'New skeleton'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'edit-skeleton',
  //   component: SkeletonComponent,
  //   data: {
  //     breadcrumb: 'Edit skeleton'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'workflow-dashboard',
  //   component: WorkflowDashboardComponent,
  //   data: {
  //     breadcrumb: 'Workflow'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'workflow-outward',
  //   component: WorkflowOutwardComponent,
  //   data: {
  //     breadcrumb: 'Workflow-outward'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'global-search',
  //   component: GlobalSearchComponent,
  //   data: {
  //     breadcrumb: 'Global Search'
  //   },
  //   canActivate: [AuthGuard]
  // },
  // {
  //   path: 'claims',
  //   loadChildren: () => import('./modules/claims/claims.module').then((module) => module.ClaimsModule),
  //   data: {
  //   },
  //   canActivate: [AuthGuard]
  // },

=======

  {
    path: 'treaty-qs',
    loadChildren: () => import('./modules/treaty-qs/treaty-qs.module').then((module) => module.TreatyQSModule),
    //loadChildren: () => import('./modules/treaty/treaty.module').then((module) => module.TreatyModule),
    data: {
      breadcrumb: 'Treaty QS'
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'accounting',
    pathMatch: 'prefix',
    loadChildren: () => import('./modules/accounting/accounting-dashboard.module').then((module) => module.AccountingDashboardModule),
    data: {
      breadcrumb: 'Treaty Account Process'
    },
    canActivate: [AuthGuard]
  },
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'top',
  })],

  exports: [RouterModule]
})
export class AppRoutingModule { }
