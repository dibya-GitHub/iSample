import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReportColumnComponent } from './components/report-column/report-column.component';
import { ExportReportsComponent } from './components/export-reports/export-reports.component';

const routes: Routes = [
  { path: '', component: ExportReportsComponent },
  {
    path: 'reports', component: ExportReportsComponent,
    data: {
      breadcrumb: { skip: true }
    }
  },
  {
    path: 'report-columns', component: ReportColumnComponent,
    data: {
      breadcrumb: 'Report Columns'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
