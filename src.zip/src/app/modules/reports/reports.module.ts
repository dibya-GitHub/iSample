import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DropdownModule } from 'primeng/dropdown';
import { SharedModule } from 'src/shared/shared.module';
import { ExportReportsComponent } from './components/export-reports/export-reports.component';
import { ReportColumnComponent } from './components/report-column/report-column.component';
import { ReportsRoutingModule } from './reports-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ReportsRoutingModule,
    SharedModule,
    DropdownModule
  ],
  declarations: [ExportReportsComponent, ReportColumnComponent]
})
export class ReportsModule { }
