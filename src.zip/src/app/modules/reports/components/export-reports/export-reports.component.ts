import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { zip } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { Utils } from 'src/app/utils';
import { ValidationHelperService } from 'src/shared/services/validate-helper.service';
import { validSelection, validSelectionValidator } from 'src/shared/validators/valid-selection-validator';
import { ReportService } from '../../services/reports.service';

@Component({
  selector: 'inward-export-reports',
  templateUrl: './export-reports.component.html',
  styleUrls: ['./export-reports.component.scss']
})
export class ExportReportsComponent implements OnInit {

  exportReportsForm: any;
  programCodes: any;
  statuses: string;
  coverHolders: any;
  territories: any;
  insureds: any;
  cedants: any;
  placingBrokers: any;
  placingsFromList: any;
  placingsToList: any;
  placementMethodsFromList: any;
  placementMethodsToList: any;
  lineOfBusinessesFromList: any;
  lineOfBusinessesToList: any;
  underWriters: any;
  accountBrokers: any[];
  retroCedant: any[];
  uwYearsFromList = [];
  uwYearsToList = [];
  divisionsFromList: any;
  divisionsToList: any;
  policiesFromList: any[];
  policiesToList: any[];
  companiesFromList: any;
  companiesToList: any;

  constructor(
    private loaderService: LoaderService,
    private commonService: CommonService,
    private formBuilder: UntypedFormBuilder,
    private location: Location,
    private reportService: ReportService,
    private toastService: ToastService,
    private validationHelper: ValidationHelperService
  ) { }

  ngOnInit() {

    const currentYear = new Date().getFullYear();
    this.uwYearsFromList.push({ value: currentYear });
    for (let i = 1; i < 5; i++) {
      this.uwYearsFromList.push({ value: currentYear - i });
    }
    this.uwYearsToList = this.uwYearsFromList;
    this.createForm();
    this.getMasterData();
  }

  createForm() {

    this.exportReportsForm = this.formBuilder.group({
      companyCodeFrom: [undefined, Validators.required],
      companyCodeTo: [undefined, Validators.required],
      divisionCodeFrom: [undefined, Validators.required],
      divisionCodeTo: [undefined, Validators.required],
      lineOfBusinessCodeFrom: [undefined],
      lineOfBusinessCodeTo: [undefined],
      placementMethodFrom: [undefined],
      placementMethodTo: [undefined],
      placingCodeFrom: [undefined],
      placingCodeTo: [undefined],
      placingBroker: [undefined],
      accountBroker: [undefined],
      cedant: [undefined],
      insured: [undefined],
      retroCedant: [undefined],
      coverHolder: [undefined],
      programCode: [undefined],
      territoryCode: [undefined],
      policyNumberFrom: [undefined],
      policyNumberTo: [undefined],
      underWritingYearFrom: [undefined],
      underWritingYearTo: [undefined],
      inceptionDateFrom: [undefined],
      inceptionDateTo: [undefined],
      approvedDateFrom: [undefined],
      approvedDateTo: [undefined],
      renewableStatus: [undefined],
      underwriterUserId: [undefined],
      status: [undefined]
    });
  }

  getMasterData() {

    this.loaderService.isBusy = true;
    zip(
      this.commonService.getUnderWriters(),
      this.commonService.getLineOfBusinesses(),
      this.commonService.getPlacementMethods(),
      this.commonService.getPlacings(),
      this.commonService.getBrokers(),
      this.commonService.getCedants(),
      this.commonService.getInsureds(),
      this.commonService.getTerritories(),
      this.commonService.getCoverHolders(),
      this.commonService.getInwardStatuses(),
      this.commonService.getProgramCodes(),
      this.commonService.getRetroCedants(),
      this.commonService.getDivision(),
      this.commonService.getPolicyLookUpTransMgt(),
      this.commonService.getAllDivisions()
    ).subscribe(([
      underWriters,
      lineOfBusinesses,
      mops, placings,
      brokers, cedants,
      insureds, territories, coverHolders,
      statuses, programCodes, retroCedants, companies, activePolicies, divisions]: any[]) => {
      this.underWriters = underWriters;
      this.lineOfBusinessesFromList = lineOfBusinesses;
      this.lineOfBusinessesToList = lineOfBusinesses;
      this.placementMethodsFromList = mops;
      this.placementMethodsToList = mops;
      this.placingsFromList = placings;
      this.placingsToList = placings;
      this.placingBrokers = (brokers as any[]).map(broker => {
        broker.displayText = broker.customerCode + ' - ' + broker.customerName;
        return broker;
      });
      this.accountBrokers = (brokers as any[]).map(broker => {
        broker.displayText = broker.customerCode + ' - ' + broker.customerName;
        return broker;
      });
      this.cedants = cedants.map(cedant => {
        cedant.displayText = cedant.customerCode + ' - ' + cedant.customerName;
        return cedant;
      });
      this.insureds = insureds.map(insured => {
        insured.displayText = insured.customerCode + ' - ' + insured.customerName;
        return insured;
      });
      this.territories = territories;
      this.coverHolders = (coverHolders as any[]).map(coverHolder => {
        coverHolder.displayText = coverHolder.customerCode + ' - ' + coverHolder.customerName;
        return coverHolder;
      });
      this.statuses = statuses;
      this.programCodes = programCodes.map(programCode => {
        programCode.displayText = programCode.code + ' - ' + programCode.description;
        return programCode;
      });
      this.retroCedant = (retroCedants as any[]).map(retroCedant => {
        retroCedant.displayText = retroCedant.customerCode + ' - ' + retroCedant.customerName;
        return retroCedant;
      });
      this.companiesFromList = companies.map(division => {
        division.displayText = division.companyCode + ' - ' + division.companyName;
        return division;
      });
      this.companiesToList = this.companiesFromList;
      this.divisionsFromList = divisions.map(division => {
        division.displayText = division.divisionCode + ' - ' + division.divisionName;
        return division;
      });
      this.divisionsToList = this.divisionsFromList;
      this.policiesFromList = activePolicies as any[];
      this.policiesToList = activePolicies as any[];
      this.exportReportsForm.get('placingBroker').setValidators([validSelectionValidator(this.placingBrokers)]);
      this.exportReportsForm.get('accountBroker').setValidators([validSelectionValidator(this.accountBrokers)]);
      this.exportReportsForm.get('cedant').setValidators([validSelectionValidator(this.cedants)]);
      this.exportReportsForm.get('insured').setValidators([validSelectionValidator(this.insureds)]);
      this.exportReportsForm.get('retroCedant').setValidators([validSelectionValidator(this.retroCedant)]);
      this.exportReportsForm.get('coverHolder').setValidators([validSelectionValidator(this.coverHolders)]);
      this.exportReportsForm.get('policyNumberFrom').setValidators([validSelection(this.policiesFromList)]);
      this.exportReportsForm.get('policyNumberTo').setValidators([validSelection(this.policiesToList)]);
      this.loaderService.isBusy = false;
    },
      err => {
        this.loaderService.isBusy = false;
      }
    );
  }

  back() {
    this.location.back();
  }

  reset() {

    this.exportReportsForm.patchValue({
      companyCodeFrom: null,
      companyCodeTo: null,
      divisionCodeFrom: null,
      divisionCodeTo: null,
      lineOfBusinessCodeFrom: null,
      lineOfBusinessCodeTo: null,
      placementMethodFrom: null,
      placementMethodTo: null,
      placingCodeFrom: null,
      placingCodeTo: null,
      placingBroker: null,
      accountBroker: null,
      cedant: null,
      insured: null,
      retroCedant: null,
      coverHolder: null,
      programCode: null,
      territoryCode: null,
      policyNumberFrom: null,
      policyNumberTo: null,
      underWritingYearFrom: null,
      underWritingYearTo: null,
      inceptionDateFrom: null,
      inceptionDateTo: null,
      approvedDateFrom: null,
      approvedDateTo: null,
      renewableStatus: false,
      underwriterUserId: null,
      status: null
    });
  }

  searchPolicyReportData(type): void {

    if (this.exportReportsForm.valid) {

      const criteriaData = this.exportReportsForm.value;
      const searchCriteria: any = {

        companyCodeFrom: criteriaData.companyCodeFrom ? criteriaData.companyCodeFrom.companyCode : '',
        companyCodeFromName: criteriaData.companyCodeFrom ? criteriaData.companyCodeFrom.companyName : '',
        companyCodeTo: criteriaData.companyCodeTo ? criteriaData.companyCodeTo.companyCode : '',
        companyCodeToName: criteriaData.companyCodeTo ? criteriaData.companyCodeTo.companyName : '',
        divisionCodeFrom: criteriaData.divisionCodeFrom ? criteriaData.divisionCodeFrom.divisionCode : '',
        divisionCodeFromName: criteriaData.divisionCodeFrom ? criteriaData.divisionCodeFrom.divisionName : '',
        divisionCodeTo: criteriaData.divisionCodeTo ? criteriaData.divisionCodeTo.divisionCode : '',
        divisionCodeToName: criteriaData.divisionCodeTo ? criteriaData.divisionCodeTo.divisionName : '',
        lineOfBusinessCodeFrom: criteriaData.lineOfBusinessCodeFrom ? criteriaData.lineOfBusinessCodeFrom.id : '',
        lineOfBusinessCodeFromDesc: criteriaData.lineOfBusinessCodeFrom ? criteriaData.lineOfBusinessCodeFrom.description : '',
        lineOfBusinessCodeTo: criteriaData.lineOfBusinessCodeTo ? criteriaData.lineOfBusinessCodeTo.id : '',
        lineOfBusinessCodeToDesc: criteriaData.lineOfBusinessCodeTo ? criteriaData.lineOfBusinessCodeTo.description : '',
        placementMethodFrom: criteriaData.placementMethodFrom ? criteriaData.placementMethodFrom.id : '',
        placementMethodFromDesc: criteriaData.placementMethodFrom ? criteriaData.placementMethodFrom.description : '',
        placementMethodTo: criteriaData.placementMethodTo ? criteriaData.placementMethodTo.id : '',
        placementMethodToDesc: criteriaData.placementMethodTo ? criteriaData.placementMethodTo.description : '',
        placingCodeFrom: criteriaData.placingCodeFrom ? criteriaData.placingCodeFrom.id : '',
        placingCodeFromDesc: criteriaData.placingCodeFrom ? criteriaData.placingCodeFrom.description : '',
        placingCodeTo: criteriaData.placingCodeTo ? criteriaData.placingCodeTo.id : '',
        placingCodeToDesc: criteriaData.placingCodeTo ? criteriaData.placingCodeTo.description : '',
        programCode: criteriaData.programCode ? criteriaData.programCode.id : '',
        programCodeDesc: criteriaData.programCode ? criteriaData.programCode.description : '',
        territoryCode: criteriaData.territoryCode ? criteriaData.territoryCode.id : '',
        territoryCodeDesc: criteriaData.territoryCode ? criteriaData.territoryCode.description : '',
        underWritingYearFrom: criteriaData.underWritingYearFrom ? criteriaData.underWritingYearFrom : null,
        underWritingYearTo: criteriaData.underWritingYearTo ? criteriaData.underWritingYearTo : null,
        inceptionDateFrom: criteriaData.inceptionDateFrom ? moment(criteriaData.inceptionDateFrom).format('DD-MM-YYYY') : '',
        inceptionDateTo: criteriaData.inceptionDateTo ? moment(criteriaData.inceptionDateFrom).format('DD-MM-YYYY') : '',
        createdDateFrom: criteriaData.approvedDateFrom ? moment(criteriaData.inceptionDateFrom).format('DD-MM-YYYY') : '',
        createdDateTo: criteriaData.approvedDateTo ? moment(criteriaData.inceptionDateFrom).format('DD-MM-YYYY') : '',
        renewableStatus: criteriaData.renewableStatus ? 'Y' : 'N',
        underwriterUserId: criteriaData.underwriterUserId ? criteriaData.underwriterUserId : '',
        status: criteriaData.status ? criteriaData.status.id : '',
        statusDesc: criteriaData.status ? criteriaData.status.description : ''
      };
      if (criteriaData.placingBroker) {

        const placingBroker = this.placingBrokers.find(broker => broker.displayText === criteriaData.placingBroker);
        if (placingBroker) {

          searchCriteria.placingBroker = placingBroker.customerCode;
          searchCriteria.placingBrokerDesc = placingBroker.customerName;
        }
      }
      if (criteriaData.accountBroker) {

        const accountBroker = this.placingBrokers.find(broker => broker.displayText === criteriaData.accountBroker);
        if (accountBroker) {

          searchCriteria.accountBroker = accountBroker.customerCode;
          searchCriteria.accountBrokerDesc = accountBroker.customerName;
        }
      }
      if (criteriaData.cedant) {

        const cedantValue = this.cedants.find(cedant => cedant.displayText === criteriaData.cedant);
        if (cedantValue) {

          searchCriteria.cedant = cedantValue.customerCode;
          searchCriteria.cedantName = cedantValue.customerName;
        }
      }
      if (criteriaData.insured) {

        const insuredValue = this.insureds.find(insured => insured.displayText === criteriaData.insured);
        if (insuredValue) {

          searchCriteria.insured = insuredValue.customerCode;
          searchCriteria.insuredName = insuredValue.customerName;
        }
      }
      if (criteriaData.retroCedant) {

        const retroCedantValue = this.retroCedant.find(retroCedant => retroCedant.displayText === criteriaData.retroCedant);
        if (retroCedantValue) {

          searchCriteria.retroCedant = retroCedantValue.customerCode;
          searchCriteria.retroCedantName = retroCedantValue.customerName;
        }
      }
      if (criteriaData.coverHolder) {

        const coverHolderValue = this.coverHolders.find(coverHolder => coverHolder.displayText === criteriaData.coverHolder);
        if (coverHolderValue) {

          searchCriteria.coverHolder = coverHolderValue.customerCode;
          searchCriteria.coverHolderName = coverHolderValue.customerName;
        }
      }
      if (criteriaData.policyNumberFrom) {

        const policyNumberFrom = this.policiesFromList.find(policy => policy.policyNo === criteriaData.policyNumberFrom);
        if (policyNumberFrom) {

          searchCriteria.policyNumberFrom = Number(policyNumberFrom.transactionId);
          searchCriteria.policyNumberFromDesc = policyNumberFrom.policyNo;
        }
      }
      if (criteriaData.policyNumberTo) {

        const policyNumberTo = this.policiesToList.find(policy => policy.policyNo === criteriaData.policyNumberTo);
        if (policyNumberTo) {

          searchCriteria.policyNumberTo = Number(policyNumberTo.transactionId);
          searchCriteria.policyNumberToDesc = policyNumberTo.policyNo;
        }
      }
      const formData: FormData = new FormData();
      formData.append(
        'reportSearchCriteria',
        JSON.stringify(searchCriteria)
      );
      this.loaderService.isBusy = true;
      this.reportService.searchPolicyReportData(formData, type).subscribe(
        data => {

          this.loaderService.isBusy = false;
          const blob = new Blob([data]);
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          let extension = 'pdf';
          if (type === 'xl') {
            extension = 'xls';
          } else if (type === 'docx') {
            extension = 'docx';
          }
          a.download = 'report.' + extension;
          document.body.appendChild(a);
          a.click();
          this.toastService.success('Report has been exported successfully');
        },
        err => {
          this.loaderService.isBusy = false;
          this.toastService.error(this.commonService.getErrorMessage(err));
        }
      );
    } else {
      this.toastService.error('Please Enter Mandatory Fields');
      this.validationHelper.validateAllFormFields(this.exportReportsForm);
    }
  }

  onCompanyChanged() {

    const fromCompany = this.exportReportsForm.get('companyCodeFrom').value;
    this.exportReportsForm.get('companyCodeTo').setValue(fromCompany);
    this.companiesToList = Utils.filterComboValues(this.companiesFromList, 'companyCode', fromCompany.companyCode);
  }

  onDivisionChanged() {

    const divisionFrom = this.exportReportsForm.get('divisionCodeFrom').value;
    this.exportReportsForm.get('divisionCodeTo').setValue(divisionFrom);
    this.divisionsToList = Utils.filterComboValues(this.divisionsFromList, 'divisionCode', divisionFrom.divisionCode);
  }

  onLobChanged() {

    const lineOfBusinessCodeFrom = this.exportReportsForm.get('lineOfBusinessCodeFrom').value;
    if (lineOfBusinessCodeFrom) {
      this.exportReportsForm.get('lineOfBusinessCodeTo').setValue(lineOfBusinessCodeFrom);
      this.lineOfBusinessesToList = Utils.filterComboValues(this.lineOfBusinessesFromList, 'id', lineOfBusinessCodeFrom.id);
    } else {
      this.lineOfBusinessesToList = this.lineOfBusinessesFromList;
    }
  }

  onMopChanged() {

    const placementMethodFrom = this.exportReportsForm.get('placementMethodFrom').value;
    if (placementMethodFrom) {
      this.exportReportsForm.get('placementMethodTo').setValue(placementMethodFrom);
      this.placementMethodsToList = Utils.filterComboValues(this.placementMethodsFromList, 'id', placementMethodFrom.id);
    } else {
      this.placementMethodsToList = this.placementMethodsFromList;
    }
  }

  onPlacingChanged() {

    const placingCodeFrom = this.exportReportsForm.get('placingCodeFrom').value;
    if (placingCodeFrom) {
      this.exportReportsForm.get('placingCodeTo').setValue(placingCodeFrom);
      this.placingsToList = Utils.filterComboValues(this.placingsFromList, 'id', placingCodeFrom.id);
    } else {
      this.placingsToList = this.placingsFromList;
    }
  }

  onUWyearChanged() {

    const uwYearFrom = this.exportReportsForm.get('underWritingYearFrom').value;
    if (uwYearFrom) {
      this.exportReportsForm.get('underWritingYearTo').setValue(uwYearFrom);
      this.uwYearsToList = Utils.filterComboValues(this.uwYearsFromList, 'value', uwYearFrom);
    } else {
      this.uwYearsToList = this.uwYearsFromList;
    }
  }

  setToDate(date: any, key) {
    if (date) {
      this.exportReportsForm.get(key).setValue(date);
    }
  }

  onSelectPolicyFrom() {

    const policyFrom = this.exportReportsForm.get('policyNumberFrom').value;
    if (policyFrom) {
      this.exportReportsForm.get('policyNumberTo').setValue(policyFrom);
      const transId = this.policiesFromList.find(policy => policy.policyNo === policyFrom).transactionId;
      this.policiesToList = Utils.filterComboValues(this.policiesFromList, 'transactionId', transId);
    } else {
      this.policiesToList = this.policiesFromList;
    }
  }
}
