import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { Module } from '@ag-grid-enterprise/all-modules';
import { ColumnsToolPanelModule } from '@ag-grid-enterprise/column-tool-panel';
import { MenuModule } from '@ag-grid-enterprise/menu';
import { RichSelectModule } from '@ag-grid-enterprise/rich-select';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { forkJoin } from 'rxjs';
import { ToastService } from 'src/app/services/toast.service';
import { ReportService } from '../../services/reports.service';
import { LoaderService } from './../../../../services/loader.service';

@Component({
  selector: 'app-report-column',
  templateUrl: './report-column.component.html',
  styleUrls: ['./report-column.component.scss']
})
export class ReportColumnComponent implements OnInit {
  showForm: boolean;
  reportcolumnDefs: any;
  reportColList: any;
  viewList: any;
  viewType = "";
  quickSearchValue: any;
  gridApi: any;
  action: string;

  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  keyword: any = 'value';
  initialValue: any = '';
  data: any;
  isLoadingResult: boolean;
  errorMsg: string = "";
  editType: any;
  defaultColDef: any;
  gridLoading = false;

  public modules: Module[] = [
    ClientSideRowModelModule,
    RichSelectModule,
    MenuModule,
    ColumnsToolPanelModule
  ];
  dataTypeList: any;
  inputTypeList: any;

  dataIdList: any;
  constructor(
    private router: Router,
    private reportService: ReportService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,
  ) { }

  ngOnInit(): void {
    this.getViewList();
    this.getAppcodes();
  }

  setReportColumnDefs() {

    let thisObj = this;
    this.reportcolumnDefs = [
      {
        headerName: 'Column Name',
        field: 'rcDispName',
      },
      {
        headerName: 'Data Type',
        field: 'rcDataType',
        cellEditor: 'agSelectCellEditor',
        cellEditorParams: {
          values: thisObj.dataTypeList.map((s: any) => s.acDesc)
        },

        valueSetter: function (params: any) {
          for (let i = 0; i < thisObj.dataTypeList.length; i++) {
            if (thisObj.dataTypeList[i].acDesc == params.newValue) {
              params.data.rcDataType = thisObj.dataTypeList[i].acCode;
            }
          }
          return true;
        },
        valueGetter: function (params: any) {
          let value = "";
          if (params && params.data && params.data.rcDataType) {
            for (let i = 0; i < thisObj.dataTypeList.length; i++) {
              if (thisObj.dataTypeList[i].acCode == params.data.rcDataType) {
                value = thisObj.dataTypeList[i].acDesc;
              }
            }
          }
          return value;
        }

      },
      {
        headerName: 'Input Type',
        field: 'rcInputType',
        cellEditor: 'agSelectCellEditor',
        cellEditorParams: {
          values: thisObj.inputTypeList.map((s: any) => s.acDesc)
        },

        valueSetter: function (params) {
          for (let i = 0; i < thisObj.inputTypeList.length; i++) {
            if (thisObj.inputTypeList[i].acDesc == params.newValue) {
              params.data.rcInputType = thisObj.inputTypeList[i].acCode;
            }
          }
          return true;
        },
        valueGetter: function (params) {
          let value = "";
          if (params && params.data && params.data.rcInputType) {
            for (let i = 0; i < thisObj.inputTypeList.length; i++) {
              if (thisObj.inputTypeList[i].acCode == params.data.rcInputType) {
                value = thisObj.inputTypeList[i].acDesc;
              }
            }
          }
          return value;
        }
      },
      {
        headerName: 'Data Id',
        field: 'rcDataId',
        cellEditor: 'agSelectCellEditor',
        cellEditorParams: {
          values: thisObj.dataIdList.map((s: any) => s.acDesc)
        },

        valueSetter: function (params) {

          for (let i = 0; i < thisObj.dataIdList.length; i++) {
            if (thisObj.dataIdList[i].acDesc == params.newValue) {
              params.data.rcDataId = thisObj.dataIdList[i].acCode;
            }
          }
          return true;
        },
        valueGetter: function (params) {
          let value = "";
          if (params && params.data && params.data.rcDataId) {
            for (let i = 0; i < thisObj.dataIdList.length; i++) {
              if (thisObj.dataIdList[i].acCode == params.data.rcDataId) {
                value = thisObj.dataIdList[i].acDesc;
              }
            }
          }
          return value;
        }
      },
      {
        headerName: 'Actual Column',
        field: 'id.rcColumnName',
        editable: false,
        enableRowGroup: true,
      },
      {
        headerName: "Action",
        cellRenderer: this.actionRender,
        cellStyle: { textAlign: 'left' },
        editable: false,
        filter: false,
        enableRowGroup: false,
      }
    ];

    this.defaultColDef = {
      flex: 1,
      editable: true,
      filter: true,
      enableRowGroup: true,
      resizable: true,
      sortable: true,
    };

    this.editType = 'fullRow';
  }

  actionRender(params) {

    if (params && params.data && params.data.action == 'Edit') {
      return `<a>
            <i class="fa fa-check fa-icon"  data-action-type="Save" title="Save" aria-hidden="true"></i>
          </a>&nbsp;
          <a>
            <i class="fa fa-close fa-icon fa-danger"  data-action-type="Cancel" title="Cancel" aria-hidden="true"></i>
          </a>
            `;
    } else {
      return `<a>
          <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        </a>`;
    }
  }

  onBtStopEditing() {
    this.gridApi.stopEditing();
  }

  onBtStartEditing(node) {
    //this.gridApi.setFocusedCell(rowIndex, 'rcDispName');
    this.gridApi.startEditingCell({
      rowIndex: node.rowIndex,
      colKey: 'rcDispName',
    });
  }

  getAppcodes() {
    this.gridLoading = true;
    // this.reportService.getAppCodes(appCode).subscribe(resp => {
    //   switch(type){
    //     case "DataType":
    //         this.dataTypeList = JSON.parse(JSON.stringify(resp));
    //         //this.refreshAllRows();
    //       break;
    //     case "InputType":
    //       //this.inputTypeList = resp;
    //       break;
    //     case "DataId":
    //       this.dataIdList = JSON.parse(JSON.stringify(resp));
    //       //this.refreshAllRows();
    //       break;
    //   }
    // }, error => {
    // });

    forkJoin(
      this.reportService.getAppCodes('ENQ_DATA_TYP'),
      this.reportService.getAppCodes('ENQ_FRM_FLD'),
      this.reportService.getAppCodes('ENQ_LOOKUP')
    )
      .subscribe(
        data => {
          this.dataTypeList = data[0];
          this.inputTypeList = data[1];
          this.dataIdList = data[2];
          this.gridLoading = false;
          this.setReportColumnDefs();
          console.log(data);

        },
        err => {
          this.gridLoading = false;
        });
  }
  getReportColumnList(viewCode, type) {
    this.loaderService.isBusy = (type == "Refresh") ? true : false;
    this.gridLoading = (type == "Init") ? true : false;
    this.reportService.getReportColumnList(viewCode).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.gridLoading = false;
      this.reportColList = resp;
      for (let j = 0; j < this.reportColList.length; j++) {
        this.reportColList[j].action = "readonly";
      }
    }, error => {
      this.loaderService.isBusy = false;
      this.gridLoading = false;
      this.reportColList = [];
    });
  }

  cleanAllRows() {
    this.onBtStopEditing();
    for (let i = 0; i < this.reportColList.length; i++) {
      this.reportColList[i].action = "readonly";
    }
    let params = {
      force: true,
      suppressFlash: true,
    };
    this.gridApi.refreshCells(params);
  }

  refreshAllRows() {
    let params = {
      force: true,
      suppressFlash: true,
    };
    this.gridApi.refreshCells(params);
  }

  reportColReset() {
    this.getReportColumnList(this.viewType, "Refresh");
  }

  getViewList() {
    this.gridLoading = true;
    this.reportService.getViewList().subscribe(resp => {
      this.gridLoading = false;
      this.viewList = resp;
      if (this.viewList.length > 0) {
        this.getReportColumnList(this.viewList[0].key, "Init");
        this.viewType = this.viewList[0].key;
      } else {
        this.reportColList = [];
      }
    }, error => {
      this.gridLoading = false;
      this.reportColList = [];
    });
  }

  updateReportColResp: any;
  saveData(e) {

    this.onBtStopEditing();
    this.reportColList[e.node.id].action = "readonly";
    var params = {
      force: true,
      suppressFlash: true,
    };
    this.gridApi.refreshCells(params);

    let reqData = {
      "rcDataId": (e.data.rcDataId) ? e.data.rcDataId : 0,
      "rcDataType": (e.data.rcDataType) ? e.data.rcDataType : "",
      "rcDispName": (e.data.rcDispName) ? e.data.rcDispName : "",
      "rcInputType": (e.data.rcInputType) ? e.data.rcInputType : "",
      "rcUpdDt": new Date(),
      "rcUpdUid": this.session.get('userId')
    };

    this.loaderService.isBusy = true;
    this.reportService.updateReportColumn(this.viewType, e.data.id.rcColumnName, reqData).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.updateReportColResp = resp;
      if (resp["messageType"] && resp["messageType"] == 'E') {
        this.toastService.error(resp["message"]);
      } else if (resp["messageType"] && resp["messageType"] == 'S') {
        this.toastService.success(resp["message"]);
      } else {
        this.toastService.success("Updated Successfully!");
      }
      if (this.viewList.length > 0) {
        this.getReportColumnList(this.viewType, "Refresh");
      }
    }, err => {
      this.toastService.error("Error in update report column!");
      this.loaderService.isBusy = false;
    });

  }

  cancelEdit(e) {
    this.onBtStopEditing();
    this.reportColList[e.node.id].action = "readonly";
    var params = {
      force: true,
      suppressFlash: true,
    };
    this.gridApi.refreshCells(params);
  }

  onRowClicked(e) {
    if (e.event.target !== undefined) {

      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      console.log(e)
      switch (actionType) {
        case "Edit":
          for (let i = 0; i < this.reportColList.length; i++) {
            this.reportColList[i].action = "readonly";
          }
          this.reportColList[e.node.id].action = "Edit";
          this.onBtStartEditing(e.node);
          let params = {
            force: true,
            suppressFlash: true,
          };
          this.gridApi.refreshCells(params);
          break;
        case "Save":
          this.saveData(e);
          break;
        case "Cancel":
          this.cancelEdit(e);
          break;
        default:
          for (let i = 0; i < this.reportColList.length; i++) {
            if (this.reportColList[i].action == "Edit") {
              this.onBtStartEditing(i);
              let params = {
                force: true,
                suppressFlash: true,
              };
              this.gridApi.refreshCells(params);
            }
          }
          break;
      }
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
    this.cleanAllRows();
  }

  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    }
  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
    this.cleanAllRows();
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
    this.cleanAllRows();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("reportColTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  back() {
    this.router.navigate(['/master/admindashboard']);
  }
}
