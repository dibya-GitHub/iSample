import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/reports/components/report-column/report-column.component.spec.ts
import { ReportColumnComponent } from './report-column.component';

describe('ReportColumnComponent', () => {
  let component: ReportColumnComponent;
  let fixture: ComponentFixture<ReportColumnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportColumnComponent ]
=======
import { EgnpContractComponent } from './egnp-contract.component';

describe('EgnpContractComponent', () => {
  let component: EgnpContractComponent;
  let fixture: ComponentFixture<EgnpContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EgnpContractComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/egnp-contract/egnp-contract.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/reports/components/report-column/report-column.component.spec.ts
    fixture = TestBed.createComponent(ReportColumnComponent);
=======
    fixture = TestBed.createComponent(EgnpContractComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/egnp-contract/egnp-contract.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
