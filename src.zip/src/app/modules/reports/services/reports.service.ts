import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  mgaUrl = environment.mgaUrl;

  constructor(private httpClient: HttpClient) { }

  searchPolicyReportData(requestData, type) {

    const params: any = {};
    params.responseType = 'arrayBuffer';
    return this.httpClient.put(environment.reportBaseUrl + '/api/searchPolicyReportData/'
      + type + '  ', requestData, params);
  }
  getAppCodes(type) {
    return this.httpClient.get(environment.commonBaseUrl + 'appcodes-mgmt/appcodes/type/' + type);
  }
  getReportColumnList(viewCode) {
    return this.httpClient.get(this.mgaUrl + 'reports/view-columns/' + viewCode);
  }

  getViewList() {
    return this.httpClient.get(this.mgaUrl + 'reports/views');
  }

  updateReportColumn(viewCode, colName, reqData) {
    return this.httpClient.put(this.mgaUrl + 'reports/report-columns/' + viewCode + '/' + colName, reqData);
  }
}
