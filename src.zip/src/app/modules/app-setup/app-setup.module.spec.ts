import { AppSetupModule } from './app-setup.module';

describe('AppSetupModule', () => {
  let appSetupModule: AppSetupModule;

  beforeEach(() => {
    appSetupModule = new AppSetupModule();
  });

  it('should create an instance', () => {
    expect(appSetupModule).toBeTruthy();
  });
});
