import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
<<<<<<< HEAD
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { DropdownModule } from 'primeng/dropdown';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { AppSetupRoutingModule } from './app-setup-routing.module';
import { AppConfigComponent } from './components/app-config/app-config.component';
import { AppParamComponent } from './components/app-param/app-param.component';
import { CompanyMasterComponent } from './components/company-master/company-master.component';
import { CostCenterComponent } from './components/cost-center/cost-center.component';
import { CustomizablePwdScreenComponent } from './components/customizable-pwd-screen/customizable-pwd-screen.component';
import { ExchangeRateGridComponent } from './components/exchange-rate-grid/exchange-rate-grid.component';
import { ExchangeRateComponent } from './components/exchange-rate/exchange-rate.component';
import { MAppConfigComponent } from './components/m-app-config/m-app-config.component';
import { MAppParamComponent } from './components/m-app-param/m-app-param.component';
import { MDepartmentComponent } from './components/m-department/m-department.component';
import { MDivisionComponent } from './components/m-division/m-division.component';
import { MTeamComponent } from './components/m-team/m-team.component';
import { OrgStructureComponent } from './components/org-structure/org-structure.component';
import { AppSetupService } from './services/app-setup.service';
<<<<<<< HEAD
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@NgModule({
  imports: [
    CommonModule,
    AppSetupRoutingModule,
    CommonAppModule,
    TypeaheadModule.forRoot(),
    DropdownModule
  ],
  declarations: [
    AppConfigComponent,
    MAppConfigComponent,
    AppParamComponent,
    MAppParamComponent,
    ExchangeRateComponent,
    ExchangeRateGridComponent,
    MDivisionComponent,
    CostCenterComponent,
    MDepartmentComponent,
    MTeamComponent,
    OrgStructureComponent,
    CompanyMasterComponent,
    CustomizablePwdScreenComponent
  ],
  providers: [AppSetupService]
})
export class AppSetupModule { }
