import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
<<<<<<< HEAD
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';
=======
import { SessionStorageService } from 'angular-web-storage';
import { environment } from 'src/environments/environment';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Injectable({
    providedIn: 'root'
})
export class AppSetupService {
    requestOption: any;
<<<<<<< HEAD
    commonBaseUrl = environment.commonBaseUrl;
    constructor(
        private httpService: HttpClient,
        private route: ActivatedRoute,
        private session: SessionStorageService,
        private authService: AuthService

    ) {
=======
    instanceId:any;
    constructor(private httpService: HttpClient, private route: ActivatedRoute,
        private session: SessionStorageService,private authService: AuthService) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        const headersOpt = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })
        this.requestOption = { headers: headersOpt };
        this.instanceId = this.authService.getInstanceCode();
    }
    // ---------------App Config-------------------//

    retrieveAppConfigDetails(path?: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get(this.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.authService.getInstanceCode()),
=======
        return this.httpService.get(environment.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.instanceId),
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            this.requestOption);
    }

    retrieveAppConfigById(body: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get(this.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.authService.getInstanceCode()) + '/' +
=======
        return this.httpService.get(environment.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.instanceId) + '/' +
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            body.acName,
            this.requestOption);
    }

    insertAppConfigDetails(body: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.post(this.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.authService.getInstanceCode()),
=======
        return this.httpService.post(environment.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.instanceId),
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            body,
            this.requestOption);
    }

    updateAppConfigDetails(body: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.put(this.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.authService.getInstanceCode()) + '/' + body.acName,
=======
        return this.httpService.put(environment.commonBaseUrl +
            ApiUrls.APP_CONFIG_PATH.replace('{instanceId}', this.instanceId) + '/' + body.acName,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            body,
            this.requestOption);
    }

    // -----------------END------------------------- //

    // ---------------- App Params----------------- //
    retrieveAppParamsDetails(): Observable<any> {
        return this.httpService.get(this.commonBaseUrl +
            ApiUrls.APP_PARAMS_PATH,
            this.requestOption);
    }

    retrieveAppParamsById(requestObj: any): Observable<any> {
        return this.httpService.get(this.commonBaseUrl +
            ApiUrls.APP_PARAMS_PATH + '/' + requestObj.paraCode + '/' + requestObj.paraSubCode,
            this.requestOption);
    }

    insertAppParamsDetails(body: any): Observable<any> {
        return this.httpService.post(this.commonBaseUrl +
            ApiUrls.APP_PARAMS_PATH, body, this.requestOption);
    }

    updateAppParamsDetails(body: any, requestObj: any): Observable<any> {
        return this.httpService.put(this.commonBaseUrl +
            ApiUrls.APP_PARAMS_PATH + '/' + requestObj.paraCode + '/' + requestObj.paraSubCode, body, this.requestOption);
    }
    // ------------------END----------------------- //

    // -----------------------Exchange Rate-------------------------//
    loadExchangeRateGrid(param: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get<any>(this.commonBaseUrl + 'exchangeRate' + '/' + ApiUrls.INSTANCE + '/' + this.authService.getInstanceCode() + '/exchange-rate/' + param.erRateFor + "?curCode=" + param.erConvFmCurrCode + "&srchDate=" + param.erEffFrmDt, this.requestOption);
=======
        return this.httpService.get<any>(environment.commonBaseUrl + 'exchangeRate' + '/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/exchange-rate/' + param.erRateFor + "?curCode=" + param.erConvFmCurrCode + "&srchDate=" + param.erEffFrmDt, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
    retrieveExchangRateType(): Observable<any> {
        return this.httpService.get<any>(this.commonBaseUrl + 'exchangeRate/exchange-type/EXG_RATE_FOR', this.requestOption);
    }
    retrieveExchCurrList(): Observable<any> {
        return this.httpService.get<any>(this.commonBaseUrl + 'exchangeRate/currency', this.requestOption);
    }
    retrieveExchDateList(): Observable<any> {
        return this.httpService.get<any>(this.commonBaseUrl + 'exchangeRate/date', this.requestOption);
    }

    searchExchRateById(param: any, path: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get<any>(this.commonBaseUrl + 'exchangeRate/instance/' + this.authService.getInstanceCode() + "/exchange-rate/" + param.erRateFor + "?curCode=" + param.erConvFmCurrCode + "&srchDate=" + param.erEffFrmDt, this.requestOption);
    }
    retrieveExchRateById(body): Observable<any> {
        return this.httpService.get<any>(this.commonBaseUrl + 'exchangeRate/instance/' + this.authService.getInstanceCode() + "/exchange-rate/" + body.erRateFor + "?exchFrmDate=" + body.exchFrmDate + "&exchToDate=" + body.exchToDate +
=======
        return this.httpService.get<any>(environment.commonBaseUrl + 'exchangeRate/instance/' + this.instanceId + "/exchange-rate/" + param.erRateFor + "?curCode=" + param.erConvFmCurrCode + "&srchDate=" + param.erEffFrmDt, this.requestOption);
    }
    retrieveExchRateById(body): Observable<any> {
        return this.httpService.get<any>(environment.commonBaseUrl + 'exchangeRate/instance/' + this.instanceId + "/exchange-rate/" + body.erRateFor + "?exchFrmDate=" + body.exchFrmDate + "&exchToDate=" + body.exchToDate +
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            "&exchCurrFrm=" + body.exchCurrFrm + "&exchCurrTo=" + body.exchCurrTo, this.requestOption);
    }

    updateExchRate(body): Observable<any> {
        return this.httpService.put<any>(this.commonBaseUrl + 'exchangeRate/instance/' + body.erInstId + "/exchange-type/" +
            body.exchangeRatePK.erRateFor,
            body,
            this.requestOption);
    }
    insertExchRate(body): Observable<any> {
<<<<<<< HEAD
        return this.httpService.post(this.commonBaseUrl + 'exchangeRage/instance/' + body.erInstId + "/exchange-rates",
=======
        console.log(body)
        return this.httpService.post(environment.commonBaseUrl + 'exchangeRate/instance/' + body.erInstId + "/exchange-rates",
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            body,
            this.requestOption);
    }


    //-----------------------Team-------------------------//

    updateteamInfo(body: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.put(this.commonBaseUrl + ApiUrls.TEAM_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.TEAM_MAPPING_PATH + "/" + body.teamCode, body, this.requestOption);
    }
    saveTeamInfo(body: any): Observable<any> {
        return this.httpService.post(this.commonBaseUrl + ApiUrls.TEAM_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.TEAM_MAPPING_PATH + "/" + body.teamCode, body, this.requestOption);
    }
    selectTeamById(body: any): Observable<any> {
        return this.httpService.get(this.commonBaseUrl + ApiUrls.TEAM_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.TEAM_MAPPING_PATH + "/" + body.teamCode +
=======
        return this.httpService.put(environment.commonBaseUrl + ApiUrls.TEAM_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.TEAM_MAPPING_PATH + "/" + body.teamCode, body, this.requestOption);
    }
    saveTeamInfo(body: any): Observable<any> {
        return this.httpService.post(environment.commonBaseUrl + ApiUrls.TEAM_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.TEAM_MAPPING_PATH + "/" + body.teamCode, body, this.requestOption);
    }
    selectTeamById(body: any): Observable<any> {
        return this.httpService.get(environment.commonBaseUrl + ApiUrls.TEAM_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.TEAM_MAPPING_PATH + "/" + body.teamCode +
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            "?teamCompCode=" + body.teamCompCode + "&teamDivnCode=" + body.teamDivnCode + "&teamCostCode=" + body.teamCostCode + "&teamDeptCode=" + body.teamDeptCode, this.requestOption);
    }

    retrieveDeptList(compCode: any): Observable<any> {
        return this.httpService.get(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + '/getDeptByCmpCode?compCode=' + compCode, this.requestOption);
    }

    //------------------------End-----------------------//

    /* ---------------- START---- DEPARTMENT Details --------------  */

    retrieveCompanyList() {
<<<<<<< HEAD
        return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMPANY_PATH + "/" + ApiUrls.COMPANY_LIST, this.requestOption);
    }

    retrieveDivisionList() {
        return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.GET_DIVN_LIST + '?company=' + this.session.get('companyCode'), this.requestOption);
    }

    retrieveCostCenterList() {
        return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COST_CENTER_LIST, this.requestOption);
=======
        return this.httpService.get<any>(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMPANY_PATH + "/" + ApiUrls.COMPANY_LIST, this.requestOption);
    }

    retrieveDivisionList() {
        return this.httpService.get<any>(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.GET_DIVN_LIST + '?company=' + this.session.get('companyCode'), this.requestOption);
    }

    retrieveCostCenterList() {
        return this.httpService.get<any>(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COST_CENTER_LIST, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }


    retrieveDeptById(body: any): Observable<any> {

<<<<<<< HEAD
        return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.DEPT_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMPANY_MAPPING_PATH + "/" + body.deptCode + "?divncode=" + body.deptDivnCode + "&deptcostcode=" + body.deptCostCode + "&deptCompCode=" + body.deptCompCode, this.requestOption);
=======
        return this.httpService.get<any>(environment.commonBaseUrl + ApiUrls.DEPT_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMPANY_MAPPING_PATH + "/" + body.deptCode + "?divncode=" + body.deptDivnCode + "&deptcostcode=" + body.deptCostCode + "&deptCompCode=" + body.deptCompCode, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }


    updateDeptById(body: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.put(this.commonBaseUrl + ApiUrls.DEPT_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMPANY_MAPPING_PATH + "/" + body.deptCode, body, this.requestOption);
=======
        return this.httpService.put(environment.commonBaseUrl + ApiUrls.DEPT_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMPANY_MAPPING_PATH + "/" + body.deptCode, body, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

    }

    saveDeptDetails(body: any): Observable<any> {

<<<<<<< HEAD
        return this.httpService.post(this.commonBaseUrl + ApiUrls.DEPT_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMPANY_MAPPING_PATH + "/" + body.deptCode, body, this.requestOption);
=======
        return this.httpService.post(environment.commonBaseUrl + ApiUrls.DEPT_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMPANY_MAPPING_PATH + "/" + body.deptCode, body, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

    }

    /* ---------------- END---- DEPARTMENT Details --------------  */

    //------------------Company--------------------------------//
    retrieveCompanyByPK(obj: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMP_PATH + "/" + obj.compCode, this.requestOption);
=======
        return this.httpService.get<any>(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMP_PATH + "/" + obj.compCode, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }


    saveCompanyDetails(body: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.post(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMP_PATH, body);
    }

    updateCompanyDetails(body: any, params: any): Observable<any> {
        return this.httpService.put(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMP_PATH + "/" + params.compCode, body, this.requestOption);
    }

    retrieveDivisions() {
        return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.GET_DIVN_LIST, this.requestOption);
=======
        return this.httpService.post(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMP_PATH, body);
    }

    updateCompanyDetails(body: any, params: any): Observable<any> {
        return this.httpService.put(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMP_PATH + "/" + params.compCode, body, this.requestOption);
    }

    retrieveDivisions() {
        return this.httpService.get<any>(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.GET_DIVN_LIST, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }

    retrieveCurrency() {
        return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.COMP_PATH + "/" + ApiUrls.GET_CURRENCY_LIST, this.requestOption);
    }

    //-----------------------Division----------------//


    retrieveCompanies() {
<<<<<<< HEAD
        return this.httpService.get<any>(this.commonBaseUrl + "/" + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMP_PATH + "/" + ApiUrls.GET_COMPANY_LIST, this.requestOption);
    }

    saveDivisionDetails(body: any): Observable<any> {
        return this.httpService.post(this.commonBaseUrl + ApiUrls.DIVISION_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.DIVN_PATH, body);
    }

    updateDivisionDetails(body: any, params: any): Observable<any> {
        return this.httpService.put(this.commonBaseUrl + ApiUrls.DIVISION_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.DIVN_PATH + "/" + params.divnCode + "/" + params.divnCompCode, body, this.requestOption);
    }

    retrieveDivisionByPk(divnpk: any): Observable<any> {
        return this.httpService.get(this.commonBaseUrl + ApiUrls.DIVISION_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.DIVN_PATH + "/" + divnpk.divnCode + "/" + divnpk.divnCompCode, this.requestOption);
=======
        return this.httpService.get<any>(environment.commonBaseUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMP_PATH + "/" + ApiUrls.GET_COMPANY_LIST, this.requestOption);
    }

    saveDivisionDetails(body: any): Observable<any> {
        return this.httpService.post(environment.commonBaseUrl + ApiUrls.DIVISION_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.DIVN_PATH, body);
    }

    updateDivisionDetails(body: any, params: any): Observable<any> {
        return this.httpService.put(environment.commonBaseUrl + ApiUrls.DIVISION_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.DIVN_PATH + "/" + params.divnCode + "/" + params.divnCompCode, body, this.requestOption);
    }

    retrieveDivisionByPk(divnpk: any): Observable<any> {
        return this.httpService.get(environment.commonBaseUrl + ApiUrls.DIVISION_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.DIVN_PATH + "/" + divnpk.divnCode + "/" + divnpk.divnCompCode, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }


    //------------------Cost Centre--------------------//

    saveCostCentreDetails(body: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.post(this.commonBaseUrl + ApiUrls.COSTCENTER_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COST_CENT_PATH, body);
    }

    updateCostCentreDetails(body: any): Observable<any> {
        return this.httpService.put(this.commonBaseUrl + ApiUrls.COSTCENTER_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COST_CENT_PATH + "/" + body.mcostCentrePK.costCode, body, this.requestOption);
    }

    retrieveCostCentreByPk(costpk: any): Observable<any> {
        return this.httpService.get(this.commonBaseUrl + ApiUrls.COSTCENTER_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COST_CENT_PATH + "/" + costpk.costCode + "?costCompCode=" + costpk.costCompCode + "&costDivCode=" + costpk.costDivCode, this.requestOption);
=======
        return this.httpService.post(environment.commonBaseUrl + ApiUrls.COSTCENTER_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COST_CENT_PATH, body);
    }

    updateCostCentreDetails(body: any): Observable<any> {
        return this.httpService.put(environment.commonBaseUrl + ApiUrls.COSTCENTER_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COST_CENT_PATH + "/" + body.mcostCentrePK.costCode, body, this.requestOption);
    }

    retrieveCostCentreByPk(costpk: any): Observable<any> {
        return this.httpService.get(environment.commonBaseUrl + ApiUrls.COSTCENTER_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COST_CENT_PATH + "/" + costpk.costCode + "?costCompCode=" + costpk.costCompCode + "&costDivCode=" + costpk.costDivCode, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }


    getParamValue(paramName) {
        let paramVal;
        this.route.queryParams.subscribe(params => {
            paramVal = params[paramName];

        });
        return paramVal;

    }
}
