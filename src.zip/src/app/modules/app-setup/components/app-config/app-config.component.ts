import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppSetupService } from '../../services/app-setup.service';

@Component({
  selector: 'app-app-config',
  templateUrl: './app-config.component.html',
  styleUrls: ['./app-config.component.scss']
})

export class AppConfigComponent {

  public defaultColDef;
  appConfigColDefs: any[];
  appConfigs: any[];
  gridApi: any;
  gridColumnApi: any;
  showEntriesOptionSelected = 10;
  showEntriesOptions = [10, 20, 50, 100];
  quickSearchValue: string;

  constructor(
    private router: Router,
    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
    private toastService: ToastService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.appConfigColDefs = [
      {
        field: 'acName',
        headerName: 'Name'
      },
      {
        field: 'acValue',
        headerName: 'Value'
      },
      {
        field: 'acRemarks',
        headerName: 'Remarks'
      },
      {
        headerName: 'Action',
        cellStyle: { textAlign: 'center' },
        cellRenderer: actionRender,
        field: 'acName',
        filter: false,
        sortable: false,
        enableRowGroup: false,

      },
    ];
    this.getAppConfigs();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  getAppConfigs() {
    this.appSetupService.retrieveAppConfigDetails().subscribe(resp => {
      this.appConfigs = resp.appConfigArray;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case "Edit":
          return this.navigateToForm(data);
      }
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  navigateToForm(data) {
    if (data) {
      this.router.navigate(['/appSetup/appConfig/edit'], { queryParams: { acName: data.acName, action: 'Edit' } });
    } else {
      this.router.navigate(['/appSetup/appConfig/add'], { queryParams: { action: 'Add' } });
    }
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return ` <a>
    <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
    </a>`;
  }
}