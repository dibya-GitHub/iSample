import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAppConfigComponent } from './m-app-config.component';

describe('MAppConfigComponent', () => {
  let component: MAppConfigComponent;
  let fixture: ComponentFixture<MAppConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAppConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAppConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
