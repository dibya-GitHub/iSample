<<<<<<< HEAD
import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppSetupService } from '../../services/app-setup.service';
=======
import { Component, OnInit, Inject, Input } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl, UntypedFormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AppSetupService } from '../../services/app-setup.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-m-app-config',
  templateUrl: './m-app-config.component.html',
  styleUrls: ['./m-app-config.component.css'],
})
export class MAppConfigComponent implements OnInit {

  acName: any;
  appConfigForm: UntypedFormGroup;
  isEdit: boolean;

  constructor(
    private fb: UntypedFormBuilder,
    private appSetupService: AppSetupService,
    private route: Router,
    private activeRouter: ActivatedRoute,
    private loaderService: LoaderService,
<<<<<<< HEAD
    private toastService: ToastService,
    private session: SessionStorageService,
    private authService: AuthService
=======
    private session: SessionStorageService,
    private toastService: ToastService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.activeRouter.queryParams.subscribe((params: any) => {
      if (params) {
        this.acName = params['acName'];
        if (this.acName) {
          this.isEdit = true;
          this.getAppConfigData();
        }
      }
    });
    this.createAppConfigForm();
  }
  createAppConfigForm() {
    this.appConfigForm = this.fb.group({
      acName: ['', Validators.required],
      acValue: ['', Validators.required],
      acRemarks: '',
      acInstId: this.authService.getInstanceCode(),
      acCrUid: this.session.get('userId'),
      acCrDt: new Date(),
      acUpdUid: '',
      acUpdDt: ''
    });
    this.loaderService.isBusy = false;
  }
  save() {
    if (this.appConfigForm.valid) {
      this.loaderService.isBusy = true;

      if (this.isEdit) {
        this.loaderService.isBusy = true;
        this.appSetupService.updateAppConfigDetails(this.appConfigForm.value).subscribe(result => {
          this.toastService.success('Updated Successfully.')
          this.loaderService.isBusy = false;
          if (result["messageType"] && result["messageType"] == 'E') {
            this.toastService.error(result["message"]);
          } else if (result["messageType"] && result["messageType"] == 'S') {
            this.toastService.success(result["message"]);
            this.back();
          }          
        }, error => {
          this.toastService.error(error);
          this.loaderService.isBusy = false;
          this.toastService.error("Somthing went wrong");
        });
      } else {
        this.loaderService.isBusy = true;
        this.appSetupService.insertAppConfigDetails(this.appConfigForm.value).subscribe(result => {
          this.toastService.success('Saved Successfully.')
          this.loaderService.isBusy = false;
          if (result["messageType"] && result["messageType"] == 'E') {
            this.toastService.error(result["message"]);
          } else if (result["messageType"] && result["messageType"] == 'S') {
            this.toastService.success(result["message"]);
            this.back();
          }          
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error("Somthing went wrong");
        });
      }
    } else {
      this.validateAllFormFields(this.appConfigForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  getAppConfigData() {
    this.loaderService.isBusy = true;
    let request = { acName: this.acName };
    this.appSetupService.retrieveAppConfigById(request).subscribe(resp => {
      let result = resp.appConfigArray;
      this.appConfigForm.patchValue({
        acName: result[0].acName,
        acValue: result[0].acValue,
        acRemarks: result[0].acRemarks,
        acCrUid: result[0].acCrUid,
        acCrDt: result[0].acCrDt,
        acUpdUid: result[0].acUpdUid,
        acUpdDt: new Date()
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
  back() {
    this.route.navigate(['/appSetup/appConfig'], { queryParamsHandling: 'merge', queryParams: { action: undefined } });
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

}
