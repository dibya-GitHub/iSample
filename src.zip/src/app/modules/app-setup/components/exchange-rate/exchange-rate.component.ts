import { ToastService } from './../../../../services/toast.service';
import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { ApiUrls } from 'src/app/api-urls';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { AppSetupService } from '../../services/app-setup.service';
declare var $: any;

@Component({
  selector: 'app-exchange-rate',
  templateUrl: './exchange-rate.component.html',
  styleUrls: ['./exchange-rate.component.css'],
  providers: [DatePipe]
})
export class ExchangeRateComponent implements OnInit {
  isDisable: boolean;
  rateFor: any;
  currTo: any;
  currFrom: any;
  toDate: any;
  fromDate: any;
  instId: any;
  buyRate: any;
  sellRate: any;
  exchangeForm: UntypedFormGroup;
  exchRateForList: any = [];
  currFromToList: any = [];
  count: number = 0;
  isEdit: any;


  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,
    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
    private datePipe: DatePipe,
    private activeRoute: ActivatedRoute,
    private session: SessionStorageService,
    private authService: AuthService
  ) {

  }

  ngOnInit() {
    this.createExchangeForm();
    this.appSetupService.retrieveExchangRateType().subscribe(resp => {
      this.exchRateForList = resp;
    });
    this.appSetupService.retrieveExchCurrList().subscribe(result => {
      this.currFromToList = result;
    });

    this.activeRoute.queryParams.subscribe((params: any) => {
      const data = JSON.parse(params.exchangeInfo);
      if (data.Action == 'edit') {
        this.instId = data.erInstId;
        this.fromDate = data.erEffFrmDt;
        this.toDate = data.erEffToDt;
        this.currFrom = data.erCurrFrmCode;
        this.currTo = data.erCurrToCode;
        this.rateFor = data.erRatefor;
        this.sellRate = data.erSelRate;
        this.buyRate = data.erBuyRate;

        if (this.fromDate) {
          this.isDisable = true;
          this.isEdit = true;
          // this.loadExchRate();
          this.patchExchRate();
        }
      } else {
        this.exchangeForm.reset();
        this.isEdit = false;
      }
    });

  }

  createExchangeForm() {
    this.exchangeForm = this.fb.group({
      erInstId: this.authService.getInstanceCode(),
      erRateFor: [, Validators.required],
      erConvFmCurrCode: [, Validators.required],
      erConvToCurrCode: [, Validators.required],
      erEffFrmDt: [, Validators.required],
      erEffToDt: [, Validators.required],
      erBuyRate: [, Validators.required],
      erSelRate: [, Validators.required],
      erCrUid: this.session.get('userId'),
      erCrDt: new Date(),
      exchangeRatePK: ''
    });
  }

  save() {
    if (this.exchangeForm.valid) {
      const formData = this.exchangeForm.value;
      formData.erInstId = this.authService.getInstanceCode();
      let requestData;
      let webServiceRequest;
      if (this.isEdit) {
        requestData = {
          exchangeRatePK: formData,
          erUpdDt: new Date(),
          erUpdUid: this.session.get('userId'),
          erInstId: this.authService.getInstanceCode()
        };

        webServiceRequest = this.appSetupService.updateExchRate(requestData);
      } else {
        requestData = {
          exchangeRatePK: formData,
          erInstId: this.authService.getInstanceCode()
        };
        webServiceRequest = this.appSetupService.insertExchRate(requestData);
      }

      webServiceRequest.subscribe(resp => {
        this.loaderService.isBusy = false;
        //this.route.navigate(['/appSetup/exchangeRate']);
        this.route.navigate(['/appSetup/exchangeRates']);
      }, error => {
        this.loaderService.isBusy = false;
      });

    } else {
      this.validateAllFormFields(this.exchangeForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  loadExchRate() {
    this.loaderService.isBusy = true;
    let obj = {
      'exchFrmDate': this.datePipe.transform(this.fromDate, ApiUrls.DATE_FORMAT),
      'exchToDate': this.datePipe.transform(this.toDate, ApiUrls.DATE_FORMAT),
      'exchCurrFrm': this.currFrom,
      'exchCurrTo': this.currTo,
      'erRateFor': this.rateFor
    }
    this.loaderService.isBusy = true;
    this.appSetupService.retrieveExchRateById(obj).subscribe(resp => {
      this.exchangeForm.patchValue({
        erRateFor: resp.exchangeRatePK.erRateFor,
        erConvFmCurrCode: resp.exchangeRatePK.erConvFmCurrCode,
        erConvToCurrCode: resp.exchangeRatePK.erConvToCurrCode,
        erEffFrmDt: moment(resp.exchangeRatePK.erEffFrmDt).toDate(),
        erEffToDt: moment(resp.exchangeRatePK.erEffToDt).toDate(),
        erBuyRate: resp.erBuyRate,
        erSelRate: resp.erSelRate
      })
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
  back() {
    this.route.navigate(['/appSetup/exchangeRates'], { queryParams: { title: 'home' } });
  }

  patchExchRate() {
    this.exchangeForm.patchValue({
      erRateFor: this.rateFor,
      erConvFmCurrCode: this.currTo,
      erConvToCurrCode: this.currFrom,
      erEffFrmDt: moment(this.fromDate).toDate(),
      erEffToDt: moment(this.toDate).toDate(),
      erBuyRate: this.buyRate,
      erSelRate: this.sellRate
    })
  }
}
