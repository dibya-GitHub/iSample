import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomizablePwdScreenComponent } from './customizable-pwd-screen.component';

describe('CustomizablePwdScreenComponent', () => {
  let component: CustomizablePwdScreenComponent;
  let fixture: ComponentFixture<CustomizablePwdScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomizablePwdScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomizablePwdScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
