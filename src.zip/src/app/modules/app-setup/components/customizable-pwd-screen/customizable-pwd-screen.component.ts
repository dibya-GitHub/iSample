import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
import { AppCodesService } from 'src/app/modules/app-codes/services/app-codes.service';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
declare var $: any;

@Component({
  selector: 'app-customizable-pwd-screen',
  templateUrl: './customizable-pwd-screen.component.html',
  styleUrls: ['./customizable-pwd-screen.component.css'],
})

export class CustomizablePwdScreenComponent implements OnInit {

  custpswdForm: UntypedFormGroup;
  companyGo: boolean = false;
  companyList: any;
  disableOTP: string;
  hideButton: boolean = true;
  editFlag: boolean = true;
  disableCompany: string;
  companyCode: any;
  twoFactList = [{ key: "E", value: "Enabled for ExternalNetwork" }, { key: "D", value: "Disabled" }, { key: "F", value: "Fully Enabled" }];
  twoFactType = [{ key: "OTP", value: "OTP" }, { key: "MD", value: "Memorable Date" }, { key: "WD", value: "Memorable Word" }];

  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private appCodesServices: AppCodesService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private authService: AuthService
  ) {
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.companyCode = this.session.get('companyCode');
    this.disableCompany = null;
    this.createCustomPassForm();
    this.getCompanyList();
    this.custpswdForm.patchValue({
      searchId: this.companyCode,
    });
    var obj = { key: this.companyCode };
    this.fetchDetails(obj);

  }
  createCustomPassForm() {
    this.custpswdForm = this.fb.group({
      searchId: '',
      ppCompCode: ['', Validators.required],
      ppLoginCount: ['', Validators.required],
      ppNoMinChr: ['', Validators.required],
      ppNoMaxChr: ['', Validators.required],
      ppNoUpperCase: ['', Validators.required],
      ppNoLowerCase: ['', Validators.required],
      ppChngDays: ['', Validators.required],
      ppSessionTimeOut: ['', Validators.required],
      ppTwoFactAuth: ['', Validators.required],
      ppTwoFactAuthType: [undefined, Validators.required],
      ppIntIpRange: ['', Validators.required],
      ppNoSplChr: ['', Validators.required],
      ppInstId: this.authService.getInstanceCode()
    });

  }

  getCompanyList() {
    this.appCodesServices.retrieveCompanies(ApiUrls.ORG_CONT_PATH).subscribe(response => {
      this.companyList = response;
      this.loaderService.isBusy = false;
    })
  }

  save() {
    if (this.custpswdForm.valid) {
      this.loaderService.isBusy = true;
      this.appCodesServices.savePasswordDetails(this.custpswdForm.value).subscribe(response => {
        this.loaderService.isBusy = false;
        this.toastService.success("Saved successfully");
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      });
    } else {
      this.validateAllFormFields(this.custpswdForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  fetchDetails(event) {
    this.loaderService.isBusy = true;
    var val = event.key ? event.key : event.value;
    this.appCodesServices.retrievePwdPlcyById(val).subscribe(result => {
      if (result == null || result == undefined) {
        this.loaderService.isBusy = false;
        this.custpswdForm.reset();
        this.custpswdForm.patchValue({
          searchId: val,
          ppCompCode: val,
          ppInstId: this.authService.getInstanceCode()
        });
        this.companyGo = true;

      } else {
        this.loaderService.isBusy = false;
        this.custpswdForm.patchValue({
          ppCompCode: result.mpasswordPolicyPK.ppCompCode,
          ppLoginCount: result.ppLoginCount,
          ppNoMinChr: result.ppNoMinChr,
          ppNoMaxChr: result.ppNoMaxChr,
          ppNoUpperCase: result.ppNoUpperCase,
          ppNoLowerCase: result.ppNoLowerCase,
          ppSecurityImg: result.ppSecurityImg,
          ppOtpMedium: result.ppOtpMedium,
          ppChngDays: result.ppChngDays,
          ppSessionTimeOut: result.ppSessionTimeOut,
          ppTwoFactAuth: result.ppTwoFactAuth,
          ppTwoFactAuthType: result.ppTwoFactAuthType,
          ppIntIpRange: result.ppIntIpRange,
          ppNoSplChr: result.ppNoSplChr
        })
        this.companyGo = true;
        this.hideButton = false;
        this.disableCompany = "true";
        if (result.ppTwoFactAuth == 'D') {
          this.disableOTP = "disabled";
        }
      }
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.info('Details not found');
      this.companyGo = false;
    });
  }

  back() {
    this.route.navigate(['/master/admindashboard'], { queryParams: { title: 'home' } });
  }

  disableOtp(value) {
    if ('D' == value) {
      this.disableOTP = "disabled";
      this.custpswdForm.patchValue({
        ppTwoFactAuthType: ''
      })
    } else {
      this.disableOTP = null;
    }
  }
}
