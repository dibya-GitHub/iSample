import { Component } from '@angular/core';
import { Router } from '@angular/router';
<<<<<<< HEAD
=======
import { GlobalService } from 'src/app/shared/services/global.service';
import { ToastrService } from 'ngx-toastr';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { GlobalService } from 'src/app/shared/services/global.service';

<<<<<<< HEAD
// declare function calltreefunction(): any;
=======
//declare function calltreefunction(): any;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@Component({
  selector: 'app-org-structure',
  templateUrl: './org-structure.component.html',
  styleUrls: ['./org-structure.component.scss']
})

export class OrgStructureComponent {

  orgstructure: any;
  displayDialog: boolean;
  title: any;
  path: any;

  constructor(
    private router: Router,
    private globalService: GlobalService,
    private loaderService: LoaderService,
<<<<<<< HEAD
    private toastService: ToastService
=======
    private toastrService: ToastrService,
    private session:SessionStorageService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.path = this.globalService.getParamValue('path');
    this.title = this.globalService.getParamValue('tittle');
    this.globalService.retrieveOrgChart().subscribe(resp => {
      this.orgstructure = resp.compList;
      this.loaderService.isBusy = false;
<<<<<<< HEAD
      // calltreefunction();
=======
      //calltreefunction();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }
  loadDetails(title, path, compCode, divnCode, costCode, deptCode, teamCode) {
    this.title = title;
    this.path = path;
    if ("Company" == title) {
      this.router.navigate(['/appSetup/company'], { queryParams: { "flag": true, "title": title, "path": path, "type": 'orchart', "action": 'add' } });
    } else if ("Division" == title) {
      this.router.navigate(['/appSetup/division'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "action": 'add' } });
    } else if ("Cost Centre" == title) {
      this.router.navigate(['/appSetup/cost'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "costCode": costCode, "action": 'add' } });
    } else if ("Department" == title) {
      this.router.navigate(['/appSetup/depart'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "costCode": costCode, "deptCode": deptCode, "action": 'add' } });
    } else if ("Team" == title) {
      this.router.navigate(['/appSetup/team'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "costCode": costCode, "deptCode": deptCode, "teamCode": teamCode, "action": 'add' } });
    }
  }

  editMaster(title, path, compCode, divnCode, costCode, deptCode, teamCode) {
    if ("Company" == title) {
      this.router.navigate(['/appSetup/company'], { queryParams: { "title": title, "path": path, "compCode": compCode, "action": 'edit' } });
    } else if ("Division" == title) {
      this.router.navigate(['/appSetup/division'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "action": 'edit' } });
    } else if ("Cost Centre" == title) {
      this.router.navigate(['/appSetup/cost'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "costCode": costCode, "action": 'edit' } });
    } else if ("Department" == title) {
      this.router.navigate(['/appSetup/depart'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "costCode": costCode, "deptCode": deptCode, "action": 'edit' } });
    } else if ("Team" == title) {
      this.router.navigate(['/appSetup/team'], { queryParams: { "title": title, "path": path, "compCode": compCode, "divnCode": divnCode, "costCode": costCode, "deptCode": deptCode, "teamCode": teamCode, "action": 'edit' } });
    }
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'Home' } });
  }
}
