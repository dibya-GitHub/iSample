<<<<<<< HEAD
import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
=======
import { Component, OnInit, Inject } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl, UntypedFormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AppSetupService } from '../../services/app-setup.service';
import { ToastService } from 'src/app/services/toast.service';
//import { ToastrService } from 'ngx-toastr';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppSetupService } from '../../services/app-setup.service';

@Component({
  selector: 'app-m-app-param',
  templateUrl: './m-app-param.component.html',
  styleUrls: ['./m-app-param.component.css'],
})
export class MAppParamComponent implements OnInit {

  appParamsForm: UntypedFormGroup;
  paraCode: string;
  paraSubCode: string;
  isEdit: boolean;
  appParamsCodes: any;
  action;

  constructor(
    private fb: UntypedFormBuilder,
    private appSetupService: AppSetupService,
    private route: Router,
<<<<<<< HEAD
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
=======
    private toastrService: ToastService,
    private loaderService: LoaderService,
    private session:SessionStorageService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
<<<<<<< HEAD
    this.activatedRoute.queryParams.subscribe((params: any) => {
=======
    this.activatedRoute.queryParams.subscribe((params:any) => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      // this.path = this.globalService.getParamValue('path');
      this.paraCode = params.paraCode;
      this.paraSubCode = params.paraSubCode;
      // this.action = this.globalService.getParamValue('action');
      if (this.paraCode && this.paraSubCode) {
        this.isEdit = true;
        this.loadAppParameters();
      }
    });
    this.getAppParams();
    this.createAppParamsForm();
  }

  createAppParamsForm() {
    this.appParamsForm = this.fb.group({
      mappParameterPK: '',
      paraCode: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9%_\-+ ]+$/)])],
      paraSubCode: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9%_\-+ ]+$/)])],
      paraName: ['', Validators.required],
      paraNameBl: ['', Validators.pattern(/^[a-zA-Z0-9%_\-+ ]*$/)],
      paraValue: ['', Validators.pattern(/^[a-zA-Z0-9%_\-+ ]*$/)],
      paraRemark: '',
      paraRemarkBl: '',
      paraCrUid: this.session.get('userId'),
      paraCrDt: new Date()
    });
    this.loaderService.isBusy = false;
  }

  loadAppParameters() {
    this.loaderService.isBusy = true;
    let obj = { 'paraCode': this.paraCode, 'paraSubCode': this.paraSubCode }
    this.appSetupService.retrieveAppParamsById(obj).subscribe(result => {

      let response = result.appParamsArray;
      this.appParamsForm.patchValue({
        mappParameterPK: response.mappParameterPK,
        paraCode: response.mappParameterPK.paraCode,
        paraSubCode: response.mappParameterPK.paraSubCode,
        paraName: response.paraName,
        paraNameBl: response.paraNameBl,
        paraValue: response.paraValue,
        paraRemark: response.paraRemark,
        paraRemarkBl: response.paraRemarkBl
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
  getAppParams() {
    this.appSetupService.retrieveAppParamsDetails().subscribe(resp => {
      this.appParamsCodes = resp.appParamsArray;
      var valArray = [];
      this.appParamsCodes.forEach(element => {
        let val = element.mappParameterPK.paraCode;
        valArray.push(val);
      });
      valArray = Array.from(new Set(valArray));
      this.appParamsCodes = valArray;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }
  save() {
    if (this.appParamsForm.valid) {
      this.loaderService.isBusy = true;
      let paramspk = {
        'paraCode': this.appParamsForm.get('paraCode').value,
        'paraSubCode': this.appParamsForm.get('paraSubCode').value
      }
      let params = {
        'mappParameterPK': paramspk,
        'paraName': this.appParamsForm.get('paraName').value,
        'paraNameBl': this.appParamsForm.get('paraNameBl').value,
        'paraValue': this.appParamsForm.get('paraValue').value,
        'paraRemark': this.appParamsForm.get('paraRemark').value,
        'paraRemarkBl': this.appParamsForm.get('paraRemarkBl').value,
        'paraCrUid': this.session.get('userId'),
        'paraCrDt': this.appParamsForm.get('paraCrDt').value

      }
      if (this.isEdit) {
        this.appSetupService.updateAppParamsDetails(params, paramspk).subscribe(result => {
          this.loaderService.isBusy = false;
          this.toastrService.success("Updated Successfully");
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
        });
      } else {
        this.appSetupService.insertAppParamsDetails(params).subscribe(result => {
          this.loaderService.isBusy = false;
          this.toastrService.success("Saved Successfully");
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
        });
      }
    } else {
      this.validateAllFormFields(this.appParamsForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  back() {
    this.route.navigate(['/appSetup/appParams']);
  }
}
