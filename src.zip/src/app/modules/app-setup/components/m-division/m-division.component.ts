import { ToastService } from './../../../../services/toast.service';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/app/services/loader.service';
import { AppSetupService } from '../../services/app-setup.service';
declare var $: any;

@Component({
  selector: 'app-m-division',
  templateUrl: './m-division.component.html',
  styleUrls: ['./m-division.component.css'],
})
export class MDivisionComponent implements OnInit {

  tittle: any;
  divnCompCode: any;
  path: any;
  divnCode: any;
  divisionForm: UntypedFormGroup;
  divInfo: any = [];
  currencyList: any;
  editFlag: boolean;
  action: any;
  companyInfo: any;
  compList: any = [];
  displayDialog: boolean;
  isDisabled: boolean;
  roundOffList: any = [
    { key: "0", value: "0" },
    { key: "1", value: "1" },
    { key: "2", value: "2" },
    { key: "3", value: "3" }
  ];

  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,

    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
    private session: SessionStorageService
  ) { }

  ngOnInit() {

    this.divnCompCode = this.appSetupService.getParamValue('compCode');
    this.divnCode = this.appSetupService.getParamValue('divnCode');
    this.tittle = this.appSetupService.getParamValue('tittle');
    this.path = this.appSetupService.getParamValue('path');
    this.action = this.appSetupService.getParamValue('action');
    this.createDivisonForm();
    if ('edit' == this.action) {
      this.isDisabled = true;
      this.loadDivInfo();
    }
    // this.divisionForm.get('divnRoundOff').setValue(0);
    this.appSetupService.retrieveCurrency().subscribe(result => {
      this.currencyList = result;
    })
    this.appSetupService.retrieveCompanies().subscribe(result => {
      this.compList = result;
      this.divisionForm.patchValue({
        divnCompCode: this.divnCompCode
      });
    });
  }

  createDivisonForm() {
    this.divisionForm = this.fb.group({
      mdivisionPK: '',
      divnInstId: '',
      divnCompCode: ['', Validators.required],
      divnCode: ['', Validators.required],
      divnName: ['', Validators.required],
      divnShortName: '',
      divnBlName: '',
      divnBlShortName: '',
      divnFrzFlag: '0',
      divnBaseCurrCode1: [undefined, Validators.required],
      divnBaseCurrCode2: [undefined, Validators.required],
      divnBaseCurrCode3: [undefined, Validators.required],
      divnRoundOff: [undefined, Validators.required],
      divnUnitName: ['', Validators.required],
      divnAdd1: ['', Validators.required],
      divnAdd2: '',
      divnAdd3: '',
      divnPoBoxNo: ['', Validators.required],
      divnTelNo: '',
      divnFaxNo: '',
      divnEmailId: '',
      divnBlAdd1: '',
      divnBlAdd2: '',
      divnBlAdd3: '',
      divnCrUid: this.session.get('userId'),
      divnCrDt: new Date()

    })
  }
  save(type: string) {
    if (this.divisionForm.valid) {
      let params = {
        'divnCompCode': this.divisionForm.get('divnCompCode').value,
        'divnCode': this.divisionForm.get('divnCode').value
      }
      this.divisionForm.patchValue({
        'mdivisionPK': params
      })

      if (this.action == 'edit') {
        this.loaderService.isBusy = true;
        this.appSetupService.updateDivisionDetails(this.divisionForm.getRawValue(), params).subscribe(result => {
          this.loaderService.isBusy = false;
          this.back();

        }, error => {
          this.loaderService.isBusy = false;

        });
      } else {

        this.loaderService.isBusy = true;
        this.appSetupService.saveDivisionDetails(this.divisionForm.value).subscribe(result => {
          this.loaderService.isBusy = false;
          if ('save' == type) {
            this.back();
          } else if ('saveAdd' == type) {
            this.displayDialog = false;
            this.route.navigate(['/appSetup/cost'], { queryParams: { 'path': 'cost-center-mgmt', 'tittle': 'Cost Centre', 'action': 'add', 'flag': 'true', 'compCode': this.divnCompCode, 'divnCode': this.divisionForm.get('divnCode').value }, skipLocationChange: true });
          }
        }, error => {

        });
      }
    } else {
      this.validateAllFormFields(this.divisionForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  back() {
    this.route.navigate(['/appSetup/orgstructure'], { queryParams: { "flag": true, "title": "Org Setup", "path": "" } });
  }
  loadDivInfo() {
    this.loaderService.isBusy = true;
    this.editFlag = true;
    let mdivisionPK = {
      'divnCompCode': this.divnCompCode,
      'divnCode': this.divnCode
    }
    this.appSetupService.retrieveDivisionByPk(mdivisionPK).subscribe(result => {
      this.divisionForm.patchValue({
        divnCompCode: result.mdivisionPK.divnCompCode,
        divnCode: result.mdivisionPK.divnCode,
        divnName: result.divnName,
        divnShortName: result.divnShortName,
        divnBlName: result.divnBlName,
        divnBlShortName: result.divnBlShortName,
        divnFrzFlag: result.divnFrzFlag,
        divnPoBoxNo: result.divnPoBoxNo,
        divnAdd1: result.divnAdd1,
        divnAdd2: result.divnAdd2,
        divnAdd3: result.divnAdd3,
        divnBaseCurrCode1: result.divnBaseCurrCode1,
        divnBaseCurrCode2: result.divnBaseCurrCode2,
        divnBaseCurrCode3: result.divnBaseCurrCode3,
        divnEmailId: result.divnEmailId,
        divnRoundOff: result.divnRoundOff,
        divnUnitName: result.divnUnitName,
        divnCrUid: result.divnCrUid,
        divnCrDt: result.divnCrDt,
        divnUpdUid: this.session.get('userId'),
        divnUpdDt: new Date()

      })
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
}
