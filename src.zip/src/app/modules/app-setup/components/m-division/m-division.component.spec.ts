import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MDivisionComponent } from './m-division.component';

describe('MDivisionComponent', () => {
  let component: MDivisionComponent;
  let fixture: ComponentFixture<MDivisionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MDivisionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MDivisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
