<<<<<<< HEAD
import { ToastService } from './../../../../services/toast.service';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AuthService } from 'src/app/services/auth.service';
=======
import { Component, OnInit, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UntypedFormControl } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { AppSetupService } from './../../services/app-setup.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { AppSetupService } from './../../services/app-setup.service';
declare var $: any;

@Component({
  selector: 'app-m-department',
  templateUrl: './m-department.component.html',
  styleUrls: ['./m-department.component.css'],
})
export class MDepartmentComponent implements OnInit {

  tittle: any;
  displayDialog: boolean;
  deptCostCode: any;
  deptDivnCode: any;
  deptCompCode: any;
  deptCode: any;
  departInfo: any;
  pk: any;
  path: any;
  departFrm: UntypedFormGroup;
  editFlag: boolean;
  isDisabled: boolean;
  action: any;
  compList: any = [];
  divnList: any = [];
  costCntrList: any = [];

  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,
    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
<<<<<<< HEAD
    private session: SessionStorageService,
    private authService: AuthService
  ) { }
=======
    private session:SessionStorageService,) { }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  ngOnInit() {

    this.deptCode = this.appSetupService.getParamValue('deptCode');
    this.deptCompCode = this.appSetupService.getParamValue('compCode');
    this.deptDivnCode = this.appSetupService.getParamValue('divnCode');
    this.deptCostCode = this.appSetupService.getParamValue('costCode');
    this.tittle = this.appSetupService.getParamValue('tittle');
    this.path = this.appSetupService.getParamValue('path');
    this.action = this.appSetupService.getParamValue('action');
    this.createDeptForm();

    if ('edit' == this.action) {
      this.departFrm.get('deptCompCode').disable();
      this.departFrm.get('deptDivnCode').disable();
      this.departFrm.get('deptCostCode').disable();
      this.isDisabled = true;
      this.loadDepartnfo();
    }
    this.appSetupService.retrieveCompanyList().subscribe(result => {
      this.compList = result;
    });
    this.appSetupService.retrieveDivisionList().subscribe(result => {
      this.divnList = result;
    });
    this.appSetupService.retrieveCostCenterList().subscribe(result => {
      this.costCntrList = result;
      this.departFrm.patchValue({
        deptCompCode: this.deptCompCode,
        deptDivnCode: this.deptDivnCode,
        deptCostCode: this.deptCostCode
      });
    });
  }
  createDeptForm() {
    this.departFrm = this.fb.group({
      mdepartmentPK: '',
      deptInstId: this.authService.getInstanceCode(),
      deptCompCode: ['', Validators.required],
      deptDivnCode: ['', Validators.required],
      deptCode: ['', Validators.required],
      deptCostCode: ['', Validators.required],
      deptName: ['', Validators.required],
      deptShortName: '',
      deptBlName: '',
      deptBlShortName: '',
      deptFrzFlag: ['0', Validators.required],
      deptCrUid: this.session.get('userId'),
      deptCrDt: new Date()
    })
  }
  save(type: string) {
    this.departFrm.get('deptCompCode').enable();
    this.departFrm.get('deptDivnCode').enable();
    this.departFrm.get('deptCostCode').enable();
    this.departFrm.get('deptCode').enable();
    if (this.departFrm.valid) {
      let params = {
        'deptCode': this.departFrm.get('deptCode').value,
        'deptCompCode': this.departFrm.get('deptCompCode').value,
        'deptDivnCode': this.departFrm.get('deptDivnCode').value,
        'deptCostCode': this.departFrm.get('deptCostCode').value
      }
      this.departFrm.patchValue({
        mdepartmentPK: params
      });
      if (this.action == 'edit') {
        this.loaderService.isBusy = true;
        this.appSetupService.updateDeptById(this.departFrm.getRawValue()).subscribe(result => {
          this.loaderService.isBusy = false;
          if ('save' == type) {
            this.back();
          } else if ('saveAdd' == type) {
            this.route.navigate(['/appSetup/team'], { queryParams: { 'path': 'team-mgmt', 'tittle': 'team', 'action': 'add', 'flag': 'true', 'compCode': this.deptCompCode, 'divnCode': this.deptDivnCode, 'costCode': this.deptCostCode, 'deptCode': this.departFrm.get('deptCode').value }, skipLocationChange: true });
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.back();
        });
      } else {
        this.loaderService.isBusy = true;
        this.appSetupService.saveDeptDetails(this.departFrm.value).subscribe(result => {
          this.loaderService.isBusy = false;
          if ('save' == type) {
            this.back();
          } else if ('saveAdd' == type) {
            this.route.navigate(['/appSetup/team'], { queryParams: { 'path': 'team-mgmt', 'tittle': 'team', 'action': 'add', 'flag': 'true', 'compCode': this.deptCompCode, 'costCode': this.deptCostCode, 'divnCode': this.deptDivnCode, 'deptCode': this.departFrm.get('deptCode').value }, skipLocationChange: true });
          }
        }, error => {
          this.loaderService.isBusy = false;
        });
      }

    } else {
      this.validateAllFormFields(this.departFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
<<<<<<< HEAD
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
=======
    Object.keys(formGroup.controls).forEach(field => {
      // console.log(field);
      const control = formGroup.get(field);
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  back() {
    this.route.navigate(['/appSetup/orgstructure'], { queryParams: { "flag": true, "title": "Org Setup", "path": "" } });
  }
  loadDepartnfo() {
    this.loaderService.isBusy = true;
    this.editFlag = true;
    let obj = {
      'deptInstId': this.authService.getInstanceCode(),
      'deptCode': this.deptCode,
      'deptCompCode': this.deptCompCode,
      'deptDivnCode': this.deptDivnCode,
      'deptCostCode': this.deptCostCode
    }
    this.appSetupService.retrieveDeptById(obj).subscribe(result => {
      this.departInfo = result;
      this.departFrm.patchValue({
        deptCompCode: result.mdepartmentPK.deptCompCode,
        deptDivnCode: result.mdepartmentPK.deptDivnCode,
        deptCode: result.mdepartmentPK.deptCode,
        deptCostCode: result.mdepartmentPK.deptCostCode,
        deptName: result.deptName,
        deptShortName: result.deptShortName,
        deptBlName: result.deptBlName,
        deptBlShortName: result.deptBlShortName,
        deptFrzFlag: result.deptFrzFlag,
      })
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
}
