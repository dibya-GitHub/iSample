import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppSetupService } from '../../services/app-setup.service';
declare var $: any;

@Component({
  selector: 'app-cost-center',
  templateUrl: './cost-center.component.html',
  styleUrls: ['./cost-center.component.css']
})

export class CostCenterComponent implements OnInit {

  freezeFlag: boolean;
  togglebtn: string;
  tittle: any;
  displayDialog: boolean;
  costInfo: any;
  costDivCode: any;
  costCompCode: any;
  path: any;
  costCode: any;
  costCenterFrm: UntypedFormGroup;
  editFlag: boolean;
  isDisabled: boolean;
  action: any;
  compList: any = []
  divnList: any = []
  disableCompDiv: string;

  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,
    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
    private session: SessionStorageService
  ) { }

  ngOnInit() {
    this.costCode = this.appSetupService.getParamValue('costCode');
    this.costCompCode = this.appSetupService.getParamValue('compCode');
    this.costDivCode = this.appSetupService.getParamValue('divnCode');
    this.tittle = this.appSetupService.getParamValue('tittle');
    this.path = this.appSetupService.getParamValue('path');
    this.action = this.appSetupService.getParamValue('action');
    this.createCostCenterForm();
    if ('edit' == this.action) {
      this.costCenterFrm.get('costCompCode').disable();
      this.costCenterFrm.get('costDivCode').disable();
      this.costCenterFrm.get('costCode').disable();
      this.disableCompDiv = "true";
      this.isDisabled = true;
      this.loadCostCenter();
    } else {
      this.disableCompDiv = "false";
    }
    this.appSetupService.retrieveCompanies().subscribe(result => {
      this.compList = result;
    });
    this.appSetupService.retrieveDivisions().subscribe(result => {
      this.divnList = result;
      this.costCenterFrm.patchValue({
        costCompCode: this.costCompCode,
        costDivCode: this.costDivCode
      });
    });
  }
  createCostCenterForm() {
    this.costCenterFrm = this.fb.group({
      mcostCentrePK: '',
      costInstId: '',
      costCompCode: ['', Validators.required],
      costDivCode: ['', Validators.required],
      costCode: ['', Validators.required],
      costName: ['', Validators.required],
      costShortName: '',
      costBlName: '',
      costBlShortName: '',
      costFreezFlag: '',
      costCrUid: this.session.get('userId'),
      costCrDt: new Date(),
      costUpdUid: '',
      costUpdDt: ''

    })
  }
  save(type: string) {
    this.costCenterFrm.get('costCompCode').enable();
    this.costCenterFrm.get('costDivCode').enable();
    this.costCenterFrm.get('costCode').enable();
    if (this.costCenterFrm.valid) {
      let params = {
        'costCompCode': this.costCenterFrm.get('costCompCode').value,
        'costDivCode': this.costCenterFrm.get('costDivCode').value,
        'costCode': this.costCenterFrm.get('costCode').value,
      }
      this.costCenterFrm.patchValue({
        mcostCentrePK: params
      });

      if (this.action == 'edit') {
        this.loaderService.isBusy = true;
        let formData = this.costCenterFrm.getRawValue();
        formData.costFreezFlag = (formData.costFreezFlag) ? 'Y' : 'N';
        this.appSetupService.updateCostCentreDetails(formData).subscribe(result => {
          this.loaderService.isBusy = false;
          this.toastService.success("Updated Successfully.");
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error while Updating');
        });
      } else {
        this.loaderService.isBusy = true;
        this.appSetupService.saveCostCentreDetails(this.costCenterFrm.value).subscribe(result => {
          this.loaderService.isBusy = false;
          if ('save' == type) {
            this.back();
          } else if ('saveAdd' == type) {
            this.route.navigate(['/appSetup/depart'], { queryParams: { 'path': 'department-mgmt', 'tittle': 'Department', 'action': 'add', 'flag': 'true', 'compCode': this.costCompCode, 'divnCode': this.costDivCode, 'costCode': this.costCenterFrm.get('costCode').value }, skipLocationChange: true });
          }
          this.toastService.success("Saved Successfully.");
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error while Saving');
        });
      }
    } else {
      this.validateAllFormFields(this.costCenterFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  back() {
    this.route.navigate(['/appSetup/orgstructure'], { queryParams: { "flag": true, "title": "Org Setup", "path": "" } });
  }

  loadCostCenter() {
    this.loaderService.isBusy = true;
    this.editFlag = true;
    let mcostCentrePK = {
      'costCode': this.costCode,
      'costCompCode': this.costCompCode,
      'costDivCode': this.costDivCode
    }
    this.appSetupService.retrieveCostCentreByPk(mcostCentrePK).subscribe(result => {

      result.costFreezFlag = (result.costFreezFlag === 'Y');
      this.costCenterFrm.patchValue({
        costCompCode: result.mcostCentrePK.costCompCode,
        costDivCode: result.mcostCentrePK.costDivCode,
        costCode: result.mcostCentrePK.costCode,
        costName: result.costName,
        costShortName: result.costShortName,
        costBlName: result.costBlName,
        costBlShortName: result.costBlShortName,
        costFreezFlag: result.costFreezFlag,
        costCrUid: result.costCrUid,
        costCrDt: result.costCrDt,
        costUpdUid: this.session.get('userId'),
        costUpdDt: new Date()
      })
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
}
