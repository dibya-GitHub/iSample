import { ToastService } from './../../../../services/toast.service';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { AppSetupService } from '../../services/app-setup.service';

@Component({
  selector: 'app-m-team',
  templateUrl: './m-team.component.html',
  styleUrls: ['./m-team.component.css'],
})
export class MTeamComponent implements OnInit {
  teamInfo = [];
  path: any;
  teamCode: any;
  teamDeptCode: any
  teamFrm: UntypedFormGroup;
  action: any;
  editFlag: boolean;
  disableCompDivCost: string;
  teamCompCode: any
  teamDivnCode: any
  teamCostCode: any
  tittle: any
  compList: any;
  divnList: any;
  costCntrList: any;
  deptList: any;


  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,
    private appSetupService: AppSetupService,
    private session: SessionStorageService,
    private loaderService: LoaderService,
    private authService: AuthService,
  ) { }

  ngOnInit() {

    this.teamDeptCode = this.appSetupService.getParamValue('deptCode');
    this.teamCompCode = this.appSetupService.getParamValue('compCode');
    this.teamDivnCode = this.appSetupService.getParamValue('divnCode');
    this.teamCostCode = this.appSetupService.getParamValue('costCode');
    this.teamCode = this.appSetupService.getParamValue('teamCode');
    this.tittle = this.appSetupService.getParamValue('tittle');
    this.path = this.appSetupService.getParamValue('path');
    this.action = this.appSetupService.getParamValue('action');

    this.disableCompDivCost = "true";
    // this.teamCode=this.globalService.getParamValue('code');
    // this.path=this.globalService.getParamValue('path');
    this.createTeamForm();
    // this.action = this.globalService.getParamValue('action');
    if ('edit' == this.action) {
      this.disableCompDivCost = "true";
      this.loadTeamInfo();
      this.teamFrm.get('teamCompCode').disable();
      this.teamFrm.get('teamDivnCode').disable();
      this.teamFrm.get('teamDeptCode').disable();
      this.teamFrm.get('teamCostCode').disable();
    }
    this.appSetupService.retrieveCompanyList().subscribe(result => {
      this.compList = result;
    });
    this.appSetupService.retrieveDivisionList().subscribe(result => {
      this.divnList = result;
    });
    this.appSetupService.retrieveDeptList(this.teamCompCode).subscribe(res => {
      this.deptList = res;
    }, err => { });
    this.appSetupService.retrieveCostCenterList().subscribe(result => {
      this.costCntrList = result;
      this.teamFrm.patchValue({
        teamCompCode: this.teamCompCode,
        teamDivnCode: this.teamDivnCode,
        teamDeptCode: this.teamDeptCode,
        teamCostCode: this.teamCostCode
      });
    });
  }

  createTeamForm() {
    this.teamFrm = this.fb.group({
      mteamPK: '',
      teamInstId: this.authService.getInstanceCode(),
      teamCode: ['', Validators.required],

      teamCompCode: [this.teamCompCode, Validators.required],
      teamDeptCode: [this.teamDeptCode, Validators.required],
      teamDivnCode: [this.teamDivnCode, Validators.required],
      teamCostCode: this.teamCostCode,
      teamBlName: '',
      teamName: ['', Validators.required],
      teamFrzFlag: ['0', Validators.required],
      teamCrUid: this.session.get('userId'),
      teamCrDt: new Date()
    })
  }
  back() {
    // this.loaderService.display(true);
    this.route.navigate(['/appSetup/orgstructure'], { queryParams: { "flag": true, "title": "Org Setup", "path": "" } });
  }
  save() {
    this.loaderService.isBusy = true;
    if (this.teamFrm.valid) {
      let param = {
        'teamCode': this.teamFrm.get('teamCode').value,
        'teamDeptCode': this.teamFrm.get('teamDeptCode').value,
        'teamCompCode': this.teamFrm.get('teamCompCode').value,
        'teamDivnCode': this.teamFrm.get('teamDivnCode').value,
        'teamCostCode': this.teamFrm.get('teamCostCode').value
      };
      this.teamFrm.patchValue({
        mteamPK: param
      });
      let data = {
        'teamName': this.teamFrm.get('teamName').value,
        // 'teamShrtName':this.teamFrm.get('teamShrtName').value,
        'teamBlName': this.teamFrm.get('teamBlName').value,
        'teamDeptCode': this.teamFrm.get('teamDeptCode').value,
        'teamFrzFlag': this.teamFrm.get('teamFrzFlag').value,
        'teamCrUid': this.session.get('userId'),
        'teamCrDt': new Date()
      }
      if (this.action == 'edit') {
        this.appSetupService.updateteamInfo(this.teamFrm.getRawValue()).subscribe(result => {
          this.back();
        }, error => {
        });
      } else {
        this.appSetupService.saveTeamInfo(this.teamFrm.value).subscribe(result => {
          this.back();
        }, error => {
        });
      }
    } else {
      this.validateAllFormFields(this.teamFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  loadTeamInfo() {
    this.loaderService.isBusy = true;
    this.editFlag = true;

    let mteamPK = {
      teamCompCode: this.teamCompCode,
      teamDivnCode: this.teamDivnCode,
      teamCostCode: this.teamCostCode,
      teamDeptCode: this.teamDeptCode,
      teamCode: this.teamCode
    }
    //let obj={key:"searchId" ,value:this.teamCode}
    this.appSetupService.selectTeamById(mteamPK).subscribe(result => {
      this.teamFrm.patchValue({
        teamCode: result.mteamPK.teamCode,
        teamCompCode: result.mteamPK.teamCompCode,
        teamDeptCode: result.mteamPK.teamDeptCode,
        teamDivnCode: result.mteamPK.teamDivnCode,
        teamCostCode: result.mteamPK.teamCostCode,
        teamBlName: result.teamBlName,
        teamName: result.teamName,
        teamFrzFlag: result.teamFrzFlag,
        teamCrUid: result.teamCrUid,
        teamCrDt: result.teamCrDt
      })
      this.loaderService.isBusy = false;
    }, error => {
    });
  }






}
