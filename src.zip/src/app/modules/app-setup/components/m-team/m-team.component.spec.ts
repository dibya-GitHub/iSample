import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MTeamComponent } from './m-team.component';

describe('MTeamComponent', () => {
  let component: MTeamComponent;
  let fixture: ComponentFixture<MTeamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MTeamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MTeamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
