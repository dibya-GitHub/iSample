<<<<<<< HEAD
import { ToastService } from './../../../../services/toast.service';
import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { AppSetupService } from '../../services/app-setup.service';
=======
import { Component, OnInit, Inject } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { Input } from '@angular/core';
import { AppSetupService } from '../../services/app-setup.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
declare function uploadfunction(): any;
declare var $: any;

@Component({
  selector: 'app-company-master',
  templateUrl: './company-master.component.html',
  styleUrls: ['./company-master.component.css'],
})
export class CompanyMasterComponent implements OnInit {
  tittle: any;
  sigImgUrl: any;
  url: any = '';
  variable: any;
  cities: any;
  compLogos: any = [];
  divArry: any = [];
  selectedCar2: string = 'BMW';
  divnList: any = []
  currencyList: any;
  editFlag: boolean = false;
  compMasterFrm: UntypedFormGroup
  compInfo: any = [];
  companyCode: string;
  companyInfo: any;
  action: any;
  buttonLabel: string = 'save & Proceed';
  displayDialog: boolean;
  isDisable: boolean;
  title: string;
  @Input() path: string;

<<<<<<< HEAD
  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,
    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private authService: AuthService
  ) { }
=======
  constructor(private fb: UntypedFormBuilder,
    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
    private route: Router,
    private session:SessionStorageService,
    private ToastService: ToastService,) { }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.companyCode = this.appSetupService.getParamValue('compCode');
    this.path = this.appSetupService.getParamValue('path');
    this.action = this.appSetupService.getParamValue('action');
    this.createcompMasterForm();
    if ('edit' == this.action) {
      this.isDisable = true;
      this.loadCompanyInfo();
    } else if ('flow' == this.action) {
      //this.loadCompanyInfo();
    }
    this.appSetupService.retrieveDivisions().subscribe(result => {
      this.divnList = result;
      this.loaderService.isBusy = false;
    });
    this.appSetupService.retrieveCurrency().subscribe(result => {
      this.currencyList = result;
      this.loaderService.isBusy = false;
    })
  }

  createcompMasterForm() {
    this.compMasterFrm = this.fb.group({
      compCode: ['', Validators.required],
      compInstId: this.authService.getInstanceCode(),
      compName: ['', Validators.required],
      compShortName: '',
      compLogo: '',
      compAdd1: ['', Validators.required],
      compAdd2: '',
      compAdd3: '',
      compDfltDivnCode: '',
      compBlName: '',
      compBlShortName: '',
      compBlAdd1: '',
      compBlAdd2: '',
      compBlAdd3: '',
      compBaseCurrCode1: '',
      compBaseCurrCode2: '',
      compBaseCurrCode3: '',
      compRoundOff: '',
      compUnitName: '',
      compEmailId: ['', [Validators.required, Validators.email]],
      compTelNo: '',
      compFaxNo: '',
      compCrUid: this.session.get('userId'),
      compCrDt: new Date(),
      compUpdDt: '',
      compUpdUid: '',
      compTheme: '#3FA8BA',
      compFrzFlag: ['0', Validators.required],
      compWebsite: '',
      compContactCenterNo: '',
      compPostBoxNo: ['', Validators.required]
    })
  }

  save(type: string) {
    if (this.compMasterFrm.valid) {
      let params = {
        "compCode": this.compMasterFrm.get('compCode').value,
        "compInstId": this.authService.getInstanceCode()
      }
      let data = {
        "mcompanyPK": params,
        "compName": this.compMasterFrm.get('compName').value,
        "compShortName": this.compMasterFrm.get('compShortName').value,
        "compLogo": this.compMasterFrm.get('compLogo').value,
        "compAdd1": this.compMasterFrm.get('compAdd1').value,
        "compAdd": this.compMasterFrm.get('compAdd2').value,
        "compAdd3": this.compMasterFrm.get('compAdd3').value,
        "compBlName": this.compMasterFrm.get('compBlName').value,
        "compBlShortName": this.compMasterFrm.get('compBlShortName').value,
        "compBlAdd1": this.compMasterFrm.get('compBlAdd1').value,
        "compBlAdd2": this.compMasterFrm.get('compBlAdd2').value,
        "compBlAdd3": this.compMasterFrm.get('compBlAdd3').value,
        "compFrzFlag": this.compMasterFrm.get('compFrzFlag').value,
        "compBaseCurrCode1": this.compMasterFrm.get('compBaseCurrCode1').value,
        "compBaseCurrCode2": this.compMasterFrm.get('compBaseCurrCode2').value,
        "compBaseCurrCode3": this.compMasterFrm.get('compBaseCurrCode3').value,
        "compRoundOff": this.compMasterFrm.get('compRoundOff').value,
        "compUnitName": this.compMasterFrm.get('compUnitName').value,
        "compEmailId": this.compMasterFrm.get('compEmailId').value,
        "compTelNo": this.compMasterFrm.get('compTelNo').value,
        "compFaxNo": this.compMasterFrm.get('compFaxNo').value,
        "compWebsite": this.compMasterFrm.get('compWebsite').value,
        "compContactCenterNo": this.compMasterFrm.get('compContactCenterNo').value,
        "compPostBoxNo": this.compMasterFrm.get('compPostBoxNo').value,
        "compDfltDivnCode": this.compMasterFrm['controls']['compDfltDivnCode'].value,
        "compTheme": this.compMasterFrm['controls']['compTheme'].value,
        "compCrUid": this.session.get('userId'),
        "compCrDt": new Date(),
      }

      if (this.action == 'edit') {
        this.loaderService.isBusy = true;
        this.appSetupService.updateCompanyDetails(data, params).subscribe(result => {          
          this.CompanyTheme();
          this.ToastService.success('Updated Successfully');
          this.loaderService.isBusy = false;
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
        });
      }
      else {
        this.loaderService.isBusy = true;
        this.appSetupService.saveCompanyDetails(data).subscribe(result => {
          this.loaderService.isBusy = false;
          if ('save' == type) {
            this.CompanyTheme();
            this.ToastService.success('Saved Successfully');
            this.loaderService.isBusy = false;
            this.back();
          } else if ('saveAdd' == type) {
            this.CompanyTheme();
            this.displayDialog = false;
            this.route.navigate(['/appSetup/division'], { queryParams: { 'path': 'division-mgmt', 'tittle': 'Division', 'action': 'add', 'flag': 'true', 'compCode': params.compCode }, skipLocationChange: true });
          }

        }, error => {
          this.loaderService.isBusy = false;
        });

      }
    } else {
      this.validateAllFormFields(this.compMasterFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
<<<<<<< HEAD
    Object.keys(formGroup['controls']).forEach(field => {
=======
    Object.keys(formGroup.controls).forEach(field => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  back() {
    this.route.navigate(['/appSetup/orgstructure'], { queryParams: { "flag": true, "title": "Org Setup", "path": "" },skipLocationChange:true });
  }
  getDefDivCode() {
    this.divArry = [{

    }]
  }
  loadCompanyInfo() {
    this.loaderService.isBusy = true;
    this.editFlag = true;
    let obj = {
      "compCode": this.companyCode,
    }
    this.appSetupService.retrieveCompanyByPK(obj).subscribe(result => {
      this.companyInfo = result;
      if (this.companyInfo.list.compLogo == null) {
        this.companyInfo.list.compLogo = '';
      }
      this.url = atob(this.companyInfo.list.compLogo);
      this.compMasterFrm.patchValue({
        compCode: this.companyInfo.list.mcompanyPK.compCode,
        compName: this.companyInfo.list.compName,
        compShortName: this.companyInfo.list.compShortName,
        compLogo: this.companyInfo.list.compLogo,
        compAdd1: this.companyInfo.list.compAdd1,
        compAdd2: this.companyInfo.list.compAdd2,
        compAdd3: this.companyInfo.list.compAdd3,
        compDfltDivnCode: this.companyInfo.list.compDfltDivnCode,
        compBlName: this.companyInfo.list.compBlName,
        compBlShortName: this.companyInfo.compBlShortName,
        compBlAdd1: this.companyInfo.list.compBlAdd1,
        compBlAdd2: this.companyInfo.list.compBlAdd2,
        compBlAdd3: this.companyInfo.list.compBlAdd3,
        compBaseCurrCode1: this.companyInfo.list.compBaseCurrCode1,
        compBaseCurrCode2: this.companyInfo.list.compBaseCurrCode2,
        compBaseCurrCode3: this.companyInfo.list.compBaseCurrCode3,
        compRoundOff: this.companyInfo.list.compRoundOff,
        compUnitName: this.companyInfo.list.compUnitName,
        compEmailId: this.companyInfo.list.compEmailId,
        compTelNo: this.companyInfo.list.compTelNo,
        compFaxNo: this.companyInfo.list.compFaxNo,
        compTheme: this.companyInfo.list.compTheme,
        compFrzFlag: this.companyInfo.list.compFrzFlag,
        compWebsite: this.companyInfo.list.compWebsite,
        compContactCenterNo: this.companyInfo.list.compContactCenterNo,
        compPostBoxNo: this.companyInfo.list.compPostBoxNo
      })
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      throw error;
    });
  }
  chagelogo() {
  }
  loadDiviCodeList() {
    this.cities = [
      { name: 'New York', code: 'NY' },
      { name: 'Rome', code: 'RM' },
      { name: 'London', code: 'LDN' },
      { name: 'Istanbul', code: 'IST' },
      { name: 'Paris', code: 'PRS' }
    ];
  }

  readUrl(e, parameter) {
    var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    var reader = new FileReader();
    this.variable = parameter;
    reader.onload = this._handleReaderLoaded.bind(this);
    reader.readAsDataURL(file);
  }

  _handleReaderLoaded(e) {
    let reader = e.target;
    if (this.variable == 'url') {
      this.url = reader.result;
      this.compMasterFrm.patchValue({
        compLogo: btoa(reader.result)
      })
    }
  }

  CompanyTheme() {
    let obj = {
      "compCode": this.session.get("companyCode")
    }
    this.appSetupService.retrieveCompanyByPK(obj).subscribe(result => {
      this.title = result.list.compTheme
      this.setActiveStyleSheet(this.title);
    }, error => {
      throw error;
    });
  }

  setActiveStyleSheet(title) {
    this.session.set("themeColor", title);
    var i, a;
    for (i = 0; (a = document.getElementsByTagName("link")[i]); i++) {
      if (a.getAttribute("rel").indexOf("style") != -1 && a.getAttribute("title")) {

        a.disabled = true;
        if (a.getAttribute("title") == title) a.disabled = false;
      }
    }
    return false;
  }
}



