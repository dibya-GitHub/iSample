import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { zip } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';
import { AppSetupService } from '../../services/app-setup.service';

@Component({
  selector: 'app-exchange-rate-grid',
  templateUrl: './exchange-rate-grid.component.html',
  styleUrls: ['./exchange-rate-grid.component.scss'],
})
export class ExchangeRateGridComponent implements OnInit {
  public defaultColDef;
  exchangeRateForm: UntypedFormGroup;
  colDefs: any[];
  rowData: any = [];
  gridApi: any;
  gridColumnApi: any;
  exchRateList: any[];
  currList: any[];
  exchDateList: any[];
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  quickSearchValue: string;

  constructor(
    private appSetupService: AppSetupService,
    private router: Router,
    private formBuilder: UntypedFormBuilder,
    private session: SessionStorageService,
    private loaderService: LoaderService,

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.colDefs = [
      { field: 'exchangeRatePK.erRateFor', headerName: 'Rate Type' },
      { field: 'exchangeRatePK.erConvFmCurrCode', headerName: 'From Currency' },
      { field: 'exchangeRatePK.erConvToCurrCode', headerName: 'To Currency' },
      { field: 'erBuyRate', headerName: 'Buy Rate' },
      { field: 'erSelRate', headerName: 'Sell Rate' },
      {
        field: 'exchangeRatePK.erEffFrmDt',
        headerName: 'Eff Fm Date',
        //dateField: 'yes',
        valueGetter: function (params) {
          if (params && params.data && params.data.exchangeRatePK.erEffFrmDt) {
            return moment(params.data.exchangeRatePK.erEffFrmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }

        },
      },
      {
        field: 'exchangeRatePK.erEffToDt',
        headerName: 'Eff To Date',
        //dateField: 'yes',
        valueGetter: function (params) {
          if (params && params.data && params.data.exchangeRatePK.erEffToDt) {
            return moment(params.data.exchangeRatePK.erEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }

        },
      },
      {
        field: 'exchangeRatePK.erRateFor',
        headerName: 'Actions',
        sortable: false,
        filter: false,
        enableRowGroup: false,
        cellStyle: { textAlign: 'center' },
        cellRenderer: actionRender,
      }
    ];
    this.createSearchForm();
    this.getMasterData();
  }
  createSearchForm() {
    this.exchangeRateForm = this.formBuilder.group({
      erRateFor: [undefined],
      erConvFmCurrCode: [undefined],
      erEffFrmDt: [undefined]
    });
  }
  getMasterData() {
    zip(
      this.appSetupService.retrieveExchangRateType(),
      this.appSetupService.retrieveExchCurrList(),
      this.appSetupService.retrieveExchDateList()
    )
      .subscribe(([exchRateList, currList, exchDateList]) => {
        this.exchRateList = exchRateList as any[];
        this.currList = currList as any[];
        this.exchDateList = exchDateList as any[];
        let exchDtObj = [];
        for(let i=0;i < this.exchDateList.length ; i++){
          exchDtObj.push({
            key : this.exchDateList[i],
            value : this.exchDateList[i]
          })
        }
        this.exchDateList = exchDtObj;
        this.exchangeRateForm.patchValue(
          {
            erRateFor: 'TN',
            erConvFmCurrCode: this.session.get('baseCurrency'),
            //erEffFrmDt: this.exchDateList[this.exchDateList.length - 1]
            erEffFrmDt: this.exchDateList[this.exchDateList.length - 1].value
          }
        );
        this.searchExchange();
      }, err => {
        this.loaderService.isBusy = false;
      });
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("applicableProductContractTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  searchExchange() {
    this.loaderService.isBusy = true;
    const filters = this.exchangeRateForm.value;
    filters.erEffFrmDt = moment(filters.erEffFrmDt, 'DD/MM/YYYY').format('DD-MM-YYYY');
    this.appSetupService.loadExchangeRateGrid(filters).subscribe(resp => {
      this.rowData = resp.list;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      const actionType = e.event.target.getAttribute('data-action-type');
      if (actionType === 'Edit') {
        return this.navigateToForm(e.data);
      }
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  navigateToForm(data) {

    if (data) {
      let objParam = {
        erInstId: data.exchangeRatePK.erInstId,
        erEffFrmDt: data.exchangeRatePK.erEffFrmDt,
        erEffToDt: data.exchangeRatePK.erEffToDt,
        erCurrFrmCode: data.erCurrFrmCode,
        erCurrToCode: data.erCurrToCode,
        erRatefor: data.erRatefor,
        erBuyRate: data.erBuyRate,
        erSelRate: data.erSelRate,
        Action: 'edit'
      };
      this.router.navigate(['/appSetup/exchangeRates/edit'], { queryParams: { exchangeInfo: JSON.stringify(objParam) }, skipLocationChange: true });
    } else {
      let objParam = {
        Action: 'add'
      }
      this.router.navigate(['/appSetup/exchangeRates/add'], { queryParams: { exchangeInfo: JSON.stringify(objParam) }, skipLocationChange: true });
    }
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
    </a>`;
  }
}