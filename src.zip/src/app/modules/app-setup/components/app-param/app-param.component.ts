import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppSetupService } from '../../services/app-setup.service';

@Component({
  selector: 'app-app-param',
  templateUrl: './app-param.component.html',
  styleUrls: ['./app-param.component.scss']
})
export class AppParamComponent implements OnInit {

  public defaultColDef;
  appParamsColDefs: any[];
  appParams: any[];
  gridApi: any;
  gridColumnApi: any;
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  quickSearchValue: string;

  constructor(
    private router: Router,
    private appSetupService: AppSetupService,
    private loaderService: LoaderService,
    private toastService: ToastService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.appParamsColDefs = [
      {
        field: 'mappParameterPK.paraCode',
        headerName: 'Code'
      },
      {
        field: 'paraName',
        header: 'Desc'
      },
      {
        field: 'mappParameterPK.paraSubCode',
        headerName: 'Sub-Code'
      },
      {
        field: 'mappParameterPK.paraCode',
        headerName: 'Actions',
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      }
    ];
    this.getAppParams();
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  getAppParams() {
    this.appSetupService.retrieveAppParamsDetails().subscribe(resp => {
      this.appParams = resp.appParamsArray;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');

      switch (actionType) {
        case "Edit":
          return this.navigateToForm(data);
      }
    }

  }

  navigateToForm(data) {
    if (data) {
      this.router.navigate(['/appSetup/appParams/edit'], { queryParamsHandling: 'merge', queryParams: { paraCode: data.mappParameterPK.paraCode, paraSubCode: data.mappParameterPK.paraSubCode, action: 'edit' }, skipLocationChange: true });
    } else {
      this.router.navigate(['/appSetup/appParams/add'], { queryParamsHandling: 'merge', queryParams: { action: 'add' } });
    }
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
}

function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
  </a>`;
  }
}