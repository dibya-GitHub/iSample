import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConfigComponent } from './components/app-config/app-config.component';
import { AppParamComponent } from './components/app-param/app-param.component';
import { CompanyMasterComponent } from './components/company-master/company-master.component';
import { CostCenterComponent } from './components/cost-center/cost-center.component';
import { CustomizablePwdScreenComponent } from './components/customizable-pwd-screen/customizable-pwd-screen.component';
import { ExchangeRateGridComponent } from './components/exchange-rate-grid/exchange-rate-grid.component';
import { ExchangeRateComponent } from './components/exchange-rate/exchange-rate.component';
import { MAppConfigComponent } from './components/m-app-config/m-app-config.component';
import { MAppParamComponent } from './components/m-app-param/m-app-param.component';
import { MDepartmentComponent } from './components/m-department/m-department.component';
import { MDivisionComponent } from './components/m-division/m-division.component';
import { MTeamComponent } from './components/m-team/m-team.component';
import { OrgStructureComponent } from './components/org-structure/org-structure.component';

const routes: Routes = [{
  path: 'appConfig',
  component: AppConfigComponent,
  data: {
    breadcrumb: 'App Config'
  },
},
{
  path: 'appConfig/add',
  component: MAppConfigComponent,
  data: {
    breadcrumb: 'App Config-Add'
  },
},
{
  path: 'appConfig/edit',
  component: MAppConfigComponent,
  data: {
    breadcrumb: 'App Config-Edit'
  }
},
{
  path: 'appParams',
  component: AppParamComponent,
  data: {
    breadcrumb: 'App Params'
  }
},
{
  path: 'appParams/add',
  component: MAppParamComponent,
  data: {
    breadcrumb: 'App Params-Add'
  }
},
{
  path: 'appParams/edit',
  component: MAppParamComponent,
  data: {
    breadcrumb: 'App Params-Edit'
  }
},
{
  path: 'exchangeRates',
  component: ExchangeRateGridComponent,
  data: {
    breadcrumb: 'Exchange Rate'
  }
},
{
  path: 'exchangeRates/add',
  component: ExchangeRateComponent,
  data: {
    breadcrumb: 'Exchange Rate-Add'
  }
},
{
  path: 'exchangeRates/edit',
  component: ExchangeRateComponent,
  data: {
    breadcrumb: 'Exchange Rate-Edit'
  }
},
{
  path: 'orgstructure',
  component: OrgStructureComponent,
  data: {
    breadcrumb: 'Org Structure'
  }
},
{
  path: 'company',
  component: CompanyMasterComponent,
  data: {
    breadcrumb: 'Company'
  }
},
{
  path: 'division',
  component: MDivisionComponent,
  data: {
    breadcrumb: 'Division'
  }
},
{
  path: 'cost',
  component: CostCenterComponent,
  data: {
    breadcrumb: 'Cost'
  }
},
{
  path: 'depart',
  component: MDepartmentComponent,
  data: {
    breadcrumb: 'Department'
  }
},
{
  path: 'team',
  component: MTeamComponent,
  data: {
    breadcrumb: 'Team'
  }
},
{
  path: 'passwordpolicy',
  component: CustomizablePwdScreenComponent,
  data: {
    breadcrumb: 'Password Policy'
  }
}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppSetupRoutingModule { }
