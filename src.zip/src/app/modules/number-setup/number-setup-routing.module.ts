import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { TransDocGridComponent } from "./components/trans-doc-grid/trans-doc-grid.component";
import { TransDocnoGenarationComponent } from "./components/trans-docno-genaration/trans-docno-genaration.component";

const routes = [
    {
        path: 'trans-doc',
        component: TransDocGridComponent,
        data: {
          breadcrumb: 'Trans Doc'
        },
    },
    {
        path: 'trans-doc/add',
        component: TransDocnoGenarationComponent,
        data: {
          breadcrumb: 'Trans Doc-Add'
        },
    },
    {
        path: 'trans-doc/edit',
        component: TransDocnoGenarationComponent,
        data: {
          breadcrumb: 'Trans Doc-Edit'
        },
    }
];

@NgModule({
    imports: [ RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class NumberSetupRoutingModule { }
