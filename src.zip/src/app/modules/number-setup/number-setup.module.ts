import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NumberSetupRoutingModule } from './number-setup-routing.module';
import { NumberSetupService } from './services/number-setup.service';
import { TransDocGridComponent } from './components/trans-doc-grid/trans-doc-grid.component';
import { TransDocnoGenarationComponent } from './components/trans-docno-genaration/trans-docno-genaration.component';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { DropdownModule } from 'primeng/dropdown';
<<<<<<< HEAD
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@NgModule({
    imports: [
        NumberSetupRoutingModule,
        CommonModule,
        CommonAppModule,
        DropdownModule
    ],
    declarations: [
        TransDocGridComponent,
        TransDocnoGenarationComponent
    ],
    providers: [ NumberSetupService ]
})
export class NumberSetupModule { }
