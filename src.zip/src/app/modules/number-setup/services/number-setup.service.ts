import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
import { environment } from 'src/environments/environment';
import { SessionStorageService } from 'angular-web-storage';

@Injectable(
    {
        providedIn: 'root'
    }
)
export class NumberSetupService {
    baseUrl: any = environment.commonBaseUrl;
    instanceId: any;
    constructor(
        private _httpService: HttpClient,
        private session: SessionStorageService
    ) {
        this.instanceId = this.session.get('instanceId');
<<<<<<< HEAD

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }

    retrieveTransDocType() {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/doctype');
    }
    retrieveTransDepList(docType: string): Observable<any> {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/type/' + docType);
    }
    retrieveTransCompanyList(): Observable<any> {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/company');
    }
    retrieveTransDocList() {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/depart');
    }
    retrieveTransYearList() {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/year');
    }
    retrieveTransDocById(body: any): Observable<any> {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/doctype/' + body.tdnDocType + '?company=' + body.tdnCompCode + '&code=' + body.tdnCode + '&year=' + body.tdnYear);
    }
    updateTransDoc(body): Observable<any> {
        return this._httpService.put<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/doctype/' + body.mtranDocNoPK.tdnDocType, body);
    }
    insertTransDoc(body): Observable<any> {
        return this._httpService.post<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/doctype/' + body.tdnDocType, body);
    }
    retrieveTranDocList(docType: string): Observable<any> {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/type/' + docType);
    }
    retrieveDivList(company: string): Observable<any> {
        return this._httpService.get<any>(this.baseUrl + 'transdoc-mgmt/' + ApiUrls.INSTANCE + '/' + this.instanceId + '/division/' + company);
    }
}
