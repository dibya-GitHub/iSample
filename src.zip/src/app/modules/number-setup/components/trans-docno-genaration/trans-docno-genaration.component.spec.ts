import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransDocnoGenarationComponent } from './trans-docno-genaration.component';

describe('TransDocnoGenarationComponent', () => {
  let component: TransDocnoGenarationComponent;
  let fixture: ComponentFixture<TransDocnoGenarationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransDocnoGenarationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransDocnoGenarationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
