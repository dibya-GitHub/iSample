<<<<<<< HEAD
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { NumberSetupService } from '../../services/number-setup.service';
=======
import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { NumberSetupService } from '../../services/number-setup.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AuthService } from 'src/app/services/auth.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-trans-docno-genaration',
  templateUrl: './trans-docno-genaration.component.html',
  styleUrls: ['./trans-docno-genaration.component.css']
})
export class TransDocnoGenarationComponent implements OnInit {

  CurrNoErr: boolean;
  LastNoErr: boolean;
  CurrNo: string;
  LastNo: any;
  FirstNo: any;
  disableDocType: boolean;
  yearList: any;
  year: any;
  code: any;
  compCode: any;
  docType: any;
  path: string;
  action: string;
  transDocFrm: UntypedFormGroup;
  showGrid: boolean = false;
  srchFrm: UntypedFormGroup;
  compList: any = [];
  divnList: any = [];
  docTypeList: any = [];
  deptList: any = [];
  constructor(
    private fb: UntypedFormBuilder,
<<<<<<< HEAD
    private route: Router,
    private numberSetupService: NumberSetupService,
    private activeRoute: ActivatedRoute,
    private toastService: ToastService,
=======
    private numberSetupService: NumberSetupService,
    private activeRoute: ActivatedRoute,
    private toastService: ToastService,
    private route: Router,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private session: SessionStorageService,
    private loaderService: LoaderService,
    private authService: AuthService
  ) { }


  ngOnInit() {
    this.loaderService.isBusy = true;
    this.activeRoute.queryParams
<<<<<<< HEAD
      .subscribe((params: any) => {
=======
      .subscribe((params:any) => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.action = params.action;
        if (params && params.code) {
          this.docType = params.docType;
          this.compCode = params.compCode;
          this.code = params.code;
          this.year = params.year;
        }
      });
    this.loadCompany();
    this.loadDepartment();
    this.numberSetupService.retrieveTransDocType().subscribe(result => {
      this.docTypeList = result;
    }, error => {
      this.toastService.error("Error while fetching doc type list");
    });
    this.numberSetupService.retrieveTransYearList().subscribe(result => {
      this.yearList = result;
    });

    if (this.action === 'edit') {
      this.disableDocType = true;
      this.loadTranDocDetails();
    }
    this.createTransDocFrm();
  }

  loadCompany() {
    this.numberSetupService.retrieveTransCompanyList().subscribe(result => {
      this.compList = result;
    });
  }
  loadDivision(event) {
    let company;
    this.loaderService.isBusy = true;
    (typeof event === 'object') ? company = event.value : company = event;
    this.numberSetupService.retrieveDivList(company).subscribe(result => {
      this.divnList = result;
      this.loaderService.isBusy = false;
    });
  }

  loadDepartment() {
    this.numberSetupService.retrieveTransDocList().subscribe(result => {
      this.deptList = result;
    });
  }

  createSearchForm() {
    this.srchFrm = this.fb.group({
      tdnDocType: ['', Validators.required]
    });
  }

  createTransDocFrm() {

    this.transDocFrm = this.fb.group({
      tdnInstId: this.authService.getInstanceCode(),
      tdnDocType: [{ value: undefined, disabled: this.disableDocType }, Validators.required],
      tdnCompCode: [{ value: undefined, disabled: this.disableDocType }, Validators.required],
      tdnDivnCode: [undefined, Validators.required],
      tdnDeptCode: undefined,
      tdnCode: [{ value: undefined, disabled: this.disableDocType }, Validators.required],
      tdnYear: [{ value: undefined, disabled: this.disableDocType }, Validators.required],
      tdnFirstNo: ['', Validators.required],
      tdnLastNo: ['', [Validators.required]],
      tdnCurrNo: ['', Validators.required],
      tdnCrUid: this.session.get('userId'),
      tdnCrDt: new Date(),
      mtranDocNoPK: ''
    });
    this.loaderService.isBusy = false;
  }
  save() {
    if (this.transDocFrm.valid) {
      this.loaderService.isBusy = true;
      var params = {
        'tdnInstId': this.transDocFrm.get('tdnInstId').value,
        'tdnDocType': this.transDocFrm.get('tdnDocType').value,
        'tdnCompCode': this.transDocFrm.get('tdnCompCode').value,
        'tdnCode': this.transDocFrm.get('tdnCode').value,
        'tdnYear': this.transDocFrm.get('tdnYear').value,
      };
      console.log(params)
      if (this.action === 'edit') {
        this.transDocFrm.patchValue({
          mtranDocNoPK: params
        })
        this.loaderService.isBusy = true;
        this.numberSetupService.updateTransDoc(this.transDocFrm.value).subscribe(result => {
          this.toastService.success('Updated Successfully.');
          this.loaderService.isBusy = false;
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error in Update Data');
        })
      } else {
        this.transDocFrm.patchValue({
          mtranDocNoPK: params
        })
        this.loaderService.isBusy = true;
        this.numberSetupService.insertTransDoc(this.transDocFrm.value).subscribe(result => {
          this.loaderService.isBusy = false;
          this.toastService.success('Saved Successfully.');
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error in Saving Data');
        });
      }
    } else {
      this.validateAllFormFields(this.transDocFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  loadTranDocDetails() {
    this.loaderService.isBusy = true;
    let obj = {
      'tdnDocType': this.docType,
      'tdnCompCode': this.compCode,
      'tdnCode': this.code,
      'tdnYear': this.year,
    }
    this.numberSetupService.retrieveTransDocById(obj).subscribe(result => {
      result = result.TransDocList;
      result = result[0];
      console.log(result);
      this.FirstNo = result.tdnFirstNo;
      this.LastNo = result.tdnLastNo;
      this.loadDivision(result.mtranDocNoPK.tdnCompCode);
      this.transDocFrm.patchValue({
        tdnDocType: result.mtranDocNoPK.tdnDocType,
        tdnCompCode: result.mtranDocNoPK.tdnCompCode,
        tdnDivnCode: result.tdnDivnCode,
        tdnDeptCode: result.tdnDeptCode,
        tdnCode: result.mtranDocNoPK.tdnCode,
        tdnYear: result.mtranDocNoPK.tdnYear,
        tdnFirstNo: result.tdnFirstNo,
        tdnLastNo: result.tdnLastNo,
        tdnCurrNo: result.tdnCurrNo,
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
  back() {
    this.route.navigate(['/number-setup/trans-doc'], { queryParams: { 'path': this.path, 'title': 'Trans doc' } });
  }
  FirstNoValidation(event) {
    this.FirstNo = event.target.value;
  }
  LastNoValidation(event) {
    this.LastNo = event.target.value;
    if (parseInt(this.FirstNo) < parseInt(this.LastNo)) {
      this.transDocFrm.patchValue({
        tdnLastNo: this.LastNo,
      })
      this.LastNoErr = false;
    } else {
      this.LastNoErr = true;
    }

  }
  CurrNoValidation(event) {
    this.CurrNo = event.target.value;
    if (parseInt(this.FirstNo) <= parseInt(this.CurrNo) && parseInt(this.LastNo) >= parseInt(this.CurrNo)) {
      this.CurrNoErr = false;
    } else {
      this.CurrNoErr = true;
    }
  }

}