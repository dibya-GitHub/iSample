import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
<<<<<<< HEAD
import { Router } from '@angular/router';
=======
import { NumberSetupService } from '../../services/number-setup.service';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/services/toast.service';
// import { ToastrService } from 'ngx-toastr';
// import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { NumberSetupService } from '../../services/number-setup.service';

@Component({
   selector: 'app-trans-doc-grid',
   templateUrl: './trans-doc-grid.component.html',
   styleUrls: ['./trans-doc-grid.component.scss']
})

export class TransDocGridComponent implements OnInit {

   public defaultColDef;
   colDefs: any[];
   transDocs: any[];
   gridApi: any;
   gridColumnApi: any;
   showEntriesOptions = [10, 20, 50, 100];
   showEntriesOptionSelected = 10;
   quickSearchValue: string;
   docTypes: any[];
   filterForm: UntypedFormGroup;

   constructor(
      private fb: UntypedFormBuilder,
<<<<<<< HEAD
      private router: Router,
      private numberSetupService: NumberSetupService,
=======
      private numberSetupService: NumberSetupService,
      private router: Router,
      //private toasterService: ToastrService,
      // private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      private toastService: ToastService,
      private loaderService: LoaderService
   ) {
      this.defaultColDef = {
         resizable: true,
         sortable: true,
         filter: true,
         enableRowGroup: true,
      };
   }

   ngOnInit() {
      this.loaderService.isBusy = true;
      this.filterForm = this.fb.group({
         docType: 'all'
      });
      this.colDefs = [
         {
            field: 'mtranDocNoPK.tdnDocType',
            headerName: 'Doc Type'
         },
         {
            field: 'tdnUpdUid',
            headerName: 'Division Name'
         },
         {
            field: 'mtranDocNoPK.tdnCode',
            headerName: 'Code'
         },
         {
            field: 'mtranDocNoPK.tdnYear',
            headerName: 'Ac Year'
         },
         {
            field: 'tdnFirstNo',
            headerName: 'First Number'
         },
         {
            field: 'tdnLastNo',
            headerName: 'Last Number'
         },
         {
            field: 'tdnCurrNo',
            headerName: 'Current Number'
         },
         {
            field: 'mtranDocNoPK.tdnDocType',
            headerName: 'Action',
            cellRenderer: actionRender,
<<<<<<< HEAD
=======
            // cellRenderer:  function (params) {
            //    if (params && params.data && params.data.mtranDocNoPK && params.data.mtranDocNoPK.tdnDocType) {            
            //      return `<a>
            //      <i class="fa fa-pencil fa-icon"  data-action-type="Edit"  title="Edit" aria-hidden="true"></i>
            //  </a>`;
            //    } else {
            //      return '';
            //    }
            //  },           
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            sortable: false,
            filter: false,
            enableRowGroup: false,
            cellStyle: { textAlign: 'center' },
         }
      ];
      this.getDocTypes();
      this.retriveData();
   }

   getDocTypes() {
      this.numberSetupService.retrieveTransDocType()
         .subscribe(res => {
            this.docTypes = [{ key: 'all', value: 'All' }, ...res];
            this.loaderService.isBusy = false;
         }, err => {
            this.loaderService.isBusy = false;
            this.toastService.error('Error in Retrive Data');
         });
   }

   onGridReady(params) {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
      this.gridApi.sizeColumnsToFit();
   }
   onQuickFilterChanged() {
      this.gridApi.setQuickFilter(this.quickSearchValue);
   }
   onFirstDataRendered(params) {
      params.api.sizeColumnsToFit();
   }
   displayedRowCount() {
      if (this.gridApi) {
         return this.gridApi.getDisplayedRowCount();
      } else {
         return;
      }
   }

   onFilterChange() {
      this.retriveData();
   }

   retriveData() {
      this.numberSetupService.retrieveTranDocList(this.filterForm.value.docType).subscribe(resp => {
         if (resp) {
            this.transDocs = resp.list;

         }
         this.loaderService.isBusy = false;
      }, error => {
         this.loaderService.isBusy = false;
         this.toastService.error('Error in Retrive Data');
      });
   }

   public onRowClicked(e) {
      if (e.event.target !== undefined) {
         const data = e.data;
         console.log('rowselectdata::', data);
         const actionType = e.event.target.getAttribute('data-action-type');

         switch (actionType) {
            case 'Edit':
               return this.navigateToForm(data);
            case 'Delete':
               return this.deleteCurrency(data);
         }
      }

   }
   deleteCurrency(data: any) {

   }

   navigateToForm(data) {
      if (data) {
         this.router.navigate(['/number-setup/trans-doc/edit'],
            {
               queryParams: {
                  code: data.mtranDocNoPK.tdnCode,
                  docType: data.mtranDocNoPK.tdnDocType,
                  compCode: data.mtranDocNoPK.tdnCompCode,
                  year: data.mtranDocNoPK.tdnYear,
                  action: 'edit'
               }
            }
         );
      } else {
         this.router.navigate(['/number-setup/trans-doc/add'], { queryParams: { action: 'add' } });
      }
   }

   pageChanged(event: any): void {
      this.gridApi.paginationGoToPage(event.page - 1);
   }

   onPaginationCountChange(event: any) {
      this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
      this.gridApi.paginationGoToPage(0);
   }

   back() {
      this.router.navigate(['master/admindashboard'], { queryParams: { title: 'Home' } });
   }
}
function actionRender(params) {
   if (params.value === undefined || params.value === null) {
     return '';
   } else {
     return `<a>
      <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true"></i>
      </a>`;
   }
 }