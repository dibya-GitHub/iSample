import { Component, OnDestroy, OnInit } from '@angular/core';
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { ReportService } from '../../services/report.service';
import { LoaderService } from './../../../../services/loader.service';

@Component({
  selector: 'app-dynamic-report',
  templateUrl: './dynamic-report.component.html',
  styleUrls: ['./dynamic-report.component.scss']
})
export class DynamicReportComponent implements OnInit, OnDestroy {

  reportColumnDef = [];
  showForm;
  reportList = [];
  viewList;
  option;
  gridApi;
  quickSearchValue
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public subscribers: any = {};
  showDynReport = false;
  action = "";
  reportId = null;
  dynReqData: any;
  excelStyles = [
    {
      id: 'stringType',
      dataType: 'string',
    },
    {
      id: 'header',
      interior: {
        color: '#CCCCCC',
        pattern: 'Solid',
      },
      borders: {
        borderBottom: {
          color: '#5687f5',
          lineStyle: 'Continuous',
          weight: 1,
        },
        borderLeft: {
          color: '#5687f5',
          lineStyle: 'Continuous',
          weight: 1,
        },
        borderRight: {
          color: '#5687f5',
          lineStyle: 'Continuous',
          weight: 1,
        },
        borderTop: {
          color: '#5687f5',
          lineStyle: 'Continuous',
          weight: 1,
        },
      },
    }
  ];
  dynamicReportColResp: any;
  dynamicReportDataResp: any;
  reportShow = false;
  defaultColDef = {
    flex: 1,
    resizable: true,
    sortable: true,
    filter: true,
    enableRowGroup: true,

  };
  colOrderMap = [];
  gridLoading = true;

  constructor(
    private reportService: ReportService,
    private loaderService: LoaderService,

  ) {
    this.subscribers = this.reportService.getdynRepOpenClk().subscribe((obj) => {
      if (obj.action == "Add") {
        this.viewList = (obj.viewCode == null) ? null : obj.viewCode.desc;
        this.dynReqData = obj.dynReqData;
        this.showDynReport = true;
        this.action = obj.action;
        this.loadDynamicReport();
      } else if (obj.action == "Edit") {
        this.viewList = (obj.viewCode == null) ? null : obj.viewCode.desc;
        this.dynReqData = obj.dynReqData;
        this.showDynReport = true;
        this.action = obj.action;
        this.reportId = obj.reportId
        this.loadDynamicReport();
      }

    });

  }

  ngOnDestroy() {
    this.subscribers.unsubscribe();
  }

  ngOnInit(): void {

  }

  loadDynamicReport() {

    if (this.action == "Add") {
      this.gridLoading = true;
      forkJoin(
        this.reportService.runDynRepWithandWithoutParamsCol(this.dynReqData),
        this.reportService.runDynRepWithandWithoutParamsData(this.dynReqData)
      ).subscribe(([res1, res2]) => {
        this.gridLoading = false;
        this.dynamicReportColResp = res1;
        this.dynamicReportDataResp = res2;
        this.loaderService.isBusy = false;
        this.createDynamicTable();
      });
    } else if (this.action == "Edit") {
      this.gridLoading = true;
      forkJoin(
        this.reportService.runDynRepWithandWithoutParamsCol(this.dynReqData),
        this.reportService.runDynRepWithandWithoutParamsData(this.dynReqData)
      ).subscribe(([res1, res2]) => {
        this.gridLoading = false;
        this.dynamicReportColResp = res1;
        this.dynamicReportDataResp = res2;
        this.loaderService.isBusy = false;

        this.createDynamicTable();
      });
    }
  }
  createDynamicTable() {
    this.colOrderMap = [];
    this.reportColumnDef = [];
    this.reportList = [];
    for (let i = 0; i < this.dynamicReportColResp.length; i++) {
      let obj = {
        headerName: this.dynamicReportColResp[i].colLable,
        headerTooltip: this.dynamicReportColResp[i].colLable,
        field: this.dynamicReportColResp[i].colName,
        cellStyle: { textAlign: 'left' },
        tooltipField: this.dynamicReportColResp[i].colName
      };
      this.reportColumnDef.push(obj);
      console.log(this.reportColumnDef);

    }

    for (let j = 0; j < this.dynamicReportDataResp.length; j++) {
      let col = this.getColumnObj();
      let obj = {};
      for (let key in this.dynamicReportDataResp[j]) {
        if (col[key]["dataType"] == "D" || col[key]["dataType"] == "T") {
          if (this.dynamicReportDataResp[j][key] === undefined || this.dynamicReportDataResp[j][key] === null
            || this.dynamicReportDataResp[j][key] === "") {
            obj[col[key]["colName"]] = '';
          } else if (col[key]["dataType"] == "D") {

            obj[col[key]["colName"]] = moment(this.dynamicReportDataResp[j][key]).format('DD/MM/YYYY');
          } else if (col[key]["dataType"] == "T") {
            obj[col[key]["colName"]] = moment(this.dynamicReportDataResp[j][key]).format('DD/MM/YYYY HH:mm');
          }
        } else {
          obj[col[key]["colName"]] = this.dynamicReportDataResp[j][key];
        }
      }
      this.reportList.push(obj);
    }
    this.gridLoading = false;
    this.reportShow = true;
  }

  getColumnObj() {
    let obj = {};
    for (let i = 0; i < this.dynamicReportColResp.length; i++) {
      obj[this.dynamicReportColResp[i].order] = {
        colName: this.dynamicReportColResp[i].colName,
        dataType: this.dynamicReportColResp[i].dataType
      }
    }
    return obj;
  }

  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.editReport(data);
      }
    }
  }
  editReport(data) {

  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'Report.xlsx',
        skipHeader: false,
        sheetName: 'Report',
        processCellCallback: (params) => {
          if (params.column.dataType == "D" && params.value != null) {
            return moment(params.value).format('DD/MM/YYYY');
          } else if (params.column.dataType == "DT" && params.value != null) {
            return moment(params.value).format('DD/MM/YYYY');
          } else {
            return params.value;
          }

        },
      });
    }
  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("dynReportTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
}
