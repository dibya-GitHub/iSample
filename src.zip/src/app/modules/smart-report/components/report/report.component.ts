import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ReportService } from '../../services/report.service';
import { LoaderService } from './../../../../services/loader.service';
declare var $: any;

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {

  reportColumnDef: any
  showForm;
  reportList;
  viewList;
  option;
  gridApi;
  quickSearchValue;
  viewCode = null;
  rowSelection: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  dateFormat: any;
  defaultColDef: any;
  hideAddEditReport = false;
  openExisRepResp: any;
  dynReqData: any;
  hideDynamicReport = false;
  @ViewChild('addReportModal') addReportModal: ElementRef;

  constructor(
    private router: Router,
    private reportService: ReportService,
    private loaderService: LoaderService,
    private modalService: BsModalService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    }
  }

  ngOnInit(): void {
    this.reportColumnDef = [
      {
        headerName: 'S.No',
        field: 'userReportsPK.urRepId',
      },
      { headerName: 'Report', field: 'urRepName', filter: true, },
      {
        headerName: 'Created Date',
        field: 'urCrDt',
        sort: 'desc',
        filter: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.urCrDt) {
            return moment(params.data.urCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        field: 'userReportsPK.urRepId',
        headerName: "Action",
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      }
    ];

    this.rowSelection = "single";
    this.getAllReport();
    this.getViewDropdown();
  }

  getAllReport() {
    setTimeout(() => { this.loaderService.isBusy = true; }, 0);
    this.reportService.fetchAllReport().subscribe(res => {
      this.reportList = res
      setTimeout(() => { this.loaderService.isBusy = false; }, 0);
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  getViewDropdown() {
    this.reportService.getViewDropdown().subscribe(res => {
      this.viewList = res;
    })
  }

  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.editReport(data.userReportsPK);
        case "Run":
          return this.runReport(data);
        case "RunWithParams":
          return this.runWithParamsReport(data.userReportsPK);
      }
    }
  }

  runReport(data) {
    this.loaderService.isBusy = true;
    this.openExistingReport(data);
  }

  openExistingReport(data) {
    this.loaderService.isBusy = true;
    this.reportService.openExistingReport(data.userReportsPK.urRepId).subscribe(resp => {
      this.openExisRepResp = resp;
      this.callRun(data);
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  callRun(data) {

    this.dynReqData = {
      userReportsPK: data,
      repColumns: this.openExisRepResp.repColumns,
      repFilter: this.openExisRepResp.repFilter,
      repGroup: [],
      repSort: this.openExisRepResp.repSort,
      urViewCode: this.openExisRepResp.urViewCode
    };

    this.hideDynamicReport = true;
    let obj = {
      action: "Edit",
      dynReqData: this.dynReqData,
      reportId: data.userReportsPK.urRepId,
      viewCode: this.viewCode
    };

    this.reportService.setdynRepOpenClk(obj);

  }
  runWithParamsReport(data) {
    this.hideAddEditReport = true;
    this.hideDynamicReport = false;
    let obj = {
      action: "Edit",
      reportId: data.urRepId,
      view: "RunWithParams"
    };
    this.reportService.setaddProceedClk(obj);
  }

  editReport(data) {
    this.hideAddEditReport = true;
    this.hideDynamicReport = false;
    let obj = {
      action: "Edit",
      reportId: data.urRepId,
      view: ""
    };
    this.reportService.setaddProceedClk(obj);
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    }
  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    const sortModel = [
      { colId: 'userReportsPK.urRepId', sort: 'desc' }
    ];
    // this.gridApi.setSortModel(sortModel);
    this.gridApi.sizeColumnsToFit();
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("reportTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }


  addReport() {
    this.hideDynamicReport = false;
    this.hideAddEditReport = true;
    let obj = {
      action: "Add",
      viewCode: this.viewCode
    };
    this.reportService.setaddProceedClk(obj);
    this.closeModal();
  }
  getView(evt) {
    this.viewCode = evt.value;
  }
  back() {
    this.router.navigate(['/master/admindashboard']);
  }
  addSmartReport() {
    this.open(this.addReportModal, 'modal-md')
    this.viewCode = null
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
    </a>&nbsp;&nbsp;&nbsp;
    <a>
    <i class="fa fa-circle-play fa-icon" style="font-size:14px;" aria-hidden="true" data-action-type="Run" title="Run"></i>
    </a>&nbsp;&nbsp;&nbsp;
    <a>
    <i class="fa fa-circle-play-circle-o fa-icon" aria-hidden="true" data-action-type="RunWithParams" title="Run with params"></i>
    </a>`;
  }
}
