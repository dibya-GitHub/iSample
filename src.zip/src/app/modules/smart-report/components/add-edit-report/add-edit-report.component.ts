import { Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { ReportService } from '../../services/report.service';
declare var $: any;
import { BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-add-edit-report',
  templateUrl: './add-edit-report.component.html',
  styleUrls: ['./add-edit-report.component.scss']
})
export class AddEditReportComponent implements OnInit, OnDestroy {

  showError = false;
  showAddEdit = false;
  hideDynamicReport = false;
  sourceColumns: any;
  fiterSourceColumns: any;
  operators: any;
  targetColumns: any;
  public subscribers: any = {};
  gridLoading = true;
  viewCode = null;
  reportId = null;
  action = "";
  view = "";
  dynamicReportColResp: any;
  dynamicReportDataResp: any;
  dynReqData: any;
  reportInfoForm: UntypedFormGroup;
  // saveAsEnable = false;
  saveAndRun = '';
  showFormError = false;
  filterForm: UntypedFormGroup;
  fieldType = "S";
  fieldInputType = "I";
  fetchAllViewResp: any;
  dropdownSettings = {
    singleSelection: false,
    idField: 'key',
    textField: 'value',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 2,
    allowSearchFilter: true,
    enableCheckAll: false
  };
  @ViewChild('saveAsModal') saveAsModal: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private reportService: ReportService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private modalService: BsModalService
  ) {

    this.subscribers = this.reportService.getaddProceedClk().subscribe((obj) => {
      this.view = "";
      if (obj.action == "Add") {
        this.viewCode = obj.viewCode;
        this.showAddEdit = true;
        this.action = "Add";
        // this.saveAsEnable = false;
        this.loadColumnsforReport();
      } else if (obj.action == "Edit") {
        this.reportId = obj.reportId;
        this.showAddEdit = true;
        this.action = "Edit";
        // this.saveAsEnable = true;
        this.view = obj.view;
        // if (this.view == "RunWithParams") {
        //   this.saveAsEnable = false;
        // }
        this.openExistingReport();
      }
      this.targetColumns = [];
      this.createFilterForm();
      this.createSortByForm();
      this.createReportInfoForm();
      this.getOperators();
    });

  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscribers.unsubscribe();
  }

  loadDynamicReport() {
    let filterGrpByOpenCount = 0;
    let filterGrpByCloseCount = 0;
    let filters = JSON.parse(JSON.stringify(this.filterForm.value.filters));
    filters.forEach(element => {
      if (element.urpFieldAttr.rcInputType == "A") {
        if (element.urpOperator == 'BETWEEN' || element.urpOperator == 'NOT BETWEEN') {
          element.urpValueFm = element.urpAutoSearch.selectedValue.key;
          element.urpValueTo = element.urpAutoSearch.selectedValueTo.key;
        } else {
          // if (element && element.urpAutoSearch.selectedValue?.key) {
          //   element.urpValueFm = element.urpAutoSearch.selectedValue.key;
          // }
        }

      }
      if (element.urpFieldAttr.rcInputType == "M") {
        if (element.urpValueFm) {
          element.urpValueFm = this.getMultiSelectList(element.urpValueFm);
        }
      }
      if (element.urpOperator != 'BETWEEN' && element.urpOperator != 'NOT BETWEEN') {
        element.urpValueTo = "";
      }

      if (element.urpFieldAttr) {
        delete element.urpFieldAttr;
      }

      if (element.urpCondGrp == "(") {
        filterGrpByOpenCount++;
      } else if (element.urpCondGrp == ")") {
        filterGrpByCloseCount++;
      }

      if (element.urpAutoSearch) {
        delete element.urpAutoSearch;
      }

      if (element.hasOwnProperty("urpGenDrpDwnList")) {
        delete element.urpGenDrpDwnList;
      }
    });

    if (filterGrpByOpenCount != filterGrpByCloseCount) {
      this.showGroupByError = true;
      window.scrollTo(0, 0);
      return;
    } else {
      filterGrpByOpenCount = filterGrpByCloseCount = 0;
      this.showGroupByError = false;
    }
    // let repId = (this.action == 'Edit') ? this.reportId : null;
    this.dynReqData = {
      repColumns: this.targetColumns,
      repFilter: filters,
      repGroup: [],
      repSort: this.sortByForm.value.sortBys,
      urViewCode: this.viewCode.key,
      userReportsPK: {
        urInstId: 1,
        urRepId: null
      },
    };

    this.hideDynamicReport = true;
    let obj = {
      action: this.action,
      dynReqData: this.dynReqData,
      reportId: this.reportId,
      viewCode: this.viewCode
    };
    this.reportService.setdynRepOpenClk(obj);
  }

  checkColumnSelected() {
    if (this.targetColumns.length == 0) {
      this.showError = true;
    } else {
      this.showError = false;
    }
  }
  cancelAddEditReport() {

    this.route.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.route.navigate(['/smart-report']).then(() => {
      });
    });

  }
  createReportInfoForm() {
    this.reportInfoForm = this.fb.group({
      reportName: ["", Validators.required]
    });
  }

  saveReport(type) {
    this.saveAndRun = type;
    if (this.action == "Add") {
      $("#saveAsModalTrigger").click();
      this.resetSaveasModal();
    } else if (this.action == "Edit") {

      let filters = JSON.parse(JSON.stringify(this.filterForm.value.filters));
      let filterGrpByOpenCount = 0;
      let filterGrpByCloseCount = 0;

      filters.forEach(element => {
        if (element.urpFieldAttr.rcInputType == "A") {
          if (element.urpAutoSearch.selectedValue) {
            element.urpValueFm = element.urpAutoSearch.selectedValue.key ? element.urpAutoSearch.selectedValue.key : "";
            element.urpValueTo = element.urpAutoSearch.selectedValueTo.key ? element.urpAutoSearch.selectedValueTo.key : "";
          }
        }
        if (element.urpFieldAttr.rcDataType == "S" && element.urpFieldAttr.rcInputType == "M") {
          if (element.urpValueFm) {
            element.urpValueFm = this.getMultiSelectList(element.urpValueFm);
          }
        }
        if (element.urpFieldAttr.rcInputType == "M") {
          if (element.urpValueFm) {
            element.urpValueFm = this.getMultiSelectList(element.urpValueFm);
          }
        }
        if (element.urpOperator != 'BETWEEN' && element.urpOperator != 'NOT BETWEEN') {
          element.urpValueTo = "";
        }

        if (element.urpFieldAttr) {
          delete element.urpFieldAttr;
        }

        if (element.urpCondGrp == "(") {
          filterGrpByOpenCount++;
        } else if (element.urpCondGrp == ")") {
          filterGrpByCloseCount++;
        }

        if (element.urpAutoSearch) {
          delete element.urpAutoSearch;
        }

        if (element.hasOwnProperty("urpGenDrpDwnList")) {
          delete element.urpGenDrpDwnList;
        }

      });

      if (filterGrpByOpenCount != filterGrpByCloseCount) {
        this.showGroupByError = true;
        window.scrollTo(0, 0);
        return;
      } else {
        filterGrpByOpenCount = filterGrpByCloseCount = 0;
        this.showGroupByError = false;
      }
      let repId = (this.action == 'Edit') ? this.reportId : null;
      let reqData = {
        urRepName: this.openExisRepResp.urRepName,
        repColumns: this.targetColumns,
        repFilter: filters,
        repGroup: [],
        repSort: this.sortByForm.value.sortBys,
        urViewCode: this.viewCode.key,
        userReportsPK: {
          urInstId: 1,
          urRepId: repId
        },
      };

      this.loaderService.isBusy = true;
      this.reportService.updateReport(this.reportId, reqData).subscribe(resp => {
        this.loaderService.isBusy = false;
        if (resp["messageType"] && resp["messageType"] == 'E') {
          this.toastService.error(resp["message"]);
        } else if (resp["messageType"] && resp["messageType"] == 'S') {
          this.toastService.success(resp["message"]);
        } else {
          this.toastService.success("Updated Successfully!");
        }
        if (type == 'Run') {
          this.saveAndRun = type;
          this.loadDynamicReport();
        } else {
          this.cancelAddEditReport();
        }
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error("Error in update report!");
      });
    }
  }

  saveReportInfo() {

    if (this.reportInfoForm.valid) {
      let data = this.reportInfoForm.value;
      let filters = JSON.parse(JSON.stringify(this.filterForm.value.filters));
      let filterGrpByOpenCount = 0;
      let filterGrpByCloseCount = 0;

      filters.forEach(element => {
        // if ((element.urpFieldAttr.rcDataType == "S" || element.urpFieldAttr.rcDataType == "N") && element.urpFieldAttr.rcInputType == "A") {

        // }
        if (element.urpFieldAttr.rcDataType == "A") {
          if (element.urpValueFm) {
            element.urpValueFm = this.getMultiSelectList(element.urpValueFm);
          }
        }

        if (element.urpOperator != 'BETWEEN' && element.urpOperator != 'NOT BETWEEN') {
          element.urpValueTo = "";
        }

        if (element.urpFieldAttr) {
          delete element.urpFieldAttr;
        }

        if (element.urpCondGrp == "(") {
          filterGrpByOpenCount++;
        } else if (element.urpCondGrp == ")") {
          filterGrpByCloseCount++;
        }
        if (element.urpAutoSearch) {
          delete element.urpAutoSearch;
        }

        if (element.hasOwnProperty("urpGenDrpDwnList")) {
          delete element.urpGenDrpDwnList;
        }

      });

      if (filterGrpByOpenCount != filterGrpByCloseCount) {
        this.showGroupByError = true;
        window.scrollTo(0, 0);
        return;
      } else {
        filterGrpByOpenCount = filterGrpByCloseCount = 0;
        this.showGroupByError = false;
      }

      if (this.action == "Add") {

        let reqData = {
          urRepName: data.reportName,
          repColumns: this.targetColumns,
          userReportsPK: {
            urInstId: 1,
            urRepId: null
          },
          repFilter: filters,
          repGroup: [],
          repSort: this.sortByForm.value.sortBys,
          urViewCode: this.viewCode.key
        };

        this.loaderService.isBusy = true;
        this.reportService.saveReport(reqData).subscribe(resp => {
          this.loaderService.isBusy = false;
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.toastService.success(resp["message"]);
          } else {
            this.toastService.success("Saved Successfully!");
          }
          // $('#saveAsModal').modal('hide');
          document.getElementById('closeAsModalTrigger').click();
          if (this.saveAndRun == 'Run') {
            this.loadDynamicReport();
          } else {
            this.cancelAddEditReport();
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in save report!");
        });

      } else if (this.action == "Edit") {
        let reqData = {
          urRepName: data.reportName,
          repColumns: this.targetColumns,
          userReportsPK: {
            urInstId: 1,
            urRepId: null
          },
          repFilter: filters,
          repGroup: [],
          repSort: this.sortByForm.value.sortBys,
          urViewCode: this.viewCode.key
        };

        this.loaderService.isBusy = true;
        this.reportService.updateReport(this.reportId, reqData).subscribe(resp => {
          this.loaderService.isBusy = false;
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.toastService.success(resp["message"]);
          } else {
            this.toastService.success("Updated Successfully!");
          }
          // $('#saveAsModal').modal('hide');
          document.getElementById('closeAsModalTrigger').click();

          if (this.saveAndRun == 'Run') {
            this.loadDynamicReport();
          } else {
            this.cancelAddEditReport();
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in update report!");
        });
      }
    }
    else {
      this.validateAllFormFields(this.reportInfoForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }


  createFilterForm() {
    this.filterForm = this.fb.group({
      filters: this.fb.array([]),
    });

  }

  setCndGrpdisable(i) {
    let cond = this.getUrpCondGrp(i);
    this.getUrpFieldAttr(i).urpCndGrpCloseDisable = false;
    this.getUrpFieldAttr(i).urpCndGrpOpenDisable = false;
    if (cond == "(") {
      this.getUrpFieldAttr(i).urpCndGrpCloseDisable = true;
    } else if (cond == ")") {
      this.getUrpFieldAttr(i).urpCndGrpOpenDisable = true;
    }
  }

  getOperator(i) {
    let operator = this.filters().value[i].urpOperator;
    operator = (operator) ? operator : '';
    return operator;
  }

  getUrpCondGrp(i) {
    let groupby = this.filters().value[i].urpCondGrp;
    groupby = (groupby) ? groupby : '';
    return groupby;
  }

  getUrpFieldAttr(i) {
    let urpFieldAttr = this.filters().value[i].urpFieldAttr;
    urpFieldAttr = (urpFieldAttr) ? urpFieldAttr : '';
    return urpFieldAttr;
  }
  urpGenDrpDwnList: any;
  getUrpGenDrpDwnList(i) {
    let urpGenDrpDwnList = this.filters().value[i].urpGenDrpDwnList;
    return urpGenDrpDwnList;
  }

  setUrpGenDrpDwnList(i, data) {
    this.filters()['controls'][i].patchValue({ urpGenDrpDwnList: data });
    this.setMultipleSelect(i);
  }

  getUrpAutoSearch(i) {
    let urpAutoSearch = this.filters().value[i].urpAutoSearch;
    let temp = {
      fmData: [],
      fmShowResult: false,
      fmNoDataFound: false,
      toData: [],
      toShowResult: false,
      toNoDataFound: false
    };
    urpAutoSearch = (urpAutoSearch) ? urpAutoSearch : temp;
    return urpAutoSearch;
  }

  filters(): UntypedFormArray {
    return this.filterForm.get("filters") as UntypedFormArray
  }

  showGroupByError = false;

  newFilter(condition): UntypedFormGroup {
    return this.fb.group({
      urpColumn: [null, Validators.required],
      urpCondition: condition,
      urpDataType: "",
      urpCondGrp: "",
      urpOperator: "=",
      urpValueFm: "",
      urpValueTo: "",
      urpFieldAttr: {
        "rcDataType": "S",
        "rcInputType": "I",
        urpCndGrpOpenDisable: false,
        urpCndGrpCloseDisable: false
      },
      urpAutoSearch: {
        fmData: [],
        fmShowResult: false,
        fmNoDataFound: false,
        toData: [],
        toShowResult: false,
        toNoDataFound: false,
        selectedValue: {},
        selectedValueTo: {}
      },
      multiselectShow: false,
      urpGenDrpDwnList: []
    })
  }

  addFilter() {
    if (this.filterForm.valid) {
      let condition = (this.filters()['controls'].length == 0) ? "" : "AND";
      this.filters().push(this.newFilter(condition));
    } else {
      this.validateForm(this.filterForm);
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  validateForm(formGroup: UntypedFormGroup | UntypedFormArray) {
    Object.keys(formGroup['controls']).forEach(field => {
      let control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      }

      if (control instanceof UntypedFormArray) {
        Object.keys(control['controls']).forEach(index => {
          this.validateForm(control.get(index) as UntypedFormGroup);
        })
      } else if (control instanceof UntypedFormGroup) {
        this.validateForm(control);
      }
    });
  }
  removeFilter(i: number) {
    this.filters().removeAt(i);
  }
  sortByForm: UntypedFormGroup;
  createSortByForm() {
    this.sortByForm = this.fb.group({
      sortBys: this.fb.array([]),
    });

  }
  sortBys(): UntypedFormArray {
    return this.sortByForm.get("sortBys") as UntypedFormArray
  }
  newSortBy(): UntypedFormGroup {
    return this.fb.group({
      urpColumn: [null, Validators.required],
      urpCondition: "ASC",
      urpDataType: ""
    })
  }
  addSortBy() {
    if (this.sortByForm.valid) {
      this.sortBys().push(this.newSortBy());
    } else {
      this.validateForm(this.sortByForm);
    }
  }

  removeSortBy(i: number) {
    this.sortBys().removeAt(i);
  }

  filterColSelect = {
    rcDataType: "S",
    rcInputType: "I"
  };

  cleanFmToValue(index) {
    this.filters()['controls'][index].patchValue({ urpValueFm: "", urpValueTo: "" });
  }

  setSortByInputFieldType(index) {

    for (let i = 0; i < this.fiterSourceColumns.length; i++) {
      if (this.sortBys()['controls'][index].get('urpColumn').value == this.fiterSourceColumns[i].id.rcColumnName) {
        this.sortBys()['controls'][index].patchValue({
          urpDataType: this.fiterSourceColumns[i].rcDataType
        });
      }
    }
  }

  setDateandAutosearchVal(index) {
    for (let i = 0; i < this.fiterSourceColumns.length; i++) {
      if (this.filters()['controls'][index].get('urpColumn').value == this.fiterSourceColumns[i].id.rcColumnName) {
        if ((this.fiterSourceColumns[i].rcDataType == "D" || this.fiterSourceColumns[i].rcDataType == "T") && this.fiterSourceColumns[i].rcInputType == "I") {
          if (this.filters()['controls'][index].get('urpValueFm').value != "" && this.filters()['controls'][index].get('urpValueFm').value != null) {
            this.filters()['controls'][index].patchValue({ urpValueFm: this.filters()['controls'][index].get('urpValueFm').value });
          }
          if (this.filters()['controls'][index].get('urpValueTo').value != "" && this.filters()['controls'][index].get('urpValueTo').value != null) {
            this.filters()['controls'][index].patchValue({ urpValueTo: this.filters()['controls'][index].get('urpValueTo').value });
          }
        }
        if ((this.fiterSourceColumns[i].rcDataType == "S" || this.fiterSourceColumns[i].rcDataType == "N") && this.fiterSourceColumns[i].rcInputType == "A") {

          if (this.filters()['controls'][index].get('urpValueFm').value != "" && this.filters()['controls'][index].get('urpValueFm').value != null) {
            this.filters()['controls'][index].patchValue({ urpValueFm: this.getUrpAutoSearch(index).selectedValue.value, urpValueTo: this.getUrpAutoSearch(index).selectedValueTo.value ? this.getUrpAutoSearch(index).selectedValueTo.value : '' });
          }

        }
      }
    }
  }

  setInputFieldType(index) {
    for (let i = 0; i < this.fiterSourceColumns.length; i++) {
      if (this.filters()['controls'][index].get('urpColumn').value == this.fiterSourceColumns[i].id.rcColumnName) {
        this.fieldType = this.fiterSourceColumns[i].rcDataType;
        this.fieldInputType = this.fiterSourceColumns[i].rcInputType;
        this.filters()['controls'][index].patchValue(
          {
            urpFieldAttr: { "rcDataType": this.fiterSourceColumns[i].rcDataType, "rcInputType": this.fiterSourceColumns[i].rcInputType },
            urpValueFm: this.filters()['controls'][index].get('urpValueFm').value,
            urpValueTo: this.filters()['controls'][index].get('urpValueTo').value,
            urpDataType: this.fiterSourceColumns[i].rcDataType,
            urpOperator: this.filters()['controls'][index].get('urpOperator').value,//"=",
            urpCondGrp: this.filters()['controls'][index].get('urpCondGrp').value//""
          });
        if (this.fiterSourceColumns[i].rcInputType == "S") {
          this.setDynamicDropdownList(this.fiterSourceColumns[i].rcDataId, index);
        }
        if (this.fiterSourceColumns[i].rcInputType == "M") {
          this.setDynamicDropdownList(this.fiterSourceColumns[i].rcDataId, index);
          if (!this.filters()['controls'][index].get('urpValueFm').value) {
            this.filters()['controls'][index].get("multiselectShow").setValue(true);
            this.filters()['controls'][index].patchValue(
              {
                urpOperator: 'IN',
                urpCondGrp: ""
              });
          }
        }
      }
    }
  }
  setMultipleSelect(index) {
    for (let i = 0; i < this.fiterSourceColumns.length; i++) {
      if (this.filters()['controls'][index].get('urpColumn').value == this.fiterSourceColumns[i].id.rcColumnName) {
        if (this.fiterSourceColumns[i].rcInputType == "M") {
          if (this.filters()['controls'][index].get('urpValueFm').value != "" && this.filters()['controls'][index].get('urpValueFm').value != null) {
            this.filters()['controls'][index].patchValue({ urpValueFm: this.setMultiselectList(this.filters()['controls'][index].get('urpValueFm').value, this.filters()['controls'][index].get('urpGenDrpDwnList').value) });
            this.filters()['controls'][index].get("multiselectShow").setValue(true);
          }
        }
      }
    }
  }
  dynamicDropDwnList: any;
  setDynamicDropdownList(dataId, index) {
    this.reportService.getDynamicColumnData(dataId, '').subscribe(resp => {
      this.setUrpGenDrpDwnList(index, resp);
    }, error => {
    });

  }
  loadColforRepResp: any;
  loadColumnsforReport() {
    this.gridLoading = true;
    this.reportService.loadColumnsforReport(this.viewCode.key).subscribe(resp => {
      this.loadColforRepResp = resp;
      this.sourceColumns = resp;
      this.fiterSourceColumns = JSON.parse(JSON.stringify(resp));
      console.log(this.sourceColumns);
      console.log(this.fiterSourceColumns);

      // for (let i = 0; i < this.fiterSourceColumns.length; i++) {
      //   if (this.fiterSourceColumns[i].rcInputType === "O") {
      //     this.fiterSourceColumns.splice(i, 1);
      //   }
      // }
      setTimeout(function () {
        $(".pi-angle-up").parent().hide();
        $(".pi-angle-double-up").parent().hide();
        $(".pi-angle-down").parent().hide();
        $(".pi-angle-double-down").parent().hide();
      }, 10);

      if (this.action == "Edit") {
        for (let f = 0; f < this.targetColumns.length; f++) {
          this.sourceColumns.forEach((element, index) => {
            if (element.id.rcColumnName == this.targetColumns[f].id.rcColumnName) {
              this.sourceColumns.splice(index, 1);
            }
          });
        }

        for (let j = 0; j < this.filters()['controls'].length; j++) {
          this.setInputFieldType(j);
          this.setDateandAutosearchVal(j);
          this.setCndGrpdisable(j);
        }
      }

      this.gridLoading = false;
    }, error => {
      this.gridLoading = false;
    });

  }

  fetchAllViews() {
    this.reportService.fetchAllViews().subscribe(resp => {
      this.loaderService.isBusy = false;
      this.fetchAllViewResp = resp;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  resetSaveasModal() {
    this.reportInfoForm.reset();
  }

  openExisRepResp: any;
  openExistingReport() {
    this.gridLoading = true;
    this.reportService.openExistingReport(this.reportId).subscribe(resp => {
      this.openExisRepResp = resp;
      if (this.openExisRepResp) {
        for (let f = 0; f < resp["repFilter"].length; f++) {
          let condition = (this.filters()['controls'].length == 0) ? "" : "AND";
          this.filters().push(this.addExistingFilter(resp["repFilter"][f]));
        }

        for (let s = 0; s < resp["repSort"].length; s++) {
          this.sortBys().push(this.addExistingSort(resp["repSort"][s]));
        }
        this.targetColumns = resp["repColumns"];
        this.viewCode = {
          key: resp["urViewCode"],
          value: resp["urViewName"],
          desc: resp["urViewDesc"]
        };
        setTimeout(function () {
          $(".pi-angle-up").parent().hide();
          $(".pi-angle-double-up").parent().hide();
          $(".pi-angle-down").parent().hide();
          $(".pi-angle-double-down").parent().hide();
        }, 10);
        this.loadColumnsforReport();
      } else{
        this.toastService.warning("No Data available");
      }
    }, error => {
      this.gridLoading = false;
      this.toastService.error("Soming Wrong");
    });

  }

  addExistingFilter(repFilter: any): UntypedFormGroup {
    return this.fb.group({
      urpColumn: [repFilter["urpColumn"], Validators.required],
      urpCondition: repFilter["urpCondition"],
      urpDataType: "",
      urpCondGrp: repFilter["urpCondGrp"],
      urpOperator: repFilter["urpOperator"],
      urpValueFm: repFilter["urpValueFm"],
      urpValueTo: repFilter["urpValueTo"],
      urpFieldAttr: {
        "rcDataType": repFilter["rcDataType"],
        "rcInputType": repFilter["rcInputType"]
      },
      urpAutoSearch: {
        fmData: [],
        fmShowResult: false,
        fmNoDataFound: false,
        toData: [],
        toShowResult: false,
        toNoDataFound: false,
        selectedValue: {
          key: repFilter["urpValueFm"],
          value: repFilter["urpValueFmDesc"]
        },
        selectedValueTo: {
          key: repFilter["urpValueTo"],
          value: repFilter["urpValueToDesc"]
        }
      },
      multiselectShow: false,
      urpGenDrpDwnList: []
    });
  }

  addExistingSort(repSort: any): UntypedFormGroup {
    return this.fb.group({
      urpColumn: repSort["urpColumn"],
      urpCondition: repSort["urpCondition"],
      urpDataType: repSort["urpDataType"]
    });
  }

  fetchAllUserRepResp: any;
  fetchAllUserReportList() {
    this.reportService.fetchAllUserReportList().subscribe(resp => {
      this.loaderService.isBusy = false;
      this.fetchAllUserRepResp = resp;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  getOperators() {
    this.reportService.getAppCodes('ENQUIRY_OPER').subscribe(resp => {
      this.operators = resp;
    }, error => {
    });
  }

  getDataId(i) {
    let col = this.filters()['controls'][i].get('urpColumn').value;
    let dataId = '';
    for (let i = 0; i < this.fiterSourceColumns.length; i++) {
      if (this.fiterSourceColumns[i].id.rcColumnName == col) {
        dataId = this.fiterSourceColumns[i].rcDataId;
      }
    }
    return dataId;
  }
  getAutoList(i, type) {
    let search = this.filters().value[i].urpValueFm;
    // if (type === 'Fm') {
    //   search = this.filters().value[i].urpValueFm;
    // } else {
    //   search = this.filters().value[i].urpValueTo;
    // }
    if (search != "" && search.length >= 3) {
      let dataId = this.getDataId(i);
      $("#autosearch_" + type + "_" + i).addClass("Field");
      this.reportService.getDynamicColumnData(dataId, search).subscribe(resp => {
        if (type == "Fm") {
          this.getUrpAutoSearch(i).fmData = resp;
          this.getUrpAutoSearch(i).fmShowResult = true;
          this.getUrpAutoSearch(i).fmNoDataFound = (this.getUrpAutoSearch(i).fmData.length == 0) ? true : false;
        } else if (type == "To") {
          this.getUrpAutoSearch(i).toData = resp;
          this.getUrpAutoSearch(i).toShowResult = true;
          this.getUrpAutoSearch(i).toNoDataFound = (this.getUrpAutoSearch(i).toData.length == 0) ? true : false;
        }
        $("#autosearch_" + type + "_" + i).removeClass("Field");
      }, error => {
        $("#autosearch_" + type + "_" + i).removeClass("Field");
      });

    }
  }

  setAutoSearchVal(item, i, type) {
    if (type == "Fm") {
      this.getUrpAutoSearch(i).fmShowResult = false;
      this.getUrpAutoSearch(i).fmNoDataFound = false;
      this.filters()['controls'][i].patchValue({ urpValueFm: item.value });
      let fmauto = this.getUrpAutoSearch(i);
      fmauto["selectedValue"] = item;
    } else if (type == "To") {
      this.getUrpAutoSearch(i).toShowResult = false;
      this.getUrpAutoSearch(i).toNoDataFound = false;
      this.filters()['controls'][i].patchValue({ urpValueTo: item.value });
      let toauto = this.getUrpAutoSearch(i);
      toauto["selectedValueTo"] = item;
    }
    this.hideAutoList(i, type);
  }

  hideAutoList(i, type) {

    if (type == "Fm") {
      this.getUrpAutoSearch(i).fmShowResult = false;
      this.getUrpAutoSearch(i).fmData = [];
      this.getUrpAutoSearch(i).fmNoDataFound = false;
    } else if (type == "To") {
      this.getUrpAutoSearch(i).toShowResult = false;
      this.getUrpAutoSearch(i).toData = [];
      this.getUrpAutoSearch(i).toNoDataFound = false;
    }

  }

  hideSearchList(e) {
    if (e.target.id) {
      if (!$("#" + e.target.id).hasClass("Auto_List")) {
        return;
      } else {
        this.blurHideAutosearch();
      }
    } else {
      this.blurHideAutosearch();
    }
  }

  blurHideAutosearch() {
    for (let i = 0; i < this.filters().value.length; i++) {
      this.getUrpAutoSearch(i).fmNoDataFound = false;
      this.getUrpAutoSearch(i).fmShowResult = false;
      this.getUrpAutoSearch(i).toNoDataFound = false;
      this.getUrpAutoSearch(i).toShowResult = false;
    }
  }
  getMultiSelectList(list) {
    let str = "";
    if (list.length > 0) {
      for (let i = 0; i < list.length; i++) {

        str += list[i].key + ",";
      }
    }
    if (str.length != 0) {
      str = str.substring(0, str.length - 1);
    }
    return str;

  }
  setMultiselectList(str: string, list) {
    let tempArr = [];
    if (str != null && str != undefined && str != "") {
      let strSplit = str.split(",");
      let thisObj = this;
      strSplit.forEach(function (value) {
        for (let i = 0; i < list.length; i++) {
          if (list[i].key == value) {
            let obj = {
              key: list[i].key,
              value: list[i].value
            }
            tempArr.push(obj);
          }
        }
      });
    }
    return tempArr;
  }

  onItemSelect(item: any) { }
  onSelectAll(items: any) {
  }
  onItemDeSelect(items: any) {
  }
  refreshPage() {
    window.location.reload();
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
  }
}
