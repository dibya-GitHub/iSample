import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddEditReportComponent } from './components/add-edit-report/add-edit-report.component';
import { DynamicReportComponent } from './components/dynamic-report/dynamic-report.component';
import { ReportComponent } from './components/report/report.component';

const routes: Routes = [
  {
    path: '',
    component: ReportComponent,
  },
  {
    path: 'dynamic-report',
    component: DynamicReportComponent,
    data: {
      breadcrumb: { skip: true }
    }
  },
  {
    path: 'add-report',
    component: AddEditReportComponent,
    data: {
      breadcrumb: { skip: true }
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SmartReportRoutingModule { }
