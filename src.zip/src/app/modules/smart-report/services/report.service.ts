import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  path = environment.commonBaseUrl;
  transactionPath = environment.mgaUrl;

  constructor(
    private httpClient: HttpClient
  ) { }

  addProceedClk = new Subject<any>();
  dynRepOpenClk = new Subject<any>();

  getaddProceedClk() {
    return this.addProceedClk.asObservable();
  }

  setaddProceedClk(data) {
    this.addProceedClk.next(data);
  }

  getdynRepOpenClk() {
    return this.dynRepOpenClk.asObservable();
  }

  setdynRepOpenClk(data) {
    this.dynRepOpenClk.next(data);
  }

  fetchAllReport() {
    return this.httpClient.get(this.transactionPath + 'reports/user-reports');
  }

  getViewDropdown() {
    return this.httpClient.get(this.transactionPath + 'reports/views');
  }

  //Run Dynamic Report With and  Without Params(Columns)
  runDynRepWithandWithoutParamsCol(reqData) {
    return this.httpClient.post(this.transactionPath + "reports/user-reports/run/columns", reqData);
  }

  //Run Dynamic Report With and Without Params(Data)
  runDynRepWithandWithoutParamsData(reqData) {
    return this.httpClient.post(this.transactionPath + "reports/user-reports/run/data", reqData);
  }

  //Run Dynamic Report With Params(Columns)
  // runDynamicReportWithParamsColumns(reqData){
  //   return this.httpClient.post(this.transactionPath + "reports/user-reports/run/params/columns",reqData);
  // }

  //Run Dynamic Report With Params(Data)
  // runDynamicReportWithParamsData(reqData){
  //   return this.httpClient.post(this.transactionPath + "reports/user-reports/run/params/data",reqData);
  // }

  //Run Saved Report Without Params(Columns)
  runSavedReportWithandWithoutParamsColumns(reportId) {
    return this.httpClient.get(this.transactionPath + "reports/user-reports/" + reportId + "/run/columns");
  }

  //Run Saved Report Without Params(Data)
  runSavedReportWithandWithoutParamsData(reportId) {
    return this.httpClient.get(this.transactionPath + "reports/user-reports/" + reportId + "/run/data");
  }

  // //Run Saved Report With Params(Columns)
  // runSavedReportWithParamsColumns(reportId){
  //   return this.httpClient.get(this.transactionPath + "reports/user-reports/"+ reportId + "/run/params/columns");
  // }

  // //Run Saved Report With Params(Data)
  // runSavedReportWithParamsData(reportId){
  //   return this.httpClient.get(this.transactionPath + "reports/user-reports/" + reportId + "/run/params/data");
  // }

  //Load Columns for Report
  loadColumnsforReport(view) {
    return this.httpClient.get(this.transactionPath + "reports/view-columns/" + view);
  }

  //Fetch all views
  fetchAllViews() {
    return this.httpClient.get(this.transactionPath + "reports/views");
  }

  //Save Report 
  saveReport(reqData) {
    return this.httpClient.post(this.transactionPath + "reports/user-report-params", reqData);
  }

  //Open Existing Report
  openExistingReport(reportId) {
    return this.httpClient.get(this.transactionPath + "reports/user-report-params/" + reportId);
  }

  //Update Report
  updateReport(reportId, reqData) {
    return this.httpClient.put(this.transactionPath + "reports/user-report-params/" + reportId, reqData);
  }

  //Fetch all user report list
  fetchAllUserReportList() {
    return this.httpClient.get(this.transactionPath + "reports/user-reports");
  }

  getAppCodes(type) {
    return this.httpClient.get(this.path + 'appcodes-mgmt/appcodes/' + type);
  }

  getDynamicColumnData(dataId, search) {
    return this.httpClient.get(this.transactionPath + 'reports/column-data/' + dataId + '?search=' + search);
  }
}
