import { SmartReportModule } from './smart-report.module';

describe('SmartReportModule', () => {
  let smartReportModule: SmartReportModule;

  beforeEach(() => {
    smartReportModule = new SmartReportModule();
  });

  it('should create an instance', () => {
    expect(smartReportModule).toBeTruthy();
  });
});
