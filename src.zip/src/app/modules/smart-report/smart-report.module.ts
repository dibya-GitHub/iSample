import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { AccordionModule } from 'primeng/accordion';
import { DropdownModule } from 'primeng/dropdown';
import { PickListModule } from 'primeng/picklist';
import { SharedModule } from 'src/shared/shared.module';
import { AddEditReportComponent } from './components/add-edit-report/add-edit-report.component';
import { DynamicReportComponent } from './components/dynamic-report/dynamic-report.component';
import { ReportComponent } from './components/report/report.component';
import { SmartReportRoutingModule } from './smart-report-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SmartReportRoutingModule,
    SharedModule,
    AccordionModule,
    PickListModule,
    DropdownModule
  ],
  declarations: [ReportComponent, DynamicReportComponent, AddEditReportComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartReportModule { }
