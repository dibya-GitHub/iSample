import { Component, Input } from '@angular/core';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { CustomPinnedRowRenderer } from './custom-pinned-row-renderer.component';

@Component({
  selector: 'app-aad-total',
  templateUrl: './aad-total.component.html',
  styleUrls: ['./aad-total.component.scss']
})
export class AadTotalComponent {

  public defaultColDef;
  colDefs: any[];
  banks: any[];
  gridApi: any;
  gridColumnApi: any;
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  quickSearchValue: string;
  pinnedBottomRowData: any;
  public frameworkComponents;
  @Input() aadGridData: any[];
  @Input() aadObj: Object;

  constructor(
    private loaderService: LoaderService,

  ) {

    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
      lockPosition: true
    };
  }
  ngOnInit() {
    this.loaderService.isBusy = true;
    this.colDefs = [
      {
        field: 'recRef',
        headerName: 'Recovery Ref'
      },
      {
        field: 'transClaimNo',
        headerName: 'Claim No'
      },
      {
        field: 'transEvent',
        headerName: 'Event',
        valueFormatter: nullFormatter,
        pinnedRowCellRenderer: "customPinnedRowRenderer",
        pinnedRowCellRendererParams: { style: { color: "blue", "font-weight": "bold" } }
      },
      {
        field: 'tlAad',
        headerName: 'AAD Deducted',
        valueFormatter: currencyFormatter,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data.tlAad != "null") {
            console.log(params.data)
            return params.data.tlAad;
          } else {
            return '';
          }
        },
      }
    ];
    this.frameworkComponents = { customPinnedRowRenderer: CustomPinnedRowRenderer };
    this.loaderService.isBusy = false;
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    if (this.aadGridData && this.aadObj) {
      this.pinnedBottomRowData = createData(1, this.aadGridData, "Bottom", this.aadObj);
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  public onRowClicked(e) {

  }
}
function currencyFormatter(params) {
  if (params != null) {
    return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else { return '' }
}
function nullFormatter(params) {
  if (params.value != "null") {
    return params.value;
  } else { return '' }
}
function createData(count, data, prefix, aadObj) {
  var result = [];
  var sum = 0;
  for (var i = 0; i < data.length; i++) {
    sum = sum + data[i].tlAad;
  }
  for (var i = 0; i < count; i++) {
    result.push({
      transEvent: 'Total AAD Deducted',
      tlAad: sum
    },
      {
        transEvent: 'AAD Balance available',
        tlAad: aadObj.tlAad - sum
      });
  }
  return result;
}