import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppCodesService } from '../../services/app-codes.service';

@Component({
   selector: 'app-currency-grid',
   templateUrl: './currency-grid.component.html',
   styleUrls: ['./currency-grid.component.scss']
})

export class CurrencyGridComponent implements OnInit {

   defaultColDef: any;
   colDefs: any[];
   currencyData: any[];
   gridApi: any;
   gridColumnApi: any;
   showEntriesOptions = [10, 20, 50, 100];
   showEntriesOptionSelected = 10;
   quickSearchValue: string;

   constructor(
      private router: Router,
      private appCodesService: AppCodesService,
      private toastService: ToastService,
      private loaderService: LoaderService
   ) {
      this.defaultColDef = {
         resizable: true,
         sortable: true,
         filter: true,
         enableRowGroup: true,
      };
   }

   ngOnInit() {
      this.loaderService.isBusy = true;
      this.colDefs = [
         {
            field: 'currCode',
            headerName: 'Currency',
         },
         {
            field: 'currName',
            headerName: 'Currency Name',
         },
         {
            field: 'currShortName',
            headerName: 'ShortName',
         },
         {
            field: 'currUnitName',
            headerName: 'Unit Name',
         },
         {
            field: 'currFreezYn',
            headerName: 'Freeze YN',
         },
         {
            field: 'currFreezDt',
            headerName: 'Freeze Date',
         },
         {
            field: 'currCode',
            headerName: 'Action',
            cellRenderer: actionRender,
            filter: false,
            sortable: false,
            enableRowGroup: false,
            cellStyle: { textAlign: 'center' },
         }
      ];
      this.retriveData();
   }

   onGridReady(params) {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
      this.gridApi.sizeColumnsToFit();
   }
   onQuickFilterChanged() {
      this.gridApi.setQuickFilter(this.quickSearchValue);
   }
   onFirstDataRendered(params) {
      params.api.sizeColumnsToFit();
   }
   displayedRowCount() {
      if (this.gridApi) {
         return this.gridApi.getDisplayedRowCount();
      } else {
         return;
      }
   }
   retriveData() {
      this.appCodesService.retrieveCurrencyDetails().subscribe(resp => {
         if (resp) {
            this.currencyData = resp.map(curr => {
               curr.currFreezYn = (curr.currFreezYn === '1') ? 'Y' : 'N';
               curr.currFreezDt = (curr.currFreezDt) ? moment(curr.currFreezDt).format('DD/MM/YYYY') : undefined;
               return curr;
            });
         }
         this.loaderService.isBusy = false;
      }, error => {
         this.loaderService.isBusy = false;
         this.toastService.error('Error in Retrive Data');
      });
   }

   public onRowClicked(e) {
      if (e.event.target !== undefined) {
         const data = e.data;
         const actionType = e.event.target.getAttribute('data-action-type');
         switch (actionType) {
            case 'Edit':
               return this.navigateToForm(data);
            case 'Delete':
               return this.deleteCurrency(data);
         }
      }
   }
   deleteCurrency(data: any) {

   }

   navigateToForm(data) {
      if (data) {
         this.router.navigate(['/appCodes/appCurrency/edit'], { queryParams: { code: data.currCode } });
      } else {
         this.router.navigate(['/appCodes/appCurrency/add']);
      }
   }
   pageChanged(event: any): void {
      this.gridApi.paginationGoToPage(event.page - 1);
   }
   onPaginationCountChange(event: any) {
      this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
      this.gridApi.paginationGoToPage(0);
   }
   back() {
      this.router.navigate(['master/admindashboard'], { queryParams: { title: 'Home' } });
   }
}
function actionRender(params) {
   if (params.value === undefined || params.value === null) {
      return '';
   } else {
      return `<a>
     <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true"></i>
     </a>`;
   }
}
