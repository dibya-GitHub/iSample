import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppCodesService } from '../../services/app-codes.service';

@Component({
   selector: 'app-bank-grid',
   templateUrl: './bank-grid.component.html',
   styleUrls: ['./bank-grid.component.scss']
})

export class BankGridComponent implements OnInit {
   public defaultColDef;
   colDefs: any[];
   banks: any[];
   gridApi: any;
   gridColumnApi: any;
   showEntriesOptions = [10, 20, 50, 100];
   showEntriesOptionSelected = 10;
   quickSearchValue: string;

   constructor(
      private router: Router,
      private appCodesService: AppCodesService,
      private toastService: ToastService,
      private loaderService: LoaderService
   ) {
      this.loaderService.isBusy = true;
      this.defaultColDef = {
         resizable: true,
         sortable: true,
         filter: true,
         enableRowGroup: true,
      };
   }

   ngOnInit() {
      this.colDefs = [
         {
            field: 'bankCode',
            headerName: 'Bank Code'
         },
         {
            field: 'bankName',
            headerName: 'Bank Name'
         },
         {
            field: 'bankShortName',
            headerName: 'Short Name'
         },
         {
            field: 'bankAddr01',
            headerName: 'Address'
         },
         {
            field: 'bankContPerName',
            headerName: 'Cont. Person'
         },
         {
            field: 'bankContPerPhNo',
            headerName: 'Cont. Per. Phone No'
         },
         {
            field: 'bankContPerEmail',
            headerName: 'Cont. Per. Email'
         },
         {
            field: 'bankCode',
            headerName: 'Action',
            cellRenderer: actionRender,
            filter: false,
            sortable: false,
            enableRowGroup: false,
            cellStyle: { textAlign: 'center' },
         }
      ];
      this.retriveData();
   }

   onGridReady(params) {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
      this.gridApi.sizeColumnsToFit();
   }
   onQuickFilterChanged() {
      this.gridApi.setQuickFilter(this.quickSearchValue);
   }

   displayedRowCount() {
      if (this.gridApi) {
         return this.gridApi.getDisplayedRowCount();
      } else {
         return;
      }
   }

   retriveData() {
      this.appCodesService.retrieveBankDetails().subscribe(resp => {
         if (resp) {
            this.banks = resp.bankArray;
         }
         this.loaderService.isBusy = false;
      }, error => {
         this.loaderService.isBusy = false;
         this.toastService.error('Error in Retrive Data');
      });
   }

   onRowClicked(e) {
      if (e.event.target !== undefined) {
         const data = e.data;
         const actionType = e.event.target.getAttribute('data-action-type');
         switch (actionType) {
            case 'Edit':
               return this.navigateToForm(data);
            case 'Delete':
               return this.deleteCurrency(data);
         }
      }
   }
   deleteCurrency(data: any) {

   }

   navigateToForm(data) {
      if (data) {
         this.router.navigate(['/appCodes/bank/edit'], { queryParams: { code: data.bankCode }, skipLocationChange: true });
      } else {
         this.router.navigate(['/appCodes/bank/add']);
      }
   }

   pageChanged(event: any): void {
      this.gridApi.paginationGoToPage(event.page - 1);
   }
   onFirstDataRendered(params) {
      params.api.sizeColumnsToFit();
   }
   onPaginationCountChange(event: any) {
      this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
      this.gridApi.paginationGoToPage(0);
   }

   back() {
      this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
   }
}
function actionRender(params) {
   if (params.value === undefined || params.value === null) {
      return '';
   } else {
      return `<a>
         <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true"></i>
      </a>`;
   }
}
