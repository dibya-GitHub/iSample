import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppCodesService } from '../../services/app-codes.service';

@Component({
  selector: 'app-all-app-codes',
  templateUrl: './all-app-codes.component.html',
  styleUrls: ['./all-app-codes.component.scss']
})
export class AllAppCodesComponent implements OnInit {

  public defaultColDef;
  user: any;
  appCodes: any;
  appCodesDetails: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';

  constructor(
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private appCodesServices: AppCodesService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.user = this.session.get('userId');
    this.appCodes = [
      {
        field: 'code',
        headerName: 'Code',
        tooltipField: 'code',

      },
      {
        field: 'description',
        headerName: 'Description',
        tooltipField: 'description',

      },
      {
        field: 'masterCode',
        headerName: 'MasterCode',
        tooltipField: 'masterCode',

      },
      {
        field: 'value',
        headerName: 'Value',
        tooltipField: 'value',
        resizable: true
      },
    ];
    this.retrieveAllAppCodes();
  }

  retrieveAllAppCodes() {
    this.appCodesServices.retrieveAllAppCodes().subscribe(resp => {
      this.appCodesDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any,) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

}
