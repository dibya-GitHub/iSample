import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllAppCodesComponent } from './all-app-codes.component';

describe('AllAppCodesComponent', () => {
  let component: AllAppCodesComponent;
  let fixture: ComponentFixture<AllAppCodesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllAppCodesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllAppCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
