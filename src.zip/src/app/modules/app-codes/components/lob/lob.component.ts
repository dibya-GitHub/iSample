import { Router } from '@angular/router';
import { UntypedFormGroup, Validators, UntypedFormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppCodesService } from '../../services/app-codes.service';
import * as moment from 'moment';
import { Utils } from 'src/app/utils';

@Component({
  selector: 'app-lob',
  templateUrl: './lob.component.html',
  styleUrls: ['./lob.component.scss']
})
export class LobComponent implements OnInit {


  public defaultColDef;
  user: any;
  appCodes: any;
  lobDetails: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';
  lobForm: UntypedFormGroup;

  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private appCodesServices: AppCodesService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }
  showForm: boolean = false;
  AddFlag;
  action: string = '';
  ngOnInit() {
    this.loaderService.isBusy = true;
    this.user = this.session.get('userId');
    this.appCodes = [
      {
        field: 'lobCodeDesc',
        headerName: 'Line of business',
        tooltipField: 'lobCodeDesc',
      },
      {
        field: 'lobDesc',
        headerName: 'Description',
        tooltipField: 'lobDesc',
      },
      {
        field: 'lobEffFmDt',
        headerName: 'Effective From',
        // cellRenderer: 'strtDateCellRenderer'
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.lobEffFmDt) {
            let startDate = moment(params.data.lobEffFmDt).format('DD/MM/YYYY');
            return startDate;
          } else {
            return '';
          }
        },
      },
      {
        field: 'lobEffToDt',
        headerName: 'Effective To',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.lobEffToDt) {
            let startDate = moment(params.data.lobEffToDt).format('DD/MM/YYYY');
            return startDate;
          } else {
            return '';
          }
        },
      },
      {
        field: 'lobShortDesc',
        headerName: 'Short Description',
        tooltipField: 'lobShortDesc',
      },
      {
        field: 'lobCodeDesc',
        headerName: 'Action',
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      }
    ];
    this.getLobData();
    this.createForm();

  }
  createForm() {
    this.lobForm = this.fb.group({
      lobCodeDesc: [''],
      lobCrDt: [''],
      lobCrUid: [''],
      lobDesc: ['', Validators.required],
      lobDescBl: [''],
      lobEffFmDt: ['', Validators.required],
      lobEffToDt: ['', Validators.required],
      lobShortDesc: ['', Validators.required],
      lobUpdUid: [''],
      lobUpddt: [''],
      lobUrl: [''],
      lobCode: ['', Validators.required]
    });
  }
  addLob() {
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'add';
  }
  cancel() {
    this.showForm = false;
    this.AddFlag = true;
    this.lobForm.reset();
  }
  saveLobForm() {
    if (this.lobForm.valid) {
      this.loaderService.isBusy = true;
      let lobData = this.lobForm.value;
      lobData.lobEffFmDt = moment(this.lobForm.get('lobEffFmDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      lobData.lobEffToDt = moment(this.lobForm.get('lobEffToDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      lobData.lobUpdUid = this.session.get('userId');
      lobData.lobUpddt = new Date();
      lobData.productSetupLobPK = {
        lobCode: this.lobForm.get('lobCode').value
      };
      if ('edit' === this.action) {
        this.appCodesServices.updateLobData(lobData).subscribe(res => {
          this.toastService.success('Updated Successfully');
          this.showForm = false;
          this.getLobData();
          this.loaderService.isBusy = false;
          this.lobForm.reset();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        lobData.lobCrDt = new Date();
        lobData.lobCrUid = this.session.get('userId');
        this.appCodesServices.addLobData(lobData).subscribe(res => {
          this.toastService.success('Added Successfully');
          this.showForm = false;
          this.getLobData();
          this.lobForm.reset();
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      }
    } else {
      Utils.validateAllFormFields(this.lobForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  editLob(data) {
    this.action = 'edit';
    this.showForm = true;
    this.lobForm.patchValue({
      lobCodeDesc: data.lobCodeDesc,
      lobDesc: data.lobDesc,
      lobCode: data.productSetupLobPK.lobCode,
      lobUrl: data.lobUrl,
      lobShortDesc: data.lobShortDesc,
      lobUpdUid: data.lobUpdUid,
      lobDescBl: data.lobDescBl,
      lobCrUid: data.lobCrUid,
      lobEffFmDt: moment(data.lobEffFmDt).toDate(),
      lobEffToDt: moment(data.lobEffToDt).toDate(),
    });
  }

  getLobData() {
    this.appCodesServices.getlobData().subscribe(resp => {
      this.lobDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'Edit':
          return this.editLob(data);
      }
    }
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any,) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
        <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true"></i>
     </a>`;
  }
}
