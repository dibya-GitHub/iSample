import { Component, OnInit, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppCodesService } from '../../services/app-codes.service';
@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.scss']
})

export class CountryComponent implements OnInit {
  public defaultColDef;
  titleName: string;
  cityDetails: any;
  stateDetails: any;
  type: string;
  action: string;
  details: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  countryShowEntriesOptionSelected = 10;
  stateShowEntriesOptionSelected = 10;
  cityShowEntriesOptionSelected = 10;
  countryQuickSearchValue: any;
  stateQuickSearchValue: any;
  cityQuickSearchValue: any;
  public countryGridApi;
  public stateGridApi;
  public cityGridApi;
  countryColumns: any;
  stateColumns: any;
  cityColumns: any;
  showForm: boolean;
  showCountryForm: boolean;
  showState: boolean;
  showStateForm: boolean;
  addStateBtn: boolean;
  showCity: boolean;
  showCityForm: boolean;
  addCityBtn: boolean;
  appCodeForm: UntypedFormGroup;
  // modelRef: any;
  selectedCountry: any;
  selectedState: any;
  heading: string;
  @ViewChild('formTemplate') formTemplate;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private appCodesServices: AppCodesService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,
    private authService: AuthService

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.countryColumns = [
      {
        field: 'acCode',
        headerName: 'Country Code',
      },
      {
        field: 'acDesc',
        headerName: 'Name',
      },
      {
        headerName: 'Action',
        field: 'acCode',
        cellRenderer: countryColumnsActionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
        width: 70,
      }
    ];
    this.stateColumns = [
      {
        field: 'acCode',
        headerName: 'State Code'
      },
      {
        field: 'acDesc',
        headerName: 'Name'
      },
      {
        field: 'acCode',
        headerName: 'Action',
        cellRenderer: stateColumnsActionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      }
    ];
    this.cityColumns = [
      {
        field: 'acCode',
        headerName: 'City Code'
      },
      {
        field: 'acDesc',
        headerName: 'Name'
      },
      {
        field: 'acCode',
        headerName: 'Action',
        cellRenderer: cityColumnsActionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
        width: 75
      }
    ];
    this.retrieveCountry();
    this.createAppCodeForm();
  }

  createAppCodeForm() {
    this.appCodeForm = this.fb.group({
      acInstId: this.authService.getInstanceCode(),
      acCode: ['', Validators.required],
      acType: 'COUNTRY',
      acValue: '',
      acMcCode: '',
      acMastDefCode: '',
      acDesc: ['', Validators.required],
      acDescBl: '',
      acShortDesc: '',
      acShortDescBl: '',
      acLongDesc: '',
      acLongDescBl: '',
      acCodeByLobYn: '1',
      acLobCode: '',
      acApplCompCode: '',
      acEffFmDt: '',
      acEffToDt: '',
      acCrUid: this.session.get('userId'),
      acCrDt: new Date(),
      acUpdUid: '',
      acUpdDt: ''
    });
  }

  retrieveCountry() {
    this.appCodesServices.retrieveAppCodesByType('COUNTRY').subscribe(resp => {
      this.details = resp;
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error('Error while fetching Country List');
    });
  }

  addDetails(title) {
    if (title == 'Country') {
      this.showForm = true;
      this.showCountryForm = true;
      this.showState = false;
      this.showCity = false;
      this.appCodeForm['controls']['acCode'].enable();

    } else if (title == 'State') {
      this.showForm = false;
      this.showState = true;
      this.showStateForm = true;
      this.showCity = false;
      this.addStateBtn = false;
      this.appCodeForm['controls']['acCode'].enable();

    } else if (title == 'City') {
      this.showForm = false;
      this.showState = false;
      this.showCity = true;
      this.showState = true;
      this.showStateForm = false;
      this.showCityForm = true;
      this.addCityBtn = false;
      this.appCodeForm['controls']['acCode'].enable();
    }
    this.titleName = title;
    this.action = 'add';
    this.openForm('Add', this.titleName);
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
  cancel(title) {
    if (title == 'Country') {
      this.showCountryForm = false;
      this.showForm = false;
      this.showState = false;
      this.showCity = false;
      this.addStateBtn = false;
      this.addCityBtn = false;
    } else if (title == 'State') {
      this.showForm = false;
      this.showStateForm = false;
      this.showCity = false;
      this.addStateBtn = true;
      this.addCityBtn = false;
    } else if (title == 'City') {
      this.showCountryForm = false;
      this.showForm = false;
      this.showState = true;
      this.showCity = true;
      this.addCityBtn = true;
      this.showCityForm = false;
    }
  }

  openForm(action, formName) {
    switch (formName) {
      case 'Country': {
        this.heading = action + ' ' + formName;
        break;
      }
      case 'State': {
        this.heading = action + ' ' + formName + ' in ' + this.selectedCountry;
        break;
      }
      case 'City': {
        this.heading = action + ' ' + formName + ' in ' + this.selectedState + ', ' + this.selectedCountry;
        break;
      }
    }
    this.appCodeForm.reset();
    // this.modelRef = this.modelService.show(this.formTemplate);
  }

  closeForm() {
    this.action = null;
  }

  save(type) {
    this.loaderService.isBusy = true;
    this.appCodeForm.get('acCode').enable();
    if (this.appCodeForm.valid) {
      if ('edit' == this.action) {
        this.appCodesServices.updateAppCodes(this.appCodeForm.value, this.appCodeForm.get('acCode').value).subscribe(result => {
          if (type === 'Country') {
            this.showCountryForm = false;
            this.retrieveCountry();
          } else if (type === 'State') {
            this.showStateForm = false;
            this.appCodesServices.retrieveByCode(this.appCodeForm.get('acMcCode').value).subscribe(resp => {
              this.stateDetails = resp;
            }, error => {
            });
          } else if (type === 'City') {
            this.showCityForm = false;
            this.addCityBtn = true;
            this.appCodesServices.retrieveZoneByStateCode(this.appCodeForm.get('acMcCode').value).subscribe(resp => {
              this.cityDetails = resp;
            }, error => {
            });
          }
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.statusText);
        });
      } else {
        if (type === 'Country') {
          this.appCodeForm.patchValue({
            acType: 'COUNTRY',
            acInstId: this.authService.getInstanceCode(),
          })
        } else if (type === 'State') {
          this.appCodeForm.patchValue({
            acType: 'State',
            acInstId: this.authService.getInstanceCode(),
          })
          this.showStateForm = false
        } else if (type === 'City') {
          this.appCodeForm.patchValue({
            acType: 'City',
            acInstId: this.authService.getInstanceCode(),
          })
          this.showCity = false
        }
        this.appCodesServices.insertAppCodes(this.appCodeForm.value).subscribe(result => {
          // this.back();
          this.retrieveCountry();
          this.showCity = false;
          this.showState = false;
          this.loaderService.isBusy = false;

        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.statusText);
        });
      }
    } else {
      this.validateAllFormFields(this.appCodeForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;

    }
  }
  edit(data, formName) {
    this.action = 'edit';
    this.openForm('Edit', formName);
    if (formName == 'Country') {
      this.appCodeForm['controls']['acCode'].disable();
      this.showForm = true;
      this.showCountryForm = true;
      this.showState = false;
      this.showCity = false;
      this.showStateForm = false;
      this.addStateBtn = false;
      this.addCityBtn = false;
    } else if (formName == 'State') {
      this.appCodeForm['controls']['acCode'].disable();
      this.showForm = false;
      this.showState = true;
      this.showStateForm = true;
      this.addStateBtn = false;
      this.showCity = false;
      this.addCityBtn = false;
    } else if (formName == 'City') {
      this.appCodeForm['controls']['acCode'].disable();
      this.showForm = false;
      this.showState = true;
      this.showCity = true;
      this.addCityBtn = false;
      this.showCityForm = true;
    }
    this.appCodeForm.patchValue({
      acInstId: this.authService.getInstanceCode(),
      acCode: data.acCode,
      acType: data.acType,
      acValue: data.acValue,
      acMcCode: data.acMcCode,
      acMastDefCode: data.acMastDefCode,
      acDesc: data.acDesc,
      acDescBl: data.acDescBl,
      acShortDesc: data.acShortDesc,
      acShortDescBl: data.acShortDescBl,
      acLongDesc: data.acLongDesc,
      acLongDescBl: data.acLongDescBl,
      acCodeByLobYn: data.acCodeByLobYn,
      acLobCode: data.acLobCode,
      acApplCompCode: data.acApplCompCode,
      acEffFmDt: data.acEffFmDt,
      acEffToDt: data.acEffToDt,
      acCrUid: data.acCrUid,
      acCrDt: data.acCrDt,
      acUpdUid: this.session.get('userId'),
      acUpdDt: new Date()
    });
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  public onRowClicked(e) {
    this.titleName = 'COuntry';
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'Edit':
          return this.edit(data, 'Country');
        case 'View':
          return this.showStateGrid(data);
      }
    }
  }
  public onStateRowClicked(e) {
    this.titleName = 'State';
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'Edit':
          return this.edit(data, 'State');
        case 'View':
          return this.showLocationGrid(data);
      }
    }
  }
  public onCityRowClicked(e) {
    this.titleName = 'City';
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'Edit':
          return this.edit(data, 'City');
      }
    }
  }
  showLocationGrid(data) {
    this.appCodeForm.patchValue({
      acType: 'LOCATION',
      acMcCode: data.acCode,
      acMastDefCode: 'STATE'
    });
    this.selectedState = data.acDesc;
    this.addStateBtn = true;
    this.showForm = false;
    this.showState = true;
    this.showStateForm = false;
    this.showCity = true;
    this.showCityForm = false;
    this.addCityBtn = true;
    this.appCodesServices.retrieveZoneByStateCode(data.acCode).subscribe(resp => {
      this.cityDetails = resp;
    }, error => {
    });

  }

  showStateGrid(data) {
    this.appCodeForm.patchValue({
      acType: 'STATE',
      acMcCode: data.acCode,
      acMastDefCode: 'COUNTRY'
    });
    this.selectedCountry = data.acDesc;
    this.showForm = false;
    this.showState = true;
    this.addStateBtn = true;
    this.showStateForm = false;
    this.showCity = false;

    this.appCodesServices.retrieveByCode(data.acCode).subscribe(resp => {
      this.stateDetails = resp;
    }, error => {
    });
  }
  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    gridApi.setQuickFilter(qickSearch);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
  }

  onGridReady(params, gridName) {
    if (gridName === 'country') {
      this.countryGridApi = params.api;
    } else if (gridName === 'state') {
      this.stateGridApi = params.api;
    } else if (gridName === 'city') {
      this.cityGridApi = params.api;
    }
    params.api.sizeColumnsToFit();
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('nationalitytable').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  displayedRowCount(gridApi: any) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
}
function countryColumnsActionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class='fa fa-file-pen fa-icon'  data-action-type='Edit' title='Edit' aria-hidden='true'></i>
    </a>&nbsp;
    <a>
    <i class='fa fa-eye fa-icon'  data-action-type='View' title='View State' aria-hidden='true'></i>
    </a>`;
  }
}
function stateColumnsActionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class='fa fa-file-pen fa-icon'  data-action-type='Edit' title='Edit' aria-hidden='true'></i>
    </a>&nbsp;
    <a>
    <i class='fa fa-eye fa-icon'  data-action-type='View' title='View City' aria-hidden='true'></i>
    </a>`;
  }
}
function cityColumnsActionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class='fa fa-file-pen fa-icon' data-action-type='Edit' title='Edit' aria-hidden='true'></i>
    </a>`;
  }
}
