import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { GlobalService } from 'src/app/shared/services/global.service';
import { AppCodesService } from '../../services/app-codes.service';

@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.scss']
})

export class BankComponent implements OnInit {

  path: any;
  bankCode: any;
  action: any;
  type: any;
  editFlag: boolean;
  bankMasterForm: UntypedFormGroup;
  countryList: any[];
  cityList: any[];
  @ViewChild('trigger') tr: ElementRef;
  isEdit: boolean;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private appCodeService: AppCodesService,
    private commonService: GlobalService,
    private toastService: ToastService,
    private activeRoute: ActivatedRoute,
    private loaderService: LoaderService,
    private session: SessionStorageService
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.activeRoute.queryParams.subscribe(
      (params: any) => {
        if (params) {
          this.bankCode = params.code;
          if (this.bankCode) {
            this.isEdit = true;
            this.edit();
          }
        }
      }
    );
    this.createbankMasterForm();
    this.getCountryList();
  }

  createbankMasterForm() {
    this.bankMasterForm = this.fb.group({
      bankCode: ['', Validators.required],
      bankName: ['', Validators.required],
      bankShortName: '',
      bankAddr01: ['', Validators.required],
      bankAddr02: '',
      bankAddr03: '',
      bankPoBoxNo: '',
      bankCountry: undefined,
      bankCity: undefined,
      bankPhoneNo: '',
      bankFaxNo: '',
      bankEmail: ['', Validators.email],
      bankWebsite: '',
      bankLogo: '',
      bankContPerName: '',
      bankContPerPhNo: '',
      bankContPerEmail: ['', Validators.email],
      bankCrUid: this.session.get('userId'),
      bankCrDt: new Date(),
      bankUpdUid: '',
      bankUpdDt: ''
    });
    this.loaderService.isBusy = false;
  }

  getCountryList() {
    this.commonService.retrieveAppCodesByType(ApiUrls.APPCODE_CONTROLLER_PATH, ApiUrls.COUNTRY).subscribe(resp => {
      this.countryList = resp;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error('Error while fetching Country List');

    });
  }
  getCityList(event) {
    this.commonService.retrieveCityByCountryCode(ApiUrls.APPCODE_CONTROLLER_PATH, event.value).subscribe(resp => {
      this.cityList = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error('Error while fetching City List');
    });
  }

  save() {
    this.loaderService.isBusy = true;
    if (this.bankMasterForm.valid) {
      if (!this.isEdit) {
        this.loaderService.isBusy = true;
        this.appCodeService.insertBankDetails(this.bankMasterForm.value).subscribe(resp => {
          this.toastService.success('Saved Successfully.');
          //this.toastService.add({ severity: 'success', summary: 'Saved Successfully.', detail: '' });
          this.loaderService.isBusy = false;
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);

        });
      } else {
        this.loaderService.isBusy = true;
        this.appCodeService.updateBankDetails(this.bankMasterForm.value).subscribe(resp => {
          this.loaderService.isBusy = false;
          this.toastService.success('Updated Successfully.');
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        });
      }
    } else {
      this.validateAllFormFields(this.bankMasterForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  edit() {
    this.loaderService.isBusy = true;
    this.editFlag = true;
    const obj = { 'bankCode': this.bankCode };
    this.appCodeService.retrieveBankById(obj).subscribe(resp => {
      const result = resp.bankArray;
      this.bankMasterForm.patchValue({
        bankCode: result.bankCode,
        bankName: result.bankName,
        bankShortName: result.bankShortName,
        bankAddr01: result.bankAddr01,
        bankAddr02: result.bankAddr02,
        bankAddr03: result.bankAddr03,
        bankPoBoxNo: result.bankPoBoxNo,
        bankCountry: result.bankCountry,
        bankCity: result.bankCity,
        bankPhoneNo: result.bankPhoneNo,
        bankFaxNo: result.bankFaxNo,
        bankEmail: result.bankEmail,
        bankWebsite: result.bankWebsite,
        bankLogo: result.bankLogo,
        bankContPerName: result.bankContPerName,
        bankContPerPhNo: result.bankContPerPhNo,
        bankContPerEmail: result.bankContPerEmail,
        bankCrUid: result.bankCrUid,
        bankCrDt: result.bankCrDt,
        bankUpdUid: this.session.get('userId'),
        bankUpdDt: new Date()
      });
      const event = { target: { value: result.bankCountry } };
      this.loaderService.isBusy = false;
      this.getCityList(event);
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    });
  }
  back() {
    this.router.navigate(['/appCodes/bank'], { queryParams: { 'flag': true, 'title': 'Bank' } });
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    window.scrollTo(0, 0);
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

}
