import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppCodesService } from '../../services/app-codes.service';

@Component({
  selector: 'app-currency',
  templateUrl: './app-currency.component.html',
  styleUrls: ['./app-currency.component.scss']
})
export class AppCurrencyComponent implements OnInit {
  FlagYN: boolean;
  buttonName: string;
  title: any;
  errormsg: any;
  currCode: any;
  userId: any;
  param: any;
  CurrencyList: any = [];
  freezeFlag: boolean;
  togglebtn = '0';
  currencyForm: UntypedFormGroup;
  userid: any;
  path: string;
  currDecimals = [1, 2, 3];
  isEdit: boolean;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private session: SessionStorageService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private appCodesServices: AppCodesService,
    private activeRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (params && params.code) {
        this.currCode = params.code;
        this.isEdit = true;
        this.editInfo();
      }
      this.title = params.title;
      this.userId = this.session.get('userId');
    });
    this.createForm();
  }
  createForm() {
    this.currencyForm = this.fb.group({
      currCode: [undefined, Validators.required],
      currName: '',
      currShortName: '',
      currBlName: '',
      currUnitName: '',
      currBlShortName: '',
      currFmtMask: '',
      currDecimal: undefined,
      currFreezYn: '',
      currFreezDt: '',
      currCrDt: new Date(),
      currCrUid: ''
    });
    this.loaderService.isBusy = false;
  }
  save() {
    if (this.currencyForm.valid) {
      this.loaderService.isBusy = true;
      if (this.currencyForm.get('currFreezYn').value === false) {
        this.togglebtn = '0';
      } else {
        this.togglebtn = '1';
      }
      this.param = this.currencyForm.get('currCode').value;
      const data = {
        currCode: this.currencyForm.get('currCode').value,
        currName: this.currencyForm.get('currName').value,
        currShortName: this.currencyForm.get('currShortName').value,
        currBlName: this.currencyForm.get('currBlName').value,
        currUnitName: this.currencyForm.get('currUnitName').value,
        currBlShortName: this.currencyForm.get('currBlShortName').value,
        currFmtMask: this.currencyForm.get('currFmtMask').value,
        currDecimal: this.currencyForm.get('currDecimal').value,
        currFreezDt: this.currencyForm.get('currFreezDt').value,
        currCrDt: new Date(),
        currCrUid: this.session.get('userId'),
        currFreezYn: this.togglebtn,
      };
      if (this.isEdit) {
        this.appCodesServices.updateCurrencyDetails(this.currCode, data).subscribe(result => {
          this.loaderService.isBusy = false;
          this.toastService.success('Saved Successfully.');
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error in Saving Data');
        });
      } else {
        this.appCodesServices.saveCurrencyDetails(data).subscribe(result => {
          this.toastService.success('Saved Successfully.');
          this.loaderService.isBusy = false;
          this.currencyForm.reset();
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.errormsg = error.error.message;
          this.toastService.error('Error in Saving Data');

        });
      }
    } else {
      this.validateAllFormFields(this.currencyForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }
  back() {
    this.currencyForm.reset();
    this.router.navigate(['appCodes/appCurrency'], { queryParams: { 'flag': true, 'title': 'Currency', 'path': this.path } });
  }
  editInfo() {
    this.loaderService.isBusy = true;
    this.appCodesServices.retrieveCurrencyById(this.currCode).subscribe(result => {
      if ('0' === result.currFreezYn) {
        this.freezeFlag = false;
      } else {
        this.freezeFlag = true;
      }
      this.currencyForm.patchValue({
        currCode: result.currCode,
        currName: result.currName,
        currShortName: result.currShortName,
        currBlName: result.currBlName,
        currUnitName: result.currUnitName,
        currBlShortName: result.currBlShortName,
        currFmtMask: result.currFmtMask,
        currDecimal: result.currDecimal,
        currFreezDt: moment(result.currFreezDt).toDate(),
        currFreezYn: (result.currFreezYn === '1') ? true : false
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error.error.message);
    });
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  freezeToggle(isChecked) {
    this.freezeFlag = isChecked;
    if (!this.freezeFlag) {
      this.currencyForm.get('currFreezDt').clearValidators();
      this.currencyForm.patchValue({
        currFreezDt: ''

      });
    } else {
      this.currencyForm.get('currFreezDt').setValidators(Validators.required);
      this.currencyForm.patchValue({
        currFreezDt: new Date()
      });
    }
  }
}
