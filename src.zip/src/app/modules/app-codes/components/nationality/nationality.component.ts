import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppCodesService } from '../../services/app-codes.service';
<<<<<<< HEAD
=======
																
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@Component({
  selector: 'app-nationality',
  templateUrl: './nationality.component.html',
  styleUrls: ['./nationality.component.scss']
})
export class NationalityComponent implements OnInit {

  public defaultColDef;
  action: string;
  details: any;
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  quickSearchValue: any;
  gridApi: any;
  nationalityColumns: any;
  showForm: boolean;
  appCodeForm: UntypedFormGroup;
  isReadonly: boolean;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private appCodesServices: AppCodesService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,
    private authService: AuthService

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.nationalityColumns = [
      {
        field: 'acCode',
        headerName: 'Nationality Code'
      },
      {
        field: 'acDesc',
        headerName: 'Name'
      },
      {
        field: 'acCode',
        headerName: "Action",
        width: 75,
<<<<<<< HEAD
=======
			   
																									   
				
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
        cellRenderer: actionRender,
      }
    ];

    this.retrieveNationality();
    this.createAppCodeForm();
  }

  createAppCodeForm() {
    this.appCodeForm = this.fb.group({
<<<<<<< HEAD
      acInstId: this.authService.getInstanceCode(),
      acCode: ['', Validators.required],
      acType: 'NATIONALITY',
      acDesc: ['', Validators.required],
      acCodeByLobYn: '1',
=======
			   
      acInstId: this.authService.getInstanceCode(),
      acCode: ['', Validators.required],
      acType: 'NATIONALITY',
				  
				   
						
      acDesc: ['', Validators.required],
				   
					  
						
					 
					   
      acCodeByLobYn: '1',
					
						 
					
					
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      acCrUid: this.session.get('userId'),
      acCrDt: new Date(),
      acUpdUid: '',
      acUpdDt: ''
    });
  }
  retrieveNationality() {
    this.appCodesServices.retrieveAppCodesByType('NATIONALITY').subscribe(resp => {
      this.details = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }
  addNationality() {
    this.action = "add";
    this.createAppCodeForm();
    this.isReadonly = false;
    this.showForm = true;
  }
  cancel() {
    this.showForm = false;
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
  save() {
    if (this.appCodeForm.valid) {
      this.loaderService.isBusy = true;
      if ("edit" === this.action) {
        this.appCodesServices.updateAppCodes(this.appCodeForm.value, this.appCodeForm.get("acCode").value).subscribe(result => {
          this.showForm = false;
          this.retrieveNationality()
          this.loaderService.isBusy = false;
          this.toastService.success('Updated Successfully.');
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error While Updating');

        });
      } else {
        this.appCodesServices.insertAppCodes(this.appCodeForm.value).subscribe(result => {
          this.showForm = false;
          this.retrieveNationality();
          this.loaderService.isBusy = false;
          this.toastService.success('Saved Successfully.');
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error While Saving');
        });
      }
    } else {
      this.validateAllFormFields(this.appCodeForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  editNationality(data) {
    this.isReadonly = true;
    this.action = "edit";
    this.showForm = true;
    this.appCodeForm.patchValue({
<<<<<<< HEAD
      acInstId: this.authService.getInstanceCode(),
      acCode: data.acCode,
      acType: data.acType,
      acDesc: data.acDesc,
      acCodeByLobYn: data.acCodeByLobYn,
=======
					  
      acInstId: this.authService.getInstanceCode(),
      acCode: data.acCode,
      acType: data.acType,
							
							  
										
      acDesc: data.acDesc,
							  
									
										
								  
									  
      acCodeByLobYn: data.acCodeByLobYn,
								
										  
								
								
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      acCrUid: data.acCrUid,
      acCrDt: data.acCrDt,
      acUpdUid: this.session.get('userId'),
      acUpdDt: new Date()
    });
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormArray) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.editNationality(data);
      }
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    // this.loadlayergrid("new");
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("nationalitytable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
    </a>`;
  }
}
