import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';
import { AuthService } from 'src/app/services/auth.service';

@Injectable({
    providedIn: 'root'
})
export class AppCodesService {
    globalUrl: any = environment.commonBaseUrl;
    instanceId: any;
    public requestHeaders;

<<<<<<< HEAD
    constructor(
        private _httpService: HttpClient,
        private session: SessionStorageService,
        private authService: AuthService

    ) {
=======
    constructor(private _httpService: HttpClient,
        private route: ActivatedRoute,
        private session: SessionStorageService,
        private authService: AuthService) {
        this.instanceId = this.authService.getInstanceCode();
        this.requestHeaders = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }

    saveCurrencyDetails(body: any): Observable<any> {
        return this._httpService.post(this.globalUrl + 'currency-mgmt/' +
            ApiUrls.CURRENCY_PATH + '?company=' + this.session.get('companyCode'),
            body);
    }

    updateCurrencyDetails(params: any, body: any): Observable<any> {
        return this._httpService.put(this.globalUrl + 'currency-mgmt/' + ApiUrls.CURRENCY_PATH + '/' + params, body);
    }

    retrieveCurrencyById(searchValue: string): Observable<any> {
        return this._httpService.get<any>(this.globalUrl + 'currency-mgmt/' + ApiUrls.CURRENCY_PATH + '/' +
            searchValue + '?company=' + this.session.get('companyCode'));
    }

    retrieveCurrencyDetails() {
        return this._httpService.get<any>(this.globalUrl + 'currency-mgmt/' + ApiUrls.CURRENCY_PATH);
    }

    //---------------- BANK MAster-----------------//
    retrieveBankDetails(): Observable<any> {
        return this._httpService.get(this.globalUrl + 'bank-mgmt/' + ApiUrls.BANK_PATH);
    }

    retrieveBankById(body: any): Observable<any> {
        return this._httpService.get(this.globalUrl + 'bank-mgmt/' + ApiUrls.BANK_PATH + '/' + body.bankCode);
    }

    insertBankDetails(body: any): Observable<any> {
        return this._httpService.post(this.globalUrl + 'bank-mgmt/' + ApiUrls.BANK_PATH, body);
    }

    updateBankDetails(body: any): Observable<any> {
        return this._httpService.put(this.globalUrl + 'bank-mgmt/' + ApiUrls.BANK_PATH + '/' + body.bankCode, body);
    }
    //------------------END----------------------- //
    retrieveAppCodesByType(type: any): Observable<any> {
<<<<<<< HEAD
        return this._httpService.get(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.APP_CODES_PATH + "/" + type);
    }

    insertAppCodes(body: any): Observable<any> {
        return this._httpService.post(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.APP_CODES_PATH, body);
    }

    updateAppCodes(body: any, id: any): Observable<any> {
        return this._httpService.put(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.APP_CODES_PATH + "/" + id, body);
    }

    retrieveByCode(code: any): Observable<any> {
        return this._httpService.get(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.APP_CODES_PATH + "/" + ApiUrls.COUNTRY_CODE + "/" + code);
    }
    retrieveZoneByStateCode(code: any): Observable<any> {
        return this._httpService.get(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.APP_CODES_PATH + "/" + ApiUrls.STATE_CODE + "/" + code);
    }

    retrieveCompanies(path: any) {
        return this._httpService.get<any>(this.globalUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.COMP_PATH + "/" + ApiUrls.GET_COMPANY_LIST);
    }

    savePasswordDetails(body: any): Observable<any> {
        return this._httpService.put(this.globalUrl + "passwordPolicy" + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.PSWD_PLCY_PATH + "/" + body.ppCompCode + '?company=' + this.session.get('companyCode'), body);

    }
    retrievePwdPlcyById(searchValue: string): Observable<any> {
        return this._httpService.get<any>(this.globalUrl + "passwordPolicy" + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.PSWD_PLCY_PATH + "/" + searchValue + '?company=' + this.session.get('companyCode'));
    }



=======
        return this._httpService.get(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.APP_CODES_PATH + "/" + type);
    }

    insertAppCodes(body: any): Observable<any> {
        return this._httpService.post(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.APP_CODES_PATH, body);
    }

    updateAppCodes(body: any, id: any): Observable<any> {
        return this._httpService.put(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.APP_CODES_PATH + "/" + id, body);
    }

    retrieveByCode(code: any): Observable<any> {
        return this._httpService.get(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.APP_CODES_PATH + "/" + ApiUrls.COUNTRY_CODE + "/" + code);
    }
    retrieveZoneByStateCode(code: any): Observable<any> {
        return this._httpService.get(this.globalUrl + ApiUrls.APPCODE_CONTROLLER_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.APP_CODES_PATH + "/" + ApiUrls.STATE_CODE + "/" + code);
    }

    retrieveCompanies(path: any) {
        return this._httpService.get<any>(this.globalUrl + ApiUrls.ORG_CONT_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.COMP_PATH + "/" + ApiUrls.GET_COMPANY_LIST);
    }

    savePasswordDetails(body: any): Observable<any> {
        return this._httpService.put(this.globalUrl + "passwordPolicy" + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.PSWD_PLCY_PATH + "/" + body.ppCompCode + '?company=' + this.session.get('companyCode'), body);

    }
    retrievePwdPlcyById(searchValue: string): Observable<any> {
        return this._httpService.get<any>(this.globalUrl + "passwordPolicy" + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.PSWD_PLCY_PATH + "/" + searchValue + '?company=' + this.session.get('companyCode'));
    }
    retrieveAllAppCodes() {
        return this._httpService.get<any>(this.globalUrl + "appcodes-mgmt/appcodes");
    }
    
    getlobData() {
        return this._httpService.get<any>(this.globalUrl + "productsetup/lob", this.requestHeaders);
    }
    addLobData(data) {
        return this._httpService.post<any>(this.globalUrl + 'productsetup/lob/save', data, this.requestHeaders);
    }

    updateLobData(data) {
        return this._httpService.put<any>(this.globalUrl + 'productsetup/lob/update', data, this.requestHeaders);
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
}
