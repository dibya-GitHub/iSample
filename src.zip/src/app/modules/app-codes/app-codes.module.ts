<<<<<<< HEAD
=======
import { AuthInterceptor } from 'src/app/services/auth-interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { AppCodesRoutingModule } from './app-codes-routing.module';
import { AppCurrencyComponent } from './components/app-currency/app-currency.component';
import { BankGridComponent } from './components/bank-grid/bank-grid.component';
import { BankComponent } from './components/bank/bank.component';
import { CountryComponent } from './components/country/country.component';
<<<<<<< HEAD
import { CurrencyGridComponent } from './components/currency-grid/currency-grid.component';
import { NationalityComponent } from './components/nationality/nationality.component';
import { AppCodesService } from './services/app-codes.service';
import { DropdownModule } from 'primeng/dropdown';
import { InputNumberModule } from 'primeng/inputnumber';

=======
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { DropdownModule } from 'primeng/dropdown';
import { InputNumberModule } from 'primeng/inputnumber';
import { AllAppCodesComponent } from './components/all-app-codes/all-app-codes.component';
import { LobComponent } from './components/lob/lob.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@NgModule({
  imports: [
    CommonModule,
    AppCodesRoutingModule,
    CommonAppModule,
    DropdownModule,
    InputNumberModule
  ],
  declarations: [
    AppCurrencyComponent,
    CurrencyGridComponent,
    BankComponent,
    BankGridComponent,
    NationalityComponent,
<<<<<<< HEAD
    CountryComponent
  ],
  providers: [AppCodesService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]

=======
    CountryComponent,
    AllAppCodesComponent,
    LobComponent
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
})
export class AppCodesModule { }
