import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AppCurrencyComponent } from "./components/app-currency/app-currency.component";
import { BankGridComponent } from "./components/bank-grid/bank-grid.component";
import { BankComponent } from "./components/bank/bank.component";
import { CountryComponent } from "./components/country/country.component";
<<<<<<< HEAD
import { CurrencyGridComponent } from "./components/currency-grid/currency-grid.component";
import { NationalityComponent } from "./components/nationality/nationality.component";
=======
import { AllAppCodesComponent } from "./components/all-app-codes/all-app-codes.component";
import { LobComponent } from "./components/lob/lob.component";
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032


const routes: Routes = [
  {
    path: 'all',
    component: AllAppCodesComponent,
    data: {
      breadcrumb: 'All App Codes'
    }
  },
  {
    path: 'lob',
    component: LobComponent,
    data: {
      breadcrumb: 'LOB'
    }
  },
  {
    path: 'appCurrency',
    component: CurrencyGridComponent,
    data: {
      breadcrumb: 'App Currency'
    },
  },
  {
    path: 'appCurrency/add',
    component: AppCurrencyComponent,
    data: {
      breadcrumb: 'App Currency-Add'
    },
  },
  {
    path: 'appCurrency/edit',
    component: AppCurrencyComponent,
    data: {
      breadcrumb: 'App Currency-Edit'
    },
  },
  {
    path: 'bank',
    component: BankGridComponent,
    data: {
      breadcrumb: 'Bank'
    },
  },
  {
    path: 'bank/add',
    component: BankComponent,
    data: {
      breadcrumb: 'Bank-Edit'
    },
  },
  {
    path: 'bank/edit',
    component: BankComponent,
    data: {
      breadcrumb: 'Bank-Add'
    },
  },
  {
    path: 'nationality',
    component: NationalityComponent,
    data: {
      breadcrumb: 'Nationality'
    },
  },
  {
    path: 'country',
    component: CountryComponent,
    data: {
      breadcrumb: 'Country'
    },

  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppCodesRoutingModule { }
