import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MSmsEmailTemplateComponent } from './components/m-sms-emal-template/m-sms-email-template.component';
import { ReportEnquiryComponent } from './components/report-enquiry/report-enquiry.component';
import { EnquiryReportComponent } from './components/enquiry-report/enquiry-report.component';
import { ReportHeadingsTableComponent } from './components/report-headings-table/report-headings-table.component';
import { MReportHeadingsComponent } from './components/m-report-headings/m-report-headings.component';
import { SmsEmailComponent } from './components/sms-email/sms-email.component';

const routes: Routes = [
  {
    path:'smsEmail',
    component:SmsEmailComponent,
    data: {
      breadcrumb: 'SMS/Email'
    },
  },
  {
    path:'smsEmail/add',
    component:MSmsEmailTemplateComponent,
    data: {
      breadcrumb: 'SMS/Email-Add'
    },
  },
  {
    path:'smsEmail/edit',
    component:MSmsEmailTemplateComponent,
    data: {
      breadcrumb: 'SMS/Email-Edit'
    },
  },
  {
    path:'repEnquiry',
    component:ReportEnquiryComponent,
    data: {
      breadcrumb: 'Report Template'
    },
  },
  {
    path:'repEnquiry/add',
    component:EnquiryReportComponent,
    data: {
      breadcrumb: 'Report Template-Add'
    },
  },
  {
    path:'repEnquiry/edit',
    component:EnquiryReportComponent,
    data: {
      breadcrumb: 'Report Template-Edit'
    },
  },
  {
    path: 'report',
    component:ReportHeadingsTableComponent,
    data: {
      breadcrumb: 'Report Heading'
    },
  },
  {
    path: 'report/add',
    component:MReportHeadingsComponent,
    data: {
      breadcrumb: 'Report Heading-Add'
    },
  },
  {
    path: 'report/edit',
    component:MReportHeadingsComponent,
    data: {
      breadcrumb: 'Report Heading-Edit'
    },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TemplatesSetupRoutingModule {

 }
