import { CommonModule } from '@angular/common';
<<<<<<< HEAD
import { NgModule } from '@angular/core';
import { DropdownModule } from 'primeng/dropdown';
import { EditorModule } from 'primeng/editor';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { EnquiryReportComponent } from './components/enquiry-report/enquiry-report.component';
import { MReportHeadingsComponent } from './components/m-report-headings/m-report-headings.component';
=======
import { DropdownModule } from 'primeng/dropdown';
import { EditorModule } from 'primeng/editor';
import { SmsEmailComponent } from './components/sms-email/sms-email.component';
import { TemplatesSetupRoutingModule } from './templates-setup-routing.module';
import { TemplateSetupService } from './services/template-setup.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { MSmsEmailTemplateComponent } from './components/m-sms-emal-template/m-sms-email-template.component';
import { ReportEnquiryComponent } from './components/report-enquiry/report-enquiry.component';
import { ReportHeadingsTableComponent } from './components/report-headings-table/report-headings-table.component';
import { SmsEmailComponent } from './components/sms-email/sms-email.component';
import { TemplateSetupService } from './services/template-setup.service';
import { TemplatesSetupRoutingModule } from './templates-setup-routing.module';

@NgModule({
  declarations: [
    SmsEmailComponent,
    MSmsEmailTemplateComponent,
    EnquiryReportComponent,
    ReportEnquiryComponent,
    ReportHeadingsTableComponent,
    MReportHeadingsComponent
  ],
  imports: [
    CommonModule,
    CommonAppModule,
    EditorModule,
    TemplatesSetupRoutingModule,
    DropdownModule
  ],
  providers: [TemplateSetupService]

})
export class TemplatesSetupModule { }
