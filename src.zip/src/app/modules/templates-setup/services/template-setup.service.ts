import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from "rxjs";
import { ApiUrls } from "src/app/api-urls";
<<<<<<< HEAD
import { AuthService } from 'src/app/services/auth.service';
import { environment } from "src/environments/environment";
=======
import { AuthService } from "src/app/services/auth.service";
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Injectable({
    providedIn: 'root'
})
export class TemplateSetupService {
    requestOption: any;
    globalUrl: any = environment.commonBaseUrl;
    reportUrl: any = environment.reportBaseUrl;
    instanceId:any;
    constructor(
        private route: ActivatedRoute,
<<<<<<< HEAD
        private httpService: HttpClient,
        private session: SessionStorageService,
        private authService: AuthService
    ) {
=======
        private session: SessionStorageService,
        private authService: AuthService){
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        const headersOpt = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })
        this.requestOption = { headers: headersOpt };
        this.instanceId = this.authService.getInstanceCode();
    }

    retrieveSmsEmailDetails(): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get(this.globalUrl + ApiUrls.SMS_EMAIL_TEMPLATE_PATH + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.SMS_EMAIL_PATH, this.requestOption);
=======
        return this.httpService.get(this.globalUrl + ApiUrls.SMS_EMAIL_TEMPLATE_PATH + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.SMS_EMAIL_PATH, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }

    retrieveEnqReport(): Observable<any> {
        return this.httpService.get(this.reportUrl + 'repenquiry-mgmt' + "/enquiry-reports", this.requestOption);
    }

    retrieveRephdDetails(): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get<any>(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.REPORT_HEADINGS_PATH);

    }

    getUserCompanyList(): Observable<any> {
        return this.httpService.get(this.globalUrl + 'users-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.GET_COMPANY_LIST, this.requestOption);
=======
        return this.httpService.get<any>(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.REPORT_HEADINGS_PATH);

    }

    getUserCompanyList(): Observable<any>  {
        return this.httpService.get(this.globalUrl + 'users-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.GET_COMPANY_LIST, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }

    getParamValue(paramName) {
        let paramVal;
        this.route.queryParams.subscribe(params => {
            paramVal = params[paramName];

        });
        return paramVal;

    }


    updateRephdsDetails(body: any, params: any): Observable<any> {

<<<<<<< HEAD
        return this.httpService.put(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.REPORT_HEADINGS_PATH + "/" + params.rhCompCode + "/" + params.rhRepId, body, this.requestOption);
    }


    saveRephdsDetails(body: any, params: any): Observable<any> {
        return this.httpService.post(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.REPORT_HEADINGS_PATH + "/" + params.rhCompCode + "/" + params.rhRepId, body);
=======
        return this.httpService.put(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.REPORT_HEADINGS_PATH + "/" + params.rhCompCode + "/" + params.rhRepId, body, this.requestOption);
    }

      
    saveRephdsDetails( body: any, params: any): Observable<any> {
        return this.httpService.post(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.REPORT_HEADINGS_PATH + "/" + params.rhCompCode + "/" + params.rhRepId, body);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }


    retrieveRephdById(obj: any): Observable<any> {
<<<<<<< HEAD
        return this.httpService.get(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.REPORT_HEADINGS_PATH + "/" + obj.rhCompCode + "/" + obj.rhRepId, this.requestOption);
=======
        return this.httpService.get(this.reportUrl + 'report-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.REPORT_HEADINGS_PATH + "/" + obj.rhCompCode + "/" + obj.rhRepId, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }

}