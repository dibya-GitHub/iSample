<<<<<<< HEAD
import { Component } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
=======
import { Component, Inject } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { TemplateSetupService } from '../../services/template-setup.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TemplateSetupService } from '../../services/template-setup.service';

declare var $: any;

@Component({
  selector: 'app-m-report-headings',
  templateUrl: './m-report-headings.component.html',
  styleUrls: ['./m-report-headings.component.css']
})
export class MReportHeadingsComponent {

  title: any;
  disableCompany: string;
  button: string;
  repId: any;
  repCompCode: any;
  param: any;
  compList: any;
  errormsg: any;
  reportForm: UntypedFormGroup;
  paramCode: any;
  action: any;
  userId: any;
  path: string;
  compcode: string;
  editFlag: boolean;
  englishFormGroup: UntypedFormGroup;
  arabicFormGroup: UntypedFormGroup;
  languageFormArray: any[];
  disableField: boolean = false;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private loaderService: LoaderService,
    private templateService: TemplateSetupService,
<<<<<<< HEAD
    private toastService: ToastService,
=======
    private toastService: ToastrService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private session: SessionStorageService,

  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.repCompCode = this.templateService.getParamValue('compCode');
    this.repId = this.templateService.getParamValue('repId');
    this.action = this.templateService.getParamValue('action');
    this.userId = this.session.get('userId')
    this.reportHeading();
    this.templateService.getUserCompanyList().subscribe(result => {
      this.compList = result;
      this.loaderService.isBusy = false;
    },
      error => {
        this.loaderService.isBusy = false;
        this.toastService.error("Error in Retrive Data");
      });
    if ('edit' == this.action) {
      this.button = "Update";
      this.disableCompany = "disabled";
      this.reportForm.get('rhRepId').disable();
      this.reportForm.get('rhCompCode').disable();
      this.editInfo();
    } else {
      this.button = "Save";
    }
  }
  reportHeading() {
    const arr = [];
    const group = {
      rhRepId: ['', Validators.required],
      rhCompCode: [undefined, Validators.required],
      thTtyDesc: '',
      rhRepName: '',
      rhRepNameFl: '',
      rhTitle1: '',
      rhTitle2: '',
      rhTitle3: '',
      rhTitle4: '',
      rhTitle5: '',
      rhTitle1Fl: '',
      rhTitle2Fl: '',
      rhTitle3Fl: '',
      rhTitle4Fl: '',
      rhTitle5Fl: '',
      rhCrDt: new Date(),
      rhCrUid: this.session.get('userId')
    };
    for (let index = 1; index <= 75; index++) {
      arr.push(index);
      group['rhCol' + index] = new UntypedFormControl();
      group['rhCol' + index + 'Fl'] = new UntypedFormControl();
    }
    this.reportForm = this.fb.group(group);
    this.languageFormArray = arr;
  }
  save() {
    if (this.reportForm.valid) {
      this.loaderService.isBusy = true;
      let param = {
        rhCompCode: this.reportForm.get('rhCompCode').value,
        rhRepId: this.reportForm.get('rhRepId').value,
      }
      if (this.action == 'edit') {
        let obj = {
          'rhCompCode': this.repCompCode,
          'rhRepId': this.repId
        }
        this.templateService.updateRephdsDetails(this.reportForm.value, obj).subscribe(result => {
          this.loaderService.isBusy = false;
          this.toastService.success("Updated Successfully");
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error('Error in Saving Data');
        });
      }
      else {
        this.templateService.saveRephdsDetails(this.reportForm.value, param).subscribe(result => {
          this.loaderService.isBusy = false;
          this.toastService.success("Saved Successfully");
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        });
      }
    } else {
      this.validateAllFormFields(this.reportForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  back() {
    this.reportForm.reset();
    this.router.navigate(['templates-setup/report'], { queryParams: { action: undefined }, queryParamsHandling: 'merge' });
  }
  editInfo() {
    this.loaderService.isBusy = true;
    this.editFlag = true;
    let obj = {
      rhCompCode: this.repCompCode,
      rhRepId: this.repId
    }
    this.templateService.retrieveRephdById(obj).subscribe(result => {
      this.reportForm.patchValue({
        rhRepId: result.mrepHeadingsPK.rhRepId,
        rhCompCode: result.mrepHeadingsPK.rhCompCode,
        rhRepName: result.rhRepName,
        rhRepNameFl: result.rhRepNameFl,
        rhTitle1: result.rhTitle1,
        rhTitle2: result.rhTitle2,
        rhTitle3: result.rhTitle3,
        rhTitle4: result.rhTitle4,
        rhTitle5: result.rhTitle5,
        rhTitle1Fl: result.rhTitle1Fl,
        rhTitle2Fl: result.rhTitle2Fl,
        rhTitle3Fl: result.rhTitle3Fl,
        rhTitle4Fl: result.rhTitle4Fl,
        rhTitle5Fl: result.rhTitle5Fl,
        rhCol1: result.rhCol1,
        rhCol2: result.rhCol2,
        rhCol3: result.rhCol3,
        rhCol4: result.rhCol4,
        rhCol5: result.rhCol5,
        rhCol6: result.rhCol6,
        rhCol7: result.rhCol7,
        rhCol8: result.rhCol8,
        rhCol9: result.rhCol9,
        rhCol10: result.rhCol10,
        rhCol11: result.rhCol11,
        rhCol12: result.rhCol12,
        rhCol13: result.rhCol13,
        rhCol14: result.rhCol14,
        rhCol15: result.rhCol15,
        rhCol16: result.rhCol16,
        rhCol17: result.rhCol17,
        rhCol18: result.rhCol18,
        rhCol19: result.rhCol19,
        rhCol20: result.rhCol20,
        rhCol21: result.rhCol21,
        rhCol22: result.rhCol22,
        rhCol23: result.rhCol23,
        rhCol24: result.rhCol24,
        rhCol25: result.rhCol25,
        rhCol26: result.rhCol26,
        rhCol27: result.rhCol27,
        rhCol28: result.rhCol28,
        rhCol29: result.rhCol29,
        rhCol30: result.rhCol30,
        rhCol31: result.rhCol31,
        rhCol32: result.rhCol32,
        rhCol33: result.rhCol33,
        rhCol34: result.rhCol34,
        rhCol35: result.rhCol35,
        rhCol36: result.rhCol36,
        rhCol37: result.rhCol37,
        rhCol38: result.rhCol38,
        rhCol39: result.rhCol39,
        rhCol40: result.rhCol40,
        rhCol41: result.rhCol41,
        rhCol42: result.rhCol42,
        rhCol43: result.rhCol43,
        rhCol44: result.rhCol44,
        rhCol45: result.rhCol45,
        rhCol46: result.rhCol46,
        rhCol47: result.rhCol47,
        rhCol48: result.rhCol48,
        rhCol49: result.rhCol49,
        rhCol50: result.rhCol50,
        rhCol51: result.rhCol51,
        rhCol52: result.rhCol52,
        rhCol53: result.rhCol53,
        rhCol54: result.rhCol54,
        rhCol55: result.rhCol55,
        rhCol56: result.rhCol56,
        rhCol57: result.rhCol57,
        rhCol58: result.rhCol58,
        rhCol59: result.rhCol59,
        rhCol60: result.rhCol60,
        rhCol61: result.rhCol61,
        rhCol62: result.rhCol62,
        rhCol63: result.rhCol63,
        rhCol64: result.rhCol64,
        rhCol65: result.rhCol65,
        rhCol66: result.rhCol66,
        rhCol67: result.rhCol67,
        rhCol68: result.rhCol68,
        rhCol69: result.rhCol69,
        rhCol70: result.rhCol70,
        rhCol71: result.rhCol71,
        rhCol72: result.rhCol72,
        rhCol73: result.rhCol73,
        rhCol74: result.rhCol74,
        rhCol75: result.rhCol75,

        rhCol1Fl: result.rhCol1Fl,
        rhCol2Fl: result.rhCol2Fl,
        rhCol3Fl: result.rhCol3Fl,
        rhCol4Fl: result.rhCol4Fl,
        rhCol5Fl: result.rhCol5Fl,
        rhCol6Fl: result.rhCol6Fl,
        rhCol7Fl: result.rhCol7Fl,
        rhCol8Fl: result.rhCol8Fl,
        rhCol9Fl: result.rhCol9Fl,
        rhCol10Fl: result.rhCol10Fl,
        rhCol11Fl: result.rhCol11Fl,
        rhCol12Fl: result.rhCol12Fl,
        rhCol13Fl: result.rhCol13Fl,
        rhCol14Fl: result.rhCol14Fl,
        rhCol15Fl: result.rhCol15Fl,
        rhCol16Fl: result.rhCol16Fl,
        rhCol17Fl: result.rhCol17Fl,
        rhCol18Fl: result.rhCol18Fl,
        rhCol19Fl: result.rhCol19Fl,
        rhCol20Fl: result.rhCol20Fl,
        rhCol21Fl: result.rhCol21Fl,
        rhCol22Fl: result.rhCol22Fl,
        rhCol23Fl: result.rhCol23Fl,
        rhCol24Fl: result.rhCol24Fl,
        rhCol25Fl: result.rhCol25Fl,
        rhCol26Fl: result.rhCol26Fl,
        rhCol27Fl: result.rhCol27Fl,
        rhCol28Fl: result.rhCol28Fl,
        rhCol29Fl: result.rhCol29Fl,
        rhCol30Fl: result.rhCol30Fl,
        rhCol31Fl: result.rhCol31Fl,
        rhCol32Fl: result.rhCol32Fl,
        rhCol33Fl: result.rhCol33Fl,
        rhCol34Fl: result.rhCol34Fl,
        rhCol35Fl: result.rhCol35Fl,
        rhCol36Fl: result.rhCol36Fl,
        rhCol37Fl: result.rhCol37Fl,
        rhCol38Fl: result.rhCol38Fl,
        rhCol39Fl: result.rhCol39Fl,
        rhCol40Fl: result.rhCol40Fl,
        rhCol41Fl: result.rhCol41Fl,
        rhCol42Fl: result.rhCol42Fl,
        rhCol43Fl: result.rhCol43Fl,
        rhCol44Fl: result.rhCol44Fl,
        rhCol45Fl: result.rhCol45Fl,
        rhCol46Fl: result.rhCol46Fl,
        rhCol47Fl: result.rhCol47Fl,
        rhCol48Fl: result.rhCol48Fl,
        rhCol49Fl: result.rhCol49Fl,
        rhCol50Fl: result.rhCol50Fl,
        rhCol51Fl: result.rhCol51Fl,
        rhCol52Fl: result.rhCol52Fl,
        rhCol53Fl: result.rhCol53Fl,
        rhCol54Fl: result.rhCol54Fl,
        rhCol55Fl: result.rhCol55Fl,
        rhCol56Fl: result.rhCol56Fl,
        rhCol57Fl: result.rhCol57Fl,
        rhCol58Fl: result.rhCol58Fl,
        rhCol59Fl: result.rhCol59Fl,
        rhCol60Fl: result.rhCol60Fl,
        rhCol61Fl: result.rhCol61Fl,
        rhCol62Fl: result.rhCol62Fl,
        rhCol63Fl: result.rhCol63Fl,
        rhCol64Fl: result.rhCol64Fl,
        rhCol65Fl: result.rhCol65Fl,
        rhCol66Fl: result.rhCol66Fl,
        rhCol67Fl: result.rhCol67Fl,
        rhCol68Fl: result.rhCol68Fl,
        rhCol69Fl: result.rhCol69Fl,
        rhCol70Fl: result.rhCol70Fl,
        rhCol71Fl: result.rhCol71Fl,
        rhCol72Fl: result.rhCol72Fl,
        rhCol73Fl: result.rhCol73Fl,
        rhCol74Fl: result.rhCol74Fl,
        rhCol75Fl: result.rhCol75Fl

      });
      this.loaderService.isBusy = false;

    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    });
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
<<<<<<< HEAD
    Object.keys(formGroup['controls']).forEach(field => {
=======
    Object.keys(formGroup.controls).forEach(field => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
