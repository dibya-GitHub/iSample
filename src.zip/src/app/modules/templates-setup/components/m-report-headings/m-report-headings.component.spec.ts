import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MReportHeadingsComponent } from './m-report-headings.component';

describe('MReportHeadingsComponent', () => {
  let component: MReportHeadingsComponent;
  let fixture: ComponentFixture<MReportHeadingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MReportHeadingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MReportHeadingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
