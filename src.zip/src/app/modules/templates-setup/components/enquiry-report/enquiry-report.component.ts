import { Component, OnInit } from '@angular/core';
<<<<<<< HEAD
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
=======
import { Inject } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { Router } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { UntypedFormControl } from '@angular/forms';
import { ReportService } from 'src/app/shared/services/report.service';
import { ToastrService } from 'ngx-toastr';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { ReportService } from 'src/app/shared/services/report.service';

@Component({
  selector: 'app-enquiry-report',
  templateUrl: './enquiry-report.component.html',
  styleUrls: ['./enquiry-report.component.css']
})

export class EnquiryReportComponent implements OnInit {
  instId: any;
  repoList: any;
  enqReportFrm: UntypedFormGroup;
  path: any;
  action: any;

  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private reportService: ReportService,
    private loaderService: LoaderService,
<<<<<<< HEAD
    private toastService: ToastService,
    private authService: AuthService

=======
    private toastrService: ToastrService,
    private session: SessionStorageService
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.action = this.reportService.getParamValue('action');
    this.path = 'repenquiry-mgmt'
    this.instId = this.reportService.getParamValue('code');
    this.createEnqRepForm();
    if ("edit" == this.action) {
      this.loadById();
    }
  }
  createEnqRepForm() {
    this.enqReportFrm = this.fb.group({
      erId: this.authService.getInstanceCode(),
      erTableName: ['', Validators.required],
      erShortDesc: ['', Validators.required],
      erLongDesc: '',
      erDispSrNo: '',
      erCrUid: 'userTest',
      erCrDt: new Date()
    });
    this.loaderService.isBusy = false;
  }

  back() {
    this.router.navigate(['templates-setup/repEnquiry'], { queryParams: { action: undefined }, queryParamsHandling: 'merge' });
  }
  loadById() {
    this.loaderService.isBusy = true;
    this.reportService.retrieveEnqRepById(this.instId).subscribe(resp => {
      this.repoList = resp;
      this.enqReportFrm.patchValue({
        erId: '',
        erTableName: this.repoList.erTableName,
        erShortDesc: this.repoList.erShortDesc,
        erLongDesc: this.repoList.erLongDesc,
        erDispSrNo: this.repoList.erDispSrNo,
      })
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    })
  }
  save() {
    if (this.enqReportFrm.valid) {
      this.loaderService.isBusy = true;

      if ("edit" == this.action) {
        let obj = this.enqReportFrm.value;
        obj.erId = this.instId;
        this.reportService.updateEnqReport(obj).subscribe(resp => {
          this.loaderService.isBusy = false;
          this.back();
        })
      } else {
        this.loaderService.isBusy = true;
        this.reportService.insertEnqReport(this.enqReportFrm.value).subscribe(resp => {
          this.loaderService.isBusy = false;
          this.back();
        })
      }
    } else {
      this.validateAllFormFields(this.enqReportFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
<<<<<<< HEAD
    Object.keys(formGroup['controls']).forEach(field => {
=======
    Object.keys(formGroup.controls).forEach(field => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
