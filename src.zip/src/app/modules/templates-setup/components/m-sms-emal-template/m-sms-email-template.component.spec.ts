import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MSmsEmailTemplateComponent } from './m-sms-email-template.component';

describe('MSmsEmailTemplateComponent', () => {
  let component: MSmsEmailTemplateComponent;
  let fixture: ComponentFixture<MSmsEmailTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MSmsEmailTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MSmsEmailTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
