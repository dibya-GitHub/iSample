import { ToastService } from './../../../../services/toast.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
// import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { GlobalService } from 'src/app/shared/services/global.service';

@Component({
  selector: 'app-m-sms-email-template',
  templateUrl: './m-sms-email-template.component.html',
  styleUrls: ['./m-sms-email-template.component.css'],
})

export class MSmsEmailTemplateComponent implements OnInit {

  // public editor = ClassicEditor;
  path: any = 'smsemail-mgmt';
  smsEmailTemplateForm: UntypedFormGroup;
  divInfo = [];
  smsEmailDetails: any;
  templatecode: any;
  action: string;
  editFlag: boolean;
  display: boolean;
  testhtml: any;
  name = 'ng2-ckeditor';
  ckeConfig: any;
  log: string = '';
  @ViewChild("myckeditor") ckeditor: any;
  @ViewChild('content') content: ElementRef;


  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,
    private globalService: GlobalService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
  ) { }

  ngOnInit() {
    this.ckeConfig = {
      allowedContent: false,
      extraPlugins: 'divarea',
      forcePasteAsPlainText: true
    };
    // this.path = this.globalService.getParamValue('path');
    this.templatecode = this.globalService.getParamValue('code');
    this.action = this.globalService.getParamValue('action');
    this.createSmsEmailTemplateform();
    if ('edit' == this.action) {
      this.edit();
    }
  }
  onChange($event: any): void {
    //this.log += new Date() + "<br />";
  }

  createSmsEmailTemplateform() {
    this.smsEmailTemplateForm = this.fb.group({
      smtTempCode: ['', Validators.required],
      smtTempDesc: ['', Validators.required],
      smtEmailTo: ['', [Validators.required, Validators.email]],
      smtEmailFrom: ['', [Validators.required, Validators.email]],
      smtEmailSubject: '',
      smtEmailBody: [''],
      smtSmsTxt: '',
      smtEmailCc: '',
      smtTempDescBl: '',
      smtEmailSubjectBl: '',
      smtEmailBodyBl: '',
      smtSmsTxtBl: '',
      smtInstId: this.session.get("instanceId"),
      smtCrUid: this.session.get("userId"),
      smtCrDt: new Date(),
      smtUpdUid: '',
      smtUpdDt: ''
    });
    this.loaderService.isBusy = false;
  }

  save() {
    if (this.smsEmailTemplateForm.valid) {
      this.loaderService.isBusy = true;
      if (this.action == 'edit') {
        this.loaderService.isBusy = true;
        this.globalService.updateSmsEmailDetails(this.path, this.smsEmailTemplateForm.value).subscribe(result => {
          this.loaderService.isBusy = false;
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
        });
      } else {
        this.loaderService.isBusy = true;
        this.globalService.insertSmsEmailDetails(this.path, this.smsEmailTemplateForm.value).subscribe(result => {
          this.loaderService.isBusy = false;
          this.back();
        }, error => {
          this.loaderService.isBusy = false;
        });
      }

    } else {
      this.validateAllFormFields(this.smsEmailTemplateForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  edit() {
    this.loaderService.isBusy = true;
    this.editFlag = true;
    let obj = { smtTempCode: this.templatecode };
    this.globalService.retrieveSmsEmailById(this.path, obj).subscribe(resp => {
      let result = resp[0];
      this.smsEmailTemplateForm.patchValue({
        smtTempCode: result.smtTempCode,
        smtTempDesc: result.smtTempDesc,
        smtEmailTo: result.smtEmailTo,
        smtEmailFrom: result.smtEmailFrom,
        smtEmailSubject: result.smtEmailSubject,
        smtEmailBody: result.smtEmailBody,
        smtSmsTxt: result.smtSmsTxt,
        smtEmailCc: result.smtEmailCc,
        smtTempDescBl: result.smtTempDescBl,
        smtEmailSubjectBl: result.smtEmailSubjectBl,
        smtEmailBodyBl: result.smtEmailBodyBl,
        smtSmsTxtBl: result.smtSmsTxtBl,
        smtCrUid: result.smtCrUid,
        smtCrDt: result.smtCrDt,
        smtUpdUid: this.session.get("userId"),
        smtUpdDt: new Date()
      });
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  preview(mode) {
    if (this.smsEmailTemplateForm['controls']['smtEmailBody'] && mode == 'Preview') {
      this.testhtml = this.smsEmailTemplateForm['controls']['smtEmailBody'].value;
      this.open(this.content, 'modal-lg');
    } else if (this.smsEmailTemplateForm['controls']['smtSmsTxtBl'] && mode == 'Bilingual') {
      this.testhtml = this.smsEmailTemplateForm['controls']['smtSmsTxtBl'].value;
      this.open(this.content, 'modal-lg');

    }
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  back() {
    this.route.navigate(['templates-setup/smsEmail'], { queryParams: { action: undefined }, queryParamsHandling: 'merge' });
  }
}
