import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportHeadingsTableComponent } from './report-headings-table.component';

describe('ReportHeadingsTableComponent', () => {
  let component: ReportHeadingsTableComponent;
  let fixture: ComponentFixture<ReportHeadingsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportHeadingsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportHeadingsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
