import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TemplateSetupService } from '../../services/template-setup.service';

@Component({
  selector: 'app-report-headings-table',
  templateUrl: './report-headings-table.component.html',
  styleUrls: ['./report-headings-table.component.scss']
})

export class ReportHeadingsTableComponent {

  private defaultColDef;
  reportHeadCols: any[];
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';
  reportHeadDetails: any;

  constructor(
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private templateService: TemplateSetupService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
     this.loaderService.isBusy = true;
    this.reportHeadCols = [
      {
        field: 'mrepHeadingsPK.rhRepId',
        headerName: 'Report ID',
        tooltipField: 'erTableName',
      },
      {
        field: 'mrepHeadingsPK.rhCompCode',
        headerName: 'Company',
        tooltipField: 'erShortDesc',
      },
      {
        field: 'rhRepName',
        headerName: 'Report Name',
        tooltipField: 'erLongDesc',
      },
      {
        field: 'rhRepNameFl',
        headerName: 'Report Name Arabic',
        tooltipField: 'erDispSrNo',
      },
      {
        headerName: 'Action',
        template:
          `<a>
                <i class="fa fa-file-pen fa-icon" data-action-type="Edit" title="Edit" aria-hidden="true"></i>
            </a>`,
        cellStyle: { textAlign: 'center' },
        resizable: true,
        filter: false,
        sortable: false,
      }
    ]
    this.retrieveReportHead();
  }

  retrieveReportHead() {
     this.loaderService.isBusy = true;
    this.templateService.retrieveRephdDetails().subscribe(resp => {
      this.reportHeadDetails = resp;
       this.loaderService.isBusy = false;
    }, error => {
       this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any, ) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  add() {
    this.router.navigate(['/templates-setup/report/add'], { queryParamsHandling: 'merge', queryParams: { action: 'add' } });
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      if (actionType) {
        this.router.navigate(['/templates-setup/report/edit'], {
          queryParamsHandling: 'merge',
          queryParams: {
            compCode: data.mrepHeadingsPK.rhCompCode,
            repId: data.mrepHeadingsPK.rhRepId,
            action: 'edit'
          }
        });
      }
    }
  }
}
