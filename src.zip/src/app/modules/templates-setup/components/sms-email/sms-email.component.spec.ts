import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmsEmailComponent } from './sms-email.component';

describe('SmsEmailComponent', () => {
  let component: SmsEmailComponent;
  let fixture: ComponentFixture<SmsEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmsEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmsEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
