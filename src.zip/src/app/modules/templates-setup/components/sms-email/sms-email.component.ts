import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
<<<<<<< HEAD
=======
import * as moment from 'moment';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TemplateSetupService } from '../../services/template-setup.service';

@Component({
  selector: 'app-sms-email',
  templateUrl: './sms-email.component.html',
  styleUrls: ['./sms-email.component.scss']
})
export class SmsEmailComponent implements OnInit {

  public defaultColDef;
  smsEmailCols: any[];
  smsEmailDetails: any;
  page: any = '';
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';
  public components;
  constructor(
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private templateService: TemplateSetupService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.smsEmailCols = [
      {
        field: 'smtTempCode',
        headerName: 'Template Code',
        tooltipField: 'smtTempCode',
      },
      {
        field: 'smtTempDesc',
        headerName: 'Template Desc',
        tooltipField: 'smtTempDesc',
      },
      {
        field: 'smtEmailTo',
        headerName: 'Email To',
        tooltipField: 'smtEmailTo',
      },
      {
        field: 'smtCrDt',
<<<<<<< HEAD
        headerName: 'Created date',
        valueFormatter: dateFormatter
      },
      {
        headerName: 'Action',
        template:
          `<a>
                <i class="fa fa-file-pen fa-icon" data-action-type="Edit" title="Edit" (click)="addSmsTemp(true)" aria-hidden="true"></i>
            </a>`,
=======
        headerName: 'Created Date',
        cellRenderer: 'crDateCellRenderer',        
        valueGetter: function (params) {
          if (params && params.data && params.data.smtCrDt) {
            let crDate = new Date(params.data.smtCrDt)
            return  moment(crDate).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,       
      },      
      {
        headerName: 'Action',
        field: 'smtTempCode',
        cellRenderer:  function (params) {
          if (params && params.data && params.data.smtTempCode) {            
            return `<a>
            <i class="fa fa-file-pen fa-icon" data-action-type="Edit" title="Edit" (click)="addSmsTemp(true)" aria-hidden="true"></i>
        </a>`;
          } else {
            return '';
          }
        },       
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        cellStyle: {
          textAlign: 'center'
        },
        resizable: true,
        sortable: false,
        filter: false,
      }
    ];
    this.retrieveSmsEmailTable();
    this.components = {
      crDateCellRenderer: crDateCellRenderer,
      
    };
  }
  retrieveSmsEmailTable() {
    this.templateService.retrieveSmsEmailDetails().subscribe(resp => {
      this.smsEmailDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
     this.toastService.error("Error in Retrive Data")
    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any, ) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("contractTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  addSmsTemp() {
    this.router.navigate(['/templates-setup/smsEmail/add'], { queryParamsHandling: 'merge', queryParams: { action: 'add' } });
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      if (actionType) {
        this.router.navigate(['/templates-setup/smsEmail/edit'], { queryParamsHandling: 'merge', queryParams: { code: data.smtTempCode, action: 'edit' } });
      }
    }
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else {
    return
  }

}
function crDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.smtCrDt).format('DD/MM/YYYY');
  }
}
var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};