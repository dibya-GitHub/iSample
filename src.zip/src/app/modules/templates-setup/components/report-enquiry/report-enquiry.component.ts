import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TemplateSetupService } from '../../services/template-setup.service';

@Component({
  selector: 'app-report-enquiry',
  templateUrl: './report-enquiry.component.html',
  styleUrls: ['./report-enquiry.component.scss']
})

export class ReportEnquiryComponent {
  private defaultColDef;
  reportCols: any[];
  reportDetails: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';

  constructor(
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private templateService: TemplateSetupService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.reportCols = [
      {
        field: 'erTableName',
        headerName: 'Table Name',
        tooltipField: 'erTableName',
      },
      {
        field: 'erShortDesc',
        headerName: 'Short Desc',
        tooltipField: 'erShortDesc',
      },
      {
        field: 'erLongDesc',
        headerName: 'Long Desc',
        tooltipField: 'erLongDesc',
      },
      {
        field: 'erDispSrNo',
        headerName: 'Display SrNo',
        tooltipField: 'erDispSrNo',
      },
      {
        field: 'erCrUid',
        headerName: 'Created By',
        tooltipField: 'erCrUid',
      },
      {
        field: 'erCrDt',
        headerName: 'Created Date',
        valueFormatter: dateFormatter
      },
      {
        headerName: 'Action',
        template:
          `<a>
              <i class="fa fa-file-pen fa-icon" data-action-type="Edit" title="Edit" aria-hidden="true"></i>
          </a>`,
        cellStyle: { textAlign: 'center' },
        resizable: false,
        sortable: false,
        filter: false,
      }
    ]
    this.retrieveReport();
  }
  retrieveReport() {
    this.templateService.retrieveEnqReport().subscribe(resp => {
      this.reportDetails = resp;
       this.loaderService.isBusy = false;
    }, error => {
       this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any, ) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  add() {
    this.router.navigate(['/templates-setup/repEnquiry/add'], { queryParamsHandling: 'merge', queryParams: { action: 'add' } });
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      if (actionType) {
        this.router.navigate(['/templates-setup/repEnquiry/edit'], { queryParamsHandling: 'merge', queryParams: { code: data.erId, action: 'edit' } });
      }
    }
  }
}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return }

}