import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FileUploadModule } from 'ng2-file-upload';
import { ProgressbarModule } from "ngx-bootstrap/progressbar";
import { TabsModule } from 'ngx-bootstrap/tabs';
import { DropdownModule } from 'primeng/dropdown';
import { AuthInterceptor } from 'src/app/services/auth-interceptor';
import { SharedModule } from 'src/shared/shared.module';
import { ClaimBordereauxRoutingModule } from './claim-bordereaux-routing.module';
import { ClaimBordereauxDashboardComponent } from './components/claim-bordereaux-dashboard/claim-bordereaux-dashboard.component';
import { ClaimBordereauxUploadComponent } from './components/claim-bordereaux-upload/claim-bordereaux-upload.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ClaimBordereauxRoutingModule,
    TabsModule.forRoot(),
    FileUploadModule,
    ProgressbarModule.forRoot(),
    DropdownModule
  ],
  declarations: [
    ClaimBordereauxDashboardComponent,
    ClaimBordereauxUploadComponent,
  ],

  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ]
})
export class ClaimBordereauxModule { }
