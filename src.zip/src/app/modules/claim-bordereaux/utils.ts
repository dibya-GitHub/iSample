import { UntypedFormArray, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import * as moment from 'moment';
const decimal: any = "2"//JSON.parse(sessionStorage.getItem('decimalRoundOff'));

export class Utils {

   public static validateAllFormFields(formGroup: UntypedFormGroup | UntypedFormArray) {
      Object.keys(formGroup['controls']).forEach(field => {
         const control = formGroup.get(field);
         if (control instanceof UntypedFormControl) {
            control.markAsTouched({ onlySelf: true });
            control.markAsDirty({ onlySelf: true });
         } else if (control instanceof UntypedFormGroup) {
            this.validateAllFormFields(control);
         } else if (control instanceof UntypedFormArray) {
            this.validateAllFormFields(control as UntypedFormArray);
         }
      });
   }
   public static clean(obj: any): any {
      for (const propName in obj) {
         if (obj[propName] === null || obj[propName] === undefined || obj[propName] === '') {
            delete obj[propName];
         }
      }
      return obj;
   }
   public static currencyFormatter(data) {
      if (data != null) {
         return Intl.NumberFormat('en-US',
            { minimumFractionDigits: decimal }).format((data));
      } else {
         return;
      }
   }

   public static currencyDecimalFormatter(data) {
      if (data.value != null) {
         return Intl.NumberFormat('en-US',
            { minimumFractionDigits: decimal }).format((data.value));
      } else {
         return;
      }
   }
   public static toFixedFun4(data) {
      if (data.value != null && data.value != undefined) {
        let vl = parseFloat(data.value);
        return vl.toFixed(4);
      } else {
        return '0.00';
      }
    }
    
   public static fixedRateFormatter(data) {
      if (data.value != null) {
         return Intl.NumberFormat('en-US',
            { minimumFractionDigits: JSON.parse('6') }).format((data.value));
      } else {
         return;
      }
   }
   public static dateFormatter(params) {
      if (params != null) {
         return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
      } else { return }
   }

   public static formatMilliSecToDate(milliseconds) {
      if (milliseconds) {
         return moment(milliseconds).format("DD/MM/YYYY");
      }
      return '';
   }
   public static tooltipRenderer(params) {
      if (params != null) {
         return '<span title="' + params.value + '">' + params.value + '</span>';
      } else { return '' }

   }
}