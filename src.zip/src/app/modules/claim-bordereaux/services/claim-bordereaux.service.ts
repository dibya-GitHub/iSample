import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { Observable, Subject } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ClaimBordereauxService {
  companyCode: any;
  public requestHeaders;
  mgaUrl: any = environment.mgaUrl;
  commonUrl = environment.mgaCommonUrl;
  mgaFinanceUrl = environment.mgaFinanceUrl;
  dmsBaseUrl = environment.dmsBaseUrl;
  uploadNewClk = new Subject<any>();
  constructor(
    private httpService: HttpClient,
    private session: SessionStorageService
  ) {
    this.companyCode = this.session.get('companyCode');
    this.requestHeaders = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })
    { }
  }

  getBatchInfo(): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.BORDERX_BATCH_INFO, this.requestHeaders);
  }

  getClaimBdx(batchId): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'clmSummBdx/' + batchId, this.requestHeaders);
  }

  getBinderRefId(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'binderRefId?companyCode=QIC')
  }

  getMgaCode(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customers/MGA', this.requestHeaders);
  }
  getMGAlist(): Observable<any> {
    return this.httpService.get(this.commonUrl + 'appcodes-mgmt/appcodes/MGA_TYPE', this.requestHeaders);
  }
  claimReadAndUploadDoc(binderRefId, batchId, formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + "clmSummBdx/readAndUploadDoc?binderRefId=" + binderRefId + "&batchId=" + batchId, formData);
  }

  searchClaim(data): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'clmSummBdx/batchinfo/filtersearch', data)
  }

  //#################### CLAIM bordereaux Upload services #############################
  readAndUploadDoc(formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + "clmSummBdx/readAndUploadDoc", formData);
  }

  getUploadNewClk() {
    return this.uploadNewClk.asObservable();
  }

  setUploadNewClk(data) {
    this.uploadNewClk.next(data);
  }

  exportExcel(gridFSId): Observable<any> {
    return this.httpService.get(this.dmsBaseUrl + gridFSId + "?companyCode=QIC", this.requestHeaders);
  }


  approveClaim(batchId): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'clmSummBdx/approve/' + batchId, this.requestHeaders);
  }

  deleteClaim(batchId): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'clmSummBdx/delete/' + batchId, this.requestHeaders)
  }

  getAccountDetails(accId): Observable<any> {
    return this.httpService.get('http://192.168.80.64:6002/binder/clmSummBdx/AccDocId/5512')
    // return this.httpService.get(this.mgaUrl + 'clmSummBdx/AccDocId/' + accId)
  }

  reverseClaim(batchId, data): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'clmSummBdx/reverse/' + batchId, data)
    // return this.httpService.put(this.mgaUrl + 'clmSummBdx/reverse/' + batchId, data)
  }
  viewClaimAccoutingDetails(batchId): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'premSummBdx/viewAccount/accBatchDocId/' + batchId);
  }
  fetchClaimBoardReportParamList(obj: any): Observable<any> {
    return this.httpService.get<any>(this.mgaUrl + ApiUrls.REPORT_PARAM_MGMT_PATH + "/" + ApiUrls.INSTANCE + "/" + obj.instId + "/" + ApiUrls.REPORT_MAPPING_PATH + "/" + obj.compCode + "?divn=" + obj.divn + "&tranType=" + obj.tranType, this.requestHeaders);
  }

  fetchClaimBoardReportUrl(obj: any): Observable<any> {
    return this.httpService.get<any>(this.mgaUrl + ApiUrls.REPORT_PARAM_MGMT_PATH + "/" + ApiUrls.REPORT_URL_MAPPING_PATH + "/" + obj.refNo + "?amendNo=" + obj.amendNo + "&repId=" + obj.repId + "&compCode=" + obj.compCode + "&docType=" + obj.docType + "&seqNo=" + obj.seqNo, this.requestHeaders);
  }

  getDocuments(file): Observable<any> {
    const params: any = {};
    params.responseType = 'arrayBuffer';
    return this.httpService.get(this.dmsBaseUrl + '/api/document/' + file, params);
  }

  getClaimCoInsDetails(data): Observable<any> {
    return this.httpService.get(this.mgaUrl + "clmSummBdx/viewCoinsuranceAcnt/" + data.tcsBatId + "/" + data.tcsBindRefNo + "/" + data.tcsAcntYear + "/" + data.tcsDivnCode + "/" + data.tcsLobCode + "/" + data.tcsProdCode + "/" + data.tcsSrNo);
  }
  progress(data): Observable<any> {
    return this.httpService.get(this.mgaUrl + "progress/" + data + '/C');
  }
  uploadProgress(batchId): Observable<any> {
    return this.httpService.get(this.mgaUrl + "progress/" + batchId + '/C');
  }
  uploadHistory(batchId, status): Observable<any> {
    return this.httpService.get(this.mgaUrl + "premclmSummBdx/uploadhistory/" + batchId + '/' + status);
  }
  validateChecksum(formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + "clmSummBdx/validateChecksum", formData);
  }
  checkSumUploadHistory(batchId): Observable<any> {
    return this.httpService.get(this.mgaUrl + "checksum/uploadhistory/" + batchId );
  }
}
