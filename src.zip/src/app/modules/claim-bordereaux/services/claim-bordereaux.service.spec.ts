import { TestBed } from '@angular/core/testing';

import { ClaimBordereauxService } from './claim-bordereaux.service';

describe('ClaimBordereauxService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClaimBordereauxService = TestBed.get(ClaimBordereauxService);
    expect(service).toBeTruthy();
  });
});
