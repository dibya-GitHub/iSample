import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimBordereauxUploadComponent } from './claim-bordereaux-upload.component';

describe('ClaimBordereauxUploadComponent', () => {
  let component: ClaimBordereauxUploadComponent;
  let fixture: ComponentFixture<ClaimBordereauxUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimBordereauxUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimBordereauxUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
