import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { FileUploader } from 'ng2-file-upload';
import { BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { DocumentService } from 'src/app/shared/components/document/document.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { MgaDocumentsComponent } from 'src/shared/components/mga-documents/mga-documents.component';
import { ClaimBordereauxService } from '../../services/claim-bordereaux.service';
import { Utils } from './../../utils';

@Component({
  selector: 'claim-bordereaux-upload',
  templateUrl: './claim-bordereaux-upload.component.html',
  styleUrls: ['./claim-bordereaux-upload.component.scss']
})
export class ClaimBordereauxUploadComponent implements OnInit {
  batchId;
  docNo;
  tranNo;
  currencyCode: any;
  batchInfoDTOForm: UntypedFormGroup;
  batchInfo: any;
  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public coInsDefaultColDef;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  batchInfoList: any;
  paginationPageSize: number;
  rowGroupPanelShow: string;
  fileList;
  public uploadNewSubscribers: any = {};
  uploadNewData: any;
  errorNos: any;
  public modules = [ClientSideRowModelModule];
  public hasBaseDropZoneOver = false;

  status: any;
  downloadLink;

  documents: any;
  isDocumentNeedsToBeUpdated: any;
  documentRefId: string;
  documentTypes: any[];
  @ViewChild('batchUploadModal1') batchUploadModal1: ElementRef;
  @ViewChild('validateCheckSumModal2') validateCheckSumModal2: ElementRef;
  @ViewChild('confirmModal3') confirmModal3: ElementRef;
  @ViewChild('uploadHistory4') uploadHistory4: ElementRef;
  @ViewChild('apprConfirmModal5') apprConfirmModal5: ElementRef;
  @ViewChild('batchReverseModal6') batchReverseModal6: ElementRef;
  @ViewChild('batchDeleteModal7') batchDeleteModal7: ElementRef;
  @ViewChild('errorModal8') errorModal8: ElementRef;
  @ViewChild('checksumUploadHistory9') checksumUploadHistory9: ElementRef;

  appvBtnDisable: boolean = false;
  claimStatus: any;
  cStatus: any;
  hideErrorColumn: boolean = true;
  getRowStyle: any;
  title;
  @ViewChild(MgaDocumentsComponent) uploadDoc: MgaDocumentsComponent;
  docMetadata: any;
  listOfFiles: any;
  isreUpload: boolean = false;
  insPercentage: any;
  postpercentage: number;
  progressList: any;
  postingList: any;
  id: any;
  enableProgressBar: boolean = false;
  uploadHistoryData: any = [];
  showCoInsEntriesOptionSelected = 10;
  coinsuranceGridApi: any;
  quickCoinsuranceSearchValue: string = '';
  pinnedBottomRowData: any;
  coinsuranceColumnDefs: any;
  coinsuranceList: any;
  showCoinsuranceDetail = false;
  batchUploadForm: UntypedFormGroup;
  missingDocType: boolean = false;
  errorDescription: any;
  selectedCoinsurance = null;
  coInsGridColumnApi: any;

  isValidateCheckSum: boolean = false;
  validateCheckSumData: any = {};
  errorCheckSum: any;
  checksumDisable: any = false;
  isView: Boolean = false;
  checksumUploadHistoryData: any;
  constructor(
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private router: Router,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private claimBorderxService: ClaimBordereauxService,
    private treatyService: TreatyService,
    private modalService: BsModalService,
    private activeRoute: ActivatedRoute,
    private docService: DocumentService,

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.coInsDefaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false
    };

    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };

    this.uploadNewSubscribers = this.claimBorderxService.getUploadNewClk().subscribe((data) => {
      this.uploadNewData = data;
      this.batchId = this.uploadNewData.batchInfoDTO.tbiBatId;
      this.errorNos = Number(this.uploadNewData.batchInfoDTO.tbiFlex04);
      this.status = this.uploadNewData.batchInfoDTO.tbiApprSts;
      this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
      this.appvBtnDisable = (this.status == 'A') ? true : false;
      if (this.status !== 'A') {
        if (this.errorNos == 0) {
          if (this.uploadNewData.isChecksumValidationRequired) {
            this.checksumDisable = this.uploadNewData.isChecksumValidationRequired
          } else {
            this.checksumDisable = this.uploadNewData.isChecksumValidationRequired;
          }
        } else {
          this.checksumDisable = false;
        }
      }
      this.documentRefId = this.uploadNewData.batchInfoDTO.tbiBatType + '-' + this.uploadNewData.batchInfoDTO.tbiBatId;
      this.downloadLink = this.uploadNewData.batchInfoDTO.tbiFlex03;
      this.batchInfoList = this.uploadNewData.csbDTOs;

      this.createbatchInfoDTOForm();
      this.agGridOptions();

      if (this.errorNos > 0) {
        this.loaderService.isBusy = false;
        this.downloadErrorFile(this.downloadLink, this.uploadNewData.docMetadata.fileName);
        this.hideErrorColumn = false;
        this.status = 'P'
      } else {
        this.hideErrorColumn = true;
        //this.status = 'P'
      }
      this.setFunctionalCurrency();
      setTimeout(() => {
        this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
      }, 1000);
    }, error => {
      this.toastService.error('Something Wrong !!!');
      this.loaderService.isBusy = false;
    })
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.currencyCode = this.session.get('baseCurrency');
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (params) {
        this.isView = params.isView;
        this.batchId = params.batchId;
        this.title = params.title;
      }
    });
    this.createBatchUploadForm();
    if (this.title === 'claimBack') {
      this.loaderService.isBusy = true;
      this.createbatchInfoDTOForm();
    }
    const context = this;
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (this.batchId != null) {
        this.claimBorderxService.getClaimBdx(this.batchId).subscribe((data: any) => {
          this.loaderService.isBusy = true;
          this.uploadNewData = data;
          this.batchId = this.uploadNewData.batchInfoDTO.tbiBatId;
          this.errorNos = Number(this.uploadNewData.batchInfoDTO.tbiFlex04);
          this.status = this.uploadNewData.batchInfoDTO.tbiApprSts;
          this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
          this.appvBtnDisable = (this.status == 'A') ? true : false;
          // if (this.status !== 'A') {
          //   this.checksumDisable = this.uploadNewData.isChecksumValidationRequired;
          // }
          if (this.status !== 'A') {
            if (this.errorNos == 0) {
              if (this.uploadNewData.isChecksumValidationRequired) {
                this.checksumDisable = this.uploadNewData.isChecksumValidationRequired
              } else {
                this.checksumDisable = this.uploadNewData.isChecksumValidationRequired;
              }
            } else {
              this.checksumDisable = false;
            }
          }
          this.documentRefId = this.uploadNewData.batchInfoDTO.tbiBatType + '-' + this.uploadNewData.batchInfoDTO.tbiBatId;
          this.downloadLink = this.uploadNewData.batchInfoDTO.tbiFlex03;
          this.batchInfoList = this.uploadNewData.csbDTOs;
          this.createbatchInfoDTOForm();
          this.agGridOptions();

          if (this.errorNos > 0) {
            this.loaderService.isBusy = false;
            this.downloadErrorFile(this.downloadLink, this.uploadNewData.docMetadata.fileName);
            this.hideErrorColumn = false;
            this.status = 'P'
          } else {
            this.hideErrorColumn = true;
          }
          this.setFunctionalCurrency();
          setTimeout(() => {
            this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
          }, 1000);
          if (this.title === 'claimBack') {
            this.viewAccountBack(data);
          }
          this.loaderService.isBusy = false;

        }, error => {
          this.showErrorDialogBox(error.error.message);
          this.loaderService.isBusy = false
        })
      } else {
        this.loaderService.isBusy = false;
      }
    });
    this.columnDefs = [
      {
        field: 'tcsBindRefNo',
        headerName: 'Contract Ref No',
        headerTooltip: 'Contract Ref No',
        width: 95,
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.data && params.data.tcsContractType == "2") {
            return '<span data-action-type="Coinsurance" style="textAlign: left;color: #036aff;font-weight: bold;text-decoration: underline;text-decoration-color: #036aff;cursor: pointer">' + params.value + '</span>';
          } else if (params.data && params.data.tcsContractType == "1") {
            return '<span data-action-type="Direct">' + params.value + '</span>';
          } else {
            return params.value;
          }
        },
        valueGetter: function (params) {
          if (params.data && params.data.tcsBindRefNo) {
            return params.data.tcsBindRefNo + ' / ' + params.data.tcsBindSeqNo + ' / ' + params.data.tcsBindAmendNo;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tcsContractTypeDesc',
        headerName: 'Contract Type',
        headerTooltip: 'Contract Type',
        cellStyle: { textAlign: 'left' },
        width: 110
      },
      {
        field: 'tcsMgaCodeDesc',
        headerName: 'Sub MGA Code & Name',
        headerTooltip: 'Sub MGA Code & Name',
        tooltipField: 'tcsMgaCodeDesc',
        cellStyle: { textAlign: 'center' },
        width: 110,
      },
      {
        field: 'tcsDivnCodeDesc',
        headerName: 'Company',
        headerTooltip: 'Company',
        width: 130,
        cellRenderer: Utils.tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.tcsDivnCode && params.data.tcsDivnCodeDesc) {
            return params.data.tcsDivnCode + ' - ' + params.data.tcsDivnCodeDesc;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tcsLobCode',
        headerName: 'Product type/LOB',
        headerTooltip: 'Product type/LOB',
        cellRenderer: Utils.tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.tcsLobCode && params.data.tcsLobCodeDesc) {
            return params.data.tcsLobCode + ' - ' + params.data.tcsLobCodeDesc;
          } else {
            return "";
          }
        },
        width: 110,
      },
      {
        field: 'tcsProdCodeDesc',
        headerName: 'Product Group/Subproduct',
        headerTooltip: 'Product Group/Subproduct',
        cellStyle: { textAlign: 'center' },
        width: 110,
        enableRowGroup: true,
        cellRenderer: Utils.tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.tcsProdCode) {
            return params.data.tcsProdCode + ' - ' + params.data.tcsProdCodeDesc;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tcsAcntYear',
        headerName: 'Year of Acnt',
        headerTooltip: 'Year of Acnt',
        cellStyle: { textAlign: 'center' },
        width: 110,
      },
      {
        field: 'tcsLedgDesc',
        headerName: 'Ledger Desc',
        cellStyle: { textAlign: 'left' },
        tooltipField: 'tcsLedgDesc',
        enableRowGroup: true,
        headerTooltip: 'Ledger Desc',
      },
      {
        field: 'tcsCurr',
        headerName: 'Currency',
        cellStyle: { textAlign: 'center' },
        tooltipField: 'tcsCurr',
        enableRowGroup: true,
        headerTooltip: 'Currency',
      },
      {
        field: 'tcsExchangeRate',
        headerName: 'Exchange Rate',
        cellStyle: { textAlign: 'right' },
        tooltipField: 'tcsExchangeRate',
        valueFormatter: Utils.fixedRateFormatter,
        headerTooltip: 'Exchange Rate',
      },
      {
        field: 'tcsPaidFc',
        width: 110,
        headerName: 'Gross Claims Paid',
        headerTooltip: 'Gross Claims Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tcsPaidFc) {
            return Number(params.data.tcsPaidFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsPaidFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },

      },
      {
        field: 'tcsRecFc',
        width: 110,
        headerName: 'Recovery Paid',
        headerTooltip: 'Recovery Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tcsRecFc) {
            return Number(params.data.tcsRecFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsRecFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tcsNetPaidFc',
        width: 110,
        headerName: 'Net Claims Paid',
        headerTooltip: 'Net Claims Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tcsNetPaidFc) {
            return Number(params.data.tcsNetPaidFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsNetPaidFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tcsPayEstFc',
        width: 110,
        headerName: 'Gross Claims Reserves',
        headerTooltip: 'Gross Claims Reserves',
        valueGetter: function (params) {
          if (params.data && params.data.tcsPayEstFc) {
            return Number(params.data.tcsPayEstFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsPayEstFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tcsRecEstFc',
        width: 110,
        headerName: 'Recovery Reserves',
        valueGetter: function (params) {
          if (params.data && params.data.tcsRecEstFc) {
            return Number(params.data.tcsRecEstFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsRecEstFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
        headerTooltip: 'Recovery Reserves',
      },
      {
        field: 'tcsNetOsFc',
        width: 110,
        headerName: 'Net Claims Reserves',
        valueGetter: function (params) {
          if (params.data && params.data.tcsNetOsFc) {
            return Number(params.data.tcsNetOsFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsNetOsFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
        headerTooltip: 'Net Claims Reserves',
      },
      {
        headerName: 'Error Details',
        headerTooltip: 'Error Details',
        field: 'tcsErrorMsg',
        tooltipField: 'tcsErrorMsg',
        cellRenderer: function (params) {
          if (params && params.data && params.data.tcsErrorMsg) {
            return `<a><i class="fa fa-eye" style="transform: scaleX(-1);"  data-action-type="ViewEye" title="Click to View Error Details" aria-hidden="true"></i>&nbsp;</a>` + ' ' + params.data.tcsErrorMsg;
          } else {
            return '';
          }
        },
        width: 110,
        resizable: true,
        sortable: true,
        filter: false,
        enableRowGroup: false,
        hide: this.hideErrorColumn
      }
    ];


    this.context = { componentParent: this };
    //this.loaderService.isBusy = false;
    this.getDocumentTypes();
    this.getApproveStatus();
    // coinsurer //
    this.setCoinsuranceColumnDefs();
    // coinsurer // 
  }

  viewAccountBack(data) {
    this.loaderService.isBusy = true;
    this.uploadNewData = data;
    this.batchId = this.uploadNewData.batchInfoDTO.tbiBatId;
    this.errorNos = Number(this.uploadNewData.batchInfoDTO.tbiFlex04);
    this.status = this.uploadNewData.batchInfoDTO.tbiApprSts;
    this.appvBtnDisable = (this.status == 'A') ? true : false;
    this.documentRefId = this.uploadNewData.batchInfoDTO.tbiBatType + '-' + this.uploadNewData.batchInfoDTO.tbiBatId;
    this.downloadLink = this.uploadNewData.batchInfoDTO.tbiFlex03; //this.uploadNewData.errorFile;
    this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
    this.batchInfoList = this.uploadNewData.csbDTOs;
    this.agGridOptions();
    if (this.errorNos > 0) {
      this.downloadErrorFile(this.downloadLink, this.uploadNewData.docMetadata.fileName);
      this.hideErrorColumn = false;
      this.status = 'P'
    } else {
      this.hideErrorColumn = true;
      //this.status = 'P'
    }
    this.setFunctionalCurrency();
    this.getApproveStatus();
  }

  getApproveStatus() {
    if (this.status == 'A') {
      this.cStatus = 'Approved';
    } else if (this.status == 'R') {
      this.cStatus = 'Reversed';
    } else {
      this.cStatus = 'Pending';
    }
  }
  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res;
      }, err => {
      });
  }
  createbatchInfoDTOForm() {
    this.batchInfoDTOForm = this.fb.group({
      tbiPaidLc1: '',
      tbiPayEstLc1: '',
      tbiRecEstLc1: '',
      tbiRecLc1: '',
      tbiNetPaidLc1: '',
      tbiNetOs: '',
    })
  }

  back() {
    this.router.navigate(['/claim-bordereaux'], { queryParams: { title: 'home' } });
  }
  upload() {

  }

  approve() {
    this.loaderService.isBusy = true;
    this.checkDocsBeforeApprove();
  }

  deleteClaim() {
    this.loaderService.isBusy = true;
    this.claimBorderxService.deleteClaim(this.batchId).subscribe(res => {
      document.getElementById('closeDelete').click();
      this.getFileListDoc();
      this.toastService.success('Deleted successfully');
      this.router.navigate(['/claim-bordereaux'], { queryParams: { title: 'home' } });
      this.loaderService.isBusy = false;
    }, error => {
      if (error.error["messageType"] && error.error["messageType"] == 'E') {
        this.showErrorDialogBox(error.error.message);
        document.getElementById('closeDelete').click();
        this.loaderService.isBusy = false;
      }
      this.loaderService.isBusy = false;
    })
  }
  checkDocsBeforeApprove() {
    this.docService.getMetaDataSearch(this.docMetadata).subscribe((data: any) => {
      if (data.length == 0) {
        this.toastService.error('Batch cannot be approved without documentation. Please upload the relevant documents prior to approval.');
        document.getElementById('closeApprove').click();
        this.loaderService.isBusy = false;
      } else {
        this.loaderService.isLoadingShow = 'approvalTemplate';
        this.claimBorderxService.approveClaim(this.batchId).subscribe((res: any) => {
          if (res["messageType"] && res["messageType"] == 'E') {
            document.getElementById('closeApprove').click();
            this.showErrorDialogBox(res.apprErrorMsg)
            this.getApproveStatus();
            // this.toastService.error('Not approved');
            this.loaderService.isBusy = false;
            this.loaderService.isLoadingShow = '';

          } else {
            this.toastService.success('Approved Successfully.');
            document.getElementById('closeApprove').click();
            this.appvBtnDisable = true;
            this.status = 'A';
            this.getApproveStatus();
            this.loaderService.isBusy = false;
            this.loaderService.isLoadingShow = '';
          }
        }, error => {
          if (error.error["messageType"] && error.error["messageType"] == 'E') {
            // document.getElementById('closeApprove').click();
            this.closeModal(5);
            this.showErrorDialogBox(error.error.message)
            this.getApproveStatus();
            // this.toastService.error('Not approved');
            this.loaderService.isBusy = false;
            this.loaderService.isLoadingShow = '';
          }
          this.loaderService.isBusy = false;
          this.loaderService.isLoadingShow = '';
        });
      }
    },
      err => {
        this.toastService.error('Error getting document(s).');
        this.loaderService.isBusy = false;
      }
    );
  }
  getFileListDoc() {
    this.docService.getMetaDataSearch(this.docMetadata).subscribe(data => {
      this.listOfFiles = data;
      if (this.listOfFiles.length > 0) {
        this.listOfFiles.forEach(element => {
          this.uploadDoc.confirmDelete(element.gridFSId);
        });
      }
    },
      err => {
        this.toastService.error('Error getting document(s).');
      }
    );
  }
  openReversePopup() {
    this.open(this.batchReverseModal6, 6, 'modal-md');
  }
  closeModal(id) {
    this.modalService.hide(id);
  }
  reverseClaim() {
    let data;
    this.loaderService.isBusy = true;
    this.loaderService.isLoadingShow = 'reversalTemplate';
    this.claimBorderxService.reverseClaim(this.batchId, data).subscribe(res => {
      this.claimBorderxService.getClaimBdx(this.batchId).subscribe(res => {
        this.status = res.batchInfoDTO.tbiApprSts;
        this.getApproveStatus();
      })
      this.loaderService.isBusy = false;
      this.loaderService.isLoadingShow = '';
      this.toastService.success('Reversed successfully');
      this.closeModal(6);
    }, error => {
      if (error.error["messageType"] && error.error["messageType"] == 'E') {
        this.showErrorDialogBox(error.error.message);
        this.loaderService.isBusy = false;
        this.loaderService.isLoadingShow = '';
      } else {
        this.toastService.error('Error reverse record');
        this.loaderService.isBusy = false;
        this.loaderService.isLoadingShow = '';
      }
    })
  }

  closeClaim() {
    this.router.navigate(['/claim-bordereaux'], { queryParams: { title: 'home' } });
  }
  viewAccounting() {
    this.router.navigate(['/mga-view-accounting'], { queryParams: { batchId: this.batchId, binder: 'BIND_CLM', status: this.status } });
  }

  setFunctionalCurrency() {
    let data = this.uploadNewData.batchInfoDTO;
    let netClaimsPaid = data.tbiPaidLc1 - data.tbiRecLc1;
    let netClaims = data.tbiPayEstLc1 - data.tbiRecEstLc1;
    this.batchInfoDTOForm.patchValue({
      tbiPaidLc1: Utils.currencyFormatter(data.tbiPaidLc1),
      tbiPayEstLc1: Utils.currencyFormatter(data.tbiPayEstLc1),
      tbiRecEstLc1: Utils.currencyFormatter(data.tbiRecEstLc1),
      tbiRecLc1: Utils.currencyFormatter(data.tbiRecLc1),
      tbiNetPaidLc1: Utils.currencyFormatter(netClaimsPaid),
      tbiNetOs: Utils.currencyFormatter(netClaims),
    });
    this.batchInfoDTOForm.disable();
    this.batchId = data.tbiBatId;
    this.docNo = data.tbiDocNo;
    this.tranNo = data.tbiTranCode;
    this.claimStatus = this.uploadNewData.batchInfoDTO.tbiApprSts;
    this.loaderService.isBusy = false;
  }

  onRowClickedPro(evt) {
    this.errorDescription = evt.data.tcsErrorMsg;
    let actionType = evt.event.target.getAttribute('data-action-type');
    switch (actionType) {
      case 'ViewEye':
        return this.showDialogbox(this.errorDescription);
      case 'Coinsurance':
        if (evt.data && evt.data.tcsContractType == "2") {
          this.selectedCoinsurance = evt.data;
          this.getCoinsurerDetails();
        } else {
          this.showCoinsuranceDetail = false;
        }
        break;
      case 'Direct':
        if (evt.data && evt.data.tcsContractType == "1") {
          this.showCoinsuranceDetail = false;
        }
        break;
    }
  }
  openDeleteClaim() {
    this.open(this.batchDeleteModal7, 7, 'modal-md');
  }
  showDialogbox(data: any) {
    this.open(this.confirmModal3, 3, 'modal-sm');
    setTimeout(() => {
      const str = this.errorDescription.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  showErrorDialogBox(apprErrorMsg) {
    this.open(this.errorModal8, 8, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  showUploadHistoryDialogBox() {
    this.open(this.uploadHistory4, 4, 'modal-md');
    this.claimBorderxService.uploadHistory(this.batchId, this.status).subscribe(res => {
      this.uploadHistoryData = res;
      if (this.uploadHistoryData && this.uploadHistoryData.length == 0) {
        document.getElementById("uploadHistoryDetails").style.display = 'none';
        document.getElementById("uploadHistoryDetails1").innerHTML += "<p>No Data Available </p>";
      } else {
        document.getElementById("uploadHistoryDetails").style.display = 'block';
      }
    }, error => {
      this.toastService.error('Error in getting Upload History');
      this.loaderService.isBusy = false;
    });
  }

  showChecksumUploadHistoryDialogBox() {
    this.open(this.checksumUploadHistory9, 9, 'modal-lg');
    this.claimBorderxService.checkSumUploadHistory(this.batchId).subscribe(res => {
      this.checksumUploadHistoryData = res;
      if (this.checksumUploadHistoryData && this.checksumUploadHistoryData.length == 0) {
        document.getElementById("checksumUploadHistoryDetails").style.display = 'none';
        document.getElementById("checksumUploadHistoryDetails1").innerHTML += "<p>No Data Available </p>";
      } else {
        document.getElementById("checksumUploadHistoryDetails").style.display = 'block';
      }
    }, error => {
      this.toastService.error('Error in getting Upload History');
      this.loaderService.isBusy = false;
    });
  }

  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val });
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    const params = {
      columnKeys: ['tcsBindRefNo', 'tcsContractTypeDesc', 'tcsMgaCodeDesc', 'tcsDivnCodeDesc', 'tcsLobCode', 'tcsProdCodeDesc', 'tcsAcntYear', 'tcsLedgDesc', 'tcsCurr', 'tcsExchangeRate', 'tcsPaidFc', 'tcsRecFc', 'tcsNetPaidFc', 'tcsPayEstFc', 'tcsRecEstFc', 'tcsNetOsFc']
    };
    if (!this.hideErrorColumn) {
      params.columnKeys.push('tcsErrorMsg');
    }
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        fileName: 'Claim_Summary.xlsx',
        skipHeader: false,
        sheetName: 'Claim Summary',
        processCellCallback: (params) => {
          if (params.column.colId == "tcsPaidFc" || params.column.colId == "tcsRecFc"
            || params.column.colId == "tcsNetPaidFc" || params.column.colId == "tcsPayEstFc" || params.column.colId == "tcsRecEstFc"
            || params.column.colId == "tcsNetOsFc") {
            if (params.value) {
              return parseFloat((params.value).replace(/,/g, ''));
            } else {
              return "";
            }
          } else {
            return params.value;
          }
        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('mgadashboard').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: this.batchInfoList,
      enableFilter: true,
      rowClassRules: {
        'ag-red-pink-outer': function (params) {
          if (params.data !== undefined) {
            if (params.data.tcsErrorMsg != null) {
              return true;
            } else {
              return false;
            }
          }
        }
      }
    };

    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
  }

  downloadErrorFile(file: any, filename: any) {
    this.claimBorderxService.getDocuments(file).subscribe((data: any) => {
      const blob = new Blob([data], { type: 'application/vnd.ms.excel' });
      const url = window.URL.createObjectURL(blob);
      document.getElementById("excelDownloadLink").innerHTML = "<a class='pr-8' href='" + url + "' download='" + filename + "'>" +
        "<i class='fa fa-download fa-icon' style='padding: 10px;' aria-hidden='true'></i></a>";
    },
      err => {
        this.toastService.error('Error downloading document(s).');
      }
    );
  }
  downloadDocument(file: any) {
    this.docService.getDocuments(file.tbiFlex08).subscribe((data) => {
      const blob = new Blob([data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.tbiFlex10;
      document.body.appendChild(a);
      a.click();
    },
      err => {
        this.toastService.error('Error downloading document(s).');
      }
    );
  }
  downloadChecksumFile(file: any) {
    this.docService.getDocuments(file.tuhFlex01).subscribe((data) => {
      const blob = new Blob([data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.tuhFileName;
      document.body.appendChild(a);
      a.click();
    },
      err => {
        this.toastService.error('Error downloading document(s).');
      }
    );
  }
  setCoinsuranceColumnDefs() {

    this.coinsuranceColumnDefs = [
      {
        field: 'tccCustCodeDesc',
        headerName: 'Coinsurer',
        headerTooltip: 'Coinsurer',
        width: 150,
        lockPosition: true,
        cellStyle: { textAlign: 'left' },
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.tccCustCode && params.data.tccCustCodeDesc) {
            return params.data.tccCustCode + ' - ' + params.data.tccCustCodeDesc;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tccLeaderYn',
        headerName: 'Leader',
        headerTooltip: 'Leader',
        width: 50,
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tccLeaderYn) {
            if (params.data.tccLeaderYn == "1") {
              return 'Yes';
            } else {
              return 'No';
            }
          } else {
            return "";
          }
        },
      },
      {
        field: 'tccSharePerc',
        headerName: 'Share %',
        headerTooltip: 'Share %',
        valueFormatter: Utils.toFixedFun4,
        width: 50,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tcsPaidFc',
        width: 95,
        cellStyle: { textAlign: 'right' },
        headerName: 'Claim Paid',
        headerTooltip: 'Claim Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tcsPaidFc) {
            return Number(params.data.tcsPaidFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsPaidFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tcsRecFc',
        headerName: 'Claim Recovery',
        headerTooltip: 'Claim Recovery',
        valueGetter: function (params) {
          if (params.data && params.data.tcsRecFc) {
            return Number(params.data.tcsRecFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsRecFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        width: 95,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tcsNetPaidFc',
        headerName: 'Net Claim Paid',
        headerTooltip: 'Net Claim Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tcsNetPaidFc) {
            return Number(params.data.tcsNetPaidFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsNetPaidFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        width: 95,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tcsPayEstFc',
        headerName: 'Payment Reserve',
        headerTooltip: 'Payment Reserve',
        valueGetter: function (params) {
          if (params.data && params.data.tcsPayEstFc) {
            return Number(params.data.tcsPayEstFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsPayEstFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        width: 150,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tcsRecEstFc',
        headerName: 'Recovery Reserve',
        headerTooltip: 'Recovery Reserve',
        valueGetter: function (params) {
          if (params.data && params.data.tcsRecEstFc) {
            return Number(params.data.tcsRecEstFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsRecEstFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        width: 150,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tcsNetOsFc',
        headerName: 'Net Claim OS',
        headerTooltip: 'Net Claim OS',
        valueGetter: function (params) {
          if (params.data && params.data.tcsNetOsFc) {
            return Number(params.data.tcsNetOsFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tcsNetOsFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        width: 95,
        cellStyle: { textAlign: 'right' }
      }
    ];

  }

  getCoinsurerDetails() {

    this.loaderService.isBusy = true;
    this.claimBorderxService.getClaimCoInsDetails(this.selectedCoinsurance).subscribe(res => {
      this.coinsuranceList = res;
      this.loaderService.isBusy = false;
      this.pinnedBottomRowData = createData(1, this.coinsuranceList, "Bottom");
      this.showCoinsuranceDetail = true;
    }, error => {
      this.toastService.error('Error in loading coinsurance details!');
      this.loaderService.isBusy = false;
    });
  }

  displayedCoInsRowCount() {
    if (this.coinsuranceGridApi) {
      return this.coinsuranceGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  pageCoInsChanged(event: any): void {
    this.coinsuranceGridApi.paginationGoToPage(event.page - 1);
  }

  onCoInsPaginationCountChange(event: any) {
    this.coinsuranceGridApi.paginationSetPageSize(this.showCoInsEntriesOptionSelected);
    this.coinsuranceGridApi.paginationGoToPage(0);
  }

  onQuickFilterCoinsuranceChanged() {
    this.coinsuranceGridApi.setQuickFilter(this.quickCoinsuranceSearchValue);
  }

  onCoInsBtExport() {
    if (this.coinsuranceGridApi) {
      this.coinsuranceGridApi.exportDataAsExcel({
        fileName: 'Claim_Summary_Coinsurance.xlsx',
        skipHeader: false,
        sheetName: 'Claim Summary Coinsurance',
        processCellCallback: (params) => {
          if (params.column.colId == "tcsPaidFc" || params.column.colId == "tcsRecFc" 
          || params.column.colId == "tcsNetPaidFc" || params.column.colId == "tcsPayEstFc" 
          || params.column.colId == "tcsRecEstFc"|| params.column.colId == "tcsNetOsFc") {
            if (params.value) {
              return parseFloat((params.value).replace(/,/g, ''));
            } else {
              return "";
            }
          } else {
            return params.value;
          }
        },
      });
    }
  }

  onCoInsuranceGridSizeChanged(params) {
    var gridWidth = document.getElementById('coinsuranceGrid').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onCoInsuranceGridReady(params) {
    this.coinsuranceGridApi = params.api;
    this.coInsGridColumnApi = params.columnApi;
  }

  onCoInsRowClicked(evt) {
  }

  openUploadPopup() {
    this.isreUpload = true;
    if (this.id) {
      clearInterval(this.id);
    }
    this.enableProgressBar = false;
    this.batchUploadForm.reset();
    this.fileList = [];
    this.batchUploadForm.patchValue({
      binderRefId: (this.uploadNewData.refId) ? this.uploadNewData.refId : "",
      batchId: (this.uploadNewData.batchInfoDTO.tbiBatId) ? this.uploadNewData.batchInfoDTO.tbiBatId : ""
    });
    this.open(this.batchUploadModal1, 1, 'modal-md')

  }
  validateCheckSum() {
    this.isValidateCheckSum = true;
    if (this.id) {
      clearInterval(this.id);
    }
    this.enableProgressBar = false;
    this.batchUploadForm.reset();
    this.fileList = [];
    this.batchUploadForm.patchValue({
      batchId: (this.batchId) ? this.batchId : ""
    });
    this.open(this.validateCheckSumModal2, 2, 'modal-md');
  }
  createBatchUploadForm() {
    this.batchUploadForm = this.fb.group({
      binderRefId: '',
      bindRefNo: "",
      bindSeqNo: "",
      bindAmendNo: "",
      binderMgaCode: "",
      batchId: ""
    });
  }

  removeFile(index) {
    this.fileList.splice(index, 1);
  }
  cancelUpload() {
    if (this.id) {
      clearInterval(this.id);
    }
    this.closeModal(1);
    this.closeModal(2);
  }
  formatFileSize(bytes, decimalPoint) {
    if (bytes == 0) return '0 KB';
    var k = 1000,
      dm = decimalPoint || 2,
      sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  uploadBatchFile(type) {
    if (this.batchId == null) {
      this.getFileListDoc();
    }
    if (this.batchUploadForm.valid) {
      this.loaderService.isBusy = true;
      // this.docMetadata = undefined;
      let data = this.batchUploadForm.getRawValue();
      let formData = new FormData();
      this.batchId = data.batchId;
      this.isreUpload == true ? this.batchId : '';
      let refId = data.binderRefId;
      if (this.fileList.length > 1) {
        this.toastService.warning("You can only upload a maximum of 1 file!");
        this.loaderService.isBusy = false;
      } else if (this.fileList.length == 1) {
        formData.append("ufile", this.fileList[0]);
        if (this.isreUpload || this.isValidateCheckSum) {
          formData.append("batchId", this.batchId);
        }
        if (this.isValidateCheckSum && type == 'checksum') {
          this.id = setInterval(() => {
            this.getProgressInfo();
            this.enableProgressBar = true;
          }, 1500);
          this.claimBorderxService.validateChecksum(formData).subscribe((resp: any) => {
            this.validateCheckSumData = resp;
            this.loaderService.isBusy = false;
            this.batchId = this.validateCheckSumData.tbiBatId;
            this.errorCheckSum = Number(this.validateCheckSumData.tbiFlex07);
            if (this.errorCheckSum == 0) {
              this.checksumDisable = false;
            } else {
              this.checksumDisable = true;
            }
            document.getElementById("closeUpload1").click();
            this.cleanUploadForm();
          }, error => {
            if (this.id) {
              clearInterval(this.id);
            }
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    if (error.error.btnAction == 'Y') {
                      this.checksumDisable = false;
                    } else {
                      this.checksumDisable = true;
                    }
                    document.getElementById("closeUpload1").click();
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          });
        } else {
          this.id = setInterval(() => {
            this.getProgressInfo();
            this.enableProgressBar = true;
          }, 1500);
          this.validateCheckSumData = {};
          this.claimBorderxService.readAndUploadDoc(formData).subscribe((resp: any) => {
            this.loaderService.isBusy = false;
            let batchId = resp.batchInfoDTO.tbiBatId;
            if (resp["messageType"] && resp["messageType"] == 'E') {
              this.toastService.error(resp["message"]);
            }
            document.getElementById("closeUpload").click();
            this.cleanUploadForm();
            this.router.navigate(["claim-bordereaux-upload"], { queryParams: { 'action': 'UPLOADNEW', 'isView': false, 'batchId': batchId }, skipLocationChange: true }).then(() => {
              this.claimBorderxService.setUploadNewClk(resp);
              this.docMetadata = resp.entityRefId;
            });

          }, error => {
            if (this.id) {
              clearInterval(this.id);
            }
            document.getElementById("closeUpload").click();
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          });
        }
      } else {
        this.toastService.warning("Please select file!");
        this.loaderService.isBusy = false;
      }
    } else {
      Utils.validateAllFormFields(this.batchUploadForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  cleanUploadForm() {
    this.batchUploadForm.reset();
    this.fileList = [];
  }

  public uploader: FileUploader = new FileUploader({
    url: "",
    autoUpload: false,
    method: '',
    disableMultipart: false,
    itemAlias: 'document',
    removeAfterUpload: false,
  });

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public onAfterAddingFile = (file) => {
  }

  public onFileSelected(event: File[]) {
    if (this.fileList.length > 0) {
      this.toastService.warning("You can only upload a maximum of 1 file!");
      return false;
    } else {
      for (let index = 0; index < event.length; index++) {
        event[index]['filesize'] = this.formatFileSize(event[index]['size'], 2);
        this.fileList.push(event[index]);
      }
    }
  }
  onExcelBtnExport() {
    if (this.uploadNewData.docMetadata.gridFSId != null) {
      this.exportExcel(this.uploadNewData.docMetadata.gridFSId);
    }
  }
  exportExcel(gridFSId) {
    this.claimBorderxService.exportExcel(gridFSId).subscribe((result: any) => {
    }, error => {
    });
  }
  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }

  checkDocType() {
    let docType = this.uploadDoc.unsavedFiles
    for (var i = 0; i < docType.length; i++) {
      if (docType[i].entityRefType == undefined) {
        return this.missingDocType = true;

      }
    }
  }
  openApproveModal() {
    this.missingDocType = false
    this.checkDocType();
    this.open(this.apprConfirmModal5, 5, 'modal-md');
    if (this.uploadDoc.unsavedFiles.length >= 0 && this.missingDocType == false) {
      if (this.uploadDoc.fileList.length !== 0) {
        this.uploadDoc.saveAllDocument();
      }
      // document.getElementById("triggerApprove").click();
      // this.approve();
    } else if (this.uploadDoc.unsavedFiles.length == 0) {
      // document.getElementById("triggerApprove").click();
      // this.approve();
    } else {
      this.toastService.warning('Save All Uploaded Documents');
    }

  }
  getProgressInfo() {
    let passData;
    if (this.batchId && this.batchId !== undefined) {
      passData = this.batchId;
    } else {
      passData = this.session.get('userId') + '' + this.session.get('companyCode') + '' + this.session.get('userDeptCode');
    }
    let progressData;
    this.claimBorderxService.uploadProgress(passData).subscribe((res: any) => {
      progressData = res.mProcessInfoArray;
      let posting = progressData.filter(function (ele) {
        if (ele) {
          if (ele.mpiProcessName) {
            return ele;
          }
        }
      })
      if (posting.length != 0) {
        this.postpercentage = posting[0].mpiProgressPcnt > 100 ? 100 : posting[0].mpiProgressPcnt;
      } else {
        this.postpercentage = 0;
      }
    }, err => {
      if (this.id) {
        clearInterval(this.id);
      }
    })
  }
  ngOnDestroy() {
    if (this.id) {
      clearInterval(this.id);
    }
    if (this.batchId == null) {
      this.getFileListDoc();
    }
  }
}

function createData(count, data, prefix) {
  var result = [];
  var tccSharePerc = 0;
  var tcsPaidFc = 0;
  var tcsRecFc = 0;
  var tcsNetPaidFc = 0;
  var tcsPayEstFc = 0;
  var tcsRecEstFc = 0;
  var tcsNetOsFc = 0;
  for (var i = 0; i < data.length; i++) {
    tccSharePerc = tccSharePerc + data[i].tccSharePerc;
    tcsPaidFc = tcsPaidFc + Number(data[i].tcsPaidFc);
    tcsRecFc = tcsRecFc + Number(data[i].tcsRecFc);
    tcsNetPaidFc = tcsNetPaidFc + Number(data[i].tcsNetPaidFc);
    tcsPayEstFc = tcsPayEstFc + Number(data[i].tcsPayEstFc);
    tcsRecEstFc = tcsRecEstFc + Number(data[i].tcsRecEstFc);
    tcsNetOsFc = tcsNetOsFc + Number(data[i].tcsNetOsFc);
  }
  result.push({
    tccCustCodeDesc: 'Total',
    tccSharePerc: tccSharePerc,
    tcsPaidFc: tcsPaidFc,
    tcsRecFc: tcsRecFc,
    tcsNetPaidFc: tcsNetPaidFc,
    tcsPayEstFc: tcsPayEstFc,
    tcsRecEstFc: tcsRecEstFc,
    tcsNetOsFc: tcsNetOsFc
  });

  return result;
}
function tooltipRenderer(params) {
  return '<span title="' + params.value + '">' + params.value + '</span>';
}
