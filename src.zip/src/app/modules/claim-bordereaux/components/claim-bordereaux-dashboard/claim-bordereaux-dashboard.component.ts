import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { FileUploader } from 'ng2-file-upload';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { HiperLinkComponent } from 'src/shared/components/ag-hiperlink/ag-hiperlink.component';
import { ClaimBordereauxService } from '../../services/claim-bordereaux.service';
import { Utils } from './../../utils';

@Component({
  selector: 'claim-bordereaux-dashboard',
  templateUrl: './claim-bordereaux-dashboard.component.html',
  styleUrls: ['./claim-bordereaux-dashboard.component.scss']
})

export class ClaimBordereauxDashboardComponent {
  searchForm: UntypedFormGroup;
  currencyCode: any;
  mgaList: any = [];
  userList: any = [];

  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  public gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  rowData: any;

  bsConfig: Partial<BsDatepickerConfig> = new BsDatepickerConfig();
  batchInfoList: any;
  contractStatus: boolean = false;
  showInprogress = false;
  batchId: any;
  sideBar: any;
  postpercentage: number;
  id: any;
  @ViewChild('batchUploadModal1') batchUploadModal1: ElementRef;
  @ViewChild('errorModal2') errorModal2: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
    private claimBorderxService: ClaimBordereauxService,
    private commonService: CommonService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loadColumn();
    this.loadInProgressColumn();
    this.currencyCode = this.session.get('baseCurrency');
    // this.currencyCode = this.currencyCode.slice(1, -1);
    this.createForm();
    this.context = { componentParent: this };
    this.agGridOptions();
    this.search('A');
    // this.getBatchInfo();
    this.createBatchUploadForm();
    this.getMgaCode();
    this.getBinderRefId();
    this.reterieveUWriterList();
  }

  loadColumn() {
    const context = this;
    this.columnDefs = [
      {
        headerName: 'Batch ID',
        headerTooltip: 'Batch ID',
        field: 'tbiBatId',
        width: 95,
        tooltipField: 'tbiBatId',
        cellStyle: { color: '#ffffff', 'font-weight': 'bold', 'text-decoration': 'underline' },
        cellRendererFramework: HiperLinkComponent,
        cellRendererParams: {
          event: (event, data) => {
            this.onRefClicked(data);
          }
        },
        pointerCursor: true,
        filter: 'agTextColumnFilter',
        filterParams: {
          filterOptions: ['contains', 'notContains'],
          debounceMs: 0,
          caseSensitive: false,
          suppressAndOrCondition: true
        },
        valueGetter: function (params) {
          if (params.data && params.data.tbiBatId && params.data.tbiBatType) {
            return 'B - ' + params.data.tbiBatId;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tbiBatDt',
        headerName: 'Input Date',
        headerTooltip: 'Input Date',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiBatDt) {
            return moment(params.data.tbiBatDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
      },
      {
        field: 'tbiMgaCode',
        headerName: 'MGA',
        cellStyle: { textAlign: 'left' },
        width: 110,
        headerTooltip: 'MGA',
        cellRenderer: Utils.tooltipRenderer,
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.tbiMgaCode + '-' + params.data.tbiMgaCodeDesc;
          }
        },
      },
      {
        field: 'tbiAcntDt',
        headerName: 'Accounting Date',
        headerTooltip: 'Accounting Date',
        cellStyle: { textAlign: 'left' },
        // valueFormatter: Utils.dateFormatter,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiAcntDt) {
            return moment(params.data.tbiAcntDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
      },
      {
        field: 'tbiCloseDt',
        headerName: 'Closing Date',
        headerTooltip: 'Closing Date',
        cellStyle: { textAlign: 'left' },
        hide: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseDt) {
            return moment(params.data.tbiCloseDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
      },
      {
        field: 'tbiCloseToDt',
        headerName: 'Closing Period',
        headerTooltip: 'Closing Period',
        cellStyle: { textAlign: 'left' },
        hide: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseToDt) {
            return moment(params.data.tbiCloseToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
      },
      {
        field: 'tbiSetlDueDt',
        headerName: 'Settlement Due Date',
        // cellRenderer: 'endDateCellRenderer',
        cellStyle: { textAlign: 'left' },
        headerTooltip: 'Settlement Due Date',
        hide: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiSetlDueDt) {
            return moment(params.data.tbiSetlDueDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
      },

      {
        field: 'tbiPaidLc1',
        width: 110,
        headerName: 'Gross Claims Paid',
        headerTooltip: 'Gross Claims Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tbiPaidLc1) {
            return Number(params.data.tbiPaidLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiPaidLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tbiRecLc1',
        width: 110,
        headerName: 'Recovery Paid',
        headerTooltip: 'Recovery Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tbiRecLc1) {
            return Number(params.data.tbiRecLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiRecLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tbiNetPaidLc1',
        width: 110,
        headerName: 'Net Claims Paid',
        headerTooltip: 'Net Claims Paid',
        valueGetter: function (params) {
          if (params.data && params.data.tbiNetPaidLc1) {
            return Number(params.data.tbiNetPaidLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiNetPaidLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tbiPayEstLc1',
        width: 110,
        headerName: 'Gross Claims Reserves',
        headerTooltip: 'Gross Claims Reserves',
        valueGetter: function (params) {
          if (params.data && params.data.tbiPayEstLc1) {
            return Number(params.data.tbiPayEstLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiPayEstLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tbiRecEstLc1',
        width: 110,
        headerName: 'Recovery Reserves',
        headerTooltip: 'Recovery Reserves',
        valueGetter: function (params) {
          if (params.data && params.data.tbiRecEstLc1) {
            return Number(params.data.tbiRecEstLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiRecEstLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },

      },
      {
        field: 'tbiNetOs',
        width: 110,
        headerName: 'Net Claims Reserves',
        headerTooltip: 'Net Claims Reserves',
        valueGetter: function (params) {
          if (params.data && params.data.tbiNetOs) {
            return Number(params.data.tbiNetOs).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiNetOs == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tbiCrUidName',
        headerName: 'Processed By',
        headerTooltip: 'Processed By',
        tooltipField: 'tbiCrUidName',
        width: 130,
      },
      {
        field: 'tbiUploadFileName',
        headerName: 'Uploaded File',
        headerTooltip: 'Uploaded File',
        width: 130,
        cellStyle: { textAlign: 'left' },
        cellRenderer: Utils.tooltipRenderer
      },
      {
        width: 110,
        field: 'tbiApprSts',
        headerName: 'Status',
        headerTooltip: 'Status',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiApprSts) {
            if (params.data.tbiApprSts === 'A') {
              return 'Approved';
            } else if (params.data.tbiApprSts === 'R') {
              return 'Reversed';
            } else {
              return 'Pending';
            }
          } else {
            return '';
          }
        },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-orange-outer': function (params) {
            if (params.value) {
              return params.value == 'Reversed';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.value) {
              return params.value == 'Pending';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Reversed') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Pending') {
            return '<span class="ag-element">' + params.value + '</span>';
          }
        },
      },
    ];
    this.sideBar = {
      toolPanels: [
        {
          id: 'columns',
          labelDefault: 'Columns',
          labelKey: 'columns',
          iconKey: 'columns',
          toolPanel: 'agColumnsToolPanel',
          toolPanelParams: {
            suppressPivots: true,
            suppressPivotMode: true,
          }
        },
        {
          id: 'filters',
          labelDefault: 'Filters',
          labelKey: 'filters',
          iconKey: 'filter',
          toolPanel: 'agFiltersToolPanel',
        }
      ],
      position: 'right'
    };
  }

  inProgColumnDefs: any;
  loadInProgressColumn() {
    const context = this;
    this.inProgColumnDefs = [
      {
        headerName: 'Batch ID',
        headerTooltip: 'Batch ID',
        field: 'tbiBatId',
        width: 95,
        tooltipField: 'tbiBatId',
        cellStyle: { color: '#ffffff', 'font-weight': 'bold', 'text-decoration': 'underline' },
        cellRendererFramework: HiperLinkComponent,
        cellRendererParams: {
          event: (event, data) => {
            this.onRefClicked(data);
          }
        },
        pointerCursor: true,
        filter: 'agTextColumnFilter',
        filterParams: {
          filterOptions: ['contains', 'notContains'],
          debounceMs: 0,
          caseSensitive: false,
          suppressAndOrCondition: true
        },
        valueGetter: function (params) {
          if (params.data && params.data.tbiBatId && params.data.tbiBatType) {
            return 'B - ' + params.data.tbiBatId;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tbiBatDt',
        headerName: 'Input Date',
        headerTooltip: 'Input Date',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiBatDt) {
            return moment(params.data.tbiBatDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
      },
      {
        field: 'tbiMgaCode',
        headerName: 'MGA',
        headerTooltip: 'MGA',
        cellStyle: { textAlign: 'left' },
        cellRenderer: Utils.tooltipRenderer,
        width: 110,
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.tbiMgaCode + '-' + params.data.tbiMgaCodeDesc;
          }
        },
        resizable: true

      },
      {
        field: 'tbiAcntDt',
        headerName: 'Accounting Date',
        headerTooltip: 'Accounting Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiAcntDt) {
            return moment(params.data.tbiAcntDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
      },
      {
        field: 'tbiCloseDt',
        headerName: 'Closing Date',
        headerTooltip: 'Closing Date',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseDt) {
            return moment(params.data.tbiCloseDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
        hide: true,
      },
      {
        field: 'tbiCloseToDt',
        headerName: 'Closing Period',
        headerTooltip: 'Closing Period',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseToDt) {
            return moment(params.data.tbiCloseToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
        hide: true,
      },
      {
        field: 'tbiSetlDueDt',
        headerName: 'Settlement Due Date',
        // cellRenderer: 'endDateCellRenderer',
        cellStyle: { textAlign: 'right' },
        headerTooltip: 'Settlement Due Date',
        // valueFormatter: Utils.dateFormatter,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiSetlDueDt) {
            return moment(params.data.tbiSetlDueDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
        hide: true,
      },

      {
        width: 110,
        headerName: 'Gross Claims Paid',
        headerTooltip: 'Gross Claims Paid',
        field: 'tbiPaidLc1',
        valueFormatter: Utils.currencyDecimalFormatter,

      },
      {
        width: 110,
        headerName: 'Recovery Paid',
        headerTooltip: 'Recovery Paid',
        field: 'tbiRecEstLc1',
        valueFormatter: Utils.currencyDecimalFormatter
      },
      {
        width: 110,
        headerName: 'Net Claims Paid',
        headerTooltip: 'Net Claims Paid',
        field: 'tbiNetPaidLc1',
        valueFormatter: Utils.currencyDecimalFormatter
      },
      {
        width: 110,
        headerName: 'Gross Claims Reserves',
        headerTooltip: 'Gross Claims Reserves',
        field: 'tbiPayEstLc1',
        valueFormatter: Utils.currencyDecimalFormatter
      },
      {
        width: 110,
        headerName: 'Recovery Reserves',
        headerTooltip: 'Recovery Reserves',
        field: 'tbiRecLc1',
        valueFormatter: Utils.currencyDecimalFormatter

      },
      {
        width: 110,
        headerName: 'Net Claims Reserves',
        headerTooltip: 'Net Claims Reserves',
        field: 'tbiNetOs',
        valueFormatter: Utils.currencyDecimalFormatter
      },
      {
        field: 'tbiCrUidName',
        headerName: 'Processed By',
        headerTooltip: 'Processed By',
        tooltipField: 'tbiCrUidName',
        width: 130,
        enableRowGroup: true,
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'tbiUploadFileName',
        headerName: 'Uploaded File',
        headerTooltip: 'Uploaded File',
        width: 130,
        cellStyle: { textAlign: 'left' },
        cellRenderer: Utils.tooltipRenderer
      },
      {
        width: 110,
        field: 'tbiApprSts',
        headerName: 'Status',
        headerTooltip: 'Status',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiApprSts) {
            if (params.data.tbiApprSts === 'A') {
              return 'Approved';
            } else if (params.data.tbiApprSts === 'R') {
              return 'Reversed';
            } else {
              return 'Pending';
            }
          } else {
            return '';
          }
        },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-orange-outer': function (params) {
            if (params.value) {
              return params.value == 'Reversed';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.value) {
              return params.value == 'Pending';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Reversed') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Pending') {
            return '<span class="ag-element">' + params.value + '</span>';
          }
        },
      },
    ];
    this.sideBar = {
      toolPanels: [
        {
          id: 'columns',
          labelDefault: 'Columns',
          labelKey: 'columns',
          iconKey: 'columns',
          toolPanel: 'agColumnsToolPanel',
          toolPanelParams: {
            suppressPivots: true,
            suppressPivotMode: true,
          }
        },
        {
          id: 'filters',
          labelDefault: 'Filters',
          labelKey: 'filters',
          iconKey: 'filter',
          toolPanel: 'agFiltersToolPanel',
        }
      ],
      position: 'right'
    };
  }
  createForm() {
    this.searchForm = this.fb.group({
      tbiAcntDtFm: [''],
      tbiAcntDtTo: [''],
      batchDate: [undefined],
      mga: null,
      batchprocessedby: null,
    });
  }

  getBatchInfo() {
    this.claimBorderxService.getBatchInfo().subscribe(res => {
      this.batchInfoList = res;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  goToUploadNew() {

  }
  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val });
  }
  closeModal(id: number) {
    this.modalService.hide(id);
  }
  onStatusChange(status) {
  }
  searchClick() {
    if (!this.showInprogress) {
      this.search('A')
    } else {
      this.search('P')
    }
  }
  // isClicked: boolean = false;
  onViewAcc(data) {
    this.loaderService.isBusy = true
    let docNo = data.tbiRevDocNo;
    // this.isClicked = true;     
    let batchId = data.tbiBatId
    this.router.navigate(["claim-bordereaux/claim-bordereaux-accounting"],
      { queryParams: { 'docNo': docNo, 'batchId': batchId }, skipLocationChange: true });
  }
  search(status) {
    this.batchInfoList = [];
    this.loaderService.isBusy = true;
    if (status == "P") {
      this.contractStatus = true
    } else {
      this.contractStatus = false;
    }
    //this.loadColumn();
    let data = this.searchForm.value;
    let bDate = data.batchDate ? moment(data.batchDate).format('DD-MM-YYYY') : '';
    let batchDate = (bDate) ? moment(bDate, "DD/MM/YYYY").valueOf() : null;

    let dataToSend = {
      tbiApprSts: status,
      //tbiBatId: data.batchId,
      tbiBatDt: batchDate,
      tbiAcntDtFm: data.tbiAcntDtFm ? moment(data.tbiAcntDtFm).format('DD-MM-YYYY') : '',
      tbiAcntDtTo: data.tbiAcntDtTo ? moment(data.tbiAcntDtTo).format('DD-MM-YYYY') : '',
      tbiCrUid: data.batchprocessedby,
      tbiMgaCode: data.mga,
    }
    this.claimBorderxService.searchClaim(dataToSend).subscribe((result: any) => {
      // this.rowData = result;
      // this.calculateFilterCounts();
      this.batchInfoList = result
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }

  tabClick(evt) {
    if (evt.heading === 'Processed') {
      this.search("A");
      this.loaderService.isBusy = true;
      this.showInprogress = false
    }
    if (evt.heading === 'In Progress') {
      this.search("P");
      this.loaderService.isBusy = true;
      this.showInprogress = true
    }
  }

  onRefClicked(data) {
    this.loaderService.isBusy = true
    let batchId = data.tbiBatId;
    this.claimBorderxService.getClaimBdx(batchId).subscribe(res => {
      this.loaderService.isBusy = false;
      this.router.navigate(["claim-bordereaux-upload"], { queryParams: { 'isView': true, 'batchId': batchId }, skipLocationChange: true }).then(() => {
        this.claimBorderxService.setUploadNewClk(res);
      });

    }, error => {
      this.showErrorDialogBox(error.error.message);
      this.loaderService.isBusy = false;
    })
  }
  reset() {
    this.searchForm.patchValue({
      tbiAcntDtFm: '',
      tbiAcntDtTo: '',
      batchDate: '',
      mga: null,
      batchprocessedby: null
    });
    this.pageChanged({ page: 1 });
    if (!this.showInprogress) {
      this.search('A')
    } else {
      this.search('P')
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'ClaimBordereauxSummary.xlsx',
        skipHeader: false,
        sheetName: 'Claim Bordereaux Summary',

        processCellCallback: (params) => {

          if (params.column.colId == "tbiBatDt" || params.column.colId == "tbiAcntDt"
            || params.column.colId == "tbiCloseDt" || params.column.colId == "tbiCloseToDt"
            || params.column.colId == "tbiSetlDueDt") {
            return params.value;
          } else if (params.column.colId == 'tbiApprSts') {
            if (params.value == 'A')
              return 'Approved';
            else if (params.value == 'P')
              return 'Pending'
            else
              return params.value;
          } else if (params.column.colId == "tbiPaidLc1" || params.column.colId == "tbiRecLc1"
            || params.column.colId == "tbiNetPaidLc1" || params.column.colId == "tbiPayEstLc1"
            || params.column.colId == "tbiRecEstLc1" || params.column.colId == "tbiNetOs") {
            if (params.value) {
              return parseFloat((params.value).replace(/,/g, ''));
            } else {
              return "";
            }
          } {
            return params.value;
          }
        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('mgadashboard').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();

  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: this.batchInfoList,
      enableFilter: true
    };
    this.context = { componentParent: this };
  }
  // Batch Upload //

  openUploadPopup() {
    this.batchUploadForm.reset();
    this.fileList = [];
    this.open(this.batchUploadModal1, 1, 'modal-md');
  }

  batchUploadForm: UntypedFormGroup;
  createBatchUploadForm() {
    this.batchUploadForm = this.fb.group({
      // bindRefNo: ["", Validators.required],
      // bindSeqNo: ["", Validators.required],
      // bindAmendNo: ["", Validators.required],
      // binderMgaCode: ["", Validators.required]
      binderRefId: '',
      binderMgaCode: ''
    });
  }

  removeFile(index) {
    this.fileList.splice(index, 1);
  }

  formatFileSize(bytes, decimalPoint) {
    if (bytes == 0) return '0 KB';
    var k = 1000,
      dm = decimalPoint || 2,
      sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  fileList: any = [];
  localQueue: any[] = [];
  timer: any;
  noFiles: Boolean = false;

  uploadBatchFile() {
    if (this.batchUploadForm.valid) {
      this.loaderService.isBusy = true;
      let data = this.batchUploadForm.getRawValue();
      let formData = new FormData();
      let batchId = '';
      let refId = data.binderRefId;
      if (this.fileList.length > 1) {
        this.toastService.warning("You can only upload a maximum of 1 file!");
        this.loaderService.isBusy = false;

      } else if (this.fileList.length == 1) {
        formData.append("ufile", this.fileList[0]);
        this.id = setInterval(() => {
          this.getProgressInfo();

        }, 1500);
        this.claimBorderxService.readAndUploadDoc(formData).subscribe(resp => {
          this.loaderService.isBusy = false;
          let batchId = resp.batchInfoDTO.tbiBatId;

          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          }
          document.getElementById("closeUpload").click();
          this.cleanUploadForm();
          this.router.navigate(["claim-bordereaux-upload"], { queryParams: { 'isView': false, 'batchId': batchId }, skipLocationChange: true }).then(() => {
            this.claimBorderxService.setUploadNewClk(resp);
          });

        }, error => {
          if (this.id) {
            clearInterval(this.id);
          }
          document.getElementById("closeUpload").click();
          if (error instanceof HttpErrorResponse) {
            if (error.error instanceof ErrorEvent) {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            } else {
              switch (error.status) {
                case 400:
                  this.loaderService.isBusy = false;
                  this.showErrorDialogBox(error.error.message);
                  break;
                default:
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in upload!");
                  break;
              }
            }
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in upload!");
          }
        });
      } else {
        this.toastService.warning("Please select file!");
        this.loaderService.isBusy = false;

      }
    } else {
      this.validateAllFormFields(this.batchUploadForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }

  cleanUploadForm() {
    this.batchUploadForm.reset();
    this.fileList = [];
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }


  public uploader: FileUploader = new FileUploader({
    url: "",
    autoUpload: false,
    method: '',
    disableMultipart: false,
    itemAlias: 'document',
    removeAfterUpload: false,
  });

  public hasBaseDropZoneOver = false;

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public onAfterAddingFile = (file) => {
  }

  public onFileSelected(event: File[]) {

    if (this.fileList.length > 0) {
      this.toastService.warning("You can only upload a maximum of 1 file!");
      return false;
    } else {
      //const file: File = event[0];
      for (let index = 0; index < event.length; index++) {
        event[index]['filesize'] = this.formatFileSize(event[index]['size'], 2);
        this.fileList.push(event[index]);
      }
    }

  }


  showErrorDialogBox(apprErrorMsg) {
    this.open(this.errorModal2, 2, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  mgaCodeList: any = [];
  getMgaCode() {
    this.claimBorderxService.getMGAlist().subscribe(resp => {
      this.mgaList = resp;
      this.mgaList = (this.mgaList as any[]).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });
      this.mgaList.unshift({ code: null, displayText: 'All' });
    })

  }
  reterieveUWriterList() {
    // let roleId = this.session.get('roleId');
    this.commonService.getUserList('ClmSummBdx').subscribe((users: any) => {
      this.userList = users;
      this.userList.unshift({ key: null, value: 'All' });
    })
  }
  binderRefList: any
  getBinderRefId() {
    this.claimBorderxService.getBinderRefId().subscribe((response: any) => {
      this.binderRefList = response.contractDetails

    }, error => {
    })
  }
  getProgressInfo() {
    let passData;
    if (this.batchId && this.batchId !== undefined) {
      passData = this.batchId;
    } else {
      passData = this.session.get('userId') + '' + this.session.get('companyCode') + '' + this.session.get('userDeptCode');
    }
    let progressData;
    this.claimBorderxService.uploadProgress(passData).subscribe((res: any) => {
      progressData = res.mProcessInfoArray;
      let posting = progressData.filter(function (ele) {
        if (ele) {
          if (ele.mpiProcessName == "Claim Summary BDX Upload") {
            return ele;
          }
        }
      })
      if (posting.length != 0) {
        this.postpercentage = posting[0].mpiProgressPcnt > 100 ? 100 : posting[0].mpiProgressPcnt;
      } else {
        this.postpercentage = 0;
      }
    }, err => {
      if (this.id) {
        clearInterval(this.id);
      }
    })
  }
  ngOnDestroy() {
    if (this.id) {
      clearInterval(this.id);
    }
  }
}