import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ClaimBordereauxDashboardComponent } from './claim-bordereaux-dashboard.component';


describe('ClaimBordereauxDashboardComponent', () => {
  let component: ClaimBordereauxDashboardComponent;
  let fixture: ComponentFixture<ClaimBordereauxDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimBordereauxDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimBordereauxDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
