import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClaimBordereauxDashboardComponent } from './components/claim-bordereaux-dashboard/claim-bordereaux-dashboard.component';
import { ClaimBordereauxUploadComponent } from './components/claim-bordereaux-upload/claim-bordereaux-upload.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'claim-bordereaux',
    pathMatch: 'prefix'
  },
  {
    path: 'claim-bordereaux',
    component: ClaimBordereauxDashboardComponent,
    data: {
      breadcrumb: { skip: true }
    }
  },
  {
    path: 'claim-bordereaux-upload',
    component: ClaimBordereauxUploadComponent,
    data: {
      breadcrumb: 'Claim Bordereaux Upload'
    }
  },
  // {
  //   path: 'claim-bordereaux-accounting',
  //   component: ClaimBordereauxAccoutingComponent,
  //   data: {
  //     breadcrumb: 'Claim Accounting Entry'
  //   }
  // },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClaimBordereauxRoutingModule { }
