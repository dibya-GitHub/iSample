import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FileUploadModule } from 'ng2-file-upload';
import { ProgressbarModule } from "ngx-bootstrap/progressbar";
import { TabsModule } from 'ngx-bootstrap/tabs';
import { DropdownModule } from 'primeng/dropdown';
import { AuthInterceptor } from 'src/app/services/auth-interceptor';
import { SharedModule } from 'src/shared/shared.module';
import { PremiumBordereauxDashboardComponent } from './components/premium-bordereaux-dashboard/premium-bordereaux-dashboard.component';
import { PremiumBordereauxUploadComponent } from './components/premium-bordereaux-upload/premium-bordereaux-upload.component';
import { PremiumBordereauxRoutingModule } from './premium-bordereaux-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    DropdownModule,
    PremiumBordereauxRoutingModule,
    TabsModule.forRoot(),
    FileUploadModule,
    ProgressbarModule.forRoot(),
  ],
  declarations: [
    PremiumBordereauxDashboardComponent,
    PremiumBordereauxUploadComponent,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PremiumBordereauxModule { }
