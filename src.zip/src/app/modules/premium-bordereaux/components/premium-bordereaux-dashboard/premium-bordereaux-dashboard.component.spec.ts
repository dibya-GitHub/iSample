import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumBordereauxDashboardComponent } from './premium-bordereaux-dashboard.component';

describe('PremiumBordereauxDashboardComponent', () => {
  let component: PremiumBordereauxDashboardComponent;
  let fixture: ComponentFixture<PremiumBordereauxDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumBordereauxDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumBordereauxDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
