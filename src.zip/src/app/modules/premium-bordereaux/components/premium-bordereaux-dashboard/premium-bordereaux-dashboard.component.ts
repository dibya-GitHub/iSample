import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { FileUploader } from 'ng2-file-upload';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { HiperLinkComponent } from 'src/shared/components/ag-hiperlink/ag-hiperlink.component';
import { PremiumBordereauxService } from './../../services/premium-bordereaux.service';
import { Utils } from './../../utils';

@Component({
  selector: 'premium-bordereaux-dashboard',
  templateUrl: './premium-bordereaux-dashboard.component.html',
  styleUrls: ['./premium-bordereaux-dashboard.component.scss']
})

export class PremiumBordereauxDashboardComponent {
  searchForm: UntypedFormGroup;
  currencyCode: any;
  mgaList: any;
  userList: any;
  binderRefList: any[] = [];
  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  rowData: any;
  public components;
  public context;
  public frameworkComponents;
  paginationPageSize: number;
  rowGroupPanelShow: string;
  bsConfig: Partial<BsDatepickerConfig> = new BsDatepickerConfig();
  batchInfoList: any = [];
  contractStatus: boolean = false;
  showInprogress = false;
  batchId: any;
  isClicked: boolean = false;
  sideBar;
  insPercentage: any;
  postpercentage: number;
  progressList: any;
  postingList: any;
  id: any;
  @ViewChild('errorModal') errorModal: ElementRef;
  @ViewChild('batchUploadModal') batchUploadModal: ElementRef;
  errorModalDetails: any = '';

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
    private prmBorderxService: PremiumBordereauxService,
    private commonService: CommonService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {

    this.loadColumn();
    this.loadInProgColumn();
    this.currencyCode = this.session.get('baseCurrency');
    console.log(this.currencyCode);

    // this.currencyCode = this.currencyCode.slice(1, -1);
    this.createForm();
    this.context = { componentParent: this };
    this.agGridOptions();
    this.search('A');
    // this.getBatchInfo();
    this.createBatchUploadForm();
    this.getMgaCode();
    // this.getBinderRefId();
    this.reterieveUWriterList();
    // this.getProgressInfo();
  }
  loadColumn() {
    const context = this;
    this.columnDefs = [
      {
        headerName: 'Batch ID',
        headerTooltip: 'Batch ID',
        field: 'tbiBatId',
        width: 85,
        cellStyle: { color: '#ffffff', 'font-weight': 'bold', 'text-decoration': 'underline', 'text-decoration-color': '#036aff', 'cursor': 'pointer' },
        cellRendererFramework: HiperLinkComponent,
        cellRendererParams: {
          event: (event, data) => {
            context.onRefClicked(data);
          }
        },
        pointerCursor: true,
        filter: 'agTextColumnFilter',
        filterParams: {
          filterOptions: ['contains', 'notContains'],
          debounceMs: 0,
          caseSensitive: false,
          suppressAndOrCondition: true
        },
        valueGetter: function (params) {
          if (params.data && params.data.tbiBatId && params.data.tbiBatType) {
            return 'B - ' + params.data.tbiBatId;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tbiBatDt',
        headerName: 'Input Date',
        headerTooltip: 'Input Date',
        cellStyle: { textAlign: 'center' },
        // valueFormatter: Utils.dateFormatter,
        width: 110,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiBatDt) {
            return moment(params.data.tbiBatDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },

      },
      {
        field: 'tbiMgaCode',
        headerName: 'MGA',
        cellStyle: { textAlign: 'left' },
        width: 150,
        headerTooltip: 'MGA',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiMgaCode) {
            return params.data.tbiMgaCode + ' - ' + params.data.tbiMgaCodeDesc;
          } else {
            return '';
          }
        },
        cellRenderer: Utils.tooltipRenderer
      },
      {
        field: 'tbiAcntDt',
        headerName: 'Accounting Date',
        headerTooltip: 'Accounting Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiAcntDt) {
            return moment(params.data.tbiAcntDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 120,
      },
      {
        field: 'tbiCloseDt',
        headerName: 'Closing Date',
        headerTooltip: 'Closing Date',
        enableRowGroup: true,
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseDt) {
            return moment(params.data.tbiCloseDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
        hide: true,
      },
      {
        field: 'tbiCloseToDt',
        headerName: 'Closing Period',
        headerTooltip: 'Closing Period',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseToDt) {
            return moment(params.data.tbiCloseToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        enableRowGroup: true, sortable: true, filter: true, resizable: true,
        cellStyle: { textAlign: 'right' },
        width: 110,
        hide: true,

      },
      {
        field: 'tbiSetlDueDt',
        headerName: 'Settlement Due Date',
        cellStyle: { textAlign: 'right' },
        headerTooltip: 'Settlement Due Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiSetlDueDt) {
            return moment(params.data.tbiSetlDueDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
        hide: true,
      },
      {
        width: 250,
        headerName: 'Gross Premium',
        field: 'tbiGrossPremLc1',
        headerTooltip: 'Gross Premium',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tbiGrossPremLc1) {
            return Number(params.data.tbiGrossPremLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiGrossPremLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'IPT',
        field: 'tbiIptLc1',
        headerTooltip: 'IPT',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tbiIptLc1) {
            return Number(params.data.tbiIptLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiIptLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'Stamp Duty',
        field: 'tbiStampDutyLc1',
        headerTooltip: 'Stamp Duty',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tbiStampDutyLc1) {
            return Number(params.data.tbiStampDutyLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiStampDutyLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'Commission',
        field: 'tbiBrkCommLc1',
        headerTooltip: 'Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tbiBrkCommLc1) {
            return Number(params.data.tbiBrkCommLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiBrkCommLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 200,
        headerName: 'Gross Net Premium',
        field: 'tbiNetPremLc1',
        headerTooltip: 'Gross Net Premium',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tbiNetPremLc1) {
            return Number(params.data.tbiNetPremLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tbiNetPremLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tbiCrUidName',
        headerName: 'Processed By',
        headerTooltip: 'Processed By',
        width: 130,
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'tbiUploadFileName',
        headerName: 'Uploaded File',
        headerTooltip: 'Uploaded File',
        width: 130,
        cellStyle: { textAlign: 'left' },
        cellRenderer: Utils.tooltipRenderer
      },
      {
        width: 110,
        field: 'tbiApprSts',
        headerName: 'Status',
        headerTooltip: 'Status',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiApprSts) {
            if (params.data.tbiApprSts === 'A') {
              return 'Approved';
            } else if (params.data.tbiApprSts === 'R') {
              return 'Reversed';
            } else {
              return 'Pending';
            }
          } else {
            return '';
          }
        },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-orange-outer': function (params) {
            if (params.value) {
              return params.value == 'Reversed';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.value) {
              return params.value == 'Pending';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Reversed') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Pending') {
            return '<span class="ag-element">' + params.value + '</span>';
          }
        },
      },
    ];
    this.sideBar = {
      toolPanels: [
        {
          id: 'columns',
          labelDefault: 'Columns',
          labelKey: 'columns',
          iconKey: 'columns',
          toolPanel: 'agColumnsToolPanel',
          toolPanelParams: {
            suppressPivots: true,
            suppressPivotMode: true,
          }
        },
        {
          id: 'filters',
          labelDefault: 'Filters',
          labelKey: 'filters',
          iconKey: 'filter',
          toolPanel: 'agFiltersToolPanel',
        }
      ],
      position: 'right'
    };
  }
  inProgColumnDefs: any;
  loadInProgColumn() {
    const context = this;
    this.inProgColumnDefs = [
      {
        headerName: 'Batch ID',
        headerTooltip: 'Batch ID',
        field: 'tbiBatId',
        width: 85,
        cellStyle: { color: '#ffffff', 'font-weight': 'bold', 'text-decoration': 'underline' },
        cellRendererFramework: HiperLinkComponent,
        cellRendererParams: {
          event: (event, data) => {
            context.onRefClicked(data);
          }
        },
        pointerCursor: true,
        filter: 'agTextColumnFilter',
        filterParams: {
          filterOptions: ['contains', 'notContains'],
          debounceMs: 0,
          caseSensitive: false,
          suppressAndOrCondition: true
        },
        valueGetter: function (params) {
          if (params.data && params.data.tbiBatId && params.data.tbiBatType) {
            return 'B - ' + params.data.tbiBatId;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tbiBatDt',
        headerName: 'Input Date',
        headerTooltip: 'Input Date',
        cellStyle: { textAlign: 'center' },
        width: 110,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiBatDt) {
            return moment(params.data.tbiBatDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        field: 'tbiMgaCode',
        headerName: 'MGA',
        cellStyle: { textAlign: 'left' },
        width: 150,
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiMgaCode) {
            return params.data.tbiMgaCode + ' - ' + params.data.tbiMgaCodeDesc;
          } else {
            return '';
          }
        },
        cellRenderer: Utils.tooltipRenderer
      },
      {
        field: 'tbiAcntDt',
        headerName: 'Accounting Date',
        headerTooltip: 'Accounting Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiAcntDt) {
            return moment(params.data.tbiAcntDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 120,
      },
      {
        field: 'tbiCloseDt',
        headerName: 'Closing Date',
        headerTooltip: 'Closing Date',
        enableRowGroup: true,
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseDt) {
            return moment(params.data.tbiCloseDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
        hide: true,
      },
      {
        field: 'tbiCloseToDt',
        headerName: 'Closing Period',
        headerTooltip: 'Closing Period',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiCloseToDt) {
            return moment(params.data.tbiCloseToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        enableRowGroup: true, sortable: true, filter: true, resizable: true,
        cellStyle: { textAlign: 'right' },
        width: 110,
        hide: true,
      },
      {
        field: 'tbiSetlDueDt',
        headerName: 'Settlement Due Date',
        cellStyle: { textAlign: 'right' },
        headerTooltip: 'Settlement Due Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiSetlDueDt) {
            return moment(params.data.tbiSetlDueDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        width: 110,
        hide: true,
      },
      {
        width: 250,
        //headerName: 'Written Perm Gross of Comm',
        headerName: 'Gross Premium',
        field: 'tbiGrossPremLc1',
        valueFormatter: Utils.currencyDecimalFormatter,
        headerTooltip: 'Gross Premium',
        cellStyle: { textAlign: 'right' },
      },
      {
        width: 110,
        headerName: 'IPT',
        field: 'tbiIptLc1',
        valueFormatter: Utils.currencyDecimalFormatter,
        headerTooltip: 'IPT',
        cellStyle: { textAlign: 'right' },
      },
      {
        width: 110,
        headerName: 'Stamp Duty',
        field: 'tbiStampDutyLc1',
        valueFormatter: Utils.currencyDecimalFormatter,
        headerTooltip: 'Stamp Duty',
        cellStyle: { textAlign: 'right' },
      },
      {
        width: 110,
        headerName: 'Commission',
        field: 'tbiBrkCommLc1',
        valueFormatter: Utils.currencyDecimalFormatter,
        headerTooltip: 'Commission',
        cellStyle: { textAlign: 'right' },
      },
      {
        width: 200,
        //headerName: 'Written Premium Net of Commission',
        headerName: 'Gross Net Premium',
        field: 'tbiNetPremLc1',
        valueFormatter: Utils.currencyDecimalFormatter,
        headerTooltip: 'Gross Net Premium',
        cellStyle: { textAlign: 'right' },
      },
      {
        field: 'tbiCrUidName',
        headerName: 'Processed By',
        headerTooltip: 'Processed By',
        width: 130,
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'tbiUploadFileName',
        headerName: 'Uploaded File',
        headerTooltip: 'Uploaded File',
        width: 130,
        cellStyle: { textAlign: 'left' },
        cellRenderer: Utils.tooltipRenderer
      },
      {
        width: 110,
        field: 'tbiApprSts',
        headerName: 'Status',
        headerTooltip: 'Status',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tbiApprSts) {
            if (params.data.tbiApprSts === 'A') {
              return 'Approved';
            } else if (params.data.tbiApprSts === 'R') {
              return 'Reversed';
            } else {
              return 'Pending';
            }
          } else {
            return '';
          }
        },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-orange-outer': function (params) {
            if (params.value) {
              return params.value == 'Reversed';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.value) {
              return params.value == 'Pending';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Reversed') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Pending') {
            return '<span class="ag-element">' + params.value + '</span>';
          }
        },
      },
    ];
    this.sideBar = {
      toolPanels: [
        {
          id: 'columns',
          labelDefault: 'Columns',
          labelKey: 'columns',
          iconKey: 'columns',
          toolPanel: 'agColumnsToolPanel',
          toolPanelParams: {
            suppressPivots: true,
            suppressPivotMode: true,
          }
        },
        {
          id: 'filters',
          labelDefault: 'Filters',
          labelKey: 'filters',
          iconKey: 'filter',
          toolPanel: 'agFiltersToolPanel',
        }
      ],
      position: 'right'
    };
  }
  createForm() {
    this.searchForm = this.fb.group({
      tbiAcntDtFm: [''],
      tbiAcntDtTo: [''],
      batchDate: [undefined],
      mga: null,
      batchprocessedby: null,
    });
  }
  getBatchInfo() {
    this.loaderService.isBusy = true;
    this.prmBorderxService.getBatchInfo().subscribe(res => {
      this.batchInfoList = res;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  goToUploadNew() {

  }
  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val });
  }
  closeModal(id: number) {
    this.modalService.hide(id);
  }
  newContType(mode, type) {
    var obj = {
      'action': mode,
      'amendNo': 0,
      'seqNo': 1,
      'type': type
    }
    this.router.navigate(['/mga-contract/mga-wizard'], { queryParams: obj, skipLocationChange: true });
    this.modalService.hide();
  }
  onStatusChange(status) {
  }
  searchClicked: boolean = false;
  searchClick() {
    this.searchClicked = true;
    if (!this.showInprogress) {
      this.search('A');
    } else {
      this.search('P')
    }
  }
  search(status) {
    this.batchInfoList = [];
    this.loaderService.isBusy = true;
    if (status == "P") {
      this.contractStatus = true;
    } else {
      this.contractStatus = false;
    }
    let data = this.searchForm.value;
    let bDate = data.batchDate ? moment(data.batchDate).format('DD-MM-YYYY') : '';
    let batchDate = (bDate) ? moment(bDate, "DD/MM/YYYY").valueOf() : null;
    let dataToSend = {
      tbiApprSts: status,
      tbiBatDt: batchDate,
      tbiAcntDtFm: data.tbiAcntDtFm ? moment(data.tbiAcntDtFm).format('DD-MM-YYYY') : '',
      tbiAcntDtTo: data.tbiAcntDtTo ? moment(data.tbiAcntDtTo).format('DD-MM-YYYY') : '',
      tbiCrUid: data.batchprocessedby,
      tbiMgaCode: data.mga,
    }
    this.prmBorderxService.searchPremium(dataToSend).subscribe((result: any) => {
      // this.rowData = resp;
      // this.calculateFilterCounts();
      this.batchInfoList = result;
      this.agGridOptions();
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }

  tabClick(evt) {
    if (evt.heading === 'Processed') {
      this.search("A")
      this.showInprogress = false
    }
    if (evt.heading === 'In Progress') {
      this.search("P")
      this.showInprogress = true
    }
  }

  onRefClicked(data) {
    this.loaderService.isBusy = true;
    let batchId = data.tbiBatId;
    this.isClicked = true;
    this.prmBorderxService.getPremSummBdx(batchId).subscribe(res => {
      this.loaderService.isBusy = false;
      this.router.navigate(["premium-bordereaux-upload"], { queryParams: { 'isView': true, 'batchId': batchId }, skipLocationChange: true }).then(() => {
        console.log("res***********", res);
        this.prmBorderxService.setUploadNewClk(res);
      });
    }, error => {
      // this.toastService.error('error');
      this.showErrorDialogBox(error.error.message);
      this.loaderService.isBusy = false
    })
  }
  showErrorDialogBox(apprErrorMsg) {
    this.open(this.errorModal, 1, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        this.errorModalDetails = value;
      });
    }, 200);
  }
  onViewAcc(data) {
    this.loaderService.isBusy = true
    let docNo = data.tbiDocNo;
    let batchId = data.tbiBatId;
    let tranNo = data.tbiTranCode;
    this.isClicked = true;
    this.router.navigate(["premium-bordereaux/accounting-entry"], {
      queryParams: {
        'docNo': docNo,
        'batchId': batchId,
        'tranNo': tranNo
      }, skipLocationChange: true
    });
  }

  onRowClickedPro(evt) {
    this.batchId = evt.data.tbiBatId
    // let actionType = evt.event.target.getAttribute('data-action-type');
    // switch (actionType) {
    //   case 'Reverse':
    //     return document.getElementById("openReverse").click();
    // }
  }

  // reverseBatch() {
  //   this.loaderService.isBusy = true;
  //   let data;
  //   document.getElementById("closeReverse").click();
  //   this.prmBorderxService.reversePremium(this.batchId, data).subscribe(res => {
  //     this.search('A')
  //     // this.loaderService.isBusy = false;
  //   }, error => {
  //     this.loaderService.isBusy = true
  //   })
  // }

  reset() {
    this.searchForm.patchValue({
      tbiAcntDtFm: '',
      tbiAcntDtTo: '',
      batchDate: '',
      mga: null,
      batchprocessedby: null,
    });
    this.pageChanged({ page: 1 });
    if (!this.showInprogress) {
      this.search('A');
    } else {
      this.search('P');
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }


  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'PremiumBordereauxSummary.xlsx',
        skipHeader: false,
        sheetName: 'Premium Bordereaux Summary',
        processCellCallback: (params) => {
          if (params.column.colId == "tbiBatDt" || params.column.colId == "tbiAcntDt"
            || params.column.colId == "tbiCloseDt" || params.column.colId == "tbiCloseToDt"
            || params.column.colId == "tbiSetlDueDt") {
            return params.value;
          } else if (params.column.colId == 'tbiApprSts') {
            if (params.value == 'A')
              return 'Approved';
            else if (params.value == 'P')
              return 'Pending'
            else
              return params.value;
          } else if (params.column.colId == "tbiGrossPremLc1" || params.column.colId == "tbiIptLc1"
            || params.column.colId == "tbiStampDutyLc1" || params.column.colId == "tbiBrkCommLc1"
            || params.column.colId == "tbiNetPremLc1") {
            if (params.value) {
              return parseFloat((params.value).replace(/,/g, ''));
            } else {
              return "";
            }
          } else {
            return params.value;
          }
        },
      });
    }
  }
  onFirstDataRendered(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('mgadashboard').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: this.batchInfoList,
      enableFilter: true
    };
    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
  }

  openUploadPopup() {
    this.batchUploadForm.reset();
    this.fileList = [];
    if (this.id) {
      clearInterval(this.id);
      this.postpercentage = 0;
    }
    this.open(this.batchUploadModal, 2, 'modal-md');
  }

  batchUploadForm: UntypedFormGroup;
  createBatchUploadForm() {
    this.batchUploadForm = this.fb.group({
      // bindRefNo: ["", Validators.required],
      // bindSeqNo: ["", Validators.required],
      // bindAmendNo: ["", Validators.required],
      // binderMgaCode: ["", Validators.required]
      binderRefId: '',
      binderMgaCode: ''
    });
  }

  removeFile(index) {
    this.fileList.splice(index, 1);
  }

  formatFileSize(bytes, decimalPoint) {
    if (bytes == 0) return '0 KB';
    var k = 1000,
      dm = decimalPoint || 2,
      sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  fileList: any = [];
  localQueue: any[] = [];
  timer: any;
  noFiles: Boolean = false;

  uploadBatchFile() {
    // this.cleanUploadForm();
    //$("#batchUploadModal").modal("hide");
    //this.closeModal();
    // //this.router.navigate(['/premium-bordereaux-upload']);
    // this.router.navigate(["premium-bordereaux-upload"]).then(() => {
    //   resData["action"] = "UPLOADNEW";
    //   this.prmBorderxService.setUploadNewClk(resData);
    // });
    if (this.batchUploadForm.valid) {
      this.loaderService.isBusy = true;
      let data = this.batchUploadForm.getRawValue();
      let formData = new FormData();
      let batchId = '';
      let refId = data.binderRefId;
      // formData.append("binderRefId", (data.binderRefId) ? data.binderRefId : "");
      // formData.append("bindSeqNo", (data.bindSeqNo) ? data.bindSeqNo : "");
      // formData.append("bindAmendNo", (data.bindAmendNo) ? data.bindAmendNo : "");
      // formData.append("binderMgaCode", (data.binderMgaCode) ? data.binderMgaCode : "");
      // formData.append("batchId", "");

      if (this.fileList.length > 1) {
        this.toastService.warning("You can only upload a maximum of 1 file!");
        this.loaderService.isBusy = false;
      } else if (this.fileList.length == 1) {
        formData.append("ufile", this.fileList[0]);
        this.id = setInterval(() => {
          this.getProgressInfo();
        }, 1500);
        this.prmBorderxService.readAndUploadDoc(formData).subscribe(resp => {
          this.loaderService.isBusy = false;
          let batchId = resp.batchInfoDTO.tbiBatId;
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          }
          this.closeModal(2);
          this.cleanUploadForm();
          this.router.navigate(["premium-bordereaux-upload"], { queryParams: { 'isView': false, 'batchId': batchId }, skipLocationChange: true }).then(() => {
            this.prmBorderxService.setUploadNewClk(resp);
          });
        }, error => {
          if (this.id) {
            clearInterval(this.id);
            this.postpercentage = 0;
          }
          this.closeModal(2);

          if (error instanceof HttpErrorResponse) {
            if (error.error instanceof ErrorEvent) {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            } else {
              switch (error.status) {
                case 400:
                  this.loaderService.isBusy = false;
                  this.showErrorDialogBox(error.error.message);
                  break;
                default:
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in upload!");
                  break;
              }
            }
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in upload!");
          }
        });
      } else {
        this.toastService.warning("Please select file!");
        this.loaderService.isBusy = false;
      }
    } else {
      this.validateAllFormFields(this.batchUploadForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }

  cleanUploadForm() {
    this.batchUploadForm.reset();
    this.fileList = [];
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }


  public uploader: FileUploader = new FileUploader({
    url: "",
    autoUpload: false,
    method: '',
    disableMultipart: false,
    // authTokenHeader: 'Authorization',
    //authToken: 'Bearer ' + JSON.parse(this.session.get('authToken')),
    itemAlias: 'document',
    removeAfterUpload: false,
  });

  public hasBaseDropZoneOver = false;

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public onAfterAddingFile = (file) => {
  }

  public onFileSelected(event: File[]) {

    if (this.fileList.length > 0) {
      this.toastService.warning("You can only upload a maximum of 1 file!");
      return false;
    } else {
      //const file: File = event[0];
      for (let index = 0; index < event.length; index++) {
        event[index]['filesize'] = this.formatFileSize(event[index]['size'], 2);
        this.fileList.push(event[index]);
      }
    }

  }

  mgaCodeList: any = [];
  getMgaCode() {
    this.prmBorderxService.getMGAlist().subscribe(resp => {
      this.mgaList = resp;
      this.mgaList = (this.mgaList as any[]).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });
      this.mgaList.unshift({ code: null, displayText: 'All' });
    })

  }
  reterieveUWriterList() {
    // let roleId = this.session.get('roleId');
    this.commonService.getUserList('premSummBdx').subscribe((users: any) => {
      this.userList = users;
      this.userList.unshift({ key: null, value: 'All' });
    })
  }
  getProgressInfo() {
    let passData;
    if (this.batchId && this.batchId !== undefined) {
      passData = this.batchId
    } else {
      passData = this.session.get('userId') + '' + this.session.get('companyCode') + '' + this.session.get('userDeptCode');
    }
    let progressData;
    this.prmBorderxService.uploadProgress(passData).subscribe((res: any) => {
      progressData = res.mProcessInfoArray;
      let posting = progressData.filter(function (ele) {
        if (ele) {
          if (ele.mpiProcessName == "Premium Summary BDX Upload") {
            return ele;
          }
        }
      })
      if (posting.length != 0) {
        this.postpercentage = posting[0].mpiProgressPcnt > 100 ? 100 : posting[0].mpiProgressPcnt;
      } else {
        this.postpercentage = 0;
      }
    }, err => {
      if (this.id) {
        clearInterval(this.id);
        this.postpercentage = 0;
      }
    })
  }
  ngOnDestroy() {
    if (this.id) {
      clearInterval(this.id);
      this.postpercentage = 0;
    }
  }
}
