import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumBordereauxUploadComponent } from './premium-bordereaux-upload.component';

describe('PremiumBordereauxUploadComponent', () => {
  let component: PremiumBordereauxUploadComponent;
  let fixture: ComponentFixture<PremiumBordereauxUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumBordereauxUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumBordereauxUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
