import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { FileUploader } from 'ng2-file-upload';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { DocumentService } from 'src/app/shared/components/document/document.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { MgaDocumentsComponent } from 'src/shared/components/mga-documents/mga-documents.component';
import { PremiumBordereauxService } from './../../services/premium-bordereaux.service';
import { Utils } from './../../utils';

@Component({
  selector: 'premium-bordereaux-upload',
  templateUrl: './premium-bordereaux-upload.component.html',
  styleUrls: ['./premium-bordereaux-upload.component.scss']
})
export class PremiumBordereauxUploadComponent implements OnInit {
  batchId: any;
  docNo: any;
  batchInfoDTOForm: UntypedFormGroup;
  batchInfo: any;
  currencyCode: any;
  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  public coInsDefaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  batchInfoList: any;
  paginationPageSize: number;
  rowGroupPanelShow: string;
  tranNo: any;
  hideErrorColumn: boolean = true;

  uploadNewSubscribers: Subscription;
  uploadNewData: any;
  errorNos: any;
  // rowClassRules: any;
  public modules = [ClientSideRowModelModule];
  public hasBaseDropZoneOver = false;

  downloadLink: any;
  fileList: any = [];
  localQueue: any[] = [];
  timer: any;
  noFiles: Boolean = false;
  isView: Boolean = false;
  status: any;
  errorDescription: any;
  selectedCoinsurance = null;
  showCoInsEntriesOptionSelected = 10;
  coinsuranceGridApi: any;
  quickCoinsuranceSearchValue: string = '';
  pinnedBottomRowData: any;
  coinsuranceColumnDefs: any;
  coinsuranceList: any;
  showCoinsuranceDetail = false;
  documents: any;
  isDocumentNeedsToBeUpdated: any;
  documentRefId: string;
  documentTypes: any;
  summaryView: Boolean = true;
  @ViewChild('batchUploadModal1', { static: true }) batchUploadModal1: ElementRef;
  @ViewChild('validateCheckSumModal2', { static: true }) validateCheckSumModal2: ElementRef;
  @ViewChild('confirmModal3', { static: true }) confirmModal3: ElementRef;
  @ViewChild('uploadHistory4', { static: true }) uploadHistory4: ElementRef;
  @ViewChild('apprConfirmModal5', { static: true }) apprConfirmModal5: ElementRef;
  @ViewChild('batchReverseModal6', { static: true }) batchReverseModal6: ElementRef;
  @ViewChild('batchDeleteModal7', { static: true }) batchDeleteModal7: ElementRef;
  @ViewChild('errorModal8', { static: true }) errorModal8: ElementRef;
  @ViewChild('checksumUploadHistory9', { static: true }) checksumUploadHistory9: ElementRef;
  isreUpload: boolean = false;
  appvBtnDisable: boolean = false;
  pStatus: any;
  statusClass: any;
  getRowStyle: any;
  title;
  @ViewChild(MgaDocumentsComponent) uploadDoc: MgaDocumentsComponent;
  docMetadata: any;
  listOfFiles: any;
  insPercentage: any;
  postpercentage: number;
  progressList: any;
  postingList: any;
  id: any;
  enableProgressBar: boolean = false;
  uploadHistoryData: any = [];
  isValidateCheckSum: boolean = false;
  validateCheckSumData: any = {};
  errorCheckSum: any;
  checksumDisable: any = false;
  checksumUploadHistoryData: any = [];

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private prmBorderxService: PremiumBordereauxService,
    private activeRoute: ActivatedRoute,
    private treatyService: TreatyService,
    private modalService: BsModalService,
    private docService: DocumentService,

  ) {

    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.coInsDefaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false
    };
    this.createbatchInfoDTOForm();
    this.createBatchUploadForm();

    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
    this.uploadNewSubscribers = this.prmBorderxService.getUploadNewClk().subscribe((data) => {
      this.uploadNewData = data;
      this.errorNos = Number(this.uploadNewData.batchInfoDTO.tbiFlex04);
      this.status = this.uploadNewData.batchInfoDTO.tbiApprSts;
      this.appvBtnDisable = (this.status == 'A') ? true : false;
      if (this.status !== 'A') {
        if (this.errorNos == 0) {
          if (this.uploadNewData.isChecksumValidationRequired) {
            this.checksumDisable = this.uploadNewData.isChecksumValidationRequired
          } else {
            this.checksumDisable = this.uploadNewData.isChecksumValidationRequired;
          }
        } else {
          this.checksumDisable = false;
        }
      }

      this.documentRefId = this.uploadNewData.batchInfoDTO.tbiBatType + '-' + this.uploadNewData.batchInfoDTO.tbiBatId;
      this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
      this.downloadLink = this.uploadNewData.batchInfoDTO.tbiFlex03;
      this.batchInfoList = this.uploadNewData.psbDTOs;
      this.createbatchInfoDTOForm();
      this.agGridOptions();
      if (this.errorNos > 0) {
        this.downloadErrorFile(this.downloadLink, this.uploadNewData.docMetadata.fileName);
        this.hideErrorColumn = false;
        this.status = 'P';
      } else {
        this.hideErrorColumn = true;
      }
      this.setFunctionalCurrency();
      setTimeout(() => {
        this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
      }, 1000);
    }, error => {
      this.toastService.error('Something Wrong !!!');
      this.loaderService.isBusy = false;
    });
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (params) {
        this.isView = params.isView;
        this.batchId = params.batchId;
        this.title = params.title;
      }
    });
    if (this.title === 'viewAccBack') {
      this.loaderService.isBusy = true;
      this.createbatchInfoDTOForm();
    }
    const context = this;
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (this.batchId != null) {
        this.prmBorderxService.getPremSummBdx(this.batchId).subscribe((data: any) => {
          this.loaderService.isBusy = true;
          this.uploadNewData = data;
          this.errorNos = Number(this.uploadNewData.batchInfoDTO.tbiFlex04);
          this.status = this.uploadNewData.batchInfoDTO.tbiApprSts;
          this.appvBtnDisable = (this.status == 'A') ? true : false;
          // if (this.status !== 'A') {
          //   this.checksumDisable = this.uploadNewData.isChecksumValidationRequired;
          // }
          if (this.status !== 'A') {
            if (this.errorNos == 0) {
              if (this.uploadNewData.isChecksumValidationRequired) {
                this.checksumDisable = this.uploadNewData.isChecksumValidationRequired
              } else {
                this.checksumDisable = this.uploadNewData.isChecksumValidationRequired;
              }
            } else {
              this.checksumDisable = false;
            }
          }

          this.documentRefId = this.uploadNewData.batchInfoDTO.tbiBatType + '-' + this.uploadNewData.batchInfoDTO.tbiBatId;
          this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
          this.downloadLink = this.uploadNewData.batchInfoDTO.tbiFlex03;
          this.batchInfoList = this.uploadNewData.psbDTOs;
          this.createbatchInfoDTOForm();
          this.agGridOptions();
          if (this.errorNos > 0) {
            this.downloadErrorFile(this.downloadLink, this.uploadNewData.docMetadata.fileName);
            this.hideErrorColumn = false;
            this.status = 'P';
          } else {
            this.hideErrorColumn = true;
          }
          this.setFunctionalCurrency();
          setTimeout(() => {
            this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
          }, 1000);
          if (this.title == 'viewAccBack') {
            this.viewAccountBack(data);
          }

        }, error => {
          this.toastService.error('error');
          this.loaderService.isBusy = false;
        })
      } else {
        this.loaderService.isBusy = false;
      }
    });
    this.columnDefs = [
      {
        field: 'tpsBindRefNo',
        headerName: 'Contract Ref No',
        headerTooltip: 'Contract Ref No',
        width: 95,
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.data && params.data.tpsContractType == "2") {
            return '<span data-action-type="Coinsurance" style="textAlign: left;color: #036aff;font-weight: bold;text-decoration: underline;text-decoration-color: #036aff;cursor: pointer">' + params.value + '</span>';
          } else if (params.data && params.data.tpsContractType == "1") {
            return '<span data-action-type="Direct">' + params.value + '</span>';
          } else {
            return params.value;
          }
        },
        valueGetter: function (params) {
          if (params.data && params.data.tpsBindRefNo) {
            return params.data.tpsBindRefNo + ' / ' + params.data.tpsBindSeqNo + ' / ' + params.data.tpsBindAmendNo;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tpsContractTypeDesc',
        headerName: 'Contract Type',
        headerTooltip: 'Contract Type',
        cellStyle: { textAlign: 'left' },
        width: 110
      },
      {
        field: 'tpsMgaCodeDesc',
        headerName: 'Sub MGA Code & Name',
        headerTooltip: 'Sub MGA Code & Name',
        cellStyle: { textAlign: 'center' },
        width: 110,
        tooltipField: 'tpsMgaCodeDesc'
      },
      {
        field: 'tpsDivnCode',
        headerName: 'Company',
        headerTooltip: 'Company',
        valueGetter: function (params) {
          if (params.data && params.data.tpsDivnCode && params.data.tpsDivnCodeDesc) {
            return params.data.tpsDivnCode + ' - ' + params.data.tpsDivnCodeDesc;
          } else {
            return "";
          }
        },
        cellRenderer: Utils.tooltipRenderer,
        width: 130,
      },
      {
        field: 'tpsLobCode',
        headerName: 'Product type/LOB',
        headerTooltip: 'Product type/LOB',
        valueGetter: function (params) {
          if (params.data && params.data.tpsLobCode) {
            return params.data.tpsLobCode + ' - ' + params.data.tpsLobCodeDesc;
          } else {
            return "";
          }
        },
        cellRenderer: Utils.tooltipRenderer,
        width: 110,
      },
      {
        field: 'tpsProdCodeDesc',
        headerName: 'Product Group/Subproduct',
        headerTooltip: 'Product Group/Subproduct',
        cellStyle: { textAlign: 'center' },
        width: 110,
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params.data && params.data.tpsProdCode) {
            return params.data.tpsProdCode + ' - ' + params.data.tpsProdCodeDesc;
          } else {
            return "";
          }
        }
      },
      {
        field: 'tpsAcntYear',
        headerName: 'Year of Acnt',
        headerTooltip: 'Year of Acnt',
        cellStyle: { textAlign: 'center' },
        width: 110,
      },
      {
        field: 'tpsLedgDesc',
        headerName: 'Ledger Desc',
        cellStyle: { textAlign: 'left' },
        tooltipField: 'tpsLedgDesc',
        headerTooltip: 'Ledger Desc',
      },
      {
        field: 'tpsCurr',
        headerName: 'Currency',
        cellStyle: { textAlign: 'center' },
        tooltipField: 'tpsCurr',
        headerTooltip: 'Currency',
      },
      {
        field: 'tpsExchangeRate',
        headerName: 'Exchange Rate',
        cellStyle: { textAlign: 'right' },
        tooltipField: 'tpsExchangeRate',
        headerTooltip: 'Exchange Rate',
        valueFormatter: Utils.fixedRateFormatter,
      },
      {
        width: 110,
        headerName: 'W - Premium',
        field: 'tpsWgrossPremFc',
        headerTooltip: 'Written Premium',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWgrossPremFc) {
            return Number(params.data.tpsWgrossPremFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWgrossPremFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'W - IPT',
        field: 'tpsWiptFc',
        headerTooltip: 'Written IPT',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWiptFc) {
            return Number(params.data.tpsWiptFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWiptFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'W - Stamp Duty',
        field: 'tpsWstampDutyFc',
        headerTooltip: 'Written Stamp Duty',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWstampDutyFc) {
            return Number(params.data.tpsWstampDutyFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWstampDutyFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'W - Commission',
        field: 'tpsWbrkCommFc',
        headerTooltip: 'Written TP Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWbrkCommFc) {
            return Number(params.data.tpsWbrkCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWbrkCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'B - Premium',
        field: 'tpsGrossPremFc',
        headerTooltip: 'Booked Premium',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsGrossPremFc) {
            return Number(params.data.tpsGrossPremFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsGrossPremFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'B - IPT',
        field: 'tpsIptFc',
        headerTooltip: 'Booked IPT',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsIptFc) {
            return Number(params.data.tpsIptFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsIptFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'B - Stamp Duty',
        field: 'tpsStampDutyFc',
        headerTooltip: 'Booked Stamp Duty',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsStampDutyFc) {
            return Number(params.data.tpsStampDutyFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsStampDutyFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'B - Commission',
        field: 'tpsBrkCommFc',
        headerTooltip: 'Booked TP Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsBrkCommFc) {
            return Number(params.data.tpsBrkCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsBrkCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'B - MGA Commission',
        field: 'tpsMinCommFc',
        headerTooltip: 'Booked MGA Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsMinCommFc) {
            return Number(params.data.tpsMinCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsMinCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'B - Adv. MGA Commission',
        field: 'tpsAdvCommFc',
        headerTooltip: 'Booked Adv. MGA Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsAdvCommFc) {
            return Number(params.data.tpsAdvCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsAdvCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'Placing Broker Fee',
        field: 'tpsPbrkFeeFc',
        headerTooltip: 'Placing Broker Fee',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsPbrkFeeFc) {
            return Number(params.data.tpsPbrkFeeFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsPbrkFeeFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'Accounting Broker Fee',
        field: 'tpsAbrkFeeFc',
        headerTooltip: 'Accounting Broker Fee',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsAbrkFeeFc) {
            return Number(params.data.tpsAbrkFeeFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsAbrkFeeFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        headerName: 'Net Amount',
        field: 'tpsNetAmtFc',
        headerTooltip: 'Net Amount',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsNetAmtFc) {
            return Number(params.data.tpsNetAmtFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsNetAmtFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },

      {
        field: 'tpsErrorMsg',
        headerName: 'Error Details',
        headerTooltip: 'Error Details',
        tooltipField: 'tpsErrorMsg',
        cellRenderer: function (params) {
          if (params && params.data && params.data.tpsErrorMsg) {
            return `<a><i class="fa fa-eye" style="transform: scaleX(-1);"  data-action-type="ViewEye" title="Click to View Error Details" aria-hidden="true"></i>&nbsp;</a>` + ' ' + params.data.tpsErrorMsg;
          } else {
            return '';
          }
        },
        width: 110,
        resizable: true,
        sortable: true,
        filter: false,
        enableRowGroup: false,
        hide: this.hideErrorColumn
      }
    ];
    this.currencyCode = this.session.get('baseCurrency');
    if (this.errorNos != 0) {
      this.summaryView = false;
    }
    this.context = { componentParent: this };
    this.getDocumentTypes();
    this.getApproveStatus();
    this.setCoinsuranceColumnDefs();

  }
  viewAccountBack(data) {
    this.uploadNewData = data;
    this.errorNos = Number(this.uploadNewData.batchInfoDTO.tbiFlex04);
    this.status = this.uploadNewData.batchInfoDTO.tbiApprSts;
    this.appvBtnDisable = (this.status == 'A') ? true : false;

    this.documentRefId = this.uploadNewData.batchInfoDTO.tbiBatType + '-' + this.uploadNewData.batchInfoDTO.tbiBatId;
    this.downloadLink = this.uploadNewData.batchInfoDTO.tbiFlex03;
    this.docMetadata = this.uploadNewData.batchInfoDTO.tbiFlex05;
    this.batchInfoList = this.uploadNewData.psbDTOs;
    //this.createbatchInfoDTOForm();
    this.agGridOptions();
    if (this.errorNos > 0) {
      this.downloadErrorFile(this.downloadLink, this.uploadNewData.docMetadata.fileName);
      this.hideErrorColumn = false;
      //this.status = 'P'
    } else {
      this.hideErrorColumn = true;
      //this.status = 'P'
    }
    this.summaryView = true;
    this.setFunctionalCurrency();
    this.getApproveStatus()
  }
  getApproveStatus() {
    if (this.status == 'A') {
      this.pStatus = 'Approved';
    } else if (this.status == 'R') {
      this.pStatus = 'Reversed';
    } else {
      this.pStatus = 'Pending';
    }
  }
  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res;
      }, err => {
      });
  }
  createbatchInfoDTOForm() {
    this.batchInfoDTOForm = this.fb.group({
      tbiGrossPremLc1: [undefined],
      tbiIptLc1: [undefined],
      tbiStampDutyLc1: [undefined],
      tbiBrkCommLc1: [undefined],
      tbiNetPremLc1: [undefined],
      tbiNetAmtLc1: [undefined],
    })
  }
  back() {
    this.router.navigate(['/premium-bordereaux'], { queryParams: { title: 'home' } });
  }
  closePremium() {
    this.router.navigate(['/premium-bordereaux'], { queryParams: { title: 'home' } });
  }
  openReversePopup() {
    this.open(this.batchReverseModal6, 6, 'modal-md');
  }
  reversePremium() {
    let data;
    this.loaderService.isBusy = true;
    this.loaderService.isLoadingShow = 'reversalTemplate';
    this.prmBorderxService.reversePremium(this.batchId, data).subscribe(res => {
      this.prmBorderxService.getPremSummBdx(this.batchId).subscribe(res => {
        this.status = res.batchInfoDTO.tbiApprSts;
        this.getApproveStatus();
      })
      this.loaderService.isBusy = false;
      this.loaderService.isLoadingShow = '';
      this.toastService.success('Reversed successfully');
      this.closeModal(6);
    }, error => {
      if (error.error["messageType"] && error.error["messageType"] == 'E') {
        // this.toastService.error(error.error.message);
        this.showErrorDialogBox(error.error.message);
        this.loaderService.isBusy = false;
        this.loaderService.isLoadingShow = '';
      } else {
        this.toastService.error('Error reverse record');
        this.loaderService.isBusy = false;
        this.loaderService.isLoadingShow = '';
      }
    })
  }
  openDeletePremium() {
    this.open(this.batchDeleteModal7, 7, 'modal-md');
  }
  deletePremium() {
    this.loaderService.isBusy = true;
    this.prmBorderxService.deletePremium(this.batchId).subscribe(res => {
      document.getElementById("closeDelete").click();
      this.getFileListDoc();
      this.toastService.success('Deleted successfully');
      this.router.navigate(['/premium-bordereaux'], { queryParams: { title: 'home' } });
      this.loaderService.isBusy = false;
    }, error => {
      if (error.error["messageType"] && error.error["messageType"] == 'E') {
        this.showErrorDialogBox(error.error.message);
        document.getElementById('closeDelete').click();
        this.loaderService.isBusy = false;
      }
      this.loaderService.isBusy = false;
    });
  }
  checkDocsBeforeApprove() {

    this.docService.getMetaDataSearch(this.docMetadata).subscribe((data: any) => {
      if (data.length == 0) {
        this.toastService.error('Batch cannot be approved without documentation. Please upload the relevant documents prior to approval.');
        document.getElementById('closeApprove').click();
        this.loaderService.isBusy = false;
      } else {
        this.loaderService.isLoadingShow = 'approvalTemplate';
        this.prmBorderxService.approvePremium(this.batchId).subscribe((res: any) => {
          if (res["messageType"] && res["messageType"] == 'E') {
            document.getElementById('closeApprove').click();
            this.showErrorDialogBox(res.message);
            this.getApproveStatus();
            // this.toastService.error('Not approved');
            this.loaderService.isBusy = false;
            this.loaderService.isLoadingShow = '';
          } else {
            document.getElementById('closeApprove').click();
            this.toastService.success('Approved Successfully.');
            this.appvBtnDisable = true;
            this.status = 'A';
            this.getApproveStatus();
            this.loaderService.isBusy = false;
            this.loaderService.isLoadingShow = '';
          }
        }, error => {
          if (error.error["messageType"] && error.error["messageType"] == 'E') {
            // document.getElementById('closeApprove').click();
            this.closeModal(5);
            this.showErrorDialogBox(error.error.message)
            this.getApproveStatus();
            // this.toastService.error('Not approved');
            this.loaderService.isBusy = false;
            this.loaderService.isLoadingShow = '';
          }
          this.loaderService.isBusy = false;
          this.loaderService.isLoadingShow = '';
        });
      }
    },
      err => {
        this.toastService.error('Error getting document(s).');
        this.loaderService.isBusy = false;
      }
    );
  }
  getFileListDoc() {
    this.docService.getMetaDataSearch(this.docMetadata).subscribe(data => {
      this.listOfFiles = data;
      if (this.listOfFiles.length > 0) {
        this.listOfFiles.forEach(element => {
          this.uploadDoc.confirmDelete(element.gridFSId);
        });
      }
    },
      err => {
        this.toastService.error('Error getting document(s).');
      }
    );
  }

  savePremium() {
    this.loaderService.isBusy = true
    this.prmBorderxService.savePremium(this.batchId).subscribe(res => {
      this.toastService.success('saved successfully');
      this.router.navigate(['/premium-bordereaux'], { queryParams: { title: 'home' } });
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error('Not saved');
      this.loaderService.isBusy = false;
    })
  }


  onRowClickedPro(evt) {
    this.errorDescription = evt.data.tpsErrorMsg;
    let actionType = evt.event.target.getAttribute('data-action-type');
    switch (actionType) {
      case 'ViewEye':
        return this.showDialogbox();
      case 'Coinsurance':
        if (evt.data && evt.data.tpsContractType == "2") {
          this.selectedCoinsurance = evt.data;
          this.getCoinsurerDetails();
        } else {
          this.showCoinsuranceDetail = false;
        }
        break;
      case 'Direct':
        if (evt.data && evt.data.tpsContractType == "1") {
          this.showCoinsuranceDetail = false;
        }
        break;
    }
  }
  showDialogbox() {
    // this.temp = data.binderLobPK;
    this.open(this.confirmModal3, 3, 'modal-sm');
    setTimeout(() => {
      const str = this.errorDescription.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  showErrorDialogBox(apprErrorMsg) {
    this.open(this.errorModal8, 8, 'modal-md');
    apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
    const str = apprErrorMsg.split(",");
    str.forEach((value, element) => {
      document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
    });
  }
  showUploadHistoryDialogBox() {
    this.open(this.uploadHistory4, 4, 'modal-md');
    this.prmBorderxService.uploadHistory(this.batchId, this.status).subscribe(res => {
      this.uploadHistoryData = res;
      if (this.uploadHistoryData && this.uploadHistoryData.length == 0) {
        document.getElementById("uploadHistoryDetails").style.display = 'none';
        document.getElementById("uploadHistoryDetails1").innerHTML += "<p>No Data Available </p>";
      } else {
        document.getElementById("uploadHistoryDetails").style.display = 'block';
      }
    }, error => {
      this.toastService.error('Error in getting Upload History');
      this.loaderService.isBusy = false;
    });
  }
  showChecksumUploadHistoryDialogBox() {
    this.open(this.checksumUploadHistory9, 9, 'modal-lg');
    this.prmBorderxService.checkSumUploadHistory(this.batchId).subscribe(res => {
      this.checksumUploadHistoryData = res;
      if (this.checksumUploadHistoryData && this.checksumUploadHistoryData.length == 0) {
        document.getElementById("checksumUploadHistoryDetails").style.display = 'none';
        document.getElementById("checksumUploadHistoryDetails1").innerHTML += "<p>No Data Available </p>";
      } else {
        document.getElementById("checksumUploadHistoryDetails").style.display = 'block';
      }
    }, error => {
      this.toastService.error('Error in getting Upload History');
      this.loaderService.isBusy = false;
    });
  }

  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val });
  }
  closeModal(id) {
    this.modalService.hide(id);
  }
  approve() {
    this.loaderService.isBusy = true;
    this.checkDocsBeforeApprove();
  }
  viewAccounting() {
    this.router.navigate(['/mga-view-accounting'], { queryParams: { batchId: this.batchId, binder: 'BIND_PRM', status: this.status } });
  }
  downloadErrorFile(file: any, filename: any) {
    this.prmBorderxService.getDocuments(file).subscribe((data: any) => {
      const blob = new Blob([data], { type: 'application/vnd.ms.excel' });
      const url = window.URL.createObjectURL(blob);
      document.getElementById("excelDownloadLink").innerHTML = "<a class='pr-8' href='" + url + "' download='" + filename + "'>" +
        "<i class='fa fa-download fa-icon' style='padding: 10px;' aria-hidden='true'></i></a>";
    },
      err => {
        this.toastService.error('Error downloading document(s).');
      }
    );
  }
  downloadDocument(file: any) {
    this.docService.getDocuments(file.tbiFlex08).subscribe((data) => {
      const blob = new Blob([data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.tbiFlex10;
      document.body.appendChild(a);
      a.click();
    },
      err => {
        this.toastService.error('Error downloading document(s).');
      }
    );
  }
  downloadChecksumFile(file: any) {
    this.docService.getDocuments(file.tuhFlex01).subscribe((data) => {
      const blob = new Blob([data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.tuhFileName;
      document.body.appendChild(a);
      a.click();
    },
      err => {
        this.toastService.error('Error downloading document(s).');
      }
    );
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    const params = {
      columnKeys: [
        'tpsBindRefNo', 'tpsContractTypeDesc', 'tpsMgaCodeDesc', 'tpsDivnCode', 'tpsLobCode', 'tpsProdCodeDesc', 'tpsAcntYear', 'tpsCurr', 'tpsExchangeRate', 'tpsWgrossPremFc', 'tpsWiptFc', 'tpsWstampDutyFc', 'tpsWbrkCommFc', 'tpsGrossPremFc', 'tpsIptFc', 'tpsStampDutyFc', 'tpsBrkCommFc', 'tpsMinCommFc', 'tpsAdvCommFc', 'tpsPbrkFeeFc', 'tpsAbrkFeeFc', 'tpsNetAmtFc']
    };
    if (!this.hideErrorColumn) {
      params.columnKeys.push('tpsErrorMsg');
    }
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        fileName: 'Premium_Summary.xlsx',
        skipHeader: false,
        sheetName: 'Premium Summary',
        processCellCallback: (params) => {
          if (params.column.colId == "tpsWgrossPremFc" || params.column.colId == "tpsWiptFc" || params.column.colId == "tpsWstampDutyFc" || params.column.colId == "tpsBrkCommFc" || params.column.colId == "tpsWbrkCommFc"
            || params.column.colId == "tpsGrossPremFc" || params.column.colId == "tpsIptFc" || params.column.colId == "tpsStampDutyFc" || params.column.colId == "tpsMinCommFc" || params.column.colId == "tpsAdvCommFc"
            || params.column.colId == "tpsPbrkFeeFc" || params.column.colId == "tpsAbrkFeeFc" || params.column.colId == "tpsNetAmtFc") {
            if (params.value) {
              return parseFloat((params.value).replace(/,/g, ''));
            } else {
              return "";
            }
          } else {
            return params.value;
          }
        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('mgadashboard').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: this.batchInfoList,
      enableFilter: true,
      rowClassRules: {
        'ag-red-pink-outer': function (params) {
          if (params.data !== undefined) {
            if (params.data.tpsErrorMsg != null) {
              return true;
            } else {
              return false;
            }
          }
        }
      }
    };
    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
  }

  // setBatchInfoGridList() {
  //   this.batchInfoList = this.uploadNewData.psbDTOs;
  //   // for (let i = 0; i < this.uploadNewData.errorPsbDTOs.length; i++) {
  //   //   this.batchInfoList.push(this.uploadNewData.errorPsbDTOs[i]);
  //   // }
  // }
  premiumStatus: any;
  setFunctionalCurrency() {
    if (this.title === 'viewAccBack') {
      this.createbatchInfoDTOForm();
    }
    let data = this.uploadNewData.batchInfoDTO;
    let netCommission = data.tbiGrossPremLc1 - data.tbiBrkCommLc1
    // let netAmount = data.tbiGrossPremLc1 - (data.tbiBrkCommLc1 + data.tbiIptLc1 + data.tbiStampDutyLc1);
    let netAmount = (data.tbiGrossPremLc1 - data.tbiBrkCommLc1) + data.tbiIptLc1 + data.tbiStampDutyLc1;
    this.batchInfoDTOForm.patchValue({
      tbiGrossPremLc1: Utils.currencyFormatter(data.tbiGrossPremLc1),
      tbiIptLc1: Utils.currencyFormatter(data.tbiIptLc1),
      tbiStampDutyLc1: Utils.currencyFormatter(data.tbiStampDutyLc1),
      tbiBrkCommLc1: Utils.currencyFormatter(data.tbiBrkCommLc1),
      tbiNetPremLc1: Utils.currencyFormatter(netCommission),
      tbiNetAmtLc1: Utils.currencyFormatter(netAmount)
    });
    this.batchInfoDTOForm.disable();
    this.batchId = data.tbiBatId;
    this.docNo = data.tbiDocNo;
    this.tranNo = data.tbiTranCode;
    this.premiumStatus = this.uploadNewData.batchInfoDTO.tbiApprSts;
    this.loaderService.isBusy = false;
  }
  // Batch Upload //

  // Premium coinsurance //

  setCoinsuranceColumnDefs() {

    this.coinsuranceColumnDefs = [
      {
        field: 'tpsBindRefNo',
        headerName: 'Contract Ref No',
        headerTooltip: 'Contract Ref No',
        width: 100,
      },
      {
        field: 'tpcCustCodeDesc',
        headerName: 'Coinsurer',
        headerTooltip: 'Coinsurer',
        width: 120,
        cellStyle: { textAlign: 'left' },
        valueGetter: function (params) {
          if (params.data && params.data.tpcCustCode && params.data.tpcCustCodeDesc) {
            return params.data.tpcCustCode + ' - ' + params.data.tpcCustCodeDesc;
          } else {
            return "";
          }
        },
      },
      {
        field: 'tpcLeaderYn',
        headerName: 'Leader',
        headerTooltip: 'Leader',
        width: 100,
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.tpcLeaderYn) {
            if (params.data.tpcLeaderYn == "1") {
              return 'Yes';
            } else {
              return 'No';
            }
          } else {
            return "";
          }
        },
      },
      {
        field: 'tpcSharePerc',
        headerName: 'Share %',
        headerTooltip: 'Share %',
        valueFormatter: Utils.toFixedFun4,
        width: 100,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tpsWgrossPremFc',
        headerName: 'W - Premium',
        headerTooltip: 'W - Premium',
        width: 100,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWgrossPremFc) {
            return Number(params.data.tpsWgrossPremFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWgrossPremFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsWiptFc',
        headerName: 'W - IPT',
        headerTooltip: 'W - IPT',
        width: 100,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWiptFc) {
            return Number(params.data.tpsWiptFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWiptFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsWstampDutyFc',
        headerName: 'W - Stamp Duty',
        headerTooltip: 'W - Stamp Duty',
        width: 100,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWstampDutyFc) {
            return Number(params.data.tpsWstampDutyFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWstampDutyFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsWbrkCommFc',
        headerName: 'W - Commission',
        headerTooltip: 'W - Commission',
        width: 100,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsWbrkCommFc) {
            return Number(params.data.tpsWbrkCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsWbrkCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsGrossPremFc',
        headerName: 'B - Premium',
        headerTooltip: 'B - Premium',
        width: 100,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsGrossPremFc) {
            return Number(params.data.tpsGrossPremFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsGrossPremFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },

      },
      {
        width: 100,
        field: 'tpsIptFc',
        headerName: 'B - IPT',
        headerTooltip: 'B - IPT',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsIptFc) {
            return Number(params.data.tpsIptFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsIptFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 100,
        field: 'tpsStampDutyFc',
        headerName: 'B - Stamp Duty',
        headerTooltip: 'B - Stamp Duty',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsStampDutyFc) {
            return Number(params.data.tpsStampDutyFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsStampDutyFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 100,
        field: 'tpsBrkCommFc',
        cellStyle: { textAlign: 'right' },
        headerName: 'B - Commission',
        headerTooltip: 'B - Commission',
        valueGetter: function (params) {
          if (params.data && params.data.tpsBrkCommFc) {
            return Number(params.data.tpsBrkCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsBrkCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        width: 110,
        field: 'tpcMgaCommFc',
        headerName: 'MGA Commission',
        headerTooltip: 'MGA Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpcMgaCommFc) {
            return Number(params.data.tpcMgaCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpcMgaCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpcAdvCommFc',
        headerName: 'Adv. MGA Commission',
        headerTooltip: 'Adv. MGA Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpcAdvCommFc) {
            return Number(params.data.tpcAdvCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpcAdvCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
        width: 110,
      },
      {
        field: 'tpcBrkAdminFeesFc',
        headerName: 'Broker Admin Fee',
        headerTooltip: 'Broker Admin Fee',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpcBrkAdminFeesFc) {
            return Number(params.data.tpcBrkAdminFeesFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpcBrkAdminFeesFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsAddCcontFeeFc',
        headerName: 'Additional coins contract fee',
        headerTooltip: 'Additional coins contract fee',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsAddCcontFeeFc) {
            return Number(params.data.tpsAddCcontFeeFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsAddCcontFeeFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpcFCommFc',
        headerName: 'Fixed Commission',
        headerTooltip: 'Fixed Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpcFCommFc) {
            return Number(params.data.tpcFCommFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpcFCommFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsPbrkFeeFc',
        headerName: 'Placing Broker Fee',
        headerTooltip: 'Placing Broker Fee',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsPbrkFeeFc) {
            return Number(params.data.tpsPbrkFeeFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsPbrkFeeFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsAbrkFeeFc',
        headerName: 'Accounting Broker Fee',
        headerTooltip: 'Accounting Broker Fee',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsAbrkFeeFc) {
            return Number(params.data.tpsAbrkFeeFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params.data && params.data.tpsAbrkFeeFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        field: 'tpsIcommFeeFc',
        headerName: 'Introducer Commission',
        headerTooltip: 'Introducer Commission',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tpsIcommFeeFc) {
            return params.data.tpsIcommFeeFc;
          } else {
            return "0.00";
          }
        },
      },
    ];

  }

  getCoinsurerDetails() {
    this.loaderService.isBusy = true;
    this.prmBorderxService.getPremiumCoInsDetails(this.selectedCoinsurance).subscribe(res => {
      this.coinsuranceList = res;
      this.loaderService.isBusy = false;
      this.pinnedBottomRowData = createData(1, this.coinsuranceList, "Bottom");
      this.showCoinsuranceDetail = true;
    }, error => {
      this.toastService.error('Error in loading coinsurance details!');
      this.loaderService.isBusy = false;
    });

  }

  displayedCoInsRowCount() {
    if (this.coinsuranceGridApi) {
      return this.coinsuranceGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onCoInsBtExport() {
    if (this.coinsuranceGridApi) {
      this.coinsuranceGridApi.exportDataAsExcel({
        fileName: 'Premium_Summary_Coinsurance.xlsx',
        skipHeader: false,
        sheetName: 'Premium Summary Coinsurance',
        processCellCallback: (params) => {
          if (params.column.colId == "tpsWgrossPremFc" || params.column.colId == "tpsWiptFc" || params.column.colId == "tpsWstampDutyFc" || params.column.colId == "tpsWbrkCommFc" || params.column.colId == "tpsGrossPremFc"
            || params.column.colId == "tpsIptFc" || params.column.colId == "tpsStampDutyFc" || params.column.colId == "tpsBrkCommFc" || params.column.colId == "tpcMgaCommFc" || params.column.colId == "tpcAdvCommFc"
            || params.column.colId == "tpcBrkAdminFeesFc" || params.column.colId == "tpsAddCcontFeeFc" || params.column.colId == "tpcFCommFc" || params.column.colId == "tpsPbrkFeeFc" || params.column.colId == "tpsAbrkFeeFc") {
            if (params.value) {
              return parseFloat((params.value).replace(/,/g, ''));
            } else {
              return "";
            }
          } else {
            return params.value;
          }
        },
      });
    }
  }

  pageCoInsChanged(event: any): void {
    this.coinsuranceGridApi.paginationGoToPage(event.page - 1);
  }

  onCoInsPaginationCountChange(event: any) {
    this.coinsuranceGridApi.paginationSetPageSize(this.showCoInsEntriesOptionSelected);
    this.coinsuranceGridApi.paginationGoToPage(0);
  }

  onQuickFilterCoinsuranceChanged() {
    this.coinsuranceGridApi.setQuickFilter(this.quickCoinsuranceSearchValue);
  }

  onCoInsuranceGridSizeChanged(params) {
    var gridWidth = document.getElementById('coinsuranceGrid').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  coInsGridColumnApi: any;
  onCoInsuranceGridReady(params) {
    this.coinsuranceGridApi = params.api;
    this.coInsGridColumnApi = params.columnApi;
  }

  onCoInsRowClicked(evt) {
  }

  openUploadPopup() {
    this.isreUpload = true;
    if (this.id) {
      clearInterval(this.id);
    }
    this.enableProgressBar = false;
    this.batchUploadForm.reset();
    this.fileList = [];
    this.batchUploadForm.patchValue({
      binderRefId: (this.uploadNewData.refId) ? this.uploadNewData.refId : "",
      batchId: (this.uploadNewData.batchInfoDTO.tbiBatId) ? this.uploadNewData.batchInfoDTO.tbiBatId : ""
    });
    this.open(this.batchUploadModal1, 1, 'modal-md')
  }
  validateCheckSum() {
    this.isValidateCheckSum = true;
    if (this.id) {
      clearInterval(this.id);
    }
    this.enableProgressBar = false;
    this.batchUploadForm.reset();
    this.fileList = [];
    this.batchUploadForm.patchValue({
      // binderRefId: (this.uploadNewData.refId) ? this.uploadNewData.refId : "",
      batchId: (this.batchId) ? this.batchId : ""
    });
    this.open(this.validateCheckSumModal2, 2, 'modal-md');
  }
  batchUploadForm: UntypedFormGroup;
  createBatchUploadForm() {
    this.batchUploadForm = this.fb.group({
      binderRefId: '',
      bindRefNo: "",
      bindSeqNo: "",
      bindAmendNo: "",
      binderMgaCode: "",
      batchId: ""
    });
  }

  removeFile(index) {
    this.fileList.splice(index, 1);
  }
  cancelUpload() {
    if (this.id) {
      clearInterval(this.id);
    }
    this.closeModal(1);
    this.closeModal(2);
  }
  formatFileSize(bytes, decimalPoint) {
    if (bytes == 0) return '0 KB';
    var k = 1000,
      dm = decimalPoint || 2,
      sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  uploadBatchFile(type) {
    if (this.batchId == null) {
      this.getFileListDoc();
    }
    if (this.batchUploadForm.valid) {
      this.loaderService.isBusy = true;
      // this.docMetadata = undefined;
      let data = this.batchUploadForm.getRawValue();
      var formData = new FormData();
      this.batchId = data.batchId;
      this.isreUpload == true ? this.batchId : '';
      let refId = data.binderRefId;
      if (this.fileList.length > 1) {
        this.toastService.warning("You can only upload a maximum of 1 file!");
        this.loaderService.isBusy = false;
      } else if (this.fileList.length == 1) {
        formData.append("ufile", this.fileList[0]);
        if (this.isreUpload || this.isValidateCheckSum) {
          formData.append("batchId", this.batchId);
        }
        if (this.isValidateCheckSum && type == 'checksum') {
          this.id = setInterval(() => {
            this.getProgressInfo();
            this.enableProgressBar = true;
          }, 1500);
          this.prmBorderxService.validateChecksum(formData).subscribe((resp: any) => {
            this.validateCheckSumData = resp;
            this.loaderService.isBusy = false;
            this.batchId = this.validateCheckSumData.tbiBatId;
            this.errorCheckSum = Number(this.validateCheckSumData.tbiFlex07);
            if (this.errorCheckSum == 0) {
              this.checksumDisable = false;
            } else {
              this.checksumDisable = true;
            }
            document.getElementById("closeUpload1").click();
            this.cleanUploadForm();
          }, error => {
            if (this.id) {
              clearInterval(this.id);
            }
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    if (error.error.btnAction == 'Y') {
                      this.checksumDisable = false;
                    } else {
                      this.checksumDisable = true;
                    }
                    document.getElementById("closeUpload1").click();
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          });
        } else {
          this.id = setInterval(() => {
            this.getProgressInfo();
            this.enableProgressBar = true;
          }, 1500);
          this.validateCheckSumData = {};
          this.prmBorderxService.readAndUploadDoc(formData).subscribe(resp => {
            this.loaderService.isBusy = false;
            let batchId = resp.batchInfoDTO.tbiBatId;
            if (resp["messageType"] && resp["messageType"] == 'E') {
              this.toastService.error(resp["message"]);
            }
            document.getElementById("closeUpload").click();
            this.cleanUploadForm();
            this.router.navigate(["premium-bordereaux-upload"], { queryParams: { 'action': 'UPLOADNEW', 'isView': false, 'batchId': batchId }, skipLocationChange: true }).then(() => {
              this.prmBorderxService.setUploadNewClk(resp);
              this.docMetadata = resp.entityRefId;
            });

          }, error => {
            if (this.id) {
              clearInterval(this.id);
            }
            document.getElementById("closeUpload").click();
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    // this.toastService.error(error.error.message);
                    this.showErrorDialogBox(error.error.message);
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          });
        }
      } else {
        this.toastService.warning("Please select file!");
        this.loaderService.isBusy = false;
      }
    } else {
      Utils.validateAllFormFields(this.batchUploadForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;

    }

  }

  cleanUploadForm() {
    this.batchUploadForm.reset();
    this.fileList = [];
  }

  public uploader: FileUploader = new FileUploader({
    url: "",
    autoUpload: false,
    method: '',
    disableMultipart: false,
    // authTokenHeader: 'Authorization',
    //authToken: 'Bearer ' + JSON.parse(this.session.get('authToken')),
    itemAlias: 'document',
    removeAfterUpload: false,
  });

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public onAfterAddingFile = (file) => {
  }

  public onFileSelected(event: File[]) {
    if (this.fileList.length > 0) {
      this.toastService.warning("You can only upload a maximum of 1 file!");
      return false;
    } else {
      for (let index = 0; index < event.length; index++) {
        event[index]['filesize'] = this.formatFileSize(event[index]['size'], 2);
        this.fileList.push(event[index]);
      }
    }
  }
  onExcelBtnExport() {
    if (this.uploadNewData.docMetadata.gridFSId != null) {
      this.exportExcel(this.uploadNewData.docMetadata.gridFSId);
    }
  }
  exportExcel(gridFSId) {
    this.prmBorderxService.exportExcel(gridFSId).subscribe((result: any) => {
    }, error => {
    });
  }
  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }
  missingDocType: boolean = false
  checkDocType() {
    let docType = this.uploadDoc.unsavedFiles
    for (var i = 0; i < docType.length; i++) {
      if (docType[i].entityRefType == undefined) {
        return this.missingDocType = true;

      }
    }
  }
  openApproveModal() {
    this.missingDocType = false
    this.checkDocType();
    this.open(this.apprConfirmModal5, 5, 'modal-md');
    if (this.uploadDoc.unsavedFiles.length >= 0 && this.missingDocType == false) {
      if (this.uploadDoc.fileList.length !== 0) {
        this.uploadDoc.saveAllDocument();
      }
      // document.getElementById("triggerApprove").click();
      // this.approve();
    } else if (this.uploadDoc.unsavedFiles.length == 0) {
      // document.getElementById("triggerApprove").click();
      // this.approve();
    } else {
      this.toastService.warning('Save All Uploaded Documents');
    }

  }
  currencyDecimalFormatter(data) {

    if (data.value != null && data.value != undefined) {
      if (data.value == "Total") {
        return ' ';
      }
      return data.value.toFixed(2);
    } else {
      return '0.00';
    }
  }
  getProgressInfo() {
    let passData;
    if (this.batchId && this.batchId !== undefined) {
      passData = this.batchId;
    } else {
      passData = this.session.get('userId') + '' + this.session.get('companyCode') + '' + this.session.get('userDeptCode');
    }
    let progressData;
    this.prmBorderxService.uploadProgress(passData).subscribe((res: any) => {
      progressData = res.mProcessInfoArray;
      let posting = progressData.filter(function (ele) {
        if (ele) {
          if (ele.mpiProcessName == "Premium Summary BDX Upload") {
            return ele;
          }
        }
      })
      if (posting.length != 0) {
        this.postpercentage = posting[0].mpiProgressPcnt > 100 ? 100 : posting[0].mpiProgressPcnt;
      } else {
        this.postpercentage = 0;
      }
    }, err => {
      if (this.id) {
        clearInterval(this.id);
      }
    })
  }
  ngOnDestroy() {
    if (this.id) {
      clearInterval(this.id);
    }
    if (this.batchId == null) {
      this.getFileListDoc();
    }
  }
}

function createData(count, data, prefix) {
  var result = [];
  var tpcSharePerc = 0;
  var tpsWgrossPremFc = 0;
  var tpsWiptFc = 0;
  var tpsWstampDutyFc = 0;
  var tpsWbrkCommFc = 0;
  var tpsGrossPremFc = 0;
  var tpsIptFc = 0;
  var tpsStampDutyFc = 0;
  var tpsBrkCommFc = 0;
  var tpcMgaCommFc = 0;
  var tpcAdvCommFc = 0;
  var tpcBrkAdminFeesFc = 0;
  var tpsAddCcontFeeFc = 0;
  var tpcFCommFc = 0;
  var tpsPbrkFeeFc = 0;
  var tpsAbrkFeeFc = 0;
  var tpsIcommFeeFc = 0;
  for (var i = 0; i < data.length; i++) {
    tpcSharePerc = tpcSharePerc + Number(data[i].tpcSharePerc);
    tpsWgrossPremFc = tpsWgrossPremFc + Number(data[i].tpsWgrossPremFc);
    tpsWiptFc = tpsWiptFc + Number(data[i].tpsWiptFc);
    tpsWstampDutyFc = tpsWstampDutyFc + Number(data[i].tpsWstampDutyFc);
    tpsWbrkCommFc = tpsWbrkCommFc + Number(data[i].tpsWbrkCommFc);
    tpsGrossPremFc = tpsGrossPremFc + Number(data[i].tpsGrossPremFc);
    tpsIptFc = tpsIptFc + Number(data[i].tpsIptFc);
    tpsStampDutyFc = tpsStampDutyFc + Number(data[i].tpsStampDutyFc);
    tpsBrkCommFc = tpsBrkCommFc + Number(data[i].tpsBrkCommFc);
    tpcMgaCommFc = tpcMgaCommFc + Number(data[i].tpcMgaCommFc);
    tpcAdvCommFc = tpcAdvCommFc + Number(data[i].tpcAdvCommFc);
    tpcBrkAdminFeesFc = tpcBrkAdminFeesFc + Number(data[i].tpcBrkAdminFeesFc);
    tpsAddCcontFeeFc = tpsAddCcontFeeFc + Number(data[i].tpsAddCcontFeeFc);
    tpcFCommFc = tpcFCommFc + Number(data[i].tpcFCommFc);
    tpsPbrkFeeFc = tpsPbrkFeeFc + Number(data[i].tpsPbrkFeeFc);
    tpsAbrkFeeFc = tpsAbrkFeeFc + Number(data[i].tpsAbrkFeeFc);
    tpsIcommFeeFc = tpsIcommFeeFc + Number(data[i].tpsIcommFeeFc);
  }

  result.push({
    tpcCustCodeDesc: 'Total',
    tpcExpPerc: 'Total',
    tpcMarginPerc: 'Total',
    tpcSharePerc: tpcSharePerc,
    tpsWgrossPremFc: tpsWgrossPremFc,
    tpsWiptFc: tpsWiptFc,
    tpsWstampDutyFc: tpsWstampDutyFc,
    tpsWbrkCommFc: tpsWbrkCommFc,
    tpsGrossPremFc: tpsGrossPremFc,
    tpsIptFc: tpsIptFc,
    tpsStampDutyFc: tpsStampDutyFc,
    tpsBrkCommFc: tpsBrkCommFc,
    tpcMgaCommFc: tpcMgaCommFc,
    tpcAdvCommFc: tpcAdvCommFc,
    tpcBrkAdminFeesFc: tpcBrkAdminFeesFc,
    tpsAddCcontFeeFc: tpsAddCcontFeeFc,
    tpcFCommFc: tpcFCommFc,
    tpsPbrkFeeFc: tpsPbrkFeeFc,
    tpsAbrkFeeFc: tpsAbrkFeeFc,
    tpsIcommFeeFc: tpsIcommFeeFc,
  });

  return result;
}
function tooltipRenderer(params) {
  return '<span title="' + params.value + '">' + params.value + '</span>';
}
