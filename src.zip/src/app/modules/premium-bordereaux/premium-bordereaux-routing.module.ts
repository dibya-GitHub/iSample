import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PremiumBordereauxDashboardComponent } from './components/premium-bordereaux-dashboard/premium-bordereaux-dashboard.component';
import { PremiumBordereauxUploadComponent } from './components/premium-bordereaux-upload/premium-bordereaux-upload.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'premium-bordereaux',
    pathMatch: 'prefix'
  },
  {
    path: 'premium-bordereaux',
    component: PremiumBordereauxDashboardComponent,
    data: {
      breadcrumb: { skip: true }
    }
  },
  {
    path: 'premium-bordereaux-upload',
    component: PremiumBordereauxUploadComponent,
    data: {
      breadcrumb: 'Premium Bordereaux Upload'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PremiumBordereauxRoutingModule { }
