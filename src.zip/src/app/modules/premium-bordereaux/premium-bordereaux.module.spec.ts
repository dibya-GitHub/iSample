import { PremiumBordereauxModule } from './premium-bordereaux.module';

describe('PremiumBordereauxModule', () => {
  let premiumBordereauxModule: PremiumBordereauxModule;

  beforeEach(() => {
    premiumBordereauxModule = new PremiumBordereauxModule();
  });

  it('should create an instance', () => {
    expect(premiumBordereauxModule).toBeTruthy();
  });
});
