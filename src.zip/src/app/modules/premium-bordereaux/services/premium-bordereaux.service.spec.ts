import { TestBed } from '@angular/core/testing';

import { PremiumBordereauxService } from './premium-bordereaux.service';

describe('PremiumBordereauxService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PremiumBordereauxService = TestBed.get(PremiumBordereauxService);
    expect(service).toBeTruthy();
  });
});
