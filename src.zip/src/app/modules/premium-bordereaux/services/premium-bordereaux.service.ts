import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { Observable, Subject } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PremiumBordereauxService {
  companyCode: any;
  public requestHeaders;
  mgaUrl: any = environment.mgaUrl;
  commonUrl = environment.mgaCommonUrl;
  mgaFinanceUrl = environment.mgaFinanceUrl;
  dmsBaseUrl = environment.dmsBaseUrl;
  uploadNewClk = new Subject<any>();

  constructor(
    private httpService: HttpClient,
    private session: SessionStorageService
  ) {
    this.companyCode = this.session.get('companyCode');
    this.requestHeaders = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })
    // this.requestHeaders = new RequestOptions({ headers: this.requestHeaders })
    { }
  }

  premSummBdxReadAndUploadDoc(file, refNo, seqNo, amendNo): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.BORDERX_PREM_SUMMARY + '/readAndUploadDoc/' + refNo + '/' + seqNo + '/' + amendNo, file);
  }
  getBatchInfo(): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.BORDERX_BATCH_INFO, this.requestHeaders);
  }

  getPremSummBdx(batchId): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.BORDERX_PREM_SUMMARY + '/' + batchId, this.requestHeaders);
  }

  getBinderRefId(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'binderRefId')
  }

  searchPremium(data): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'premSummBdx/batchinfo/filtersearch', data)
  }

  reversePremium(batchId, data): Observable<any> {
    // return this.httpService.put(this.mgaUrl + 'premSummBdx/reverse/' + batchId, data)
    return this.httpService.put(this.mgaUrl + 'premSummBdx/reverse/' + batchId, data)
  }

  //#################### Premium bordereaux Upload services #############################
  //binderRefId, batchId,  ?binderRefId=" + binderRefId + "&batchId=" + batchId
  readAndUploadDoc(formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + "premSummBdx/readAndUploadDoc", formData);
  }
  validateChecksum(formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + "premSummBdx/validateChecksum", formData);
  }

  getMgaCode(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customers/MGA', this.requestHeaders);
  }
  getMGAlist(): Observable<any> {
    return this.httpService.get(this.commonUrl + 'appcodes-mgmt/appcodes/MGA_TYPE', this.requestHeaders);
  }
  getUploadNewClk(): Observable<any> {
    return this.uploadNewClk.asObservable();
  }

  setUploadNewClk(data) {
    this.uploadNewClk.next(data);
  }

  exportExcel(gridFSId): Observable<any> {
    return this.httpService.get(this.dmsBaseUrl + gridFSId + "?companyCode=QIC", this.requestHeaders);
  }

  savePremium(batchId): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'premSummBdx/save/' + batchId, this.requestHeaders);
  }
  approvePremium(batchId): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'premSummBdx/approve/' + batchId, this.requestHeaders);
  }
  closePremium(batchId): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'premSummBdx/close/' + batchId, this.requestHeaders);
  }

  deletePremium(batchId): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'premSummBdx/delete/' + batchId, this.requestHeaders)
  }



  //#################### Premium bordereaux Upload services #############################

  getAccountDetails(docNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'premSummBdx/viewAccount/AccDocId/' + docNo, this.requestHeaders);
  }

  viewAccoutingDetails(batchId, binder,type): Observable<any> {
    return this.httpService.get(this.mgaUrl + type + '/viewAccount/accBatchDocId/' + batchId + '/' + binder, this.requestHeaders);
  }
  fetchPremBoardReportParamList(obj: any): Observable<any> {
    return this.httpService.get<any>(this.mgaUrl + ApiUrls.REPORT_PARAM_MGMT_PATH + "/" + ApiUrls.INSTANCE + "/" + obj.instId + "/" + ApiUrls.REPORT_MAPPING_PATH + "/" + obj.compCode + "?divn=" + obj.divn + "&tranType=" + obj.tranType, this.requestHeaders);
  }

  fetchPremBoardReportUrl(obj: any): Observable<any> {
    return this.httpService.get<any>(this.mgaUrl + ApiUrls.REPORT_PARAM_MGMT_PATH + "/" + ApiUrls.REPORT_URL_MAPPING_PATH + "/" + obj.refNo + "?amendNo=" + obj.amendNo + "&repId=" + obj.repId + "&compCode=" + obj.compCode + "&docType=" + obj.docType + "&seqNo=" + obj.seqNo, this.requestHeaders);
  }
  getDocuments(file): Observable<any> {
    const params: any = {};
    params.responseType = 'arrayBuffer';
    return this.httpService.get(this.dmsBaseUrl + '/api/document/' + file, params);
  }

  sendEmail(data): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'report-param-mgmt/ta/sendEmail', data)
    //report-param-mgmt/ta/sendEmail
  }

  //############## Premium Coinsurance details ####################
  getPremiumCoInsDetails(data): Observable<any> {
    return this.httpService.get(this.mgaUrl + "premSummBdx/viewCoinsuranceAcnt/" + data.tpsBatId + "/" + data.tpsBindRefNo + "/" + data.tpsAcntYear + "/" + data.tpsDivnCode + "/" + data.tpsLobCode + "/" + data.tpsProdCode + "/" + data.tpsSrNo);
  }
  //############## Premium Coinsurance details ####################

  getAccountTypeList(data): Observable<any> {
    return this.httpService.get(this.commonUrl + "appcodes-mgmt/viewacc/ACC_DOC_TYPE/" + data);
  }
  progress(data): Observable<any> {
    return this.httpService.get(this.mgaUrl + "progress/" + data + '/P');
  }
  uploadProgress(batchId): Observable<any> {
    return this.httpService.get(this.mgaUrl + "progress/" + batchId + '/P');
  }
  uploadHistory(batchId, status): Observable<any> {
    return this.httpService.get(this.mgaUrl + "premclmSummBdx/uploadhistory/" + batchId + '/' + status);
  }
  checkSumUploadHistory(batchId): Observable<any> {
    return this.httpService.get(this.mgaUrl + "checksum/uploadhistory/" + batchId );
  }
}
