import { AuthInterceptor } from 'src/app/services/auth-interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { CommonAppModule } from "src/app/shared/common-app.module";
import { CustomerCategoryFormComponent } from "./components/customer-category-form/customer-category-form.component";
import { CustomerCategoryComponent } from "./components/customer-category/customer-category.component";
import { CustomerGroupFormComponent } from './components/customer-group-form/customer-group-form.component';
import { CustomerComponent } from "./components/customer/customer.component";
import { CustomergroupComponent } from "./components/customergroup/customergroup.component";
import { CustomerRoutingModule } from "./customer-routing.module";
<<<<<<< HEAD
import { CustomerService } from "./services/customer.service";
import { DropdownModule } from 'primeng/dropdown';
=======
import { CommonAppModule } from "src/app/shared/common-app.module";
import { DropdownModule } from 'primeng/dropdown';
import { CustomerCategoryDemoComponent } from './components/customer-category-demo/customer-category-demo.component';
import { InputNumberModule } from 'primeng/inputnumber';
// import { MAppCodesComponent } from "./components/m-app-codes/m-app-codes.component";
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@NgModule({
  imports: [
    CommonModule,
    CommonAppModule,
    CustomerRoutingModule,
<<<<<<< HEAD
    DropdownModule
=======
    DropdownModule,
    InputNumberModule
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ],
  declarations: [
    CustomergroupComponent,
    CustomerGroupFormComponent,
    CustomerCategoryComponent,
    CustomerCategoryFormComponent,
    CustomerComponent,
    CustomerCategoryDemoComponent,
    // MAppCodesComponent
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ]
})
export class CustomerModule { }
