import { HttpClient } from "@angular/common/http";
<<<<<<< HEAD
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ApiUrls } from "src/app/api-urls";
import { AuthService } from 'src/app/services/auth.service';
=======
import { Inject, Injectable } from "@angular/core";
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from "rxjs";
import { ApiUrls } from "src/app/api-urls";
import { AuthService } from "src/app/services/auth.service";
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  requestOption: any;
  customerUrl: any = environment.financeUrl;
  commonUrl: any = environment.commonBaseUrl;
  instanceId: any;
  // customer-mgmt
  constructor(
    private httpService: HttpClient,
<<<<<<< HEAD
    private authService: AuthService
  ) { }

  retrieveCustCategory(): Observable<any> {
    return this.httpService.get<any>(this.customerUrl + "/customer-category-mgmt/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.CUSTOMER_PATH + "/CUST_CATG", this.requestOption);
=======
    private session: SessionStorageService,
    private authService: AuthService
  ) {
    this.instanceId = this.authService.getInstanceCode();
  }

  retrieveCustCategory(): Observable<any> {
    return this.httpService.get<any>(this.commonUrl + ApiUrls.CUSTOMER_PATH + "/CUST_CATG", this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  retrieveCodeMapping(path: string, CM_Code: any): Observable<any> {
    return this.httpService.get<any>(this.customerUrl + path + "/" + ApiUrls.CUSTOMER_PATH + "/" + ApiUrls.CODE_MAP_PATH + "/" + CM_Code, this.requestOption);
  }

  retrieveCategoryById(path: string, type: any, value: any): Observable<any> {
<<<<<<< HEAD
    return this.httpService.get<any>(this.customerUrl + path + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.CUSTOMER_PATH + '/' + type + "/" + value, this.requestOption);
  }

  saveCategoryDetails(path: string, body: any): Observable<any> {
    return this.httpService.post<any>(this.customerUrl + path + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.CUSTOMER_PATH, body);
  }

  updateCategoryDetails(path: string, custID: any, body: any): Observable<any> {
    return this.httpService.put<any>(this.customerUrl + path + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.CUSTOMER_PATH + "/" + custID, body);
=======
    return this.httpService.get<any>(this.customerUrl + path + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.CUSTOMER_PATH + '/' + type + "/" + value, this.requestOption);
  }

  saveCategoryDetails(body: any): Observable<any> {
    return this.httpService.post<any>(this.commonUrl + ApiUrls.INSTANCE + "/" + this.instanceId + "/appcodes/" + ApiUrls.CUSTOMER_PATH + "/save", body);
  }

  updateCategoryDetails(body: any): Observable<any> {
    return this.httpService.put<any>(this.commonUrl + ApiUrls.INSTANCE + "/" + this.instanceId + "/appcodes/" + ApiUrls.CUSTOMER_PATH + "/update", body);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  custCatgTypeList(): Observable<any> {
    return this.httpService.get(this.commonUrl + ApiUrls.CUSTOMER_PATH + "/type", this.requestOption);

  }
}
