import { CustomerCategoryDemoComponent } from './components/customer-category-demo/customer-category-demo.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CustomerCategoryFormComponent } from "./components/customer-category-form/customer-category-form.component";
import { CustomerCategoryComponent } from "./components/customer-category/customer-category.component";
import { CustomerGroupFormComponent } from './components/customer-group-form/customer-group-form.component';
import { CustomerComponent } from "./components/customer/customer.component";
import { CustomergroupComponent } from "./components/customergroup/customergroup.component";

<<<<<<< HEAD
const routes: Routes = [{
  path: 'customerCat',
  component: CustomerCategoryComponent,
  data: {
    breadcrumb: 'Customer Category'
  },
},
{
  path: 'customerCat/add',
  component: CustomerCategoryFormComponent,
  data: {
    breadcrumb: 'Customer Category-Add'
  },
},
{
  path: 'customerCat/edit',
  component: CustomerCategoryFormComponent,
  data: {
    breadcrumb: 'Customer Category-Edit'
  },
},
{
  path: 'customerGroup',
  component: CustomergroupComponent,
  data: {
    breadcrumb: 'Customer Group'
  },
},
{
  path: 'customerGroup/add',
  component: CustomerGroupFormComponent,
  data: {
    breadcrumb: 'Customer Group-Add'
  },
},
{
  path: 'customerGroup/edit',
  component: CustomerGroupFormComponent,
  data: {
    breadcrumb: 'Customer Group-Edit'
  },
},
{
  path: 'customer',
  component: CustomerComponent,
  data: {
    breadcrumb: 'Customer'
  },
},
=======
const routes: Routes = [
  {
    path: 'customerCat',
    component: CustomerCategoryDemoComponent,
    data: {
      breadcrumb: 'Customer Category'
    }
  },
  //   {
  //   path: 'customerCat',
  //   component: CustomerCategoryComponent
  // },
  // {
  //   path: 'customerCat/add',
  //   component: CustomerCategoryFormComponent
  // },
  // {
  //   path: 'customerCat/edit',
  //   component: CustomerCategoryFormComponent
  // },
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  // {
  //   path: 'customerGroup',
  //   component: CustomergroupComponent
  // },
  // {
  //   path: 'customerGroup/add',
  //   component: CustomerGroupFormComponent
  // },
  // {
  //   path: 'customerGroup/edit',
  //   component: CustomerGroupFormComponent
  // },
  // {
  //   path: 'customer',
  //   component: CustomerComponent
  // },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule { }
