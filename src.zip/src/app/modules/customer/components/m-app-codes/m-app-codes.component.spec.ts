// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MAppCodesComponent } from './m-app-codes.component';

// describe('MAppCodesComponent', () => {
//   let component: MAppCodesComponent;
//   let fixture: ComponentFixture<MAppCodesComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ MAppCodesComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MAppCodesComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
