// import { Component, OnInit, Inject } from '@angular/core';
// import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl, UntypedFormArray } from '@angular/forms';
// import { Router } from '@angular/router';
// import { MessageService } from 'primeng/api';
// import { SessionStorageService } from 'angular-web-storage';
// import { GlobalService } from 'src/app/shared/services/global.service';
// import { CustomerService } from 'src/app/shared/services/customer.service';
// import { DatePipe } from '@angular/common';
// import { ApiUrls } from 'src/app/api-urls';
// import * as moment from 'moment';
// declare var $: any;

// @Component({
//   selector: 'app-m-app-codes',
//   templateUrl: './m-app-codes.component.html',
//   styleUrls: ['./m-app-codes.component.css'],
//   providers: [MessageService,DatePipe]
// })
// export class MAppCodesComponent implements OnInit {
  
//   buttonName: string;
//   stateName: any;
//   countryName: any;
//   nameDesc: any;
//   dateFlag: boolean;
//   custGroupFlag: boolean;
//   breadcrumbFlag: boolean;
//   editTypeFlag: boolean;
//   typeFlag: boolean;
//   custGrpList: any;
//   path: any;
//   acId: any;
//   acType: any;
//   action: any;
//   type: any;
//   editFlag: boolean;
//   appCodeForm: UntypedFormGroup;
//   appCodeType=[];
//   country:any;
//   state:any;
//   zone:any;

//   constructor(private fb: UntypedFormBuilder,
//     private globalService: GlobalService,
//     private customerService: CustomerService,
//     private route: Router,
//     private toastService: MessageService,
<<<<<<< HEAD
=======
//     private spinnerService: Ng4LoadingSpinnerService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
//     private session: SessionStorageService,
//     private datePipe: DatePipe) { }

//   ngOnInit() {
//     this.path = this.customerService.getParamValue('path');
//     this.acId = this.customerService.getParamValue('code');

//     this.acType = this.customerService.getParamValue('code1');
//     this.action = this.customerService.getParamValue('action');
//     this.type = this.globalService.getParamValue('type');
//     this.country = this.customerService.getParamValue('country');
//     this.state = this.customerService.getParamValue('state');
//     this.zone = this.customerService.getParamValue('location');
//     this.countryName = this.customerService.getParamValue('country name');
//     this.stateName = this.customerService.getParamValue('state name');
    
    
    

// console.log("Type is ",this.type);


//     if(this.type == "COUNTRY" || this.type == "STATE" || this.type == "LOCATION" || this.type == "NATIONALITY"){
//       this.editFlag=false;
//       this.dateFlag = false;
//       this.breadcrumbFlag = true;

//     } else if(this.type =="CUST_GROUP"){
//       this.editFlag=false;
//       this.dateFlag = true;
      
//     }

//     if ('edit' == this.action) {
//       this.buttonName ="Update";
//       if(this.type == "COUNTRY" || this.type == "STATE" || this.type == "LOCATION" ||this.type == "NATIONALITY"){
//         this.editFlag=false;
//         this.dateFlag = false;
//       } else if(this.type =="CUST_GROUP"){
//         this.editFlag=false;
//         this.dateFlag = true;
        
//       }
//       this.edit();
//     }
//     else{
//       this.buttonName ="Save";
//     }
//     this.ngAfterViewInit();
//     this.appCodeType=[
//       {key:'COUNTRY',value:'COUNTRY'},
//       {key:'STATE',value:'STATE'},
//       {key:'LOCATION',value:'LOCATION'},
//       {key:'NATIONALITY',value:'NATIONALITY'}
      
//     ]

//     this.createAppCodeForm();
//   }
//   createAppCodeForm() {
//     this.appCodeForm = this.fb.group({
//       acId:'',
//       acInstId:this.authService.getInstanceCode(),
//       acCode: ['',Validators.required],
//       acType: '',
//       acValue: '',
//       acMcCode: '',
//       acMastDefCode: '',
//       acDesc: ['',Validators.required],
//       acDescBl: '',
//       acShortDesc: '',
//       acShortDescBl: '',
//       acLongDesc: '',
//       acLongDescBl: '',
//       acCodeByLobYn: '1',
//       acLobCode: '',
//       acApplCompCode: '',
//       acEffFmDt: '',
//       acEffToDt: '',
//       acCrUid: this.session.get('userId'),
//       acCrDt: new Date(),
//       acUpdUid: '',
//       acUpdDt: ''
//     });
//   }


//   save() {
 
//     if (this.appCodeForm.valid) {
//       this.spinnerService.show();

      
//       if(this.action=='edit'){
       
//         if("CUST_GROUP"!=this.type){
//         this.appCodeForm.patchValue({
//           acType: this.appCodeForm.get('acCodeByLobYn').value==true?'1':'0',
//         })
//       }
//         this.appCodeForm.patchValue({
//           acType: this.type
//         })
//         if("CUST_GROUP"!=this.type){
//           this.globalService.updateAppCodes(this.path,this.appCodeForm.value,this.appCodeForm.get("acId").value).subscribe(result => {
//             this.spinnerService.hide();
//             this.toastService.add({ severity: 'success', summary: "Saved Successfully.", detail: '' });
//             this.back();
  
//           }, error => {
  
//             this.spinnerService.hide();
//             this.toastService.add({ severity: 'error', summary: "Error in Saving Data", detail: '' });
//           });
//         }else{
//          this.appCodeForm.patchValue({
//           acEffFmDt: moment(this.appCodeForm.get("acEffFmDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD') ,
//           acEffToDt: moment(this.appCodeForm.get("acEffToDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD')
//          })         
//         this.customerService.updateCategoryDetails(this.path,this.appCodeForm.get("acId").value,this.appCodeForm.value).subscribe(result => {
//         this.spinnerService.hide();
//           this.toastService.add({ severity: 'success', summary: "Saved Successfully.", detail: '' });
//           this.back();
//         }, error => {
//           this.spinnerService.hide();
//           this.toastService.add({ severity: 'error', summary: "Error in Saving Data", detail: '' });
//         });
//       }
//       }else{
//         if(this.type == "STATE"){
//           console.log("patch state code",this.state);
//           this.appCodeForm.patchValue({
//             acMcCode: this.country
//           })
//         }else if(this.type == "LOCATION"){
//           console.log("patch zone code",this.zone);
//           this.appCodeForm.patchValue({
//             acMcCode: this.state
//           })
//         }

//         if(this.appCodeForm.get('acCodeByLobYn').value==""){          
//           this.appCodeForm.patchValue({
//             acCodeByLobYn: '0'
//           })
//         }

//           this.appCodeForm.patchValue({
//             acType: this.type
//           })
//           if("CUST_GROUP"!=this.type){
//             this.globalService.insertAppCodes(this.path,this.appCodeForm.value).subscribe(result => {
//               this.spinnerService.hide();
//               this.toastService.add({ severity: 'success', summary: "Saved Successfully.", detail: '' });
//               this.back();
    
//             }, error => {
//                  console.log(error);
//               this.spinnerService.hide();
//               this.toastService.add({ severity: 'error', summary: error.error.message, detail: '' });
//             });
//           }
//           else{
//             this.appCodeForm.patchValue({
//               acEffFmDt: moment(this.appCodeForm.get("acEffFmDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD') ,
//               acEffToDt: moment(this.appCodeForm.get("acEffToDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD')
//              }) 
//             this.customerService.saveCategoryDetails(this.path,this.appCodeForm.value).subscribe(result => {
//               this.spinnerService.hide();
//               this.toastService.add({ severity: 'success', summary: "Saved Successfully.", detail: '' });
//               this.back();
    
//             }, error => {
    
//               this.spinnerService.hide();
//               this.toastService.add({ severity: 'error', summary: "Error in Saving Data", detail: '' });
//             });
//         }
       

//       }
    
//     } else {
//       this.validateAllFormFields(this.appCodeForm);
      
//     }
//   }


//   edit() {
//     this.spinnerService.show();
//     // this.editFlag = true;
//    // let obj = {'acId':this.acId};
//    if("CUST_GROUP"!=this.type){
//    this.globalService.retrieveAppCodesById(this.path, this.acId).subscribe(result => {
//     this.appCodeForm.patchValue({
//       acId:result.acId,
//       acInstId:this.authService.getInstanceCode(),
//       acCode: result.acCode,
//       acType: result.acType,
//       acValue: result.acValue,
//       acMcCode: result.acMcCode,
//       acMastDefCode: result.acMastDefCode,
//       acDesc: result.acDesc,
//       acDescBl: result.acDescBl,
//       acShortDesc: result.acShortDesc,
//       acShortDescBl: result.acShortDescBl,
//       acLongDesc: result.acLongDesc,
//       acLongDescBl: result.acLongDescBl,
//      acCodeByLobYn: result.acCodeByLobYn,
//       acLobCode: result.acLobCode,
//       acApplCompCode: result.acApplCompCode,
//       acEffFmDt:this.datePipe.transform(result.acEffFmDt, ApiUrls.DATE_FORMAT),
//       acEffToDt:this.datePipe.transform(result.acEffToDt, ApiUrls.DATE_FORMAT),
//       acCrUid: result.acCrUid,
//       acCrDt: result.acCrDt,
//       acUpdUid:this.session.get('userId'),
//       acUpdDt: new Date()
//     });
//     this.spinnerService.hide();
//   } , error => {
//     this.spinnerService.hide();
//   });
// }else{
//     this.customerService.retrieveCategoryById(this.path,'CUST_GROUP', this.acId).subscribe(result => {
//       this.custGrpList=result[0];
//       this.appCodeForm.patchValue({
//         acId:this.custGrpList.acId,
//         acInstId:this.authService.getInstanceCode(),
//         acCode: this.custGrpList.acCode,
//         acType: result.acType,
//         acDesc: this.custGrpList.acDesc,
//         acEffFmDt:this.datePipe.transform(this.custGrpList.acEffFmDt, ApiUrls.DATE_FORMAT),
//         acEffToDt:this.datePipe.transform(this.custGrpList.acEffToDt, ApiUrls.DATE_FORMAT),
//         acCrUid: this.custGrpList.acCrUid,
//         acCrDt: this.custGrpList.acCrDt,
//       });
//       this.spinnerService.hide();
//     }, error => {
//       this.spinnerService.hide();
//       this.toastService.add({ severity: 'error', summary: error.error.message, detail: '' });
//     });
//   }
// }
//   back() {
//     if("CUST_GROUP"==this.type){
//       this.route.navigate(['/master'], { queryParams: { "flag": true, "title": "Customer Group", "path": this.path, "type":this.type,  } , skipLocationChange : false });      
//     }else{
//       this.route.navigate(['/master/app-codes'], { queryParams: { "flag": true, "title": "App Code", "path": this.path, "type":this.type ,'country':this.country,'state':this.state,'location':this.zone,'country name':this.countryName,'state name':this.stateName } , skipLocationChange : false });
      
//     }
   
//   }

<<<<<<< HEAD
//   validateAllFormFields(formGroup: FormGroup) {
//     Object.keys(formGroup['controls']).forEach(field => {
=======
//   validateAllFormFields(formGroup: UntypedFormGroup) {
//     Object.keys(formGroup.controls).forEach(field => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
//       const control = formGroup.get(field);
//       console.log(field + ":" + control.status);
//       if (control instanceof UntypedFormControl) {
//         console.log(formGroup.get(field));
//         control.markAsTouched({ onlySelf: true });
//       } else if (control instanceof UntypedFormArray) {
//         control.markAsTouched({ onlySelf: true });
//       } else if (control instanceof UntypedFormGroup) {
//         this.validateAllFormFields(control);
//       }
//     });
//   }
//   ngAfterViewInit() {
    
//     $('.selectpicker').selectpicker();
//     setTimeout(() => {
//     $('.selectpicker').selectpicker('refresh');
//     }, 500);
//     }
// }