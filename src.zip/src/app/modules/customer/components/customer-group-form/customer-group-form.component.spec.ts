import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerGroupFormComponent } from './customer-group-form.component';

describe('CustomerGroupFormComponent', () => {
  let component: CustomerGroupFormComponent;
  let fixture: ComponentFixture<CustomerGroupFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerGroupFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerGroupFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
