import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { CustomerService } from '../../services/customer.service';
declare var $: any;

@Component({
  selector: 'app-customer-group-form',
  templateUrl: './customer-group-form.component.html',
  styleUrls: ['./customer-group-form.component.css'],
  providers: [DatePipe]
})
export class CustomerGroupFormComponent {

  custCatgType: any;
  button: string;
  custID: any;
  userId: any;
  date: Date;
  errormsg: any;
  type: any;
  path: any;
  header: any;
  editFlag: boolean;
  action: string;
  custGroupForm: UntypedFormGroup;
  isEdit: boolean;

  constructor(
    private session: SessionStorageService,
    private toastService: ToastService,
    private fb: UntypedFormBuilder,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private loaderService: LoaderService,
    private customerservice: CustomerService,
    private datePipe: DatePipe
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (params && params.code) {
        this.isEdit = true;
        this.editInfo();
      }
      this.userId = this.session.get('userId');
    });
    console.log("Customer Category", this.path, this.header, this.custID);
    this.custCategory();
    this.loadCatgTypeList();

    if ('edit' == this.action) {
      this.editInfo();
      this.button = "Update";
    } else {
      this.button = "Save";
    }
    this.userId = this.session.get("userId");
  }
  custCategory() {
    this.custGroupForm = this.fb.group({
      acCode: ['', Validators.required],
      acDesc: ['', Validators.required],
      acValue: [undefined, Validators.required],
      acEffFmDt: '',
      acEffToDt: '',
      acCrDt: new Date(),
      acCrUid: this.session.get("userId"),
      acCodeByLobYn: '0',
      acType: 'CUST_CATG'
    })
  }

  editInfo() {
    this.editFlag = true;
    this.loaderService.isBusy = true;
    this.customerservice.retrieveCategoryById(this.path, 'CUST_CATG', this.custID).subscribe(result => {
      console.log("Edit List", result);
      this.custGroupForm.patchValue({
        acCode: result[0].acCode,
        acDesc: result[0].acDesc,
        acValue: result[0].acValue,
        acEffFmDt: this.datePipe.transform(result[0].acEffFmDt, ApiUrls.DATE_FORMAT),
        acEffToDt: this.datePipe.transform(result[0].acEffToDt, ApiUrls.DATE_FORMAT),
        acCrDt: result[0].acCrDt,
        acCrUid: result[0].acCrUid,
        acCodeByLobYn: result[0].acCodeByLobYn == null ? '0' : result[0].acCodeByLobYn,
        acType: result[0].acType,
      })
      this.custID = result[0].acId;
      this.loaderService.isBusy = true;
    }, error => {
      this.loaderService.isBusy = true;
    });
  }
  save() {
    if (this.custGroupForm.valid) {
      this.loaderService.isBusy = true;
      this.custGroupForm.patchValue({
        acEffFmDt: moment(this.custGroupForm.get("acEffFmDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD'),
        acEffToDt: moment(this.custGroupForm.get("acEffToDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD')
      })
      if (this.action == 'edit') {
        // this.customerservice.updateCategoryDetails(this.path, this.custID, this.custGroupForm.value).subscribe(result => {
        //   this.loaderService.isBusy = true;
        //   this.toastService.success("Saved Successfully.");
        //   this.back();
        // }, error => {
        //   this.loaderService.isBusy = true;
        //   this.toastService.error(error.error.message);
        // });
      }
      else {
        // this.customerservice.saveCategoryDetails(this.path, this.custGroupForm.value).subscribe(result => {
        //   this.loaderService.isBusy = true;
        //   this.toastService.success("Saved Successfully.");
        //   this.back();
        // }, error => {
        //   this.loaderService.isBusy = true;
        //   this.errormsg = error.error.message;
        //   console.log("error due to ", this.errormsg);
        //   this.toastService.error(error.error.message);
        // });
      }
    } else {
      this.validateAllFormFields(this.custGroupForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  back() {
    this.router.navigate(['/customers-setup/customerCat'], { queryParams: { 'flag': true, 'title': 'Customer Category' } });
  }

  loadCatgTypeList() {
    this.customerservice.custCatgTypeList().subscribe(resp => {
      this.custCatgType = resp;
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
}
