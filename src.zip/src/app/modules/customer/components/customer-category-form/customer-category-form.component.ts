import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { CustomerService } from '../../services/customer.service';
declare var $: any;

@Component({
  selector: 'app-customer-category-form',
  templateUrl: './customer-category-form.component.html',
  styleUrls: ['./customer-category-form.component.css'],
  providers: [DatePipe]
})
export class CustomerCategoryFormComponent {

  custCatgType: any;
  button: string;
  custID: any;
  userId: any;
  date: Date;
  errormsg: any;
  type: any;
  path: any;
  header: any;
  editFlag: boolean;
  action: string;
  custCategoryForm: UntypedFormGroup;
  isEdit: boolean;

  constructor(
    private session: SessionStorageService,
    private toastService: ToastService,
    private fb: UntypedFormBuilder,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private loaderService: LoaderService,
    private customerservice: CustomerService,
    private datePipe: DatePipe
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.activeRoute.queryParams.subscribe((params: any) => {
<<<<<<< HEAD
      if (params && params.code) {
=======
      if (params && params.acCode) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.isEdit = true;
        this.custID = params.acCode;
        this.editInfo();
      }
      this.userId = this.session.get('userId');
    });
    this.custCategory();
    this.loadCatgTypeList();

    if ('edit' == this.action) {
      this.editInfo();
      this.button = "Update";
    } else {
      this.button = "Save";
    }
    this.userId = this.session.get("userId");
  }
  custCategory() {
    this.custCategoryForm = this.fb.group({
      acCode: ['', Validators.required],
      acDesc: ['', Validators.required],
      acValue: [undefined, Validators.required],
      acEffFmDt: '',
      acEffToDt: '',
      acCrDt: new Date(),
      acCrUid: this.session.get("userId"),
      acCodeByLobYn: '0',
      acType: 'CUST_CATG'
    })
  }

  editInfo() {
    this.editFlag = true;
    this.loaderService.isBusy = true;
    this.customerservice.retrieveCategoryById(this.path, 'CUST_CATG', this.custID).subscribe(result => {
      this.custCategoryForm.patchValue({
        acCode: result[0].acCode,
        acDesc: result[0].acDesc,
        acValue: result[0].acValue,
        acEffFmDt: this.datePipe.transform(result[0].acEffFmDt, ApiUrls.DATE_FORMAT),
        acEffToDt: this.datePipe.transform(result[0].acEffToDt, ApiUrls.DATE_FORMAT),
        acCrDt: result[0].acCrDt,
        acCrUid: result[0].acCrUid,
        acCodeByLobYn: result[0].acCodeByLobYn == null ? '0' : result[0].acCodeByLobYn,
        acType: result[0].acType,
      })
      this.custID = result[0].acId;
      this.loaderService.isBusy = true;
    }, error => {
      this.loaderService.isBusy = true;
    });
  }
  save() {
    if (this.custCategoryForm.valid) {
      this.loaderService.isBusy = true;
      this.custCategoryForm.patchValue({
        acEffFmDt: moment(this.custCategoryForm.get("acEffFmDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD'),
        acEffToDt: moment(this.custCategoryForm.get("acEffToDt").value, 'DD-MM-YYYY').format('YYYY-MM-DD')
      })
      if (this.action == 'edit') {
        // this.customerservice.updateCategoryDetails(this.path, this.custID, this.custCategoryForm.value).subscribe(result => {
        //   this.loaderService.isBusy = true;
        //   this.toastService.success("Saved Successfully.");
        //   this.back();
        // }, error => {
        //   this.loaderService.isBusy = true;
        //   this.toastService.error(error.error.message);
        // });
      }
      else {
<<<<<<< HEAD
        this.customerservice.saveCategoryDetails(this.path, this.custCategoryForm.value).subscribe(result => {
          this.loaderService.isBusy = true;
          this.toastService.success("Saved Successfully.");
          this.back();
        }, error => {
          this.loaderService.isBusy = true;
          this.errormsg = error.error.message;
          this.toastService.error(error.error.message);
        });
=======
        // this.customerservice.saveCategoryDetails(this.path, this.custCategoryForm.value).subscribe(result => {
        //   this.loaderService.isBusy = true;
        //   this.toastService.success("Saved Successfully.");
        //   this.back();
        // }, error => {
        //   this.loaderService.isBusy = true;
        //   this.errormsg = error.error.message;
        //   this.toastService.error(error.error.message);
        // });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    } else {
      this.validateAllFormFields(this.custCategoryForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  back() {
    this.router.navigate(['/customers-setup/customerCat'], { queryParams: { 'flag': true, 'title': 'Customer Category' } });
  }

  loadCatgTypeList() {
    this.customerservice.custCatgTypeList().subscribe(resp => {
      this.custCatgType = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
}
