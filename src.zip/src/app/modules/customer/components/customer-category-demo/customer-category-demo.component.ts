
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { Utils } from 'src/app/utils';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-customer-category-demo',
  templateUrl: './customer-category-demo.component.html',
  styleUrls: ['./customer-category-demo.component.scss']
})
export class CustomerCategoryDemoComponent implements OnInit {
  public defaultColDef;
  user: any;
  appCodes: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';
  columnDefs = [];
  custCategoryForm: UntypedFormGroup;
  details: any;
  custCatgType: any;

  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private customerService: CustomerService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }
  showForm: boolean = false;
  AddFlag;
  action: string = '';
  isEdit: boolean = false;

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.user = this.session.get('userId');
    this.columnDefs = [
      {
        field: 'acCode',
        headerName: 'Category Code'
      },
      {
        field: 'acDesc',
        headerName: 'Category Desc'
      },
      {
        field: 'acType',
        headerName: 'Category Type'
      },
      {
        field: 'acCode',
        headerName: 'Action',
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },

    ];
    this.customerCategory();
    this.createForm();

  }
  createForm() {
    this.custCategoryForm = this.fb.group({
      acId: [''],
      acCode: ['', Validators.required],
      acDesc: ['', Validators.required],
      acValue: [undefined, Validators.required],
      acEffFmDt: '',
      acEffToDt: '',
      acCrDt: new Date(),
      acCrUid: this.session.get("userId"),
      acType: 'CUST_CATG'
    })
  }

  addCustomerCategory() {
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'add';
    this.isEdit = false;
    this.loadCatgTypeList();
  }
  cancel() {
    this.showForm = false;
    this.AddFlag = true;
    this.custCategoryForm.reset();
  }
  customerCategory() {
    this.customerService.retrieveCustCategory().subscribe(resp => {
      this.details = resp;
      this.loaderService.isBusy = false;

    }, error => {
      this.toastService.error('Error in Retrive Data');
      this.loaderService.isBusy = false;
    });
  }
  loadCatgTypeList() {
    this.customerService.custCatgTypeList().subscribe(resp => {
      this.custCatgType = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  saveCustomerCategory() {
    if (this.custCategoryForm.valid) {
      this.loaderService.isBusy = true;
      let custCategoryData = this.custCategoryForm.value;
      custCategoryData.acType = 'CUST_CATG';
      custCategoryData.acUpdDt = new Date();
      custCategoryData.acUpdUid = this.session.get('userId');
      if ('edit' === this.action) {
        delete custCategoryData.acCrDt;
        delete custCategoryData.acCrUid;
        this.customerService.updateCategoryDetails(custCategoryData).subscribe(result => {
          if (result["messageType"] && result["messageType"] == 'E') {
            this.loaderService.isBusy = false;
            this.toastService.error(result["message"]);
          } else if (result["messageType"] && result["messageType"] == 'S') {
            this.loaderService.isBusy = false;
            this.toastService.success("Updated Successfully.");
            this.cancel();
            this.customerCategory();
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        });
      } else {
        custCategoryData.acCrDt = new Date();
        custCategoryData.acCrUid = this.session.get('userId');
        custCategoryData.acInstId = 1;
        this.customerService.saveCategoryDetails(custCategoryData).subscribe(result => {
          if (result["messageType"] && result["messageType"] == 'E') {
            this.loaderService.isBusy = false;
            this.toastService.error(result["message"]);
          } else if (result["messageType"] && result["messageType"] == 'S') {
            this.loaderService.isBusy = false;
            this.toastService.success("Saved Successfully.");
            this.cancel();
            this.customerCategory();
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        });
      }
    } else {
      Utils.validateAllFormFields(this.custCategoryForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  editCustomerCategory(result) {
    this.loadCatgTypeList();
    this.action = 'edit';
    this.showForm = true;
    this.isEdit = true;
    this.custCategoryForm.patchValue({
      acId: result.acId,
      acCode: result.acCode,
      acDesc: result.acDesc,
      acValue: result.acValue,
      acEffFmDt: result.acEffFmDt == null ? null : moment(result.acEffFmDt).toDate(),
      acEffToDt: result.acEffToDt == null ? null : moment(result.acEffToDt).toDate(),
      acCrDt: result.acCrDt,
      acCrUid: result.acCrUid,
      acType: result.acType,
    });
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'Edit':
          return this.editCustomerCategory(data);
      }
    }
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any,) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
        <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true"></i>
     </a>`;
  }
}
