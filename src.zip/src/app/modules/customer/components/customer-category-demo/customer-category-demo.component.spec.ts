import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerCategoryDemoComponent } from './customer-category-demo.component';

describe('CustomerCategoryDemoComponent', () => {
  let component: CustomerCategoryDemoComponent;
  let fixture: ComponentFixture<CustomerCategoryDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerCategoryDemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerCategoryDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
