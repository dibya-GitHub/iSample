import { Component } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
   selector: 'app-customer',
   templateUrl: './customer.component.html',
   styleUrls: ['./customer.component.scss']
})

export class CustomerComponent {
   public defaultColDef;
   gridApi: any;
   gridColumnApi: any;
   showEntriesOptions = [10, 20, 50, 100];
   showEntriesOptionSelected = 10;
   quickSearchValue: string;
   colDefs: any[];
   rowData: any[];
   exchangeRateForm: UntypedFormGroup;
   exchRateList;
   currList;
   exchDateList;
   constructor(
      private router: Router,
      private loaderService: LoaderService
   ) { }
   ngOnInit(): void {
      //this.loaderService.isBusy = true;
      this.colDefs = [
         {
            field: 'customerPK',
            headerName: 'Code',
            //subFields: 'custCode'
         },
         {
            field: 'custName',
            headerName: 'Customer Name'
         },
         {
            field: 'custGroupDesc',
            headerName: 'Cust Group Desc'
         },
         {
            field: 'custCcCode',
            headerName: 'ID/CR NO'
         },
         {
            field: 'custEffFmDt',
            headerName: 'Effective From Date',
            //dateField: 'yes'
         },
         {
            field: 'custEffToDt',
            headerName: 'Effective To Date',
            //dateField: 'yes'
         },
         {
            field: 'custCreditLimit',
            headerName: 'Credit limit'
         },
         {
            field: 'custCreditDays',
            headerName: 'Credit Days'
         },
         {
            field: 'Action',
            headerName: 'Action'
         }
      ];
   }
   onGridReady(params) {
      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
      this.gridApi.sizeColumnsToFit();
   }
   onQuickFilterChanged() {
      this.gridApi.setQuickFilter(this.quickSearchValue);
   }

   pageChanged(event: any): void {
      this.gridApi.paginationGoToPage(event.page - 1);
   }
   onFirstDataRendered(params) {
      params.api.sizeColumnsToFit();
   }
   onPaginationCountChange(event: any) {
      this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
      this.gridApi.paginationGoToPage(0);
   }
   back() {
      this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
   }
   searchCustomers() {

   }
   public onRowClicked(e) {

   }
}