import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { GlobalService } from 'src/app/shared/services/global.service';
import { CustomerService } from '../../services/customer.service';
<<<<<<< HEAD
=======
																
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
declare var $: any;

@Component({
  selector: 'app-customer-category',
  templateUrl: './customer-category.component.html',
  styleUrls: ['./customer-category.component.css']
})

export class CustomerCategoryComponent {

  public defaultColDef;
  gridApi: any;
  gridColumnApi: any;
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  quickSearchValue: string;
  details2: any;
  CM_Code: any;
  appControlFlag: boolean;
  code1: any;
  tableColumns: any[];
  tableColumns2: any[];
  tableColumns3: any[];
  details: any = [];
  CM_Details: any = [];
  appCodes: any[];
  applicableCodes: any[];
  exchDateList: any[];
  code: any;
  path: any;
  type: any;
  header: string;
  custCatConfigs: any[];

  @ViewChild('trigger') tr: ElementRef;

  constructor(
    private router: Router,
    private globalServices: GlobalService,
    private toastService: ToastService,
    private customerservice: CustomerService,
    private loaderService: LoaderService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.header = this.globalServices.getParamValue('title');
    this.type = "CUST_CATG";

    this.custCatConfigs = [
      {
        field: 'acCode',
        headerName: 'Category Code'
      },
      {
        field: 'acDesc',
        headerName: 'Category Desc'
      },
      {
        field: 'acType',
        headerName: 'Category Type'
      },
      {
        field: 'acCode',
        headerName: 'Action',
<<<<<<< HEAD
        template:
          ` <a>
                  <i class='fa fa-file-pen fa-icon' data-action-type='Edit' title='Edit' aria-hidden='true'></i>
            </a>`,
=======
        cellRenderer: actionRender,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },

    ];
    this.customerCategory();
    let date1: string = '2017-03-05 11:26:16 AM';
    let date2: string = '2017-03-06 12:26:16 AM';

    let diffInMs: number = Date.parse(date2) - Date.parse(date1);
    let diffInHours: number = diffInMs / 1000 / 60 / 60;
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
<<<<<<< HEAD
      const data = e.data;
=======
      const data = e.data;										   
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      const actionType = e.event.target.getAttribute('data-action-type');

      switch (actionType) {
        case 'Edit':
          return this.navigateToForm(data);
        case 'Delete':
        // return this.deleteCurrency(data);
      }
    }
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  customerCategory() {

    this.customerservice.retrieveCustCategory().subscribe(resp => {
      this.loaderService.isBusy = false;
      this.details = resp;
    }, error => {
      this.toastService.error('Error in Retrive Data');
      this.loaderService.isBusy = false;
    });
  }

  addMaster() {
    let obj = { 'path': this.path, 'action': 'add ', type: this.type }
    this.router.navigate(['/master/cust-category-form'], { queryParams: obj, skipLocationChange: true });
  }

  editMaster(data) {
<<<<<<< HEAD
=======
										 
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.onSelect(data);
    let obj = { 'path': this.path, 'action': 'edit', 'code': this.code, 'code1': this.code1, type: this.type }
    this.router.navigate(['/master/cust-category-form'], { queryParams: obj, skipLocationChange: true });
  }
  onSelect(event) {
    this.code = event.acId;
  }

  viewmaster(event) {
    this.loaderService.isBusy = true;
    this.appControlFlag = true;
    this.tableColumns2 = this.applicableCodes;
    this.CM_Code = event.acCode;
    this.customerservice.retrieveCodeMapping(this.path, this.CM_Code).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.CM_Details = resp;

    }, error => {
      this.loaderService.isBusy = false;
    });
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
  navigateToForm(data) {
    if (data) {
      this.router.navigate(['/customers-setup/customerCat/edit'], { queryParams: { code: data.acCode } });
    } else {
<<<<<<< HEAD
      this.router.navigate(['/customers-setup/customerCat/add'], { queryParams: { code: data.currCode } });
=======
      this.router.navigate(['/customers-setup/customerCat/add'], { queryParams: { code: data.acCode } });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  // bookmarkScript() {
  //   $(document).ready(function () {
  //     var bookmarked;
  //     bookmarked = false;
  //     return $(".cont").on("mousedown", function () {
  //       if (bookmarked !== true) {
  //         $(".bookmark").toggleClass("bookmarked");
  //         $(".cont").toggleClass("cont_alter");
  //         $(".label").toggleClass("hide_label");
  //         $(".label2").toggleClass("hide_label");
  //         return bookmarked = true;
  //       }
  //       else {
  //         $(".bookmark").toggleClass("bookmarked");
  //         $(".cont").toggleClass("cont_alter");
  //         $(".label").toggleClass("hide_label");
  //         $(".label2").toggleClass("hide_label");
  //         return bookmarked = false;
  //       }
  //     });
  //   });
  // }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
        <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true"></i>
     </a>`;
  }
}