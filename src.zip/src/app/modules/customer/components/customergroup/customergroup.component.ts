import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-customergroup',
  templateUrl: './customergroup.component.html',
  styleUrls: ['./customergroup.component.css']
})

export class CustomergroupComponent {

  public defaultColDef;
  colDefs: any[];
  gridApi: any;
  gridColumnApi: any;
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  quickSearchValue: string;
  customerGroupData: any;
  constructor(
    private router: Router,
    private loaderService: LoaderService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.colDefs = [
      {
        field: '',
        headerName: 'Group Code',
      },
      {
        field: '',
        headerName: 'Description',
      },
      {
        field: '',
        headerName: 'Action',
      }
    ];
    this.loaderService.isBusy = false;
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
  navigateToForm(data) {
    if (data) {
      this.router.navigate(['/customers-setup/customerGroup/edit'], { queryParams: { code: data.currCode } });
    } else {
<<<<<<< HEAD
      this.router.navigate(['/customers-setup/customerGroup/add'], { queryParams: { code: data.currCode } });
=======
      this.router.navigate(['/customers-setup/customerGroup/add'], { queryParams: { code: data.currCode }, });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }
}
