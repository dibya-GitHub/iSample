import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { MasterMenuComponent } from './master-menu/master-menu.component';
import { MasterRoutingModule } from './master-routing.module';

@NgModule({
  imports: [
    CommonModule,
    MasterRoutingModule,
    ReactiveFormsModule,
    CommonAppModule,

  ],
  declarations: [
    AdminDashboardComponent,
    MasterMenuComponent

  ],
  schemas: [
    NO_ERRORS_SCHEMA,
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class MasterModule { }
