import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { MasterMenuComponent } from './master-menu/master-menu.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'prefix',
    redirectTo: 'admindashboard',
    data: {
      breadcrumb: { skip: true }
    },
  },

  {
    path: 'admindashboard',
    component: AdminDashboardComponent,
    data: {
      breadcrumb: 'Admin Dashboard'
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterRoutingModule { }
