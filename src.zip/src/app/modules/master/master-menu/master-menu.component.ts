import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
<<<<<<< HEAD
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderServiceService } from 'src/app/shared/Loader-service/loader-service.service';
import { CustomerService } from 'src/app/shared/services/customer.service';
=======
import { UntypedFormGroup } from '@angular/forms';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { UntypedFormControl } from '@angular/forms';
import { LoaderServiceService } from 'src/app/shared/Loader-service/loader-service.service';
import { SessionStorageService } from 'angular-web-storage';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { GlobalService } from 'src/app/shared/services/global.service';
import { ReportService } from 'src/app/shared/services/report.service';
<<<<<<< HEAD
import { UserService } from 'src/app/shared/services/user.service';

=======
import { CustomerService } from 'src/app/shared/services/customer.service';
import { ApiUrls } from 'src/app/api-urls';
import { ViewChild } from '@angular/core';
import { ElementRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
declare var $: any;

@Component({
  selector: 'app-master-menu',
  templateUrl: './master-menu.component.html',
  styleUrls: ['./master-menu.component.css'],
})
export class MasterMenuComponent implements OnInit {
  gridColumnApi: any;
  gridApi: any;

  @ViewChild('content') content: ElementRef;
  errorMsg: any;
  custGrpCols: any = [];
  custCatgCols: any;
  appCodeCols: any;
  enqRepLokInfo: any;
  isShowRepLook: boolean = false;
  enqReport: any = [];
  tableheading: any;
  enqRepLookCols: any = [];
  msgs: { severity: string; summary: string; detail: string; }[];
  menuCols: any = [];
  dt: void;
  cur: void;
  rtf: void;
  onlyRead: boolean;
  reportLogFrm: UntypedFormGroup;
  customerFrm: UntypedFormGroup;
  showlog: boolean;
  repDateList: any = [];
  repUserList: any = [];
  reprtLogFrm: UntypedFormGroup;
<<<<<<< HEAD
  //reprtLogFrm: FormGroup;
=======
  //reprtLogFrm: UntypedFormGroup;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  reportCols: any = [];
  exchDateList: any = [];
  currFromToList: any = [];
  exchRateForList: any = [];
  exchRateFrm: UntypedFormGroup;
  code4: any;
  code3: any;
  code2: any;
  exchRateCols: any[];

  reportInfo: any[];
  mReportColumn: any[];
  mCurrencyColumn: any[];
  transDocSrchFrm: UntypedFormGroup;
  docTypeList: any = [];
  docType: any;
  transDocCols: any[];
  action: string;
  compCode: any;
  deptCostCode: any;
  deptDivnCode: any;
  deptCompCode: any;
  divnCompCode: any;
  costDivCode: any;
  costCompCode: any;
  costCols: any[];
  teamCols: any[];
  userInfo: any;
  userRoleCols: any[];
  selectedId: any;
  departCols: any[];
  diviCode: any;
  divCols: any[];
  compCols: any[];
  userCols: any[];
  appParamCols: any[];
  header: any;
  page: any;
  title: any;
  userRoleFrm: UntypedFormGroup;
  smsEmailTemplateFrm: UntypedFormGroup;
  displayDialog: boolean;
  newCar: boolean;
  cars: any = [];
  compDetail: any = [];
  loading: boolean;
  userRoleInfo: any;

  isShowUserMaster: boolean = false;
  isShowflag: boolean = false;
  compInfo: any = [];
  code: any;
  code1: any;
  disableFlag: boolean = true;
  totalRecords: number;
  tableColumns: any[];
  loginDetailsTable: any[];
  smsemailmaster: boolean;
  userRoleMaster: boolean;
  smsEmailCols: any[];
  appConfig: any[];
  appCodes: any[];
  details: Array<any>;
  loginDetails: Array<any>;
  template_code: any;
  editFlag: boolean;
  paraCode: string;
  paraSubCode: string;
  //isShowEditFlg :boolean=false;
  enableEdit: boolean = true;
  showLoginDetails: boolean = false;
  showApplCompDetails: boolean = false;
  applCompTable: any[];
  applCompDetails: Array<any>;
  applCompColumn: any[];
  displayViewDialog: boolean;
  viewUserRole: boolean;
  userLoginCols: any[];

  applUserRoleColumn: any[];
  applUserRoleTable: any[];
  showapplUserRoleDetails: boolean = false;
  applUserRoleDetails: any[];

  insuredMasterCols: any[];

  dashboard: boolean = true;
  type: any;
  bankCols: any[];

  custCode: string;
  repIdList: any = [];
  repLogList: any = [];

  groupCodeList: any = [];
  categoryList: any = [];

  menuList = [];
  selectedMenuList = [];

  applicableCompTitle: string;
  loginAttemptTitle: string;

  emptyMessage: string = "No data Found";
  autocompleteStyle: string = "border :0px";
  @Output('viewMasterEvent')
  viewMasterEvent = new EventEmitter<number>();
  display: boolean;
  userRoleId: string;
  filteredCustomerList: any;

  userId: string;

  @ViewChild('trigger') tr: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private globalService: GlobalService,
    private userService: UserService,
    private reportService: ReportService,
    private customerService: CustomerService,
<<<<<<< HEAD
    private loaderService: LoaderServiceService,
    private session: SessionStorageService,
    private authService: AuthService,
    private modalService: BsModalService
  ) { }
=======
    private fb: UntypedFormBuilder,
    private loaderService: LoaderServiceService,
    private session:SessionStorageService,
    private modalService: BsModalService
    //private spinnerService: Ng4LoadingSpinnerService,
    ) { }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032


  ngOnInit() {

    this.compCols = [
      { field: 'mcompanyPK.compCode', header: 'Code', subFields: 'compCode' },
      { field: 'compName', header: 'Desc' },
      { field: 'compEmailId', header: 'Email' },
      { field: 'Action', header: 'Action' }
    ];
    this.userCols = [
      { field: 'userPK', header: 'Login Id', subFields: 'userId' },
      { field: 'userName', header: 'User Name' },
      { field: 'userEmailId', header: 'Email Id' },
      { field: 'userMobileNo', header: 'Contact No' },
      { field: 'userDisableFlag', header: 'Status', flage: 'yes' },
      { field: 'userAction', header: 'Action' }
    ];
    this.userLoginCols = [
      { field: 'loghLoginDt', header: 'Login Date', },//dateField: 'yes'
      { field: 'loghIpAddress', header: 'Ip Address' },
      { field: 'loghSessionId', header: 'Session Id' },
      { field: 'loghDevice', header: 'Device Name' },
      { field: 'loghDeviceOs', header: 'Device Os' },
      { field: 'loghBrowser', header: 'Browser' },
      { field: 'loghStatus', header: 'Login Status' },
      { field: 'loghLogoutDt', header: 'Logout Date',},//dateField: 'yes'
      { field: 'loghRemarks', header: 'Remarks' }
    ];
    this.applCompColumn = [
      { field: 'userCompCode', header: 'Company' },
      { field: 'userDivCode', header: 'Division' },
      { field: 'userCostCode', header: 'Cost Centre' },
      { field: 'userDeptCode', header: 'Depatment' }
    ];
    this.mCurrencyColumn = [
      { field: 'currCode', header: 'Currency' },
      { field: 'currName', header: 'Currency Name' },
      { field: 'currShortName', header: 'ShortName' },
      { field: 'currUnitName', header: 'Unit Name' },
      { field: 'currFreezYn', header: 'Freeze YN', currency: 'yes' },
      { field: 'currFreezDt', header: 'Freeze Date', dateField: 'yes' },
      { field: 'Action', header: 'Action' }
    ];
    this.mReportColumn = [
      { field: 'mrepHeadingsPK', header: 'Report ID', subFields: 'rhRepId' },
      { field: 'mrepHeadingsPK', header: 'Company', subFields: 'rhCompCode' },
      { field: 'rhRepName', header: 'Report Name' },
      { field: 'rhRepNameFl', header: 'Report Name Arabic' },
      { field: 'Action', header: 'Action' },
    ];
    this.applUserRoleColumn = [
      { field: 'userId', header: 'User Id' },
      { field: 'userCompCode', header: 'Company' },
      { field: 'userDivCode', header: 'Division' },
      { field: 'userCostCode', header: 'Cost Centre' },
      { field: 'userDeptCode', header: 'Depatment' }
    ];
    this.smsEmailCols = [
      { field: 'smtTempCode', header: 'code' },
      { field: 'smtTempDesc', header: 'Desc' },
      { field: 'smtEmailTo', header: 'Email To' },
      { field: 'smtCrDt', header: 'Created Date' },
      { field: 'Action', header: 'Action' }
    ];
    this.divCols = [
      { field: 'mdivisionPK', header: 'Code', subFields: 'divnCode' },
      { field: 'divnName', header: 'Desc' },
      { field: 'Action', header: 'Action' }
      //   { field: '', header: 'Email' }
    ];
    this.departCols = [
      { field: 'mdepartmentPK', header: 'Code', subFields: 'deptCode' },
      { field: 'deptName', header: 'Desc' },
      { field: 'Action', header: 'Action' }
      //  { field: '', header: 'Email' }
    ];
    this.userRoleCols = [
      { field: 'muserRolesPK', header: 'Role Id', subFields: 'urId' },
      { field: 'urDesc', header: 'Role Description' },
      { field: 'roleAction', header: 'Actions' }
      // { field: 'urBlDesc', header: 'Email' }
    ];
    this.teamCols = [
      { field: 'teamCode', header: 'Code' },
      { field: 'teamName', header: 'Desc' },
      { field: 'teamBlName', header: 'Email' },
      { field: 'Action', header: 'Action' }
    ];
    this.costCols = [
      { field: 'mcostCentrePK', header: 'Code', subFields: 'costCode' },
      { field: 'costName', header: 'Desc' },
      { field: 'Action', header: 'Action' }
    ];

    this.appConfig = [
      { field: 'acName', headerName: 'Name' },
      { field: 'acValue', headerName: 'Value' },
      { field: 'acRemarks', headerName: 'Remarks' },
      {
        headerName: 'Action',
        field: 'actions',
        template:
          ` <a>
        <i class="fa fa-file-pen"  data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true"></i>
        </a>`
      },
    ];


    this.appParamCols = [
      { field: 'mappParameterPK', header: 'Code', subFields: 'paraCode' },
      { field: 'paraName', header: 'Desc' },
      { field: 'mappParameterPK', header: 'Sub-Code', subFields: 'paraSubCode' },
      { field: 'Action', header: 'Action' }
    ];

    this.teamCols = [
      { field: 'teamCode', header: 'Code' },
      { field: 'teamName', header: 'Desc' },
      { field: 'Action', header: 'Action' }
    ];
    // this.transDocCols = [
    //   { field: 'mtranDocNoPK', header: 'Doc Type', subFields: 'tdnDocType' },
    //   { field: 'tdnUpdUid', header: 'Division Name' },
    //   { field: 'mtranDocNoPK', header: 'Code', subFields: 'tdnCode' },
    //   { field: 'tdnCurrNo', header: 'Current No' },
    //   { field: 'mtranDocNoPK', header: 'Ac Year', subFields: 'tdnYear' },
    //   { field: 'Action', header: 'Action' }
    // ];
    this.exchRateCols = [
      { field: 'exchangeRatePK', header: 'Rate Type', subFields: 'erRateFor' },
      { field: 'exchangeRatePK', header: 'From Currency', subFields: 'erConvFmCurrCode' },
      { field: 'exchangeRatePK', header: 'To Currency', subFields: 'erConvToCurrCode' },
      { field: 'erBuyRate', header: 'Buy Rate' },
      { field: 'erSelRate', header: 'Sell Rate' },
      { field: 'exchangeRatePK', header: 'Eff Fm Date', subFields: 'erEffFrmDt',},// dateField: 'yes' 
      { field: 'exchangeRatePK', header: 'Eff To Date', subFields: 'erEffToDt',}, // dateField: 'yes' 
      { field: 'Action', header: 'Action' }
    ];
    this.reportCols = [
      { field: 'repSrNo', header: 'Rep Sr No' },
      { field: 'repId', header: 'Rep ID' },
      { field: 'repCompCode', header: 'Company' },
      { field: 'repCrUid', header: 'User' },
      { field: 'repCrDt', header: 'Date',},//dateField: 'yes'
      { field: 'repAction', header: 'Action' },

    ];

    this.insuredMasterCols = [
      { field: 'customerPK', header: 'Code', subFields: 'custCode' },
      { field: 'custName', header: 'Customer Name' },
      { field: 'custGroupDesc', header: 'Cust Group Desc' },
      { field: 'custCcCode', header: 'ID/CR NO' },
      { field: 'custEffFmDt', header: 'Effective From Date',},// dateField: 'yes' 
      { field: 'custEffToDt', header: 'Effective To Date',},// dateField: 'yes' 
      { field: 'custCreditLimit', header: 'Credit limit' },
      { field: 'custCreditDays', header: 'Credit Days' },
      { field: 'Action', header: 'Action' }
    ];
    this.bankCols = [
      { field: 'bankCode', header: 'Bank Code' },
      { field: 'bankName', header: 'Bank Name' },
      { field: 'bankShortName', header: 'Short Name' },
      { field: 'bankAddr01', header: 'Address' },
      { field: 'bankContPerName', header: 'Cont. Person' },
      { field: 'bankContPerPhNo', header: 'Cont. Per. Phone No' },
      { field: 'bankContPerEmail', header: 'Cont. Per. Email' },
      { field: 'Action', header: 'Action' }
    ];
    this.menuCols = [
      { field: 'menuParentId', header: 'Parent Menu' },
      { field: 'mmenuPK', header: 'Menu Id', subFields: 'menuId' },
      { field: 'menuScrName', header: 'Name' },
      { field: 'menuSrNo', header: 'Disp Sr No' },
      { field: 'menuAction', header: 'Menu Action' },
      { field: 'menuType', header: 'Type' },
      { field: 'menuSection', header: 'Section' },
      { field: 'MenuAction', header: 'Action' }
    ];
    this.enqReport = [
      { field: 'erTableName', header: 'Table Name' },
      { field: 'erShortDesc', header: 'Short Description' },
      { field: 'erLongDesc', header: 'Long Description' },
      { field: 'erDispSrNo', header: 'Display Sr No' },
      { field: 'erCrUid', header: 'Created By' },
      { field: 'erCrDt', header: 'Created Date',},// dateField: 'yes' 
      { field: 'RepAction', header: 'Action' }
    ];
    this.enqRepLookCols = [
      { field: 'elkColumnName', header: 'Column Name' },
      { field: 'elkFieldName', header: 'Display Field Name' },
      { field: 'elkAutoCompYn', header: 'Auto Comp YN' },
      { field: 'elkQuery', header: 'Query' },
      { field: 'elkCrUid', header: 'Created By' },
      { field: 'elkCrDt', header: 'Created Date',},//dateField: 'yes' 
      { field: 'Action', header: 'Action' }
    ];
    this.custGrpCols = [
      { field: 'acCode', header: 'Group Code' },
      { field: 'acDesc', header: 'Description' },
      { field: 'Action', header: 'Action' }
    ];
    this.appCodeCols = [
      { field: 'elkColumnName', header: 'Column Name' },
      { field: 'elkFieldName', header: 'Display Field Name' },
      { field: 'elkAutoCompYn', header: 'Auto Comp YN' },
      { field: 'elkQuery', header: 'Query' },
      { field: 'elkCrUid', header: 'Created By' },
      { field: 'elkCrDt', header: 'Created Date',},//dateField: 'yes'
      { field: 'Action', header: 'Action' }
    ];


    this.loading = true;
    this.page = this.globalService.getParamValue('path');
    this.title = this.globalService.getParamValue('title');
    this.header = this.globalService.getParamValue('header');
    if (this.header == null || this.header == undefined) {
      this.header = this.title
    }
    if ((this.page != null && this.title != null)
      || (this.page != undefined && this.title != undefined)) {
      if (ApiUrls.COMP_TITLE == this.title && ApiUrls.ORCHART_TITLE == this.globalService.getParamValue('type')) {
        this.addMaster();
      } else if (ApiUrls.SRAND_LETTER_TITLE == this.title) {
        this.router.navigate(['/master/standardletter'], { queryParams: { "path": this.page }, skipLocationChange: true });
      } else if (ApiUrls.TRANS_DOC_TITLE == this.title) {
        this.createTranDocfrm();
        this.globalService.retrieveTransDocType(this.page).subscribe(result => {
          this.docTypeList = result;
          this.ngAfterViewInit();
          this.scriptcall();
          this.loaderService.display(false);
<<<<<<< HEAD
=======
          console.log(this.docTypeList);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        }, error => {
          this.scriptcall();
        });
      } else if (ApiUrls.EXC_RATE_TITLE == this.title) {
        this.loaderService.display(true);
        this.createExchRatefrm();
        this.scriptcall();
      } else if (ApiUrls.REPT_LOG == this.title) {
        this.createReprtFrm();
        this.reportService.retrieveRepIdList(this.page).subscribe(resp => {
          this.repIdList = resp;
          this.ngAfterViewInit();
        })
        this.reportService.retrieveRepUserList(this.page).subscribe(resp => {
          this.repUserList = resp;
          this.ngAfterViewInit();
        })
        this.reportService.retrieveRepDateList(this.page).subscribe(resp => {
          this.repDateList = resp;
          this.ngAfterViewInit();
        })
      } else if (ApiUrls.CUST_TITLE == this.title) {
        this.createCustomerFrm();
        this.customerService.getAppCodesList('CUST_GROUP', this.page).subscribe(resp => {
          this.groupCodeList = resp;
          this.customerService.getcodeMappingList('CNTL_ACNT_MAP', this.page).subscribe(resp => {
            this.categoryList = resp;
            this.ngAfterViewInit();
          })
        })

      }

      this.headerDetails();



    }


  }



  headerDetails() {
    this.loaderService.display(true);
    this.isShowflag = true;
    this.enableEdit = true;
    if (ApiUrls.COMP_TITLE == this.title) {
      this.tableColumns = this.compCols;
    } else if (ApiUrls.ROLE_TITLE == this.title) {
      //this.tableColumns = this.userRoleCols;
      this.router.navigate(['/user-setup/user-role']);
    } else if (ApiUrls.USER_TITLE == this.title) {
      this.router.navigate(['/user-setup/user']);
      //this.tableColumns = this.userCols;
    } else if (ApiUrls.SMS_EMAIL_TITLE == this.title) {
      this.tableColumns = this.smsEmailCols;
    } else if (ApiUrls.TEAM_TITLE == this.title) {
      this.tableColumns = this.teamCols;
    } else if (ApiUrls.DIVN_TITLE == this.title) {
      this.tableColumns = this.divCols;
    } else if (ApiUrls.DEPT_TITLE == this.title) {
      this.tableColumns = this.departCols;
    } else if (ApiUrls.COST_CENT_TITLE == this.title) {
      this.tableColumns = this.costCols
    } else if (ApiUrls.PASS_POL_TITLE == this.title) {
      this.router.navigate(['/master/pwdScreen'], { skipLocationChange: true });
    } else if (ApiUrls.APP_CONF_TITLE == this.title) {
      this.tableColumns = this.appConfig;
    } else if (ApiUrls.APP_PARAM_TITLE == this.title) {
      this.tableColumns = this.appParamCols;
    } else if (ApiUrls.SMT_REPT_TITLE == this.title) {
      this.router.navigate(['/master/report'], { queryParams: { "path": this.page }, skipLocationChange: true });
    } else if (ApiUrls.CUST_TITLE == this.title) {
      this.tableColumns = this.insuredMasterCols;
      //this.router.navigate(['/master/insured'], { queryParams: { "path": this.page } });
    } else if (ApiUrls.TRANS_DOC_TITLE == this.title) {
      this.tableColumns = this.transDocCols;
    } else if (ApiUrls.EXC_RATE_TITLE == this.title) {
      this.tableColumns = this.exchRateCols;
    }
    else if (ApiUrls.CURRENCY_TITLE == this.title) {
      this.tableColumns = this.mCurrencyColumn;
    }
    else if (ApiUrls.REPT_TITLE == this.title) {
      this.tableColumns = this.mReportColumn;
    } else if (ApiUrls.BANK_TITLE == this.title) {
      this.tableColumns = this.bankCols;
    }
    else if (ApiUrls.REPT_LOG == this.title) {
      this.tableColumns = this.reportCols;
    } else if (ApiUrls.REPT_HEAD_TITLE == this.title) {
      this.tableColumns = this.mReportColumn;
    } else if (ApiUrls.USER_MENU_TITLE == this.title) {
      // this.tableColumns = this.menuCols;
      this.router.navigate(['/user-setup/menu']);
    } else if (ApiUrls.REPT_TEMP_TITLE == this.title) {
      this.isShowRepLook = true;
      this.tableColumns = this.enqReport;
    } else if (ApiUrls.CUST_GROUP_TITLE == this.title) {
      this.type = 'CUST_GROUP'
      this.tableColumns = this.custGrpCols;
    } else if (ApiUrls.CUST_CATE_TITLE == this.title) {
      this.router.navigate(['/master/cust-category'], { queryParams: { "flag": true, "title": this.title, "path": this.page, "type": this.title }, skipLocationChange: true });
    }

    if (ApiUrls.SMT_REPT_TITLE != this.title && ApiUrls.EXC_RATE_TITLE != this.title) {
      this.getMasterValues();
    }

  }

  getMasterValues() {
    this.loaderService.display(true);
    if (ApiUrls.BANK_TITLE == this.title) {
      this.globalService.retrieveBankDetails(this.page).subscribe(resp => {
        this.details = resp.bankArray;
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);

      }, error => {
        this.scriptcall();
        this.loaderService.display(false);
      });
    } else if (ApiUrls.APP_CONF_TITLE == this.title) {
      // this.globalService.retrieveAppConfigDetails(this.page).subscribe(resp => {
      //   this.details = resp.appConfigArray;
      //   this.scriptcall();
      //  this.loaderService.display(false);

      // }, error => {
      //   this.scriptcall();
      //  this.loaderService.display(false);
      // });
    } else if (ApiUrls.APP_PARAM_TITLE == this.title) {
      // this.globalService.retrieveAppParamsDetails(this.page).subscribe(resp => {
      //   this.details = resp.appParamsArray;
      //   this.scriptcall();
      //  this.loaderService.display(false);

      // }, error => {
      //  this.loaderService.display(false);
      // });
    } else if (ApiUrls.SMS_EMAIL_TITLE == this.title) {
      this.globalService.retrieveSmsEmailDetails(this.page).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);

      }, error => {
        this.loaderService.display(false);
      });
    }
    else if (ApiUrls.SMS_EMAIL_TITLE == this.title) {
      this.globalService.retrieveSmsEmailDetails(this.page).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);

      }, error => {
        this.loaderService.display(false);
      });
    }
    else if (ApiUrls.USER_TITLE == this.title) {

      this.userService.retrieveUserMastertInfo(this.page).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);
      }, error => {
        this.loaderService.display(false);
      });

    } else if (ApiUrls.TRANS_DOC_TITLE == this.title) {
      let data = this.transDocSrchFrm['controls']['transDocType'].value;
      this.globalService.retrieveTranDocList(data, this.page).subscribe(resp => {
        this.details = resp.list;
        this.searchCall();
        // this.scriptcall();
        this.loaderService.display(false);
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }, error => {
        this.loaderService.display(false);
      });

    }
    else if (ApiUrls.CURRENCY_TITLE == this.title) {
      // this.globalService.retrieveCurrencyDetails(this.page, this.type).subscribe(resp => {
      //   this.details = resp;
      //   this.scriptcall();
      //  this.loaderService.display(false);
      // }, error => {
      //  this.loaderService.display(false);
      // });

    } else if (ApiUrls.REPT_HEAD_TITLE == this.title) {
      this.reportService.retrieveRephdDetails(this.page, this.type).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
        this.reportInfo = resp.list
        this.loaderService.display(false);
      }, error => {
<<<<<<< HEAD
=======
        console.log("retrieve", error.message);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);
      });


    } else if (ApiUrls.REPT_TEMP_TITLE == this.header) {
      this.reportService.retrieveEnqReport(this.page).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
        this.loaderService.display(false);
      }, error => {
<<<<<<< HEAD
=======
        console.log("Response  is ", error);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);
      });
      this.reportService.retrieveEnqLookup('reportTemp').subscribe(resp => {
        this.enqRepLokInfo = resp;
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);

      }, error => {
        this.loaderService.display(false);
      });


    } else if (ApiUrls.CUST_TITLE == this.title) {
      this.customerService.retrieveCustomerDetails(this.page).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);
      })

    } else if (ApiUrls.REPT_LOG == this.title) {
      this.reportService.retrieveReportLogs(this.page).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
        this.loaderService.display(false);
      }, error => {
        this.loaderService.display(false);
      })

    } else if (ApiUrls.USER_MENU_TITLE == this.title) {
      this.userService.retrieveMenus(this.page).subscribe(resp => {
        this.details = resp;
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.page*****', resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);
      }, error => {
        this.loaderService.display(false);
      });
    } else if (ApiUrls.ROLE_TITLE == this.title) {
      this.userService.retrieveUserRoles(this.page).subscribe(resp => {
        this.details = resp.list;
        this.viewApplUser(this.details[0].muserRolesPK.urId)
        this.scriptcall();
<<<<<<< HEAD
=======
        console.log('this.test*****', resp.list);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);
      }, error => {
        this.loaderService.display(false);
      });
    } else if (ApiUrls.CUST_GROUP_TITLE == this.title) {
      this.customerService.retrieveCustGroup().subscribe(resp => {
        this.details = resp;
        this.scriptcall();

<<<<<<< HEAD
=======
        console.log('this.page*****', resp.list);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.loaderService.display(false);
      }, error => {
        this.loaderService.display(false);
      });
    }
    /* else {
 
       this.globalService.getMastertDetails(this.page).subscribe(resp => {
         this.details = resp;
        this.loaderService.display(false);
        
       }, error => {
        this.loaderService.display(false);
       });
     }
 */

  }


  loginAttempt(val) {
    this.loaderService.display(true);
    this.loginDetailsTable = this.userLoginCols;
    this.showLoginDetails = true;
    this.loginAttemptTitle = "Login Attempt Details for " + val;
    this.userService.retrieveLoginDetails(this.page, val, "").subscribe(resp => {
      this.loginDetails = resp.list;
      this.scriptcall4();
      this.loaderService.display(false);
    }, error => {
      this.loaderService.display(false);
    });
  }
  applCompanies(val) {
    this.loaderService.display(true);
    this.applicableCompTitle = "Applicable Company for " + val;
    this.applCompTable = this.applCompColumn;
    this.showApplCompDetails = true;
    this.userService.retrieveApplicableCompanies(this.page, val).subscribe(resp => {
      this.applCompDetails = resp.list;
      this.scriptcall2();
      this.loaderService.display(false);
    }, error => {
      this.loaderService.display(false);
    });
  }

  viewApplUser(val) {

    this.loaderService.display(true);
    this.applUserRoleTable = this.applUserRoleColumn;
    this.showapplUserRoleDetails = true;
    this.userService.getApplicableUserRoles(ApiUrls.USER_CONTROLLER_PATH, val).subscribe(resp => {
      this.applUserRoleDetails = resp.list;
      this.scriptcall3();
      this.tableheading = 'Applicable Users';
      // this.scriptcall()
      this.loaderService.display(false);
    }, error => {
      this.loaderService.display(false);
    });
  }


  addMaster() {
    let obj = { 'title': this.title, 'path': this.page, 'action': 'add', type: this.type }

    if (ApiUrls.ROLE_TITLE == this.title) {
      this.editFlag = false;
      //this.action ='add';
      //this.showDialogToAdd(this.header);
      this.router.navigate(['/master/userRoles'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.USER_TITLE == this.title) {
      this.router.navigate(['/master/user'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.COMP_TITLE == this.title) {
      this.router.navigate(['/master/company'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.COST_CENT_TITLE == this.title) {
      this.router.navigate(['/master/cost'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.DEPT_TITLE == this.title) {
      this.router.navigate(['/master/depart'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.DIVN_TITLE == this.title) {
      this.router.navigate(['/master/divsion'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.TEAM_TITLE == this.title) {
      this.router.navigate(['/master/team'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.SMS_EMAIL_TITLE == this.title) {
      this.router.navigate(['/master/smsemailtemplate'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.APP_CONF_TITLE == this.title) {
      this.router.navigate(['/master/appconfig'], { queryParams: obj, skipLocationChange: false });
    } else if (ApiUrls.APP_PARAM_TITLE == this.title) {
      this.router.navigate(['/master/appParam'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.TRANS_DOC_TITLE == this.title) {
      this.router.navigate(['/master/transdoc'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.EXC_RATE_TITLE == this.title) {
      this.router.navigate(['/master/exchange'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.CUST_TITLE == this.title) {
      this.router.navigate(['/master/insured'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.CURRENCY_TITLE == this.title) {
      this.router.navigate(['/master/currency'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.BANK_TITLE == this.title) {
      this.router.navigate(['/master/bank'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.REPT_HEAD_TITLE == this.title) {
      this.router.navigate(['/master/report-heading'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.USER_MENU_TITLE == this.header) {
      this.router.navigate(['/master/menu'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.REPT_TEMP_TITLE == this.header) {
      this.router.navigate(['/master/enqReport'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.CUST_GROUP_TITLE == this.title) {
      this.router.navigate(['/master/appcodes'], { queryParams: obj, skipLocationChange: true });
    }

  }

  editMaster(data) {
    this.onSelect(data);
    this.loaderService.display(true);
    let obj = { 'path': this.page, 'action': 'edit', 'title': this.title, 'code': this.code, 'code1': this.code1, type: this.type }
    if (ApiUrls.ROLE_TITLE == this.title) {
      this.router.navigate(['/master/userRoles'], { queryParams: { "compCode": this.selectedId, 'title': this.title, 'path': this.page, 'action': 'edit' }, skipLocationChange: true });
    } else if (ApiUrls.USER_TITLE == this.title) {
      this.router.navigate(['/master/user'], { queryParams: { "userId": this.userId, 'title': this.title, 'path': this.page, 'action': 'edit' }, skipLocationChange: true });
      // this.router.navigate(['/master/user'], { queryParams: obj });
    } else if (ApiUrls.COMP_TITLE == this.title) {
      this.router.navigate(['/master/viewMasters'], { queryParams: { "compCode": this.compCode, 'title': this.title, 'path': this.page, 'action': 'edit' }, skipLocationChange: true });
      //this.router.navigate(['/master/company'], { queryParams: obj });
    } else if (ApiUrls.DIVN_TITLE == this.title) {
      this.router.navigate(['/master/divsion'], { queryParams: { "divnCode": this.selectedId, 'path': this.page, 'title': this.title, 'divnCompCode': this.divnCompCode, 'action': 'edit' }, skipLocationChange: true });
      //this.router.navigate(['/master/depart'], { queryParams: obj });
    } else if (ApiUrls.SMS_EMAIL_TITLE == this.title) {
      this.router.navigate(['/master/smsemailtemplate'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.TEAM_TITLE == this.title) {
      this.router.navigate(['/master/team'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.APP_CONF_TITLE == this.title) {
      this.router.navigate(['/master/appconfig'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.APP_PARAM_TITLE == this.title) {
      this.router.navigate(['/master/appParam'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.DEPT_TITLE == this.title) {
      this.router.navigate(['/master/depart'], { queryParams: { "deptCode": this.selectedId, 'path': this.page, 'deptCompCode': this.deptCompCode, 'deptDivnCode': this.deptDivnCode, 'title': this.title, 'deptCostCode': this.deptCostCode, 'action': 'edit' }, skipLocationChange: true });
      // this.router.navigate(['/master/team'], { queryParams: { "teamCode": this.selectedId, 'path': this.page, 'action': 'edit' }, skipLocationChange: true });
    } else if (ApiUrls.COST_CENT_TITLE == this.title) {
      this.router.navigate(['/master/cost'], { queryParams: { "costCode": this.selectedId, 'path': this.page, 'costCompCode': this.costCompCode, 'costDivCode': this.costDivCode, 'title': this.title, 'action': 'edit' }, skipLocationChange: true });
    } else if (ApiUrls.TRANS_DOC_TITLE == this.title) {
      this.router.navigate(['/master/transdoc'], { queryParams: { "docType": this.docType, 'path': this.page, 'compCode': this.compCode, 'code': this.code, "year": this.code1, 'action': 'edit' }, skipLocationChange: true });
    } else if (ApiUrls.EXC_RATE_TITLE == this.title) {
      this.router.navigate(['/master/exchange'], { queryParams: { "instId": this.selectedId, 'path': this.page, 'effFromDate': this.code, 'title': this.title, 'effToDate': this.code1, "currFrmCode": this.code2, 'currToCode': this.code3, "rateFor": this.code4, 'action': 'edit' }, skipLocationChange: true });
    } else if (ApiUrls.CURRENCY_TITLE == this.title) {
      this.router.navigate(['/master/currency'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.CUST_TITLE == this.title) {
      let obj = { 'path': this.page, 'action': 'edit', 'title': this.title, 'custCode': this.custCode }
      this.router.navigate(['/master/insured'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.REPT_TITLE == this.title) {
      this.router.navigate(['/master/report-heading'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.BANK_TITLE == this.title) {
      this.router.navigate(['/master/bank'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.REPT_HEAD_TITLE == this.title) {
      this.router.navigate(['/master/report-heading'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.USER_MENU_TITLE == this.header) {
      this.router.navigate(['/master/menu'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.REPT_TEMP_TITLE == this.header) {
      this.router.navigate(['/master/enqReport'], { queryParams: obj, skipLocationChange: true });
    } else if (ApiUrls.CUST_GROUP_TITLE == this.title) {
      this.router.navigate(['/master/appcodes'], { queryParams: obj, skipLocationChange: true });
    }
  }

  onSelect(event) {
    this.enableEdit = false;
    if (ApiUrls.COMP_TITLE == this.title) {
      this.compCode = event.compCode;
      // this.isShowEditFlg= true;
    } else if (ApiUrls.USER_TITLE == this.title) {
      this.userId = event.userPK.userId;
      // this.isShowEditFlg= true;
    } else if (ApiUrls.DIVN_TITLE == this.title) {
      this.selectedId = event.divisionPK.divnCode;
      this.divnCompCode = event.divisionPK.divnCompCode;
      //this.isShowEditFlg= true;
    } else if (ApiUrls.DEPT_TITLE == this.title) {
      this.selectedId = event.departmentPK.deptCode;
      this.deptCompCode = event.departmentPK.deptCompCode;
      this.deptDivnCode = event.departmentPK.deptDivnCode;
      this.deptCostCode = event.departmentPK.deptCostCode;
      // this.isShowEditFlg= true;
    } else if (ApiUrls.ROLE_TITLE == this.title) {
      this.selectedId = event.muserRolesPK.urId;
      //   this.isShowEditFlg= true;
    } else if (ApiUrls.TEAM_TITLE == this.title) {
      this.code = event.teamCode;
      //this.isShowEditFlg= true;
    } else if (ApiUrls.COST_CENT_TITLE == this.title) {
      this.selectedId = event.costCentrePK.costCode;
      this.costCompCode = event.costCentrePK.costCompCode;
      this.costDivCode = event.costCentrePK.costDivCode;
      // this.isShowEditFlg= true;
    } else if (ApiUrls.SMS_EMAIL_TITLE == this.title) {
      this.code = event.smtTempCode;
      // this.isShowEditFlg= true;
    } else if (ApiUrls.TEAM_TITLE == this.title) {
      this.code = event.data.teamCode;
    } else if (ApiUrls.APP_CONF_TITLE == this.title) {
      this.code = event.acName;
      //this.isShowEditFlg= true;
    } else if (ApiUrls.APP_PARAM_TITLE == this.title) {
      this.code = event.mappParameterPK.paraCode;
      this.code1 = event.mappParameterPK.paraSubCode;
      // this.isShowEditFlg= true;
    }
    else if (ApiUrls.CURRENCY_TITLE == this.title) {
      this.code = event.currCode;
    }
    else if (ApiUrls.REPT_TITLE == this.title) {

      this.code = event.mrepHeadingsPK.rhRepId;
      this.code1 = event.mrepHeadingsPK.rhCompCode;

    } else if (ApiUrls.TRANS_DOC_TITLE == this.title) {
      this.docType = event.mtranDocNoPK.tdnDocType
      this.compCode = event.mtranDocNoPK.tdnCompCode
      this.code = event.mtranDocNoPK.tdnCode
      this.code1 = event.mtranDocNoPK.tdnYear
    } else if (ApiUrls.CUST_TITLE == this.title) {
      this.custCode = event.customerPK.custCode;

    } else if (ApiUrls.EXC_RATE_TITLE == this.title) {
      this.selectedId = event.exchangeRatePK.erInstId
      this.code = event.exchangeRatePK.erEffFrmDt
      this.code1 = event.exchangeRatePK.erEffToDt
      this.code2 = event.erCurrFrmCode
      this.code3 = event.erCurrToCode
      this.code4 = event.erRatefor
    } else if (ApiUrls.BANK_TITLE == this.title) {
      this.code = event.bankCode;

    } else if (ApiUrls.REPT_LOG == this.title) {
      this.selectedId = event.repSrNo
      this.code = event.repId
      this.code1 = event.repCrUid
      this.code2 = event.repCrDt
    } else if (ApiUrls.REPT_HEAD_TITLE == this.title) {

      this.code = event.mrepHeadingsPK.rhRepId;
      this.code1 = event.mrepHeadingsPK.rhCompCode;

    } else if (ApiUrls.USER_MENU_TITLE == this.header) {
      this.code = event.mmenuPK.menuInstId
      this.code1 = event.mmenuPK.menuId
    } else if (ApiUrls.REPT_TEMP_TITLE == this.header) {
      this.code = event.erId;
    } else if (ApiUrls.CUST_GROUP_TITLE == this.title) {
      this.code = event.acId;
    }
    else {
      this.code = event.compCode;
    }

  }



  showDialogToAdd(mastername) {
    if (ApiUrls.ROLE_TITLE == mastername) {
      this.userRoleMaster = true;
      this.createUserRolefrm();
    }
    this.displayDialog = true;
  }


  createUserRolefrm() {
    this.userRoleFrm = this.fb.group({
      urId: ['', Validators.required],
      urDesc: ['', Validators.required],
      urBlDesc: '',
      urDashBoard: ''
    })

  }
  createTranDocfrm() {
    this.transDocSrchFrm = this.fb.group({
      transDocType: ['all',],
    })

  }
  createCustomerFrm() {
    this.customerFrm = this.fb.group({
      custCodeHidden: "",
      custCode: "",
      category: "",
      groupCode: "",
      insId: this.authService.getInstanceCode()
    })
  }

  save(data: any) {

  }

  edit(mastername: any) {
    let obj;
    if ("SMS/Email" == mastername) {
      obj = { key: "template_code", value: this.template_code }
      this.globalService.getSelectedById(obj, this.page).subscribe(result => {
        this.smsEmailTemplateFrm.patchValue({
          template_code: result.template_code,
          description: result.description,
          emailto: result.emailto,
          emailfrom: result.emailfrom,
          emailsubject: result.emailsubject,
          emailbody: result.emailbody,
          smstext: result.smstext,
          emailcc: result.emailcc,
        });

      }, error => {
      });
    }

  }




  back() {
    this.displayDialog = false;

  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
<<<<<<< HEAD
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
=======
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }


  cancel() {
    this.displayDialog = false;
    this.loaderService.display(true);
    this.router.navigate(['/master'], { queryParams: { "flag": true, "title": "UserRole Master", "path": "userRoles" }, skipLocationChange: true });
  }

  loadTransDocGrid() {
<<<<<<< HEAD
    let data = this.transDocSrchFrm['controls']['transDocType'].value;
=======
    let data = this.transDocSrchFrm.controls['transDocType'].value;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.loaderService.display(true);
    this.globalService.retrieveTranDocList(data, this.page).subscribe(resp => {
      this.details = resp.list;
      //this.scriptcall();
      this.searchCall();
      this.loaderService.display(false);
    }, error => {
      this.loaderService.display(false);
      this.errorMsg = error.error.message;
    });
  }

  createExchRatefrm() {
    this.exchRateFrm = this.fb.group({
      erRateFor: '',
      erConvFmCurrCode: '',
      erEffFrmDt: ''
    });

  }


  searchExchRate() {
    this.loaderService.display(true);
    // this.globalService.searchExchRateById(this.exchRateFrm.value, this.page).subscribe(resp => {
    //  this.loaderService.display(false);
    //   this.details = resp.list;
    //   this.searchCall();
    // })

  }

  createReprtFrm() {
    this.reprtLogFrm = this.fb.group({
      repId: '',
      repUser: '',
      repDate: ''
    })
  }

  searchRepLog() {
    this.showlog = false;
    this.reportService.searchReportLogById(this.reprtLogFrm.value, this.page).subscribe(resp => {
      this.details = resp.list;
      this.scriptcall();
    })

  }

  createReportLog() {
    this.reportLogFrm = this.fb.group({
      repValue1: '',
      repValue2: '',
      repValue3: '',
      repValue4: '',
      repValue5: '',
      repValue6: '',
      repValue7: '',
      repValue8: '',
      repValue9: '',
      repValue10: '',
      repValue11: '',
      repValue12: '',
      repValue13: '',
      repValue14: '',
      repValue15: '',
      repValue16: '',
      repValue17: '',
      repValue18: '',
      repValue19: '',
      repValue20: '',
      repValue21: '',
      repValue22: '',
      repValue23: '',
      repValue24: '',
      repValue25: '',
      repValue26: '',
      repValue27: '',
      repValue28: '',
      repValue29: '',
      repValue30: '',
      repValue31: '',
      repValue32: '',
      repValue33: '',
      repValue34: '',
      repValue35: '',
      repValue36: '',
      repValue37: '',
      repValue38: '',
      repValue39: '',
      repValue40: '',
      repValue41: '',
      repValue42: '',
      repValue43: '',
      repValue44: '',
      repValue45: '',
      repValue46: '',
      repValue47: '',
      repValue48: '',
      repValue49: '',
      repValue50: '',
      rhCrDt: new Date(),
      rhCrUid: this.session.get('userId')
    })
  }


  viewMaster(event) {
    this.selectedId = event.repSrNo
    this.createReportLog();
    let data = {
      "repSrNo": this.selectedId,
    }
    this.loaderService.display(true);
    this.reportService.retrieveReportLogById(data, this.page).subscribe(resp => {
      this.repLogList = resp;
      this.scriptcall();
      if (this.repLogList != null) {
        this.showlog = true;
        this.onlyRead = true;
        this.loaderService.display(false);
      }

      this.reportLogFrm.patchValue({
        repValue1: this.repLogList[0].repValue1,
        repValue2: this.repLogList[0].repValue2,
        repValue3: this.repLogList[0].repValue3,
        repValue4: this.repLogList[0].repValue4,
        repValue5: this.repLogList[0].repValue5,
        repValue6: this.repLogList[0].repValue6,
        repValue7: this.repLogList[0].repValue7,
        repValue8: this.repLogList[0].repValue8,
        repValue9: this.repLogList[0].repValue9,
        repValue10: this.repLogList[0].repValue10,
        repValue11: this.repLogList[0].repValue11,
        repValue12: this.repLogList[0].repValue12,
        repValue13: this.repLogList[0].repValue13,
        repValue14: this.repLogList[0].repValue14,
        repValue15: this.repLogList[0].repValue15,
        repValue16: this.repLogList[0].repValue16,
        repValue17: this.repLogList[0].repValue17,
        repValue18: this.repLogList[0].repValue18,
        repValue19: this.repLogList[0].repValue19,
        repValue20: this.repLogList[0].repValue20,
        repValue21: this.repLogList[0].repValue21,
        repValue22: this.repLogList[0].repValue22,
        repValue23: this.repLogList[0].repValue23,
        repValue24: this.repLogList[0].repValue24,
        repValue25: this.repLogList[0].repValue25,
        repValue26: this.repLogList[0].repValue26,
        repValue27: this.repLogList[0].repValue27,
        repValue28: this.repLogList[0].repValue28,
        repValue29: this.repLogList[0].repValue29,
        repValue30: this.repLogList[0].repValue30,
        repValue31: this.repLogList[0].repValue31,
        repValue32: this.repLogList[0].repValue32,
        repValue33: this.repLogList[0].repValue33,
        repValue34: this.repLogList[0].repValue34,
        repValue35: this.repLogList[0].repValue35,
        repValue36: this.repLogList[0].repValue36,
        repValue37: this.repLogList[0].repValue37,
        repValue38: this.repLogList[0].repValue38,
        repValue39: this.repLogList[0].repValue39,
        repValue40: this.repLogList[0].repValue40,
        repValue41: this.repLogList[0].repValue41,
        repValue42: this.repLogList[0].repValue42,
        repValue43: this.repLogList[0].repValue43,
        repValue44: this.repLogList[0].repValue44,
        repValue45: this.repLogList[0].repValue45,
        repValue46: this.repLogList[0].repValue46,
        repValue47: this.repLogList[0].repValue47,
        repValue48: this.repLogList[0].repValue48,
        repValue49: this.repLogList[0].repValue49,
        repValue50: this.repLogList[0].repValue50,
      });
    })

  }

  viewApplMenu(value) {
    this.loaderService.display(true);
    this.userRoleId = value;
    this.userService.getUserRoleMenusById(value, ApiUrls.MENU_USER_ROLE_CONTROLLER_PATH).subscribe(result => {
      this.selectedMenuList = result.list;
      this.getMenuList();

    }, error => {
    });
  }

  getMenuList() {
    this.userService.getMenuList(ApiUrls.USER_CONTROLLER_PATH).subscribe(result => {
      this.menuList = result.menulist;
      for (var i = 0; i < this.menuList.length; i++) {
        for (var j = 0; j < this.selectedMenuList.length; j++) {
          if (this.menuList[i].menuId == this.selectedMenuList[j]) {
            this.menuList[i].flag = true;
          }
          for (var k = 0; k < this.menuList[i].msubmenu.length; k++) {
            if (this.menuList[i].msubmenu[k].menuId == this.selectedMenuList[j]) {
              this.menuList[i].msubmenu[k].flag = true;
            }
          }
        }
      }
      this.loaderService.display(false);
<<<<<<< HEAD
=======
      console.log("===" + JSON.stringify(result.menulist));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.open(this.content, 'modal-md');
    }, error => {
    });
  }

  checkenable(event, menuId) {
    if (event.target.checked == true) {
      this.selectedMenuList.push(menuId);
    } else {
      var index = this.selectedMenuList.indexOf(menuId);
      this.selectedMenuList.splice(index, 1)
    }
  }

  close() {
    this.loaderService.display(true);
    let param = {
      'urInstId': this.authService.getInstanceCode(),
      'urId': this.userRoleId
    }
    let data = {
      'roleId': this.userRoleId,
      'selectedMenuIds': this.selectedMenuList,
      'urCrUid': this.session.get("userId"),
      'urCrDt': new Date()

    }

    this.userService.saveUserRoleMenus(data, ApiUrls.MENU_USER_ROLE_CONTROLLER_PATH).subscribe(result => {
<<<<<<< HEAD
=======
      console.log("Success...");
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.loaderService.display(false);
      let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
      element.click();
    }, error => {
      this.loaderService.display(false);
    });




  }

  searchCustomer() {
    this.loaderService.display(true);
    let obj = this.customerFrm.get('custCodeHidden').value;
    this.customerFrm.patchValue({
      custCode: obj.key
    });
    this.customerService.filterCustomerDetails(this.customerFrm.value, this.page).subscribe(resp => {
      this.details = resp;
      this.scriptcall();
      this.loaderService.display(false);
    })
  }

  filteredList(event) {
    let custCode = event.query;
    this.customerService.customerDropDownList(custCode, this.page).subscribe(resp => {
      this.filteredCustomerList = resp;
    });
  }
  deleteMaster(data: any) {
  }


<<<<<<< HEAD
  open(content, val) {
    this.modalService.show(content, { class: val });
=======
  open(content,val) {
    this.modalService.show(content, { class: val });    
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  closeModal() {
    this.modalService.hide();
  }
  addRepLookUp(path: string) {
    let obj = { 'path': path, 'action': 'add', type: this.type }
    this.router.navigate(['/master/enqRepLookup'], { queryParams: obj, skipLocationChange: true });
  }

  editRepLook(event: any) {
    this.code = event.elkId;
    let obj = { 'path': 'reportTemp', 'action': 'edit', 'code': this.code, type: this.type }
    this.router.navigate(['/master/enqRepLookup'], { queryParams: obj, skipLocationChange: true });
  }



  scriptcall() {
    // $('#qic-table').DataTable().destroy();
    // setTimeout(() => {
    //   $('#qic-table').DataTable({ "order": [] }).draw();
    // }, 500);

  }

  searchCall() {
    // $('#qic-table').DataTable().destroy();
    // setTimeout(() => {
    //   $('#qic-table').DataTable({ "order": [] }).draw();
    // }, 500);

  }


  scriptcall2() {
    // $('#qic-table2').DataTable().destroy();
    // setTimeout(() => {
    //   $('#qic-table2').DataTable({ "order": [] }).draw();
    // }, 500);
  }

  scriptcall3() {
    // $('#qic-table3').DataTable().destroy();
    // setTimeout(() => {
    //   $('#qic-table3').DataTable({ "order": [] }).draw();
    // }, 500);
  }
  scriptcall4() {
    // $('#qic-table4').DataTable().destroy();
    // setTimeout(() => {
    //   $('#qic-table4').DataTable({ "order": [] }).draw();
    // }, 500);
  }



  ngAfterViewInit() {

    // $('.selectpicker').selectpicker();
    // setTimeout(() => {
    //   $('.selectpicker').selectpicker('refresh');
    // }, 500);
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");

      switch (actionType) {
        case "Edit":
          return this.editMaster(data)
      }
    }

  }
}

