import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
<<<<<<< HEAD
import { SessionStorageService } from 'angular-web-storage';
=======
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { LoaderServiceService } from 'src/app/shared/Loader-service/loader-service.service';
import { SessionStorageService } from 'angular-web-storage';
import { GlobalService } from 'src/app/shared/services/global.service';
import { LoaderService } from 'src/app/services/loader.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { GlobalService } from 'src/app/shared/services/global.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
})

export class AdminDashboardComponent implements OnInit {

<<<<<<< HEAD
=======
  title: any;
  CompTheme: any;
  action: string;
  compCode: any;
  deptCostCode: any;
  deptDivnCode: any;
  deptCompCode: any;
  divnCompCode: any;
  costDivCode: any;
  costCompCode: any;
  costCols: any[];
  teamCols: any[];
  userRoleInfo = [];
  userRoleCols: any[];
  selectedId: any;
  departCols: any[];
  diviCode: any;
  divCols: any[];
  compCols: any[];
  userCols: any[];
  appParamCols: any[];
  header: any;
  page: any;
  userRoleFrm: UntypedFormGroup;
  smsEmailTemplateFrm: UntypedFormGroup;
  displayDialog: boolean;
  newCar: boolean;
  cars: any = [];
  compDetail: any = [];
  loading: boolean;
  userInfo: any = [];
  isShowUserMaster: boolean = false;
  isShowflag: boolean = false;
  compInfo: any = [];
  code: any;
  code1: any;
  disableFlag: boolean = true;
  totalRecords: number;
  tableColumns: any[];
  smsemailmaster: boolean;
  userRoleMaster: boolean;
  smsEmailCols: any[];
  appConfig: any[];
  appCodes: any[];
  details: Array<any>;
  template_code: any;
  editFlag: boolean;
  paraCode: string;
  paraSubCode: string;
  //isShowEditFlg :boolean=false;
  enableEdit: boolean = true;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  roleId: String;
  menuList: any[];
  welcomeModal: boolean = false;

  constructor(
    private router: Router,
    private session: SessionStorageService,
    private commonService: CommonService,
    private globalService: GlobalService,
<<<<<<< HEAD
=======
    private fb: UntypedFormBuilder,
    private session:SessionStorageService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private loaderService: LoaderService,
    private toastService: ToastService
    ) {

  }

  ngOnInit() {
    setTimeout(() => { this.loaderService.isBusy = true; }, 0);
    //this.loaderService.isBusy = true;
    this.roleId = this.session.get('roleId');
    this.welcomeModal = this.globalService.getParamValue('page') == "welcome" ? true : false;
    let obj = {
      user: this.session.get('roleId'),
      role: this.session.get('roleId')
    }
    this.commonService.getDasboardMenus(obj).subscribe(res => {
      this.menuList = res.menulist;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error('Error');
      this.loaderService.isBusy = false;
    });
  }

  loadDetails(title, path, type) {
<<<<<<< HEAD
    this.router.navigate([path], { queryParams: { "flag": true, "title": title }, queryParamsHandling: 'merge', });
=======

    // if(title ==='Report Template'){
    //   this.router.navigate(['/master/enqReport'], { queryParams: { "flag": true, "title": title}}); 
    // }else{
    this.router.navigate([path], { queryParams: { "flag": true, "title": title }, queryParamsHandling: 'merge', });
    // }

    /* if (ApiUrls.HISTORY_LOG_TITLE == title || ApiUrls.SMS_TITLE == title || ApiUrls.DOCUMENT_PRINT_TITLE == title || ApiUrls.LOGIN_HISTORY_TITLE == title || ApiUrls.EMAIL_TITLE == title) {
       this.router.navigate(['/master/logs'], { queryParams: { "flag": true, "title": title, "path": path, "type": type }, skipLocationChange: true });
     } else if (ApiUrls.APP_CODE_TITLE == title) {
       console.log(path, "2");
       this.router.navigate(['/master/app-codes'], { queryParams: { "flag": true, "title": title, "path": path, "type": type.toUpperCase() }, skipLocationChange: true });
     }
     else if (ApiUrls.CUST_CATE_TITLE == title) {
       console.log(path, "3");
       this.router.navigate(['/master/cust-category'], { queryParams: { "flag": true, "title": title, "path": path, "type": type }, skipLocationChange: true });
     }
     else if (ApiUrls.ORG_SETUP_TITLE == title) {
       console.log(path, "4");
       this.router.navigate(['/appSetup/orgstructure'], { queryParams: { "flag": true, "title": title, "path": path, "type": type }, skipLocationChange: true });
     } else {
       console.log(title, path, type)
       this.router.navigate(['/master'], { queryParams: { "flag": true, "title": title, "path": path, "type": type.toUpperCase() }, skipLocationChange: false });
     }*/
    this.loaderService.isBusy = false;

  }

  updateFirstLoginFlag() {
    this.welcomeModal = false;
    this.globalService.updateFirstLoginFlag(this.session.get("userId")).subscribe(result => {

    })
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
}
