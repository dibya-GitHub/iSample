import { AgGridModule } from '@ag-grid-community/angular';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FileUploadModule } from "ng2-file-upload";
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ChartModule } from 'primeng/chart';
import { EditorModule } from 'primeng/editor';
import { InputNumberModule } from 'primeng/inputnumber';
import { SharedModule } from 'src/shared/shared.module';
import { MgaAdjustmentLevyComponent } from './components/mga-adjustment-levy/mga-adjustment-levy.component';
import { MgaAmendHistoryComponent } from './components/mga-amend-history/mga-amend-history.component';
import { MgaBusinessRulesComponent } from './components/mga-business-rules/mga-business-rules.component';
import { MgaCodeMappingComponent } from './components/mga-code-mapping/mga-code-mapping.component';
import { MgaCoinsuranceDemoComponent } from './components/mga-coinsurance-demo/mga-coinsurance-demo.component';
import { NumericEditorComponent } from './components/mga-coinsurance-demo/numeric-editor.component';
import { MgaCompanyLobComponent } from './components/mga-company-lob/mga-company-lob.component';
import { MgaContractDashboardComponent } from './components/mga-contract-dashboard/mga-contract-dashboard.component';
import { MgaContractInfoComponent } from './components/mga-contract-info/mga-contract-info.component';
import { MgaContractualTermComponent } from './components/mga-contractual-term/mga-contractual-term.component';
import { MgaEditviewrenderComponent } from './components/mga-editviewrender/mga-editviewrender.component';
import { MgaEpiComponent } from './components/mga-epi/mga-epi.component';
import { MgaOutwardReinsuranceComponent } from './components/mga-outward-reinsurance/mga-outward-reinsurance.component';
import { MgaProductionSummaryComponent } from './components/mga-production-summary/mga-production-summary.component';
import { MgaTaAccountingCreateComponent } from './components/mga-ta-accounting-create/mga-ta-accounting-create.component';
import { MgaTaAccountingComponent } from './components/mga-ta-accounting/mga-ta-accounting.component';
import { MgaTermsDemoComponent } from './components/mga-terms-demo/mga-terms-demo.component';
import { MgaViewAccountingComponent } from './components/mga-view-accounting/mga-view-accounting.component';
import { MgaWizardFlowComponent } from './components/mga-wizard-flow/mga-wizard-flow.component';
import { MgaWizardComponent } from './components/mga-wizard/mga-wizard.component';
import { RadiorenderComponent } from './components/radiorender/radiorender.component';
import { RadiorenderComponent2 } from './components/radiorender/radiorender2.component';
import { RadiorenderComponent3 } from './components/radiorender/radiorender3.component';
import { RadiorenderComponent4 } from './components/radiorender/radiorender4.component';
import { ViewContractComponent } from './components/view-contract/view-contract.component';
import { MgaContractRoutingModule } from './mga-contract-routing.module';
import { DropdownModule } from 'primeng/dropdown';
import { MgaTaAccountingViewComponent } from './components/mga-ta-accounting-view/mga-ta-accounting-view.component';
// import { MgaCoinsExpensesComponent } from './components/mga-coinsurance-next/mga-coins-expenses/mga-coins-expenses.component';
// import { MgaCoinsuranceNextComponent } from './components/mga-coinsurance-next/mga-coinsurance-next.component';

@NgModule({
  imports: [
    CommonModule,
    MgaContractRoutingModule,
    SharedModule,
    AgGridModule.withComponents([RadiorenderComponent, RadiorenderComponent2, RadiorenderComponent3, RadiorenderComponent4, MgaEditviewrenderComponent, NumericEditorComponent]),
    TabsModule.forRoot(),
    FileUploadModule,
    InputNumberModule,
    EditorModule,
    ChartModule,
    DropdownModule
  ],
  declarations: [
    MgaContractDashboardComponent,
    MgaContractInfoComponent,
    MgaWizardComponent,
    RadiorenderComponent,
    RadiorenderComponent2,
    RadiorenderComponent3,
    RadiorenderComponent4,
    MgaCompanyLobComponent,
    MgaOutwardReinsuranceComponent,
    MgaEpiComponent,
    MgaBusinessRulesComponent,
    ViewContractComponent,
    MgaAmendHistoryComponent,
    MgaWizardFlowComponent,
    MgaProductionSummaryComponent,
    MgaTaAccountingComponent,
    MgaTaAccountingCreateComponent,
    MgaEditviewrenderComponent,
    MgaViewAccountingComponent,
    MgaCodeMappingComponent,
    MgaTermsDemoComponent,
    MgaCoinsuranceDemoComponent,
    MgaAdjustmentLevyComponent,
    NumericEditorComponent,
    MgaContractualTermComponent,
    MgaTaAccountingViewComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MgaContractModule { }
