import { MgaContractModule } from './mga-contract.module';

describe('MgaContractModule', () => {
  let mgaContractModule: MgaContractModule;

  beforeEach(() => {
    mgaContractModule = new MgaContractModule();
  });

  it('should create an instance', () => {
    expect(mgaContractModule).toBeTruthy();
  });
});
