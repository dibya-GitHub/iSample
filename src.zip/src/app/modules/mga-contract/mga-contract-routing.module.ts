import { MgaTaAccountingViewComponent } from './components/mga-ta-accounting-view/mga-ta-accounting-view.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MgaAdjustmentLevyComponent } from './components/mga-adjustment-levy/mga-adjustment-levy.component';
import { MgaAmendHistoryComponent } from './components/mga-amend-history/mga-amend-history.component';
import { MgaCodeMappingComponent } from './components/mga-code-mapping/mga-code-mapping.component';
import { MgaContractDashboardComponent } from './components/mga-contract-dashboard/mga-contract-dashboard.component';
import { MgaProductionSummaryComponent } from './components/mga-production-summary/mga-production-summary.component';
import { MgaTaAccountingCreateComponent } from './components/mga-ta-accounting-create/mga-ta-accounting-create.component';
import { MgaTaAccountingComponent } from './components/mga-ta-accounting/mga-ta-accounting.component';
import { MgaViewAccountingComponent } from './components/mga-view-accounting/mga-view-accounting.component';
import { MgaWizardComponent } from './components/mga-wizard/mga-wizard.component';
import { ViewContractComponent } from './components/view-contract/view-contract.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'mga-dashboard',
    pathMatch: 'full'
  },
  {
    path: 'mga-dashboard',
    component: MgaContractDashboardComponent,
    data: {
      breadcrumb: { skip: true }
    }
  },
  {
    path: 'mga-wizard',
    component: MgaWizardComponent,
    data: {
      breadcrumb: 'Contract Info'
    },
  },
  {
    path: 'mga-view-contract',
    component: ViewContractComponent,
    data: {
      breadcrumb: 'View Contract',
    },
  },
  {
    path: 'mga-amend-history',
    component: MgaAmendHistoryComponent,
    data: {
      breadcrumb: 'Contract Information',
    },
  },
  {
    path: 'mga-landing-page',
    component: MgaProductionSummaryComponent,
    data: {
      breadcrumb: 'Production Summary',
    },
  },
  {
    path: 'mga-ta-accounting',
    component: MgaTaAccountingComponent,
    data: {
      breadcrumb: 'Technical Accounting',
    },
  },
  {
    path: 'mga-ta-accounting-create',
    component: MgaTaAccountingCreateComponent,
    data: {
      breadcrumb: 'Technical Accounting',
    },
  },
  {
    path: 'mga-view-accounting',
    component: MgaViewAccountingComponent,
    data: {
      breadcrumb: 'View Accounting',
    },
  },
  {
    path: 'mga-ta-accounting-view',
    component: MgaTaAccountingViewComponent,
    data: {
      breadcrumb: 'Advanced Search',
    },
  },
  
  {
    path: 'mga-code-mapping',
    component: MgaCodeMappingComponent,
    data: {
      breadcrumb: 'Mga Code Mapping',
    },
  },
  {
    path: 'mga-adjustment-levy',
    component: MgaAdjustmentLevyComponent,
    data: {
      breadcrumb: 'Mga Adjustment Levy',
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MgaContractRoutingModule { }
