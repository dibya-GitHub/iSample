import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { zip } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaEditviewrenderComponent } from '../mga-editviewrender/mga-editviewrender.component';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'mga-epi',
  templateUrl: './mga-epi.component.html',
  styleUrls: ['./mga-epi.component.scss']
})
export class MgaEpiComponent implements OnInit, AfterViewInit {

  mgaEpiForm: UntypedFormGroup;
  epiList: any = [];
  AddFlag: boolean = true;
  showForm: boolean = false;
  userId: string = this.session.get('userId');
  baseCurrency: any
  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() amendSrNo: string;
  @Input() action: string;
  @Input() seqNo: number;
  @Input() contractType: string;
  @Input() status: string;
  @Input() lobSrNo: any;
  @Input() lobInfo: any;
  @Input() passedData: any;

  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;

  lobEpiList: any = [];
  regions: any[];
  currencyList: any;
  editLobEpi: any;
  temp: any;
  closeResult: string;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  buyRate1: any;
  buyRate2: any;
  buyRate3: any;
  pinnedBottomRowData: any;
  modalRef: BsModalRef;
  @ViewChild('errorModal') errorModal: ElementRef;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private mgaService: MgaContractService,
    private modalService: BsModalService

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.baseCurrency = JSON.parse(sessionStorage.getItem('baseCurrencyCode'));
    console.log(this.baseCurrency);
    
  }

  ngOnInit() {
    this.columnDefs = [
      {
        headerName: "Region",
        headerTooltip: "Region",
        field: "beRegionCode",
        valueGetter: function (params) {
          if (params.data && params.data.beRegionCode && params.data.beRegionCodeDesc) {
            return params.data.beRegionCode + " - " + params.data.beRegionCodeDesc;
          } else {
            return '';
          }
        },
        width: 150,
      },
      {
        headerName: "Currency",
        headerTooltip: "Currency",
        field: "beCurrCode",
        valueGetter: function (params) {
          if (params.data && params.data.beCurrCode && params.data.beCurrCodeDesc) {
            return params.data.beCurrCode + " - " + params.data.beCurrCodeDesc;
          } else {
            return '';
          }
        },
        width: 150,
      },
      {
        headerName: "EPI",
        headerTooltip: "EPI",
        field: "beEpiFc",
        enableRowGroup: true,
        width: 150,
        cellStyle: { textAlign: 'right' },
        headerClass: "grid-cell-centered",
        valueGetter: function (params) {
          if (params && params.data && params.data.beEpiFc) {
            return Number(params.data.beEpiFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params && params.data && params.data.beEpiFc == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        headerName: "EPI in functional currency (" + this.baseCurrency.baseCurrency1 + ")",
        headerTooltip: "EPI in functional currency (" + this.baseCurrency.baseCurrency1 + ")",
        field: "beEpiLc1",
        cellStyle: { textAlign: 'right' },
        headerClass: "grid-cell-centered",
        width: 150,
        valueGetter: function (params) {
          if (params && params.data && params.data.beEpiLc1) {
            return Number(params.data.beEpiLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params && params.data && params.data.beEpiLc1 == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        headerName: 'Action',
        cellRendererFramework: MgaEditviewrenderComponent,
        cellStyle: { textAlign: 'center' },
        resizable: false,
        sortable: false,
        filter: false,
        width: 80,
        enableRowGroup: false,
      }
    ];
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      if (params.node.data != null)
        var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
    this.createEPIForm();
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.dynamicTabIndex();
    }, 500);
  }
  createEPIForm() {
    this.mgaEpiForm = this.fb.group({
      beRegionCode: ['', Validators.required],
      beCurrCode: ['', Validators.required],
      beEpiFc: ['', Validators.required],
      beEpiLc1: [''],
      beEpiLc2: [''],
      beEpiLc3: [''],
    })
    this.getMasterData();
  }

  getAllLOBEPIByRefId() {
    this.loaderService.isBusy = true;
    this.mgaService.getLOBEPIbyRefNoSrNo(this.refNo, this.seqNo, this.amendNo, this.lobSrNo).subscribe(resp => {
      this.lobEpiList = resp;
      if (this.lobEpiList) {
        this.pinnedBottomRowData = createData(1, this.lobEpiList, "Bottom");
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getMasterData() {
    this.loaderService.isBusy = true;
    zip(
      this.mgaService.getRegions(),
      this.mgaService.getCurrencyAppCode(),
    ).subscribe(([regions, currencies]) => {
      // this.regions = regions;
      this.regions = (regions as any).map(region => {
        region.displayText = region.code + ' - ' + region.description;
        return region;
      });
      this.currencyList = (currencies as any).map(currency => {
        currency.displayText = currency.currCode + ' - ' + currency.currName;
        return currency;
      });
      this.loaderService.isBusy = false;
    }, err => {
      this.loaderService.isBusy = false;
    })
    this.getAllLOBEPIByRefId();
  }

  addEpiInfo() {
    this.mgaEpiForm.reset();
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'add';
    this.dynamicTabIndex();
  }

  back() {
    this.showForm = false;
    this.AddFlag = true;
    this.mgaEpiForm.reset();
  }
  onchangeCurrency(event) {
    this.loaderService.isBusy = true;
    let onDate = this.passedData.biStartDt;
    let fromCurrencyDate = event.value;
    forkJoin(
      this.mgaService.fetchExchangeRate(fromCurrencyDate, this.baseCurrency.baseCurrency1, onDate),
      this.mgaService.fetchExchangeRate(fromCurrencyDate, this.baseCurrency.baseCurrency2, onDate),
      this.mgaService.fetchExchangeRate(fromCurrencyDate, this.baseCurrency.baseCurrency3, onDate)
    ).subscribe((data: any) => {
      this.buyRate1 = (data[0] && data[0].buyRate) ? data[0].buyRate : 0;
      this.buyRate2 = (data[1] && data[1].buyRate) ? data[1].buyRate : 0;
      this.buyRate3 = (data[2] && data[2].buyRate) ? data[2].buyRate : 0;
      if (this.buyRate1 == 0) {
        this.toastService.warning("Exchange Rate is not Available for the Contract Year.");
      }
      this.onAmountEnter();
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.warning("Exchange Rate is not Available for the Contract Year.");
    })
    // this.mgaService.fetchExchangeRate(fromCurrencyDate, this.baseCurrency.baseCurrency1, onDate).subscribe((res: any) => {
    //   if (res && res.buyRate) {
    //     this.buyRate1 = res.buyRate;
    //   } else {
    //     this.buyRate1 = 0;
    //     this.toastService.warning("Exchange Rate is not Available for the Contract Year.")
    //   }
    //   this.onAmountEnter();
    // })
    // this.mgaService.fetchExchangeRate(fromCurrencyDate, this.baseCurrency.baseCurrency2, onDate).subscribe((res: any) => {
    //   if (res && res.buyRate) {
    //     this.buyRate2 = res.buyRate;
    //   } else {
    //     this.buyRate2 = 0;
    //     this.toastService.warning("Exchange Rate is not Available for the Contract Year.")
    //   }
    //   this.onAmountEnter();
    // })
    // this.mgaService.fetchExchangeRate(fromCurrencyDate, this.baseCurrency.baseCurrency3, onDate).subscribe((res: any) => {
    //   if (res && res.buyRate) {
    //     this.buyRate3 = res.buyRate;
    //   } else {
    //     this.buyRate3 = 0;
    //     this.toastService.warning("Exchange Rate is not Available for the Contract Year.")
    //   }
    //   this.onAmountEnter();
    // })
  }

  onAmountEnter() {
    const amount = this.mgaEpiForm.get('beEpiFc').value;
    this.calcAmount(amount, this.buyRate1, 'beEpiLc1');
    this.calcAmount(amount, this.buyRate2, 'beEpiLc2');
    this.calcAmount(amount, this.buyRate3, 'beEpiLc3');
  }
  calcAmount(amount, buyRate, epiLc) {
    const localCurrency = amount * buyRate;
    this.mgaEpiForm.get(epiLc).setValue(Number(localCurrency.toString()), { emitEvent: true });
  }

  saveForm(actionEPI) {
    this.loaderService.isBusy = true;
    if (this.mgaEpiForm.valid) {
      let mgaEpiData = this.mgaEpiForm.getRawValue();

      if (this.action == 'edit') {
        mgaEpiData.beUpdDt = new Date();
        mgaEpiData.beUpdUid = this.userId;
        mgaEpiData.beEpiLc1 = Number(mgaEpiData.beEpiLc1);
        mgaEpiData.beEpiLc2 = Number(mgaEpiData.beEpiLc2);
        mgaEpiData.beEpiLc3 = Number(mgaEpiData.beEpiLc3);
        mgaEpiData.beStatus = 'P';
        let obj = {
          binderLobEpiPK: this.editLobEpi,
        };
        Object.assign(mgaEpiData, obj);
        mgaEpiData = MgaUtils.clean(mgaEpiData);
        this.mgaService.updateLOBEPI(mgaEpiData, this.refNo, this.amendSrNo).subscribe((resp) => {
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp.message);
            this.loaderService.isBusy = false;
          } else {
            this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: mgaEpiData.binderLobEpiPK.beProdSrNo });
            this.toastService.success('Successfully Updated');
            this.getAllLOBEPIByRefId();
            this.showForm = false;
            this.AddFlag = true;
            this.loaderService.isBusy = false;
          }
        }, error => {
          if (error instanceof HttpErrorResponse) {
            if (error.error instanceof ErrorEvent) {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            } else {
              switch (error.status) {
                case 400:
                  this.loaderService.isBusy = false;
                  this.showErrorDialogBox(error.error.message);
                  this.modalService.hide();
                  break;
                default:
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in Updating!");
                  break;
              }
            }
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Updating!");
          }
        })

      } else {
        let obj = {
          binderLobEpiPK: {
            beAmendNo: this.amendNo,
            beProdSrNo: this.lobSrNo,
            beRefNo: this.refNo,
            beSeqNo: this.seqNo,
          },
          beCrDt: new Date(),
          beCrUid: this.userId,
          beStatus: 'P',
          beUpdDt: new Date(),
          beUpdUid: this.userId,
        };
        Object.assign(mgaEpiData, obj);
        mgaEpiData = MgaUtils.clean(mgaEpiData);
        mgaEpiData.beEpiLc2 = mgaEpiData.beEpiLc2;
        mgaEpiData.beEpiLc3 = mgaEpiData.beEpiLc3;
        if (actionEPI == 'save') {
          this.mgaService.saveLOBEPI(mgaEpiData).subscribe((resp) => {
            if (resp["messageType"] && resp["messageType"] == 'E') {
              this.toastService.error(resp.message);
              this.loaderService.isBusy = false;
            } else {
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: mgaEpiData.binderLobEpiPK.beProdSrNo });
              this.toastService.success('Successfully Saved');
              this.getAllLOBEPIByRefId();
              this.showForm = false;
              this.AddFlag = true;
              this.loaderService.isBusy = false;
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          })
        }
      }
    } else {
      MgaUtils.validateAllFormFields(this.mgaEpiForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  openModal(content, val) {
    this.modalRef = this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalRef.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.modalService.hide();
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    } else {
      this.gridOptions.api.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("mgaEPIGrid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.onActionEditLOBEpi(data);
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
  onActionEditLOBEpi(data: any) {
    this.loaderService.isBusy = true;
    this.action = 'edit';
    this.showForm = true;
    this.AddFlag = false;
    this.editLobEpi = data.binderLobEpiPK;
    this.mgaEpiForm.patchValue(data);
    this.dynamicTabIndex();
    this.loaderService.isBusy = false;
    this.onchangeCurrency({ value: data.beCurrCode });
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  showDialogbox(data: any) {
    this.temp = data.binderLobEpiPK;
    this.open(this.confirmModal, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  close() {
    this.modalService.hide();
  }
  deleteRow() {
    if (this.temp && this.temp.beRefNo && this.temp.beSrNo) {
      this.loaderService.isBusy = true;
      this.mgaService.deleteLOBEPI(this.temp.beRefNo, this.seqNo, this.amendNo, this.temp.beProdSrNo, this.temp.beSrNo).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully.');
        this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: this.temp.beProdSrNo });
        this.getAllLOBEPIByRefId();
        this.loaderService.isBusy = false;
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.modalService.hide();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        }
      })
    } else {
      this.toastService.error('Error in Deleting Data');
    }
  }

  dynamicTabIndex() {
    $(".page-link").attr("tabindex", "-1");
    $(".pagination-page.page-item.active.ng-star-inserted .page-link").attr("tabindex", "-1");
  }
}

function createData(count, data, prefix) {
  var result = [];
  var sum = 0;
  var sumbeEpiLc1 = 0;
  for (var i = 0; i < data.length; i++) {
    sum = sum + data[i].beEpiFc;
    sumbeEpiLc1 = sumbeEpiLc1 + data[i].beEpiLc1
  }
  for (var i = 0; i < count; i++) {
    result.push({
      beRegionCode: 'Total :',
      beEpiFc: sum,
      beEpiLc1: sumbeEpiLc1,
      beRegionCodeDesc: ''
    });
  }
  return result;
}
