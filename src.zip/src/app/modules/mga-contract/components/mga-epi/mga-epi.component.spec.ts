import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-epi/mga-epi.component.spec.ts
import { MgaEpiComponent } from './mga-epi.component';

describe('MgaEpiComponent', () => {
  let component: MgaEpiComponent;
  let fixture: ComponentFixture<MgaEpiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaEpiComponent ]
=======
import { NCBComponent } from './ncb.component';

describe('NCBComponent', () => {
  let component: NCBComponent;
  let fixture: ComponentFixture<NCBComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NCBComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/ncb/ncb.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-epi/mga-epi.component.spec.ts
    fixture = TestBed.createComponent(MgaEpiComponent);
=======
    fixture = TestBed.createComponent(NCBComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/ncb/ncb.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
