import { Component } from '@angular/core';
import { ICellRendererAngularComp } from '@ag-grid-community/angular';

@Component({
  selector: 'app-radiorender3',
  template: `<div *ngIf="canShow && params" style="display: block; text-align:center;">
  
  <input type="radio" name="groupname2" [value]="params.getValue()"
  [checked]="params.context.componentParent.selectedRowId1 === params.getValue()"
   (click)="invokeParentMethod($event)">
</div>`,
})
export class RadiorenderComponent3 implements ICellRendererAngularComp {
  public params: any;
  canShow: boolean;
  agInit(params: any): void {
    this.params = params;
    const value = this.params.getValue();
    if (this.params && this.params.data) {
      this.canShow = true;
    } else {
      this.canShow = false;
    }
  }

  public invokeParentMethod(e) {
    let header = this.params.colDef.headerName;
    if ('Select' == header) {
      if (this.params.context.selectedRow) {
        this.params.context.selectedRow(this.params);
      } else {
        this.params.context.componentParent.selectedRow(this.params)
      }
    } else if ('layer' == header) {
      this.params.context.componentParent.selectedRow(e, this.params)
    } else {
      this.params.context.componentParent.selectedRow(this.params)
      this.params.context.componentParent.showInstal(e, this.params)
    }
  }
  refresh(): boolean {
    return false;
  }
}
