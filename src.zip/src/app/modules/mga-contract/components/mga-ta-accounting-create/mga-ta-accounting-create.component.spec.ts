import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaTaAccountingCreateComponent } from './mga-ta-accounting-create.component';

describe('MgaTaAccountingCreateComponent', () => {
  let component: MgaTaAccountingCreateComponent;
  let fixture: ComponentFixture<MgaTaAccountingCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaTaAccountingCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MgaTaAccountingCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
