import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as _ from 'lodash';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { MgaContractService } from 'src/app/modules/mga-contract/services/mga-contract.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { MgaDocumentsComponent } from 'src/shared/components/mga-documents/mga-documents.component';
import { MgaUtils } from './../mga-utils';
@Component({
  selector: 'mga-ta-accounting-create',
  templateUrl: './mga-ta-accounting-create.component.html',
  styleUrls: ['./mga-ta-accounting-create.component.scss']
})
export class MgaTaAccountingCreateComponent implements OnInit, AfterViewInit {

  @ViewChild(MgaDocumentsComponent) uploadDoc: MgaDocumentsComponent;
  headerTAForm: UntypedFormGroup;
  detailsTAForm: UntypedFormGroup;
  accountingDetailsReinsForm: UntypedFormGroup;
  accountingDetailsCoinsForm: UntypedFormGroup;
  items: UntypedFormArray;
  itemReins: UntypedFormArray;
  itemCoins: UntypedFormArray;
  mgaList: any = [];

  documents: any;
  isDocumentNeedsToBeUpdated: any;
  documentRefId: any;
  documentTypes: any[];

  transTypeList: any;
  contractList: any = [];
  accCurrency: any;
  techAccDetails: any = [];
  lobCompanyList: any;
  action: string;
  batchId: any;
  isNew: boolean = false;
  status: string;
  sumAccoutingCurrency: any = 0;
  sumFunctionalCurrency: any = 0;
  revenueDetails: any = [];
  revenueDetailsCoins: any = [];
  subProdList: any;
  headerDetails: any;
  buyRate1: any;
  buyRate2: any;
  buyRate3: any;
  baseCurrencyCode: any;

  LocalCurrency: any;
  newID: any;
  isSave: boolean = false;
  isUpdate: boolean = false;
  newForm;
  divisionCode: any;
  techAccTypesList: any = [];

  transType: any;
  contractId: any;
  minDate: any;
  minClosingDate: any;
  sumFunctionalNum: any = 0;
  bType: any;
  isAvailQS: boolean = true;
  paymentFreqList: any;
  enablePreview: boolean = false;
  enablePreviewCoins: boolean = false;
  tType: any;
  showCoinsurer: boolean = false;
  coinsList: any = [];
  sumAccoutingCoinsCurrency: any = 0;
  sumOrgValCoins: any = [];
  sumOrgValReins: any = [];
  contractIdKey: any;
  GNList: any = [{ key: 'G', value: "G" }, { key: 'N', value: "N" }];
  defaultData: any;
  tempItemArray: any;
  taTypeValueListCoinsDB: any;
  taTypeValueListDirectDB: any;
  directListArray: any;
  coinsListArray: any;

  reinsList: any = [];
  showReinsurer: boolean = false;
  enablePreviewReins: boolean = false;
  addEditTime: boolean = false;

  @ViewChild('confirmModal1') confirmModal1: ElementRef;
  @ViewChild('saveModal2') saveModal2: ElementRef;
  @ViewChild('errorModal3') errorModal3: ElementRef;
  @ViewChild('confirmDialog4') confirmDialog4: ElementRef;
  @ViewChild('apprConfirmModal5') apprConfirmModal5: ElementRef;
  @ViewChild('previewDialog6') previewDialog6: ElementRef;
  @ViewChild('coinsPopup7') coinsPopup7: ElementRef;
  @ViewChild('saveNapproveModal8') saveNapproveModal8: ElementRef;
  @ViewChild('batchReverseModal9') batchReverseModal9: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private loaderService: LoaderService,
    private mgaService: MgaContractService,
    private toastService: ToastService,
    private session: SessionStorageService,
    private modalService: BsModalService,
    private treatyService: TreatyService,
    private activatedRoute: ActivatedRoute,
  ) {
    this.activatedRoute.queryParams.subscribe(params => {
      this.newForm = params['newForm'];
    });
  }
  ngOnInit() {
    this.loaderService.isBusy = true;
    this.divisionCode = this.session.get('divisionCode');
    this.action = this.mgaService.getParamValue('action');
    this.batchId = this.mgaService.getParamValue('id');
    this.status = this.mgaService.getParamValue('status');
    this.createForm();
    this.createDetailsForm();
    this.createReinsDetailsForm();
    this.createCoinsuranceForm();
    this.getMasterData();
    this.getDocumentTypes();

    if (this.status == 'A' || this.status == 'R') {
      this.headerTAForm.disable();
      this.detailsTAForm.disable();
      this.isSave = true;
      this.isUpdate = true;
    }
    if (this.status == 'P') {
      this.headerTAForm.get('bhProdCode').disable();
    }
    this.isNew = (this.batchId != undefined ? true : false);
    if (!this.isNew) {
      this.isSave = false;
      this.isUpdate = true;
    } else {
      this.isSave = true;
    }
    if (this.batchId != undefined) {
      this.mgaService.fetchTechAccListById(this.batchId).subscribe(res => {
        this.transType = res.bhTranType;
        if (res && res.bhFlex05) {
          this.documentRefId = res.bhFlex05;
        }
        if (this.transType) {
          this.mgaService.fetchContractList(this.transType).subscribe(contractList => {
            this.contractList = contractList;
            this.headerTAForm.patchValue({
              bhTranType: res.bhTranType,
              bhcontractId: this.contractList.find(datum => datum.key === res.bhFlex02)
            })
            this.getDetailsByContractId(this.headerTAForm.get('bhcontractId').value, this.contractList.length)
          })
        }
        this.headerDetails = res;
        this.headerTAForm.patchValue(res);
        this.headerTAForm.patchValue({
          bhDocDt: new Date(res.bhDocDt),
        });
        this.minDate = new Date(moment(this.headerTAForm.get('bhDocDt').value, 'DD-MM-YYYY').toDate());
        this.headerTAForm.patchValue({
          bhDueDt: new Date(res.bhDueDt),
        });
        this.headerTAForm.patchValue({
          bhCloseDateFm: (res.bhCloseDateFm == null) ? null : new Date(res.bhCloseDateFm),
          bhCloseDateTo: (res.bhCloseDateTo == null) ? null : new Date(res.bhCloseDateTo)
        });
        this.minClosingDate = new Date(moment(this.headerTAForm.get('bhCloseDateFm').value, 'DD-MM-YYYY').toDate());
        this.loaderService.isBusy = false;
      })

    } else {
      this.documentRefId = MgaUtils.makeRandomWord('TA-', 32);
      setTimeout(() => {
        this.getRevenueDetails({ key: this.headerTAForm.get('bhTranType').value }, 'loading');
      }, 100);
    }
    this.getBaseCurrencyCode();
    this.LocalCurrency = this.session.get('baseCurrency');

  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.setTabindex();
      this.calcAccPrice();
    }, 500);
  }
  createDetailsForm() {
    this.detailsTAForm = this.fb.group({
      bdAcntType: [undefined],
      bdFlex02: [undefined],
      bdCoa: [undefined],
      bdNotes: [undefined, Validators.required],
      bdOrgValFc: [undefined],
      bdAcntValFc: [undefined],
      bdPerc: [undefined],
      bdGn: [undefined],
      bdSrNo: [undefined],
      label: [undefined],
      desc: [undefined],
      info: [undefined],
      items: this.fb.array([]),
    });
  }
  createReinsDetailsForm() {
    this.accountingDetailsReinsForm = this.fb.group({
      bdAcntType: [undefined],
      bdFlex02: [undefined],
      bdCoa: [undefined],
      bdNotes: [undefined, Validators.required],
      bdOrgValFc: [undefined],
      bdAcntValFc: [undefined],
      bdPerc: [undefined],
      bdGn: [undefined],
      bdSrNo: [undefined],
      label: [undefined],
      desc: [undefined],
      info: [undefined],
      itemReins: this.fb.array([]),
    });
  }
  createCoinsDetailsForm(data) {
    if (this.action == 'edit' && !this.addEditTime || this.action == 'view') {
      return this.fb.group({
        bdAcntType: data.bdAcntType,
        bdAcntValFc: data.bdAcntValFc,
        bdGn: [data.bdGn],
        bdCoa: data.bdCoa,
        bdNotes: data.bdNotes,
        bdOrgValFc: data.bdOrgValFc,
        bdFlex02: data.taTypeId,
        bdPerc: (data.bdSrNo == null || data.bdPerc == '') ? null : [data.bdPerc],
        bdFlex01: data.bdFlex01,
        bdFlex07: undefined,
        bdSrNo: data.bdSrNo,
        edited: true,
        label: data.label,
        desc: data.desc,
        info: data.info,
        info3: data.info3,
        isPerc: data.bdPerc == '' ? true : false,
        taTypeId: data.taTypeId
      });

    } else if (this.action == 'edit' && this.addEditTime || this.action == undefined) {
      return this.fb.group({
        bdAcntType: data.value,
        bdFlex02: data.key,
        bdCoa: data.info1,
        bdNotes: data.value,
        bdOrgValFc: data.bdOrgValFc,
        bdAcntValFc: data.bdAcntValFc,
        bdPerc: data.info2 == '' ? null : [data.info2],
        bdGn: [data.info3],
        bdFlex01: data.bdFlex01,
        bdSrNo: data.bdSrNo,
        edited: false,
        label: data.label,
        desc: data.desc,
        info: data.info,
        info3: data.info3,
        isPerc: data.info2 == '' ? true : false,
        bdFlex07: undefined,
      });
    }
  }
  createCoinsuranceForm() {
    this.accountingDetailsCoinsForm = this.fb.group({
      mainItemCoins: this.fb.array([]),
    });

  }
  getBaseCurrencyCode() {
    this.mgaService.getBaseCurrencyDivision(this.divisionCode).subscribe(res => {
      this.baseCurrencyCode = res;
      sessionStorage.setItem('baseCurrencyCode', JSON.stringify(this.baseCurrencyCode));
    })
  }
  createItem(data?: any): UntypedFormGroup {
    if (this.action == 'edit' || this.action == 'view') {
      return this.fb.group({
        bdAcntType: data.bdAcntType,
        bdCoa: data.bdCoa,
        bdNotes: data.bdNotes,
        bdOrgValFc: data.bdOrgValFc,
        bdAcntValFc: data.bdAcntValFc,
        bdPerc: data.bdPerc == "" ? null : [data.bdPerc],
        bdGn: [data.info3],
        bdFlex01: data.bdFlex01,
        bdSrNo: data.bdSrNo,
        edited: true,
        label: data.label,
        desc: data.desc,
        info: data.info,
        isPerc: data.bdPerc == "" ? true : false,
      });
    } else {
      return this.fb.group({
        bdAcntType: data.value,
        bdFlex02: data.key,
        bdCoa: data.info1,
        bdNotes: data.value,
        bdOrgValFc: data.bdOrgValFc,
        bdAcntValFc: data.bdAcntValFc,
        bdPerc: data.info2 == "" ? null : [data.info2],
        bdGn: [data.info3],
        bdFlex01: data.bdFlex01,
        bdSrNo: data.bdSrNo,
        edited: false,
        label: data.label,
        desc: data.desc,
        info: data.info,
        isPerc: data.info2 == "" ? true : false,
      });
    }
  }
  createItem1(data?: any): UntypedFormGroup {
    return this.fb.group({
      bdAcntType: data.value,
      bdFlex02: data.key,
      bdCoa: data.info1,
      bdNotes: data.value,
      bdOrgValFc: data.bdOrgValFc,
      bdAcntValFc: data.bdAcntValFc,
      bdFlex01: data.bdFlex01,
      bdSrNo: data.bdSrNo,
      edited: false,
    });
  }
  createItemCoins(data?: any): UntypedFormGroup {
    var farr = this.fb.array([]) as UntypedFormArray;
    for (let i = 0; i < data.subCoinsList.length; i++) {
      farr.push(this.createCoinsDetailsForm(data.subCoinsList[i]));
    }
    return this.fb.group({
      bdAcntType: data.value,
      bdFlex02: data.key,
      bdCoa: data.info1,
      bdNotes: data.bdNotes,
      bdOrgValFc: data.bdOrgValFc,
      bdAcntValFc: data.bdAcntValFc,
      bdPerc: data.info2 == '' ? null : [data.info2],
      bdGn: [data.info3],
      bdFlex01: data.bdFlex01,
      bdSrNo: data.bdSrNo,
      edited: false,
      label: data.label,
      desc: data.desc,
      info: data.info,
      info3: data.info3,
      itemCoins: farr,
    });

  }
  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val, backdrop: true, ignoreBackdropClick: true });
  }

  closeModal(id: number) {
    this.modalService.hide(id);
  }
  addItemReins(event?: string, tType?: string): void {
    this.itemReins = this.accountingDetailsReinsForm.get('itemReins') as UntypedFormArray;
    while (this.itemReins.length !== 0) {
      this.itemReins.removeAt(0);
    }
    if (this.reinsList && event == 'reins' && (tType == '001')) {
      for (let j = 0; j < this.reinsList.length; j++) {
        this.itemReins.push(this.createItem(this.reinsList[j]));
      }
    }
    this.sumFuncCurrency();
    if (this.status == 'A' || this.status == 'R') {
      this.itemReins['controls'].forEach((control) => {
        control.disable();
      })
    }
    this.sumAccCurrency();
  }
  addItem(event?: string, tType?: string): void {
    this.items = this.detailsTAForm.get('items') as UntypedFormArray;
    while (this.items.length !== 0) {
      this.items.removeAt(0);
    }
    if (this.directListArray && event == 'auto' && (this.tType == '001' || this.tType == '008')) {
      for (let j = 0; j < this.directListArray.length; j++) {
        this.items.push(this.createItem(this.directListArray[j]));
      }
    } else if (this.directListArray && event == 'auto' && (this.tType == '002' || this.tType == '009')) {
      for (let j = 0; j < this.directListArray.length; j++) {
        this.items.push(this.createItem1(this.directListArray[j]));
      }
    }
    this.sumFuncCurrency();
    if (this.status == 'A' || this.status == 'R') {
      this.items = this.detailsTAForm.get('items') as UntypedFormArray;
      this.itemReins = this.accountingDetailsReinsForm.get('itemReins') as UntypedFormArray;
      this.items['controls'].forEach((control) => {
        control.disable();
      })
      this.itemReins['controls'].forEach((control) => {
        control.disable();
      })
    }
    this.sumAccCurrency();
  }
  filters(): UntypedFormArray {
    return this.accountingDetailsCoinsForm.get('mainItemCoins') as UntypedFormArray;
  }
  itemCoinArray(i) {
    return (this.accountingDetailsCoinsForm.get('mainItemCoins') as UntypedFormArray).controls[i].get('itemCoins') as UntypedFormArray;
  }
  fetchTransactionType() {
    this.mgaService.fetchTransactionType().subscribe(transaction => {
      this.transTypeList = transaction;
    })
  }

  getContractId(evt) {
    this.loaderService.isBusy = true;
    this.transType = evt.value;
    this.showCoinsurer = false;
    this.headerTAForm.patchValue({
      bhNetValFc: 0,
      bhNetValLc1: 0,
      bhNetValLc2: 0,
      bhNetValLc3: 0,
    })
    let info = this.transTypeList.filter((datum) => datum.key === this.transType);
    this.isAvailQS = (info[0].info == 'Y') ? false : true;
    this.headerTAForm.get('bhProdCode').setValidators(Validators.required);
    this.headerTAForm.get('bhProdCode').updateValueAndValidity();
    this.sumOrgValCoins = this.sumOrgValReins = [];
    if (this.isAvailQS) {
      this.headerTAForm.get('bhPayFrq').clearValidators();
      this.headerTAForm.get('bhCloseDateFm').clearValidators();
      this.headerTAForm.get('bhCloseDateTo').clearValidators();
      this.headerTAForm.patchValue({ bhProdCode: '', bhKcentRef: '', bhPayFrq: '' });
    } else {

      this.headerTAForm.get('bhPayFrq').setValidators(Validators.required);
      this.headerTAForm.get('bhPayFrq').updateValueAndValidity();
      this.headerTAForm.get('bhCloseDateFm').setValidators(Validators.required);
      this.headerTAForm.get('bhCloseDateFm').updateValueAndValidity();
      this.headerTAForm.get('bhCloseDateTo').setValidators(Validators.required);
      this.headerTAForm.get('bhCloseDateTo').updateValueAndValidity();
      this.headerTAForm.patchValue({ bhProdCode: null });
      this.sumAccoutingCurrency = this.sumFunctionalNum = 0;
    }
    this.mgaService.fetchContractList(evt.value).subscribe((res: any) => {
      this.contractList = res;
      if (this.contractList.length > 0) {
        this.loaderService.isBusy = false
        this.techAccTypesList = [];
        this.headerTAForm.patchValue({
          bhcontractId: undefined,
          // bhAcntCurr: undefined,
          bhTtyRefNo: undefined,
          bhFlex02: undefined,
          bhAcntCust: undefined,
          bhAcntYear: undefined
        });
      } else {
        this.contractList = this.techAccTypesList = [];
        this.loaderService.isBusy = false;
        this.headerTAForm.patchValue({
          bhcontractId: undefined,
          // bhAcntCurr: undefined,
          bhTtyRefNo: undefined,
          bhFlex02: undefined,
          bhAcntCust: undefined,
          bhAcntYear: undefined
        });
      }
    })
    this.revenueDetails = [];
  }
  updateLedgers() {
    this.ledgerUpdateCommon();
    if (this.enablePreviewReins) {
      this.ledgerUpdateReinsurer();
    }
    setTimeout(() => {
      if (Number(this.sumAccoutingCurrency) == 0) {
        this.toastService.warning("Accounting Amount should not be 0 !")
      } else {
        this.open(this.previewDialog6, 6, 'modal-xlg');
      }
    }, 200);
  }
  ledgerUpdateReinsurer() {
    for (let i = 0; i < this.itemReins.value.length; i++) {
      if (this.tType == '001') {
        if (this.itemReins.value[i].bdPerc && this.itemReins.value[i].bdPerc != 0 || this.itemReins.value[i].bdOrgValFc && this.itemReins.value[i].bdOrgValFc != 0) {
          (this.accountingDetailsReinsForm.get('itemReins') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(true, { emitEvent: true });
        } else {
          (this.accountingDetailsReinsForm.get('itemReins') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(false, { emitEvent: true });
        }
      } else {
        if (this.itemReins.value[i].bdOrgValFc) {
          (this.accountingDetailsReinsForm.get('itemReins') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(true, { emitEvent: true });
        } else {
          (this.accountingDetailsReinsForm.get('itemReins') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(false, { emitEvent: true });
        }
      }
    }
  }
  ledgerUpdateCommon() {
    for (let i = 0; i < this.items.value.length; i++) {
      if (this.tType == '001' || this.tType == '008') {
        if (this.items.value[i].bdPerc && this.items.value[i].bdPerc != 0 || this.items.value[i].bdOrgValFc && this.items.value[i].bdOrgValFc != 0) {
          (this.detailsTAForm.get('items') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(true, { emitEvent: true });
        } else {
          (this.detailsTAForm.get('items') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(false, { emitEvent: true });
        }
      } else {
        if (this.items.value[i].bdOrgValFc) {
          (this.detailsTAForm.get('items') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(true, { emitEvent: true });
        } else {
          (this.detailsTAForm.get('items') as UntypedFormArray)
            .at(i)
            .get('edited').setValue(false, { emitEvent: true });
        }
      }
    }
  }
  updateLedgersCoins() {
    this.ledgerUpdateCommon();
    let rawValueCoins = this.filters();
    for (let k = 0; k < rawValueCoins.length; k++) {
      let form = rawValueCoins.value[k];
      for (let i = 0; i < form.itemCoins.length; i++) {
        let OrgVal = this.itemCoinArray(k).at(i).get('bdOrgValFc').value;
        let Perc = this.itemCoinArray(k).at(i).get('bdPerc').value;
        let edited = this.itemCoinArray(k).at(i).get('edited');
        if ((Perc && Perc != 0) || (OrgVal && OrgVal != 0)) {
          edited.setValue(true, { emitEvent: true });
        } else {
          edited.setValue(false, { emitEvent: true });
        }
      }
    }
    setTimeout(() => {
      if (Number(this.sumAccoutingCurrency) == 0) {
        this.toastService.warning("Accounting Amount should not be 0 !")
      } else {
        this.open(this.coinsPopup7, 7, 'modal-xlg');
      }
    }, 200);
  }

  addReinsurer() {
    this.sumOrgValReins = [];
    if (Number(this.sumAccoutingCurrency) == 0) {
      this.showReinsurer = true;
      this.enablePreviewReins = false;
      this.toastService.warning("Accounting Amount should not be 0 !")
    } else {
      this.showReinsurer = false;
      this.enablePreviewReins = true;
      this.generateRowDataForReins('reins', this.tType);
    }
  }
  addCoinsurer() {
    this.showCoinsurer = true;
    this.enablePreviewCoins = true;
    if (this.action == undefined || this.action == 'edit' && this.addEditTime) {
      this.revenueDetailsCoins = this.coinsList;
    }
    if (this.revenueDetailsCoins.length > 0) {
      this.revenueDetailsCoins = this.revenueDetailsCoins.filter((value) => {
        return value.value == '0';
      });
    }
    while (this.filters().length !== 0) {
      this.filters().removeAt(0);
    }
    this.sumOrgValCoins = [];
    if (Number(this.sumAccoutingCurrency) == 0) {
      this.showCoinsurer = false;
      this.enablePreviewCoins = false;
      this.toastService.warning("Accounting Amount should not be 0 !")
    } else {
      this.showCoinsurer = true;
      this.enablePreviewCoins = true;
      this.enablePreview = false;
      this.revenueDetailsCoins.forEach((element1: any, value1) => {
        this.filters().push(this.createItemCoins(element1));
      });
      this.autoCalc(0);
      this.autoCalc(1);
      this.autoCalc(2);
      this.autoCalc(3);
    }
    if (this.status == 'A' || this.status == 'R') {
      this.accountingDetailsCoinsForm.disable();
      let itemCoins = this.accountingDetailsCoinsForm.get('mainItemCoins') as UntypedFormArray;
      itemCoins['controls'].forEach((control) => {
        control.disable();
      })
    }
  }
  cancelCoinsurer() {
    this.showCoinsurer = false;
    this.enablePreview = true;
    this.sumOrgValCoins = [];
    while (this.filters().length !== 0) {
      this.filters().removeAt(0);
    }
  }
  cancelReinsurer() {
    this.showReinsurer = true;
    this.enablePreviewReins = false
    this.sumOrgValReins = [];
    while (this.itemReins.length !== 0) {
      this.itemReins.removeAt(0);
    }
  }
  getDetailsContract(evnt) {
    this.loaderService.isBusy = true;
    this.getTechAccTypes(this.contractIdKey, this.batchId, this.transType, this.bType, evnt.value);
    this.headerTAForm.patchValue({ bhPayFrq: '' });
    this.sumOrgValCoins = this.sumOrgValReins = [];
    while (this.filters().length !== 0) {
      this.filters().removeAt(0);
    }
  }
  getDetailsByContractId(evt, len) {
    this.loaderService.isBusy = true;
    const bhAcntYear = this.headerTAForm.get('bhAcntYear');
    this.bType = evt.info;
    this.contractIdKey = evt.key;
    let info = this.transTypeList.filter((datum) => datum.key === this.transType);
    this.isAvailQS = (info[0].info == 'Y') ? false : true;

    this.getTechAccTypes(this.contractIdKey, this.batchId, this.transType, evt.info);
    if (this.newForm != 'New') {
      this.getRevenueDetails({ key: this.headerTAForm.get('bhTranType').value }, 'loading');
    }
    if (len > 0) {
      let array;
      evt = (typeof evt === 'object') ? evt.key : evt;
      if (evt != null) {
        array = evt.split('~');
        this.contractId = {
          taRefNo: array[0],
          taSeqNo: array[1],
          taAmendNo: array[2],
          taContractDesc: array[3]
        }
      }
    } else {
      this.contractId = {
        taRefNo: this.headerTAForm.get('bhTtyRefNo').value,
        taYear: this.headerTAForm.get('bhAcntYear').value,
      }
    }
    bhAcntYear.clearValidators();
    bhAcntYear.updateValueAndValidity();
    if (this.action == undefined) {
      this.headerTAForm.patchValue({ bhProdCode: '' });
    }
    this.sumAccoutingCurrency = 0;
    this.sumOrgValCoins = this.sumOrgValReins = [];
    this.batchId = (this.batchId == undefined) ? 0 : this.batchId;
    this.mgaService.fetchContractDetails(this.transType, this.contractId).subscribe(res => {
      this.headerTAForm.patchValue({
        bhTtyRefNo: res.refNo,
        bhFlex02: evt.key,
        bhAcntYear: res.year,
      });
      this.setNarration(res, 'refNo')
      if (this.contractList.length > 0) {
        this.subProdList = res.products;
      }
      this.loaderService.isBusy = false;
    }, (err => {
      this.toastService.error(err);
      this.loaderService.isBusy = false;
    }))
  }
  changeAccTo() {
    this.headerTAForm.patchValue({ bhPayFrq: '' });
  }
  getClosingDT(evnt, trans_code) {
    if (this.transType == trans_code) {
      this.loaderService.isBusy = true;
      let formData = {
        "bhPayFrq": evnt.value,
        "bhTranType": trans_code,
        "bhAcntYear": this.headerTAForm.get('bhAcntYear').value,
        "bhAcntCust": this.headerTAForm.get('bhAcntCust').value,
        "bhProdCode": this.headerTAForm.get('bhProdCode').value,
        "bhTtyRefNo": this.contractId.taRefNo,
        "bhTtyAmendNo": this.contractId.taAmendNo,
        "bhTtySeqNo": this.contractId.taSeqNo
      }
      this.mgaService.getClosingDate(formData).subscribe((resp: any) => {
        if (resp && resp.closeDateFrom) {
          this.headerTAForm.get('bhCloseDateFm').setValue(new Date(resp.closeDateFrom));
        }
        if (resp && resp.closeDateTo) {
          this.headerTAForm.get('bhCloseDateTo').setValue(new Date(resp.closeDateTo));
        }
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error);
      })
    }
  }
  getRevenueDetails(trans_code, loadingTime?: string) {
    this.loaderService.isBusy = true;
    this.batchId = (this.batchId == undefined) ? 0 : this.batchId;
    if (this.batchId != 0 && loadingTime != 'loading') {
      this.showDialogbox(trans_code);
    }
    if (trans_code.key) {
      this.mgaService.fetchRevenueDetails('REVENUE_CODE', trans_code.key, this.batchId).subscribe((resp: any) => {
        this.techAccTypesList = resp;
        this.defaultData = this.techAccTypesList.defaultData;
        this.coinsList = this.defaultData.coinsList;
        this.reinsList = this.defaultData.taTypeValueListQSOnPrem;
        this.taTypeValueListCoinsDB = this.techAccTypesList.taTypeValueListCoinsDB;
        this.taTypeValueListDirectDB = this.techAccTypesList.taTypeValueListDirectDB;
        let data = {
          "refNo": this.contractIdKey,
          "batchId": 0,
          "tranType": trans_code.key,
          "busType": this.bType,
          "productCode": this.headerTAForm.get('bhProdCode').value
        };
        if (this.taTypeValueListCoinsDB.length == 0) {
          this.mgaService.fetchTAAccTypes(data).subscribe((res: any) => {
            this.coinsList = res.coinsList;
            this.addEditTime = true;
            if (this.coinsList.length > 0) {
              this.showCoinsurer = false;
              this.enablePreview = true;
            } else {
              this.showCoinsurer = true;
              this.enablePreviewCoins = false;
              this.enablePreview = true;
            }
          }, error => {
            this.loaderService.isBusy = false;
            this.toastService.error(error.error);
          });
        }
        this.directListArray = JSON.parse(
          JSON.stringify(this.defaultData.taTypeValueListDirect)
        );
        this.coinsListArray = JSON.parse(JSON.stringify(this.coinsList));

        this.revenueDetails = this.techAccTypesList.taTypeValueListDirectDB;
        this.taTypeValueListDirectDB.forEach((element, value) => {
          for (let j = this.directListArray.length; j >= 0; j--) {
            if (
              this.directListArray &&
              this.directListArray[j] &&
              this.directListArray[j].key
            ) {
              if (element.taTypeId == this.directListArray[j].key) {
                this.directListArray.splice(j, 1);
              }
            }
          }
        });
        this.directListArray.forEach((element, value) => {
          element.bdAcntType = element.value;
          element.bdAcntValFc = 0;
          element.bdCoa = element.info1;
          element.bdGn = element.info3;
          element.bdNotes = element.value;
          element.bdOrgValFc = 0;
          element.bdPerc = element.info2;
          element.bdSrNo = null;
          element.coinShare = 'null';
          element.coinsurer = 'null';
          element.info = element.info;
          element.taTypeId = element.key;
        });
        this.directListArray.push(...this.taTypeValueListDirectDB);
        this.directListArray = _.sortBy(this.directListArray, [
          function (o) {
            return o.taTypeId;
          },
        ]);

        this.generateRowData('auto', this.tType);
        this.detailsTAForm.patchValue({
          items: this.directListArray
        });
        this.coinsListArray.forEach((element, value) => {
          element.subCoinsList.map((element) => {
            element.info = element.info;
            element.bdCoa = element.info1;
            element.bdSrNo = null;
            element.bdOrgValFc = '';
            element.bdPerc = element.info2;
            element.bdGn = element.info3;
            element.bdAcntValFc = '';
            element.key = element.key;
            element.bdAcntType = element.value;
            element.bdNotes = element.value;
            element.taTypeId = element.key;
          });
        });
        this.coinsListArray.forEach((element, value) => {
          element.itemArray = this.taTypeValueListCoinsDB;
          let tempItemArray = JSON.parse(
            JSON.stringify(this.taTypeValueListCoinsDB)
          );
          for (let j = tempItemArray.length; j >= 0; j--) {
            if (tempItemArray[j] && tempItemArray[j]['coinShare'] != element.info) {
              tempItemArray.splice(j, 1);
            }
          }
          element.itemArrayCoins = tempItemArray;
        });
        for (let o = 0; o < this.coinsListArray.length; o++) {
          for (let i = 0; i < this.coinsListArray[o].itemArrayCoins.length; i++) {
            for (let j = 0; j < this.coinsListArray[o].subCoinsList.length; j++) {
              if (
                this.coinsListArray[o].itemArrayCoins[i].taTypeId ==
                this.coinsListArray[o].subCoinsList[j].taTypeId
              ) {
                this.coinsListArray[o].subCoinsList[j] = this.coinsListArray[o].itemArrayCoins[i];
              }
            }
          }
        }
        this.revenueDetailsCoins = this.coinsListArray;
        if (this.revenueDetailsCoins.length > 0) {
          this.showCoinsurer = false;
          this.addCoinsurer();
          this.enablePreview = false;
        } else {
          this.showCoinsurer = true;
          this.enablePreview = true;
        }
        if (this.reinsList && this.reinsList.length > 0 && (this.tType == '001' || this.tType == '002')) {
          this.showReinsurer = true;
        } else {
          this.showReinsurer = false;
        }
        this.loaderService.isBusy = false;
      }, (err => {
        this.toastService.error(err);
        this.loaderService.isBusy = false;
      }))
    }
  }
  setUwYear(value) {
    if (value !== null) {
      let obj = {
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0
      };
      var warrDays;
      this.minDate = value;
      let startDate = moment(value).set(obj);
      let endDate = this.headerTAForm.get('bhDueDt').value;
      if (endDate == null || endDate == undefined) {
        warrDays = 0;
        var data = {
          bhWarrDays: warrDays,
        };
      } else {
        startDate = moment(startDate).set(obj);
        endDate = moment(endDate, "DD-MM-YYYY").set(obj);
        warrDays = endDate.diff(startDate, 'days');
        var data = {
          bhWarrDays: warrDays + 1,
        };
      }
      if (warrDays < 1) {
        this.headerTAForm.patchValue({ bhDueDt: null });
      }
      this.headerTAForm.patchValue(data);
      if (this.headerTAForm.get('bhAcntCurr').value != null) {
        this.onchangeCurrency(this.headerTAForm.get('bhAcntCurr').value)
      }
    }
  }
  setWarrantyDay(value) {
    setTimeout(() => {
      let obj = {
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0
      }
      this.minDate = new Date(moment(this.headerTAForm.get('bhDocDt').value, 'DD-MM-YYYY').toDate());
      var startDate = this.headerTAForm.get('bhDocDt').value;
      var endDate = this.headerTAForm.get('bhDueDt').value;
      var warrDays;
      if (endDate == null || endDate == undefined) {
        warrDays = 0;
      } else {
        startDate = moment(startDate).set(obj);
        endDate = moment(endDate, "DD-MM-YYYY").set(obj);
        warrDays = endDate.diff(startDate, 'days');
        if (warrDays > 0) {
          warrDays = warrDays
        } else {
          warrDays = Math.abs(warrDays);
          warrDays = warrDays
        }
      }
      this.headerTAForm.patchValue({ bhWarrDays: warrDays });
    }, 200);
  }
  setClosingDate(value) {
    this.minClosingDate = new Date(moment(value, 'DD-MM-YYYY').toDate());
    let toDate = this.headerTAForm.get('bhCloseDateTo').value
    if (toDate != null && this.minClosingDate > toDate) {
      this.headerTAForm.get('bhCloseDateTo').setValue(null);
    }
  }
  narration = {
    refNo: '',
    subproduct: '',
    fromDate: '',
    toDate: '',
  };
  setNarration(evnt, name) {
    let notes = this.headerTAForm.get('bhNotes').value;
    if (name == 'refNo') {
      this.narration.refNo = 'Binder Ref No: ' + evnt.refNo + ', YOA: ' + evnt.year + ' ,';
    }
    if (name == 'subproduct') {
      this.narration.subproduct = ' Product: ' + evnt.value + ' ,';
    }
    if (name == 'fromDate') {
      if (evnt !== null && evnt != undefined) {
        evnt = moment(evnt, 'DD-MM-YYYY').format('DD/MM/YYYY')
        this.narration.fromDate = 'Closing Date: ' + evnt;
        if (this.headerTAForm.get('bhCloseDateTo').value) {
          this.narration.toDate = '-' + moment(this.headerTAForm.get('bhCloseDateTo').value, 'DD-MM-YYYY').format('DD/MM/YYYY');
        }
      } else {
        this.narration.fromDate = '';
        this.narration.toDate = '';
      }
    }
    if (name == 'toDate') {
      if (this.headerTAForm.get('bhCloseDateFm').value) {
        if (evnt !== null && evnt != undefined) {
          evnt = moment(evnt, 'DD-MM-YYYY').format('DD/MM/YYYY')
          this.narration.toDate = '-' + evnt;
        } else {
          this.narration.toDate = '-';
        }
      }
    }
    if (this.action == undefined) {
      this.headerTAForm.patchValue({
        bhNotes: this.narration.refNo + this.narration.subproduct + this.narration.fromDate + this.narration.toDate,
      });
    }
  }
  generateRowData(event, tType) {
    this.directListArray.forEach(element => {
      this.addItem('auto', tType);
    });
  }
  generateRowDataForReins(event, tType) {
    this.reinsList.forEach(element => {
      this.addItemReins(event, tType);
    });
  }
  fetchAccCurrency() {
    this.mgaService.fetchAccCurrency().subscribe(currencies => {
      this.accCurrency = (currencies as any).map(currency => {
        currency.displayText = currency.currCode + ' - ' + currency.currName;
        return currency;
      });
      if (this.newForm === 'New') {
        this.headerTAForm.patchValue({ bhAcntCurr: this.LocalCurrency })
        this.onchangeCurrency(this.LocalCurrency);
      }
      this.loaderService.isBusy = false;
    }, (err => {
      this.toastService.error(err);
    }))
  }
  fetchAllTechAccDetails() {
    this.mgaService.fetchAllTechAccDetails().subscribe(techAcc => {
      this.techAccDetails = techAcc;
    })
  }
  getMGAappCode() {
    this.mgaService.getACNTfilterlist().subscribe((mgaLst: any) => {
      this.mgaList = (mgaLst as any[]).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });
    })
    this.loaderService.isBusy = false;
  }
  getLOBCompanyAppCode() {
    this.mgaService.getLOBCompanyAppCode().subscribe(lobCompany => {
      this.lobCompanyList = lobCompany.list;
    })

  }
  getMasterData() {
    this.fetchTransactionType();
    this.fetchAccCurrency();
    this.getMGAappCode();
    this.getLOBCompanyAppCode();
    this.fetchSubProductDetails();
    this.getPaymentFrequency();
  }
  getPaymentFrequency() {
    this.mgaService.getBordereauxFrequency().subscribe((resp: any) => {
      this.paymentFreqList = resp;
    }, err => {
    });
  }
  fetchSubProductDetails() {
    this.mgaService.fetchSubProductDetails().subscribe((subPrd: any) => {
      this.subProdList = subPrd.AccSubProductList;
    })
  }
  onchangeCurrency(event) {
    this.loaderService.isBusy = true;
    setTimeout(() => {
      var currCode, dt, onDate;
      currCode = (typeof event === 'object') ? event.value : event;
      dt = this.headerTAForm.get('bhDocDt').value;
      if (dt == null || dt == undefined) {
        this.toastService.warning('Choose Accounting Date');
        this.loaderService.isBusy = false;

      } else {
        if (this.baseCurrencyCode) {
          onDate = moment(dt).format('YYYY-MM-DD');
          this.mgaService.fetchExchangeRate(currCode, this.baseCurrencyCode.baseCurrency1, onDate).subscribe((res: any) => {
            if (res && res.buyRate) {
              this.buyRate1 = res.buyRate;
            } else {
              this.buyRate1 = 0;
              this.toastService.warning("Exchange Rate is not Available for the Contract Year.")
            }
            this.headerTAForm.get('bhFixedRate').setValue(this.buyRate1);
            this.onAmountEnter();
            this.calcAccPrice();
            if (this.showCoinsurer) {
              this.calcAccPriceForCoins();
            }
            if (this.enablePreviewReins) {
              this.calcAccPriceForReins();
            }
          })
          this.mgaService.fetchExchangeRate(currCode, this.baseCurrencyCode.baseCurrency2, onDate).subscribe((res: any) => {
            this.buyRate2 = res.buyRate;
            this.onAmountEnter();

          })
          this.mgaService.fetchExchangeRate(currCode, this.baseCurrencyCode.baseCurrency3, onDate).subscribe((res: any) => {
            this.buyRate3 = res.buyRate;
            this.onAmountEnter();
          })
        }
        this.loaderService.isBusy = false;
      }
    }, 100);
  }
  print() {

  }
  onAmountEnter() {
    this.headerTAForm.patchValue({ 'bhNetValFc': this.sumAccoutingCurrency });

    if (this.sumAccoutingCurrency) {
      this.calcAmount(this.sumAccoutingCurrency, this.buyRate1, 'bhNetValLc1');
      this.calcAmount(this.sumAccoutingCurrency, this.buyRate2, 'bhNetValLc2');
      this.calcAmount(this.sumAccoutingCurrency, this.buyRate3, 'bhNetValLc3');
    }
  }
  calcAmount(amount, buyRate, epiLc) {
    if (amount && buyRate) {
      const localCurrency = amount * buyRate;
      let no = ((localCurrency * 100) / 100).toFixed(4);
      this.headerTAForm.get(epiLc).setValue(no);
    }
  }
  viewAccounting() {
    this.router.navigate(['/mga-view-accounting'], { queryParams: { batchId: this.batchId, binder: 'BIND_TAM', status: this.status } });
  }
  openReversePopup() {
    this.open(this.batchReverseModal9, 9, 'modal-md');
  }
  doReverse() {
    this.loaderService.isBusy = true;
    this.mgaService.reversalTAManual(this.batchId).subscribe((resp) => {
      this.toastService.success('Batch Id : ' + this.batchId + ' Successfully Reversed');
      this.modalService.hide();
      setTimeout(() => {
        this.back();
      }, 500);
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }

  createForm() {
    this.headerTAForm = this.fb.group({
      bhTranType: [undefined, Validators.required],
      bhcontractId: [undefined, Validators.required],
      bhRefNo: [undefined],
      bhDueDt: [undefined, Validators.required],
      bhWarrDays: [undefined],
      bhAcntYear: [undefined, [Validators.required, YearValidator]],
      bhAcntCurr: [undefined, Validators.required],
      bhNotes: [undefined, Validators.required],
      bhNetValFc: [undefined],
      bhNetValLc1: [undefined],
      bhNetValLc2: [undefined],
      bhNetValLc3: [undefined],
      bhProdCode: [undefined, Validators.required],
      bhDocDt: [new Date(), Validators.required],
      bhFixedRate: [undefined],
      bhAcntCust: [undefined, Validators.required],
      bhTtyRefNo: [undefined, Validators.required],
      bhFlex02: undefined,
      bhCloseDateFm: [undefined],
      bhCloseDateTo: [undefined],
      bhKcentRef: [undefined],
      bhPayFrq: [undefined],
    });
  }

  setValidation() {
    const accAmount = (this.detailsTAForm.get('items') as UntypedFormArray);
    accAmount['controls'].forEach(fg => {
      let parsed = parseFloat(fg.get('bdOrgValFc').value);
      if (parsed != 0) {
        fg["controls"]['bdNotes'].setValidators([Validators.required]);
        fg["controls"]['bdNotes'].updateValueAndValidity();
      } else {
        fg["controls"]['bdNotes'].clearValidators();
        fg["controls"]['bdNotes'].updateValueAndValidity();
        fg.patchValue({ 'bdNotes': "" });
      }
    });
  }

  sumAccCurrency() {
    this.sumAccoutingCurrency = 0;
    const accAmount = (this.detailsTAForm.get('items') as UntypedFormArray)
    accAmount['controls'].forEach((element, value) => {
      let parsed = element.get('bdOrgValFc').value;
      if (this.tType == '001' && (element.value.bdAcntType).indexOf('104') != -1) {
        this.sumAccoutingCurrency += parsed;
      } else if (this.tType == '002' || this.tType == '009') {
        if (value == 0 || value == 1) {
          this.sumAccoutingCurrency += parsed;
        }
      } else if (this.tType == '008' && (element.value.bdAcntType).indexOf('307') != -1) {
        this.sumAccoutingCurrency += parsed;
      } else if (this.tType == '009' && (element.value.bdAcntType).indexOf('357') != -1) {
        this.sumAccoutingCurrency += this.returnAlwaysNegetive(parsed);
      } else {
        this.sumAccoutingCurrency += parsed;
      }
    })
    this.sumAccoutingCurrency = Number(this.sumAccoutingCurrency).toFixed(2);
    this.headerTAForm.patchValue({ 'bhNetValFc': this.sumAccoutingCurrency });
  }
  sumFuncCurrency() {
    this.sumFunctionalCurrency = 0;
    const funcAmount = (this.detailsTAForm.get('items') as UntypedFormArray)
    funcAmount['controls'].forEach((element, value) => {
      let parsed = parseFloat(element.get('bdAcntValFc').value);
      if (this.tType == '001' && (element.value.bdAcntType).indexOf('104') != -1) {
        this.sumFunctionalCurrency += parsed;
      } else if (this.tType == '002' || this.tType == '009') {
        if (value == 0 || value == 1) {
          this.sumFunctionalCurrency += parsed;
        }
      } else if (this.tType == '008' && (element.value.bdAcntType).indexOf('307') != -1) {
        this.sumFunctionalCurrency += parsed;
      } else if (this.tType == '009' && (element.value.bdAcntType).indexOf('357') != -1) {
        this.sumFunctionalCurrency += this.returnAlwaysNegetive(parsed);
      } else {
        this.sumFunctionalCurrency += this.changeNumber(parsed);
      }
    })
    this.sumFunctionalNum = Number(this.headerTAForm.get('bhNetValLc1').value).toFixed(2);
  }
  calcAccPriceForCoins() {
    let rawValueCoins = this.filters();
    if (this.tType !== '002') {
      this.sumOrgValCoins = [];
      for (let k = 0; k < rawValueCoins.length; k++) {
        this.sumOrgValCoins.push({ orgCurr: 0, acntCurr: 0 });
        let form = rawValueCoins.value[k].itemCoins;
        for (let i = 0; i < form.length; i++) {
          let bdOrgValFc = form[i].bdOrgValFc;
          if (this.buyRate1) {
            const result = ((this.buyRate1 * bdOrgValFc * 100) / 100).toFixed(4);
            this.itemCoinArray(k)
              .at(i)
              .get('bdAcntValFc')
              .setValue(result);
            if ((this.itemCoinArray(k).at(i).get('bdAcntType').value).indexOf('204') != -1) {
              this.sumOrgValCoins[k].orgCurr = this.sumOrgValCoins[k].orgCurr + Number(this.itemCoinArray(k).at(i).get('bdOrgValFc').value);
              this.sumOrgValCoins[k].acntCurr = this.sumOrgValCoins[k].acntCurr + Number(this.itemCoinArray(k).at(i).get('bdAcntValFc').value);
            } else {
              this.sumOrgValCoins[k].orgCurr = this.sumOrgValCoins[k].orgCurr + Number(this.itemCoinArray(k).at(i).get('bdOrgValFc').value);
              this.sumOrgValCoins[k].acntCurr = this.sumOrgValCoins[k].acntCurr + Number(this.itemCoinArray(k).at(i).get('bdAcntValFc').value);
            }
          }
        }
      }
    }
  }
  calcAccPriceForReins() {
    let rawValueReins = this.itemReins;
    if (this.tType == '001' || this.tType == '002') {
      this.sumOrgValReins.push({ orgCurr: 0, acntCurr: 0 });
    }
  }
  calcAccPrice() {
    let rawValue = this.detailsTAForm.getRawValue().items;
    var items = this.detailsTAForm.get('items') as UntypedFormArray;
    for (let k = 0; k < rawValue.length; k++) {
      let bdOrgValFc = (this.detailsTAForm.get('items') as UntypedFormArray)
        .at(k)
        .get('bdOrgValFc').value;
      if (this.tType == '002' || this.tType == '009') {
        if (k == 1) {
          let bdOrgValFc1 = (rawValue[k].bdOrgValFc == null) ? 0 : rawValue[k].bdOrgValFc;
          items.at(k).get('bdOrgValFc').setValue(this.convertedNumber(rawValue[0].bdOrgValFc, bdOrgValFc1));
        }
      }
      if (this.buyRate1) {
        const result = ((this.buyRate1 * bdOrgValFc * 100) / 100).toFixed(4);
        (this.detailsTAForm.get('items') as UntypedFormArray).at(k).get('bdAcntValFc').setValue(Number(result));
      }
    }
    this.sumFuncCurrency();
  }
  autoCalc(index) {
    let rawValue = (this.detailsTAForm.getRawValue().items);
    let rawValueReins = (this.accountingDetailsReinsForm.getRawValue().itemReins);
    var items = this.detailsTAForm.get('items') as UntypedFormArray;
    let rawValueCoins = this.filters();
    if (this.tType == '001') {
      if (index == 3) {
        for (let k = 0; k < rawValue.length; k++) {
          let bdOrgValFc = (rawValue[0].bdOrgValFc == null) ? 0 : rawValue[0].bdOrgValFc;
          let bdOrgValFc3 = (rawValue[index].bdOrgValFc == null) ? 0 : rawValue[index].bdOrgValFc;
          let bdPerc = items.at(k).get('bdPerc').value;
          let bdGn = items.at(k).get('bdGn').value;
          var result;
          items.at(index).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, bdOrgValFc3));
          if (Number(bdPerc)) {
            if (bdGn == 'N') {
              if (this.tType == '001') {
                if (bdOrgValFc > 0) {
                  result = ((bdPerc * (bdOrgValFc - this.returnAlwaysPositive(bdOrgValFc3))) / 100).toFixed(4);
                } else {
                  result = ((bdPerc * (bdOrgValFc - this.returnAlwaysNegetive(bdOrgValFc3))) / 100).toFixed(4);
                }
              } else {
                result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
              }
            } else {
              result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
            }
            items.at(k).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, result));
          }
        }
        setTimeout(() => {
          for (let k = 0; k < rawValueCoins.length; k++) {
            let bdPerc = rawValueCoins.value[k].info;
            let form = rawValueCoins.value[k];
            for (let i = 0; i < form.itemCoins.length; i++) {

              let perc = this.itemCoinArray(k)
                .at(i)
                .get('bdPerc').value;
              let gn = this.itemCoinArray(k)
                .at(i)
                .get('bdGn').value;
              let bdOrgValFc = this.itemCoinArray(k)
                .at(0)
                .get('bdOrgValFc').value;
              let bdOrgValFc3 = this.itemCoinArray(k)
                .at(3)
                .get('bdOrgValFc').value;
              this.itemCoinArray(k)
                .at(index)
                .get('bdOrgValFc')
                .setValue(this.convertedNumber(bdOrgValFc, bdOrgValFc3));
              if (Number(perc)) {
                if (gn == 'N') {
                  if (this.tType == '001') {
                    if (bdOrgValFc > 0) {
                      result = ((perc * (bdOrgValFc - this.returnAlwaysPositive(bdOrgValFc3))) / 100).toFixed(4);
                    } else {
                      result = ((perc * (bdOrgValFc - this.returnAlwaysNegetive(bdOrgValFc3))) / 100).toFixed(4);
                    }
                  } else {
                    result = ((perc * bdOrgValFc) / 100).toFixed(4);;
                  }
                } else {
                  result = ((perc * bdOrgValFc) / 100).toFixed(4);;
                }
                this.itemCoinArray(k)
                  .at(i)
                  .get('bdOrgValFc')
                  .setValue(this.convertedNumber(bdOrgValFc, result));
              }
            }
          }
        }, 10);
      }
      if (index == 0) {
        for (let k = 0; k < rawValue.length; k++) {
          let bdOrgValFc = (rawValue[index].bdOrgValFc == null) ? 0 : rawValue[index].bdOrgValFc;
          let bdOrgValFc3 = (rawValue[3].bdOrgValFc == null) ? 0 : rawValue[3].bdOrgValFc;
          let bdPerc = items.at(k).get('bdPerc').value;
          let bdGn = items.at(k).get('bdGn').value;
          var result;
          if (Number(bdPerc)) {
            if (bdGn == 'N') {
              if (this.tType == '001') {
                if (bdOrgValFc > 0) {
                  result = ((bdPerc * (bdOrgValFc - this.returnAlwaysPositive(bdOrgValFc3))) / 100).toFixed(4);
                } else {
                  result = ((bdPerc * (bdOrgValFc - this.returnAlwaysNegetive(bdOrgValFc3))) / 100).toFixed(4);
                }
              } else {
                result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
              }
            } else {
              result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
            }
            items.at(k).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, result));
          } else if (k == 3) {
            items.at(k).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, bdOrgValFc3));
          }
        }

        let OrgVal = (rawValue[0].bdOrgValFc == null) ? 0 : rawValue[0].bdOrgValFc;
        for (let k = 0; k < rawValueCoins.length; k++) {
          let bdPerc = rawValueCoins.value[k].info;
          let form = rawValueCoins.value[k];
          this.sumOrgValCoins.push({ orgCurr: 0, acntCurr: 0 });
          for (let i = 0; i < form.itemCoins.length; i++) {
            if (i == index) {
              this.itemCoinArray(k)
                .at(i)
                .get('bdOrgValFc')
                .setValue(((bdPerc * OrgVal) / 100).toFixed(4));
            }
            let perc = this.itemCoinArray(k)
              .at(i)
              .get('bdPerc').value;
            let gn = this.itemCoinArray(k)
              .at(i)
              .get('bdGn').value;
            let bdOrgValFc = this.itemCoinArray(k)
              .at(index)
              .get('bdOrgValFc').value;
            let bdOrgValFc3 = this.itemCoinArray(k)
              .at(3)
              .get('bdOrgValFc').value;
            this.itemCoinArray(k)
              .at(3)
              .get('bdOrgValFc')
              .setValue(this.convertedNumber(bdOrgValFc, bdOrgValFc3));
            if (Number(perc)) {
              if (gn == 'N') {
                if (this.tType == '001') {
                  if (bdOrgValFc > 0) {
                    result = ((perc * (bdOrgValFc - this.returnAlwaysPositive(bdOrgValFc3))) / 100).toFixed(4);
                  } else {
                    result = ((perc * (bdOrgValFc - this.returnAlwaysNegetive(bdOrgValFc3))) / 100).toFixed(4);
                  }
                } else {
                  result = ((perc * bdOrgValFc) / 100).toFixed(4);
                }
              } else {
                result = ((perc * bdOrgValFc) / 100).toFixed(4);
              }
              this.itemCoinArray(k)
                .at(i)
                .get('bdOrgValFc')
                .setValue(this.convertedNumber(OrgVal, result));
            }
            if ((this.itemCoinArray(k).at(i).get('bdAcntType').value).indexOf('204') != -1) {
              this.sumOrgValCoins[k].orgCurr = this.sumOrgValCoins[k].orgCurr + Number(this.itemCoinArray(k).at(i).get('bdOrgValFc').value);
            } else {
              this.sumOrgValCoins[k].orgCurr = this.sumOrgValCoins[k].orgCurr + Number(this.itemCoinArray(k).at(i).get('bdOrgValFc').value);
            }
            if (this.buyRate1) {
              let bdOrgValFc = this.itemCoinArray(k).at(i).get('bdOrgValFc').value;
              this.itemCoinArray(k)
                .at(i)
                .get('bdAcntValFc')
                .setValue(((this.buyRate1 * bdOrgValFc * 100) / 100).toFixed(4));
              if ((this.itemCoinArray(k).at(i).get('bdAcntType').value).indexOf('204') != -1) {
                this.sumOrgValCoins[k].acntCurr = this.sumOrgValCoins[k].acntCurr + Number(this.itemCoinArray(k).at(i).get('bdAcntValFc').value);
              } else {
                this.sumOrgValCoins[k].acntCurr = this.sumOrgValCoins[k].acntCurr + Number(this.itemCoinArray(k).at(i).get('bdAcntValFc').value);
              }
            }
            setTimeout(() => {
              this.calcAccPriceForCoins();
            }, 100);
          }
        }
      }
      if (index == 1 || index == 2 || index == 3) {

        let inx = index;
        let OrgVal = (rawValue[inx].bdOrgValFc == null) ? 0 : rawValue[inx].bdOrgValFc;
        for (let k = 0; k < rawValueCoins.length; k++) {
          let bdPerc = rawValueCoins.value[k].info;
          let form = rawValueCoins.value[k];
          for (let i = 0; i < form.itemCoins.length; i++) {
            this.itemCoinArray(k)
              .at(inx)
              .get('bdOrgValFc')
              .setValue(((bdPerc * OrgVal) / 100).toFixed(4));

            if ((this.itemCoinArray(k).at(i).get('bdAcntType').value).indexOf('204') != -1) {
              this.sumOrgValCoins[k].orgCurr = this.sumOrgValCoins[k].orgCurr + Number(this.convertedNumber(OrgVal, this.itemCoinArray(k).at(i).get('bdOrgValFc').value));
            } else {
              this.sumOrgValCoins[k].orgCurr = this.sumOrgValCoins[k].orgCurr + Number(this.itemCoinArray(k).at(i).get('bdOrgValFc').value);
            }
            if (this.buyRate1) {
              let bdOrgValFc = this.itemCoinArray(k).at(i).get('bdOrgValFc').value;
              this.itemCoinArray(k)
                .at(inx)
                .get('bdAcntValFc')
                .setValue(((this.buyRate1 * bdOrgValFc * 100) / 100).toFixed(4));
              if ((this.itemCoinArray(k).at(inx).get('bdAcntType').value).indexOf('204') != -1) {
                this.sumOrgValCoins[k].acntCurr = this.sumOrgValCoins[k].acntCurr + Number(this.convertedNumber(OrgVal, this.itemCoinArray(k).at(inx).get('bdAcntValFc').value));
              } else {
                this.sumOrgValCoins[k].acntCurr = this.sumOrgValCoins[k].acntCurr + Number(this.itemCoinArray(k).at(inx).get('bdAcntValFc').value);
              }
            }
          }
        }
      }
    } else if (this.tType == '002') {
      this.sumOrgValCoins = [];
      let inx = index;
      for (let k = 0; k < rawValueCoins.length; k++) {
        let bdPerc = rawValueCoins.value[k].info;
        let form = rawValueCoins.value[k];
        this.sumOrgValCoins.push({ orgCurr: 0, acntCurr: 0 });
        for (let i = 0; i < form.itemCoins.length; i++) {
          let OrgVal = (rawValue[i].bdOrgValFc == null) ? 0 : rawValue[i].bdOrgValFc;
          this.itemCoinArray(k)
            .at(i)
            .get('bdOrgValFc')
            .setValue(((bdPerc * OrgVal) / 100).toFixed(4));
          if (i == 1) {
            this.itemCoinArray(k)
              .at(1)
              .get('bdOrgValFc')
              .setValue(this.convertedNumber(rawValue[0].bdOrgValFc, (bdPerc * OrgVal) / 100).toFixed(4));
          }
          if (i == 0 || i == 1) {
            this.sumOrgValCoins[k].orgCurr = this.sumOrgValCoins[k].orgCurr + Number(this.itemCoinArray(k).at(i).get('bdOrgValFc').value);
          }
          if (this.buyRate1) {
            let bdOrgValFc = this.itemCoinArray(k).at(i).get('bdOrgValFc').value;
            this.itemCoinArray(k)
              .at(i)
              .get('bdAcntValFc')
              .setValue(((this.buyRate1 * bdOrgValFc * 100) / 100).toFixed(4));
            if (i == 0 || i == 1) {
              this.sumOrgValCoins[k].acntCurr = this.sumOrgValCoins[k].acntCurr + Number(this.itemCoinArray(k).at(i).get('bdAcntValFc').value);
            }
          }
        }
      }
    } else if (this.tType == '008') {
      if (index == 1) {
        for (let k = 0; k < rawValue.length; k++) {
          let bdOrgValFc = (rawValue[0].bdOrgValFc == null) ? 0 : rawValue[0].bdOrgValFc;
          let bdOrgValFc1 = (rawValue[index].bdOrgValFc == null) ? 0 : rawValue[index].bdOrgValFc;
          let bdPerc = items.at(k).get('bdPerc').value;
          let bdGn = items.at(k).get('bdGn').value;
          var result;
          items.at(index).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, bdOrgValFc1));
          if (Number(bdPerc)) {
            if (bdGn == 'N') {
              if (bdOrgValFc > 0) {
                result = ((bdPerc * (bdOrgValFc - this.returnAlwaysPositive(bdOrgValFc1))) / 100).toFixed(4);
              } else {
                result = ((bdPerc * (bdOrgValFc - this.returnAlwaysNegetive(bdOrgValFc1))) / 100).toFixed(4);
              }
            } else {
              result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
            }
            items.at(k).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, result));
          }
        }
      }
      if (index == 0) {
        for (let k = 0; k < rawValue.length; k++) {
          let bdOrgValFc = (rawValue[index].bdOrgValFc == null) ? 0 : rawValue[index].bdOrgValFc;
          let bdOrgValFc1 = (rawValue[1].bdOrgValFc == null) ? 0 : rawValue[1].bdOrgValFc;
          let bdPerc = items.at(k).get('bdPerc').value;
          let bdGn = items.at(k).get('bdGn').value;
          var result;
          if (Number(bdPerc)) {
            if (bdGn == 'N') {
              if (bdOrgValFc > 0) {
                result = ((bdPerc * (bdOrgValFc - this.returnAlwaysPositive(bdOrgValFc1))) / 100).toFixed(4);
              } else {
                result = ((bdPerc * (bdOrgValFc - this.returnAlwaysNegetive(bdOrgValFc1))) / 100).toFixed(4);
              }
            } else {
              result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
            }
            items.at(k).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, result));
          } else if (k == 1) {
            items.at(k).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, bdOrgValFc1));
          }
        }
      }
    }
    this.calcAccPrice();
    this.sumAccCurrency();
    this.onAmountEnter();
  }
  convertedNumber(orgCurr, number) {
    return orgCurr > 0 ? -Math.abs(number) : Math.abs(number)
  }
  changeNumber(number) {
    return number > 0 ? -Math.abs(number) : Math.abs(number)
  }
  returnAlwaysNegetive(number) {
    return -Math.abs(number);
  }
  returnAlwaysPositive(number) {
    return Math.abs(number);
  }
  calcAccCurr(index) {
    let rawValue = (this.detailsTAForm.getRawValue().items)[index];
    var firstRawValue = this.detailsTAForm.getRawValue().items;
    var items = this.detailsTAForm.get('items') as UntypedFormArray;
    let bdPerc = rawValue.bdPerc;
    let bdGn = rawValue.bdGn;
    var bdOrgValFc = (firstRawValue[0].bdOrgValFc == null) ? 0 : firstRawValue[0].bdOrgValFc;
    var bdTP;
    if (this.tType == '008') {
      bdTP = (firstRawValue[1].bdOrgValFc == null) ? 0 : firstRawValue[1].bdOrgValFc;
    } else {
      bdTP = (firstRawValue[3].bdOrgValFc == null) ? 0 : firstRawValue[3].bdOrgValFc;
    }
    var result;
    if (Number(bdPerc)) {
      if (bdGn == 'N') {
        if (this.tType == '001' || this.tType == '008') {
          if (bdOrgValFc > 0) {
            result = ((bdPerc * (bdOrgValFc - this.returnAlwaysPositive(bdTP))) / 100).toFixed(4);
          } else {
            result = ((bdPerc * (bdOrgValFc - this.returnAlwaysNegetive(bdTP))) / 100).toFixed(4);
          }
        } else {
          result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
        }
      } else {
        result = ((bdPerc * bdOrgValFc) / 100).toFixed(4);
      }
      items.at(index).get('bdOrgValFc').setValue(this.convertedNumber(bdOrgValFc, result));
    } else {
      items.at(index).get('bdOrgValFc').setValue(Number(0));
    }
    this.sumAccCurrency();
    this.onAmountEnter();

    setTimeout(() => {
      this.calcAccPrice();
    }, 100);

  }

  calcAccCurrCoins(index) {
    let inx = index;
    let rawValueCoins = this.filters();
    var result;
    for (let k = 0; k < rawValueCoins.length; k++) {
      let form = rawValueCoins.value[k];
      for (let i = 0; i < form.itemCoins.length; i++) {
        let bdPerc = this.itemCoinArray(k)
          .at(inx)
          .get('bdPerc').value;
        let bdGn = this.itemCoinArray(k)
          .at(inx)
          .get('bdGn').value;
        let bdOrgValFc = this.itemCoinArray(k)
          .at(0)
          .get('bdOrgValFc').value;
        let bdOrgValFc3 = this.itemCoinArray(k)
          .at(3)
          .get('bdOrgValFc').value;
        if (Number(bdPerc)) {
          if (bdGn == 'N') {
            if (this.tType == '001') {
              if (bdOrgValFc > 0) {
                result = ((bdPerc * (bdOrgValFc - this.returnAlwaysPositive(bdOrgValFc3))) / 100).toFixed(4);
              } else {
                result = ((bdPerc * (bdOrgValFc - this.returnAlwaysNegetive(bdOrgValFc3))) / 100).toFixed(4);
              }
            } else {
              result = ((bdPerc * (bdOrgValFc)) / 100).toFixed(4);
            }
          } else {
            result = ((bdPerc * (bdOrgValFc)) / 100).toFixed(4);
          }
          this.itemCoinArray(k)
            .at(inx)
            .get('bdOrgValFc')
            .setValue(this.convertedNumber(bdOrgValFc, result));
        } else {
          this.itemCoinArray(k)
            .at(inx)
            .get('bdOrgValFc')
            .setValue(Number(0));
        }
        setTimeout(() => {
          this.calcAccPriceForCoins();
        }, 100);
      }
    }
  }

  back() {
    this.router.navigate(['/mga-ta-accounting'], { queryParams: { title: 'home' } });
  }
  close() {

  }
  missingDocType: boolean = false
  checkDocType() {
    let docType = this.uploadDoc.unsavedFiles
    for (var i = 0; i < docType.length; i++) {
      if (docType[i].entityRefType == undefined) {
        return this.missingDocType = true;
      }
    }
  }
  save(type) {
    this.mgaService.sendMGAGridLoad('reload');
    if (this.headerTAForm.valid && this.headerTAForm.valid) {
      this.missingDocType = false
      this.checkDocType();
      if (this.uploadDoc.unsavedFiles.length >= 0 && this.missingDocType == false) {
        if (this.uploadDoc.fileList.length !== 0) {
          this.uploadDoc.saveAllDocument();
        }
        this.loaderService.isBusy = true;
        if (this.contractList.length == 0) {
          this.contractId = {
            taRefNo: this.headerTAForm.get('bhTtyRefNo').value,
          };
        }
        if (this.items && this.items['controls'].length > 0) {
          if (this.items.valid) {
            let formData = this.headerTAForm.getRawValue();
            (type == 'save') ? formData.bhApprSts = 'P' : formData.bhApprSts = 'A';
            formData.bhFlex05 = this.documentRefId;
            if ('edit' === this.action || 'view' === this.action) {
              formData.bhCrDt = new Date(this.headerDetails.bhCrDt);
              formData.bhUpdId = 'admin';
              formData.bhUpdDt = new Date();
              formData.bhDueDt = moment(formData.bhDueDt, 'DD-MM-YYYY');
              formData.bhCloseDateFm = moment(formData.bhCloseDateFm, 'DD-MM-YYYY');
              formData.bhCloseDateTo = moment(formData.bhCloseDateTo, 'DD-MM-YYYY');
              formData.bhRefNo = this.contractId.taRefNo;
              formData.bhTranType = this.transType;
              formData.bhFlex02 = (this.headerTAForm.get('bhcontractId').value).key;
              let directDetailsForm = this.detailsTAForm.value.items;
              let directDetailsData = { "accountingDetails": [] };
              let coinsDetailsForm = this.accountingDetailsCoinsForm.value.mainItemCoins;
              let data = { "accountingHeader": formData };
              directDetailsForm.forEach((element, value) => {
                directDetailsData.accountingDetails.push(element);
              });
              for (let j = 0; j < directDetailsData.accountingDetails.length; j++) {
                if (directDetailsData.accountingDetails[j]["bdSrNo"]) {
                  directDetailsData.accountingDetails[j]["accountingDetailPK"] = { "bdSrNo": directDetailsData.accountingDetails[j].bdSrNo };
                } else {
                  delete directDetailsData.accountingDetails[j]["bdSrNo"];
                }
              }
              for (let i = 0; i < coinsDetailsForm.length; i++) {
                for (let j = coinsDetailsForm[i]["itemCoins"].length; j >= 0; j--) {
                  if (coinsDetailsForm[i]["itemCoins"][j] && coinsDetailsForm[i]["itemCoins"][j]['bdFlex07'] == null) {
                    coinsDetailsForm[i]["itemCoins"][j]['bdFlex07'] = this.bType;
                  }
                  if (coinsDetailsForm[i]["itemCoins"][j] && (coinsDetailsForm[i]["itemCoins"][j]["bdOrgValFc"] == 0 || coinsDetailsForm[i]["itemCoins"][j]["bdOrgValFc"] == null)) {
                    coinsDetailsForm[i]["itemCoins"].splice(j, 1);
                  }
                }
              }
              let coinsDetailsData = { "accountingDetailsCoins": coinsDetailsForm };
              let finalData;
              finalData = Object.assign(data, directDetailsData);
              finalData = Object.assign(finalData, coinsDetailsData);
              this.mgaService.updateTechAccountingHeader(this.batchId, finalData).subscribe((resp) => {
                this.toastService.success('Batch Id : ' + this.batchId + ' Successfully Saved');
                this.modalService.hide();
                this.loaderService.isBusy = false;
                this.back();
              }, error => {
                this.loaderService.isBusy = false;
                this.toastService.error(error.error);
              })
            } else {
              formData.bhCrUid = this.session.get('userId');
              formData.bhCrDt = new Date();
              formData.bhDueDt = moment(formData.bhDueDt, 'DD-MM-YYYY');
              formData.bhCloseDateFm = moment(formData.bhCloseDateFm, 'DD-MM-YYYY');
              formData.bhCloseDateTo = moment(formData.bhCloseDateTo, 'DD-MM-YYYY');
              formData.bhTranType = this.transType;
              formData.bhRefNo = this.contractId.taRefNo;
              formData.bhFlex02 = (this.headerTAForm.get('bhcontractId').value).key;
              formData.bhUpdId = this.session.get('userId');
              formData.bhUpdDt = new Date();
              if (type == 'saveAndApv') {
                formData.bhApprSts = 'A';
                formData.bhApprUid = this.session.get('userId');
                formData.bhApprDt = new Date();
              }
              let directDetailsForm = this.detailsTAForm.value.items;
              let directDetailsData = { "accountingDetails": [] };
              let coinsDetailsForm = this.accountingDetailsCoinsForm.value.mainItemCoins;
              let data = { "accountingHeader": formData };
              directDetailsForm.forEach((element, value) => {
                if (element.bdOrgValFc != null) {
                  directDetailsData.accountingDetails.push(element);
                }
              });
              for (let i = 0; i < coinsDetailsForm.length; i++) {
                for (let j = coinsDetailsForm[i]["itemCoins"].length; j >= 0; j--) {
                  if (coinsDetailsForm[i]["itemCoins"][j] && coinsDetailsForm[i]["itemCoins"][j]['bdFlex07'] == null) {
                    coinsDetailsForm[i]["itemCoins"][j]['bdFlex07'] = this.bType;
                  }
                  if (coinsDetailsForm[i]["itemCoins"][j] && (coinsDetailsForm[i]["itemCoins"][j]["bdOrgValFc"] == 0 || coinsDetailsForm[i]["itemCoins"][j]["bdOrgValFc"] == null)) {
                    coinsDetailsForm[i]["itemCoins"].splice(j, 1);
                  }
                }
              }
              let coinsDetailsData = { "accountingDetailsCoins": coinsDetailsForm };
              let finalData;
              finalData = Object.assign(data, directDetailsData);
              finalData = Object.assign(finalData, coinsDetailsData);
              if (type == 'save') {
                this.mgaService.saveTechAccountingHeaders(finalData).subscribe((resp) => {
                  this.newID = this.batchId = resp.headerId;
                  this.closeModal(6);
                  this.closeModal(7);
                  this.closeModal(8);
                  this.toastService.success('Batch Id : ' + this.batchId + ' Successfully Created');

                  this.confirmSave();
                  this.loaderService.isBusy = false;
                }, error => {
                  this.loaderService.isBusy = false;
                  this.toastService.error(error.error);
                })
              } else {
                if (Number(this.sumAccoutingCurrency == 0)) {
                  this.toastService.warning('Accounting Amount should not be 0');
                  this.loaderService.isBusy = false;
                } else {
                  if (formData.bhNetValFc == this.sumAccoutingCurrency) {
                    if (directDetailsData.accountingDetails.length == 0) {
                      this.toastService.warning('Add Technical Accounting Details before approving.');
                      this.loaderService.isBusy = false;
                    } else {
                      this.mgaService.saveTechAccountingHeaders(finalData).subscribe((resp) => {
                        this.loaderService.isBusy = true;
                        this.newID = resp.headerId;
                        this.batchId = this.newID;
                        if (this.newID) {
                          this.mgaService.approveTechAccount(this.newID, finalData).subscribe((resp: any) => {
                            if (resp["messageType"] && resp["messageType"] == 'E') {
                              this.toastService.error('Not approved');
                              this.showErrorDialogBox(resp.message);
                              this.loaderService.isBusy = false;
                            } else {
                              this.toastService.success('Batch Id : ' + this.batchId + ' Approved Successfully');
                              this.status = 'A';

                              this.fetchHeaderDetails(this.batchId);
                              this.headerTAForm.disable();
                              this.headerTAForm.disable();
                              this.isUpdate = true;
                              this.modalService.hide();
                              this.back();
                              this.loaderService.isBusy = false;
                            }
                          }, error => {
                            this.loaderService.isBusy = false;
                            this.toastService.error(error.error);
                          })
                        }
                      }, error => {
                        this.loaderService.isBusy = false;
                        this.toastService.error(error.error);
                      })
                    }

                  } else {
                    this.toastService.warning("Amount should be match with revenue amount");
                    this.loaderService.isBusy = false;
                  }
                }
              }
            }
          } else {
            MgaUtils.validateAllFormFields(this.detailsTAForm);
            this.toastService.warning('Enter Mandatory Fields');
            this.loaderService.isBusy = false;
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.warning('Please Enter Technical Accounting Details');
        }
      } else {
        this.toastService.warning('Save All Uploaded Documents');
        this.loaderService.isBusy = false;
      }

    } else {
      MgaUtils.validateAllFormFields(this.headerTAForm);
      MgaUtils.validateAllFormFields(this.headerTAForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  openSaveAndApproveModal() {
    this.open(this.saveNapproveModal8, 8, 'modal-sm');
  }
  openApproveModal() {
    if (this.headerTAForm.valid) {
      this.missingDocType = false;
      this.checkDocType();
      if (this.uploadDoc.unsavedFiles.length >= 0 && this.missingDocType == false) {
        if (this.items && this.items.valid) {
          if (this.uploadDoc.fileList.length !== 0) {
            this.uploadDoc.saveAllDocument();
          }
          let formData = this.headerTAForm.getRawValue();
          if (formData.bhNetValFc == this.sumAccoutingCurrency) {
            if ('edit' === this.action || 'view' === this.action) {
              this.open(this.apprConfirmModal5, 5, 'modal-sm');
            } else {
              this.toastService.warning('Save first');
              this.loaderService.isBusy = false;
            }
          } else {
            this.toastService.warning("Amount should be match with revenue amount");
            this.loaderService.isBusy = false;
          }

        } else {
          MgaUtils.validateAllFormFields(this.detailsTAForm);
          this.toastService.warning('Add atleast 1 Technical Account Type');
          this.loaderService.isBusy = false;
        }
      } else {
        this.toastService.warning('Save All Uploaded Documents');
        this.loaderService.isBusy = false;
      }

    } else {
      MgaUtils.validateAllFormFields(this.headerTAForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  approve() {
    this.loaderService.isBusy = true;
    let formData = this.headerTAForm.getRawValue();
    formData.bhUpdId = this.session.get('userId');
    formData.bhApprSts = 'A';
    formData.bhApprUid = this.session.get('userId');
    formData.bhUpdDt = new Date();
    formData.bhApprDt = new Date();
    formData.bhTranType = this.headerTAForm.get('bhTranType').value;
    formData.bhFlex02 = (this.headerTAForm.get('bhcontractId').value).key;
    formData.bhFlex05 = this.documentRefId;
    formData.bhRefNo = this.contractId.taRefNo;

    let directDetailsForm = this.detailsTAForm.value.items;
    let directDetailsData = { "accountingDetails": [] };
    let coinsDetailsForm = this.accountingDetailsCoinsForm.value.mainItemCoins;
    let data = { "accountingHeader": formData };
    directDetailsForm.forEach((element, value) => {
      directDetailsData.accountingDetails.push(element);
    });
    for (let j = 0; j < directDetailsData.accountingDetails.length; j++) {
      if (directDetailsData.accountingDetails[j]["bdSrNo"]) {
        directDetailsData.accountingDetails[j]["accountingDetailPK"] = { "bdSrNo": directDetailsData.accountingDetails[j].bdSrNo };
      } else {
        delete directDetailsData.accountingDetails[j]["bdSrNo"];
      }
    }
    for (let i = 0; i < coinsDetailsForm.length; i++) {
      for (let j = coinsDetailsForm[i]["itemCoins"].length; j >= 0; j--) {
        if (coinsDetailsForm[i]["itemCoins"][j] && coinsDetailsForm[i]["itemCoins"][j]['bdFlex07'] == null) {
          coinsDetailsForm[i]["itemCoins"][j]['bdFlex07'] = this.bType;
        }
        if (coinsDetailsForm[i]["itemCoins"][j] && (coinsDetailsForm[i]["itemCoins"][j]["bdOrgValFc"] == 0 || coinsDetailsForm[i]["itemCoins"][j]["bdOrgValFc"] == null)) {
          coinsDetailsForm[i]["itemCoins"].splice(j, 1);
        }
      }
    }
    let coinsDetailsData = { "accountingDetailsCoins": coinsDetailsForm };
    let finalData;
    finalData = Object.assign(data, directDetailsData);
    finalData = Object.assign(finalData, coinsDetailsData);
    if (Number(this.sumAccoutingCurrency == 0)) {
      this.toastService.warning('Accounting Amount should not be 0');
      this.loaderService.isBusy = false;
    } else {
      if (finalData.accountingDetails.length == 0) {
        this.toastService.warning('Add Technical Accounting Details before approving.');
        this.loaderService.isBusy = false;
      } else {
        this.mgaService.updateTechAccountingHeader(this.batchId, finalData).subscribe((resp) => {
          this.mgaService.approveTechAccount(this.batchId, finalData).subscribe((resp: any) => {
            if (resp["messageType"] && resp["messageType"] == 'E') {
              this.toastService.error('Not approved');
              this.showErrorDialogBox(resp.message);
              this.loaderService.isBusy = false;
            } else {
              this.toastService.success('Batch Id : ' + this.batchId + ' Approved Successfully');
              this.status = 'A';
              this.fetchHeaderDetails(this.batchId);
              this.headerTAForm.disable();
              this.detailsTAForm.disable();
              this.headerTAForm.disable();
              this.modalService.hide();
              this.isUpdate = true;
              this.back();
              this.loaderService.isBusy = false;
            }
          }, error => {
            this.loaderService.isBusy = false;
            this.toastService.error(error.error);
          })
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error);
        })
      }
    }
  }
  getTechAccTypes(contractId, docId, tType, bType, prodCode?: any) {
    this.tType = tType;
    let data = {
      "refNo": contractId,
      "batchId": docId,
      "tranType": tType,
      "busType": bType,
      "productCode": this.headerTAForm.get('bhProdCode').value
    };
    if (this.newForm == 'New') {
      this.mgaService.fetchTAAccTypes(data).subscribe((resp: any) => {
        this.techAccTypesList = resp;
        this.coinsList = this.techAccTypesList.coinsList;
        this.reinsList = this.techAccTypesList.taTypeValueListQSOnPrem;
        if (tType == '008' || tType == '009') {
          this.directListArray = this.techAccTypesList.taTypeValueListQS;
        } else {
          this.directListArray = this.techAccTypesList.taTypeValueListDirect;
        }
        if (this.coinsList.length > 0) {
          this.showCoinsurer = false;
          this.enablePreview = true;
        } else {
          this.showCoinsurer = true;
          this.enablePreviewCoins = false;
          this.enablePreview = true;
        }
        if (this.reinsList.length > 0 && tType == '001') {
          this.showReinsurer = true;
          this.enablePreviewReins = false;
        } else {
          this.showReinsurer = false;
          this.enablePreviewReins = false;
        }
        this.sumFunctionalNum = "0.00";
        this.generateRowData('auto', tType);
        this.detailsTAForm.patchValue({
          items: this.directListArray
        });
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error);
      });
    } else {
      if (this.directListArray && this.directListArray.length > 0) {
        this.generateRowData('auto', tType);
        this.detailsTAForm.patchValue({
          items: this.directListArray
        });
      }
    }
  }
  showDialogbox(data: any) {
    this.open(this.confirmModal1, 1, 'modal-sm');
  }
  showSaveDialogbox() {
    this.open(this.saveModal2, 2, 'modal-sm');
  }
  showErrorDialogBox(apprErrorMsg) {
    this.open(this.errorModal3, 3, 'modal-md');
    setTimeout(() => {
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  deleteRows(batchId) {
    this.mgaService.delteAccountingDetails(batchId).subscribe((res) => {
      this.toastService.success('Successfully Deleted');
      this.modalService.hide();
      this.loaderService.isBusy = false;
    }, err => {
      this.toastService.error(err);
      this.loaderService.isBusy = false;
    })
  }

  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }
  confirmSave() {
    this.modalService.hide();
    this.isSave = true;
    this.isUpdate = false;
    this.action = 'edit';
    this.batchId = this.newID;
    this.mgaService.fetchTechAccListById(this.batchId).subscribe(res => {
      this.headerDetails = res;
      this.headerTAForm.patchValue({
        bhDueDt: new Date(res.bhDueDt),
      });
    })
    this.back();
  }
  fetchHeaderDetails(batchId) {
    this.mgaService.fetchTechAccListById(batchId).subscribe(res => {
      this.headerDetails = res;
    })
  }

  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res;
      }, err => {
      });
  }
  setTabindex() {
    $("#transType .ng-input>input").attr("tabIndex", "1");
    $("#accCurr .ng-input>input").attr("tabIndex", "5");
    $("#netAmt .numeric-textbox>input").attr("tabIndex", "6")
    $("#netAmtLc .numeric-textbox>input").attr("tabIndex", "7")
    $("#accTo .ng-input>input").attr("tabIndex", "8");
    $("#prodGroup .ng-input>input").attr("tabIndex", "10");
    $(".navbar-brand").attr("tabIndex", "-1");
  }

  setDynamicTabIndex() {
    let c = 13
    $(".dynRow").each(function (index) {
      $(this).attr("tabIndex", c++);
    });
  }

}
function YearValidator(control: UntypedFormControl) {
  let year = control.value;
  let currentYear = new Date().getFullYear();
  if (year == '' || year == undefined) {
    return null;
  } else {
    if (year <= currentYear && year > 1999) {
      return null;
    } else {
      return {
        validYear: true
      }
    }
  }
}
