import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaWizardHelperService } from './../../services/mga-wizard.service';
import { MgaTermsDemoComponent } from './../mga-terms-demo/mga-terms-demo.component';
declare var $: any;

@Component({
  selector: 'mga-wizard',
  templateUrl: './mga-wizard.component.html',
  styleUrls: ['./mga-wizard.component.scss']
})
export class MgaWizardComponent implements OnInit {
  wizards: any[];
  currentWizard: any;
  showContractInfoScreen: boolean = false;
  showCompanyLOBScreen: boolean = false;
  showOutwardReinsurance: boolean = false;
  public canEnterStep2Backwards = true;
  public canEnterStep2Forwards = true;

  public canEnterStep1Forwards = true;
  public canEnterStep1BackWard = true;

  public canEnterStep3Forwards = false;
  public canEnterStep3Backwards = true;

  public canEnterStep4Forwards = false;
  public canEnterStep4Backwards = true;
  contractRefNo: any;
  versionNo: any;
  mgaCode: any;
  mgaYear: any;
  seqNo: any;
  productSrNo: any;
  action: any;
  contType: any;
  status: any;
  showChild_TabScreen: boolean = false;
  epi_TabScreen: boolean = false;
  terms_TabScreen: boolean = false;
  busineessRules_TabScreen: boolean = false;
  coInsurance_TabScreen: boolean = false;
  lobSrNo: any;
  passedDataToChild: any;
  amendSrNo: any;
  lobInfo: any;
  prodInfo: any;
  @ViewChild(MgaTermsDemoComponent) mgaTermsDemo: MgaTermsDemoComponent;
  modalRef: BsModalRef;
  @ViewChild('errorModal') errorModal: ElementRef;
  constructor(
    private router: Router,
    private wizardHelper: MgaWizardHelperService,
    private loaderService: LoaderService,
    private mgaService: MgaContractService,
    private session: SessionStorageService,
    private toastService: ToastService,
    private modalService: BsModalService,
    private modalService1: BsModalService,

  ) { }

  ngOnInit() {
    this.contractRefNo = this.mgaService.getParamValue('refNo');
    this.versionNo = Number(this.mgaService.getParamValue('amendNo'));
    this.seqNo = Number(this.mgaService.getParamValue('seqNo'));
    this.action = this.mgaService.getParamValue('action');
    this.contType = this.mgaService.getParamValue('type');
    this.status = this.mgaService.getParamValue('status');
    this.amendSrNo = this.mgaService.getParamValue('amendSrNo');
    this.amendSrNo = (this.amendSrNo == undefined) ? 0 : this.amendSrNo;
    this.wizards = [
      { displayText: 'Contract Info', displayValue: 'Step1' },
      { displayText: 'Company / LOB', displayValue: 'Step2' },
      { displayText: 'Outward Reinsurance', displayValue: 'Step3' }
    ];
    this.currentWizard = 'Step1';
    this.wizardHelper.context = this;
    this.wizardHelper.next = this.onNext;
    this.wizardHelper.previous = this.onPrevious;
    this.wizardHelper.finish = this.onFinish;
  }
  onNext(): void {
    const currentIndex = this.wizards.findIndex(wizard => wizard.displayValue === this.currentWizard);
    if ((currentIndex >= 0) && (currentIndex < (this.wizards.length - 1))) {
      this.currentWizard = this.wizards[currentIndex + 1].displayValue;
      this.canEnterStep(currentIndex + 2, 'Forward');
    }
  }
  onPrevious(): void {
    const currentIndex = this.wizards.findIndex(wizard => wizard.displayValue === this.currentWizard);
    if ((currentIndex > 0) && (currentIndex < (this.wizards.length))) {
      this.currentWizard = this.wizards[currentIndex - 1].displayValue;
      this.canEnterStep(currentIndex, 'Backward');
    }
  }
  onFinish(): void {
    this.approve();
  }
  canEnterStep(step: any, direction: string) {
    switch (step.toString()) {
      case '1': {
        if (direction === 'Forward') {
          this.showContractInfoScreen = true;
        } else {
          this.showContractInfoScreen = true;
        }
        break;
      }
      case '2': {
        if (direction === 'Forward') {
          if (this.canEnterStep2Forwards) {
            this.showContractInfoScreen = false;
          }
        } else {
          this.showContractInfoScreen = true;
          this.showCompanyLOBScreen = true;
          this.showOutwardReinsurance = false;
        }
        break;
      }
      case '3': {
        if (direction === 'Forward') {
          this.showOutwardReinsurance = false;
        } else {
          this.showOutwardReinsurance = true;
          return this.canEnterStep3Backwards;
        }
        break;
      }
    }
  }
  wizardSelectionChange(event) {
    this.currentWizard = event;
  }
  tabswitch(e) {
    if (!e || !e.heading) {
      return;
    }
    if (e.heading === 'EPI') {
      this.showChild_TabScreen = true;
      this.epi_TabScreen = true;
      this.terms_TabScreen = false;
      this.busineessRules_TabScreen = false;
      this.coInsurance_TabScreen = false;

    } else if (e.heading === 'Terms') {
      this.showChild_TabScreen = true;
      this.epi_TabScreen = false;
      this.terms_TabScreen = true;
      this.busineessRules_TabScreen = false;
      this.coInsurance_TabScreen = false;
      this.mgaTermsDemo.getTermData('PS');
    } else if (e.heading === 'Business Rules') {
      this.showChild_TabScreen = true;
      this.epi_TabScreen = false;
      this.terms_TabScreen = false;
      this.busineessRules_TabScreen = true;
      this.coInsurance_TabScreen = false;
    } else {
      this.showChild_TabScreen = true;
      this.epi_TabScreen = false;
      this.terms_TabScreen = false;
      this.busineessRules_TabScreen = false;
      this.coInsurance_TabScreen = true;
      this.mgaTermsDemo.getTermData('IC');
    }
  }
  retrieveSavedData(event) {
    if (event == "error") {
      this.canEnterStep2Backwards = false;
      this.canEnterStep2Forwards = false;
      this.showContractInfoScreen = true;
      this.showCompanyLOBScreen = false;
    } else if (event == "error2") {
      this.canEnterStep2Backwards = false;
      this.canEnterStep2Forwards = false;
      this.showCompanyLOBScreen = true;
    } else if (event == "ermaxShareror") {
      this.canEnterStep2Backwards = false;
      this.canEnterStep2Forwards = false;
      this.showCompanyLOBScreen = true;
    } else {
      this.passedDataToChild = {
        biStartDt: event.biStartDt,
        biEndDt: event.biEndDt,
        biBusType: event.biBusType,
        biRefNo: event.biRefNo
      };
      console.log(this.passedDataToChild);
      this.canEnterStep2Forwards = true;
      this.canEnterStep2Backwards = true;
      this.contractRefNo = event.biRefNo;
      this.versionNo = event.biAmendNo;
      this.contType = event.biContractType;
      this.mgaCode = event.biMga;
      this.mgaYear = event.biUwYear
    }
  }
  lobRowDetailEvent(event) {
    console.log(event);
    this.productSrNo = event.binderLobPK.bpProdSrNo;
    this.lobInfo = {
      bpCompCode: event.bpCompCode,
      bpLobCode: event.bpLobCode,
      bpProdCode: event.bpProdCode,
      bpCompCodeDesc: event.bpCompCodeDesc,
      bpLobCodeDesc: event.bpLobCodeDesc,
      bpProdCodeDesc: event.bpProdCodeDesc
    };
    this.prodInfo = event;
  }
  sendLOBDetail_Id(event) {
    if ("0" != event) {
      this.lobSrNo = event;
      this.showChild_TabScreen = false;
      setTimeout(() => {
        this.showChild_TabScreen = true;
      }, 300);
    } else {
      this.showChild_TabScreen = false;
    }
  }
  approve() {
    this.approveContract();
    // this.mgaService.approveValidation(this.contractRefNo, this.seqNo, this.versionNo).subscribe(res => {
    //   if (res.isProductAdded == true) {
    //     if (res.isEpiAdded == true) {
    //       if (this.passedDataToChild.biBusType == '2') {
    //         if (res.isCoinsAdded == true) {
    //           if (this.versionNo !== 0) {
    //             if (res.isCorrectionDone == true) {
    //               this.approveContract();
    //             } else {
    //               this.toastService.error('No Amendent is Added');
    //               this.loaderService.isBusy = false;
    //             }
    //           } else {
    //             this.approveContract();
    //           }
    //         } else {
    //           this.toastService.error('No Coinsurance is Added');
    //           this.loaderService.isBusy = false;
    //         }
    //       } else {
    //         if (this.versionNo !== 0) {
    //           if (res.isCorrectionDone == true) {
    //             this.approveContract();
    //           } else {
    //             this.toastService.error('No Amendent is Added');
    //             this.loaderService.isBusy = false;
    //           }
    //         } else {
    //           this.approveContract();
    //         }
    //       }
    //     } else {
    //       this.toastService.error('No Epi is Added');
    //       this.loaderService.isBusy = false;
    //     }
    //   } else {
    //     this.toastService.error('No Product is Added');
    //     this.loaderService.isBusy = false;
    //   }
    // })
  }
  openModal(content, val) {
    this.modalRef = this.modalService1.show(content, { class: val });
  }
  closeModal() {
    this.modalRef.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.modalService.hide();
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  approveContract() {
    this.loaderService.isBusy = true;
    let obj = {
      binderOutwardPK: {
        boRefNo: this.contractRefNo,
        boAmendNo: this.versionNo,
        boSeqNo: this.seqNo
      },
      boStatus: 'A',
      boUpdDt: new Date(),
      boUpdUid: this.session.get('userId')
    }
    this.mgaService.approveContract(this.contractRefNo, obj).subscribe(resp => {
      this.toastService.success(this.contractRefNo + " Approved Successfully");
      this.modalService.hide();
      this.action = 'view';
      this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
      this.loaderService.isBusy = false;
    }, error => {
      if (error instanceof HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in upload!");
        } else {
          switch (error.status) {
            case 400:
              this.loaderService.isBusy = false;
              this.showErrorDialogBox(error.error.message);
              this.modalService.hide();
              break;
            default:
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
              break;
          }
        }
      } else {
        this.loaderService.isBusy = false;
        this.toastService.error("Error in upload!");
      }
    })
  }
}
