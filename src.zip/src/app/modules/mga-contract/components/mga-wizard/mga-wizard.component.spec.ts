import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-wizard/mga-wizard.component.spec.ts
import { MgaWizardComponent } from './mga-wizard.component';

describe('MgaWizardComponent', () => {
  let component: MgaWizardComponent;
  let fixture: ComponentFixture<MgaWizardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaWizardComponent ]
=======
import { TrustFundComponent } from './trust-fund.component';

describe('TrustFundComponent', () => {
  let component: TrustFundComponent;
  let fixture: ComponentFixture<TrustFundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrustFundComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/trust-fund/trust-fund.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-wizard/mga-wizard.component.spec.ts
    fixture = TestBed.createComponent(MgaWizardComponent);
=======
    fixture = TestBed.createComponent(TrustFundComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/trust-fund/trust-fund.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
