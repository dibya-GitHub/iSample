import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { RadiorenderComponent2 } from '../radiorender/radiorender2.component';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';
import { RadiorenderComponent3 } from './../radiorender/radiorender3.component';

@Component({
  selector: 'mga-view-contract',
  templateUrl: './view-contract.component.html',
  styleUrls: ['./view-contract.component.scss'],
})
export class ViewContractComponent implements OnInit {

  @Input() amendmendData: any;
  contractInfoForm: UntypedFormGroup;
  action: any;
  refNo: any;
  amendNo: any;
  userId: any;
  seqNo: any;
  contractType: any;
  contractInfo: any;
  createdDate: any;
  showChild_TabScreen: boolean = false;
  epi_TabScreen: boolean = false;
  terms_TabScreen: boolean = false;
  busineessRules_TabScreen: boolean = false;
  coInsurance_TabScreen: boolean = false;
  coInsurance_childTabScreen: boolean = false;
  lobSrNo: any;

  //companyLOB
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;
  applicableProductList: any;

  //companyLOB -- EPI
  quickSearchValueEPI: string = '';
  showEntriesOptionsEPI = [10, 20, 50, 100];
  showEntriesOptionSelectedEPI = 10;
  public gridOptionsEPI;
  public defaultColDefEPI;
  private gridColumnApiEPI;
  columnDefsEPI = [];
  public componentsEPI;
  public getRowHeightEPI;
  public getRowStyleEPI;
  lobEpiList: any;
  pinnedBottomRowData: any;
  //companyLOB -- EPI

  //companyLOB --Coinsurance 
  quickSearchValueCoinsurance: string = '';
  showEntriesOptionsCoinsurance = [10, 20, 50, 100];
  showEntriesOptionSelectedCoinsurance = 10;
  public gridOptionsCoinsurance;
  public defaultColDefCoinsurance;
  private gridColumnApiCoinsurance;
  columnDefsCoinsurance = [];
  public componentsCoinsurance;
  public getRowHeightCoinsurance;
  public getRowStyleCoinsurance;
  coinsuereList: any = [];
  context1: any;
  frameworkComponents1: any;

  bottomColumns: any;
  bottomColumnsApplCont: any;
  bottomData: any[];
  bottomDataApplCont: any[];
  columnDefsCoinsuranceExpenses: any = [];
  coinsExpenseData: any;
  coinsExpInfo: any;
  infoLoading: boolean = false;
  coinsXolCostData: any;
  maxSharePerc: number = 0;
  shareOn: any;
  showCoinsurance: boolean = false;
  //companyLOB --Coinsurance 

  //companyLOB --BussinessRules_premium 

  quickSearchValueBRules_premium: string = '';
  showEntriesOptionsBRules_premium = [10, 20, 50, 100];
  showEntriesOptionSelectedBRules_premium = 10;
  public gridOptionsBRules_premium;
  public defaultColDefBRules_premium;
  private gridColumnApiBRules_premium;
  columnDefsBRules_premium = [];
  public componentsBRules_premium;
  public getRowHeightBRules_premium;
  public getRowStyleBRules_premium;
  premiumListData: any;

  //companyLOB --BussinessRules_premium 

  //companyLOB --BussinessRules_discount 
  quickSearchValueBRules_discount: string = '';
  showEntriesOptionsBRules_discount = [10, 20, 50, 100];
  showEntriesOptionSelectedBRules_discount = 10;
  public gridOptionsBRules_discount;
  public defaultColDefBRules_discount;
  private gridColumnApiBRules_discount;
  columnDefsBRules_discount = [];
  public componentsBRules_discount;
  public getRowHeightBRules_discount;
  public getRowStyleBRules_discount;
  discountListData: any;
  //companyLOB --BussinessRules_discount

  //companyLOB --BussinessTerms_Minimum 
  quickSearchValueTerms_Minimum: string = '';
  showEntriesOptionsTerms_Minimum = [10, 20, 50, 100];
  showEntriesOptionSelectedTerms_Minimum = 10;
  public gridOptionsTerms_Minimum;
  public defaultColDefTerms_Minimum;
  private gridColumnApiTerms_Minimum;
  columnDefsTerms_Minimum = [];
  public componentsTerms_Minimum;
  public getRowHeightTerms_Minimum;
  public getRowStyleTerms_Minimum;
  termsMinCommData: any;
  termContractData_Coins: any;
  //companyLOB --BussinessTerms_Minimum

  //companyLOB --BussinessTerms_Advance 
  quickSearchValueTerms_Contract: string = '';
  showEntriesOptionsTerms_Contract = [10, 20, 50, 100];
  showEntriesOptionSelectedTerms_Contract = 10;
  public gridOptionsTerms_Contract;
  public defaultColDefTerms_Contract;
  private gridColumnApiTerms_Contract;
  columnDefsTerms_Contract = [];
  public componentsTerms_Contract;
  public getRowHeightTerms_Contract;
  public getRowStyleTerms_Contract;
  termContractData: any;

  //companyLOB --BussinessTerms_XOL 
  quickSearchValueTerms_XOL: string = '';
  showEntriesOptionsTerms_XOL = [10, 20, 50, 100];
  showEntriesOptionSelectedTerms_XOL = 10;
  public gridOptionsTerms_XOL;
  public defaultColDefTerms_XOL;
  private gridColumnApiTerms_XOL;
  columnDefsTerms_XOL = [];
  public componentsTerms_XOL;
  public getRowHeightTerms_XOL;
  public getRowStyleTerms_XOL;
  termXolCostData: any;
  lobInfo: any;
  //companyLOB --BussinessTerms_XOL
  //Outward reinsurance

  outwardReinsuraceList: any;
  outwardColumnDefs: any;
  baseCurrency;

  quickSearchValueCoins_Expenses: string = '';
  showEntriesOptionsCoins_Expenses = [10, 20, 50, 100];
  showEntriesOptionSelectedCoins_Expenses = 10;
  public gridOptionsCoins_Expenses;
  public defaultColDefCoins_Expenses;
  private gridColumnApiCoins_Expenses;
  public componentsCoins_Expenses;
  public getRowHeightCoins_Expenses;
  public getRowStyleCoins_Expenses;

  profitShareTerm: UntypedFormGroup;
  termCommData: any;
  freqList: any;

  profitCommForm: UntypedFormGroup;
  SSCForm: UntypedFormGroup;
  slidingScaleRateForm: UntypedFormGroup;
  coinsuranceTermData: any;
  slidingScaleRateList: any;
  public columnDefsSSC;
  gridApi: any;
  epiGridApi: any;
  terms_minGridApi: any;
  terms_contractGridApi: any;
  business_premiumGridApi: any;
  business_discountGridApi: any;
  coinsuranceGridApi: any;
  coinsurance_expenseGridApi: any;
  coinsurance_termGridApi: any;
  termsGridApi: any;
  sliding_scaleGridApi: any;
  outward_reinsuranceGridApi: any;

  bpSumEpiInGbp: any;
  bpMgaCommission: any;

  constructor(
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private mgaService: MgaContractService,
    private session: SessionStorageService,

  ) {
    this.baseCurrency = this.session.get('baseCurrency');
    this.columnDefsSSC = [
      {
        headerName: "Loss Ratio From",
        headerTooltip: "Loss Ratio From",
        field: "bsMinLrPerc",
        width: 270,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
      },
      {
        headerName: "Loss Ratio To",
        headerTooltip: "Loss Ratio To",
        field: "bsMaxLrPerc",
        width: 270,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
      },
      {
        headerName: "Applicable Commission",
        headerTooltip: "Applicable Commission",
        field: "bsCommPerc",
        width: 270,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
      }
    ];
    this.columnDefs = [
      {
        headerName: "Select",
        field: 'binderLobPK.bpProdSrNo',
        cellRenderer: "radioButtonRenderer2",
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        headerName: "Company",
        field: "bpCompCodeDesc",
        sortable: true,
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.bpCompCode) {
            return params.data.bpCompCode + " - " + params.data.bpCompCodeDesc;
          } else {
            return '';
          }
        },
      },
      {
        headerName: "LOB",
        field: "bpLobCodeDesc",
        sortable: true,
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.bpLobCode) {
            return params.data.bpLobCode + " - " + params.data.bpLobCodeDesc;
          } else {
            return '';
          }
        },
      },
      {
        headerName: "Product",
        field: "bpProdCodeDesc",
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.bpProdCode) {
            return params.data.bpProdCode + " - " + params.data.bpProdCodeDesc;
          } else {
            return '';
          }
        },
      },
      {
        headerName: "EPI in functional currency (GBP)",
        field: "bpSumEpiInGbp",
        enableRowGroup: true,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.bpSumEpiInGbp) {
            return Number(params.data.bpSumEpiInGbp).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params && params.data && params.data.bpSumEpiInGbp == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        headerName: "MGA Commission",
        field: "bpMgaCommission",
        enableRowGroup: true,
        valueFormatter: MgaUtils.toFixedFun4,
        cellStyle: { textAlign: 'right' },
        headerClass: "grid-cell-centered",
      }
    ];
    this.bottomColumnsApplCont = [
      {
        headerName: "Select",
        field: 'binderLobPK.bpProdSrNo',
      },
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "bpCompCodeDesc",
      },
      {
        headerName: "LOB",
        headerTooltip: 'LOB',
        field: "bpLobCodeDesc",
      },
      {
        headerName: "Product",
        headerTooltip: "Product",
        field: "bpProdCodeDesc",
      },
      {
        headerName: "EPI in functional currency (GBP)",
        headerTooltip: "EPI in functional currency (GBP)",
        field: "bpSumEpiInGbp",
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.toFixedFun,
      },
      {
        headerName: "MGA Commission",
        headerTooltip: "MGA Commission",
        field: "bpMgaCommission",
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.toFixedFun4,
      }
    ];
    this.columnDefsEPI = [
      {
        headerName: "Region",
        field: "beRegionCode",
        valueGetter: function (params) {
          if (params.data.beRegionCode != null && params.data.beRegionCode != undefined) {
            return params.data.beRegionCode + " - " + params.data.beRegionCodeDesc;
          } else {
            return params.data.beRegionCodeDesc;
          }
        },
        sortable: true,
        enableRowGroup: true
      },
      {
        headerName: "Currency",
        field: "beCurrCode",
        valueGetter: function (params) {
          if (params.data.beCurrCode != null && params.data.beCurrCode != undefined) {
            return params.data.beCurrCode + " - " + params.data.beCurrCodeDesc;
          } else {
            return params.data.beCurrCodeDesc;
          }
        },
        sortable: true,
        enableRowGroup: true
      },
      {
        headerName: "EPI",
        field: "beEpiFc",
        valueFormatter: MgaUtils.toFixedFun,
        enableRowGroup: true,
        width: 250,
        cellStyle: { textAlign: 'right' },
        headerClass: "grid-cell-centered",
      },
      {
        headerName: "EPI in functional currency (" + this.baseCurrency + ")",
        headerTooltip: "EPI in functional currency (" + this.baseCurrency + ")",
        field: "beEpiLc1",
        valueFormatter: MgaUtils.toFixedFun,
        enableRowGroup: true,
        cellStyle: { textAlign: 'right' },
        headerClass: "grid-cell-centered",
      },
    ];
    this.columnDefsCoinsurance = [
      {
        headerName: "Select",
        field: 'binderCoinsPK.bcSrNo',
        cellRenderer: "radioButtonRenderer3",
        cellStyle: { textAlign: 'center' },
        width: 100,
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },
      {
        headerName: "Coinsurer",
        headerTooltip: "Coinsurer",
        field: "bcCustCodeShortDesc",
        width: 290,
      },
      {
        headerName: "Leader",
        headerTooltip: "Leader",
        field: "bcLeaderYn",
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === '1') {
            return '<span class="ag-element"> Yes </span>';
          } else if (params.value === '0') {
            return '<span class="ag-element"> No </span>';
          }
        },
      },
      {
        headerName: "Share %",
        headerTooltip: "Share %",
        field: "bcSharePerc",
        valueFormatter: MgaUtils.currencyFormatter4,
        cellStyle: { textAlign: 'right' },
      },
    ];

    this.columnDefsCoinsuranceExpenses = [
      {
        headerName: "Percentage",
        headerTooltip: "Percentage",
        field: "btCommPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
        width: 250,
      },
      {
        headerName: "Type",
        headerTooltip: "Type",
        field: "btRecPayType",
        width: 250,
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'R') {
            return '<span class="ag-element"> Receivable </span>';
          } else if (params.value === 'P') {
            return '<span class="ag-element"> Payable </span>';
          }
        },
      },
      {
        headerName: "Effective From",
        headerTooltip: "Effective From",
        field: "btEffFmDt",
        cellStyle: { textAlign: 'left' },
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffFmDt) {
            return moment(params.data.btEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        headerName: "Effective To",
        headerTooltip: "Effective To",
        field: "btEffToDt",
        cellStyle: { textAlign: 'left' },
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffToDt) {
            return moment(params.data.btEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
    ];
    this.bottomColumns = [
      {
        headerName: "Select",
        field: 'binderCoinsPK.bcProdSrNo',
        width: 100,
      },
      {
        headerName: "Coinsurer",
        field: "bcCustCodeShortDesc",
        width: 290,
      },
      {
        headerName: "Leader",
        field: "bcLeaderYn",
      },
      {
        headerName: "Share %",
        field: "bcSharePerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter4
      },
    ];

    this.columnDefsBRules_premium = [
      {
        headerName: "Min Rate",
        field: "brMinRate",
        sortable: true,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,

      },
      {
        headerName: "Max Rate",
        field: "brMaxRate",
        sortable: true,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
      },
      {
        headerName: "Severity",
        field: "brSeverityDesc",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Effective From",
        field: "brEffFmDt",
        // valueFormatter: MgaUtils.dateFormatter,
        width: 250,
        valueGetter: function (params) {
          if (params && params.data && params.data.brEffFmDt) {
            return moment(params.data.brEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }

      },
      {
        headerName: "Effective To",
        field: "brEffToDt",
        width: 250,
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffToDt) {
            return moment(params.data.btEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
    ];

    this.columnDefsTerms_Minimum = [
      {
        headerName: "Term Type",
        field: "btTypeDesc",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Notes / Remarks",
        field: "btRemarks",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Based On",
        field: "btBasedOnDesc",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Rate %",
        field: "btCommPerc",
        sortable: true,
        valueFormatter: MgaUtils.currencyFormatter4,
        headerClass: "grid-cell-centered",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Effective From",
        field: "btEffFmDt",
        width: 250,
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffFmDt) {
            return moment(params.data.btEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        headerName: "Effective To",
        field: "btEffToDt",
        width: 250,
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffToDt) {
            return moment(params.data.btEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      }
    ];
    this.columnDefsTerms_Contract = [
      {
        headerName: "Term Type",
        field: "btTypeDesc",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Notes / Remarks",
        field: "btRemarks",
        sortable: true,
      },
      {
        headerName: "Intermediary",
        field: "btIntBrkCodeDesc",
        sortable: true,
      },
      {
        headerName: "Based On",
        field: "btBasedOnDesc",
        sortable: true,
      },
      {
        headerName: "Rate %",
        field: "btCommPerc",
        sortable: true,
        valueFormatter: MgaUtils.currencyFormatter4,
        cellStyle: { textAlign: 'right' },
        headerClass: "grid-cell-centered",
      },
      {
        headerName: "Effective From",
        field: "btEffFmDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffFmDt) {
            return moment(params.data.btEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        headerName: "Effective To",
        field: "btEffToDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffToDt) {
            return moment(params.data.btEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      }
    ];
    this.columnDefsTerms_XOL = [
      {
        headerName: "Term Type",
        field: "btTypeDesc",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Notes / Remarks",
        field: "btRemarks",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Based On",
        field: "btBasedOnDesc",
        sortable: true,
        cellStyle: { textAlign: 'left' },
      },
      {
        headerName: "Rate %",
        field: "btCommPerc",
        sortable: true,
        valueFormatter: MgaUtils.currencyFormatter4,
        cellStyle: { textAlign: 'right' },
        headerClass: "grid-cell-centered",
      },
      {
        headerName: "Effective From",
        field: "btEffFmDt",
        width: 250,
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffFmDt) {
            return moment(params.data.btEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        headerName: "Effective To",
        field: "btEffToDt",
        width: 250,
        valueGetter: function (params) {
          if (params && params.data && params.data.btEffToDt) {
            return moment(params.data.btEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      }

    ];
    this.outwardColumnDefs = [
      {
        headerName: "Company / LOB / Product",
        field: "boCompClassProductDesc",
        enableRowGroup: true,
        width: 400,
        cellRenderer: MgaUtils.tooltipRenderer,
      },
      {
        headerName: "Contract Type",
        field: "boContractType",
        enableRowGroup: true,
      },
      {
        headerName: "Allocation Order",
        field: "boAllocOrder",
        enableRowGroup: true,
        width: 140
      },
      {
        headerName: "Outward Contract Ref",
        field: "bpCompCode",
        cellRenderer: MgaUtils.tooltipRenderer,
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.boContractRefDesc;
          }
        }
      },
      {
        headerName: "Share / Limit",
        field: "boShare",
        enableRowGroup: true,
        width: 100,
        valueFormatter: MgaUtils.currencyFormatter,
        cellStyle: function (params) {
          if ((params.data.boTtyContType).slice(-1) == 'X') {
            return { textAlign: 'right' };
          } else {
            return { textAlign: 'left' };
          }
        },
      },
    ]
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.defaultColDefEPI = this.defaultColDefTerms_Contract = this.defaultColDefCoinsurance = this.defaultColDefBRules_premium = this.defaultColDefBRules_discount = this.defaultColDefTerms_Minimum = this.defaultColDefTerms_XOL = this.defaultColDefCoins_Expenses = this.defaultColDef;
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    console.log(this.amendmendData);
    if (this.amendmendData == undefined) {
      this.action = this.mgaService.getParamValue('action');
      this.refNo = this.mgaService.getParamValue('refNo');
      this.amendNo = this.mgaService.getParamValue('amendNo');
      this.seqNo = this.mgaService.getParamValue('seqNo');
      this.contractType = this.mgaService.getParamValue('contractType');
    } else {
      this.amendNo = this.amendmendData.amendNo;
      this.refNo = this.amendmendData.refNo;
      this.seqNo = this.amendmendData.seqNo;
    }
    this.userId = this.session.get('userName');
    this.createContractInfoForm();
    this.agGridOptions();
    this.createProfitShareForm();
    this.createSlidingScaleRateForm();
    this.createProfitCommTable();
    this.createSSCFormTable();
  }
  createProfitShareForm() {
    this.profitShareTerm = this.fb.group({
      btPsFirstEvlDt: [undefined],
      btPsLastEvlDt: [undefined],
      btPsEvlFrq: [undefined],
      btPsFirstPc: [undefined],
      btPsInsExp: [undefined],
      btPsInsFirstPc: [undefined],
      btPsInsLastPc: [undefined],
      btPsIntLicFees: [undefined],
      btPsMgaFprcPc: [undefined],
      btPsMgaLastPc: [undefined],
      btPsYn: ['']
    })
    this.getFreqList();
  }
  createSSCFormTable() {
    this.SSCForm = this.fb.group({
      btSscProv: [undefined],
      btSscEvlFrq: [undefined],
      btSscFirstEvlDt: [undefined],
      btSscLastEvlDt: [undefined],
      btSscYn: [''],
    })
  }
  createSlidingScaleRateForm() {
    this.slidingScaleRateForm = this.fb.group({
      btSscMinLr: [undefined],
      btSscMaxLr: [undefined],
      btSscLrDiff: [undefined],
      btSscMinComm: [undefined],
      btSscMaxComm: [undefined],
      btSscCommDiff: [undefined],
      btSscYn: ['']
    })
  }
  createProfitCommTable() {
    this.profitCommForm = this.fb.group({
      btPcEvlFrq: [undefined],
      btPcFirstEvlDt: [undefined],
      btPcLastEvlDt: [undefined],
      btPcFinalPerc: [undefined],
      btPcMePerc: [undefined],
      btPcProvPerc: [undefined],
      btPcYn: [''],
    })

  }
  getFreqList() {
    this.mgaService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
      this.freqList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    })
  }
  getTermData(custCode, commType) {
    let type = (commType == 'PS') ? 'TERMS' : 'COTERMS';
    this.mgaService.getTermCommType(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, type, custCode, commType).subscribe(resp => {
      this.termCommData = resp.termCommList;

      if (this.termCommData.length > 0) {
        if (commType == 'PS') {
          this.profitShareTerm.patchValue({
            btPsFirstEvlDt: (this.termCommData[0].btPsFirstEvlDtmoment == null) ? '' : (this.termCommData[0].btPsFirstEvlDt).format('DD-MM-YYYY HH:mm'),
            btPsLastEvlDt: (this.termCommData[0].btPsLastEvlDt == null) ? '' : moment(this.termCommData[0].btPsLastEvlDt).format('DD-MM-YYYY HH:mm'),
            btPsEvlFrq: this.termCommData[0].btPsEvlFrq,
            btPsFirstPc: this.termCommData[0].btPsFirstPc,
            btPsInsExp: this.termCommData[0].btPsInsExp,
            btPsInsFirstPc: this.termCommData[0].btPsInsFirstPc,
            btPsInsLastPc: this.termCommData[0].btPsInsLastPc,
            btPsIntLicFees: this.termCommData[0].btPsIntLicFees,
            btPsMgaFprcPc: this.termCommData[0].btPsMgaFprcPc,
            btPsMgaLastPc: this.termCommData[0].btPsMgaLastPc
          })
          this.profitShareTerm.get('btPsYn').setValue((this.termCommData[0].btPsYn === 'Y'));
          this.profitShareTerm.disable();
        } else if (commType == 'PC') {
          this.profitCommForm.patchValue({
            btPcEvlFrq: this.termCommData[0].btPcEvlFrq,
            btPcFirstEvlDt: (this.termCommData[0].btPcFirstEvlDt == null) ? '' : moment(this.termCommData[0].btPcFirstEvlDt).format('DD-MM-YYYY HH:mm'),
            btPcLastEvlDt: (this.termCommData[0].btPcLastEvlDt == null) ? '' : moment(this.termCommData[0].btPcLastEvlDt).format('DD-MM-YYYY HH:mm'),
            btPcFinalPerc: this.termCommData[0].btPcFinalPerc,
            btPcMePerc: this.termCommData[0].btPcMePerc,
            btPcProvPerc: this.termCommData[0].btPcProvPerc,
          })
          this.profitCommForm.get('btPcYn').setValue((this.termCommData[0].btPcYn === 'Y'));
          this.profitCommForm.disable();

        } else if (commType == 'SSC') {
          this.SSCForm.patchValue({
            btSscProv: this.termCommData[0].btSscProv,
            btSscEvlFrq: this.termCommData[0].btSscEvlFrq,
            btSscFirstEvlDt: (this.termCommData[0].btSscFirstEvlDt == null) ? '' : moment(this.termCommData[0].btSscFirstEvlDt).format('DD-MM-YYYY HH:mm'),
            btSscLastEvlDt: (this.termCommData[0].btSscLastEvlDt == null) ? '' : moment(this.termCommData[0].btSscLastEvlDt).format('DD-MM-YYYY HH:mm'),
          })
          this.slidingScaleRateForm.patchValue({
            btSscMinLr: this.termCommData[0].btSscMinLr,
            btSscMaxLr: this.termCommData[0].btSscMaxLr,
            btSscLrDiff: this.termCommData[0].btSscLrDiff,
            btSscMinComm: this.termCommData[0].btSscMinComm,
            btSscMaxComm: this.termCommData[0].btSscMaxComm,
            btSscCommDiff: this.termCommData[0].btSscCommDiff,
          })

          this.SSCForm.get('btSscYn').setValue((this.termCommData[0].btSscYn === 'Y'));
          this.SSCForm.disable();
          this.slidingScaleRateForm.disable();

        }
      } else {
        if (commType == 'PS') {
          this.profitShareTerm.patchValue({
            btPsFirstEvlDt: null,
            btPsLastEvlDt: null,
            btPsEvlFrq: null,
            btPsFirstPc: null,
            btPsInsExp: null,
            btPsInsFirstPc: null,
            btPsInsLastPc: null,
            btPsIntLicFees: null,
            btPsMgaFprcPc: null,
            btPsMgaLastPc: null
          })
          this.profitShareTerm.get('btPsYn').setValue(false);
          this.profitShareTerm.get('btPsYn').enable();
        } else if (commType == 'SSC') {
          this.SSCForm.patchValue({
            btSscProv: null,
            btSscEvlFrq: null,
            btSscFirstEvlDt: null,
            btSscLastEvlDt: null,
          })
          this.slidingScaleRateForm.patchValue({
            btSscMinLr: null,
            btSscMaxLr: null,
            btSscLrDiff: null,
            btSscMinComm: null,
            btSscMaxComm: null,
            btSscCommDiff: null,
          })
          this.SSCForm.get('btSscYn').setValue(false);
          this.SSCForm.get('btSscYn').enable();
        } else if (commType == 'PC') {
          this.profitCommForm.patchValue({
            btPcEvlFrq: null,
            btPcFirstEvlDt: null,
            btPcLastEvlDt: null,
            btPcFinalPerc: null,
            btPcMePerc: null,
            btPcProvPerc: null,
          })
          this.profitCommForm.get('btPcYn').setValue(false);
          this.profitCommForm.get('btPcYn').enable();
        }
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getTermSSCgridData(custCode) {
    this.slidingScaleRateList = [];
    this.mgaService.getTermCommType(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'COTERMS', custCode, 'SSC').subscribe(resp => {
      this.slidingScaleRateList = resp.sscList;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }

  createContractInfoForm() {
    this.contractInfoForm = this.fb.group({
      biAmendNo: this.amendNo,
      biRefNo: this.refNo,
      biSeqNo: this.seqNo,
      biContractPeriod: [''],
      biAmendEndDt: [''],
      biAmendStartDt: [''],
      biAmendType: [''],
      biApprDt: [''],
      biApprSts: [''],
      biApprUid: [''],
      biCanDt: [''],
      biCanNotifyDays: [''],
      biContractType: [''],
      biCrDt: new Date(),
      biCrUid: this.userId,
      biDesc: [''],
      biStartDt: [undefined],
      biEndDt: [undefined],
      biFixedRate: [''],

      biMgaDesc: [undefined],
      biBrokerDesc: [undefined],
      biCurrDesc: [undefined],
      biBusTypeDesc: [undefined],
      biAcStmtFreqDesc: [undefined],
      biUmrNo: [''],
      biAgreementNo: [''],
      biCreditDays: [''],
      biSetlDays: [''],
      biProgCode: [''],
      biPrvAmendNo: [''],
      biPrvRefNo: [''],
      biPrvSeqNo: [''],
      biRemarks: [''],
      biStatus: [''],
      biUpdDt: new Date(),
      biUpdUid: this.userId,
      biUwYear: [''],
      biFlex06: [''],
      binderContractPK: {
        biAmendNo: this.amendNo,
        biRefNo: this.refNo,
        biSeqNo: this.seqNo
      }
    })
    this.getContractInfo();
    this.getOutwardList();
  }
  getContractInfo() {
    this.bpSumEpiInGbp = this.bpMgaCommission = 0;
    this.mgaService.viewMgaContract(this.refNo, this.seqNo, this.amendNo).subscribe((result: any) => {
      let viewContract = result;
      this.contractInfo = viewContract.binderContract;
      this.applicableProductList = viewContract.binderLob;
      if (this.contractInfo && this.contractInfo.binderContractPK) {
        this.contractInfoForm.patchValue({
          biAmendNo: this.contractInfo.binderContractPK.biAmendNo,
          biSeqNo: this.contractInfo.binderContractPK.biSeqNo,
          biRefNo: this.contractInfo.binderContractPK.biRefNo,
        })
      }
      if (this.contractInfo && this.contractInfo.biStartDt) {
        this.contractInfo.biStartDt = moment(this.contractInfo.biStartDt).format('DD/MM/YYYY');
      } else if (this.contractInfo) {
        this.contractInfo.biStartDt = undefined;
      }
      if (this.contractInfo && this.contractInfo.biEndDt) {
        this.contractInfo.biEndDt = moment(this.contractInfo.biEndDt).format('DD/MM/YYYY');
      } else if (this.contractInfo) {
        this.contractInfo.biEndDt = undefined;
      }
      if (this.contractInfo && this.contractInfo.biCanDt) {
        this.contractInfo.biCanDt = moment(this.contractInfo.biCanDt).format('DD/MM/YYYY');
      } else if (this.contractInfo) {
        this.contractInfo.biCanDt = undefined;
      }
      if (this.contractInfo && this.contractInfo.biCrDt) {
        this.contractInfo.biCrDt = moment(this.contractInfo.biCrDt).format('DD/MM/YYYY');
      } else if (this.contractInfo) {
        this.contractInfo.biCrDt = undefined;
      }
      if (this.contractInfo && this.contractInfo.biUpdDt) {
        this.contractInfo.biUpdDt = moment(this.contractInfo.biUpdDt).format('DD/MM/YYYY');
      } else if (this.contractInfo) {
        this.contractInfo.biUpdDt = undefined;
      }
      if (this.contractInfo && this.contractInfo.biFlex10) {
        this.contractInfo.biContractPeriod = this.contractInfo.biFlex10;
      } else if (this.contractInfo) {
        this.contractInfo.biContractPeriod = undefined;
      }
      if (this.contractInfo && this.contractInfo.biFlex06) {
        this.contractInfo.biFlex06 = (this.contractInfo.biFlex06 == 'Y' ? 'Yes' : 'No');
      } else if (this.contractInfo) {
        this.contractInfo.biFlex06 = undefined;
      }
      this.contractInfo.biMgaDesc = this.contractInfo.biMga + ' - ' + this.contractInfo.biMgaDesc;
      this.contractInfo.biBrokerDesc = (this.contractInfo.biBrokerDesc != null) ? this.contractInfo.biBroker + ' - ' + this.contractInfo.biBrokerDesc : '';
      this.contractInfo.biCurrDesc = this.contractInfo.biCurr + ' - ' + this.contractInfo.biCurrDesc;
      this.contractInfo.biBusTypeDesc = this.contractInfo.biBusType + ' - ' + this.contractInfo.biBusTypeDesc;

      this.contractInfoForm.disable();
      this.contractInfoForm.patchValue(this.contractInfo);
      if (this.applicableProductList.length > 0) {
        this.context.componentParent.selectedRowId = this.applicableProductList[0].binderLobPK.bpProdSrNo;
        this.selectedRowData({ data: this.applicableProductList[0] });
        for (var i = 0; i < this.applicableProductList.length; i++) {
          this.bpSumEpiInGbp = this.bpSumEpiInGbp + this.applicableProductList[i].bpSumEpiInGbp;
          this.bpMgaCommission = this.bpMgaCommission + this.applicableProductList[i].bpMgaCommission;
        }
      } else {
        this.applicableProductList = [];
        this.bpSumEpiInGbp = this.bpMgaCommission = 0;
      }
      this.bottomDataDetailsApplCont();
      this.loaderService.isBusy = false;
    })
  }
  getAllLOBEPIByRefId() {
    this.loaderService.isBusy = true;
    this.mgaService.viewMgaEPI(this.refNo, this.seqNo, this.amendNo, this.lobSrNo).subscribe(resp => {
      this.lobEpiList = resp;
      if (this.lobEpiList) {
        this.pinnedBottomRowData = createData(1, this.lobEpiList, "Bottom");
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getAllCoinsurerList() {
    this.maxSharePerc = 0;
    this.mgaService.viewMgaCoinsurance(this.refNo, this.seqNo, this.amendNo, this.lobSrNo).subscribe((resp: any) => {
      this.coinsuereList = resp;
      if (this.coinsuereList.length > 0) {
        this.context1.componentParent.selectedRowId1 = this.coinsuereList[0].binderCoinsPK.bcSrNo;
        this.selectedRow({ data: this.coinsuereList[0] });
        for (var i = 0; i < this.coinsuereList.length; i++) {
          this.maxSharePerc = this.maxSharePerc + this.coinsuereList[i].bcSharePerc;
        }
      } else {
        this.coinsuranceTermData = [];
        this.getTermData('NA', 'SSC');
        this.getTermData('NA', 'PC');
      }
      this.bottomDataDetails();
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  bottomDataDetails() {
    this.bottomData = [
      {
        binderCoinsPK: { bcProdSrNo: '' },
        bcLeaderYn: 'Total',
        bcSharePerc: this.maxSharePerc.toFixed(2),
      }
    ];
  }
  bottomDataDetailsApplCont() {
    this.bottomDataApplCont = [
      {
        binderLobPK: { bpProdSrNo: '' },
        bpProdCodeDesc: 'Total',
        bpSumEpiInGbp: this.bpSumEpiInGbp.toFixed(2),
        bpMgaCommission: this.bpMgaCommission.toFixed(4),
      }
    ];
  }
  getPremiumBusinessRules(typeId: any) {
    this.mgaService.viewMgaBusiness(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, typeId).subscribe(resp => {
      if (typeId == '04') {
        this.premiumListData = resp;
      } else if (typeId == '05') {
        this.discountListData = resp;
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getAllCommByRefId(typeId: any) {
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, typeId, 'NA', '').subscribe(resp => {
      this.termsMinCommData = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getAlContractTerms(typeId: any) {
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, typeId, 'NA', 'CONPTERM').subscribe(resp => {
      this.termContractData = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getAlContractCoins(typeId: any, custCode) {
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, typeId, custCode, 'CONCTERM').subscribe(resp => {
      this.termContractData_Coins = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getOutwardList() {
    this.mgaService.viewOutwardList(this.refNo, this.seqNo, this.amendNo).subscribe(resp => {
      this.outwardReinsuraceList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  selectedRowData(cell) {
    this.lobInfo = cell.data;
    let SrNo = cell.data.binderLobPK.bpProdSrNo;

    this.lobSrNo = SrNo;
    setTimeout(() => {
      this.showChild_TabScreen = true;
      this.getAllLOBEPIByRefId();
      this.getAllCommByRefId('TERMS');
      this.getAlContractTerms('TERMS');
      this.getPremiumBusinessRules('04');
      this.getPremiumBusinessRules('05');
      console.log(this.coinsExpInfo);
      this.getTermData('NA', 'PS');
      this.getTermData('NA', 'IC');
      this.getAllCoinsurerList();

    }, 300);
  }
  hideCoinsTab: boolean = false;
  selectedRow(cell) {
    this.coInsurance_childTabScreen = false;
    this.infoLoading = true;
    this.coinsExpInfo = cell.data;
    this.shareOn = cell.data.bcShareOn;
    let srNo = this.coinsExpInfo.binderCoinsPK.bcProdSrNo;
    let typeId = '07';
    let custCode = this.coinsExpInfo.bcCustCode;
    if (this.shareOn == 'P1') {
      this.hideCoinsTab = true;
    } else {
      this.hideCoinsTab = false;
    }
    setTimeout(() => {
      if (this.shareOn == 'P1') {
        this.showCoinsurance = true;
        this.infoLoading = false;
        this.getAllCoinsExpenseByRefId(srNo, typeId, custCode);
      } else {
        this.showCoinsurance = false;
      }
      this.infoLoading = false;
      this.coInsurance_childTabScreen = true;
      //this.getAllCoinsExpenseByRefId(srNo,typeId,custCode);
      this.getAllCoinsXolByRefId(srNo, '06', custCode);
      this.getTermSSCgridData(cell.data.bcCustCode);
      this.getAllByRefId(cell.data.bcCustCode);
      this.getAlContractCoins('COTERMS', cell.data.bcCustCode);
      // this.getTermData(cell.data.bcCustCode, 'IC');
      this.getTermData(cell.data.bcCustCode, 'PC');
      this.getTermData(cell.data.bcCustCode, 'SSC');
    }, 300);
  }
  getAllCoinsXolByRefId(srNo: any, typeId: string, custCode: any) {
    this.mgaService.getCoinsuranceExpenses(this.refNo, this.seqNo, this.amendNo, srNo, typeId, custCode).subscribe(resp => {
      this.coinsXolCostData = resp;
    });
  }
  getAllByRefId(bcCustCode) {
    // this.infoLoading = true;
    this.coinsuranceTermData = [];
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'COTERMS', bcCustCode, '').subscribe(resp => {
      this.coinsuranceTermData = resp;
      this.loaderService.isBusy = false;

    });
  }
  getAllCoinsExpenseByRefId(srNo, typeId, custCode) {
    this.mgaService.getCoinsuranceExpenses(this.refNo, this.seqNo, this.amendNo, srNo, typeId, custCode).subscribe(resp => {
      this.coinsExpenseData = resp;
      this.infoLoading = false;
      this.loaderService.isBusy = false;
    });
  }

  selectedRow1(cell) {
    this.getTermSSCgridData(cell.data.bcCustCode);
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount(gridApi) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    } else {
      this.gridOptions.api.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(gridApi: any, page) {
    gridApi.paginationSetPageSize(page);
    gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params, id) {
    var gridWidth = document.getElementById("applicableProductContractTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer2: RadiorenderComponent2
    };
    this.context1 = { componentParent: this };
    this.frameworkComponents1 = {
      radioButtonRenderer3: RadiorenderComponent3
    };
  }
  onGridReady(gridApi, table) {
    gridApi = gridApi.api;
    gridApi.sizeColumnsToFit();
    if (table === 'applicableProduct') {
      this.gridApi = gridApi;
    } else if (table === 'epi') {
      this.epiGridApi = gridApi;
    } else if (table === 'terms_min') {
      this.terms_minGridApi = gridApi;
    } else if (table === 'terms_contract') {
      this.terms_contractGridApi = gridApi;
    } else if (table === 'business_premium') {
      this.business_premiumGridApi = gridApi;
    } else if (table === 'business_discount') {
      this.business_discountGridApi = gridApi;
    } else if (table === 'coinsurance') {
      this.coinsuranceGridApi = gridApi;
    } else if (table === 'coinsurance_expense') {
      this.coinsurance_expenseGridApi = gridApi;
    } else if (table === 'coinsurance_term') {
      this.coinsurance_termGridApi = gridApi;
    } else if (table === 'terms') {
      this.termsGridApi = gridApi;
    } else if (table === 'sliding_scale') {
      this.sliding_scaleGridApi = gridApi;
    } else if (table === 'outward_reinsurance') {
      this.outward_reinsuranceGridApi = gridApi;
    }
  }
  tabswitch(e) {
    // this.loaderService.isBusy = true;
    if (!e || !e.heading) {
      return;
    }
    this.showChild_TabScreen = true;
    if (e.heading === 'EPI') {
      this.getAllLOBEPIByRefId();
      this.epi_TabScreen = true;
      this.terms_TabScreen = false;
      this.busineessRules_TabScreen = false;
      this.coInsurance_TabScreen = false;

    } else if (e.heading === 'Terms') {
      this.getAllCommByRefId('TERMS');
      this.getAlContractTerms('TERMS');
      this.getTermData('NA', 'PS');
      this.epi_TabScreen = false;
      this.terms_TabScreen = true;
      this.busineessRules_TabScreen = false;
      this.coInsurance_TabScreen = false;
    } else if (e.heading === 'Business Rules') {
      this.getPremiumBusinessRules('04');
      this.getPremiumBusinessRules('05');
      this.epi_TabScreen = false;
      this.terms_TabScreen = false;
      this.busineessRules_TabScreen = true;
      this.coInsurance_TabScreen = false;
    } else {
      this.getAllCoinsurerList();
      this.epi_TabScreen = false;
      this.terms_TabScreen = false;
      this.busineessRules_TabScreen = false;
      this.coInsurance_TabScreen = true;
      this.getTermData('NA', 'IC');
      this.getTermData(this.coinsExpInfo.bcCustCode, 'PC');
      this.getTermData(this.coinsExpInfo.bcCustCode, 'SSC');
    }
  }
}

function createData(count, data, prefix) {
  var result = [];
  var sum = 0;
  var sumbeEpiLc1 = 0;
  for (var i = 0; i < data.length; i++) {
    sum = sum + data[i].beEpiFc;
    sumbeEpiLc1 = sumbeEpiLc1 + data[i].beEpiLc1
  }
  for (var i = 0; i < count; i++) {
    ({
      beRegionCode: 'Total',
      beEpiFc: sum.toFixed(2),
      beEpiLc1: sumbeEpiLc1.toFixed(2),
      beRegionCodeDesc: ':'
    });
  }
  return result;
}
