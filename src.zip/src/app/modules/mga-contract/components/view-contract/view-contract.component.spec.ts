import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/view-contract/view-contract.component.spec.ts
import { ViewContractComponent } from './view-contract.component';

describe('ViewContractComponent', () => {
  let component: ViewContractComponent;
  let fixture: ComponentFixture<ViewContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewContractComponent ]
=======
import { ApplContractComponent } from './appl-contract.component';

describe('ApplContractComponent', () => {
  let component: ApplContractComponent;
  let fixture: ComponentFixture<ApplContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplContractComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/appl-contract/appl-contract.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/view-contract/view-contract.component.spec.ts
    fixture = TestBed.createComponent(ViewContractComponent);
=======
    fixture = TestBed.createComponent(ApplContractComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/appl-contract/appl-contract.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
