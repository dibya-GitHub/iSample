import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { MgaContractService } from 'src/app/modules/mga-contract/services/mga-contract.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { HiperLinkComponent } from 'src/shared/components/ag-hiperlink/ag-hiperlink.component';
import { MgaUtils } from '../mga-utils';

@Component({
  selector: 'mga-ta-accounting',
  templateUrl: './mga-ta-accounting.component.html',
  styleUrls: ['./mga-ta-accounting.component.scss'],
  providers: [DatePipe]
})
export class MgaTaAccountingComponent implements OnInit {
  techAccForm: UntypedFormGroup;
  mgaList: any = [];
  bsConfig: Partial<BsDatepickerConfig> = new BsDatepickerConfig();

  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefsAppr = [];
  columnDefsPend = [];

  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;

  techAccList: any = [];
  transactionType: any = [];
  accountToList: any = [];
  contractIdList: any = [];
  userList: any = [];
  showPending: boolean = false;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private mgaService: MgaContractService,
    private loaderService: LoaderService,
    private toastService: ToastService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.bsConfig = Object.assign({}, { rangeInputFormat: 'DD/MM/YYYY', customTodayClass: 'custom-today-class' });
    this.createForm();
    this.columnDefsFnForAppr();
    this.columnDefsFnForPend();
    this.search('A');
  }

  columnDefsFnForAppr() {
    const context = this;
    this.columnDefsAppr = [
      {
        headerName: 'Batch Id',
        headerTooltip: 'Batch Id',
        field: 'bhId',
        width: 95,
        tooltipField: 'bhId',
        cellStyle: { color: '#ffffff', 'font-weight': 'bold', textAlign: 'center', 'text-decoration': 'underline' },
        cellRendererFramework: HiperLinkComponent,
        cellRendererParams: {
          event: (event, data) => {
            context.onRefClickedAppr(data);
          }
        },
        pointerCursor: true,
        filter: 'agTextColumnFilter',
        filterParams: {
          filterOptions: ['contains', 'notContains'],
          debounceMs: 0,
          caseSensitive: false,
          suppressAndOrCondition: true
        },
        valueGetter: function (params) {
          if (params.data && params.data.bhId) {
            return 'M - ' + params.data.bhId;
          } else {
            return "";
          }
        },
      },
      {
        headerName: "Ref.No",
        headerTooltip: 'Ref.No',
        field: "bhTtyRefNo",
        width: 120,
      },
      {
        headerName: "Narration",
        headerTooltip: "Narration",
        field: "bhNotes",
        width: 250,
      },
      {
        headerName: "Accounting To",
        headerTooltip: "Accounting To",
        field: "bhAcntCust",
      },
      {
        headerName: "Contract Id",
        headerTooltip: "Contract Id",
        field: "bhRefNo",
      },
      {
        headerName: "Transaction Type",
        headerTooltip: "Transaction Type",
        field: "bhTranType",
      },
      {
        headerName: "Accounting Currency",
        headerTooltip: "Accounting Currency",
        field: "bhAcntCurr",
        width: 140
      },
      {
        headerName: "Account Amount",
        headerTooltip: "Account Amount",
        field: "bhNetValFc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      },
      {
        headerName: "Approved By",
        headerTooltip: "Approved By",
        field: "bhApprUid",
      },
      {
        headerName: "Approved Date",
        headerTooltip: 'Approved Date',
        field: "bhApprDt",
        width: 120,
        valueGetter: function (params) {
          if (params && params.data && params.data.bhApprDt) {
            return moment(params.data.bhApprDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
      },
      {
        width: 110,
        field: 'bhApprSts',
        headerName: 'Status',
        headerTooltip: 'Status',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.bhApprSts) {
            if (params.data.bhApprSts === 'A') {
              return 'Approved';
            } else if (params.data.bhApprSts === 'R') {
              return 'Reversed';
            }
          } else {
            return '';
          }
        },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-orange-outer': function (params) {
            if (params.value) {
              return params.value == 'Reversed';
            }
          }
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else if (params.value === 'Reversed') {
            return '<span class="ag-element">' + params.value + '</span>';
          }
        },
      },
    ];
  }
  columnDefsFnForPend() {
    const context = this;
    this.columnDefsPend = [
      {
        headerName: 'Batch Id',
        headerTooltip: 'Batch Id',
        field: 'bhId',
        width: 95,
        tooltipField: 'bhId',
        cellStyle: { color: '#ffffff', 'font-weight': 'bold', textAlign: 'center', 'text-decoration': 'underline' },
        cellRendererFramework: HiperLinkComponent,
        cellRendererParams: {
          event: (event, data) => {
            context.onRefClickedPend(data);
          }
        },
        pointerCursor: true,
        filter: 'agTextColumnFilter',
        filterParams: {
          filterOptions: ['contains', 'notContains'],
          debounceMs: 0,
          caseSensitive: false,
          suppressAndOrCondition: true
        },
        valueGetter: function (params) {
          if (params.data && params.data.bhId) {
            return 'M - ' + params.data.bhId;
          } else {
            return "";
          }
        },
      },
      {
        headerName: "Ref.No",
        headerTooltip: 'Ref.No',
        field: "bhTtyRefNo",
        width: 120,
      },
      {
        headerName: "Narration",
        headerTooltip: "Narration",
        field: "bhNotes",
        width: 250,
      },
      {
        headerName: "Accounting To",
        headerTooltip: "Accounting To",
        field: "bhAcntCust",
      },
      {
        headerName: "Contract Id",
        headerTooltip: "Contract Id",
        field: "bhRefNo",
      },
      {
        headerName: "Transaction Type",
        headerTooltip: "Transaction Type",
        field: "bhTranType",
        // headerClass: "grid-cell-centered",
      },
      {
        headerName: "Accounting Currency",
        headerTooltip: "Accounting Currency",
        field: "bhAcntCurr",
        width:140
      },
      {
        headerName: "Account Amount",
        headerTooltip: "Account Amount",
        field: "bhNetValFc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      },
      {
        headerName: "Created By",
        headerTooltip: "Created By",
        field: "bhCrUid",
      },
      {
        headerName: "Created Date",
        headerTooltip: 'Created Date',
        field: "bhCrDt",
        width: 120,
        valueGetter: function (params) {
          if (params && params.data && params.data.bhCrDt) {
            return moment(params.data.bhCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
      },
    ];
  }
  onRefClickedAppr(data) {
    this.loaderService.isBusy = true
    let obj = { 'action': 'view', 'id': data.bhId, 'status': data.bhApprSts };
    this.router.navigate(["/mga-ta-accounting-create"], { queryParams: obj, skipLocationChange: false });
    this.loaderService.isBusy = false;
  }
  onRefClickedPend(data) {
    this.loaderService.isBusy = true
    let obj = { 'action': 'edit', 'id': data.bhId, 'status': data.bhApprSts };
    this.router.navigate(["/mga-ta-accounting-create"], { queryParams: obj, skipLocationChange: false });
    this.loaderService.isBusy = false;
  }
  createForm() {
    this.techAccForm = this.fb.group({
      dateFm: [undefined],
      dateTo: [undefined],
      bhTranType: [undefined],
      bhAcntCust: [undefined],
      bhTtyRefNo: [undefined],
      bhCrUid: [undefined],
    });
    this.getDate();
    this.getMasterData();
  }
  getDate() {
    var now = new Date();
    var oneYr = new Date().setFullYear(now.getFullYear() - 1);
    var firstDay = new Date(oneYr).setDate(new Date(oneYr).getDate() + 1);

    this.techAccForm.patchValue({
      dateFm: new Date(firstDay),
    });
    this.setContractPeriod(this.techAccForm.get('dateFm').value, 'loading');
  }
  setContractPeriod(value, evnt) {
    if (value) {
      const startDate = moment(value.getDate() + '/' + (value.getMonth() + 1) + '/' + value.getFullYear(), 'DD/MM/YYYY');
      const endDate = moment(startDate).add(1, 'year').add(-1, 'days');
      if (evnt == 'loading') {
        const data = {
          dateTo: endDate.format('DD/MM/YYYY'),
        };
        this.techAccForm.patchValue(data);
      }
    }
  }
  searchClicked() {
    if (!this.showPending) {
      this.search('A');
    } else {
      this.search('P');
    }
  }
  search(status) {
    this.techAccList = [];
    this.loaderService.isBusy = true;
    let formData = this.techAccForm.getRawValue();

    formData.dateFm = (formData.dateFm == null) ? "" : moment(formData.dateFm, 'DD/MM/YYYY').format('DD/MM/YYYY');
    formData.dateTo = (formData.dateTo == null) ? "" : moment(formData.dateTo, 'DD/MM/YYYY').format('DD/MM/YYYY');
    let obj = {
      dateFm: formData.dateFm,
      dateTo: formData.dateTo,
      bhTranType: (formData.bhTranType == '' ? null : formData.bhTranType),
      bhApprSts: status,
      bhAcntCust: (formData.bhAcntCust == '' ? null : formData.bhAcntCust),
      bhTtyRefNo: (formData.bhTtyRefNo == '' ? null : formData.bhTtyRefNo),
      bhCrUid: (formData.bhCrUid == '' ? null : formData.bhCrUid),
    };

    this.mgaService.accountSearch(obj).subscribe(resp => {
      this.techAccList = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error('Error in Retrive Data');
      this.loaderService.isBusy = false;
    });
  }


  tabClick(evt) {
    if (evt.heading === 'Approved') {
      this.search("A");
      this.showPending = false;
    }
    if (evt.heading === 'Pending') {
      this.search("P");
      this.showPending = true;
    }
  }
  reset() {
    this.techAccForm.patchValue({
      dateFm: null,
      dateTo: null,
      bhTranType: null,
      bhAcntCust: null,
      bhTtyRefNo: null,
      bhCrUid: null,
    });
    this.pageChanged({ page: 1 });
    if (!this.showPending) {
      this.search('A');
    } else {
      this.search('P');
    }
  }
  newAccounting() {
    this.router.navigate(['/mga-ta-accounting-create'], { queryParams: { newForm: 'New' } });
  }
  gotoAdvancedSearch() {
    this.router.navigate(['/mga-ta-accounting-view']);
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case 'Print':
          return this.onActionPrintAccounting(data);
      }
    }
  }
  onActionPrintAccounting(data: any) {
    this.loaderService.isBusy = true;

    // let obj = { 'action': 'edit', 'id': data.bhId, 'status': data.bhAppSts };
    // this.router.navigate(['/mga-ta-accounting-create'], { queryParams: obj, skipLocationChange: true });
    this.loaderService.isBusy = false;
  }
  fetchTransactionType() {
    this.mgaService.fetchTransactionType().subscribe(transaction => {
      this.transactionType = transaction;
    })
  }
  getLOBCompanyAppCode() {
    this.mgaService.getACNTfilterlist().subscribe((mgaLst: any) => {
      this.accountToList = (mgaLst as any[]).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });
    })
  }
  getContractIdCode() {
    this.mgaService.getContractIds().subscribe((contractIds: any) => {
      this.contractIdList = contractIds.filter((el) => {
        return el.key != null;
      });
    })
  }
  reterieveUserList() {
    this.mgaService.getTAUsers().subscribe((users: any) => {
      this.userList = users;
      this.userList.unshift({ key: '', value: 'All' });
    })
  }
  getMasterData() {
    this.loaderService.isBusy = true;
    this.fetchTransactionType();
    this.getLOBCompanyAppCode();
    this.getContractIdCode();
    this.reterieveUserList();
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("dataViewTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'technicalAccounting.xlsx',
        skipHeader: false,
        sheetName: 'Technical Accounting',

        processCellCallback: (params) => {
          if (params.column.colId) {
            return params.value;
          }
        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  agGridOptions() {
    this.context = { componentParent: this };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};
function currencyFormatter(params) {
  if (params && params.value != null) {
    return Intl.NumberFormat('en-US',
      { minimumFractionDigits: 2 }).format((params.value));
  } else {
    return;
  }
}