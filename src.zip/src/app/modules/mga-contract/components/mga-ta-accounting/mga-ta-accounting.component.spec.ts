import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-ta-accounting/mga-ta-accounting.component.spec.ts
import { MgaTaAccountingComponent } from './mga-ta-accounting.component';

describe('MgaTaAccountingComponent', () => {
  let component: MgaTaAccountingComponent;
  let fixture: ComponentFixture<MgaTaAccountingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaTaAccountingComponent ]
=======
import { LayerTreatyTypeComponent } from './layer-treaty-type.component';

describe('LayerTreatyTypeComponent', () => {
  let component: LayerTreatyTypeComponent;
  let fixture: ComponentFixture<LayerTreatyTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LayerTreatyTypeComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/layer-treaty-type/layer-treaty-type.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-ta-accounting/mga-ta-accounting.component.spec.ts
    fixture = TestBed.createComponent(MgaTaAccountingComponent);
=======
    fixture = TestBed.createComponent(LayerTreatyTypeComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/layer-treaty-type/layer-treaty-type.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
