import { Component } from '@angular/core';
import { ICellRendererAngularComp } from '@ag-grid-community/angular';

@Component({
  selector: 'mga-editviewrender',
  template: `<a>
  <i class="fa fa-file-pen fa-icon"  data-action-type="Edit"  title="Edit" aria-hidden="true"  *ngIf="canShowEgnp"></i>&nbsp;&nbsp;
  <i class="fa fa-trash fa-icon fa-danger" data-action-type="Delete"  title="Delete" aria-hidden="true" *ngIf="canShowEgnp"></i>
  </a>`,

  styleUrls: ['./mga-editviewrender.component.scss']
})
export class MgaEditviewrenderComponent implements ICellRendererAngularComp {
  public params: any;
  canViewShow: boolean;
  canEditShow: boolean;
  canShowEgnp: boolean;
  constructor() { }

  agInit(params: any): void {
    console.log(params.data);
    this.params = params;
    if (this.params && this.params.data) {
      if (this.params.data.beRegionCode == 'Total :') {
        this.canShowEgnp = false;
      } else {
        this.canShowEgnp = true;
      }
    }
  }

  public invokeParentMethod(e) {

  }
  refresh(): boolean {
    return false;
  }

}
