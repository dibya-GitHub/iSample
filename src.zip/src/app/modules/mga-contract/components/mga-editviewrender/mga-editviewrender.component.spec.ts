import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-editviewrender/mga-editviewrender.component.spec.ts
import { MgaEditviewrenderComponent } from './mga-editviewrender.component';

describe('MgaEditviewrenderComponent', () => {
  let component: MgaEditviewrenderComponent;
  let fixture: ComponentFixture<MgaEditviewrenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaEditviewrenderComponent ]
=======
import { AdjustmentPremiumComponent } from './adjustment-premium.component';

describe('AdjustmentPremiumComponent', () => {
  let component: AdjustmentPremiumComponent;
  let fixture: ComponentFixture<AdjustmentPremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdjustmentPremiumComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/adjustment-premium/adjustment-premium.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-editviewrender/mga-editviewrender.component.spec.ts
    fixture = TestBed.createComponent(MgaEditviewrenderComponent);
=======
    fixture = TestBed.createComponent(AdjustmentPremiumComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/adjustment-premium/adjustment-premium.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
