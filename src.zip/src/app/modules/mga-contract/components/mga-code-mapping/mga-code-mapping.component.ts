import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';

@Component({
  selector: 'mga-code-mapping',
  templateUrl: './mga-code-mapping.component.html',
  styleUrls: ['./mga-code-mapping.component.scss']
})
export class MgaCodeMappingComponent implements OnInit {
  mgaCodeMappingForm: UntypedFormGroup;
  mgaMappingSrchFrm: UntypedFormGroup;
  mgaCodeMappingList: any = [];
  showForm: boolean = false;
  AddFlag: boolean = true;
  action: string;

  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  rowData: any;
  public components;
  public context;
  public frameworkComponents;
  paginationPageSize: number;
  rowGroupPanelShow: string;
  public getRowHeight;
  public getRowStyle;

  mgaList: any = [];
  mgaCodeTypeList: any = [];
  mgaCodetypeDD: any = [];
  @ViewChild('confirmModal') confirmModal: ElementRef;
  temp: any;
  closeResult: string;
  mgaOurCodeList: any = [];
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
    private mgaService: MgaContractService,

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true
    };
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      if (params.node.data != null)
        var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.columnDefs = [
      {
        headerName: "MGA",
        headerTooltip: 'MGA',
        field: "mcmMgaDesc",
        width: 200,
      },
      {
        headerName: "Type",
        headerTooltip: 'Type',
        field: "mcmType",
        valueGetter: function (params) {
          if (params && params.data && params.data.mcmTypeDesc) {
            return params.data.mcmTypeDesc;
          } else {
            return '';
          }
        },
        width: 200,
      },
      {
        headerName: "MGA Value",
        headerTooltip: "MGA Value",
        field: "mcmMgaVal",
        width: 200,
      },
      {
        headerName: "Our Code",
        headerTooltip: 'Our Code',
        field: "mcmOurCode",
        width: 200,
      },
      {
        headerName: "Our Description",
        headerTooltip: 'Our Description',
        field: "mcmOurDesc",
        width: 200,
      },
      {
        headerName: "Created by",
        headerTooltip: 'Created by',
        field: "mcmCrUname",
      },
      {
        headerName: "Created Date",
        headerTooltip: 'Created Date',
        field: "mcmCrDt",
        width: 200,
        valueGetter: function (params) {
          if (params && params.data && params.data.mcmCrDt) {
            let startDate = moment(params.data.mcmCrDt).format('DD/MM/YYYY');
            return startDate;
          } else {
            return '';
          }
        },
      },
      {
        field: "mcmMgaDesc",
        headerName: "Action",
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
        width: 100,
      }
    ];
    this.createForm();
    this.createSrchForm();
    this.searchContract();
    this.getMGAList();
    this.getCodeTypeList();
    this.agGridOptions();
  }
  getMGAList() {
    this.mgaService.getMGAlist().subscribe((resp: any) => {
      this.mgaList = resp;
      this.mgaList = (this.mgaList as any[]).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });
      this.mgaList.unshift({ code: '', displayText: 'All' });
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getCodeTypeList() {
    this.mgaService.getCodeTypeList().subscribe((resp: any) => {
      this.mgaCodetypeDD = resp;
      this.mgaCodeTypeList = resp;
      this.mgaCodeTypeList.unshift({ key: '', value: 'All' });
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getCodeTypeDropdown() {
    this.mgaService.getCodeTypeList().subscribe((resp: any) => {
      this.mgaCodetypeDD = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  createSrchForm() {
    this.mgaMappingSrchFrm = this.fb.group({
      mcmMga: [undefined],
      mcmType: [undefined],
    })
  }
  createForm() {
    this.mgaCodeMappingForm = this.fb.group({
      mcmMga: [undefined, Validators.required],
      mcmMgaCode: "",
      mcmMgadesc: "",
      mcmOurCode: [undefined, Validators.required],
      mcmType: [undefined, Validators.required],
      mcmCrDt: [undefined],
      mcmCrUid: [undefined],
      mcmOurDesc: [undefined],
      mcmUpDt: [undefined],
      mcmUpUid: [undefined],
      mcmMgaVal: [undefined, Validators.required]
    }, {})
  }
  selectedRowData(cell) {
    let SrNo = cell.data;
  }
  addMgaCodeMapping() {
    this.mgaCodeMappingForm.reset();
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'add';
    this.mgaOurCodeList = [];
    this.mgaCodeMappingForm.get('mcmMgaVal').enable();
    this.mgaCodeMappingForm.get('mcmType').enable();
    this.mgaCodeMappingForm.get('mcmMga').enable();
  }
  saveForm() {
    this.loaderService.isBusy = true;

    if (this.mgaCodeMappingForm.valid) {
      this.mgaCodeMappingForm.get('mcmMgaVal').enable();
      this.mgaCodeMappingForm.get('mcmType').enable();
      this.mgaCodeMappingForm.get('mcmMga').enable();
      let mappingData = this.mgaCodeMappingForm.value;
      let obj = {
        mcmMga: this.mgaCodeMappingForm.get('mcmMga').value,
        mcmMgaCode: mappingData.mcmMgaCode,
        mcmMgadesc: mappingData.mcmMgadesc,
        mcmOurCode: mappingData.mcmOurCode,
        mcmType: this.mgaCodeMappingForm.get('mcmType').value,
        mcmMgaVal: this.mgaCodeMappingForm.get('mcmMgaVal').value,
      };
      Object.assign(mappingData, obj);
      mappingData = MgaUtils.clean(mappingData);

      if ('edit' === this.action) {
        mappingData.mcmUpDt = new Date();
        mappingData.mcmUpUid = this.session.get('userId');
        mappingData = MgaUtils.clean(mappingData);
        this.mgaService.updateCodeMapping(mappingData).subscribe(resp => {
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp.message);
            this.loaderService.isBusy = false;
          } else {
            this.toastService.success('Successfully Updated');
            // this.getMgaCodeMapping();
            this.searchContract();
            this.showForm = false;
            this.AddFlag = true;
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        mappingData.mcmCrDt = new Date();
        mappingData.mcmCrUid = this.session.get('userId');
        mappingData.mcmUpDt = new Date();
        mappingData.mcmUpUid = this.session.get('userId');
        this.mgaService.saveCodeMapping(mappingData).subscribe(resp => {
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp.message);
            this.loaderService.isBusy = false;
          } else {
            this.toastService.success('Successfully Saved');
            // this.getMgaCodeMapping();
            this.searchContract();
            this.showForm = false;
            this.AddFlag = true;
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      }
    } else {
      MgaUtils.validateAllFormFields(this.mgaCodeMappingForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  back() {
    this.showForm = false;
    this.AddFlag = true;
    this.mgaCodeMappingForm.reset();
  }
  back1() {
    this.router.navigate(['/mga-contract/mga-landing-page'], { queryParams: { title: 'Home' } });
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case 'Edit':
          return this.onActionEditCodeMapping(data);
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
  onActionEditCodeMapping(data) {
    this.loaderService.isBusy = true;
    this.mgaCodeMappingForm.get('mcmMgaVal').disable();
    this.mgaCodeMappingForm.get('mcmType').disable();
    this.mgaCodeMappingForm.get('mcmMga').disable();
    this.getCodeTypeDropdown();
    this.action = 'edit';
    this.showForm = true;
    this.AddFlag = false;
    this.mgaCodeMappingForm.patchValue({
      mcmMga: data.mcmMga,
      mcmMgaCode: data.mcmMgaCode,
      mcmMgadesc: data.mcmMgadesc,
      mcmType: data.mcmType,
      mcmOurCode: data.mcmOurCode,
      mcmOurDesc: data.mcmOurDesc,
      mcmMgaVal: data.mcmMgaVal,
    });
    this.loaderService.isBusy = false;
  }
  searchContract() {
    this.loaderService.isBusy = true;
    let formData = this.mgaMappingSrchFrm.getRawValue();
    let obj = {
      mcmMga: (formData.mcmMga == '' ? null : formData.mcmMga),
      mcmType: (formData.mcmType == '' ? null : formData.mcmType),
    };
    this.mgaService.codeMappingFilterSearch(obj).subscribe(resp => {
      this.mgaCodeMappingList = resp;
      if (this.mgaCodeMappingList.length > 0) {
        this.context.componentParent.selectedRowId = this.mgaCodeMappingList[0].mcmId;
        this.selectedRowData({ data: this.mgaCodeMappingList[0] });
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
    this.showForm = false;
    this.AddFlag = true;
  }
  reset() {
    this.mgaMappingSrchFrm.patchValue({
      mcmMga: '',
      mcmType: '',
    });
    this.pageChanged({ page: 1 });
    this.searchContract();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  showDialogbox(data: any) {
    this.temp = data;
    this.open(this.confirmModal, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  close(){
    this.modalService.hide();
  }
  deleteRow() {
    this.loaderService.isBusy = true;
    if (this.temp) {
      this.mgaService.deleteCodeMapping(this.temp.mcmMga, this.temp.mcmType, this.temp.mcmMgaVal).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully.');
        this.searchContract();
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    } else {
      this.loaderService.isBusy = false;
      this.toastService.error('Error in Deleting Data');
    }
  }
  changeCodeType(event) {
    this.loaderService.isBusy = true;
    this.mgaService.getOurMgaCode(event.value).subscribe((resp) => {
      this.mgaOurCodeList = resp;
      this.mgaCodeMappingForm.get('mcmOurCode').setValue(null);

      this.loaderService.isBusy = false;
    });
  }
  changeOurCode(event) {
    if (event.key) {
      this.mgaCodeMappingForm.get('mcmOurDesc').setValue(event.value);
    }
  }
  onBtExport() {
    if (this.gridApi) {
      let columnKeys = ['mcmMgaDesc', 'mcmType', 'mcmMgaVal', 'mcmOurCode', 'mcmOurDesc', 'mcmCrUname', 'mcmCrDt'];
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'mga_code_mapping.xlsx',
        skipHeader: false,
        sheetName: 'Mga Code Mapping',
        columnKeys: columnKeys,
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('mgaCodeMappingListTable').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();

  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: null,
      enableFilter: true
    };

    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
   </a>&nbsp;
   <a>
    <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
   </a>`;
  }
}