import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-code-mapping/mga-code-mapping.component.spec.ts
import { MgaCodeMappingComponent } from './mga-code-mapping.component';

describe('MgaCodeMappingComponent', () => {
  let component: MgaCodeMappingComponent;
  let fixture: ComponentFixture<MgaCodeMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaCodeMappingComponent ]
=======
import { AgGridCheckboxComponent } from './ag-grid-checkbox.component';

describe('AgGridCheckboxComponent', () => {
  let component: AgGridCheckboxComponent;
  let fixture: ComponentFixture<AgGridCheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgGridCheckboxComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/ag-grid-checkbox/ag-grid-checkbox.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-code-mapping/mga-code-mapping.component.spec.ts
    fixture = TestBed.createComponent(MgaCodeMappingComponent);
=======
    fixture = TestBed.createComponent(AgGridCheckboxComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/ag-grid-checkbox/ag-grid-checkbox.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
