import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaContractualTermComponent } from './mga-contractual-term.component';

describe('MgaContractualTermComponent', () => {
  let component: MgaContractualTermComponent;
  let fixture: ComponentFixture<MgaContractualTermComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaContractualTermComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MgaContractualTermComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
