import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, SimpleChanges, TemplateRef, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as _ from 'lodash';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';

@Component({
  selector: 'mga-contractual-term',
  templateUrl: './mga-contractual-term.component.html',
  styleUrls: ['./mga-contractual-term.component.scss']
})
export class MgaContractualTermComponent implements OnInit {
  contractualForm: UntypedFormGroup;
  termContractData: any;
  items: UntypedFormArray;
  disableAddrow_cont: boolean = false;
  profitShareTerm: UntypedFormGroup;
  termsMinCommForm: UntypedFormGroup;
  termsMinCommData: any;
  basedOnList: any = [];
  deleteIndex_cont: any;
  index_cont: any;
  formName_cont: any;
  @ViewChild('confirmContDialog') confirmContDialog: ElementRef;

  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() amendSrNo: string;
  @Input() action: string;
  @Input() seqNo: number;
  @Input() status: string;
  @Input() lobSrNo: number;
  @Input() passedData: any;
  @Input() type: any;
  @Input() custCode: any;

  modalRef: BsModalRef;
  modalRef1: BsModalRef;
  minDate: any;
  maxDate: any;
  termsContractList: any = [];
  btTypeCList: any = [];
  btTypePList: any = [];
  intermediaryList: any;
  userId: string;
  @ViewChild('errorModal') errorModal: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private mgaService: MgaContractService,
    private modalService: BsModalService,

  ) {
    this.userId = this.session.get('userId');
  }

  ngOnInit() {
    this.minDate = new Date(new Date(this.passedData.biStartDt).setHours(0, 0, 0, 0));
    this.maxDate = new Date(new Date(this.passedData.biEndDt).setHours(0, 0, 0, 0));
    this.createContractTable();
    this.getBtCTypeList();
    this.getBtPTypeList();
    this.getBasedOn();
    this.getCustomers();
  }
  getCustomers() {
    this.mgaService.getCustomers().subscribe(resp => {
      // this.intermediaryList = resp;
      this.intermediaryList = (resp as any[]).map(result => {
        result.displayText = result.customerCode + ' - ' + result.customerName;
        return result;
      });
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }

  createContractTable() {
    this.contractualForm = this.fb.group({
      btType: [undefined, Validators.required],
      btCommPerc: [undefined, Validators.required],
      btBasedOn: [undefined, Validators.required],
      btRemarks: [undefined, Validators.required],
      btIntBrkCode: [undefined, Validators.required],
      btEffFmDt: [undefined, Validators.required],
      btEffToDt: [undefined],
      items: this.fb.array([])
    })
    this.getContractualTerms();
  }
  ngOnChanges(changes: SimpleChanges): void {
    let change: any = changes;
    if (change.custCode) {
      this.getContractualTerms();
    }
  }
  createItem(date?: any, endDate?: any): UntypedFormGroup {
    return this.fb.group({
      btType: [undefined, Validators.required],
      btCommPerc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btBasedOn: [undefined, Validators.required],
      btRemarks: [undefined, Validators.required],
      btIntBrkCode: [undefined, Validators.required],
      btEffFmDt: [date, Validators.required],
      btEffToDt: [endDate],
      srnoId: undefined,
      edited: false,
    },
      {
        validator: [this.dateValidators("btEffFmDt", "btEffToDt")]
      }
    );
  }
  getBtCTypeList() {
    this.mgaService.getBtContactTypeList('CONCTERM').subscribe(resp => {
      this.btTypeCList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getBtPTypeList() {
    this.mgaService.getBtContactTypeList('CONPTERM').subscribe(resp => {
      this.btTypePList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getBasedOn() {
    this.mgaService.getCoinPrmMtd().subscribe(resp => {
      this.basedOnList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  saveContratualForm(item, action, formName) {
    this.loaderService.isBusy = true;
    if (formName == 'contractual') {
      if (this.items.valid) {
        let contractTerms = item.value;
        if (action == 'save') {
          let obj = {
            binderLobTermsPK: {
              btAmendNo: this.amendNo,
              btRefNo: this.refNo,
              btSeqNo: this.seqNo,
              btProdSrNo: this.lobSrNo
            },
            btCrDt: new Date(),
            btCrUid: this.userId,
            btUpdDt: new Date(),
            btUpdUid: this.userId,
            btStatus: 'P',
            btEffFmDt: moment(item.value.btEffFmDt, 'DD-MM-YYYY'),
            btEffToDt: moment(item.value.btEffToDt, 'DD-MM-YYYY'),
            btFlex01: this.type,
            btFlex02: (this.type == 'COTERMS') ? 'CONCTERM' : 'CONPTERM',
            btCustCode: (this.type == 'COTERMS') ? this.custCode : 'NA',
          };

          Object.assign(contractTerms, obj);

          contractTerms = MgaUtils.clean(contractTerms);
          // this.loaderService.isBusy = false;
          this.mgaService.saveTerms(contractTerms).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Saved');
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: contractTerms.binderLobTermsPK.btProdSrNo });
              this.getContractualTerms('save');
              this.disableAddrow_cont = false;
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    this.decline();
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          })
        } else {
          let contractTerms = item.value;
          let obj = {
            binderLobTermsPK: {
              btAmendNo: this.amendNo,
              btRefNo: this.refNo,
              btSeqNo: this.seqNo,
              btProdSrNo: this.lobSrNo,
              btSrNo: contractTerms.srnoId
            },
            btUpdDt: new Date(),
            btUpdUid: this.userId,
            btStatus: 'P',
            btEffFmDt: moment(item.value.btEffFmDt, 'DD-MM-YYYY'),
            btEffToDt: moment(item.value.btEffToDt, 'DD-MM-YYYY'),
            btFlex01: this.type,
            btFlex02: (this.type == 'COTERMS') ? 'CONCTERM' : 'CONPTERM',
            btCustCode: (this.type == 'COTERMS') ? this.custCode : 'NA',
          };
          Object.assign(contractTerms, obj);

          contractTerms = MgaUtils.clean(contractTerms);
          this.mgaService.updateTerms(contractTerms, this.refNo, this.amendSrNo).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Updated');
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: contractTerms.binderLobTermsPK.btProdSrNo });
              this.getContractualTerms('save');
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: contractTerms.binderLobTermsPK.btProdSrNo });
              this.getContractualTerms('save');
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in Updating!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            }
          })
        }
      } else {
        MgaUtils.validateAllFormFields(this.contractualForm);
        this.toastService.warning('Enter mandatory fields');
        this.loaderService.isBusy = false;
      }
    }
  }
  openModal(content, val) {
    this.modalRef1 = this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalRef1.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.decline();
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  openConfirmModal_Contract(template: TemplateRef<any>, srNo, index, formName) {
    this.formName_cont = formName;
    this.deleteIndex_cont = srNo;
    this.index_cont = index;
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  decline(): void {
    this.modalRef.hide();
  }
  addItem(): void {
    this.items = this.contractualForm.get('items') as UntypedFormArray;
    if (_.size(this.items) > 0) {
      var size = _.size(this.items) - 1;
      // let date = new Date(moment(this.items.value[size].btEffToDt, 'DD-MM-YYYY').toDate());
      // date.setDate(date.getDate() + 1);
      this.items.push(
        this.createItem()//date
      );
      setTimeout(() => {
        for (let i = 0; i < this.items.value.length; i++) {
          if (this.items.value[i].edited == false) {
            this.disableAddrow_cont = true;
          } else {
            this.disableAddrow_cont = false;
          }
        }
      }, 100);
    } else {
      this.items.push(this.createItem(this.minDate, this.maxDate));
      setTimeout(() => {
        for (let i = 0; i < this.items.value.length; i++) {
          if (this.items.value[i].edited == false) {
            this.disableAddrow_cont = true;
          } else {
            this.disableAddrow_cont = false;
          }
        }
      }, 100);
    }
  }

  getContractualTerms(action?: string) {
    if (action != 'save') {
      let item = (this.contractualForm.get('items') as UntypedFormArray);
      while (item.value.length != 0) {
        item.removeAt(0)
      }
    }
    this.loaderService.isBusy = true;
    let custCode = (this.type == 'COTERMS') ? this.custCode : 'NA';
    let termType = (this.type == 'COTERMS') ? 'CONCTERM' : 'CONPTERM';
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, this.type, custCode, termType).subscribe(resp => {
      this.termsContractList = resp;
      if (this.termsContractList.length) {
        for (let i = 0; i < this.termsContractList.length; i++) {
          this.termsContractList[i].edited = true;
          this.termsContractList[i].btEffFmDt = (this.termsContractList[i].btEffFmDt == null) ? "" : new Date(this.termsContractList[i].btEffFmDt);
          this.termsContractList[i].btEffToDt = (this.termsContractList[i].btEffToDt == null) ? "" : new Date(this.termsContractList[i].btEffToDt);

          if (action != 'save') {
            this.addItem();
          }
          (this.contractualForm.get('items') as UntypedFormArray)
            .at(i)
            .get('srnoId').setValue(this.termsContractList[i].binderLobTermsPK.btSrNo, { emitEvent: true });
          this.contractualForm.patchValue({
            items: this.termsContractList
          })
        }
      } else {
        let item = (this.contractualForm.get('items') as UntypedFormArray);
        while (item.value.length != 0) {
          item.removeAt(0)
        }
        this.termsContractList = [];
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  confirmContract(srId, index, formName): void {
    this.loaderService.isBusy = true;
    if (srId == null && formName == 'contractual') {
      this.items.removeAt(index);
      this.modalRef.hide();
      this.loaderService.isBusy = false;
      this.disableAddrow_cont = false;
    } else {
      this.mgaService.deleteTerms(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, srId).subscribe(() => {
        this.toastService.success('Deleted Succcessfully.');
        this.loaderService.isBusy = false;
        if (formName == 'contractual') {
          this.items.removeAt(index);
          this.disableAddrow_cont = false;
        }
        this.modalRef.hide();
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.decline();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Deleting Data");
        }
      })
    }
  }
  dateValidators(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message = "Should be in Contract Period";
      const message1 = "Must be greater than Eff From Date";
      if (first.value && first.value < this.minDate || first.value > this.maxDate) {
        first.setErrors({ dateValidator: message });
        return { dateValidator: true };
      }
      if (second.value && second.value < first.value) {
        second.setErrors({ dateValidator: message1 });
        return { dateValidator: true };
      } else {
        second.setErrors(null);
      }
    };
  }
}
