import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as _ from 'lodash';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';

@Component({
  selector: 'mga-terms-demo',
  templateUrl: './mga-terms-demo.component.html',
  styleUrls: ['./mga-terms-demo.component.scss']
})
export class MgaTermsDemoComponent implements OnInit {
  profitShareTerm: UntypedFormGroup;
  termsMinCommForm: UntypedFormGroup;
  termsMinCommData: any;
  basedOnList: any = [];
  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() amendSrNo: string;
  @Input() action: string;
  @Input() seqNo: number;
  @Input() contractType: string;
  @Input() status: string;
  @Input() lobSrNo: number;
  @Input() passedData: any;
  @Input() lobInfo: any;

  disableAddrow_min: boolean = false;
  minDate: any;
  maxDate: any;
  items_min: UntypedFormArray;
  showDefault = false;
  infoLoading: boolean = false;
  modalRef: BsModalRef;


  userId: string = this.session.get('userId');

  deleteIndex: any;
  index: any;
  formName: any;
  @ViewChild('confirmDialog') confirmDialog: ElementRef;
  termsList: any;
  btTypeList: any;
  btTypeListWA: any;
  enableIntSave: boolean = false;
  enableProfShareSave: boolean = false;
  termCommData: any;
  freqList: any;
  btSrNo: any;
  isAvailForTerms: boolean = false;
  modalRef1: BsModalRef;
  @ViewChild('errorModal') errorModal: ElementRef;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private mgaService: MgaContractService,
    private modalService: BsModalService,
  ) { }

  ngOnInit() {
    // this.getBtTypeList('WA');
    this.getBtTypeList();
    this.minDate = new Date(new Date(this.passedData.biStartDt).setHours(0, 0, 0, 0));
    this.maxDate = new Date(new Date(this.passedData.biEndDt).setHours(0, 0, 0, 0));
    this.createMinCommTable();
    this.createProfitShareForm();
    this.getBasedOn();
    this.mgaService.defaultButton(this.refNo, this.seqNo, this.amendNo, this.lobInfo.bpLobCode).subscribe(res => {
      console.log(res);
      if (this.lobSrNo == res) {
        this.showDefault = true;
      } else {
        this.showDefault = false;
      }
    })
    this.mgaService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
      this.freqList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    })
  }
  createProfitShareForm() {
    this.profitShareTerm = this.fb.group({
      btPsFirstEvlDt: [undefined, Validators.required],
      btPsLastEvlDt: [undefined, Validators.required],
      btPsEvlFrq: [undefined, Validators.required],
      btPsFirstPc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPsInsExp: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPsInsFirstPc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPsInsLastPc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPsIntLicFees: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPsMgaFprcPc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPsMgaLastPc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPsYn: ['']
    })
    this.getTermData('PS');

  }
  getTermData(commType) {
    this.mgaService.getTermCommType(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'TERMS', 'NA', commType).subscribe(resp => {
      this.termCommData = resp.termCommList;
      if (this.termCommData.length > 0) {
        this.btSrNo = this.termCommData[0].mBinderTermsPK.btSrNo;
        this.mgaService.sendSavedDataTerms(false);
      }
      if (commType == 'PS') {
        this.profitShareTerm.patchValue({
          btPsFirstEvlDt: moment(this.termCommData[0].btPsFirstEvlDt).format('DD-MM-YYYY HH:mm'),
          btPsLastEvlDt: moment(this.termCommData[0].btPsLastEvlDt).format('DD-MM-YYYY HH:mm'),
          btPsEvlFrq: this.termCommData[0].btPsEvlFrq,
          btPsFirstPc: this.termCommData[0].btPsFirstPc,
          btPsInsExp: this.termCommData[0].btPsInsExp,
          btPsInsFirstPc: this.termCommData[0].btPsInsFirstPc,
          btPsInsLastPc: this.termCommData[0].btPsInsLastPc,
          btPsIntLicFees: this.termCommData[0].btPsIntLicFees,
          btPsMgaFprcPc: this.termCommData[0].btPsMgaFprcPc,
          btPsMgaLastPc: this.termCommData[0].btPsMgaLastPc
        })
        this.profitShareTerm.get('btPsYn').setValue((this.termCommData[0].btPsYn === 'Y'));
        if (this.termCommData[0].btPsYn === 'Y') {
          this.enableSaveBtnPft(true);
          // this.profitShareTerm.get('btPsYn').disable();
        }
      }
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getBtTypeList() {
    this.mgaService.getBtTypeList().subscribe(resp => {
      this.btTypeList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  createMinCommTable() {
    this.termsMinCommForm = this.fb.group({
      btType: [undefined],
      btRemarks: [undefined],
      btCommPerc: [undefined],
      btBasedOn: [undefined],
      btEffFmDt: [undefined, Validators.required],
      btEffToDt: [undefined],
      btStatus: [undefined],
      items_min: this.fb.array([])
    })
    this.getMinCommRules();
    this.getAllCommByRefId();
  }
  getBasedOn() {
    this.mgaService.getCoinPrmMtd().subscribe(resp => {
      this.basedOnList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  createItem_min(date?: any, endDate?: any): UntypedFormGroup {
    return this.fb.group({
      btType: [undefined, Validators.required],
      btRemarks: [undefined],
      btCommPerc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btBasedOn: [undefined, Validators.required],
      btEffFmDt: [date, Validators.required],
      btEffToDt: [endDate],
      btStatus: [''],
      srnoId: undefined,
      edited: false,
    },
      {
        validator: [this.dateValidators("btEffFmDt", "btEffToDt")]
      }
    );
  }
  getAllCommByRefId() {
    this.infoLoading = true;
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'TERMS', 'NA', '').subscribe(resp => {
      this.termsMinCommData = resp;
      this.infoLoading = false;
      this.loaderService.isBusy = false;
    }, error => {
      this.infoLoading = false;
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getMinCommRules(action?: string) {
    this.loaderService.isBusy = true;
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'TERMS', 'NA', '').subscribe(resp => {
      this.termsList = resp;
      if (this.termsList) {
        for (let i = 0; i < this.termsList.length; i++) {
          this.termsList[i].edited = true;
          this.termsList[i].btEffFmDt = (this.termsList[i].btEffFmDt == null) ? "" : new Date(this.termsList[i].btEffFmDt);
          this.termsList[i].btEffToDt = (this.termsList[i].btEffToDt == null) ? "" : new Date(this.termsList[i].btEffToDt);

          if (action != 'save') {
            this.addItem_min();
          }
          (this.termsMinCommForm.get('items_min') as UntypedFormArray)
            .at(i)
            .get('srnoId').setValue(this.termsList[i].binderLobTermsPK.btSrNo, { emitEvent: true });
          this.termsMinCommForm.patchValue({
            items_min: this.termsList
          })
        }
      }
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  // selectMaxDate_min(value, i) {
  //   if (_.size(this.termsMinCommForm.get("items_min").value) > 1) {
  //     (this.termsMinCommForm.get("items_min") as FormArray).at(i + 1).get("btEffFmDt").setValue(value);
  //   }
  // }
  saveForm(item, action, formName) {
    this.loaderService.isBusy = true;
    if (formName == 'minComm') {
      if (this.items_min.valid) {
        let termsMinComm = item.value;
        item.value.btEffToDt = (item.value.btEffToDt == 'Invalid date') ? null : item.value.btEffToDt;
        if (action == 'save') {
          console.log(item.value)
          let obj = {
            binderLobTermsPK: {
              btAmendNo: this.amendNo,
              btRefNo: this.refNo,
              btSeqNo: this.seqNo,
              btProdSrNo: this.lobSrNo
            },
            btCrDt: new Date(),
            btCrUid: this.userId,
            btUpdDt: new Date(),
            btUpdUid: this.userId,
            btStatus: 'P',
            btEffFmDt: moment(item.value.btEffFmDt).format('YYYY-MM-DD'),
            btEffToDt: (item.value.btEffToDt == null) ? null : moment(item.value.btEffToDt).format('YYYY-MM-DD'),
            btFlex01: "TERMS",
          };

          Object.assign(termsMinComm, obj);

          termsMinComm = MgaUtils.clean(termsMinComm);
          this.mgaService.saveTerms(termsMinComm).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Saved');
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: termsMinComm.binderLobTermsPK.btProdSrNo });
              this.getMinCommRules('save');
              this.disableAddrow_min = false;
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    this.decline();
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          })
        } else {
          let termsMinComm = item.value;
          let obj = {
            binderLobTermsPK: {
              btAmendNo: this.amendNo,
              btRefNo: this.refNo,
              btSeqNo: this.seqNo,
              btProdSrNo: this.lobSrNo,
              btSrNo: termsMinComm.srnoId
            },
            btUpdDt: new Date(),
            btUpdUid: this.userId,
            btStatus: 'P',
            btEffFmDt: moment(item.value.btEffFmDt).format('YYYY-MM-DD'),
            btEffToDt: (item.value.btEffToDt == null) ? null : moment(item.value.btEffToDt).format('YYYY-MM-DD'),
            btFlex01: "TERMS",
          };
          Object.assign(termsMinComm, obj);

          termsMinComm = MgaUtils.clean(termsMinComm);
          this.mgaService.updateTerms(termsMinComm, this.refNo, this.amendSrNo).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Updated');
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: termsMinComm.binderLobTermsPK.btProdSrNo });
              this.getMinCommRules('save');
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: termsMinComm.binderLobTermsPK.btProdSrNo });
              this.getMinCommRules('save');
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in Updating!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            }
          })
        }
      } else {
        MgaUtils.validateAllFormFields(this.termsMinCommForm);
        this.toastService.warning('Enter mandatory fields');
        this.loaderService.isBusy = false;
      }
    }
  }
  openModal(content, val) {
    this.modalRef1 = this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalRef1.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.decline();
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  openConfirmModal(template: TemplateRef<any>, srNo, index, formName) {
    this.formName = formName;
    this.deleteIndex = srNo;
    this.index = index;
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  dateValidators(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message = "Should be in Contract Period";
      const message1 = "Must be greater than Eff From Date";
      if (first.value && first.value < this.minDate || first.value > this.maxDate) {
        first.setErrors({ dateValidator: message });
        return { dateValidator: true };
      }
      if (second.value && second.value < first.value) {
        second.setErrors({ dateValidator: message1 });
        return { dateValidator: true };
      } else {
        second.setErrors(null);
      }
    };
  }
  addItem_min(): void {
    this.items_min = this.termsMinCommForm.get('items_min') as UntypedFormArray;
    if (_.size(this.items_min) > 0) {
      var size = _.size(this.items_min) - 1;
      // let date = new Date(moment(this.items_min.value[size].btEffToDt, 'DD-MM-YYYY').toDate());
      // date.setDate(date.getDate() + 1);
      this.items_min.push(
        this.createItem_min()//date
      );
      setTimeout(() => {
        for (let i = 0; i < this.items_min.value.length; i++) {
          if (this.items_min.value[i].edited == false) {
            this.disableAddrow_min = true;
          } else {
            this.disableAddrow_min = false;
          }
        }
      }, 100);
    } else {
      this.items_min.push(this.createItem_min(this.minDate, this.maxDate));
      setTimeout(() => {
        for (let i = 0; i < this.items_min.value.length; i++) {
          if (this.items_min.value[i].edited == false) {
            this.disableAddrow_min = true;
          } else {
            this.disableAddrow_min = false;
          }
        }
      }, 100);
    }
  }
  openDefaultTerm(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  decline(): void {
    this.modalRef.hide();
  }
  ConfirmDefault() {
    if (this.termsMinCommForm.value['items_min'].length !== 0) {
      this.loaderService.isBusy = true;
      this.mgaService.defaultAllTermsButton(this.refNo, this.seqNo, this.amendNo, this.lobInfo.bpLobCode, this.lobSrNo, this.lobInfo.bpCompCode).subscribe(res => {
        this.toastService.success('Updated Successfully');
        this.loaderService.isBusy = false;
        this.modalRef.hide();
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Updating!");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.decline();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Updating!");
        }
      })
    } else {
      this.toastService.warning('Add Data in Commission')
    }
  }

  confirm(srId, index, formName): void {
    this.loaderService.isBusy = true;
    if (srId == null && formName == 'minComm') {
      this.items_min.removeAt(index);
      this.modalRef.hide();
      this.loaderService.isBusy = false;
      this.disableAddrow_min = false;
    } else {
      this.mgaService.deleteTerms(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, srId).subscribe(() => {
        this.toastService.success('Deleted Succcessfully.');
        this.loaderService.isBusy = false;
        if (formName == 'minComm') {
          this.items_min.removeAt(index);
          this.disableAddrow_min = false;
        }
        this.modalRef.hide();
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.decline();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Deleting Data");
        }
      })
    }
  }
  enableSaveBtnPft(evnt) {
    if (evnt) {
      this.enableProfShareSave = true;
      if (this.termCommData.length > 0) {
        if (this.termCommData[0].btPsYn !== 'Y') {
          this.isAvailForTerms = true;
        } else {
          this.isAvailForTerms = false;
        }
      } else {
        this.isAvailForTerms = true;
      }
      this.mgaService.sendSavedDataTerms(this.isAvailForTerms);
    } else {
      this.enableProfShareSave = false;
      this.isAvailForTerms = false;
      this.profitShareTerm.reset();
      this.mgaService.sendSavedDataTerms(this.isAvailForTerms);
      this.clearValidators(this.profitShareTerm);
    }
  }
  clearValidators(formGroup: UntypedFormGroup | UntypedFormArray) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsUntouched({ onlySelf: true });
        control.markAsPristine({ onlySelf: true });
      }
    });
  }
  saveProfitShare() {
    this.loaderService.isBusy = true;
    if (this.profitShareTerm.valid) {
      let formData = this.profitShareTerm.getRawValue();
      let obj = {
        binderLobTermsPK: {
          btAmendNo: this.amendNo,
          btRefNo: this.refNo,
          btSeqNo: this.seqNo,
          btProdSrNo: this.lobSrNo,
          btSrNo: (this.btSrNo == undefined) ? 0 : this.btSrNo
        },
        btCrDt: new Date(),
        btCrUid: this.userId,
        btUpdDt: new Date(),
        btUpdUid: this.userId,
        btStatus: 'P',
        btFlex01: "TERMS",
        btPsYn: 'Y',
      };
      Object.assign(formData, obj);
      formData.btPsFirstEvlDt = (typeof (formData.btPsFirstEvlDt) == 'string') ? moment(formData.btPsFirstEvlDt, 'DD/MM/YYYY') : moment(formData.btPsFirstEvlDt)
      formData.btPsLastEvlDt = (typeof (formData.btPsLastEvlDt) == 'string') ? moment(formData.btPsLastEvlDt, 'DD/MM/YYYY') : moment(formData.btPsLastEvlDt)
      formData = MgaUtils.clean(formData);
      this.mgaService.saveTerms(formData).subscribe((resp) => {
        if (resp.messageType == 'S') {
          this.toastService.success('Successfully Saved');
          this.loaderService.isBusy = false;
          this.mgaService.sendSavedDataTerms(this.isAvailForTerms);
          this.isAvailForTerms = false;
          this.getTermData('PS');
        } else if (resp.messageType == 'U') {
          this.loaderService.isBusy = false;
          this.toastService.success(resp.message);
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error(resp.message);
        }
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      })
    } else {
      MgaUtils.validateAllFormFields(this.profitShareTerm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
}