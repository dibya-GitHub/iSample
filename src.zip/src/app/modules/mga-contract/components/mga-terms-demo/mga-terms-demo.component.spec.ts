import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-terms-demo/mga-terms-demo.component.spec.ts
import { MgaTermsDemoComponent } from './mga-terms-demo.component';

describe('MgaTermsDemoComponent', () => {
  let component: MgaTermsDemoComponent;
  let fixture: ComponentFixture<MgaTermsDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaTermsDemoComponent ]
=======
import { FacRiskPerilComponent } from './fac-risk-peril.component';

describe('FacRiskPerilComponent', () => {
  let component: FacRiskPerilComponent;
  let fixture: ComponentFixture<FacRiskPerilComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacRiskPerilComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/fac-risk-peril/fac-risk-peril.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-terms-demo/mga-terms-demo.component.spec.ts
    fixture = TestBed.createComponent(MgaTermsDemoComponent);
=======
    fixture = TestBed.createComponent(FacRiskPerilComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/fac-risk-peril/fac-risk-peril.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
