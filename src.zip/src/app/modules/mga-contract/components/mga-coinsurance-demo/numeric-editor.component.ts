import { Component, ViewContainerRef, ViewChild, AfterViewInit } from '@angular/core';

import { ICellEditorAngularComp } from '@ag-grid-community/angular';

@Component({
    selector: 'numeric-cell',
    template: `<p-inputNumber #input mode="decimal" [useGrouping]="false" autocomplete="off"
		inputStyleClass="form-control rightAlign" [(ngModel)]="value" required
		[minFractionDigits]="2" [maxFractionDigits]="4" placeholder="Enter Accounting CCY Net Amount"
		></p-inputNumber>
        `
})
export class NumericEditorComponent implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: number;
    // private cancelBeforeStart: boolean = false;

    @ViewChild('input', { read: ViewContainerRef }) public input;


    agInit(params: any): void {
        this.params = params;
        this.value = this.params.value;

        // only start edit if key pressed is a number, not a letter
        // this.cancelBeforeStart = params.charPress && ('1234567890'.indexOf(params.charPress) < 0);
    }

    getValue(): any {
        return this.value;
    }

    // isCancelBeforeStart(): boolean {
    //     return this.cancelBeforeStart;
    // }

    // // will reject the number if it greater than 1,000,000
    // // not very practical, but demonstrates the method.
    // isCancelAfterEnd(): boolean {
    //     return this.value > 1000000;
    // };

    // onKeyDown(event): void {
    //     if (!this.isKeyPressedNumeric(event)) {
    //         if (event.preventDefault) event.preventDefault();
    //     }
    // }

    // private getCharCodeFromEvent(event): any {
    //     event = event || window.event;
    //     return (typeof event.which == "undefined") ? event.keyCode : event.which;
    // }

    // private isCharNumeric(charStr): boolean {
    //     return !!/\d/.test(charStr);
    // }

    // private isKeyPressedNumeric(event): boolean {
    //     var charCode = this.getCharCodeFromEvent(event);
    //     var charStr = String.fromCharCode(charCode);
    //     return this.isCharNumeric(charStr);
    // }
    // dont use afterGuiAttached for post gui events - hook into ngAfterViewInit instead for this
    ngAfterViewInit() {
        this.input.element.nativeElement.focus();
    }

}
