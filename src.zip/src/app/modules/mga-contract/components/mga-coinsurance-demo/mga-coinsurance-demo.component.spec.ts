import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-coinsurance-demo/mga-coinsurance-demo.component.spec.ts
import { MgaCoinsuranceDemoComponent } from './mga-coinsurance-demo.component';

describe('MgaCoinsuranceDemoComponent', () => {
  let component: MgaCoinsuranceDemoComponent;
  let fixture: ComponentFixture<MgaCoinsuranceDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaCoinsuranceDemoComponent ]
=======
import { TreatyApprContractComponent } from './treaty-appr-contract.component';

describe('TreatyApprContractComponent', () => {
  let component: TreatyApprContractComponent;
  let fixture: ComponentFixture<TreatyApprContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyApprContractComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/treaty-appr-contract/treaty-appr-contract.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-coinsurance-demo/mga-coinsurance-demo.component.spec.ts
    fixture = TestBed.createComponent(MgaCoinsuranceDemoComponent);
=======
    fixture = TestBed.createComponent(TreatyApprContractComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/treaty-appr-contract/treaty-appr-contract.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
