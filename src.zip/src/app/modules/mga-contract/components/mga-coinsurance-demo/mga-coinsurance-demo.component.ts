import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { Module } from '@ag-grid-enterprise/all-modules';
import { ColumnsToolPanelModule } from '@ag-grid-enterprise/column-tool-panel';
import { MenuModule } from '@ag-grid-enterprise/menu';
import { RichSelectModule } from '@ag-grid-enterprise/rich-select';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as _ from 'lodash';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';
import { RadiorenderComponent2 } from './../radiorender/radiorender2.component';
import { NumericEditorComponent } from './numeric-editor.component';

@Component({
  selector: 'mga-coinsurance-demo',
  templateUrl: './mga-coinsurance-demo.component.html',
  styleUrls: ['./mga-coinsurance-demo.component.scss']
})
export class MgaCoinsuranceDemoComponent implements OnInit {

  coinsuranceTermForm: UntypedFormGroup;

  coinsuranceTermData: any;

  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() amendSrNo: string;
  @Input() action: string;
  @Input() seqNo: number;
  @Input() contractType: string;
  @Input() status: string;
  @Input() lobSrNo: number;
  @Input() passedData: any;
  @Input() lobInfo: any;
  @Input() prodInfo: any;

  disableAddrow: boolean = false;
  minDate: any;
  maxDate: any;
  items_coins: UntypedFormArray;
  showDefault = false;
  infoLoading: boolean = false;
  modalRef: BsModalRef;
  modalRef1: BsModalRef;
  userId: string = this.session.get('userId');

  deleteIndex: any;
  index: any;
  formName: any;
  @ViewChild('confirmDialog') confirmDialog: ElementRef;
  coinsList: any;
  btTypeList: any;
  premMethodList: any;
  profitCommForm: UntypedFormGroup;
  SSCForm: UntypedFormGroup;
  // introducerForm: FormGroup;
  slidingScaleRateForm: UntypedFormGroup;
  slidingScaleRateList: any = [];
  public columnDefsSSC;
  items: UntypedFormArray;

  freqList: any;
  mgaCoinsuranceForm: UntypedFormGroup;
  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  public columnDefs;
  public bottomColumns;
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;
  bottomData: any = [];
  lobCoinsuranceList: any;
  maxSharePerc: number = 0;
  coinsuereList: any;
  showForm: boolean = false;
  AddFlag: boolean = true;
  selectedLob: any;
  temp: any;
  closeResult: string;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  isExceedAmount100: boolean = false;
  termCommData: any;
  enableIntSave: boolean = false;
  enableSSCSave: boolean = false;
  enablePCSave: boolean = false;

  coinsIntData: any = [];
  coinsSSCData: any = [];
  coinsPCData: any = [];

  isAvailGroup: any = {
    isIntAvail: false,
    isSSCAvail: false,
    isPCAvail: false
  };
  keyword: any = 'value';
  initialValue: any = '';
  data: any;
  isLoadingResult: boolean;
  errorMsg: string;
  recentSelection: any;
  btSrNoIC: any;
  btSrNoSSC: any;
  btSrNoPC: any;
  isAvailLeader: boolean = false;
  bcSrNo: any;
  public modules: Module[] = [
    ClientSideRowModelModule,
    RichSelectModule,
    MenuModule,
    ColumnsToolPanelModule
  ];
  private editingRowIndex;
  @ViewChild('errorModal') errorModal: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private mgaService: MgaContractService,
    private modalService: BsModalService,
  ) { }

  ngOnInit() {
    this.getBtTypeList();
    // this.getBtTypeList('A');
    this.minDate = new Date(new Date(this.passedData.biStartDt).setHours(0, 0, 0, 0));
    this.maxDate = new Date(new Date(this.passedData.biEndDt).setHours(0, 0, 0, 0));
    this.createCoinsTable();
    this.createProfitCommTable();
    this.createSSCFormTable();
    // this.createIntroducerForm();
    this.slidingScaleRateForm = this.fb.group({
      btSscMinLr: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btSscMaxLr: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btSscLrDiff: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btSscMinComm: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btSscMaxComm: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btSscCommDiff: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
    }, {
      validator: [this.graterValidator("btSscMinLr", "btSscMaxLr"), this.graterValidator("btSscMinComm", "btSscMaxComm")]
    })
    this.getPremiumList();

    this.columnDefs = [
      {
        headerName: "Select",
        field: 'binderCoinsPK.bcSrNo',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
        width: 100,
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        headerName: "Coinsurer",
        headerTooltip: "Coinsurer",
        field: "bcCustCodeShortDesc",
        width: 350,
      },
      {
        headerName: "Leader",
        headerTooltip: "Leader",
        field: "bcLeaderYn",
        width: 100,
        cellStyle: { textAlign: 'center' },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === '1') {
            return '<span class="ag-element"> Yes </span>';
          } else if (params.value === '0') {
            return '<span class="ag-element"> No </span>';
          }
        },
      },
      {
        headerName: "Share %",
        headerTooltip: "Share %",
        field: "bcSharePerc",
        width: 100,
        valueFormatter: MgaUtils.currencyFormatter4,
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Action",
        template:
          `<a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>&nbsp;
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
          </a>`,
        cellStyle: { textAlign: 'center' },
        resizable: false,
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
    ];
    this.bottomColumns = [
      {
        headerName: "Select",
        field: 'binderCoinsPK.bcProdSrNo',
        width: 100,
      },
      {
        headerName: "Coinsurer",
        field: "bcCustCodeShortDesc",
        width: 350,
      },
      {
        headerName: "Leader",
        field: "bcLeaderYn",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Share %",
        field: "bcSharePerc",
        width: 100,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter4
      },
      {
        headerName: "Action",
        cellStyle: { textAlign: 'center' },
      }
    ];
    this.columnDefsSSC = [
      {
        headerName: "Loss Ratio From",
        headerTooltip: "Loss Ratio From",
        field: "bsMinLrPerc",
        width: 270,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
        editable: true,
        cellEditorFramework: NumericEditorComponent,
      },
      {
        headerName: "Loss Ratio To",
        headerTooltip: "Loss Ratio To",
        field: "bsMaxLrPerc",
        width: 270,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
        editable: true,
        cellEditorFramework: NumericEditorComponent,
      },
      {
        headerName: "Applicable Commission",
        headerTooltip: "Applicable Commission",
        field: "bsCommPerc",
        width: 270,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
        editable: true,
        cellEditorFramework: NumericEditorComponent,
      },
      {
        headerName: "Action",
        cellStyle: { textAlign: 'center' },
        width: 100,
        cellRenderer: actionCellRenderer,
        editable: false,
        colId: "action"
      }
    ];

    this.createForm();
    this.agGridOptions();
    this.mgaService.defaultButton(this.refNo, this.seqNo, this.amendNo, this.lobInfo.bpLobCode).subscribe(res => {
      if (this.lobSrNo == res) {
        this.showDefault = true;
      } else {
        this.showDefault = false;
      }
    })
  }
  createSSCFormTable() {
    this.SSCForm = this.fb.group({
      btSscProv: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btSscEvlFrq: [undefined, Validators.required],
      btSscFirstEvlDt: [undefined, Validators.required],
      btSscLastEvlDt: [undefined, Validators.required],
      btSscYn: [''],
    })
    this.getTermData('NA', 'SSC');
  }
  createProfitCommTable() {
    this.profitCommForm = this.fb.group({
      btPcEvlFrq: [undefined, Validators.required],
      btPcFirstEvlDt: [undefined, Validators.required],
      btPcLastEvlDt: [undefined, Validators.required],
      btPcFinalPerc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPcMePerc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPcProvPerc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btPcYn: [''],
    })
    this.getTermData('NA', 'PC');

  }
  getTermData(custCode, commType) {
    this.mgaService.getTermCommType(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'COTERMS', custCode, commType).subscribe(resp => {
      this.termCommData = resp.termCommList;
      if (this.termCommData.length > 0) {
        // this.slidingScaleRateForm.patchValue({
        //   btSscMinLr: undefined,
        //   btSscMaxLr: undefined,
        //   btSscLrDiff: undefined,
        //   btSscMinComm: undefined,
        //   btSscMaxComm: undefined,
        //   btSscCommDiff: undefined,
        // })

        if (commType == 'SSC') {
          this.coinsSSCData = this.termCommData;
          this.btSrNoSSC = this.coinsSSCData[0].mBinderTermsPK.btSrNo;
          this.SSCForm.patchValue({
            btSscProv: this.coinsSSCData[0].btSscProv,
            btSscEvlFrq: this.coinsSSCData[0].btSscEvlFrq,
            btSscFirstEvlDt: moment(this.coinsSSCData[0].btSscFirstEvlDt).format('DD-MM-YYYY HH:mm'),
            btSscLastEvlDt: moment(this.coinsSSCData[0].btSscLastEvlDt).format('DD-MM-YYYY HH:mm'),
          })


          if (this.coinsSSCData[0].btSscMinLr !== null) {
            this.slidingScaleRateForm.get('btSscMinLr').setValue(this.coinsSSCData[0].btSscMinLr);
            this.slidingScaleRateForm.get('btSscMinLr').markAsTouched({ onlySelf: true });
          } else {
            this.slidingScaleRateForm.get('btSscMinLr').markAsUntouched({ onlySelf: true });
            this.slidingScaleRateForm.get('btSscMinLr').markAsPristine({ onlySelf: true });
          }
          if (this.coinsSSCData[0].btSscMaxLr !== null) {
            this.slidingScaleRateForm.get('btSscMaxLr').setValue(this.coinsSSCData[0].btSscMaxLr);
            this.slidingScaleRateForm.get('btSscMaxLr').markAsTouched({ onlySelf: true });

          } else {
            this.slidingScaleRateForm.get('btSscMaxLr').markAsUntouched({ onlySelf: true });
            this.slidingScaleRateForm.get('btSscMaxLr').markAsPristine({ onlySelf: true });
          }
          if (this.coinsSSCData[0].btSscLrDiff !== null) {
            this.slidingScaleRateForm.get('btSscLrDiff').setValue(this.coinsSSCData[0].btSscLrDiff);
            this.slidingScaleRateForm.get('btSscLrDiff').markAsTouched({ onlySelf: true });

          } else {
            this.slidingScaleRateForm.get('btSscLrDiff').markAsUntouched({ onlySelf: true });
            this.slidingScaleRateForm.get('btSscLrDiff').markAsPristine({ onlySelf: true });
          }
          if (this.coinsSSCData[0].btSscMinComm !== null) {
            this.slidingScaleRateForm.get('btSscMinComm').setValue(this.coinsSSCData[0].btSscMinComm);
            this.slidingScaleRateForm.get('btSscMinComm').markAsTouched({ onlySelf: true });
          } else {
            this.slidingScaleRateForm.get('btSscMinComm').markAsUntouched({ onlySelf: true });
            this.slidingScaleRateForm.get('btSscMinComm').markAsPristine({ onlySelf: true });
          }
          if (this.coinsSSCData[0].btSscMaxComm !== null) {
            this.slidingScaleRateForm.get('btSscMaxComm').setValue(this.coinsSSCData[0].btSscMaxComm);
            this.slidingScaleRateForm.get('btSscMaxComm').markAsTouched();

          } else {
            this.slidingScaleRateForm.get('btSscMaxComm').markAsUntouched({ onlySelf: true });
            this.slidingScaleRateForm.get('btSscMaxComm').markAsPristine({ onlySelf: true });
          }
          if (this.coinsSSCData[0].btSscCommDiff !== null) {
            this.slidingScaleRateForm.get('btSscCommDiff').setValue(this.coinsSSCData[0].btSscCommDiff);
            this.slidingScaleRateForm.get('btSscCommDiff').markAsTouched();
          } else {
            this.slidingScaleRateForm.get('btSscCommDiff').markAsUntouched({ onlySelf: true });
            this.slidingScaleRateForm.get('btSscCommDiff').markAsPristine({ onlySelf: true });
          }
          this.SSCForm.get('btSscYn').setValue((this.coinsSSCData[0].btSscYn === 'Y'));

          if (this.coinsSSCData[0].btSscYn === 'Y') {
            // this.SSCForm.get('btSscYn').disable();
            this.enableSaveBtnSSC(true);
          }

        } else if (commType == 'PC') {
          this.coinsPCData = this.termCommData;
          this.btSrNoPC = this.coinsPCData[0].mBinderTermsPK.btSrNo;
          this.profitCommForm.patchValue({
            btPcEvlFrq: this.coinsPCData[0].btPcEvlFrq,
            btPcFirstEvlDt: moment(this.coinsPCData[0].btPcFirstEvlDt).format('DD-MM-YYYY HH:mm'),
            btPcLastEvlDt: moment(this.coinsPCData[0].btPcLastEvlDt).format('DD-MM-YYYY HH:mm'),
            btPcFinalPerc: this.coinsPCData[0].btPcFinalPerc,
            btPcMePerc: this.coinsPCData[0].btPcMePerc,
            btPcProvPerc: this.coinsPCData[0].btPcProvPerc,
          })
          this.profitCommForm.get('btPcYn').setValue((this.coinsPCData[0].btPcYn === 'Y'));
          if (this.coinsPCData[0].btPcYn === 'Y') {
            // this.profitCommForm.get('btPcYn').disable();
            this.enableSaveBtnPC(true);
          }
        }
        let obj = {
          isIntAvail: false,
          isSSCAvail: false,
          isPCAvail: false,
        }
        this.mgaService.sendSavedCoinsData(obj);
      } else {
        if (commType == 'SSC') {
          this.coinsSSCData = this.termCommData;
          this.btSrNoSSC = 0;
          this.SSCForm.patchValue({
            btSscProv: null,
            btSscEvlFrq: null,
            btSscFirstEvlDt: null,
            btSscLastEvlDt: null,
          })
          this.slidingScaleRateForm.reset();
          this.SSCForm.get('btSscYn').setValue(false);
          this.SSCForm.get('btSscYn').enable();
          this.enableSaveBtnSSC(false);
        } else if (commType == 'PC') {
          this.coinsPCData = this.termCommData;
          this.btSrNoPC = 0;
          this.profitCommForm.patchValue({
            btPcEvlFrq: null,
            btPcFirstEvlDt: null,
            btPcLastEvlDt: null,
            btPcFinalPerc: null,
            btPcMePerc: null,
            btPcProvPerc: null,
          })
          this.profitCommForm.get('btPcYn').setValue(false);
          this.profitCommForm.get('btPcYn').enable();
          this.enableSaveBtnPC(false);
        }
      }

    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }

  getTermSSCgridData(custCode) {
    this.slidingScaleRateList = [];
    this.mgaService.getTermCommType(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'COTERMS', custCode, 'SSC').subscribe(resp => {
      this.slidingScaleRateList = resp.sscList;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  createForm() {
    this.mgaCoinsuranceForm = this.fb.group({
      bcCustCode: ['', Validators.required],
      bcSharePerc: ['', Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      bcLeaderYn: ['0'],
      srnoId: undefined,
    });
    this.getAllLobCoinsuranceByRefId();
  }
  getMasterData() {
    this.loaderService.isBusy = true;
    this.mgaService.getCoinsList(this.refNo, this.seqNo, this.amendNo, this.lobSrNo).subscribe((coinsuere: any) => {
      this.coinsuereList = (coinsuere as any[]).map(coins => {
        coins.displayText = coins.code + ' - ' + coins.description;
        return coins;
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getEditCoinsList() {
    this.loaderService.isBusy = true;
    this.mgaService.getEditCoinsList().subscribe((coinsuere: any) => {
      this.coinsuereList = (coinsuere as any[]).map(coins => {
        coins.displayText = coins.code + ' - ' + coins.description;
        return coins;
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getAllLobCoinsuranceByRefId() {
    this.maxSharePerc = 0;
    this.loaderService.isBusy = true;
    this.getMasterData();
    this.mgaService.getCoinsurancebyRefNoSrNo(this.refNo, this.seqNo, this.amendNo, this.lobSrNo).subscribe(resp => {
      this.lobCoinsuranceList = resp;
      this.isAvailLeader = false;
      if (this.lobCoinsuranceList.length > 0) {
        this.context.componentParent.selectedRowId = this.lobCoinsuranceList[0].binderCoinsPK.bcSrNo;
        this.selectedRowData({ data: this.lobCoinsuranceList[0] });
        for (var i = 0; i < this.lobCoinsuranceList.length; i++) {
          this.maxSharePerc = this.maxSharePerc + this.lobCoinsuranceList[i].bcSharePerc;
          if (this.lobCoinsuranceList[i].bcLeaderYn == '1') {
            this.isAvailLeader = true;
          }
        }
      } else {
        this.maxSharePerc = 0;
        this.infoLoading = true;
        let item = (this.coinsuranceTermForm.get('items_coins') as UntypedFormArray);

        while (item.value.length != 0) {
          item.removeAt(0)
        }
        this.coinsuranceTermData = undefined;
        this.infoLoading = false;
        this.getTermData('NA', 'SSC');
        this.getTermData('NA', 'PC');
      }
      this.bottomDataDetails();
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  selectedRowData(cell) {
    this.selectedLob = cell.data;
    this.getTermData(this.selectedLob.bcCustCode, 'SSC');
    this.getTermData(this.selectedLob.bcCustCode, 'PC');
    this.getTermSSCgridData(this.selectedLob.bcCustCode);
    this.getAllByRefId(this.selectedLob.bcCustCode);
    let item = (this.coinsuranceTermForm.get('items_coins') as UntypedFormArray)
    while (item.value.length != 0) {
      item.removeAt(0)
    }
    this.getRules(this.selectedLob.bcCustCode);
  }
  back() {
    this.showForm = false;
    this.AddFlag = true;
    this.mgaCoinsuranceForm.reset();
  }
  addCoinsurerInfo() {
    this.action = 'add';
    this.mgaCoinsuranceForm.reset();
    this.showForm = true;
    this.AddFlag = false;
    this.getMasterData();
    this.mgaCoinsuranceForm.get('bcCustCode').enable();
    this.loaderService.isBusy = false;
  }
  addItem(): void {
    this.items = this.slidingScaleRateForm.get('items') as UntypedFormArray;
    this.items.push(this.createItem1());
    setTimeout(() => {
      for (let i = 0; i < this.items.value.length; i++) {
        if (this.items.value[i].edited == false) {
          this.disableAddrow = true;
        } else {
          this.disableAddrow = false;
        }
      }
    }, 100);
  }
  createItem1(data?: any): UntypedFormGroup {
    return this.fb.group({
      tsMinLrPerc: [undefined, Validators.required],
      tsMaxLrPerc: [undefined, Validators.required],
      tsCommPerc: [undefined, Validators.required],
      edited: false,
      tsId: undefined,
    }, {
      validator: [this.graterValidator("tsMinLrPerc", "tsMaxLrPerc")]
    });
  }

  checkValue(event) {
    if (event.target.checked) {
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent2
    };
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("mgaCoinsuereGrid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.onActionEditCoinsurance(data);
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
  onRowClickedSSC(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action");
      switch (actionType) {
        case "Edit":
          return this.onActionEditSSC(e);
        case "Delete":
          return this.onActionEditSSC(e);
      }
    }
  }
  onRowEditingStarted(params) {
    params.api.refreshCells({
      columns: ["action"],
      rowNodes: [params.node],
      force: true
    });
  }
  onRowEditingStopped(params) {
    params.api.refreshCells({
      columns: ["action"],
      rowNodes: [params.node],
      force: true
    });
  }
  onActionEditSSC(params) {
    if (params.column.colId === "action" && params.event.target.dataset.action) {
      let action = params.event.target.dataset.action;
      if (action === "edit") {
        params.api.startEditingCell({
          rowIndex: params.node.rowIndex,
          colKey: params.columnApi.getDisplayedCenterColumns()[0].colId
        });
      }
      if (action === "delete") {
        this.deleteCell(params);
      }
      if (action === "update") {
        this.updateCell(params);
      }
      if (action === "cancel") {
        params.api.stopEditing(true);
      }
    }
  }
  deleteCell(params) {
    this.loaderService.isBusy = true;
    let data = params.data.binderSscPK;
    this.mgaService.deleteSSCInfo(data.bsRefNo, data.bsSeqNo, data.bsAmendNo, data.bsProdSrNo, data.bsSrNo, data.bsCustCode).subscribe((resp) => {
      params.api.applyTransaction({
        remove: [params.node.data]
      });
      if (resp["messageType"] && resp["messageType"] == 'E') {
        this.toastService.error(resp["message"]);
      } else if (resp["messageType"] && resp["messageType"] == 'D') {
        this.toastService.success("Deleted Successfully!");
      } else {
        this.toastService.success(resp["message"]);
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.message);
    })
  }
  updateCell(params) {
    this.loaderService.isBusy = true;
    params.api.stopEditing(false);
    let data = params.data;
    this.mgaService.updateSSCInfo(data, data.binderSscPK.bsRefNo).subscribe((resp) => {
      if (resp["messageType"] && resp["messageType"] == 'E') {
        this.toastService.error(resp["message"]);
      } else if (resp["messageType"] && resp["messageType"] == 'U') {
        this.toastService.success("Updated Successfully!");
      } else {
        this.toastService.success(resp["message"]);
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.message);
    })
  }
  showDialogbox(data: any) {
    this.temp = data.binderCoinsPK;
    this.open(this.confirmModal, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  close(){
    this.modalService.hide();
  }
  existLeader: any;
  onActionEditCoinsurance(data: any) {
    this.loaderService.isBusy = true;
    this.action = 'edit';
    this.showForm = true;
    this.AddFlag = false;
    this.selectedLob = data;
    this.bcSrNo = data.binderCoinsPK.bcSrNo;
    this.getEditCoinsList();
    this.existLeader = data.bcLeaderYn;
    this.mgaCoinsuranceForm.get('bcCustCode').disable();
    this.mgaCoinsuranceForm.patchValue({
      bcCustCode: data.bcCustCode,
      bcSharePerc: data.bcSharePerc
    });
    this.mgaCoinsuranceForm.patchValue({
      bcLeaderYn: (data.bcLeaderYn === '1') ? true : false
    })
    this.loaderService.isBusy = false;
  }
  deleteRow() {
    this.loaderService.isBusy = true;
    if (this.temp && this.temp.bcRefNo && this.temp.bcSrNo) {
      this.mgaService.deleteCoinsurance(this.temp.bcRefNo, this.seqNo, this.amendNo, this.temp.bcProdSrNo, this.temp.bcSrNo).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully.');
        this.getAllLobCoinsuranceByRefId();
        this.loaderService.isBusy = false;
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.decline();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Deleting Data");
        }
      })
    } else {
      this.loaderService.isBusy = false;
      this.toastService.error('Error in Deleting Data');
    }
  }

  graterValidator(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message =
        "Must be greater or eq to Loss ratio %";
      if (second.value > first.value) {

      } else if (second.value == first.value) {
      } else {
        second.setErrors({ equalValue: message });
        return { equalValue: true };
      }
    };
  }
  getBtTypeList() {
    this.mgaService.getBtCoTypeList().subscribe(resp => {
      this.btTypeList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getPremiumList() {
    this.mgaService.getCoinPrmMtd().subscribe(resp => {
      this.premMethodList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
    this.mgaService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
      this.freqList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    })
  }


  createCoinsTable() {
    this.coinsuranceTermForm = this.fb.group({
      btType: [undefined],
      btRemarks: [undefined],
      btBasedOn: [undefined],
      btCommPerc: [undefined],
      btAdjustYear: [undefined],
      btMinLrPerc: [undefined],
      btMaxLrPerc: [undefined],
      btEffFmDt: [undefined, Validators.required],
      btEffToDt: [undefined],
      btStatus: [undefined],
      items_coins: this.fb.array([])
    })
  }

  createItem(date?: any, endDate?: any): UntypedFormGroup {
    return this.fb.group({
      btType: [undefined, Validators.required],
      btRemarks: [undefined],
      btBasedOn: [undefined, Validators.required],
      btCommPerc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      btAdjustYear: [''],
      btMinLrPerc: [''],
      btMaxLrPerc: [''],
      btEffFmDt: [date, Validators.required],
      btEffToDt: [endDate],
      btStatus: [''],
      srnoId: undefined,
      edited: false,
    }
      , {
        validator: [this.dateValidators("btEffFmDt", "btEffToDt")]
      }
    );
  }
  getAllByRefId(bcCustCode) {
    this.infoLoading = true;
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'COTERMS', bcCustCode, '').subscribe(resp => {
      this.coinsuranceTermData = resp;
      this.infoLoading = false;
      this.loaderService.isBusy = false;
    }, error => {
      this.infoLoading = false;
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getRules(bcCustCode, action?: string) {
    this.loaderService.isBusy = true;
    this.mgaService.getTermRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, 'COTERMS', bcCustCode, '').subscribe(resp => {
      this.coinsList = resp;
      if (this.coinsList.length) {
        for (let i = 0; i < this.coinsList.length; i++) {
          this.coinsList[i].edited = true;
          this.coinsList[i].btEffFmDt = (this.coinsList[i].btEffFmDt == null) ? "" : new Date(this.coinsList[i].btEffFmDt);
          this.coinsList[i].btEffToDt = (this.coinsList[i].btEffToDt == null) ? "" : new Date(this.coinsList[i].btEffToDt);
          if (action != 'save') {
            this.addItem_min();
          }
          (this.coinsuranceTermForm.get('items_coins') as UntypedFormArray)
            .at(i)
            .get('srnoId').setValue(this.coinsList[i].binderLobTermsPK.btSrNo, { emitEvent: true });
          this.coinsuranceTermForm.patchValue({
            items_coins: this.coinsList
          })
        }
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  // selectMaxDate_min(value, i) {
  //   if (_.size(this.coinsuranceTermForm.get("items_coins").value) > 1) {
  //     (this.coinsuranceTermForm.get("items_coins") as FormArray).at(i + 1).get("btEffFmDt").setValue(value);
  //   }
  // }
  save(action) {
    this.loaderService.isBusy = true;
    if (this.mgaCoinsuranceForm.valid) {
      let mgaCoinsuranceData = this.mgaCoinsuranceForm.getRawValue();
      if (mgaCoinsuranceData.bcSharePerc == 0) {
        this.toastService.warning("Shared Percentage should not be Zero")
        this.loaderService.isBusy = false;
      } else {
        if (this.existLeader != 1 && mgaCoinsuranceData.bcLeaderYn == true) {
          if (this.lobCoinsuranceList.length > 0 && mgaCoinsuranceData.bcLeaderYn == true) {
            // this.context.componentParent.selectedRowId = this.lobCoinsuranceList[0].binderCoinsPK.bcSrNo;
            // this.selectedRowData({ data: this.lobCoinsuranceList[0] });
            for (var i = 0; i < this.lobCoinsuranceList.length; i++) {
              //this.maxSharePerc = this.maxSharePerc + this.lobCoinsuranceList[i].bcSharePerc;
              if (this.lobCoinsuranceList[i].bcLeaderYn == '1') {
                this.loaderService.isBusy = false;
                this.toastService.warning('Leader Already Exist')
                return false;
                //this.isAvailLeader = true;
              }
            }
          }
        }
        if (action == 'save') {
          let obj = {
            binderCoinsPK: {
              bcAmendNo: this.amendNo,
              bcRefNo: this.refNo,
              bcSeqNo: this.seqNo,
              bcProdSrNo: this.lobSrNo
            },
            bcCrDt: new Date(),
            bcCrUid: this.userId,
            bcUpdDt: new Date(),
            bcUpdUid: this.userId,
            bcStatus: 'P',
            bcEffFmDt: new Date(this.passedData.biStartDt),
            bcEffToDt: new Date(this.passedData.biEndDt),
          };
          Object.assign(mgaCoinsuranceData, obj);
          mgaCoinsuranceData.bcLeaderYn = (mgaCoinsuranceData.bcLeaderYn === true) ? '1' : '0';
          mgaCoinsuranceData = MgaUtils.clean(mgaCoinsuranceData);
          this.isExceedAmount100 = this.calculateExceedLimit(action, mgaCoinsuranceData.bcSharePerc);
          if (this.isExceedAmount100 == false) {
            this.toastService.warning('Total coinsurance participant share percentage must be equal to 100%');
            this.loaderService.isBusy = false;
          } else {
            this.mgaService.saveCoinsurance(mgaCoinsuranceData).subscribe((resp) => {
              this.toastService.success('Successfully Saved');
              this.getAllLobCoinsuranceByRefId();
              this.showForm = false;
              this.AddFlag = true;
              this.loaderService.isBusy = false;
            }, error => {
              if (error instanceof HttpErrorResponse) {
                if (error.error instanceof ErrorEvent) {
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in upload!");
                } else {
                  switch (error.status) {
                    case 400:
                      this.loaderService.isBusy = false;
                      this.showErrorDialogBox(error.error.message);
                      this.decline();
                      break;
                    default:
                      this.loaderService.isBusy = false;
                      this.toastService.error("Error in upload!");
                      break;
                  }
                }
              } else {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              }
            })
          }
        } else {
          let obj = {
            binderCoinsPK: {
              bcAmendNo: this.amendNo,
              bcRefNo: this.refNo,
              bcSeqNo: this.seqNo,
              bcProdSrNo: this.lobSrNo,
              bcSrNo: this.bcSrNo
            },
            bcUpdDt: new Date(),
            bcUpdUid: this.userId,
            bcEffFmDt: new Date(this.passedData.biStartDt),
            bcEffToDt: new Date(this.passedData.biEndDt),
            bcStatus: 'P',
          };
          Object.assign(mgaCoinsuranceData, obj);
          mgaCoinsuranceData.bcLeaderYn = (mgaCoinsuranceData.bcLeaderYn === true) ? '1' : '0';
          mgaCoinsuranceData = MgaUtils.clean(mgaCoinsuranceData);
          this.isExceedAmount100 = this.calculateExceedLimit(action, mgaCoinsuranceData.bcSharePerc);
          if (this.isExceedAmount100 == false) {
            this.toastService.warning('Total coinsurance participant share percentage must be equal to 100%');
            this.loaderService.isBusy = false;
          } else {
            this.mgaService.updateCoinsurance(mgaCoinsuranceData, this.refNo, this.amendSrNo).subscribe((resp) => {
              this.toastService.success('Successfully Updated');
              this.getAllLobCoinsuranceByRefId();
              this.showForm = false;
              this.AddFlag = true;
              this.loaderService.isBusy = false;
            }, error => {
              if (error instanceof HttpErrorResponse) {
                if (error.error instanceof ErrorEvent) {
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in Updating!");
                } else {
                  switch (error.status) {
                    case 400:
                      this.loaderService.isBusy = false;
                      this.showErrorDialogBox(error.error.message);
                      this.decline();
                      break;
                    default:
                      this.loaderService.isBusy = false;
                      this.toastService.error("Error in Updating!");
                      break;
                  }
                }
              } else {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
              }
            })
          }
        }
      }

    } else {
      MgaUtils.validateAllFormFields(this.mgaCoinsuranceForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  openModal(content, val) {
    this.modalRef1 = this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalRef1.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.decline();
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    } else {
      this.gridOptions.api.exportDataAsExcel();
    }
  }
  calculateExceedLimit(action, bcSharePerc: any) {
    if (action == 'save') {
      let value = this.maxSharePerc + bcSharePerc;
      if (value >= 0 && value <= 100) {
        return true;
      } else {
        return false;
      }
    } else {
      let value = this.maxSharePerc - Number(this.selectedLob.bcSharePerc) + bcSharePerc;
      if (value >= 0 && value <= 100) {
        return true;
      } else {
        return false;
      }
    }

  }
  saveForm(item, action, formName) {
    this.loaderService.isBusy = true;
    if (formName == 'minComm') {
      if (this.items_coins.valid) {
        let termsMinComm = item.value;
        if (action == 'save') {
          let obj = {
            binderLobTermsPK: {
              btAmendNo: this.amendNo,
              btRefNo: this.refNo,
              btSeqNo: this.seqNo,
              btProdSrNo: this.lobSrNo
            },
            btCrDt: new Date(),
            btCrUid: this.userId,
            btUpdDt: new Date(),
            btUpdUid: this.userId,
            btStatus: 'P',
            btEffFmDt: moment(item.value.btEffFmDt, 'DD-MM-YYYY'),
            btEffToDt: moment(item.value.btEffToDt, 'DD-MM-YYYY'),
            btFlex01: "COTERMS",
            btCustCode: this.selectedLob.bcCustCode,
          };

          Object.assign(termsMinComm, obj);

          termsMinComm = MgaUtils.clean(termsMinComm);
          this.mgaService.saveCoinsuranceExpenses(termsMinComm).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Saved');
              // this.mgaService.sendMGAGridLoad('reload');
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: termsMinComm.binderLobTermsPK.btProdSrNo });
              this.getRules(this.selectedLob.bcCustCode, 'save');
              this.disableAddrow = false;
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    this.decline();
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          })
        } else {
          let termsMinComm = item.value;
          let obj = {
            binderLobTermsPK: {
              btAmendNo: this.amendNo,
              btRefNo: this.refNo,
              btSeqNo: this.seqNo,
              btProdSrNo: this.lobSrNo,
              btSrNo: termsMinComm.srnoId
            },
            btUpdDt: new Date(),
            btUpdUid: this.userId,
            btStatus: 'P',
            btEffFmDt: moment(item.value.btEffFmDt, 'DD-MM-YYYY'),
            btEffToDt: moment(item.value.btEffToDt, 'DD-MM-YYYY'),
            btFlex01: "COTERMS",
            btCustCode: this.selectedLob.bcCustCode,

          };
          Object.assign(termsMinComm, obj);

          termsMinComm = MgaUtils.clean(termsMinComm);
          this.mgaService.updateCoinsuranceExpenses(termsMinComm, this.refNo, this.amendSrNo).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Updated');
              // this.mgaService.sendMGAGridLoad('reload');
              this.mgaService.sendMGAGridLoad({ status: 'reload', srNo: termsMinComm.binderLobTermsPK.btProdSrNo });
              this.getRules(this.selectedLob.bcCustCode, 'save');
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in Updating!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            }
          })
        }
      } else {
        MgaUtils.validateAllFormFields(this.coinsuranceTermForm);
        this.toastService.warning('Enter mandatory fields');
        this.loaderService.isBusy = false;
      }
    }
  }
  openConfirmModal(template: TemplateRef<any>, srNo, index, formName) {
    this.formName = formName;
    this.deleteIndex = srNo;
    this.index = index;
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  dateValidators(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message = "Should be in Contract Period";
      const message1 = "Must be greater than Eff From Date";
      if (first.value && first.value < this.minDate || first.value > this.maxDate) {
        // if (first.value.toDateString() === this.minDate.toDateString()) {
        //   first.setErrors(null);
        // } else {
        first.setErrors({ dateValidator: message });
        return { dateValidator: true };
        // }
      }
      if (second.value && second.value < first.value) {
        second.setErrors({ dateValidator: message1 });
        return { dateValidator: true };
      } else {
        second.setErrors(null);
      }
    };
  }
  addItem_min(): void {
    this.items_coins = this.coinsuranceTermForm.get('items_coins') as UntypedFormArray;
    if (_.size(this.items_coins) > 0) {
      var size = _.size(this.items_coins) - 1;
      // let date = new Date(moment(this.items_coins.value[size].btEffToDt, 'DD-MM-YYYY').toDate());
      // date.setDate(date.getDate() + 1);
      this.items_coins.push(
        this.createItem()
      );
      setTimeout(() => {
        for (let i = 0; i < this.items_coins.value.length; i++) {
          if (this.items_coins.value[i].edited == false) {
            this.disableAddrow = true;
          } else {
            this.disableAddrow = false;
          }
        }
      }, 100);
    } else {
      this.items_coins.push(this.createItem(this.minDate, this.maxDate));
      setTimeout(() => {
        for (let i = 0; i < this.items_coins.value.length; i++) {
          if (this.items_coins.value[i].edited == false) {
            this.disableAddrow = true;
          } else {
            this.disableAddrow = false;
          }
        }
      }, 100);
    }
  }
  openDefaultTerm(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  decline(): void {
    this.modalRef.hide();
  }
  ConfirmDefault() {
    if (this.coinsuranceTermForm.value['items_coins'].length !== 0) {
      this.loaderService.isBusy = true;
      this.mgaService.defaultAllTermsButton(this.refNo, this.seqNo, this.amendNo, this.lobInfo.bpLobCode, this.lobSrNo, this.lobInfo.bpCompCode).subscribe(res => {
        this.toastService.success('updated successfully');
        this.loaderService.isBusy = false;
        this.modalRef.hide();
      })
    } else {
      this.toastService.warning('Add Data in Commission')
    }
  }

  confirm(srId, index, formName): void {
    this.loaderService.isBusy = true;
    if (srId == null && formName == 'minComm') {
      this.items_coins.removeAt(index);
      this.modalRef.hide();
      this.loaderService.isBusy = false;
      this.disableAddrow = false;
    } else {
      this.mgaService.deleteTerms(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, srId).subscribe(() => {
        this.toastService.success('Deleted Succcessfully.');
        this.loaderService.isBusy = false;
        if (formName == 'minComm') {
          this.items_coins.removeAt(index);
          this.disableAddrow = false;
        }
        this.modalRef.hide();
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
                element.click();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Deleting Data");
        }
      })
    }
  }
  enableSaveBtnInt(evnt) {
    if (evnt) {
      this.enableIntSave = true;
      if (this.coinsIntData.length > 0) {
        if (this.coinsIntData[0].btIcYn !== 'Y') {
          this.isAvailGroup.isIntAvail = true;
        } else {
          this.isAvailGroup.isIntAvail = false;
        }
      } else {
        this.isAvailGroup.isIntAvail = true;
      }
      this.mgaService.sendSavedCoinsData(this.isAvailGroup);
    } else {
      this.enableIntSave = false;
      this.isAvailGroup.isIntAvail = false;
      // this.introducerForm.reset();
      this.mgaService.sendSavedCoinsData(this.isAvailGroup);
      // this.clearValidators(this.introducerForm);
    }
  }
  enableSaveBtnSSC(evnt) {
    if (evnt) {
      this.enableSSCSave = true;
      if (this.coinsSSCData.length > 0) {
        if (this.coinsSSCData[0].btSscYn !== 'Y') {
          this.isAvailGroup.isSSCAvail = true;
        } else {
          this.isAvailGroup.isSSCAvail = false;
        }
      } else {
        this.isAvailGroup.isSSCAvail = true;
      }
      this.mgaService.sendSavedCoinsData(this.isAvailGroup);
    } else {
      this.enableSSCSave = false;
      this.isAvailGroup.isSSCAvail = false;
      // this.slidingScaleRateForm.reset();
      // this.SSCForm.reset();
      this.mgaService.sendSavedCoinsData(this.isAvailGroup);
      this.clearValidators(this.SSCForm);
    }
  }
  enableSaveBtnPC(evnt) {
    if (evnt) {
      this.enablePCSave = true;
      if (this.coinsPCData.length > 0) {
        if (this.coinsPCData[0].btPcYn !== 'Y') {
          this.isAvailGroup.isPCAvail = true;
        } else {
          this.isAvailGroup.isPCAvail = false;
        }
      } else {
        this.isAvailGroup.isPCAvail = true;
      }
      this.mgaService.sendSavedCoinsData(this.isAvailGroup);
    } else {
      this.enablePCSave = false;
      this.clearValidators(this.profitCommForm);
      this.profitCommForm.reset();
      this.isAvailGroup.isPCAvail = false;
      this.mgaService.sendSavedCoinsData(this.isAvailGroup);
    }
  }
  clearValidators(formGroup: UntypedFormGroup | UntypedFormArray) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsUntouched({ onlySelf: true });
        control.markAsPristine({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.clearValidators(control);
      }
    });
  }
  clearAndUpdate(formGroup: UntypedFormGroup | UntypedFormArray) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        if (control.value == null || control.value == undefined) {
          control.clearValidators();
          control.updateValueAndValidity();
        }
      }
    });
  }
  saveSlidingRateForm() {
    this.loaderService.isBusy = true;
    if (this.slidingScaleRateForm.valid) {
      let formData = this.slidingScaleRateForm.getRawValue();
      let obj = {
        binderLobTermsPK: {
          btAmendNo: this.amendNo,
          btRefNo: this.refNo,
          btSeqNo: this.seqNo,
          btProdSrNo: this.lobSrNo,
          btSrNo: (this.btSrNoSSC == undefined) ? 0 : this.btSrNoSSC
        },
        btCrDt: new Date(),
        btCrUid: this.userId,
        btUpdDt: new Date(),
        btUpdUid: this.userId,
        btStatus: 'P',
        btFlex01: "COTERMS",
        btSscYn: 'Y',
      };
      Object.assign(formData, obj);
      formData = MgaUtils.clean(formData);
      if (this.selectedLob && this.selectedLob.bcCustCode) {
        formData.btCustCode = this.selectedLob.bcCustCode;
        if (this.coinsSSCData.length > 0 && this.coinsSSCData[0].btSscYn === 'Y') {
          this.mgaService.saveTerms(formData).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Saved');
              this.getTermData(this.selectedLob.bcCustCode, 'SSC');
              this.mgaService.sendSavedCoinsData(this.isAvailGroup.isSSCAvail);
              this.isAvailGroup.isSSCAvail = false;
              this.getTermSSCgridData(this.selectedLob.bcCustCode);
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            this.loaderService.isBusy = false;
            this.toastService.error(error.error.message);
          })

        } else {
          this.loaderService.isBusy = false;
          this.toastService.warning("Before Apply Loss Ratio, Please Save Sliding Scale Commission");
        }
      } else {
        this.loaderService.isBusy = false;
        this.toastService.warning("Must have 1 Coinsurer.");
      }
    } else {
      MgaUtils.validateAllFormFields(this.slidingScaleRateForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }
  saveSSC() {
    this.loaderService.isBusy = true;
    if (this.SSCForm.valid) {
      let formData = this.SSCForm.getRawValue();
      let obj = {
        binderLobTermsPK: {
          btAmendNo: this.amendNo,
          btRefNo: this.refNo,
          btSeqNo: this.seqNo,
          btProdSrNo: this.lobSrNo,
          btSrNo: (this.btSrNoSSC == undefined) ? 0 : this.btSrNoSSC
        },
        btCrDt: new Date(),
        btCrUid: this.userId,
        btUpdDt: new Date(),
        btUpdUid: this.userId,
        btStatus: 'P',
        btFlex01: "COTERMS",
        btSscYn: 'Y',
      };
      Object.assign(formData, obj);
      formData.btSscFirstEvlDt = (typeof (formData.btSscFirstEvlDt) == 'string') ? moment(formData.btSscFirstEvlDt, 'DD/MM/YYYY') : moment(formData.btSscFirstEvlDt);
      formData.btSscLastEvlDt = (typeof (formData.btSscLastEvlDt) == 'string') ? moment(formData.btSscLastEvlDt, 'DD/MM/YYYY') : moment(formData.btSscLastEvlDt);
      formData = MgaUtils.clean(formData);
      if (this.selectedLob && this.selectedLob.bcCustCode) {
        formData.btCustCode = this.selectedLob.bcCustCode;
        this.mgaService.saveTerms(formData).subscribe((resp) => {
          if (resp.messageType == 'S') {
            this.toastService.success('Successfully Saved');
            this.getTermData(this.selectedLob.bcCustCode, 'SSC');
            this.loaderService.isBusy = false;
          } else if (resp.messageType == 'U') {
            this.loaderService.isBusy = false;
            this.toastService.success(resp.message);
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error(resp.message);
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        this.loaderService.isBusy = false;
        this.toastService.warning("Must have 1 Coinsurer.");
      }

    } else {
      MgaUtils.validateAllFormFields(this.SSCForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  savePC() {
    this.loaderService.isBusy = true;
    if (this.profitCommForm.valid) {
      let formData = this.profitCommForm.getRawValue();
      let obj = {
        binderLobTermsPK: {
          btAmendNo: this.amendNo,
          btRefNo: this.refNo,
          btSeqNo: this.seqNo,
          btProdSrNo: this.lobSrNo,
          btSrNo: (this.btSrNoPC == undefined) ? 0 : this.btSrNoPC
        },
        btCrDt: new Date(),
        btCrUid: this.userId,
        btUpdDt: new Date(),
        btUpdUid: this.userId,
        btStatus: 'P',
        btFlex01: "COTERMS",
        btPcYn: 'Y',
      };
      Object.assign(formData, obj);
      formData.btPcFirstEvlDt = (typeof (formData.btPcFirstEvlDt) == 'string') ? moment(formData.btPcFirstEvlDt, 'DD/MM/YYYY') : moment(formData.btPcFirstEvlDt)
      formData.btPcLastEvlDt = (typeof (formData.btPcLastEvlDt) == 'string') ? moment(formData.btPcLastEvlDt, 'DD/MM/YYYY') : moment(formData.btPcLastEvlDt)
      formData = MgaUtils.clean(formData);
      if (this.selectedLob && this.selectedLob.bcCustCode) {
        formData.btCustCode = this.selectedLob.bcCustCode;
        this.mgaService.saveTerms(formData).subscribe((resp) => {
          if (resp.messageType == 'S') {
            this.toastService.success('Successfully Saved');
            this.getTermData(this.selectedLob.bcCustCode, 'PC');
            this.mgaService.sendSavedCoinsData(this.isAvailGroup.isPCAvail);
            this.isAvailGroup.isPCAvail = false;
            this.loaderService.isBusy = false;
          } else if (resp.messageType == 'U') {
            this.loaderService.isBusy = false;
            this.toastService.success(resp.message);
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error(resp.message);
          }
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        this.loaderService.isBusy = false;
        this.toastService.error("Must have 1 Coinsurer.");
      }

    } else {
      MgaUtils.validateAllFormFields(this.profitCommForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  bottomDataDetails() {
    this.bottomData = [
      {
        binderCoinsPK: { bcProdSrNo: '' },
        bcLeaderYn: 'Total',
        bcSharePerc: this.maxSharePerc,
      }
    ];
    let obj = {
      bcSharePerc: this.maxSharePerc,
      availLeader: this.isAvailLeader,
      isCoins: this.passedData.biBusType
    }
    this.mgaService.sendCoinsSharePer(obj);
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
}
function actionCellRenderer(params) {
  let eGui = document.createElement("div");

  let editingCells = params.api.getEditingCells();
  let isCurrentRowEditing = editingCells.some((cell) => {
    return cell.rowIndex === params.node.rowIndex;
  });

  if (isCurrentRowEditing) {
    eGui.innerHTML = `
          <a>
            <i class="fa fa-refresh fa-icon"  data-action="update" title="Update" aria-hidden="true"></i>
          </a>&nbsp;&nbsp;
          <a>
            <i class="fa fa-close fa-icon fa-danger"  data-action="cancel" title="Cancel" aria-hidden="true"></i>
          </a>
        `;
  } else {
    eGui.innerHTML = `
          <a>
            <i class="fa fa-file-pen fa-icon"  data-action="edit" title="Edit" aria-hidden="true"></i>
          </a>&nbsp;&nbsp;
          <a>
            <i class="fa fa-trash fa-icon fa-danger"  data-action="delete" title="Delete" aria-hidden="true"></i>
          </a>
        `;
  }

  return eGui;
}