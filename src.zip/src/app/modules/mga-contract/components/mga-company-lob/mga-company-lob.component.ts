import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaWizardHelperService } from './../../services/mga-wizard.service';
import { MgaUtils } from './../mga-utils';

declare var $: any;
@Component({
  selector: 'mga-company-lob',
  templateUrl: './mga-company-lob.component.html',
  styleUrls: ['./mga-company-lob.component.scss']
})
export class MgaCompanyLobComponent implements OnInit {

  applicableProductForm: UntypedFormGroup;

  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() action: string;
  @Input() seqNo: number;
  @Input() amendSrNo: any;
  @Input() mgaYear: any;
  @Input() mgaCode: any;
  @Input() busType: any;
  @Output() retrieveSavedData = new EventEmitter();
  @Output() sendLOBDetail_Id = new EventEmitter();
  @Output() lobRowDetailEvent = new EventEmitter();
  flag = "A"
  contTypeVal: string = 'Applicable Company / LOB / Products';
  applicableProductList: any = [];
  showForm: boolean = false;
  AddFlag: boolean = true;
  divisionCode
  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;

  userId: any;
  selectedLob: any;
  lobSubProductList: any;
  lobProductList: any;
  lobCompanyList: any;

  closeResult: string;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  @ViewChild('errorModal') errorModal: ElementRef;
  @ViewChild('errorModalPopup') errorModalPopup: ElementRef;

  temp: any;
  editCompanyLOB: any;
  public termPerSaveEventsubscription: any = {};
  public getSharePercentage: any = {};
  loadLOBGrid: any;
  errorEvent: boolean = false;
  divisCode: any;
  maxShare: any;
  availLeader: boolean = false;
  isCoins: boolean = false;
  isAvailGroup: any = {
    isIntAvail: false,
    isSSCAvail: false,
    isPCAvail: false
  };
  isAvailForTerms: boolean = false;
  bottomData: any = [];
  public bottomColumns;
  bpSumEpiInGbp: any;
  bpMgaCommission: any;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private wizardHelperService: MgaWizardHelperService,
    private mgaService: MgaContractService,
    private modalService: BsModalService,

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true
    };

    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      if (params.node.data != null)
        var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };

    this.columnDefs = [
      {
        headerName: "Select",
        field: 'binderLobPK.bpProdSrNo',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        headerName: "S.No",
        field: 'binderLobPK.bpProdSrNo',
        filter: false,
        enableRowGroup: false,
      },
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "bpCompCodeDesc",
        sortable: true,
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.bpCompCode + ' - ' + params.data.bpCompCodeDesc;
          } else { return '' }
        },
      },
      {
        headerName: "LOB",
        headerTooltip: 'LOB',
        field: "bpLobCodeDesc",
        sortable: true,
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.bpLobCode + ' - ' + params.data.bpLobCodeDesc;
          } else { return '' }
        },
      },
      {
        headerName: "Product",
        headerTooltip: "Product",
        field: "bpProdCodeDesc",
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.bpProdCode + ' - ' + params.data.bpProdCodeDesc;
          } else { return '' }
        },
      },
      {
        headerName: "EPI in functional currency (GBP)",
        headerTooltip: "EPI in functional currency (GBP)",
        field: "bpSumEpiInGbp",
        enableRowGroup: true,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.bpSumEpiInGbp) {
            return Number(params.data.bpSumEpiInGbp).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else if (params && params.data && params.data.bpSumEpiInGbp == 0) {
            return Number(0).toFixed(2);
          } else {
            return;
          }
        },
      },
      {
        headerName: "MGA Commission",
        headerTooltip: "MGA Commission",
        field: "bpMgaCommission",
        enableRowGroup: true,
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.toFixedFun4,
      },
      {
        field: 'binderLobPK.bpProdSrNo',
        headerName: "Action",
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      }
    ];
    this.bottomColumns = [
      {
        headerName: "Select",
        field: 'binderLobPK.bpProdSrNo',
      },
      {
        headerName: "S.No",
        field: 'binderLobPK.bpProdSrNo',
      },
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "bpCompCodeDesc",
      },
      {
        headerName: "LOB",
        headerTooltip: 'LOB',
        field: "bpLobCodeDesc",
      },
      {
        headerName: "Product",
        headerTooltip: "Product",
        field: "bpProdCodeDesc",
      },
      {
        headerName: "EPI in functional currency (GBP)",
        headerTooltip: "EPI in functional currency (GBP)",
        field: "bpSumEpiInGbp",
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.toFixedFun,
      },
      {
        headerName: "MGA Commission",
        headerTooltip: "MGA Commission",
        field: "bpMgaCommission",
        cellStyle: { textAlign: 'right' },
        valueFormatter: MgaUtils.currencyFormatter,
      },
      {
        headerName: "Action",
      }
    ];
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    console.log(this.busType);

    this.agGridOptions();
    this.userId = this.session.get('userName');
    this.divisCode = this.session.get('divisionCode');
    this.createApplicableProductForm();
    this.termPerSaveEventsubscription = this.mgaService.getMGAGridLoad().subscribe((obj) => {
      this.loadLOBGrid = obj;
      if (this.loadLOBGrid.status === 'reload') {
        this.reloadLobGrid()
      }
    });
    this.getSharePercentage = this.mgaService.getCoinsSharePer().subscribe((obj) => {
      this.maxShare = obj.bcSharePerc;
      this.availLeader = obj.availLeader;
      this.isCoins = (obj.isCoins == '2') ? true : false;
    });
    this.mgaService.getSavedCoinsData().subscribe((obj) => {
      this.isAvailGroup = obj;
    });
    this.mgaService.getSavedTermsData().subscribe((obj) => {
      this.isAvailForTerms = obj;
    });
  }

  createApplicableProductForm() {
    this.applicableProductForm = this.fb.group({
      bpCompCode: ['', Validators.required],
      bpLobCode: ['', Validators.required],
      bpProdCode: ['', Validators.required],
      bpFnol: [''],
      bpLlNotifyDays: [''],
      bpMaxSi: [''],
      bpPlaLimit: [''],
      bpClaLimit: [''],
      bpStatus: [''],
      bpCrUid: [undefined],
      bpCrDt: [undefined],
      bpUpdDt: [undefined],
      bpUpdUid: [undefined],
    }, {
      validator: graterValidator("bpPlaLimit", "bpClaLimit")
    })
    this.getMasterData();
    this.getAllBinderLOBByRefId();
  }
  getMasterData() {
    this.getLOBCompanyAppCode();
    // this.getLOBProductAppCode();
  }

  getLOBCompanyAppCode() {
    this.mgaService.getLOBCompanyAppCode().subscribe((resp: any) => {
      this.lobCompanyList = resp.list;
    }, error => {
      this.toastService.error(error);
    });
  }
  getLOBProductAppCode(divCode) {
    this.mgaService.getLOBProductAppCode(divCode).subscribe((resp: any) => {
      this.lobProductList = resp.lobProdTypeList;
      this.lobProductList = (this.lobProductList as any).map(code => {
        code.displayText = code.key + ' - ' + code.value;
        return code;
      });
    }, error => {
      this.toastService.error(error);
    });
  }

  changeCompany(event) {
    this.divisionCode = event.value;
    this.applicableProductForm.get('bpLobCode').setValue(null);
    this.applicableProductForm.get('bpProdCode').setValue(null);
    this.getLOBProductAppCode(event.value);
    // this.applicableProductForm.reset({
    //   bpLobCode: [''],
    //   bpProdCode: [''],
    // })
  }
  getSubProduct(event) {
    this.loaderService.isBusy = true;
    this.applicableProductForm.get('bpProdCode').setValue(null);
    this.mgaService.getLOBSubProductAppCode(this.refNo, this.seqNo, this.amendNo, this.divisionCode, event.value).subscribe((resp: any) => {
      this.lobSubProductList = resp.lobSubProductList;
      this.lobSubProductList = (this.lobSubProductList as any).map(code => {
        code.displayText = code.key + ' - ' + code.value;
        return code;
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getAllBinderLOBByRefId() {
    this.loaderService.isBusy = true;
    this.bpSumEpiInGbp = this.bpMgaCommission = 0;
    this.mgaService.getAllBinderLOBByRefId(this.refNo, this.seqNo, this.amendNo).subscribe(resp => {
      this.applicableProductList = resp;
      if (this.applicableProductList.length > 0) {
        if (this.loadLOBGrid && this.loadLOBGrid.srNo) {
          this.context.componentParent.selectedRowId = this.loadLOBGrid.srNo;
          let array = this.applicableProductList.filter((value) => {
            return value.binderLobPK.bpProdSrNo == this.loadLOBGrid.srNo;
          })
          this.selectedRowData({ data: array[0] });
        } else {
          this.context.componentParent.selectedRowId = this.applicableProductList[0].binderLobPK.bpProdSrNo;
          this.selectedRowData({ data: this.applicableProductList[0] });
        }
        for (var i = 0; i < this.applicableProductList.length; i++) {
          this.bpSumEpiInGbp = this.bpSumEpiInGbp + this.applicableProductList[i].bpSumEpiInGbp;
          this.bpMgaCommission = this.bpMgaCommission + this.applicableProductList[i].bpMgaCommission;
        }
      } else {
        this.applicableProductList = [];
        this.sendLOBDetail_Id.emit("0");
        this.bpSumEpiInGbp = this.bpMgaCommission = 0;
      }
      this.bottomDataDetails();
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  reloadLobGrid() {
    this.getAllBinderLOBByRefId();
  }
  back() {
    this.showForm = false;
    this.AddFlag = true;
    this.errorEvent = false;
    this.applicableProductForm.reset();
  }
  saveForm() {
    this.loaderService.isBusy = true;
    if (this.applicableProductForm.valid) {
      let lobData = this.applicableProductForm.value;
      if ('edit' === this.action) {
        lobData.bpUpdDt = new Date();
        lobData.bpUpdUid = this.session.get('userId');
        let obj = {
          binderLobPK: this.editCompanyLOB,
        };
        Object.assign(lobData, obj);
        lobData = MgaUtils.clean(lobData);
        this.mgaService.updateBinderLOB(lobData, this.refNo, this.amendSrNo).subscribe(resp => {
          this.toastService.success('Successfully Updated');
          this.getAllBinderLOBByRefId();
          this.showForm = false;
          this.AddFlag = true;
          this.loaderService.isBusy = false;
          this.errorEvent = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        let obj = {
          binderLobPK: {
            bpAmendNo: this.amendNo,
            bpRefNo: this.refNo,
            bpSeqNo: this.seqNo
          },
          bpUpdDt: new Date(),
          bpUpdUid: this.session.get('userId'),
          bpStatus: 'P',
          bpCrDt: new Date(),
          bpCrUid: this.session.get('userId'),
        };
        Object.assign(lobData, obj);
        lobData = MgaUtils.clean(lobData);
        this.mgaService.saveBinderLOB(lobData).subscribe(resp => {
          this.toastService.success('Successfully Saved');
          this.getAllBinderLOBByRefId();
          this.showForm = false;
          this.AddFlag = true;
          this.loaderService.isBusy = false;
          this.errorEvent = false;
        }, error => {
          if (error instanceof HttpErrorResponse) {
            if (error.error instanceof ErrorEvent) {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            } else {
              switch (error.status) {
                case 400:
                  this.loaderService.isBusy = false;
                  this.showErrorDialogBox1(error.error.message);
                  break;
                default:
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in upload!");
                  break;
              }
            }
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in upload!");
          }
        })
      }
    } else {
      this.errorEvent = true;
      MgaUtils.validateAllFormFields(this.applicableProductForm);
      this.retrieveSavedData.emit('error2');
      this.loaderService.isBusy = false;
    }

  }
  closeModal() {
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.modalService.hide();
  }
  close() {
    this.modalService.hide();
  }
  showErrorDialogBox1(apprErrorMsg) {
    this.open(this.errorModalPopup, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails1").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  showErrorDialogBox(apprErrorMsg) {
    // this.open(this.errorModal, 'modal-md');
    setTimeout(() => {
      // apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(".");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  proceed() {
    this.mgaService.entryValidate(this.refNo, this.seqNo, this.amendNo, this.busType).subscribe((resp) => {
      this.getProceed();
    }, error => {
      this.loaderService.isBusy = false;
      if (error.error.text !== '') {
        this.showErrorDialogBox(error.error.text);
      } else {
        this.getProceed();
      }
    })


  }
  getProceed() {
    if (this.isAvailForTerms) {
      this.toastService.warning('Profit Share in Terms need to Save first');
    } else if (this.isAvailGroup.isIntAvail) {
      this.toastService.warning('Introducer Commision need to Save first');
    } else if (this.isAvailGroup.isSSCAvail) {
      this.toastService.warning('Sliding Scale Commision need to Save first');
    } else if (this.isAvailGroup.isPCAvail) {
      this.toastService.warning('Profit Commision need to Save first');
    } else {
      if (this.errorEvent) {
        this.toastService.warning('Enter mandatory fields');
      } else {
        if (this.isCoins) {
          if (this.availLeader == true) {
            if (this.maxShare === undefined) {
              this.wizardHelperService.goNext();
            } else {
              if (this.maxShare == 100) {
                this.wizardHelperService.goNext();
              } else {
                this.retrieveSavedData.emit('ermaxShareror');
                this.toastService.warning('Share Percentage must be equal to 100');
              }
            }
          } else {
            this.toastService.warning('Coinsurance must have 1 Leader');
          }
        } else {
          if (this.maxShare === undefined) {
            this.wizardHelperService.goNext();
          } else {
            if (this.maxShare == 100) {
              this.wizardHelperService.goNext();
            } else {
              this.retrieveSavedData.emit('ermaxShareror');
              this.toastService.warning('Share Percentage must be equal to 100');
            }
          }
        }
      }
    }
  }
  addApplicableProduct() {
    this.applicableProductForm.reset();
    this.showForm = true;
    this.flag = 'A';
    this.AddFlag = false;
    this.action = 'add';
    this.applicableProductForm.reset();
    this.applicableProductForm.get('bpCompCode').enable();
    this.applicableProductForm.get('bpLobCode').enable();
    this.applicableProductForm.get('bpProdCode').enable();
  }
  goPrevious() {
    if (this.errorEvent) {
      this.retrieveSavedData.emit('error2');
      this.toastService.warning('Enter mandatory fields');
    } else {
      this.wizardHelperService.goPrevious();
    }
  }
  onActionEditCompanyLOB(data) {
    this.loaderService.isBusy = true;
    // this.applicableProductForm.reset();
    console.log(data);
    this.action = 'edit';
    this.showForm = true;
    this.AddFlag = false;
    this.editCompanyLOB = data.binderLobPK;
    this.applicableProductForm.get('bpPlaLimit').setValue('');
    this.applicableProductForm.get('bpClaLimit').setValue('');
    this.applicableProductForm.patchValue(data);
    this.divisionCode = this.applicableProductForm.get('bpCompCode').value;
    let temp = data.bpProdCode + ' - ' + data.bpProdCodeDesc
    // this.getSubProduct({ key: this.applicableProductForm.get('bpLobCode').value });
    this.applicableProductForm.get('bpProdCode').setValue(temp);
    this.applicableProductForm.get('bpCompCode').disable();
    this.applicableProductForm.get('bpLobCode').disable();
    this.applicableProductForm.get('bpProdCode').disable();
    this.flag = this.applicableProductForm.get('bpLobCode').value
    this.loaderService.isBusy = false;
  }
  checkLimit(type) {
    let cla = this.applicableProductForm.get('bpClaLimit').value;
    let pla = this.applicableProductForm.get('bpPlaLimit').value;
    if (pla >= cla) {
      this.toastService.warning("CLA Limit must be greater than or equal to the PLA limit");
      this.applicableProductForm.get('bpClaLimit').setValue('0', { emitEvent: true });
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    } else {
      this.gridOptions.api.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("applicableProductContractTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case 'Edit':
          return this.onActionEditCompanyLOB(data);
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
  showDialogbox(data: any) {
    this.temp = data.binderLobPK;
    this.open(this.confirmModal, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  deleteRow() {
    if (this.temp && this.temp.bpRefNo && this.temp.bpProdSrNo) {
      this.loaderService.isBusy = true;
      this.mgaService.deleteBinderLOB(this.temp).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully.');
        this.loadLOBGrid = undefined;
        this.getAllBinderLOBByRefId();
        this.loaderService.isBusy = false;
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in delete!");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox1(error.error.message);
                this.modalService.hide();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in delete!");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in delete!");
        }
      })
    } else {
      this.toastService.error('Error in Deleting Data');
    }
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }

  selectedRowData(cell) {
    let SrNo = cell.data.binderLobPK.bpProdSrNo;
    this.selectedLob = cell.data;
    this.sendLOBDetail_Id.emit(SrNo);
    this.lobRowDetailEvent.emit(this.selectedLob);
  }

  bottomDataDetails() {
    this.bottomData = [
      {
        binderLobPK: { bpProdSrNo: '' },
        bpProdCodeDesc: 'Total',
        bpSumEpiInGbp: this.bpSumEpiInGbp,
      }
    ];
    // if (this.amendNo == '0') {
    //   this.bottomData[0].bpMgaCommission = this.bpMgaCommission;
    // }
    console.log(this.bottomData)
  }
}
function graterValidator(firstKey: string, secondKey: string): ValidatorFn {
  return (group: UntypedFormGroup): { [key: string]: any } => {
    const first = group['controls'][firstKey];
    const second = group['controls'][secondKey];
    const message =
      "CLA Limit must be equal to or greater than PLA limit";
    if (second.value > first.value) {
      // first.setErrors(null);
      // second.setErrors(null);
    } else if (second.value == first.value) {
      // second.setErrors(null);
      // first.setErrors(null);
    } else {
      second.setErrors({ equalValue: message });
      return { equalValue: true };
    }
  };
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
   </a>`;
  }
}