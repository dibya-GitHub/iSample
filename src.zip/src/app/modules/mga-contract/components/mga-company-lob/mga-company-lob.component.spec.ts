import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaCompanyLobComponent } from './mga-company-lob.component';

describe('MgaCompanyLobComponent', () => {
  let component: MgaCompanyLobComponent;
  let fixture: ComponentFixture<MgaCompanyLobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaCompanyLobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MgaCompanyLobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
