import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaWizardFlowComponent } from './mga-wizard-flow.component';

describe('MgaWizardFlowComponent', () => {
  let component: MgaWizardFlowComponent;
  let fixture: ComponentFixture<MgaWizardFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaWizardFlowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MgaWizardFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
