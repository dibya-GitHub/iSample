import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';

@Component({
  selector: 'mga-wizard-flow',
  templateUrl: './mga-wizard-flow.component.html',
  styleUrls: ['./mga-wizard-flow.component.scss']
})
export class MgaWizardFlowComponent implements OnInit {

  private _selectedItem: any;
  @Input()
  wizards: any[];
  isFromView: boolean;
  @Input()
  set selectedItem(value: any) {
    if (this._selectedItem !== value) {
      this._selectedItem = value;
      this.onSelectionChange();
    }
  }
  get selectedItem(): any {
    return this._selectedItem;
  }
  @Output()
  selectedItemChange = new EventEmitter<any>();
  myForm: UntypedFormGroup;
  onChanges: any;
  constructor() { }

  ngOnInit() {
    this.myForm = new UntypedFormGroup({
      radio: new UntypedFormControl()
    });
    this.onChanges = this.myForm.valueChanges.subscribe(val => {
      this.isFromView = true;
    });

  }
  updateForm() {
    if (this.myForm) {

      this.myForm.patchValue({
        radio: this._selectedItem
      }, { emitEvent: (this.isFromView) ? !this.isFromView : true });
      this.isFromView = false;
    }
  }
  onSelectionChange() {
    this.selectedItemChange.emit(this.selectedItem);
  }
  ngOnDestroy(): void {
    this.onChanges.unsubscribe();
  }
}
