import { DirtyCheckerService } from './../../../../../shared/services/dirty-checker.service';
import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { MgaDocumentsComponent } from 'src/shared/components/mga-documents/mga-documents.component';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaWizardHelperService } from './../../services/mga-wizard.service';
import { MgaUtils } from './../mga-utils';

@Component({
  selector: 'mga-contract-info',
  templateUrl: './mga-contract-info.component.html',
  styles: [
    `
      :host .tooltip-inner {
        background-color: var(--primary-color);
        color: #fff;
        max-width: 100%;
        text-align:left;
        padding:10px;
      }
      :host .tooltip {
        width: 100%;
      }
      :host .tooltip.top .tooltip-arrow:before,
      :host .tooltip.top .tooltip-arrow {
        border-top-color: var(--primary-color);
      }
      :host .tooltip-inner table {
        border-collapse: collapse;
        width: 100%;
      }

      :host .tooltip-inner table td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding-left: 5px;
      }
      .circle-info {
          position: relative;
          top: -25px;
          right: -9px;
          left: 5%;
          font-size: 15px;
          color: var(--primary-color);
          z-index: 1;
          cursor: pointer;
          float:right;
      }
      textarea {
          resize: auto;
      }

      .contactval {
          padding-top: 8px !important;
          padding-bottom: 8px !important;
      }
      .grey-background.px-5.padding-bottom10 {
        /* padding-top: 3.5em; */
      }
      .switch {
        position: relative;
        display: inline-block;
        width: 95px !important;
        height: 25px;
        padding: 0px;
        border-radius: 18px;
        cursor: pointer;
      }
      
      .switch-input {
        position: absolute;
        top: 0;
        left: 0;
        opacity: 0;
      }
      
      .switch-label {
        width: 75px;
        margin-top: 3px;
        position: relative;
        display: block;
        height: 22px;
        text-transform: uppercase;
        background: #F03A0F;
        border-radius: inherit;
        -moz-box-shadow:  #F03A0F 0 0 2px 1px inset;
        -webkit-box-shadow: #F03A0F 0 0 2px 1px inset;
        box-shadow: #F03A0F 0 0 2px 1px inset;
        -moz-transition: ease-out 0.15s;
        -o-transition: ease-out 0.15s;
        -webkit-transition: ease-out 0.15s;
        transition: ease-out 0.15s;
        -moz-transition-property: opacity, background;
        -o-transition-property: opacity, background;
        -webkit-transition-property: opacity, background;
        transition-property: opacity background;
      }
      
      .switch-label:before,
      .switch-label:after {
        position: absolute;
        top: 50%;
        margin-top: -0.44em;
        line-height: 1;
        -moz-transition: inherit;
        -o-transition: inherit;
        -webkit-transition: inherit;
        transition: inherit;
      }
      
      .switch-label:before {
        content: attr(data-off);
        right: 10px;
        color: white;// #6d6d6d;
        text-shadow: 0 1px rgba(0, 0, 0, 0.2);//0 1px rgba(255, 255, 255, 0.5);
      }
      
      .switch-label:after {
        content: attr(data-on);
        left: 12px;
        color: white;
        text-shadow: 0 1px rgba(0, 0, 0, 0.2);
        opacity: 0;
      }
      
      .switch-input:checked ~ .switch-label {
        background: #22BF4F;
        -moz-box-shadow: #22BF4F 0 0 2px 1px inset;
        -webkit-box-shadow: #22BF4F 0 0 2px 1px inset;
        box-shadow: #22BF4F 0 0 2px 1px inset;
      }
      
      .switch-input:checked ~ .switch-label:before {
        opacity: 0;
      }
      
      .switch-input:checked ~ .switch-label:after {
        opacity: 1;
      }
      
      .switch-handle {
        position: absolute;
        top: 5px;
        left: 4px;
        width: 18px;
        height: 18px;
        background: white;
        border-radius: 10px;
        background: url("data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4gPHN2ZyB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJncmFkIiBncmFkaWVudFVuaXRzPSJvYmplY3RCb3VuZGluZ0JveCIgeDE9IjAuNSIgeTE9IjAuMCIgeDI9IjAuNSIgeTI9IjEuMCI+PHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2Y3ZjdmNyIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iI2ZmZmZmZiIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHg9IjAiIHk9IjAiIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JhZCkiIC8+PC9zdmc+IA==");
        background: -webkit-gradient(linear, 50% 0%, 50% 100%, color-stop(0%, #f7f7f7), color-stop(100%, #ffffff));
        background: -moz-linear-gradient(top, #f7f7f7, #ffffff);
        background: -webkit-linear-gradient(top, #f7f7f7, #ffffff);
        background: linear-gradient(to bottom, #f7f7f7, #ffffff);
        -moz-transition: left 0.15s ease-out;
        -o-transition: left 0.15s ease-out;
        -webkit-transition: left 0.15s ease-out;
        transition: left 0.15s ease-out;
      }
      
      .switch-input:checked ~ .switch-handle {
        left: 55px;
      }
    `
  ],
  providers: [DatePipe]

})
export class MgaContractInfoComponent implements OnInit {
  contractInfoForm: UntypedFormGroup;

  @Input() refNo: string;
  @Input() amendNo: any;
  @Input() action: string;
  @Input() seqNo: number;
  @Input() contractType: string;
  @Input() status: string;
  @Input() amendSrNo: any;
  @Input() passedData: any;
  @Output() retrieveSavedData = new EventEmitter();

  contTypeVal: string = 'Contract Info';
  mgaList: any = [];
  contractInfo: any;
  userId: any;
  createdDate: any;
  brokers: any;
  disable: boolean = false;
  bordereauxFreq: any[];
  bussinessType: any[];
  currencyList: any;
  modalRef: BsModalRef;
  @ViewChild('errorModal') errorModal: ElementRef;
  documents: any;
  isDocumentNeedsToBeUpdated: any;
  documentRefId: string;
  minDate: any;
  maxDate: any;
  userName: any;
  loginCurr: any;
  documentTypes: any[];
  isAmendGraterThanZero: boolean = false;
  @ViewChild(MgaDocumentsComponent) uploadDoc: MgaDocumentsComponent;
  passedRefNo: any;
  tooltipText: any = `<span><b>Contract ID should be created in the following format:</b></span><br/>
  <span>Year of Account – Company – Line of Business – Sequence Number</span><br/>
  <span>For example:</span><br/>
  <span>2020-ZIP-MTR-002 , 2016-MICL-LIA-001</span><br/>
  <table class="tableHTML">
  <tr>
    <th>Data item</th>
    <th>Valid Values</th>
    <th>Description</th>
  </tr>
  <tr>
    <td>Year of Account</td>
    <td>2016, 2017, 2018, etc</td>
    <td>Four-digit number</td>
  </tr>
  <tr>
    <td>Company</td>
    <td>ZIP, MICL, STJ, NOV, NEW</td>
    <td>Three or four-letter abbreviation of Lead Company</td>
  </tr>
  <tr>
    <td>Line of Business</td>
    <td>MTR, LIA, PRP, MFL, PET, OFS</td>
    <td>Three letter abbreviation of the Line of Business</td>
  </tr>
  <tr>
    <td>Sequence</td>
    <td>001, 002, 003, etc</td>
    <td>Three-digit sequence number increasing incrementally</td>
  </tr>
</table>`;
  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private wizardHelperService: MgaWizardHelperService,
    private datePipe: DatePipe,
    private mgaService: MgaContractService,
    private treatyService: TreatyService,
    private modalService: BsModalService,
    private dirtyChecker: DirtyCheckerService

  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.createdDate = this.datePipe.transform(new Date(), ApiUrls.Contract_Form_Date);
    this.userName = this.session.get('userName');
    this.userId = this.session.get('userId');
    this.loginCurr = this.session.get('baseCurrency');

    this.createContractInfoForm();
    if ('edit' === this.action) {
      this.disable = true;
    }
    this.amendNo = Number(this.amendNo);
    this.isAmendGraterThanZero = (this.amendNo == 0) ? true : false;
    this.getDocumentTypes();
    this.passedRefNo = (this.passedData == undefined) ? undefined : this.passedData.biRefNo;
    if (this.refNo == undefined) {
      this.documentRefId = MgaUtils.makeRandomWord('CONT-', 32);
    }
  }
  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res;
      }, err => {
      });
  }

  getMasterData() {
    this.getMGAlist();
    this.getPlacingBrokerAppCode();
    this.getBussinessTypeAppCode();
    this.getCurrencyAppCode();
    this.getBordereauxFrequency();
    this.getContractInfo(this.refNo, this.seqNo, this.amendNo);
  }
  getMGAlist() {
    this.mgaService.getMGAlist().subscribe(mgalist => {
      this.mgaList = (mgalist as any).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });

    }, err => {
    });
  }
  getPlacingBrokerAppCode() {
    this.mgaService.getPlacingBrokerAppCode().subscribe(broker => {
      this.brokers = (broker as any[]).map(brok => {
        brok.displayText = brok.customerCode + ' - ' + brok.customerName;
        return brok;
      });
    }, err => {
    });
  }
  getBussinessTypeAppCode() {
    this.mgaService.getBussinessTypeAppCode().subscribe(bussinessType => {
      this.bussinessType = bussinessType;
    }, err => {
    });
  }
  getCurrencyAppCode() {
    this.mgaService.getCurrencyAppCode().subscribe(currencies => {
      this.currencyList = (currencies as any[]).map(currency => {
        currency.displayText = currency.currCode + ' - ' + currency.currName;
        return currency;
      });
    }, err => {
    });
  }
  getBordereauxFrequency() {
    this.mgaService.getBordereauxFrequency().subscribe(bordereauxFreq => {
      this.bordereauxFreq = bordereauxFreq;
    }, err => {
    });
  }
  createContractInfoForm() {
    this.contractInfoForm = this.fb.group({
      biRefNo: ['', Validators.required],
      biAmendNo: 0,
      biSeqNo: this.seqNo,
      biContractPeriod: [''],

      biAmendEndDt: [''],
      biAmendStartDt: [''],
      biAmendType: [''],
      biApprDt: [''],
      biApprSts: [''],
      biApprUid: [''],
      biCanDt: [''],
      biCanNotifyDays: ['', Validators.required],
      biContractType: [''],
      biCrDt: new Date(),
      biCrUid: this.userId,
      biDesc: ['', Validators.required],
      biStartDt: [undefined, Validators.required],
      biEndDt: [undefined, Validators.required],
      biFixedRate: [''],

      biMga: [undefined, Validators.required],
      biBroker: [undefined],
      biCurr: [this.loginCurr, Validators.required],
      biBusType: [undefined, Validators.required],
      biAcStmtFreq: [undefined, Validators.required],

      biUmrNo: [''],
      biAgreementNo: [''],
      biCreditDays: ['', Validators.required],
      biSetlDays: ['', Validators.required],

      biProgCode: [''],
      biPrvAmendNo: [''],
      biPrvRefNo: [''],
      biPrvSeqNo: [''],
      biRemarks: [''],
      biStatus: [''],
      biUpdDt: new Date(),
      biUpdUid: this.userId,
      biUwYear: [''],
      biFlex06: [undefined],
      binderContractPK: {
        biAmendNo: this.amendNo,
        biRefNo: this.refNo,
        biSeqNo: this.seqNo
      }
    })
    this.getMasterData();

  }
  getContractInfo(refNo, seqNo, amendNo) {
    if (refNo != undefined) {
      this.mgaService.getContractInfo(refNo, seqNo, amendNo).subscribe((result: any) => {
        this.contractInfo = result;
        if (this.contractInfo && this.contractInfo.binderContractPK) {
          this.contractInfoForm.patchValue({
            biAmendNo: this.contractInfo.binderContractPK.biAmendNo,
            biSeqNo: this.contractInfo.binderContractPK.biSeqNo,
            biRefNo: this.contractInfo.binderContractPK.biRefNo,
          })
        }
        if (this.contractInfo && this.contractInfo.biStartDt) {
          this.contractInfo.biStartDt = moment(this.contractInfo.biStartDt).format('DD-MM-YYYY HH:mm');
        } else if (this.contractInfo) {
          this.contractInfo.biStartDt = undefined;
        }
        if (this.contractInfo && this.contractInfo.biEndDt) {
          this.contractInfo.biEndDt = moment(this.contractInfo.biEndDt).format('DD-MM-YYYY HH:mm');
        } else if (this.contractInfo) {
          this.contractInfo.biEndDt = undefined;
        }
        if (this.contractInfo && this.contractInfo.biCanDt) {
          this.contractInfo.biCanDt = moment(this.contractInfo.biCanDt).format('DD-MM-YYYY HH:mm');
        } else if (this.contractInfo) {
          this.contractInfo.biCanDt = undefined;
        }
        if (this.contractInfo && this.contractInfo.biCrDt) {
          this.createdDate = this.datePipe.transform(this.contractInfo.biCrDt, ApiUrls.DATE_FORMAT);
        }
        if (this.contractInfo && this.contractInfo.biFlex05) {
          this.documentRefId = this.contractInfo.biFlex05;
        }
        if (this.contractInfo && this.contractInfo.biFlex06) {
          this.contractInfo.biFlex06 = (this.contractInfo.biFlex06 == 'Y');
        }
        this.minDate = new Date(moment(this.contractInfo.biStartDt, 'DD-MM-YYYY').toDate());
        this.maxDate = new Date(moment(this.contractInfo.biEndDt, 'DD-MM-YYYY').toDate());
        this.contractInfoForm.patchValue(this.contractInfo);
        setTimeout(() => {
          this.loaderService.isBusy = false;
        }, 1000);
      })
    } else {
      this.loaderService.isBusy = false;
      this.contractInfoForm.get('biFlex06').setValue(false);
    }
  }
  back() {
    this.route.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'Home' } });
  }
  missingDocType: boolean = false
  checkDocType() {
    let docType = this.uploadDoc.unsavedFiles
    for (var i = 0; i < docType.length; i++) {
      if (docType[i].entityRefType == undefined) {
        return this.missingDocType = true;

      }
    }
  }

  saveForm() {
    this.loaderService.isBusy = true;
    if (this.contractInfoForm.valid) {
      var dirty = this.dirtyChecker.validateDirtyCheck(this.contractInfoForm);
      this.missingDocType = false;
      this.checkDocType();
      if (this.uploadDoc.unsavedFiles.length >= 0 && this.missingDocType == false) {
        if (this.uploadDoc.fileList.length !== 0) {
          this.uploadDoc.saveAllDocument();
        }
        let contractData = this.contractInfoForm.value;
        contractData.biStartDt = moment(this.contractInfoForm.get('biStartDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
        contractData.biEndDt = moment(this.contractInfoForm.get('biEndDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
        if (this.contractInfoForm.get('biCanDt').value == '' || this.contractInfoForm.get('biCanDt').value == null) {
          contractData.biCanDt = null;
        } else {
          contractData.biCanDt = moment(this.contractInfoForm.get('biCanDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
        }
        contractData.biFlex10 = contractData.biContractPeriod;
        contractData.biFlex06 = (contractData.biFlex06) ? 'Y' : 'N';
        contractData.biFlex05 = this.documentRefId;
        // contractData = MgaUtils.clean(contractData);
        if ('edit' === this.action) {
          this.mgaService.updateContractInfoData(contractData, this.refNo, this.amendSrNo).subscribe(resp => {
            if (dirty) {
              this.toastService.success('Successfully Saved');
            }
            this.retrieveSavedData.emit(contractData);
            this.wizardHelperService.goNext();
            this.loaderService.isBusy = false;
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    this.modalRef.hide();
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          })
        } else {
          contractData.binderContractPK = {
            biRefNo: this.contractInfoForm.get('biRefNo').value,
            biAmendNo: '0',
            biSeqNo: this.contractInfoForm.get('biSeqNo').value,
          };
          contractData.biContractType = this.contractType;
          contractData.biFlex10 = contractData.biContractPeriod;
          contractData.biStatus = 'P';
          // contractData = MgaUtils.clean(contractData);

          if (contractData.binderContractPK.biRefNo == this.passedRefNo) {
            if (this.passedRefNo == undefined) {
              this.mgaService.saveContractInfoData(contractData).subscribe(resp => {
                this.toastService.success('Successfully Saved');
                this.retrieveSavedData.emit(this.contractInfoForm.value);
                this.wizardHelperService.goNext();
                this.loaderService.isBusy = false;
              }, error => {
                this.loaderService.isBusy = false;
                this.toastService.error(error.error.message);
              })
            } else {
              this.mgaService.updateContractInfoData(contractData, contractData.binderContractPK.biRefNo, this.amendSrNo).subscribe(resp => {
                if (dirty) {
                  this.toastService.success('Successfully Saved');
                }
                this.retrieveSavedData.emit(contractData);
                this.wizardHelperService.goNext();
                this.loaderService.isBusy = false;
              }, error => {
                this.loaderService.isBusy = false;
                this.toastService.error(error.error.message);
              })
            }

          } else {
            this.mgaService.validateRefNo(contractData.binderContractPK.biRefNo).subscribe((resp: any) => {
              if (resp.messageType == 'S') {
                if (this.passedRefNo == undefined) {
                  this.mgaService.saveContractInfoData(contractData).subscribe(resp => {
                    this.toastService.success('Successfully Saved');
                    this.retrieveSavedData.emit(this.contractInfoForm.value);
                    this.wizardHelperService.goNext();
                    this.loaderService.isBusy = false;
                  }, error => {
                    this.loaderService.isBusy = false;
                    this.toastService.error(error.error.message);
                  })
                } else {
                  this.mgaService.updateContractInfoData(contractData, contractData.binderContractPK.biRefNo, this.amendSrNo).subscribe(resp => {
                    if (dirty) {
                      this.toastService.success('Successfully Saved');
                    }
                    this.retrieveSavedData.emit(contractData);
                    this.wizardHelperService.goNext();
                    this.loaderService.isBusy = false;
                  }, error => {
                    this.loaderService.isBusy = false;
                    this.toastService.error(error.error.message);
                  })
                }
              } else {
                this.loaderService.isBusy = false;
                this.toastService.error(resp.message);
              }
            }, error => {
              this.loaderService.isBusy = false;
              this.toastService.error(error.message);
            });
          }
          this.loaderService.isBusy = false;
        }
      } else {
        this.loaderService.isBusy = false;
        this.toastService.warning('Save All Uploaded Documents');
      }

    } else {
      MgaUtils.validateAllFormFields(this.contractInfoForm);
      this.retrieveSavedData.emit('error');
      this.loaderService.isBusy = false;
      this.toastService.warning('Enter mandatory fields');
    }
  }
  openModal(content, val) {
    this.modalRef = this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalRef.hide();
    this.route.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  validateRefNo(evnt) {
    var refNo = evnt.target.value;
    if (refNo != "" && this.passedRefNo == undefined) {
      this.mgaService.validateRefNo(refNo).subscribe((resp: any) => {
        if (resp.messageType == 'S') {
        } else {
          this.toastService.error(resp.message);
        }
      }, error => {
        this.toastService.error(error.message);
      });
    }
  }
  setUwYear(value) {
    if (value) {
      this.minDate = new Date(moment(value, 'DD-MM-YYYY').toDate());
      const startDate = moment(value.getDate() + '/' + (value.getMonth() + 1) + '/' + value.getFullYear(), 'DD/MM/YYYY');
      const endDate = moment(startDate).add(1, 'year').add(-1, 'days');
      this.maxDate = new Date(moment(endDate, 'DD-MM-YYYY').toDate());
      const data = {
        biEndDt: endDate.format('DD/MM/YYYY'),
        biUwYear: startDate.format('YYYY'),
        biContractPeriod: endDate.diff(startDate, 'days') + 1,
      };
      this.contractInfoForm.patchValue(data);
    }
  }
  setContractPeriod(value) {
    if (value) {
      let startDate = this.contractInfoForm.get('biStartDt').value;
      let sdate = moment(startDate, 'DD-MM-YYYY');
      let edate = moment(value);
      let data = {
        biContractPeriod: edate.diff(sdate, 'days') + 1,
      };
      this.contractInfoForm.patchValue(data);
    }
  }
  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }
}
