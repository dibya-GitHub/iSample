import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-contract-info/mga-contract-info.component.spec.ts
import { MgaContractInfoComponent } from './mga-contract-info.component';

describe('MgaContractInfoComponent', () => {
  let component: MgaContractInfoComponent;
  let fixture: ComponentFixture<MgaContractInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaContractInfoComponent ]
=======
import { TreatyReinsurerComponent } from './treaty-reinsurer.component';

describe('TreatyReinsurerComponent', () => {
  let component: TreatyReinsurerComponent;
  let fixture: ComponentFixture<TreatyReinsurerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyReinsurerComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/treaty-reinsurer/treaty-reinsurer.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-contract-info/mga-contract-info.component.spec.ts
    fixture = TestBed.createComponent(MgaContractInfoComponent);
=======
    fixture = TestBed.createComponent(TreatyReinsurerComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/treaty-reinsurer/treaty-reinsurer.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
