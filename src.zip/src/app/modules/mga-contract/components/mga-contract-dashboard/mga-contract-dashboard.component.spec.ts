import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaContractDashboardComponent } from './mga-contract-dashboard.component';

describe('MgaContractDashboardComponent', () => {
  let component: MgaContractDashboardComponent;
  let fixture: ComponentFixture<MgaContractDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaContractDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MgaContractDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
