import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';

@Component({
  selector: 'mga-contract-dashboard',
  templateUrl: './mga-contract-dashboard.component.html',
  styleUrls: ['./mga-contract-dashboard.component.scss']
})
export class MgaContractDashboardComponent {
  mgaSrchFrm: UntypedFormGroup;
  mgaAmendmentForm: UntypedFormGroup;
  mgaRenewForm: UntypedFormGroup;
  baseCurrencyCode

  contractTypeList: any[];
  yearList: any;
  mgaList: any;
  userList: any;
  statusList: any;
  totalCount: number;
  pendingCount: number;
  approvedCount: number;

  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  rowData: any;
  public components;
  public context;
  public frameworkComponents;
  paginationPageSize: number;
  rowGroupPanelShow: string;
  isRadioActive: boolean = false;
  refNo: any;
  amndNo: any;
  seqNo: any;
  contType: any;
  status: any;
  contractDesc: any;
  currentContract: any;
  EditBtnFlag: boolean = false;
  viewBtnFlag: boolean = false;
  amendBtnFlag: boolean = false;
  renewBtnFlag: boolean = false;
  amendHistoryBtnFlag: boolean = false;
  contractData: any;
  minDate: Date;
  startDate: any;
  endDate: any
  renewalDate: any;
  divisionCode: any;
  enableBottomDiv: boolean = false;
  lobCompanyList: any;
  lobProductList: any;
  lobSubProductList: any;
  compCode: any;
  userId: string;
  modalRef: BsModalRef;
  @ViewChild('contTypeModal') contcTypeModal: ElementRef;
  @ViewChild('amendmentContent') amendmentContent: ElementRef;
  @ViewChild('renewContent') renewContent: ElementRef;
  @ViewChild('errorModal') errorModal: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
    private mgaService: MgaContractService,
    private treatyService: TreatyService,
    private commonService: CommonService,
    private modalService1: BsModalService,
  ) {
    this.userId = this.session.get('userName');
    this.compCode = this.session.get('companyCode');
    this.divisionCode = this.session.get('divisionCode');
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.components = {
      strtDateCellRenderer: strtDateCellRenderer,
      endDateCellRenderer: endDateCellRenderer,
      statusCellRenderer: statusCellRenderer,
      periodCellRenderer: periodCellRenderer,
    };
    this.columnDefs = [
      {
        field: 'binderContractPK.biRefNo',
        headerName: 'Select',
        sortable: false,
        checkboxSelection: false,
        cellRenderer: 'radioButtonRenderer',
        cellStyle: { textAlign: 'center' },
        headerTooltip: 'Select',
        enableRowGroup: false,

      },
      {
        field: 'biUwYear',
        headerName: 'Year',
        headerTooltip: 'Protection Year',
        cellStyle: { textAlign: 'left' },
      },
      {
        field: 'binderContract',
        headerName: 'Contract ID',
        headerTooltip: 'Contract ID',
        resizable: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.binderContractPK) {
            return params.data.binderContractPK.biRefNo + ' / ' + params.data.binderContractPK.biSeqNo + ' / ' + params.data.biDesc;
          } else {
            return '';
          }
        },
        cellRenderer: MgaUtils.tooltipRenderer
      },
      {
        field: 'biPeriod',
        headerName: 'Period',
        valueGetter: function (params) {
          if (params && params.data && params.data.biStartDt && params.data.biEndDt) {
            let startDate = moment(params.data.biStartDt).format('DD/MM/YYYY');
            let endDate = moment(params.data.biEndDt).format('DD/MM/YYYY');
            return startDate + ' - ' + endDate;
          } else {
            return '';
          }
        },
        filterParams: filterParams,
        cellStyle: { textAlign: 'left' },
        headerTooltip: 'Contract Start Date',
      },
      {
        field: 'biBusTypeDesc',
        headerName: 'Business Type',
        headerTooltip: 'Business Type',
        tooltipField: 'biBusTypeDesc',
      },
      {
        field: 'biMgaDesc',
        headerName: 'MGA',
        headerTooltip: 'MGA',
        cellStyle: { textAlign: 'left' },
        tooltipField: 'biMgaDesc',
      },
      {
        field: 'biApprUid',
        headerName: 'Approved By',
        headerTooltip: 'Approved By',
        cellStyle: {
          height: '31px',
          textAlign: 'left'
        },
      },
      {
        field: 'biUpdDt',
        headerName: 'Last Updated On',
        cellStyle: { textAlign: 'left' },
        headerTooltip: 'Last Updated On',
        valueGetter: function (params) {
          if (params && params.data && params.data.biUpdDt) {
            return moment(params.data.biUpdDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams1,
      },
      {
        field: 'biStatus',
        headerName: 'Status',
        headerTooltip: 'Status',
        cellStyle: { textAlign: 'center' },
        valueGetter: function (params) {
          if (params && params.data && params.data.biStatus) {
            if (params.data.biStatus === 'A') {
              return 'Approved';
            } else {
              return 'Pending';
            }
          } else {
            return '';
          }
        },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.value) {
              return params.value == 'Pending';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else {
            return '<span class="ag-element">' + params.value + '</span>';
          }
        },

      },
    ];
    this.createForm();
    this.createAmendmentForm();
    this.createRenewForm();
    this.retrieveContractYear();
    this.retrieveMGAList();
    this.reterieveUWriterList();
    this.context = { componentParent: this };
    this.statusList = [
      {
        key: '',
        value: 'All'
      },
      {
        key: 'A',
        value: 'Approved'
      },
      {
        key: 'P',
        value: 'Pending'
      },
    ];
    this.agGridOptions();
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
    this.getBaseCurrencyCode();
    this.getBusinessType();
    this.getLOBCompanyAppCode();
    this.getLOBProductAppCode();
    this.getSubProduct();
    this.mgaService.getMGAGridLoad().subscribe((obj) => {
      if (obj === 'reload') {
        this.searchContract();
      }
    });
  }
  getLOBCompanyAppCode() {
    this.mgaService.getLOBCompanyAppCode().subscribe((resp: any) => {
      this.lobCompanyList = resp.list;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error);
    });
  }
  getLOBProductAppCode() {
    this.mgaService.getCompanyLOBDropdown(this.compCode).subscribe((resp: any) => {
      this.lobProductList = resp.lobProdTypeList;
      this.lobProductList = (this.lobProductList as any).map(code => {
        code.displayText = code.key + ' - ' + code.value;
        return code;
      });
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error);
    });
  }
  getSubProduct() {

    this.mgaService.getAllSubProduct().subscribe((resp: any) => {
      this.lobSubProductList = resp.lobSubProductList;
      this.lobSubProductList = (this.lobSubProductList as any).map(code => {
        code.displayText = code.key + ' - ' + code.value;
        return code;
      });

    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getBaseCurrencyCode() {
    this.mgaService.getBaseCurrencyDivision(this.divisionCode).subscribe(res => {
      this.baseCurrencyCode = res;
      sessionStorage.setItem('baseCurrencyCode', JSON.stringify(this.baseCurrencyCode));
    })
  }
  getBusinessType() {
    this.mgaService.getBussinessTypeAppCode().subscribe(res => {
      this.contractTypeList = res;
      this.contractTypeList.unshift({ code: '', description: 'All' });
    })
  }
  createForm() {
    this.mgaSrchFrm = this.fb.group({
      biBusType: [''],
      biUwYear: [''],
      biMga: [''],
      biApprUid: [''],
      biStatus: [''],
      bpCompCode: [undefined],
      bpLobCode: [undefined],
      bpProdCode: [undefined],
    });
  }
  createAmendmentForm() {
    this.mgaAmendmentForm = this.fb.group({
      baAmendNo: [undefined],
      baAmendSrNo: [undefined, Validators.required],
      baAmendStartDt: [undefined, Validators.required],
      baAmendEndDt: [undefined, Validators.required],
      baRemarks: [undefined, Validators.required],
      baCrDt: new Date(),
      baCrUid: this.userId,
      baUpDt: new Date(),
      baUpUid: this.userId,
    });
  }
  createRenewForm() {
    this.mgaRenewForm = this.fb.group({
      refNo: this.refNo,
      bcrSeqNo: this.seqNo,
      bcrAmendNo: this.amndNo,

      bcrRefNo: [undefined, Validators.required],
      bcrStartDt: [undefined, Validators.required],
      bcrEndDt: [undefined, Validators.required],
      bcrDesc: [undefined, Validators.required],
      bcrRemarks: [undefined, Validators.required],

      bcrCrUid: this.session.get('userId'),
      bcrCrDt: new Date(),
      bcrUpUid: this.session.get('userId'),
      bcrUpDt: new Date()
    });
  }
  retrieveContractYear() {
    this.treatyService.retrieveContractYear('bc-master').subscribe(resp => {
      this.yearList = resp;
      this.yearList.unshift({ key: '', value: 'All' });
    })
  }
  retrieveMGAList() {
    this.mgaService.getMGAlist().subscribe(resp => {
      this.mgaList = resp;
      this.mgaList = (this.mgaList as any[]).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });
      this.mgaList.unshift({ code: '', displayText: 'All' });
    })
  }
  reterieveUWriterList() {
    // let roleId = this.session.get('roleId');
    this.commonService.getUserList('mga-contract').subscribe((users: any) => {
      this.userList = users;
      this.userList.unshift({ key: '', value: 'All' });
    })
  }

  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  close() {
    this.modalService.hide();
  }
  newContract(mode) {
    if ('add' == mode) {
      this.open(this.contcTypeModal, 'modal-dialog-centered modal-md');
    }
  }

  newContType(mode, type) {
    var obj = {
      'action': mode,
      'amendNo': 0,
      'seqNo': 1,
      'type': type,
    }
    this.router.navigate(['/mga-contract/mga-wizard'], { queryParams: obj, skipLocationChange: true });
    this.modalService.hide();
  }
  onStatusChange(status) {
    this.loaderService.isBusy = true;
    if (status) {
      this.rowData = this.contractData.filter(datum => datum.biStatus === status);
      this.loaderService.isBusy = false;
    } else {
      this.rowData = this.contractData;
      this.loaderService.isBusy = false;
    }
  }
  View(mode) {
    if (this.refNo == null || this.refNo == '') {
      this.toastService.warning('Please Select ');
    }
    else if (mode == 'view') {
      let obj = { 'action': mode, 'refNo': this.refNo, 'amendNo': this.amndNo, 'status': this.status, 'seqNo': this.seqNo, 'contractType': this.contType }
      this.router.navigate(['/mga-contract/mga-view-contract'], { queryParams: obj, skipLocationChange: true });

    } else {
      let obj = { 'action': mode, 'refNo': this.refNo, 'amendNo': this.amndNo, 'type': this.contType, 'seqNo': this.seqNo, 'status': this.status }
      this.router.navigate(['/mga-contract/mga-wizard'], { queryParams: obj, skipLocationChange: true });
    }
  }
  searchContract() {
    this.loaderService.isBusy = true;
    this.enableBottomDiv = false;
    let formData = this.mgaSrchFrm.getRawValue();
    let obj = {
      biStatus: (formData.biStatus == '' ? null : formData.biStatus),
      biBusType: (formData.biBusType == '' ? null : formData.biBusType),
      biUwYear: (formData.biUwYear == '' ? null : formData.biUwYear),
      biMga: (formData.biMga == '' ? null : formData.biMga),
      bpCompCode: (formData.bpCompCode == '' ? null : formData.bpCompCode),
      bpLobCode: (formData.bpLobCode == '' ? null : formData.bpLobCode),
      bpProdCode: (formData.bpProdCode == '' ? null : formData.bpProdCode),
      biApprUid: (formData.biApprUid == '' ? null : formData.biApprUid),
    };
    this.mgaService.searchContract(obj).subscribe(resp => {
      this.rowData = resp;
      this.contractData = this.rowData;
      this.calculateFilterCounts();
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
    this.isRadioActive = false;
  }
  calculateFilterCounts() {
    if (this.rowData) {
      this.totalCount = this.rowData.length;
      this.pendingCount = this.rowData.filter(datum => datum.biStatus === 'P').length;
      this.approvedCount = this.rowData.filter(datum => datum.biStatus === 'A').length;
    }
  }
  selectedRowData(val: any) {
    this.loaderService.isBusy = true;
    this.enableBottomDiv = false;
    this.isRadioActive = true;
    this.currentContract = val.data;
    this.refNo = val.data.binderContractPK.biRefNo;
    this.amndNo = val.data.binderContractPK.biAmendNo;
    this.seqNo = val.data.binderContractPK.biSeqNo;
    this.contType = val.data.biBusType;
    this.status = val.data.biStatus;
    this.contractDesc = val.data.biDesc;
    this.startDate = new Date(val.data.biStartDt);
    this.endDate = new Date(val.data.biEndDt);
    if (this.status == 'P') {
      this.EditBtnFlag = true;
      this.viewBtnFlag = false;
      this.amendBtnFlag = false;
      this.renewBtnFlag = false;
      this.amendHistoryBtnFlag = false;
      this.loaderService.isBusy = false;
    } else {
      this.EditBtnFlag = false;
      this.viewBtnFlag = true;
      this.amendBtnFlag = true;
      this.renewBtnFlag = true;
      this.amendHistoryBtnFlag = true;
      this.loaderService.isBusy = false;
    }
  }

  reset() {
    this.enableBottomDiv = false;
    this.mgaSrchFrm.patchValue({
      biBusType: '',
      biUwYear: '',
      biMga: '',
      biApprUid: '',
      biStatus: '',
      bpCompCode: undefined,
      bpLobCode: undefined,
      bpProdCode: undefined,
    });
    this.mgaSrchFrm.get('biApprUid').enable();
    this.pageChanged({ page: 1 });
    this.searchContract();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: false,
        fileName: 'MgaContracts.xlsx',
        skipHeader: false,
        sheetName: 'MGA Contracts',
        columnKeys: ['biUwYear', 'binderContract', 'biPeriod', 'biBusTypeDesc', 'biMgaDesc', 'biApprUid', 'biUpdDt', 'biStatus'],
        processCellCallback: (params) => {
          if (params.column.colId == "biUpdDt") {
            if (params.value == null || params.value == undefined) {
              return '';
            } else {
              return params.value;
            }
          } else if (params.column.colId == 'biStatus') {
            if (params.value == 'A')
              return 'Approved';
            else if (params.value == 'P')
              return 'Pending'
            else
              return params.value;
          } else {
            return params.value;
          }

        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('mgadashboard').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.searchContract();
    this.gridApi.sizeColumnsToFit();

  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: null,
      enableFilter: true
    };

    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }
  goToAmendment() {
    if (this.refNo == null || this.refNo == '' || this.refNo == undefined) {
      this.toastService.warning('Please Select ');
      return false;
    } else {
      this.loaderService.isBusy = true;
      this.open(this.amendmentContent, 'modal-dialog-centered modal-lg');
      this.mgaAmendmentForm.reset();
      this.mgaService.fetchAmendmentSrNo(this.refNo).subscribe(resp => {
        if (resp) {
          this.mgaAmendmentForm.patchValue({
            baAmendNo: resp.amendNo,
            baAmendSrNo: resp.amendSrNo,
            baAmendStartDt: this.startDate,
            baAmendEndDt: this.endDate,
          })
        }
        this.loaderService.isBusy = false;
      }, error => {
        this.toastService.error("Error in Fetching Details");
        this.loaderService.isBusy = false;
      })
    }
  }
  saveAmendment() {
    this.loaderService.isBusy = true;
    let formValue = this.mgaAmendmentForm.value;

    if (this.mgaAmendmentForm.valid) {
      formValue.baRefNo = this.refNo;
      formValue.baSeqNo = this.seqNo;
      formValue.baAmendEndDt = moment(formValue.baAmendEndDt, 'DD-MM-YYYY');
      console.log(formValue);
      this.mgaService.saveAmendmentDetails(formValue.baRefNo, formValue).subscribe(resp => {
        let data = resp;
        this.toastService.success("Successfully Saved");
        if (resp) {
          let obj = { 'action': 'edit', 'refNo': this.refNo, 'amendNo': data.biAmendNo, 'seqNo': data.biSeqNo, 'status': this.status, 'amendSrNo': formValue.baAmendSrNo }
          this.modalService.hide();
          this.router.navigate(['/mga-contract/mga-wizard'], { queryParams: obj, skipLocationChange: true });
        }
        this.loaderService.isBusy = false;
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in upload!");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.searchContract();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in upload!");
        }
      });

    } else {
      MgaUtils.validateAllFormFields(this.mgaAmendmentForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  openModal(content, val) {
    this.modalRef = this.modalService1.show(content, { class: val });
  }
  closeModal() {
    this.modalRef.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.modalService.hide();
  }
  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  goToRenewal() {
    this.mgaRenewForm.reset();
    if (this.refNo == null || this.refNo == '' || this.refNo == undefined) {
      this.toastService.warning('Please Select ');
      return false;
    } else {
      let endDay = this.currentContract.biEndDt;
      let startDay = moment(endDay).add(1, 'days').format('DD-MM-YYYY HH:mm');
      console.log(startDay);
      this.renewalDate = new Date(moment(startDay, 'DD/MM/YYYY').format('MM/DD/YYYY'));
      this.mgaRenewForm.patchValue({
        bcrStartDt: startDay,
      })
      this.open(this.renewContent, 'modal-dialog-centered modal-lg');
    }
  }
  saveRenew() {

    let formData = this.mgaRenewForm.getRawValue();

    if (this.mgaRenewForm.valid) {
      this.loaderService.isBusy = true;
      console.log(formData)

      formData.bcrAmendNo = 0;
      formData.bcrSeqNo = this.seqNo;
      formData.bcrStartDt = moment(moment(formData.bcrStartDt, 'DD-MM-YYYY HH:mm').toDate());
      formData.bcrEndDt = moment(formData.bcrEndDt, 'DD-MM-YYYY');
      let rnw = {
        refNo: this.refNo,
        bcrAmendNo: formData.bcrAmendNo,
        bcrSeqNo: formData.bcrSeqNo
      };
      delete formData.refNo;
      this.mgaService.validateRefNo(formData.bcrRefNo).subscribe((resp: any) => {
        if (resp.messageType == 'S') {
          this.mgaService.saveRenewDetails(rnw, formData).subscribe(resp => {
            this.modalService.hide();
            this.toastService.success("Successfully Renewed");

            let obj = { 'action': 'edit', 'refNo': formData.bcrRefNo, 'amendNo': formData.bcrAmendNo, 'seqNo': formData.bcrSeqNo, 'status': 'P', 'pathThrow': 'renew' }
            this.router.navigate(['/mga-contract/mga-wizard'], { queryParams: obj, skipLocationChange: true });
            this.loaderService.isBusy = false;

          }, error => {
            this.loaderService.isBusy = false;
            this.toastService.error(error.message);
          });
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error(resp.message);
        }
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      });
      this.loaderService.isBusy = false;


    } else {
      MgaUtils.validateAllFormFields(this.mgaRenewForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  goToAmendmentHistory() {
    if (this.refNo == null || this.refNo == '' || this.refNo == undefined) {
      this.toastService.warning('Please Select ');
      return false;
    }
    else {
      // this.router.navigate(['/mga-contract/mga-amend-history/'], { queryParams: { 'refNo': this.refNo, 'seqNo': this.seqNo, 'amendNo': this.amndNo, contDesc: this.contractDesc }, skipLocationChange: true });
      this.enableBottomDiv = true;
    }
  }
  setUwYear(value) {
    if (value) {
      const startDate = moment(value.getDate() + '/' + (value.getMonth() + 1) + '/' + value.getFullYear(), 'D/M/YYYY');
      const endDate = moment(startDate).add(1, 'year').add(-1, 'days');
      const data = {
        baAmendEndDt: endDate.format('DD/MM/YYYY'),
      };
      this.mgaAmendmentForm.patchValue(data);
    }
  }
  setRenewYear(value) {
    if (value) {
      let endDate = moment(value).add(1, 'year').add(-1, 'days');
      const data = {
        bcrEndDt: endDate.format('DD/MM/YYYY'),
      };
      // this.minDate = new Date(this.mgaRenewForm.get('bcrStartDt').value);
      this.mgaRenewForm.patchValue(data);
    }
  }
  changeStatus(evnt) {
    this.mgaSrchFrm.get('biApprUid').enable();
    if (evnt.value == 'P') {
      this.mgaSrchFrm.get('biApprUid').setValue("");
      this.mgaSrchFrm.get('biApprUid').disable();
    }
  }
}

function statusCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    if ('A' == params.data.thApprSts) {
      status = 'Approved'
    } else {
      status = 'Pending'
    }
    return status;
  }
}
function strtDateCellRenderer(params) {
  if (params && params.data && params.data.biStartDt) {
    return moment(params.data.biStartDt).format('DD/MM/YYYY');
  } else {
    return '';
  }
}

function endDateCellRenderer(params) {
  if (params && params.data && params.data.biEndDt) {
    return moment(params.data.biEndDt).format('DD/MM/YYYY');
  } else {
    return '';
  }

}

function periodCellRenderer(params) {
  if (params && params.data && params.data.biStartDt && params.data.biEndDt) {
    let startDate = moment(params.data.biStartDt).format('DD/MM/YYYY');
    let endDate = moment(params.data.biEndDt).format('DD/MM/YYYY');
    return startDate + ' - ' + endDate;
  } else {
    return '';
  }
}
var filterParams = {
  comparator: (a, b) => {
    const valA = moment(a.split(' -')[0], 'DD-MM-YYYY');
    const valB = moment(b.split(' -')[0], 'DD-MM-YYYY');
    const valA1 = moment(a.split(' -')[1], 'DD-MM-YYYY');
    const valB1 = moment(b.split(' -')[1], 'DD-MM-YYYY');
    if (valA == valB) {
      return 0;
    } else {
      if (valA > valB) {
        return 1;
      } else {
        if (valA1 == valB1) {
          return 0;
        } else {
          if (valA1 > valB1) {
            return 1;
          } else {
            return -1;
          }
        }
      }
    }
  },
};

var filterParams1 = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    console.log(a);
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};
