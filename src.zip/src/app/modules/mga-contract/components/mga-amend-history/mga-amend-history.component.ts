import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent4 } from '../radiorender/radiorender4.component';
import { LoaderService } from './../../../../services/loader.service';
import { MgaContractService } from './../../services/mga-contract.service';
declare var $: any;

@Component({
  selector: 'mga-amend-history',
  templateUrl: './mga-amend-history.component.html',
  styleUrls: ['./mga-amend-history.component.scss']
})

export class MgaAmendHistoryComponent implements OnInit {

  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  defaultColDef: any;
  domLayout: string;
  gridApi: any;
  amendHistGridApi: any;
  quickSearchValue = '';
  quickSearchValueHist = '';
  private rowGroupPanelShow;
  public frameworkComponents;
  public context;
  selectedData
  columnDefs: any;
  @Input() refNo: any;
  @Input() seqNo: any;
  @Input() amendNo: any;
  @Input() contractDesc: any;
  amendHistAllData: any;
  amendHistCols: any;
  rowSelection: string;
  amendRef: any;
  amendSrNo: any;
  amendDesc: any;
  historyData: any;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  closeResult: string;
  viewPage: boolean = false;
  auditPage: boolean = false;
  viewButton: boolean = false;
  amendmendData: any;
  showAuditButton = true;
  showEditButton: any;
  documentRefId: string;
  documentTypes: any[];
  documents: any;
  isDocumentNeedsToBeUpdated: any;
  temp: any;
  @ViewChild('errorModal') errorModal: ElementRef;
  modalRef: BsModalRef;
  constructor(
    private mgaService: MgaContractService,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private modalService: BsModalService,
    private treatyService: TreatyService,
    private modalService1: BsModalService,

  ) {

    this.defaultColDef = {
      resizable: true,
      enableRowGroup: true,
      filter: true,
      sortable: true,
    };
    this.rowGroupPanelShow = 'always';
    this.domLayout = 'autoHeight';
    this.setGridConfig();
  }
  setGridConfig() {
    this.rowSelection = 'single';
    this.columnDefs = [
      {
        headerName: 'Page',
        field: 'tcaPage',
        headerTooltip: 'Page',
        width: 120
      },
      {
        headerName: 'Section',
        field: 'tcaSection',
        headerTooltip: 'Section',
        width: 120
      },

      {
        headerName: 'Field',
        field: 'tcaField',
        headerTooltip: 'Field',
        width: 120
      },
      {
        headerName: 'Log Type',
        field: 'tcaLogType',
        headerTooltip: 'Log Type',
        width: 120,
        // cellRenderer: function (params) {
        //   if (params.value === undefined || params.value === null) {
        //     return '';
        //   } else if (params.value === 'I') {
        //     return '<span class="ag-element"> Insert </span>';
        //   } else if (params.value === 'U') {
        //     return '<span class="ag-element"> Update </span>';
        //   } else if (params.value === 'D') {
        //     return '<span class="ag-element"> Delete </span>';
        //   }
        // },
        valueGetter: function (params) {
          if (params && params.data && params.data.tcaLogType) {
            if (params.data.tcaLogType === 'I') {
              return 'Insert';
            } else if (params.data.tcaLogType === 'U') {
              return 'Update';
            } else if (params.data.tcaLogType === 'D') {
              return 'Delete';
            } else {
              return '';
            }
          } else {
            return '';
          }
        },
      },
      {
        headerName: 'Old Value',
        field: 'tcaOldValue',
        headerTooltip: 'Old Value',
        width: 120,
        cellClassRules: {
          'ag-red-outer': function (params) {
            if (params.data.tcaLogType == 'D') {
              return params.data.tcaOldValue;
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.data.tcaLogType === 'D') {
            return '<span class="ag-element"> ' + params.data.tcaOldValue + ' </span>';
          } else {
            return params.data.tcaOldValue;
          }
        },
      },
      {
        headerName: 'New Value',
        field: 'tcaNewValue',
        headerTooltip: 'New Value',
        width: 120,
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.data.tcaLogType == 'I') {
              return params.data.tcaNewValue;
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.data.tcaLogType == 'U') {
              return params.data.tcaNewValue;
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.data.tcaLogType == 'I') {
            return '<span class="ag-element"> ' + params.data.tcaNewValue + ' </span>';
          } else if (params.data.tcaLogType == 'U') {
            return '<span class="ag-element"> ' + params.data.tcaNewValue + ' </span>';
          } else {
            return params.data.tcaNewValue;
          }
        },
      },
      {
        headerName: 'Changed on',
        field: 'tcaLogDate',
        headerTooltip: 'Changed on',
        width: 120,
        valueGetter: function (data) {
          if (data.data && data.data.tcaLogDate) {
            return moment(data.data.tcaLogDate).format('DD/MM/YYYY HH:mm')
          }
        },
      },
      {
        headerName: 'Log User',
        field: 'tcaLogUid',
        headerTooltip: 'Log User',
        width: 120
      }
    ];
    this.amendHistCols = [
      {
        headerName: "Select",
        field: 'baAmendNo',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
        width: 120,
        headerTooltip: 'Select',
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        headerName: 'Sr No', field: 'baAmendNo', width: 100, headerTooltip: 'Sr No', resizable: false,
        enableRowGroup: false,
        filter: false,
        sortable: false,
      },
      { headerName: 'Reference No', field: 'baRefNo', headerTooltip: 'Reference No', },
      {
        headerName: 'Contract Start Date', field: 'baContractStartDt',
        headerTooltip: 'Contract Start Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.baContractStartDt) {
            return moment(params.data.baContractStartDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        headerName: 'Contract End Date', field: 'baContractEndDt',
        headerTooltip: 'Contract End Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.baContractEndDt) {
            return moment(params.data.baContractEndDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      { headerName: 'Amendment Remarks', field: 'baRemarks', headerTooltip: 'Amendment Remarks', tooltipField: 'baRemarks', },
      {
        headerName: 'Effective Date', field: 'baAmendStartDt',
        headerTooltip: 'Effective Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.baAmendStartDt) {
            return moment(params.data.baAmendStartDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        headerName: 'Effective To', field: 'baAmendEndDt',
        headerTooltip: 'Effective To',
        valueGetter: function (params) {
          if (params && params.data && params.data.baAmendEndDt) {
            return moment(params.data.baAmendEndDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      { headerName: 'Amended By', field: 'baCrUid', headerTooltip: 'Amended By', },
      {
        headerName: 'Amended On', field: 'baCrDt',
        headerTooltip: 'Amended On',
        valueGetter: function (params) {
          if (params && params.data && params.data.baCrDt) {
            return moment(params.data.baCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      { headerName: 'Approved By', field: 'baApprUid', headerTooltip: 'Approved By', },
      {
        headerName: 'Approved On', field: 'baApprDt', headerTooltip: 'Approved On',
        valueGetter: function (params) {
          if (params && params.data && params.data.baApprDt) {
            return moment(params.data.baApprDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
    ];
  }
  ngOnInit() {
    this.loaderService.isBusy = true;
    // this.activeRoute.queryParams.subscribe((params:any) => {
    //   if (params) {
    //     this.refNo = params.refNo;
    //     this.seqNo = params.seqNo;
    //     this.amendNo = params.amendNo;
    //     this.contractDesc = params.contDesc;
    //     this.mgaService.viewMgaContract(this.refNo, this.seqNo, this.amendNo).subscribe((result: any) => {
    //       this.documentRefId = result.binderContract.biFlex05;
    //     })
    //     this.fetchAllAmendHistory(this.refNo);
    //   } else {
    //     this.toastService.error('Error in fetching Amendment History');
    //   }
    // });
    this.mgaService.viewMgaContract(this.refNo, this.seqNo, this.amendNo).subscribe((result: any) => {
      this.documentRefId = result.binderContract.biFlex05;
    })
    this.fetchAllAmendHistory(this.refNo);
    this.agGridOptions();
  }
  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        console.log(res);
        this.documentTypes = res.appcodeList;
      }, err => {
        console.log(err);
      });
  }
  fetchAllAmendHistory(data) {
    this.mgaService.fetchAllAmendHistory(data).subscribe(
      res => {
        this.amendHistAllData = res;
        if (this.amendHistAllData.length > 0) {
          this.context.componentParent.selectedRowId = this.amendHistAllData[0].baAmendNo;
          this.View({ data: this.amendHistAllData[0] });
        }
        this.loaderService.isBusy = false;
      }, err => {
        this.loaderService.isBusy = false;
        this.toastService.error('Error in Fetching');
      });
  }


  onGridReady(gridApi, table) {
    gridApi = gridApi.api;
    gridApi.sizeColumnsToFit();
    if (table === 'amendHistAll') {
      this.amendHistGridApi = gridApi;
    } else if (table === 'history') {
      this.gridApi = gridApi;
    }
  }
  onPaginationCountChange(gridApi: any, page) {
    gridApi.paginationSetPageSize(page);
    gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    gridApi.setQuickFilter(qickSearch);
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent4
    };
  }
  selectedRowData(data) {
    this.viewPage = false;
    this.viewButton = true;
  }
  View(data?: any) {
    this.loaderService.isBusy = true;
    if (data) {
      this.selectedData = data.data;
    }

    this.amendmendData = {
      refNo: this.selectedData.baRefNo,
      seqNo: this.selectedData.baSeqNo,
      amendNo: this.selectedData.baAmendNo,
      amendSrNo: this.selectedData.baAmendSrNo,
      remarks: this.selectedData.baRemarks,
      status: this.selectedData.baStatus,
    };
    this.viewPage = true;
    this.auditPage = false;
    if (this.selectedData.baApprSts !== "A") {
      this.showEditButton = true
    } else {
      this.showEditButton = false
    }
    this.context.componentParent.selectedRowId = this.selectedData.baAmendNo;
    if (this.selectedData.baAmendNo !== 0) {
      this.showAuditButton = true;
      this.showEditButton = true;
    } else {
      this.showAuditButton = false;
      this.showEditButton = true;
    }
    if (this.selectedData.baApprSts !== "A") {
      this.showEditButton = true;
    } else {
      this.showEditButton = false;
    }
    setTimeout(() => {
      this.loaderService.isBusy = false;
    }, 500);

  }

  Edit() {
    this.onActionContract(this.amendmendData, 'Edit');
  }

  cancelAmend() {
    this.showDialogbox(this.amendmendData);
  }

  viewAudit() {
    this.amendmendData = {
      refNo: this.selectedData.baRefNo,
      seqNo: this.selectedData.baSeqNo,
      amendNo: this.selectedData.baAmendNo,
      amendSrNo: this.selectedData.baAmendSrNo,
      remarks: this.selectedData.baRemarks,
      status: this.selectedData.baStatus,
    };
    this.retriveHistoryDetails(this.amendmendData);
  }
  onRowClicked(e) {
    this.selectedData = e.data;
    if (e.event.target !== undefined) {
      let data = e.data;
      if (data.baAmendNo !== 0) {
        this.showAuditButton = true
      } else {
        this.showAuditButton = false
      }
      if (data.baApprSts !== "A") {
        this.showEditButton = true
      } else {
        this.showEditButton = false
      }
      let actionType = e.event.target.getAttribute("data-action-type");
      this.amendmendData = {
        refNo: data.baRefNo,
        seqNo: data.baSeqNo,
        amendNo: data.baAmendNo,
        amendSrNo: data.baAmendSrNo,
        remarks: data.baRemarks,
        status: data.baStatus,
      };
      switch (actionType) {
        case "View":
          return this.retriveHistoryDetails(this.amendmendData);
        case "Edit":
          return this.onActionContract(this.amendmendData, 'Edit');
        case "Delete":
          return this.showDialogbox(this.amendmendData);
      }
    }
  }
  retriveHistoryDetails(data) {
    this.loaderService.isBusy = true;
    this.mgaService.retriveAmendmendOldNewHistory(data).subscribe(
      res => {
        this.viewPage = false;
        this.auditPage = true;
        this.historyData = res;
        this.amendRef = data.refNo;
        this.amendSrNo = data.amendNo;
        this.amendDesc = data.remarks
        this.loaderService.isBusy = false;

      },
      err => {
        this.loaderService.isBusy = false;
        this.toastService.error('Error in Fetching');
      }
    );
  }
  onActionContract(data, action) {
    if (action == 'Edit') {
      this.loaderService.isBusy = true;
      let obj = { 'action': 'edit', 'refNo': data.refNo, 'amendNo': data.amendNo, 'seqNo': data.seqNo, 'status': data.status, 'amendSrNo': data.amendSrNo }
      this.router.navigate(['/mga-contract/mga-wizard'], { queryParams: obj, skipLocationChange: true });
      this.loaderService.isBusy = false;
    }
  }

  showDialogbox(data: any) {
    this.temp = data;
    this.open(this.confirmModal, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  close() {
    this.modalService.hide();
  }
  deleteRow() {
    if (this.temp && this.temp.refNo) {
      this.loaderService.isBusy = true;
      this.mgaService.deleteAmendHistory(this.temp).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully.');
        this.fetchAllAmendHistory(this.temp.refNo);
        this.mgaService.sendMGAGridLoad('reload');
        this.loaderService.isBusy = false;
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.modalService.hide();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Deleting Data");
        }
      })
    } else {
      this.toastService.error('Error in Deleting Data');
    }
  }
  openModal(content, val) {
    this.modalRef = this.modalService1.show(content, { class: val });
  }
  closeModal() {
    this.modalRef.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.modalService.hide();
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  back() {
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
  }
  displayRowCount(gridApi) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }
}
