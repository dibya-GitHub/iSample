import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-amend-history/mga-amend-history.component.spec.ts
import { MgaAmendHistoryComponent } from './mga-amend-history.component';

describe('MgaAmendHistoryComponent', () => {
  let component: MgaAmendHistoryComponent;
  let fixture: ComponentFixture<MgaAmendHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaAmendHistoryComponent ]
=======
import { RecoveryEnquiryComponent } from './recovery-enquiry.component';

describe('RecoveryEnquiryComponent', () => {
  let component: RecoveryEnquiryComponent;
  let fixture: ComponentFixture<RecoveryEnquiryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecoveryEnquiryComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/recovery-enquiry/recovery-enquiry.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-amend-history/mga-amend-history.component.spec.ts
    fixture = TestBed.createComponent(MgaAmendHistoryComponent);
=======
    fixture = TestBed.createComponent(RecoveryEnquiryComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/recovery-enquiry/recovery-enquiry.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
