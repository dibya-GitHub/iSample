import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaContractService } from '../../services/mga-contract.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { MgaWizardHelperService } from './../../services/mga-wizard.service';
import { MgaUtils } from './../mga-utils';

@Component({
  selector: 'mga-outward-reinsurance',
  templateUrl: './mga-outward-reinsurance.component.html',
  styles: [`
        .contactval{
            padding-top: 8px !important;
            padding-bottom: 8px !important;
        }
        .grey-background.px-5.padding-bottom10 {
            /* padding-top: 3.5em; */
        }
    `]
})
export class MgaOutwardReinsuranceComponent implements OnInit {

  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() action: string;
  @Input() seqNo: number;
  @Input() productSrNo: number;
  @Output() approve = new EventEmitter<any>();

  outwardReinsForm: UntypedFormGroup;
  contTypeVal: string = 'Outward Reinsurance';
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public defaultColDef;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;
  temp: any;
  showForm = false
  outwardRefNoList;
  contractTypeList;
  saveAction;
  outwardDetails;

  private outRiGridApi;
  outRiQuickSearchValue: string = '';
  outRiShowEntriesOptions = [10, 20, 50, 100];
  outRiShowEntriesOptionSelected = 10;
  prodCode: any;
  selectedRow: any;
  closeResult: string;
  boProdSrNo: any;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  @ViewChild('approveModal') approveModal: ElementRef;
  modalRef: BsModalRef;
  @ViewChild('errorModal') errorModal: ElementRef;
  contractCode: any;
  childOutwardList: any;
  editOutward: any;
  AddFlag: boolean = true;
  companylobprodList: any;
  companyInfo: any;
  contractType: any;
  contractIdList: any;
  errorEvent: boolean = false;
  disableApprBtn: boolean = true;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private mgaService: MgaContractService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private toastService: ToastService,
    private modalService: BsModalService,
    private wizardHelperService: MgaWizardHelperService,
    private modalService1: BsModalService,

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.createOutwardForm();
    this.getDropdownData();
    this.agGridOptions();
    this.loadColumn();
    this.getChildOutwardList();
  }

  loadColumn() {
    this.columnDefs = [
      {
        headerName: "Company / LOB / Product",
        headerTooltip: "Company / LOB / Product",
        field: "boCompClassProductDesc",
        width: 400
      },
      {
        headerName: "Contract Type",
        headerTooltip: "Contract Type",
        field: "boContractType",
      },
      {
        headerName: "Allocation Order",
        headerTooltip: "Allocation Order",
        field: "boAllocOrder",
        width: 140
      },
      {
        headerName: "Outward Contract Ref",
        headerTooltip: "Outward Contract Ref",
        field: "bpCompCode",
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.boContractRefDesc;
          } else { return '' }
        }
      },
      {
        headerName: "Share / Limit",
        headerTooltip: "Share / Limit",
        field: "boShare",
        cellStyle: function (params) {
          if ((params.data.boTtyContType).slice(-1) == 'X') {
            return { textAlign: 'right' };
          } else {
            return { textAlign: 'left' };
          }
        },
        valueFormatter: MgaUtils.currencyFormatter,
        width: 100,
      },
      {
        headerName: "Action",
        template:
          `<a>
             <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
            </a>&nbsp;
            <a>
             <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
            </a>`,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        width: 130
      }
    ];
  }
  getDropdownData() {
    this.getOutwardContractId();
    this.mgaService.getContractType().subscribe(resp => {
      this.contractTypeList = resp['contractTypeList'];
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }

  createOutwardForm() {
    this.outwardReinsForm = this.fb.group({
      binderOutwardPK: {
        boAmendNo: this.amendNo,
        boRefNo: this.refNo,
        boSrNo: this.productSrNo,
        boSeqNo: this.seqNo
      },
      bpCompCode: [undefined, Validators.required],
      boNonPropFac: '',
      boNonPropTty: '',
      boPropFac: '',
      boPropTty: '',
      boProdNo: [undefined],
      boProdSrNo: [undefined],
      boTtyContType: [undefined, Validators.required],
      boTtyRefNo: [undefined],
      boTtySeqNo: [undefined],
      boTtyAmendNo: [undefined],
      boTtyYear: [undefined],
      boAllocOrder: ['', Validators.required],
      boStatus: 'P',
      boShare: '',
      boEndDt: '',
      boStDt: '',
      boFlex02: [undefined, Validators.required],

    })
  }

  addOutwardReins() {
    this.showForm = true;
    this.AddFlag = false;
    this.saveAction = 'add';
    this.outwardReinsForm.reset();
    this.outwardReinsForm.get('boTtyContType').enable();
    this.outwardReinsForm.get('boFlex02').enable();
  }
  saveForm(actionType) {
    this.loaderService.isBusy = true;
    let data = this.outwardReinsForm.value;
    if (this.outwardReinsForm.valid) {
      data.boStDt = moment(data.boStDt, 'DD-MM-YYYY');
      data.boEndDt = moment(data.boEndDt, 'DD-MM-YYYY');
      data.boStatus = 'P';
      data.boCrDt = new Date();
      data.boCrUid = this.session.get('userId');
      data.boUpdDt = new Date();
      data.boUpdUid = this.session.get('userId');
      data.binderOutwardPK = {
        boRefNo: this.refNo,
        boAmendNo: this.amendNo,
        boSeqNo: this.seqNo,
      };
      data.boProdSrNo = this.companyInfo.prodSrNo;
      data.boCompCode = this.companyInfo.companyCode;
      data.boLobCode = this.companyInfo.lobCode;
      data.boProdCode = this.companyInfo.prodCode;
      data.boFlex01 = data.boShare;
      if (actionType == 'add') {
        data.boCrDt = new Date();
        data.boCrUid = this.session.get('userId');
        data.boUpdDt = new Date();
        data.boUpdUid = this.session.get('userId');
        this.mgaService.addOutwardRi(data).subscribe(res => {
          this.toastService.success('Successfully Saved');
          this.showForm = false;
          this.getChildOutwardList()
          this.loaderService.isBusy = false;
          this.AddFlag = true;
          this.errorEvent = false;
        }, error => {
          if (error instanceof HttpErrorResponse) {
            if (error.error instanceof ErrorEvent) {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            } else {
              switch (error.status) {
                case 400:
                  this.loaderService.isBusy = false;
                  this.showErrorDialogBox(error.error.message);
                  this.modalService.hide();
                  break;
                default:
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in upload!");
                  break;
              }
            }
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in upload!");
          }
        })
      } else if (actionType == 'edit') {
        data.boUpdDt = new Date();
        data.boUpdUid = this.session.get('userId');
        data.binderOutwardPK.boSrNo = this.editOutward.binderOutwardPK.boSrNo;
        data.boTtySeqNo = this.editOutward.boTtySeqNo;
        data.boTtyYear = this.editOutward.boTtyYear;

        data.boTtyRefNo = this.editOutward.boTtyRefNo;
        data.boTtySeqNo = this.editOutward.boTtySeqNo;
        data.boTtyAmendNo = this.outwardReinsForm.get('boTtyAmendNo').value;
        data.boTtyContType = this.editOutward.boTtyContType;
        this.mgaService.updateOutwardRi(data.binderOutwardPK.boRefNo, data).subscribe(res => {
          this.getChildOutwardList();
          this.toastService.success('Successfully Updated');
          this.showForm = false;
          this.AddFlag = true;
          this.loaderService.isBusy = false;
          this.errorEvent = false;
        }, error => {
          if (error instanceof HttpErrorResponse) {
            if (error.error instanceof ErrorEvent) {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            } else {
              switch (error.status) {
                case 400:
                  this.loaderService.isBusy = false;
                  this.showErrorDialogBox(error.error.message);
                  this.modalService.hide();
                  break;
                default:
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in Updating!");
                  break;
              }
            }
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Updating!");
          }
        })
      }
    } else {
      this.errorEvent = true;
      MgaUtils.validateAllFormFields(this.outwardReinsForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  openModal(content, val) {
    this.modalRef = this.modalService1.show(content, { class: val });
  }
  closeModal() {
    this.modalRef.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.modalService.hide();
  }
  close() {
    this.modalService.hide();
  }
  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  splitOutwardData(event) {
    let str = event.value;
    let obj = str.split('-');
    this.companyInfo = {
      companyCode: obj[0],
      lobCode: obj[1],
      prodCode: obj[2],
      prodSrNo: obj[3],
    };
  }
  getOutwardCompanyInfo(srNo) {
    if (srNo == null) {
      this.loaderService.isBusy = false;
    } else {
      this.mgaService.getOutwardCompanyInfo(this.refNo, srNo).subscribe((res: any) => {
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    }
  }
  getChildOutwardList() {
    let obj = {
      boRefNo: this.refNo,
      boSeqNo: this.seqNo,
      boAmendNo: this.amendNo,
      boProdCode: '0',
    };
    this.mgaService.getChildOutwardDetails(obj).subscribe((res: any) => {
      this.childOutwardList = res;
      if (this.childOutwardList.length > 0) {
        this.disableApprBtn = false;
      } else {
        this.disableApprBtn = false;
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  onRowClickedOutRi(evt) {
    let data = evt.data;
    this.prodCode = data.boProdCode;
    this.boProdSrNo = data.boProdSrNo;
    this.loaderService.isBusy = false;
  }

  getOutwardContractId() {
    this.loaderService.isBusy = true;
    this.mgaService.getOutwardCompanyId(this.refNo, this.seqNo, this.amendNo).subscribe((resp: any) => {
      this.companylobprodList = resp.outwardCompanyLob;
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  getOutwarddata(event) {
    if (this.companyInfo && (this.companyInfo.companyCode == undefined || this.companyInfo.companyCode == null)) {
      this.toastService.warning("Please Select Company / LOB / Product")
    } else {
      this.contractType = event.value;
      this.mgaService.getOutwardContractId(this.refNo, this.seqNo, this.contractType, this.companyInfo.prodCode, this.companyInfo.companyCode, this.companyInfo.lobCode).subscribe((resp: any) => {
        this.contractIdList = resp.outwardContracts;
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      })
    }
  }
  onContractIdChange(event) {
    this.loaderService.isBusy = true;
    let data = {
      refNo: this.refNo,
      boContType: this.contractType,
      boProdCode: this.companyInfo.prodCode,
      contRefSeqNo: event.value
    };
    this.mgaService.getDetailsByContract(data).subscribe(res => {
      this.outwardReinsForm.patchValue({
        boTtyYear: res.treatyYear,
        boShare: res.share,
        boStDt: moment(res.riStartDate).format('DD/MM/YYYY'),
        boEndDt: moment(res.riEndDate).format('DD/MM/YYYY'),
        boTtyRefNo: res.treatyRefNo,
        boTtySeqNo: res.treatySeqNo,
        boTtyAmendNo: res.treatyAmendNo,
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }

  approval() {
    // || (this.outwardReinsForm.touched || this.outwardReinsForm.dirty)
    if (this.errorEvent) {
      this.toastService.warning('Enter mandatory fields');
    } else {
      this.openModal(this.approveModal, 'modal-sm');
    }

  }

  onActionEditOutward(data) {
    this.loaderService.isBusy = true;
    this.saveAction = 'edit';
    this.showForm = true;
    this.AddFlag = false;
    this.editOutward = data;
    this.outwardReinsForm.get('boTtyContType').disable();
    this.outwardReinsForm.get('boFlex02').disable();
    this.companyInfo = {
      companyCode: data.boCompCode,
      lobCode: data.boLobCode,
      prodCode: data.boProdCode,
      prodSrNo: data.boProdSrNo,
    };

    // this.getOutwarddataOnEdit(data);
    this.outwardReinsForm.patchValue({
      boAllocOrder: data.boAllocOrder,
      boShare: data.boShare,
      boStDt: moment(data.boStDt).format('DD/MM/YYYY'),
      boEndDt: moment(data.boEndDt).format('DD/MM/YYYY'),
      boTtyContType: data.boTtyContType,
      boFlex02: data.boFlex02,
    });
    this.contractType = this.outwardReinsForm.get('boTtyContType').value;
    this.mgaService.getOutwardDataEdit(data).subscribe((resp: any) => {
      this.contractIdList = resp.outwardContractsEdit;
      let comb = data.boTtyRefNo + '-' + data.boTtySeqNo;
      let keyValue = this.contractIdList.find(datum => datum.key === comb);
      this.outwardReinsForm.get('bpCompCode').setValue(comb);
      this.onContractIdChange(keyValue);
    })
    this.loaderService.isBusy = false;
  }
  showDialogbox(data: any) {
    this.temp = {
      boRefNo: data.binderOutwardPK.boRefNo,
      boSeqNo: data.binderOutwardPK.boSeqNo,
      boAmendNo: data.binderOutwardPK.boAmendNo,
      boSrNo: data.binderOutwardPK.boSrNo,
      boProdSrNo: data.boProdSrNo
    };
    this.openModal(this.confirmModal, 'modal-sm');
  }
  deleteRow() {
    if (this.temp && this.temp.boRefNo && this.temp.boSrNo) {
      this.loaderService.isBusy = true;
      this.mgaService.deleteOutwardRi(this.temp.boRefNo, this.temp.boSeqNo, this.temp.boAmendNo, this.temp.boSrNo, this.temp.boProdSrNo).subscribe(() => {
        this.closeModal();
        this.toastService.success('Deleted Succcessfully.');
        this.getChildOutwardList()
        this.loaderService.isBusy = false;
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.modalService.hide();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Deleting Data");
        }
      })
    } else {
      this.toastService.error('Error in Deleting Data');
    }
  }
  checkParentFieldCheck() {
    let contType = this.outwardReinsForm.get('boTtyContType').value;
    if (contType == null) {
      this.toastService.warning("Please select Contract type first");
    }
  }
  back() {
    this.showForm = false;
    this.AddFlag = true;
    this.errorEvent = false;
    this.outwardReinsForm.reset();
  }
  goPrevious() {
    if (this.errorEvent) {
      this.toastService.warning('Enter mandatory fields');
    } else {
      this.wizardHelperService.goPrevious();
    }

  }
  onGridReadyOutRi(params) {
    this.outRiGridApi = params.api;
    this.outRiGridApi.sizeColumnsToFit();
  }

  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }

  // ####### Outward Second table ######
  onQuickFilterChanged() {
    this.outRiGridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.outRiGridApi) {
      return this.outRiGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.outRiGridApi) {
      this.outRiGridApi.exportDataAsExcel();
    } else {
      this.outRiGridApi.api.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.outRiGridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.outRiGridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.outRiGridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("outwardReinsTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case 'Edit':
          return this.onActionEditOutward(data);
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
}
