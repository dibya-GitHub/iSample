import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaOutwardReinsuranceComponent } from './mga-outward-reinsurance.component';

describe('MgaOutwardReinsuranceComponent', () => {
  let component: MgaOutwardReinsuranceComponent;
  let fixture: ComponentFixture<MgaOutwardReinsuranceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaOutwardReinsuranceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MgaOutwardReinsuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
