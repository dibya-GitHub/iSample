import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaTaAccountingViewComponent } from './mga-ta-accounting-view.component';

describe('MgaTaAccountingViewComponent', () => {
  let component: MgaTaAccountingViewComponent;
  let fixture: ComponentFixture<MgaTaAccountingViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MgaTaAccountingViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MgaTaAccountingViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
