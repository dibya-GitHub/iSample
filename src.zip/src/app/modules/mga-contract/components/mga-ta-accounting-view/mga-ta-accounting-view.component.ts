import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { MgaContractService } from 'src/app/modules/mga-contract/services/mga-contract.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { Utils } from 'src/app/utils';

@Component({
  selector: 'mga-ta-accounting-view',
  templateUrl: './mga-ta-accounting-view.component.html',
  styleUrls: ['./mga-ta-accounting-view.component.scss']
})
export class MgaTaAccountingViewComponent implements OnInit {
  techAccForm: UntypedFormGroup;
  mgaList: any = [];
  bsConfig: Partial<BsDatepickerConfig> = new BsDatepickerConfig();

  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public defaultColDef;

  public context;

  techAccList: any = [];
  transactionType: any = [];
  accountToList: any = [];
  contractIdList: any = [];
  userList: any = [];
  showPending: boolean = false;
  columnDefs: any;
  headerData: any;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private mgaService: MgaContractService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.bsConfig = Object.assign({}, { rangeInputFormat: 'DD/MM/YYYY', customTodayClass: 'custom-today-class' });
    this.createForm();
    this.columnDefsFn();
    this.search();
  }

  columnDefsFn() {
    const context = this;
    this.columnDefs = [
      {
        headerName: "Batch Id",
        headerTooltip: "Batch Id",
        field: "adTransId",
        tooltipField: 'adTransId',
        valueGetter: function (params) {
          if (params.data && params.data.adTransId) {
            return 'M - ' + params.data.adTransId;
          } else {
            return "";
          }
        },
      },
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "adDivnCodeDesc",
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.adCustCodeDesc;
          }
        },
      },

      {
        headerName: "Doc Date",
        headerTooltip: "Doc Date",
        field: "adDocDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.adDocDt) {
            return moment(params.data.adDocDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        sortable: false,
        filter: true,
        enableRowGroup: false,
      },
      {
        headerName: "Doc No",
        headerTooltip: "Doc No",
        field: "adDocNo",
        valueGetter: function (params) {
          if (params.data && params.data.adTranCode && params.data.adDocNo) {
            return params.data.adTranCode + ' - ' + params.data.adDocNo;
          } else {
            return "";
          }
        },
      },
      {
        headerName: "Narration",
        headerTooltip: "Narration",
        field: "adNarration",
        tooltipField: 'adNarration'
      },
      {
        headerName: "Currency",
        headerTooltip: "Currency",
        field: "adCurrCode",
      },
      {
        headerName: "Dr / Cr",
        headerTooltip: "Dr / Cr",
        field: "adDrcrFlag",
        valueGetter: function (params) {
          if (params.data && params.data.adDrcrFlag) {
            if (params.data.adDrcrFlag === 'D') {
              return 'Dr';
            } else if (params.data.adDrcrFlag === 'C') {
              return 'Cr';
            }
          }
        },
      },
      {
        headerName: "Amnt in Acnt Curr",
        headerTooltip: "Amnt in Acnt Curr",
        field: "adAmtFc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: Utils.currencyDecimalFormatter,
      },
      {
        headerName: "Amnt in Funct Curr (" + this.session.get('baseCurrency') + ")",
        headerTooltip: "Amnt in Funct Curr (" + this.session.get('baseCurrency') + ")",
        field: "adAmtLc1",
        cellStyle: { textAlign: 'right' },
        valueFormatter: Utils.currencyDecimalFormatter,
      },
      {
        headerName: "Main Account",
        headerTooltip: "Main Account",
        field: "adMainAcntCodeDesc",
        valueGetter: function (params) {
          if (params.data && params.data.adMainAcntCode && params.data.adMainAcntCodeDesc == null) {
            return params.data.adMainAcntCode;
          } else if (params.data && params.data.adMainAcntCode && params.data.adMainAcntCodeDesc) {
            return params.data.adMainAcntCode + ' - ' + params.data.adMainAcntCodeDesc;
          } else {
            return "";
          }
        },
      },

      {
        headerName: "Sub Account",
        headerTooltip: "Sub Account",
        cellStyle: { textAlign: 'right' },
        field: "adSubAcntCodeDesc",
        valueGetter: function (params) {
          if (params.data && params.data.adSubAcntCode && params.data.adSubAcntCodeDesc == null) {
            return params.data.adSubAcntCode;
          } else if (params.data && params.data.adSubAcntCode && params.data.adSubAcntCodeDesc) {
            return params.data.adSubAcntCode + ' - ' + params.data.adSubAcntCodeDesc;
          } else {
            return "";
          }
        }
      },
      {
        headerName: "Year of Accounts",
        headerTooltip: "Year of Accounts",
        field: "adFlex02",
        width: 250,
      },
      {
        headerName: "Product",
        headerTooltip: 'Product',
        field: "adProductDesc",
        tooltipField: 'adProductDesc'
      },
    ];
  }
  createForm() {
    this.techAccForm = this.fb.group({
      adTransIdFrm: ['1', Validators.required],
      adTransIdTo: ['25', Validators.required],
      dateFm: [undefined],
      dateTo: [undefined],
    }, {
      validator: [this.graterValidator("adTransIdFrm", "adTransIdTo")]
    });
  }
  searchClicked() {
    this.search();
  }
  search() {
    this.techAccList = [];
    this.loaderService.isBusy = true;
    if (this.techAccForm.valid) {
      let formData = this.techAccForm.getRawValue();
      formData.adTransIdFrm = (formData.adTransIdFrm == null) ? "" : formData.adTransIdFrm;
      formData.adTransIdTo = (formData.adTransIdTo == null) ? "" : formData.adTransIdTo;
      formData.dateFm = (formData.dateFm == null) ? "" : moment(formData.dateFm, 'DD/MM/YYYY').format('DD/MM/YYYY');
      formData.dateTo = (formData.dateTo == null) ? "" : moment(formData.dateTo, 'DD/MM/YYYY').format('DD/MM/YYYY');
      let obj = {
        binderTAM: 'BIND_TAM',
        adTransIdFrm: formData.adTransIdFrm,
        adTransIdTo: formData.adTransIdTo,
        dateFm: formData.dateFm,
        dateTo: formData.dateTo,
      };

      this.mgaService.accountAdvancedSearch(obj).subscribe(resp => {
        this.techAccList = resp;
        if (this.techAccList.length > 0) {
          this.headerData = this.techAccList[0].adCurrCode;
        }
        this.loaderService.isBusy = false;
      }, error => {
        this.toastService.error('Error in Retrive Data');
        this.loaderService.isBusy = false;
      });
    } else {
      this.validateAllFormFields(this.techAccForm);
      this.loaderService.isBusy = false;
    }
  }

  reset() {
    this.techAccForm.patchValue({
      dateFm: null,
      dateTo: null,
      adTransIdFrm: null,
      adTransIdTo: null,
      bhTtyRefNo: null,
      bhCrUid: null,
    });
    this.pageChanged({ page: 1 });
    this.search();
  }
  newAccounting() {
    this.router.navigate(['/mga-ta-accounting-create'], { queryParams: { newForm: 'New' } });
  }
  gotoAdvancedSearch() {
    this.router.navigate(['/mga-ta-accounting-view'], { queryParams: { newForm: 'New' } });
  }
  cancelAdvancedSearch() {
    this.router.navigate(['/mga-ta-accounting']);

  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("accEntryListTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'technicalAccounting.xlsx',
        skipHeader: false,
        sheetName: 'Technical Accounting',
        processCellCallback: (params) => {
          if (params.column.colId) {
            return params.value;
          }
        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  agGridOptions() {
    this.context = { componentParent: this };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  validateAllFormFields(formGroup: UntypedFormGroup | UntypedFormArray) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
        control.markAsDirty({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      } else if (control instanceof UntypedFormArray) {
        this.validateAllFormFields(control as UntypedFormArray);
      }
    });
  }
  graterValidator(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message =
        "Must be greater than Start Batch id";
      if (second.value > first.value) {
      } else {
        second.setErrors({ equalValue: message });
        return { equalValue: true };
      }
    };
  }
}
var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};
function currencyFormatter(params) {
  if (params && params.value != null) {
    return Intl.NumberFormat('en-US',
      { minimumFractionDigits: 2 }).format((params.value));
  } else {
    return;
  }
}
