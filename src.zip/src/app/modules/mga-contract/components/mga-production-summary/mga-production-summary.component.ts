import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Utils } from 'src/app/modules/premium-bordereaux/utils';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaContractService } from '../../services/mga-contract.service';


@Component({
  selector: 'mga-production-summary',
  templateUrl: './mga-production-summary.component.html',
  styleUrls: ['./mga-production-summary.component.scss']
})
export class MgaProductionSummaryComponent implements OnInit {
  productionSummaryForm: UntypedFormGroup;
  mgaList: any;

  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;
  dataViewList: any = [];
  divisCode: any;
  bsConfig: Partial<BsDatepickerConfig> = new BsDatepickerConfig();
  flag: boolean = true;
  //Charts Starts
  mgaChart: any;
  mgaLossChart: any;
  lobChart: any;
  lobLossChart: any;
  binderContractChart: any;
  binderContractLossChart: any;
  basicOptions = {
    plugins: {
      legend: {
        labels: {
          color: '#000',
        },
      },
    },
    responsive: true,
    scales: {
      x: {
        ticks: {
          color: '#000',
        },
        grid: {
          color: 'rgba(255,255,255,0.3)',
        },
      },
      y: {
        ticks: {
          color: '#000',
        },
        grid: {
          color: '#ccc',
        },
      },
    },
  };
  mgaDataSets: any = [];
  mgaLossDataSets: any = [];

  lobDataSets: any = [];
  lobLossDataSets: any = [];

  binderContractDataSets: any = [];
  binderContractLossDataSets: any = [];
  //Charts Ends

  constructor(
    private fb: UntypedFormBuilder,
    private loaderService: LoaderService,
    private mgaService: MgaContractService,
    private toastService: ToastService,
    private session: SessionStorageService
  ) {
    this.defaultColDef = {
      resizable: true,
      enableRowGroup: true,
      sortable: true,
      filter: true
    };
  }

  ngOnInit() {
    this.bsConfig = Object.assign({}, { rangeInputFormat: 'DD/MM/YYYY', customTodayClass: 'custom-today-class' });
    this.mgaChart = {
      labels: [],
      datasets: [],
    };
    this.mgaLossChart = {
      labels: [],
      datasets: [],
    };
    this.lobChart = {
      labels: [],
      datasets: [],
    };
    this.lobLossChart = {
      labels: [],
      datasets: [],
    };
    this.binderContractChart = {
      labels: [],
      datasets: [],
    };
    this.binderContractLossChart = {
      labels: [],
      datasets: [],
    };
    this.createForm();
    this.columnDefsFn();
    this.getMgaCode();
    this.getContractList();
    this.initChartData();
    setTimeout(() => {
      this.getLobList();
    }, 1000);
  }

  columnDefsFn() {
    this.columnDefs = [
      {
        headerName: "MGA",
        headerTooltip: 'MGA',
        field: "mgaCode",
      },
      {
        headerName: "Contract",
        headerTooltip: 'Contract',
        field: "binderContract",
      },
      {
        headerName: "LOB",
        headerTooltip: "LOB",
        field: "lobCode",
        width: 250,
      },
      {
        headerName: "Gross Written Premium",
        headerTooltip: "Gross Written Premium",
        field: "premAmt",
        valueFormatter: Utils.currencyDecimalFormatter,
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Claims Incurred",
        headerTooltip: "Claims Incurred",
        field: "clmAmt",
        valueFormatter: Utils.currencyDecimalFormatter,
        headerClass: "grid-cell-centered",
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Loss Ratio (%)",
        headerTooltip: "Loss Ratio (%)",
        valueFormatter: Utils.currencyDecimalFormatter,
        field: "lossRatio",
        cellStyle: { textAlign: 'right' },
      }
    ];
  }
  createForm() {
    this.productionSummaryForm = this.fb.group({
      dateFm: [undefined, Validators.required],
      dateTo: [undefined, Validators.required],
      mga: [undefined],
      contract: [undefined],
      lob: [undefined],
    });
    // let date = new Date();
    this.getDate();
  }
  getDate() {
    var now = new Date();
    // let firstDay = new Date().setFullYear(now.getFullYear() - 1);
    var oneYr = new Date().setFullYear(now.getFullYear() - 1);
    var firstDay = new Date(oneYr).setDate(new Date(oneYr).getDate() + 1);

    this.productionSummaryForm.patchValue({
      dateFm: new Date(firstDay),
    });
    this.setContractPeriod(this.productionSummaryForm.get('dateFm').value, 'loading');
  }

  getMgaCode() {
    this.mgaService.getMGAlist().subscribe(resp => {
      this.mgaList = resp;
      this.mgaList = (this.mgaList as any[]).map(mga => {
        mga.displayText = mga.code + ' - ' + mga.description;
        return mga;
      });
      this.mgaList.unshift({ code: '', displayText: 'All' });
      this.productionSummaryForm.patchValue({ "mga": '' });
    })
  }

  contractList = [];
  getContractList() {
    this.mgaService.getContractList().subscribe(res => {
      this.contractList = res;
      this.contractList.unshift({ key: '', value: 'All' });
      this.productionSummaryForm.patchValue({ "contract": '' });
    }, error => {
    })
  }

  lobList = [];
  getLobList() {
    this.divisCode = this.session.get('divisionCode');
    this.mgaService.getLOBProductAppCode(this.divisCode).subscribe((res: any) => {
      this.lobList = res.lobProdTypeList;
      this.lobList.unshift({ key: '', value: 'All' });
      this.productionSummaryForm.patchValue({ "lob": '' });
    }, error => {
      console.log(error)
    })
  }

  callSearch() {
    if (this.flag) {//chart
      this.searchChartData();
    } else {//data
      this.searchTableData();
    }
  }
  // Filter data fetch //

  //Search chart data//

  initChartData() {

    this.resetData();
    this.callSearch();
  }
  setContractPeriod(value, evnt) {
    if (value) {
      const startDate = moment(value.getDate() + '/' + (value.getMonth() + 1) + '/' + value.getFullYear(), 'DD/MM/YYYY');
      const endDate = moment(startDate).add(1, 'year').add(-1, 'days');
      if (evnt == 'loading') {
        const data = {
          dateTo: endDate.format('DD/MM/YYYY'),
        };
        this.productionSummaryForm.patchValue(data);
      }
    }
  }
  // Reset Data 
  resetData() {
    this.dataViewList = [];
  }
  // Reset Data

  chartData: any;

  searchChartData() {

    if (this.productionSummaryForm.valid) {

      this.loaderService.isBusy = true;
      let data = this.productionSummaryForm.value;
      data.dateFm = (typeof (data.dateFm) == 'object') ? moment(data.dateFm, 'DD/MM/YYYY') : moment(data.dateFm, 'DD/MM/YYYY');
      data.dateTo = (typeof (data.dateTo) == 'object') ? moment(data.dateTo, 'DD/MM/YYYY') : moment(data.dateTo, 'DD/MM/YYYY');

      let dataToSend = {
        dateFm: (data.dateFm).format('DD-MM-YYYY'),
        dateTo: (data.dateTo).format('DD-MM-YYYY'),
        mgaCode: (data.mga) ? data.mga : "",
        binderContract: (data.contract) ? data.contract : "",
        lobCode: (data.lob) ? data.lob : "",
      };
      this.mgaService.getChartData(dataToSend).subscribe((result: any) => {
        this.loaderService.isBusy = false;
        this.chartData = result;
        this.calcMgaChart();
        this.calcLobChart();
        this.calcbinderContractChart();
      }, error => {
        this.toastService.error("Error while getting chart data!");
        this.loaderService.isBusy = false;
      });
    } else {
      this.validateAllFormFields(this.productionSummaryForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  //Search chart data //
  calcMgaChart() {
    let premAmt = [];
    let claimAmt = [];
    let lossRatio = [];
    this.mgaChart = {
      labels: [],
      datasets: [],
    };
    this.mgaLossChart = {
      labels: [],
      datasets: [],
    };
    this.lobChart = {
      labels: [],
      datasets: [],
    };
    this.lobLossChart = {
      labels: [],
      datasets: [],
    };
    this.binderContractChart = {
      labels: [],
      datasets: [],
    };
    this.binderContractLossChart = {
      labels: [],
      datasets: [],
    };
    this.chartData.mgaChart.forEach((value) => {
      this.mgaChart.labels.push(value.mgaCodeDesc);
      this.mgaLossChart.labels.push(value.mgaCodeDesc);
      premAmt.push(value.premAmt);
      claimAmt.push(value.clmAmt);
      lossRatio.push(value.lossRatio);
    });
    this.mgaDataSets = [
      {
        data: premAmt,
        label: 'Gross Written Premium',
        backgroundColor: '#FF8C1A',
      },
      { data: claimAmt, label: 'Claims Incurred', backgroundColor: '#008AE6' },
    ];
    this.mgaLossDataSets = [
      {
        data: lossRatio,
        label: 'Loss Ratio (%)',
        backgroundColor: 'rgba(182, 232, 239,0.3)',
        borderColor: '#3FA8BA',
      },
    ];
    this.mgaChart.datasets = this.mgaDataSets;
    this.mgaLossChart.datasets = this.mgaLossDataSets;
  }
  calcbinderContractChart() {
    let premAmt = [];
    let claimAmt = [];
    let lossRatio = [];
    this.chartData.binderContractChart.forEach((value) => {
      this.binderContractChart.labels.push(value.binderContract);
      this.binderContractLossChart.labels.push(value.binderContract);
      premAmt.push(value.premAmt);
      claimAmt.push(value.clmAmt);
      lossRatio.push(value.lossRatio);
    });
    this.binderContractDataSets = [
      {
        data: premAmt,
        label: 'Gross Written Premium',
        backgroundColor: '#FF8C1A',
      },
      { data: claimAmt, label: 'Claims Incurred', backgroundColor: '#008AE6' },
    ];
    this.binderContractLossDataSets = [
      {
        data: lossRatio,
        label: 'Loss Ratio (%)',
        backgroundColor: 'rgba(182, 232, 239,0.3)',
        borderColor: '#3FA8BA',
      },
    ];
    this.binderContractChart.datasets = this.binderContractDataSets;
    this.binderContractLossChart.datasets = this.binderContractLossDataSets;
  }
  calcLobChart() {
    let premAmt = [];
    let claimAmt = [];
    let lossRatio = [];
    this.chartData.lobChart.forEach((value) => {
      this.lobChart.labels.push(value.lobCodeDesc);
      this.lobLossChart.labels.push(value.lobCodeDesc);
      premAmt.push(value.premAmt);
      claimAmt.push(value.clmAmt);
      lossRatio.push(value.lossRatio);
    });
    this.lobDataSets = [
      {
        data: premAmt,
        label: 'Gross Written Premium',
        backgroundColor: '#FF8C1A',
      },
      { data: claimAmt, label: 'Claims Incurred', backgroundColor: '#008AE6' },
    ];
    this.lobLossDataSets = [
      {
        data: lossRatio,
        label: 'Loss Ratio (%)',
        backgroundColor: 'rgba(182, 232, 239,0.3)',
        borderColor: '#3FA8BA',
      },
    ];
    this.lobChart.datasets = this.lobDataSets;
    this.lobLossChart.datasets = this.lobLossDataSets;
  }
  // Search Table data //

  tableData = [];
  searchTableData() {

    if (this.productionSummaryForm.valid) {

      this.loaderService.isBusy = true;
      let data = this.productionSummaryForm.value;
      data.dateFm = (typeof (data.dateFm) == 'object') ? moment(data.dateFm, 'DD/MM/YYYY') : moment(data.dateFm, 'DD/MM/YYYY');
      data.dateTo = (typeof (data.dateTo) == 'object') ? moment(data.dateTo, 'DD/MM/YYYY') : moment(data.dateTo, 'DD/MM/YYYY');

      let dataToSend = {
        dateFm: (data.dateFm).format('DD-MM-YYYY'),
        dateTo: (data.dateTo).format('DD-MM-YYYY'),
        mgaCode: (data.mga) ? data.mga : "",
        binderContract: (data.contract) ? data.contract : "",
        lobCode: (data.lob) ? data.lob : "",
      };
      this.mgaService.getTableData(dataToSend).subscribe((result: any) => {
        this.loaderService.isBusy = false;
        this.tableData = result;
        this.dataViewList = result;
      }, error => {
        this.toastService.error("Error while getting table data!");
        this.loaderService.isBusy = false;
      });
    } else {
      this.validateAllFormFields(this.productionSummaryForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }

  // Search table data //

  reset() {
    this.getDate();
    this.productionSummaryForm.patchValue({
      contract: '',
      mga: '',
      lob: ''
    });
    this.initChartData();
  }
  onFlagChange(evnt) {
    this.flag = !evnt;
  }

  switchViewType(eve) {
    this.flag = eve.target.checked;
    //this.callSearch();
    this.initChartData();
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("dataViewTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    } else {
      this.gridOptions.api.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  agGridOptions() {
    this.context = { componentParent: this };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
