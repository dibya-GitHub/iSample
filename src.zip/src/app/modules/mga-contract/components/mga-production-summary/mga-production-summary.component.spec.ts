import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MgaProductionSummaryComponent } from './mga-production-summary.component';

describe('MgaProductionSummaryComponent', () => {
  let component: MgaProductionSummaryComponent;
  let fixture: ComponentFixture<MgaProductionSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaProductionSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MgaProductionSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
