import { Component, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Utils } from 'src/app/modules/premium-bordereaux/utils';
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { PremiumBordereauxService } from './../../../premium-bordereaux/services/premium-bordereaux.service';
@Component({
  selector: 'inward-mga-view-accounting',
  templateUrl: './mga-view-accounting.component.html',
  styleUrls: ['./mga-view-accounting.component.scss']
})
export class MgaViewAccountingComponent implements OnInit {


  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;
  baseCurrency
  accEntryList: any = [];
  headerData: any;
  docNo;
  batchId;
  tranNo;
  selectedArray = [];
  binder: string;
  mailReplyForm: UntypedFormGroup;
  // editorConfig: AngularEditorConfig;
  appStatus;
  summaryHeaderForm: UntypedFormGroup
  hideTAColumn: boolean = false;
  prefixWord: string = '';
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private loaderService: LoaderService,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private session: SessionStorageService,
    private toastService: ToastService,
    private authService: AuthService,
    private PremiumBordereauxService: PremiumBordereauxService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.baseCurrency = this.session.get('baseCurrency');
    this.activatedRoute.queryParams.subscribe(params => {
      this.batchId = params['batchId'];
      this.binder = params['binder'];
      this.appStatus = params['status'];
      
    });
    this.createSummaryHeaderForm();
    if (this.appStatus == 'R' && this.binder === "BIND_PRM") {
      this.docTypeDropdown('BIND_PRM')
      this.summaryHeaderForm.patchValue({ transType: 'BIND_PRM_REV' })
      this.binder = 'BIND_PRM_REV';
    } else if (this.appStatus == 'R' && this.binder === "BIND_CLM") {
      this.docTypeDropdown('BIND_CLM')
      this.summaryHeaderForm.patchValue({ transType: 'BIND_CLM_REV' })
      this.binder = 'BIND_CLM_REV';
    }
    else if (this.appStatus == 'R' && this.binder === "BIND_TAM") {
      this.docTypeDropdown('BIND_TAM')
      this.summaryHeaderForm.patchValue({ transType: 'BIND_TAM_REV' })
      this.binder = 'BIND_TAM_REV';
    }
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.getAllData();
    this.createMailReplyModal();
  }
  transactionType: any
  showTrantypeDropdown: boolean = true;
  tranType: '';
  getAllData() {
    let type = '';
    if (this.binder === "BIND_PRM" || this.binder === 'BIND_PRM_REV' || this.binder === "BIND_CLM" || this.binder === 'BIND_CLM_REV') {
      type = 'premClaimSummBdx';
      this.prefixWord = 'B - ';
    } else if (this.binder === "BIND_TAM" || this.binder === 'BIND_TAM_REV' || this.binder === "QS_ACNT") {
      type = 'tamanual';
      this.prefixWord = 'M - ';
    }
    this.PremiumBordereauxService.viewAccoutingDetails(this.batchId, this.binder, type).subscribe(res => {
      this.loaderService.isBusy = false;
      this.accEntryList = res;
      this.headerData = res[0];
      if (this.headerData && this.headerData.adCrDt) {
        this.headerData.adCrDt = moment(this.headerData.adCrDt).format('DD/MM/YYYY');
      } else if (this.headerData) {
        this.headerData.adCrDt = undefined;
      }
      if (this.binder === "BIND_PRM" || this.binder === 'BIND_PRM_REV') {
        this.transactionType = "Binder Premium"
        if (this.appStatus == 'R') {
          this.showTrantypeDropdown = true;
          this.docTypeDropdown("BIND_PRM");
        } else {
          this.showTrantypeDropdown = false;
        }

      } else if (this.binder === "BIND_CLM" || this.binder === 'BIND_CLM_REV') {
        this.transactionType = "Binder Claims"
        if (this.appStatus == 'R') {
          this.showTrantypeDropdown = true;
          this.docTypeDropdown("BIND_CLM");
        } else {
          this.showTrantypeDropdown = false;
        }
      } else if (this.binder === "BIND_TAM" || this.binder === 'BIND_TAM_REV') {
        this.showTrantypeDropdown = false;
        this.transactionType = "Technical Accounting"
        this.hideTAColumn = true;
        if (this.appStatus == 'R') {
          this.showTrantypeDropdown = true;
          this.docTypeDropdown("BIND_TAM");
        } else {
          this.showTrantypeDropdown = false;
        }

      }
      this.columnDefsFn();
      this.loaderService.isBusy = false;
    }, error => {
      this.columnDefsFn();
      this.loaderService.isBusy = false;
      this.toastService.error(error.message);
    })
  }
  columnDefsFn() {
    this.columnDefs = [
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "adDivnCodeDesc",
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.adCustCodeDesc;
          }
        },
      },

      {
        headerName: "Doc Date",
        headerTooltip: "Doc Date",
        field: "adDocDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.adDocDt) {
            return moment(params.data.adDocDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        sortable: false,
        filter: true,
        enableRowGroup: false,
      },
      {
        headerName: "Doc No",
        headerTooltip: "Doc No",
        field: "adDocNo",
        valueGetter: function (params) {
          if (params.data && params.data.adTranCode && params.data.adDocNo) {
            return params.data.adTranCode + ' - ' + params.data.adDocNo;
          } else {
            return "";
          }
        },
      },
      {
        headerName: "Sr No",
        headerTooltip: "Sr No",
        field: "adFlex08",
        valueGetter: function (params) {
          if (params.data && params.data.adFlex08) {
            return params.data.adFlex08;
          } else {
            return "";
          }
        },
        hide: this.hideTAColumn
      },
      {
        headerName: "Transaction Id",
        headerTooltip: "Transaction Id",
        field: "adTransId",
        tooltipField: 'adTransId',
        valueGetter: function (params) {
          if (params.data && params.data.adTransId && params.data.adDocType) {
            let prefixWord = '';
            if (params.data.adDocType === "BIND_PRM" || params.data.adDocType === 'BIND_PRM_REV' || params.data.adDocType === "BIND_CLM" || params.data.adDocType === 'BIND_CLM_REV') {
              prefixWord = 'B - ';
            } else if (params.data.adDocType === "BIND_TAM" || params.data.adDocType === 'BIND_TAM_REV' || params.data.adDocType === "QS_ACNT") {
              prefixWord = 'M - ';
            }
            return prefixWord + '' + params.data.adTransId;
          } else {
            return "";
          }
        },
      },

      {
        headerName: "Narration",
        headerTooltip: "Narration",
        field: "adNarration",
        tooltipField: 'adNarration'
      },
      {
        headerName: "Currency",
        headerTooltip: "Currency",
        field: "adCurrCode",
      },
      {
        headerName: "Dr / Cr",
        headerTooltip: "Dr / Cr",
        field: "adDrcrFlag",
        valueGetter: function (params) {
          if (params.data && params.data.adDrcrFlag) {
            if (params.data.adDrcrFlag === 'D') {
              return 'Dr';
            } else if (params.data.adDrcrFlag === 'C') {
              return 'Cr';
            }
          }
        },
      },
      {
        headerName: "Amnt in Acnt Curr (" + this.headerData.adCurrCode + ")",
        headerTooltip: "Amnt in Acnt Curr (" + this.headerData.adCurrCode + ")",
        field: "adAmtFc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: Utils.currencyDecimalFormatter,
      },
      {
        headerName: "Amnt in Funct Curr (" + this.baseCurrency + ")",
        headerTooltip: "Amnt in Funct Curr (" + this.baseCurrency + ")",
        field: "adAmtLc1",
        cellStyle: { textAlign: 'right' },
        valueFormatter: Utils.currencyDecimalFormatter,
      },
      {
        headerName: "Main Account",
        headerTooltip: "Main Account",
        field: "adMainAcntCodeDesc",
      },

      {
        headerName: "Sub Account",
        headerTooltip: "Sub Account",
        field: "adSubAcntCodeDesc",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Year of Accounts",
        headerTooltip: "Year of Accounts",
        field: "adFlex02",
        width: 250,
      },
      {
        headerName: "Product",
        headerTooltip: 'Product',
        field: "adProductDesc",
        tooltipField: 'adProductDesc'
      },
    ];
  }
  back() {
    if (this.transactionType == 'Binder Premium') {
      this.router.navigate(['/premium-bordereaux-upload'], { queryParams: { 'isView': true, title: 'viewAccBack', batchId: this.batchId } });
    } else if (this.transactionType == 'Binder Claims') {
      this.router.navigate(['/claim-bordereaux-upload'], { queryParams: { title: 'claimBack', batchId: this.batchId } });
    } else if (this.transactionType == 'Technical Accounting') {
      let obj = { 'action': 'edit', 'id': this.batchId, 'status': this.appStatus };
      this.router.navigate(['/mga-ta-accounting-create'], { queryParams: obj, skipLocationChange: false });
    }
  }
  paramList: any
  autoSelect: boolean = false;
  print(content) {
    this.loaderService.isBusy = true;
    this.openMailTemp = false;
    let obj = {
      compCode: this.session.get('companyCode'),
      instId: this.authService.getInstanceCode(),
      divn: this.session.get('userDivnCode'),
      tranType: ''
    }
    if (this.binder === "BIND_PRM" || this.binder === 'BIND_PRM_REV') {
      obj.tranType = 'BT_DCP_NOTE';
    } else if (this.binder === 'BIND_CLM' || this.binder === 'BIND_CLM_REV') {
      obj.tranType = 'BT_DCC_NOTE';
    } else if (this.binder == 'BIND_TAM' || this.binder === 'BIND_TAM_REV') {
      obj.tranType = 'TA_DC_NOTE';
    }
    this.PremiumBordereauxService.fetchPremBoardReportParamList(obj).subscribe(resp => {
      this.paramList = resp.reportParamList;
      if (resp.reportParamList.length == 1) {
        this.autoSelect = true;
      }
      this.loaderService.isBusy = false;
    })
    this.open(content, 'modal-lg');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
  }
  docTypeList: any;
  docTypeDropdown(data) {
    this.PremiumBordereauxService.getAccountTypeList(data).subscribe(res => {
      this.docTypeList = res["acntDocType"];
      this.docTypeList.unshift({ key: 'All', value: "All" });
    })

  }

  pushSelectedDocs(event, value) {
    if (event.target.checked == true) {
      this.selectedArray.push(value);
    } else {
      var index = this.selectedArray.indexOf(value);
      this.selectedArray.splice(index, 1)
    }
  }
  printDocument() {
    this.openMailTemp = false;
    if (this.selectedArray.length == 0) {
      this.toastService.warning('Please Select atleast one checkBox');
      return false;
    }
    if (this.paramList[0].rmRepId == this.selectedArray[0]) {
      let selectedRmtype = this.paramList[0].rmType;
      let amendNo
      if (this.binder == 'BIND_TAM') {
        amendNo = 'TA_DC_NOTE';
      } else {
        amendNo = '';
      }
      var params = {
        refNo: this.batchId,
        amendNo: amendNo,
        compCode: this.session.get('companyCode'),
        repId: this.selectedArray[0],
        seqNo: '',
        docType: selectedRmtype
      }
      this.PremiumBordereauxService.fetchPremBoardReportUrl(params)
        .subscribe(result => {
          var url = result.resultUrl;
          var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
          width=0,height=0,left=-1000,top=-1000`;
          var winRef = window.open(url, 'Reports', param);

        });
    }

    /*  }
   } */
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("accEntryListTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      let columnKeys = ['adDivnCodeDesc', 'adDocDt', 'adDocNo', 'adFlex08', 'adTransId', 'adNarration', 'adCurrCode', 'adDrcrFlag', 'adAmtLc1', 'adAmtFc', 'adMainAcntCodeDesc', 'adSubAcntCodeDesc', 'adFlex02', 'adProductDesc'];
      if (this.hideTAColumn) {
        const index = columnKeys.indexOf('adFlex08');
        if (index > -1) {
          columnKeys.splice(index, 1);
        }
      }
      console.log(columnKeys);
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: this.binder + '_viewAccounting.xlsx',
        skipHeader: false,
        sheetName: 'View Accounting',
        columnKeys: columnKeys,
        processCellCallback: (params) => {
          if (params.column.colId == "adDocDt") {
            if (params.value == null || params.value == undefined) {
              return '';
            } else {
              return params.value;
            }
          } else if (params.column.colId == 'adDrcrFlag') {
            if (params.value == 'D')
              return 'Dr';
            else if (params.value == 'C')
              return 'Cr'
            else
              return params.value;
          } else {
            return params.value;
          }
        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  agGridOptions() {
    this.context = { componentParent: this };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  createMailReplyModal() {
    this.mailReplyForm = this.fb.group({
      fromEmail: '',
      toEmail: ['', [Validators.required, Validators.email, this.commaSepEmail]],
      ccEmail: ['', [this.commaSepCCEmail, Validators.email]],
      subject: ['', Validators.required],
      emailBody: [undefined, Validators.required],
      jasperUrlPath: "",
      reportFileName: ''
    });
  }
  createSummaryHeaderForm() {
    this.summaryHeaderForm = this.fb.group({
      transType: undefined
    })
  }
  commaSepEmail = (control: AbstractControl): { [key: string]: any } | null => {
    if (control.value != null) {
      const emails = control.value.split(',').map(e => e.trim());
      const forbidden = emails.some(email => Validators.email(new UntypedFormControl(email)));
      return forbidden ? { 'toEmail': { value: control.value } } : null;
    }
  };
  commaSepCCEmail = (control: AbstractControl): { [key: string]: any } | null => {
    if (control.value != null) {
      const emails = control.value.split(',').map(e => e.trim());
      const forbidden = emails.some(email => Validators.email(new UntypedFormControl(email)));
      return forbidden ? { 'ccEmail': { value: control.value } } : null;
    }
  };
  // MAil Template

  openMailTemp: boolean = false;
  attachedFileName: any;
  openReplyModal() {
    this.loaderService.isBusy = true;
    this.mailReplyForm.reset();
    let fromEmail = "anoudadmin@qicgroup.com.qa";
    let subject;
    let message = "Dear ,<br/><br/>Please find attached document<br/><br/>Regards,<br/><br/><br/><br/>";
    if (this.binder === "BIND_PRM" || this.binder === 'BIND_PRM_REV') {
      subject = "Premium";
    } else if (this.binder === 'BIND_CLM' || this.binder === 'BIND_CLM_REV') {
      subject = "Claims";
    } else if (this.binder == 'BIND_TAM') {
      subject = "Technical Accounting";
    }
    //this.mailReplyForm.patchValue({  fromEmail : fromEmail , emailBody: message , subject: subject}); 
    if (this.selectedArray.length == 0) {
      this.toastService.warning('Please Select atleast one checkBox');
      this.loaderService.isBusy = false;
      return false;
    } else {
      this.openMailTemp = true;
    }
    if (this.paramList[0].rmRepId == this.selectedArray[0]) {
      let selectedRmtype = this.paramList[0].rmType;
      var params = {
        refNo: this.batchId,
        amendNo: '',
        compCode: this.session.get('companyCode'),
        repId: this.selectedArray[0],
        seqNo: '',
        docType: selectedRmtype
      }
      this.PremiumBordereauxService.fetchPremBoardReportUrl(params)
        .subscribe(result => {
          this.mailReplyForm.patchValue({
            jasperUrlPath: result.resultUrl,
            reportFileName: subject + " (Batch ID - " + this.batchId + ") Debit_Credit Note",
            fromEmail: fromEmail, emailBody: message, subject: subject + " Batch ID - " + this.batchId + ""
          });
          this.loaderService.isBusy = false;
        });
      this.attachedFileName = subject + " (Batch ID - " + this.batchId + ") Debit_Credit Note.pdf"
    }
  }
  url: any;
  sendEmail() {
    this.loaderService.isBusy = true;
    if (this.mailReplyForm.valid) {
      let data = this.mailReplyForm.getRawValue();
      this.PremiumBordereauxService.sendEmail(data).subscribe((resp) => {
        if (resp["messageType"] && resp["messageType"] == 'S') {
          document.getElementById('btnClose').click();
          this.toastService.success(resp["message"]);
        } else {
          this.toastService.error(resp["message"]);
        }
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    } else {
      Utils.validateAllFormFields(this.mailReplyForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }

  directReverseGridLoad(event) {
    this.loaderService.isBusy = true;
    let type = '';
    if (this.binder === "BIND_PRM" || this.binder === 'BIND_PRM_REV' || this.binder === "BIND_CLM" || this.binder === 'BIND_CLM_REV') {
      type = 'premClaimSummBdx'
    } else if (this.binder === "BIND_TAM" || this.binder === 'BIND_TAM_REV' || this.binder === "QS_ACNT") {
      type = 'tamanual';
    }
    this.PremiumBordereauxService.viewAccoutingDetails(this.batchId, event.value, type).subscribe(res => {
      this.accEntryList = res;
      this.headerData = res[0];
      if (this.headerData && this.headerData.adCrDt) {
        this.headerData.adCrDt = moment(this.headerData.adCrDt).format('DD/MM/YYYY');
      } else if (this.headerData) {
        this.headerData.adCrDt = undefined;
      }
      this.loaderService.isBusy = false;
    })
  }
}
