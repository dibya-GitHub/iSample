import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-view-accounting/mga-view-accounting.component.spec.ts
import { MgaViewAccountingComponent } from './mga-view-accounting.component';

describe('MgaViewAccountingComponent', () => {
  let component: MgaViewAccountingComponent;
  let fixture: ComponentFixture<MgaViewAccountingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaViewAccountingComponent ]
=======
import { EditAdjustPremiumComponent } from './edit-adjust-premium.component';

describe('EditAdjustPremiumComponent', () => {
  let component: EditAdjustPremiumComponent;
  let fixture: ComponentFixture<EditAdjustPremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditAdjustPremiumComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/edit-adjust-premium/edit-adjust-premium.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-view-accounting/mga-view-accounting.component.spec.ts
    fixture = TestBed.createComponent(MgaViewAccountingComponent);
=======
    fixture = TestBed.createComponent(EditAdjustPremiumComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/edit-adjust-premium/edit-adjust-premium.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
