import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { LoaderService } from 'src/app/services/loader.service';
import { RadiorenderComponent2 } from './../radiorender/radiorender2.component';

@Component({
  selector: 'mga-adjustment-levy',
  templateUrl: './mga-adjustment-levy.component.html',
  styleUrls: ['./mga-adjustment-levy.component.scss']
})
export class MgaAdjustmentLevyComponent implements OnInit {

  adjLevyForm: UntypedFormGroup;
  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  public columnDefs;
  public bottomColumns;
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;
  levyList: any;

  public columnDefsCoins;
  constructor(
    private fb: UntypedFormBuilder,
    private loaderService: LoaderService,

  ) { }

  ngOnInit() {
    this.createAdjLevyForm();
    this.columnDefs = [
      {
        headerName: "Select",
        field: 'binderCoinsPK.bcSrNo',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
        width: 100,
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },
      {
        headerName: "Batch ID",
        headerTooltip: "Batch ID",
        field: "alBatchId",
        width: 150,
      },
      {
        headerName: "Batch Date",
        headerTooltip: "Batch Date",
        field: "alBatchDate",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Company",
        headerTooltip: "Company",
        field: "alCompany",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Product",
        headerTooltip: "Product",
        field: "alProduct",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Currency",
        headerTooltip: "Currency",
        field: "alCurrency",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Gross Premium",
        headerTooltip: "Gross Premium",
        field: "alGrossPrem",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Provisional Amount",
        headerTooltip: "Provisional Amount",
        field: "alProvAmnt",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Actual Amount",
        headerTooltip: "Actual Amount",
        field: "alActualAmnt",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Adjustment Amount",
        headerTooltip: "Adjustment Amount",
        field: "alAdjAmnt",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
    ];

    this.columnDefsCoins = [
      {
        headerName: "Select",
        field: 'binderCoinsPK.bcSrNo',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
        width: 100,
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },
      {
        headerName: "Coinsurer",
        headerTooltip: "Coinsurer",
        field: "alCoinsurer",
        width: 350,
      },
      {
        headerName: "Leader",
        headerTooltip: "Leader",
        field: "alLeader",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Share %",
        headerTooltip: "Share %",
        field: "alSharePerc",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Gross Premium",
        headerTooltip: "Gross Premium",
        field: "alGrossPrem",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Provisional Amount",
        headerTooltip: "Provisional Amount",
        field: "alProvAmnt",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Actual Amount",
        headerTooltip: "Actual Amount",
        field: "alActualAmnt",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
      {
        headerName: "Adjustment Amount",
        headerTooltip: "Adjustment Amount",
        field: "alAdjAmnt",
        width: 100,
        cellStyle: { textAlign: 'center' },
      },
    ];
  }
  createAdjLevyForm() {
    this.adjLevyForm = this.fb.group({
      selectLevy: [undefined, Validators.required],
      mgaContractId: [undefined, Validators.required],
      classofBusiness: [undefined, Validators.required],
      provisionalRate: [undefined, Validators.required],
      yearOfAccounts: [undefined, Validators.required],
      products: [undefined, Validators.required],
      actualRate: [undefined, Validators.required],
    });
  }

  getAllLobCoinsuranceByRefId() {
    this.loaderService.isBusy = true;
    // this.mgaService.getCoinsurancebyRefNoSrNo().subscribe(resp => {
    //   this.levyList = resp;
    //   this.loaderService.isBusy = false;
    // }, error => {
    //   this.toastService.error(error);
    //   this.loaderService.isBusy = false;
    // });
  }
  process() {

  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent2
    };
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("mgaLevyGrid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      console.log(actionType);
    }
  }

}
