import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-adjustment-levy/mga-adjustment-levy.component.spec.ts
import { MgaAdjustmentLevyComponent } from './mga-adjustment-levy.component';

describe('MgaAdjustmentLevyComponent', () => {
  let component: MgaAdjustmentLevyComponent;
  let fixture: ComponentFixture<MgaAdjustmentLevyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaAdjustmentLevyComponent ]
=======
import { AadTotalComponent } from './aad-total.component';

describe('AadTotalComponent', () => {
  let component: AadTotalComponent;
  let fixture: ComponentFixture<AadTotalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AadTotalComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/aad-total/aad-total.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-adjustment-levy/mga-adjustment-levy.component.spec.ts
    fixture = TestBed.createComponent(MgaAdjustmentLevyComponent);
=======
    fixture = TestBed.createComponent(AadTotalComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/aad-total/aad-total.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
