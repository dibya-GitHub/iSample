import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-business-rules/mga-business-rules.component.spec.ts
import { MgaBusinessRulesComponent } from './mga-business-rules.component';

describe('MgaBusinessRulesComponent', () => {
  let component: MgaBusinessRulesComponent;
  let fixture: ComponentFixture<MgaBusinessRulesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MgaBusinessRulesComponent ]
=======
import { ReinsurePremiumComponent } from './reinsure-premium.component';

describe('ReinsurePremiumComponent', () => {
  let component: ReinsurePremiumComponent;
  let fixture: ComponentFixture<ReinsurePremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReinsurePremiumComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/reinsure-premium/reinsure-premium.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/mga-contract/components/mga-business-rules/mga-business-rules.component.spec.ts
    fixture = TestBed.createComponent(MgaBusinessRulesComponent);
=======
    fixture = TestBed.createComponent(ReinsurePremiumComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/reinsure-premium/reinsure-premium.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
