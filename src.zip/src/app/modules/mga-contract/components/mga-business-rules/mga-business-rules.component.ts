import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as _ from 'lodash';
import * as moment from 'moment';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MgaContractService } from './../../services/mga-contract.service';
import { MgaUtils } from './../mga-utils';

@Component({
  selector: 'mga-business-rules',
  templateUrl: './mga-business-rules.component.html',
  styleUrls: ['./mga-business-rules.component.scss']
})
export class MgaBusinessRulesComponent implements OnInit {

  mgaBussinessRulesForm: UntypedFormGroup;
  mgaDiscountRulesForm: UntypedFormGroup;
  lob_BRules_PremiumListForm: UntypedFormGroup;
  lob_BRules_DiscountListForm: UntypedFormGroup;
  bRulesList: any = [];
  userId: string;

  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() amendSrNo: string;

  @Input() action: string;
  @Input() seqNo: number;
  @Input() contractType: string;
  @Input() status: string;
  @Input() lobSrNo: number;
  @Input() passedData: any;
  @Input() lobInfo: any;

  @ViewChild('confirmModal') confirmModal: ElementRef;
  severityList: any;
  ruleTypeList: any;
  @ViewChild('ruleContent') ruleContent: ElementRef;
  discountTable: boolean = false;
  premiumTable: boolean = false;
  discountListData: any;
  premiumListData: any;
  items_premium: UntypedFormArray;
  items_discount: UntypedFormArray;

  modalRef: BsModalRef;
  modalRef1: BsModalRef;

  @ViewChild('confirmDialog') confirmDialog: ElementRef;
  @ViewChild('errorModal') errorModal: ElementRef;

  severity: any;
  deleteIndex: any;
  index: any;
  formName: any;
  minDate: any;
  maxDate: any;
  disableAddrow_premium: boolean = false;
  disableAddrow_discount: boolean = false;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private mgaService: MgaContractService,
    private modalService: BsModalService,

  ) {
    this.userId = this.session.get('userId');
  }

  ngOnInit() {
    this.minDate = new Date(this.passedData.biStartDt);
    this.maxDate = new Date(this.passedData.biEndDt);
    this.createRulesForm();
  }
  createRulesForm() {
    this.mgaBussinessRulesForm = this.fb.group({
      brSeverity: [undefined, Validators.required],
    })
    this.mgaDiscountRulesForm = this.fb.group({
      brSeverity: [undefined, Validators.required],
    })
    this.getRuleTypeDropDown();
    this.getSeverityDropdown();
  }
  createPremiumTable(typeId) {
    this.lob_BRules_PremiumListForm = this.fb.group({
      brEffFmDt: [undefined, Validators.required],
      brEffToDt: [undefined, Validators.required],
      brMaxRate: [undefined, Validators.required],
      brMinRate: [undefined, Validators.required],
      brSeverity: [undefined],
      brStatus: [undefined],
      brType: typeId,
      items_premium: this.fb.array([])
    })
    this.getPremiumBusinessRules(this.lob_BRules_PremiumListForm.get('brType').value);
    this.getAllBussinessRulesByRefId(this.lob_BRules_PremiumListForm.get('brType').value)
  }
  createDiscountTable(typeId) {

    this.lob_BRules_DiscountListForm = this.fb.group({
      brEffFmDt: [undefined, Validators.required],
      brEffToDt: [undefined, Validators.required],
      brMaxRate: [undefined, Validators.required],
      brMinRate: [undefined, Validators.required],
      brSeverity: [undefined],
      brStatus: [undefined],
      brType: typeId,
      items_discount: this.fb.array([])
    })
    this.getDiscountBusinessRules(this.lob_BRules_DiscountListForm.get('brType').value);
    this.getAllBussinessRulesByRefId(this.lob_BRules_DiscountListForm.get('brType').value)
  }
  createItem_premium(date?: any, endDate?: any): UntypedFormGroup {
    return this.fb.group({
      brEffFmDt: [date, Validators.required],
      brEffToDt: [endDate],
      brMinRate: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      brMaxRate: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      brSeverity: [''],
      brStatus: [''],
      brType: '04',
      srnoId: undefined,
      edited: false,
    }, {
      validator: [this.graterValidator("brMinRate", "brMaxRate"), this.dateValidators("brEffFmDt", "brEffToDt")]
    });
  }
  createItem_discount(date?: any, endDate?: any): UntypedFormGroup {
    return this.fb.group({
      brEffFmDt: [date, Validators.required],
      brEffToDt: [endDate],
      brMinRate: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      brMaxRate: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      brSeverity: [''],
      brStatus: [''],
      brType: '05',
      srnoId: undefined,
      edited: false,
    }, {
      validator: [this.graterValidator("brMinRate", "brMaxRate"), this.dateValidators("brEffFmDt", "brEffToDt")]
    });
  }
  addItem_premium(): void {
    this.items_premium = this.lob_BRules_PremiumListForm.get(
      "items_premium"
    ) as UntypedFormArray;
    if (_.size(this.items_premium) > 0) {
      var size = _.size(this.items_premium) - 1;
      let date = new Date(
        moment(this.items_premium.value[size].brEffToDt, "DD-MM-YYYY").toDate()
      );
      date.setDate(date.getDate() + 1);
      this.items_premium.push(this.createItem_premium(date));
      setTimeout(() => {
        for (let i = 0; i < this.items_premium.value.length; i++) {
          if (this.items_premium.value[i].edited == false) {
            this.disableAddrow_premium = true;
          } else {
            this.disableAddrow_premium = false;
          }
        }
      }, 100);
    } else {
      this.items_premium.push(this.createItem_premium(this.minDate, this.maxDate));
      setTimeout(() => {
        for (let i = 0; i < this.items_premium.value.length; i++) {
          if (this.items_premium.value[i].edited == false) {
            this.disableAddrow_premium = true;
          } else {
            this.disableAddrow_premium = false;
          }
        }
      }, 100);
    }
  }
  addItem_discount(): void {
    this.items_discount = this.lob_BRules_DiscountListForm.get(
      "items_discount"
    ) as UntypedFormArray;
    if (_.size(this.items_discount) > 0) {
      var size = _.size(this.items_discount) - 1;
      let date = new Date(
        moment(this.items_discount.value[size].brEffToDt, "DD-MM-YYYY").toDate()
      );
      date.setDate(date.getDate() + 1);
      this.items_discount.push(this.createItem_discount(date));
      setTimeout(() => {
        for (let i = 0; i < this.items_discount.value.length; i++) {
          if (this.items_discount.value[i].edited == false) {
            this.disableAddrow_discount = true;
          } else {
            this.disableAddrow_discount = false;
          }
        }
      }, 100);
    } else {
      this.items_discount.push(this.createItem_discount(this.minDate, this.maxDate));
      setTimeout(() => {
        for (let i = 0; i < this.items_discount.value.length; i++) {
          if (this.items_discount.value[i].edited == false) {
            this.disableAddrow_discount = true;
          } else {
            this.disableAddrow_discount = false;
          }
        }
      }, 100);
    }

  }
  getAllBussinessRulesByRefId(typeId, action?: string) {
    this.loaderService.isBusy = true;
    this.mgaService.getBussinessRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, typeId).subscribe(resp => {
      this.bRulesList = resp;
      if (this.bRulesList) {
        for (let i = 0; i < this.bRulesList.length; i++) {
          this.bRulesList[i].edited = true;
          this.bRulesList[i].brEffFmDt = moment(this.bRulesList[i].brEffFmDt).format('DD-MM-YYYY HH:mm');
          this.bRulesList[i].brEffToDt = moment(this.bRulesList[i].brEffToDt).format('DD-MM-YYYY HH:mm');
          if (typeId == '04') {
            if (action != 'save') {
              this.addItem_premium();
            }
            (this.lob_BRules_PremiumListForm.get('items_premium') as UntypedFormArray)
              .at(i)
              .get('srnoId').setValue(this.bRulesList[i].mBinderRulesPK.brSrNo, { emitEvent: true });

            // setTimeout(() => {
            //   this.mgaBussinessRulesForm.get('brSeverity').setValue(this.bRulesList[i].brSeverity, { emitEvent: true });
            // }, 500);

            if (this.bRulesList.length != 0) {
              //   let preSeverity = this.bRulesList[this.bRulesList.length - 1].brSeverity;
              this.mgaBussinessRulesForm.get("brSeverity").setValue(this.bRulesList[0].brSeverity, { emitEvent: true })
            }
            this.lob_BRules_PremiumListForm.patchValue({
              items_premium: this.bRulesList
            })

          } else {
            if (action != 'save') {
              this.addItem_discount();
            }
            (this.lob_BRules_DiscountListForm.get('items_discount') as UntypedFormArray)
              .at(i)
              .get('srnoId').setValue(this.bRulesList[i].mBinderRulesPK.brSrNo, { emitEvent: true });
            // setTimeout(() => {
            //   this.mgaBussinessRulesForm.get('brSeverity').setValue(this.bRulesList[i].brSeverity, { emitEvent: true });
            // }, 500);
            // if (this.discountListData.length >= 1) {
            //   let sevValue = this.discountListData[this.discountListData.length - 1].brSeverity
            //   this.mgaDiscountRulesForm.get('brSeverity').setValue(sevValue)
            // }

            this.lob_BRules_DiscountListForm.patchValue({
              items_discount: this.bRulesList
            })
          }
        }
      }

    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getRuleTypeDropDown() {
    this.mgaService.getRuleTypeDropDown().subscribe((resp: any) => {
      this.ruleTypeList = resp.lobListApplDept;
      this.createPremiumTable('04');
      this.createDiscountTable('05');

    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getSeverityDropdown() {

    this.mgaService.getSeverityTypeDropdown().subscribe(resp => {
      this.severityList = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  onValueChange(date: Date, i): void {
    const expriyDate = new Date(date);
    expriyDate.setDate(expriyDate.getDate() + 1);
    if (_.size(this.lob_BRules_PremiumListForm.get("items_premium").value) > 1) {
      (this.lob_BRules_PremiumListForm.get("items_premium") as UntypedFormArray).at(i + 1).get("brEffFmDt").setValue(expriyDate);
    }
  }
  toDate: any;
  saveForm(item, action, formName) {
    this.loaderService.isBusy = true;
    if (formName == 'premium') {
      if (this.items_premium.valid) {
        let lobBusinessData = item.value;
        let brSeverity = this.mgaBussinessRulesForm.get('brSeverity').value;
        // let brEffFmDate = moment(item.value.brEffFmDt, "DD-MM-YYYY").format('YYYY-MM-DD');
        // var size = _.size(this.items_premium) - 2;
        //let brEffToDate =  moment(item.value.brEffToDt, "DD-MM-YYYY").format('YYYY-MM-DD');
        // if(_.size(this.items_premium) > 1){
        //   this.toDate = moment(this.items_premium.value[size].brEffToDt, "DD-MM-YYYY").format('YYYY-MM-DD');
        // }     

        // if(_.size(this.items_premium) >= 1) {
        //   if (new Date(brEffFmDate) <= new Date( this.toDate)){
        //     this.toastService.warning("Effective From Date Should be Greater than Previous Effective To Date");
        //       this.loaderService.isBusy = false;
        //       return false;
        //   }
        // }
        if (action == 'save') {
          if (brSeverity == "" || brSeverity == null) {
            this.toastService.warning("Choose Severity");
            this.loaderService.isBusy = false;
          } else {
            let obj = {
              binderLobBusRulesPK: {
                brAmendNo: this.amendNo,
                brRefNo: this.refNo,
                brSeqNo: this.seqNo,
                brProdSrNo: this.lobSrNo
              },
              brCrDt: new Date(),
              brCrUid: this.userId,
              brUpdDt: new Date(),
              brUpdUid: this.userId,
              brStatus: 'P',
              brSeverity: brSeverity,
              brEffFmDt: moment(item.value.brEffFmDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
              brEffToDt: moment(item.value.brEffToDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
            };

            Object.assign(lobBusinessData, obj);
            this.mgaService.saveBussinessRules(lobBusinessData).subscribe((resp) => {
              if (resp.messageType == 'S') {
                this.toastService.success('Successfully Saved');
                this.getAllBussinessRulesByRefId('04', 'save');
                this.loaderService.isBusy = false;
                this.disableAddrow_premium = false;
              } else if (resp.messageType == 'U') {
                this.loaderService.isBusy = false;
                this.toastService.success(resp.message);
              } else {
                this.loaderService.isBusy = false;
                this.toastService.error(resp.message);
              }
            }, error => {
              if (error instanceof HttpErrorResponse) {
                if (error.error instanceof ErrorEvent) {
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in upload!");
                } else {
                  switch (error.status) {
                    case 400:
                      this.loaderService.isBusy = false;
                      this.showErrorDialogBox(error.error.message);
                      this.decline();
                      break;
                    default:
                      this.loaderService.isBusy = false;
                      this.toastService.error("Error in upload!");
                      break;
                  }
                }
              } else {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              }
            })
          }
        } else {
          let lobBusinessData = item.value;
          let obj = {
            binderLobBusRulesPK: {
              brAmendNo: this.amendNo,
              brRefNo: this.refNo,
              brSeqNo: this.seqNo,
              brProdSrNo: this.lobSrNo,
              brSrNo: lobBusinessData.srnoId,
            },
            brSeverity: brSeverity,
            brUpdDt: new Date(),
            brUpdUid: this.userId,
            brStatus: 'P',
            brEffFmDt: moment(item.value.brEffFmDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
            brEffToDt: moment(item.value.brEffToDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
          };
          Object.assign(lobBusinessData, obj);
          this.mgaService.updateBussinessRules(lobBusinessData, this.refNo, this.amendSrNo).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Updated');
              this.getAllBussinessRulesByRefId('04', 'save');
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    this.decline();

                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in Updating!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            }
          })
        }
      } else {
        MgaUtils.validateAllFormFields(this.lob_BRules_PremiumListForm);
        this.loaderService.isBusy = false;
      }
    } else {
      if (this.items_discount.valid) {
        let lobDiscountData = item.value;
        let brSeverity = this.mgaDiscountRulesForm.get('brSeverity').value;
        if (action == 'save') {
          if (brSeverity == "" || brSeverity == null) {
            this.toastService.warning("Choose Severity");
            this.loaderService.isBusy = false;
          } else {
            let obj = {
              binderLobBusRulesPK: {
                brAmendNo: this.amendNo,
                brRefNo: this.refNo,
                brSeqNo: this.seqNo,
                brProdSrNo: this.lobSrNo
              },
              brCrDt: new Date(),
              brCrUid: this.userId,
              brUpdDt: new Date(),
              brUpdUid: this.userId,
              brStatus: 'P',
              brSeverity: brSeverity,
              brEffFmDt: moment(item.value.brEffFmDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
              brEffToDt: moment(item.value.brEffToDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
            };
            Object.assign(lobDiscountData, obj);
            this.mgaService.saveBussinessRules(lobDiscountData).subscribe((resp) => {
              if (resp.messageType == 'S') {
                this.toastService.success('Successfully Saved');
                this.getAllBussinessRulesByRefId('05', 'save');
                this.loaderService.isBusy = false;
                this.disableAddrow_discount = false;
              } else if (resp.messageType == 'U') {
                this.loaderService.isBusy = false;
                this.toastService.success(resp.message);
              } else {
                this.loaderService.isBusy = false;
                this.toastService.error(resp.message);
              }
            }, error => {
              if (error instanceof HttpErrorResponse) {
                if (error.error instanceof ErrorEvent) {
                  this.loaderService.isBusy = false;
                  this.toastService.error("Error in upload!");
                } else {
                  switch (error.status) {
                    case 400:
                      this.loaderService.isBusy = false;
                      this.showErrorDialogBox(error.error.message);
                      this.decline();

                      break;
                    default:
                      this.loaderService.isBusy = false;
                      this.toastService.error("Error in upload!");
                      break;
                  }
                }
              } else {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              }
            })
          }
        } else {
          let lobDiscountData = item.value;
          let obj = {
            binderLobBusRulesPK: {
              brAmendNo: this.amendNo,
              brRefNo: this.refNo,
              brSeqNo: this.seqNo,
              brProdSrNo: this.lobSrNo,
              brSrNo: lobDiscountData.srnoId
            },
            brSeverity: brSeverity,
            brUpdDt: new Date(),
            brUpdUid: this.userId,
            brStatus: 'P',
            brEffFmDt: moment(item.value.brEffFmDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
            brEffToDt: moment(item.value.brEffToDt, 'DD-MM-YYYY').format('YYYY-MM-DD'),
          };
          Object.assign(lobDiscountData, obj);
          lobDiscountData = MgaUtils.clean(lobDiscountData);
          this.mgaService.updateBussinessRules(lobDiscountData, this.refNo, this.amendSrNo).subscribe((resp) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Updated');
              this.getAllBussinessRulesByRefId('05', 'save');
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    this.showErrorDialogBox(error.error.message);
                    this.decline();

                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in Updating!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            }
          })
        }
      } else {
        MgaUtils.validateAllFormFields(this.lob_BRules_DiscountListForm);
        this.loaderService.isBusy = false;
      }
    }
  }
  openModal(content, val) {
    this.modalRef1 = this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalRef1.hide();
    this.router.navigate(['/mga-contract/mga-dashboard'], { queryParams: { title: 'home' } });
    this.decline();
  }

  showErrorDialogBox(apprErrorMsg) {
    this.openModal(this.errorModal, 'modal-md');
    setTimeout(() => {
      apprErrorMsg = apprErrorMsg.replace("Error Message - ", "");
      const str = apprErrorMsg.split(",");
      str.forEach((value, element) => {
        document.getElementById("errorModalDetails").innerHTML += "<p>" + value + "</p>";
      });
    }, 200);
  }
  openConfirmModal(template: TemplateRef<any>, srNo, index, formName) {
    this.formName = formName;
    this.deleteIndex = srNo;
    this.index = index;
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  decline(): void {
    this.modalRef.hide();
  }
  confirm(srId, index, formName): void {
    this.loaderService.isBusy = true;
    if (srId == null && formName == 'premium') {
      this.items_premium.removeAt(index);
      this.modalRef.hide();
      this.loaderService.isBusy = false;
      this.disableAddrow_premium = false;
    } else if (srId == null && formName == 'discount') {
      this.items_discount.removeAt(index);
      this.modalRef.hide();
      this.loaderService.isBusy = false;
      this.disableAddrow_discount = false;

    } else {
      this.mgaService.deleteBussinessRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, srId).subscribe(() => {
        this.toastService.success('Deleted Succcessfully.');
        this.loaderService.isBusy = false;
        if (formName == 'premium') {
          this.items_premium.removeAt(index);
          this.disableAddrow_premium = false;
        } else {
          this.items_discount.removeAt(index);
          this.disableAddrow_discount = false;
        }
        this.modalRef.hide();
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error("Error in Deleting Data");
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.showErrorDialogBox(error.error.message);
                this.decline();
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Deleting Data");
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("Error in Deleting Data");
        }
      })
    }
  }
  getPremiumBusinessRules(ruleId) {
    this.mgaService.getBussinessRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, ruleId).subscribe(resp => {
      this.premiumListData = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  getDiscountBusinessRules(ruleId) {
    this.mgaService.getBussinessRules(this.refNo, this.seqNo, this.amendNo, this.lobSrNo, ruleId).subscribe(resp => {
      this.discountListData = resp;
      if (this.discountListData.length != 0) {
        // let sevValue = this.discountListData[this.discountListData.length - 1].brSeverity
        this.mgaDiscountRulesForm.get('brSeverity').setValue(this.discountListData[0].brSeverity)
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  addBusinessRulesInfo() {
    this.open(this.ruleContent, 'modal-lg');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  dateValidators(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message = "Should be in Contract Period";
      if (first.value < this.minDate || first.value > this.maxDate) {
        first.setErrors({ dateValidator: message });
        return { dateValidator: true };
      }
      if (second.value < this.minDate || second.value > this.maxDate) {
        second.setErrors({ dateValidator: message });
        return { dateValidator: true };
      }
    };
  }
  graterValidator(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message =
        "Must be greater or equal to the Min Loss %";
      if (second.value > first.value) {
      } else if (second.value == first.value) {
      } else {
        second.setErrors({ equalValue: message });
        return { equalValue: true };
      }
    };
  }
}

