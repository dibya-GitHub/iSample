import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { Observable, Subject } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MgaContractService {
  companyCode: any;
  divisionCode: any;
  departmentCode: any;
  public requestHeaders;
  // public requestHeaders;
  mgaUrl: any = environment.mgaUrl;
  mgaCommonUrl = environment.mgaCommonUrl;
  commonBaseUrl = environment.commonBaseUrl;
  mgaFinanceUrl = environment.mgaFinanceUrl;
  public headers;
  private subject = new Subject<any>();
  private termPerUpdate = new Subject<any>();
  private sharePercentage = new Subject<any>();
  private savedData = new Subject<any>();
  private savedDataForTerm = new Subject<any>();
  constructor(
    private route: ActivatedRoute,
    private httpService: HttpClient,
    private session: SessionStorageService,
    private authService: AuthService
  ) {
    this.companyCode = this.session.get('companyCode');
    this.divisionCode = this.session.get('divisionCode');
    this.departmentCode = this.session.get('departmentCode');
    this.requestHeaders = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })
    // this.requestHeaders = new RequestOptions({ headers: this.requestHeaders })
    { }

  }


  sendClickEvent(errLog) {
    this.subject.next(errLog);
  }
  getClickEvent(): Observable<any> {
    return this.subject.asObservable();
  }

  getParamValue(paramName) {
    let paramVal;
    this.route.queryParams.subscribe(params => {
      paramVal = params[paramName];

    });
    return paramVal;
  }
  getBussinessTypeAppCode(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/BUS_TYPE', this.requestHeaders);
  }
  getRegions(): Observable<any> {
    return this.httpService.get(this.commonBaseUrl + '/appcodes-mgmt/appcodes/COUNTRY', this.requestHeaders);
  }
  getCurrencyAppCode(): Observable<any> {
    return this.httpService.get(this.commonBaseUrl + 'currency-mgmt/currency', this.requestHeaders);
  }
  getBordereauxFrequency(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/BRDX_FRQ', this.requestHeaders);
  }
  getMGAappCode(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customers/MGA', this.requestHeaders);
  }
  getMGAlist() {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/MGA_TYPE', this.requestHeaders);
  }
  getCoinsList(refNo, seqNo, amendNo, lobSrNo) {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/COINS_LIST/' + refNo + '/' + seqNo + '/' + amendNo + '/' + lobSrNo, this.requestHeaders);
  }
  getEditCoinsList() {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/COINS_LIST/', this.requestHeaders);
  }
  getACNTfilterlist() {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/ACNT_FILTER', this.requestHeaders);
  }
  getPlacingBrokerAppCode(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customers/BROKER', this.requestHeaders);
  }
  getLOBCompanyAppCode(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'users-mgmt/instance/1/' + this.companyCode + '?type=divsion', this.requestHeaders);
  }
  getLOBProductAppCode(divisionCode): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/lobprodtype/compcode/' + this.companyCode + '/division/' + divisionCode, this.requestHeaders);
  }
  getLOBSubProductAppCode(refNo, seqNo, amendNo, compCode, lobCode): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/lobsubproduct/' + refNo + '/' + seqNo + '/' + amendNo + '/comp/' + compCode + '/lob/' + lobCode, this.requestHeaders);
  }
  searchContract(formData: any): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'contracts/filtersearch', formData);
  }

  retrieveContractYear(path: string): Observable<any> {
    return this.httpService.get<any>(this.mgaUrl + path + "/" + ApiUrls.MGA_MAPPING_PATH + "/year", this.requestHeaders);
  }
  reterieveUserList(): Observable<any> {
    return this.httpService.get<any>(this.mgaUrl + ApiUrls.MGA_BINDER_CONTRACTS + "/user-dd", this.requestHeaders);
  }
  reterieveUWriterList(): Observable<any> {
    return this.httpService.get<any>(this.mgaUrl + "contracts/user-dd", this.requestHeaders);
  }
  binderContracts(): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_BINDER_CONTRACTS, this.requestHeaders);
  }
  getContractInfo(refNo, seqNo, amendNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_BINDER_CONTRACTS + '/' + refNo + '/' + seqNo + '/' + amendNo, this.requestHeaders);
  }
  saveContractInfoData(formData) {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_BINDER_CONTRACTS, formData);
  }
  updateContractInfoData(formData, refNo, amendSrNo) {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_BINDER_CONTRACTS + '/' + refNo + '?amendSrNo=' + amendSrNo, formData);
  }

  // - ------------Applicable Product/Company/LOB --------- -
  getAllBinderLOBByRefId(refNo, seqNo, amendNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_LOB_CONTRACTS + '/' + refNo + '/' + seqNo + '/' + amendNo, this.requestHeaders);
  }
  getLOBbyRefNoSrNo(refNo, srNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_LOB_CONTRACTS + '/' + refNo + '/' + srNo, this.requestHeaders);
  }
  saveBinderLOB(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_LOB_CONTRACTS, formData);
  }
  updateBinderLOB(formData, refNo, amendSrNo): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_LOB_CONTRACTS + '/' + refNo + '?amendSrNo=' + amendSrNo, formData);
  }
  deleteBinderLOB(obj): Observable<any> {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_LOB_CONTRACTS + '/' + obj.bpRefNo + '/' + obj.bpSeqNo + '/' + obj.bpAmendNo + '/' + obj.bpProdSrNo, this.requestHeaders);
  }
  // - ------------Applicable Product/Company/LOB --------- -

  // - ------------Applicable Product/Company/LOB EPI--------- -

  getLOBEPIbyRefNoSrNo(refNo, seqNo, amendNo, srNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_LOB_EPI + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + srNo, this.requestHeaders);
  }
  saveLOBEPI(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_LOB_EPI + '/', formData);
  }
  updateLOBEPI(formData, refNo, amendSrNo): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_LOB_EPI + '/' + refNo + '?amendSrNo=' + amendSrNo, formData);
  }
  deleteLOBEPI(refNo, seqNo, amendNo, prodId, srNo): Observable<any> {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_LOB_EPI + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + srNo, this.requestHeaders);

  }
  // - ------------Applicable Product/Company/LOB EPI--------- -
  // - ------------Applicable Product/Company/LOB BUSINESS RULES--------- -

  getRuleTypeDropDown(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/lobbusruletype', this.requestHeaders);
  }
  getSeverityTypeDropdown(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/SEVERITY', this.requestHeaders);
  }
  getBussinessRules(refNo, seqNo, amendNo, prodId, ruleId): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_BUSINESS_RULES + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + ruleId, this.requestHeaders);
  }
  updateBussinessRules(formData, refNo, amendSrNo): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_BUSINESS_RULES + '/' + refNo + '?amendSrNo=' + amendSrNo, formData);
  }
  saveBussinessRules(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_BUSINESS_RULES + '/', formData);
  }
  deleteBussinessRules(refNo, seqNo, amendNo, prodId, srNo): Observable<any> {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_BUSINESS_RULES + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + srNo, this.requestHeaders);
  }
  // - ------------Applicable Product/Company/LOB BUSINESS RULES--------- -

  // - ------------Applicable Product/Company/LOB COINSURANCE--------- -
  getCoinsurerList(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customers/BROKER', this.requestHeaders);
  }
  getBrokerList(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customers/BROKER', this.requestHeaders);
  }
  getAccountToList(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/ACCOUNT_TO', this.requestHeaders);
  }


  getCoinsurancebyRefNoSrNo(refNo, seqNo, amendNo, srNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_COINSURANCE + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + srNo, this.requestHeaders);
  }
  updateCoinsurance(formData, refNo, amendSrNo): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_COINSURANCE + '/' + refNo + '?amendSrNo=' + amendSrNo, formData);
  }
  saveCoinsurance(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_COINSURANCE, formData);
  }
  deleteCoinsurance(refNo, seqNo, amendNo, prodId, srNo): Observable<any> {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_COINSURANCE + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + srNo, this.requestHeaders);
  }

  updateSSCInfo(formData, refNo) {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/' + 'ssc' + '/' + refNo, formData);
  }
  deleteSSCInfo(refNo, seqNo, amendNo, prodId, srNo, custCode): Observable<any> {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/' + 'ssc' + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + srNo + '/' + custCode, this.requestHeaders);
  }
  // - ------------Applicable Product/Company/LOB COINSURANCE--------- -


  // - ------------Applicable Product/Company/LOB TERMS--------- -
  getBtTypeList() {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/termcodetype/MGA_TERM_TYP/TERMS/', this.requestHeaders);
  }
  getBtCoTypeList() {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/termcodetype/MGA_TERM_TYP/COTERMS/', this.requestHeaders);
  }
  getBtContactTypeList(type) {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/termcodetype/MGA_TERM_TYP/' + type, this.requestHeaders);
  }
  getTermRules1(refNo, seqNo, amendNo, prodId): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId, this.requestHeaders);
  }
  getTermRules(refNo, seqNo, amendNo, prodId, pathName, custCode, brkType): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + pathName + '?custCode=' + custCode + '&btBrkType=' + brkType, this.requestHeaders);
  }
  getCustomers() {
    return this.httpService.get(environment.financeBaseUrl + '/api/customers');
  }
  getTermCommType(refNo, seqNo, amendNo, prodId, termType, custCode, commtype): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + termType + '/custCode/' + custCode + '?commType=' + commtype, this.requestHeaders);
  }

  updateTerms(formData, refNo, amendSrNo): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/' + refNo + '?amendSrNo=' + amendSrNo, formData);
  }
  saveTerms(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/', formData);
  }
  deleteTerms(refNo, seqId, amendNo, prodId, srNo): Observable<any> {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_LOB_TERMS + '/' + refNo + '/' + seqId + '/' + amendNo + '/' + prodId + '/' + srNo, this.requestHeaders);
  }
  // - ------------Applicable Product/Company/LOB TERMS--------- -
  getCoinPrmMtd(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/COIN_TRM_ON', this.requestHeaders);
  }
  getCoinExpType(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/COIN_EXP_TYP', this.requestHeaders);
  }

  getCoinsuranceExpenses(refNo, seqNo, amendNo, prodId, typeId, custCode): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_COINSURANCE_EXPENSES + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + typeId + '/' + custCode, this.requestHeaders);
  }
  updateCoinsuranceExpenses(formData, refNo, amendSrNo): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_COINSURANCE_EXPENSES + '/' + refNo + '?amendSrNo=' + amendSrNo, formData);
  }
  saveCoinsuranceExpenses(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_COINSURANCE_EXPENSES + '/', formData);
  }
  deleteCoinsuranceExpenses(refNo, seqId, amendNo, prodId, srNo): Observable<any> {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_COINSURANCE_EXPENSES + '/' + refNo + '/' + seqId + '/' + amendNo + '/' + prodId + '/' + srNo, this.requestHeaders);
  }


  //  - ------------ - OUTWARD REINSURANCE -  - ------------

  getContractType(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/appcodes/acmccodenull/CONTRACT_TYP', this.requestHeaders);
  }
  getChildOutwardDetails(data) {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/cgrid/' + data.boRefNo + '/' + data.boSeqNo + '/' + data.boAmendNo + '?productCode=' + data.boProdCode, this.requestHeaders);
  }
  getOutwardCompanyInfo(refNo, srNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/' + refNo + '/' + srNo, this.requestHeaders);
  }
  getOutwardCompanyId(refNo, seqNo, amendNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/form-dd/' + refNo + '/' + seqNo + '/' + amendNo, this.requestHeaders);
  }
  getOutwardContractId(refNo, seqNo, contractId, prodCode, compCode, lobCode): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/form-dd/' + refNo + '/' + seqNo + '/' + contractId + '/' + prodCode + '/' + compCode + '/' + lobCode, this.requestHeaders);
  }
  getOutwardDataEdit(data): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/form-dd-edit/' + data.binderOutwardPK.boRefNo + '/' + data.binderOutwardPK.boSeqNo + '/' + data.boTtyContType + '/' + data.boProdCode + '?boTtyRefNo=' + data.boTtyRefNo + '&boTtySeqNo=' + data.boTtySeqNo, this.requestHeaders);
  }
  getDetailsByContract(data): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/form-text/' + data.refNo + '/' + data.boContType + '/' + data.boProdCode + '/' + data.contRefSeqNo, this.requestHeaders);
  }
  addOutwardRi(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_OUTWARD, formData);
  }
  updateOutwardRi(refNo, formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/' + refNo, formData);
  }
  deleteOutwardRi(refNo, seqNo, amendNo, srNo, prodSrNo) {
    return this.httpService.delete(this.mgaUrl + ApiUrls.MGA_OUTWARD + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + srNo + '/' + prodSrNo, this.requestHeaders)
  }
  //  - ------------ - OUTWARD REINSURANCE -  - ------------
  approveContract(refNo, formData) {
    return this.httpService.put(this.mgaUrl + 'outward-approve' + '/' + refNo, formData);
  }

  approveValidation(refNo, seqNo, amendNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'bc-outward/approve-validate/' + refNo + '/' + seqNo + '/' + amendNo, this.requestHeaders)
  }
  // - ------------View Contracts UI Start--------- -

  viewMgaContract(refNo, seqNo, amendNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_VIEW + '/' + refNo + '/' + seqNo + '/' + amendNo, this.requestHeaders);
  }
  viewMgaEPI(refNo, seqNo, amendNo, srNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_VIEW + '/' + ApiUrls.MGA_LOB_EPI + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + srNo, this.requestHeaders);
  }
  viewMgaTerms(refNo, seqNo, amendNo, prodId, ruleId): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_VIEW + '/' + ApiUrls.MGA_LOB_TERMS + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + ruleId, this.requestHeaders);
  }
  viewMgaBusiness(refNo, seqNo, amendNo, prodId, ruleId): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_VIEW + '/' + ApiUrls.MGA_BUSINESS_RULES + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodId + '/' + ruleId, this.requestHeaders);
  }
  viewMgaCoinsurance(refNo, seqNo, amendNo, srNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_VIEW + '/' + ApiUrls.MGA_COINSURANCE + '/' + refNo + '/' + seqNo + '/' + amendNo + '/' + srNo, this.requestHeaders);
  }
  viewOutwardList(refNo, seqNo, amendNo) {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_VIEW + '/' + ApiUrls.MGA_OUTWARD + '/' + refNo + '/' + seqNo + '/' + amendNo, this.requestHeaders);
  }
  // - ------------View Contracts UI end--------- -

  // - ------------Amendment Start--------- -

  fetchAmendmentSrNo(refNo): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_AMEND + '/increment/' + refNo, this.requestHeaders);
  }
  saveAmendmentDetails(refNo, body): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_AMEND + '/' + refNo, body, this.requestHeaders);
  }
  fetchAllAmendHistory(refNo: any): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_AMEND + '/history/' + refNo, this.requestHeaders);
  }
  retriveAmendmendOldNewHistory(data: any): Observable<any> {
    return this.httpService.get(this.mgaUrl + ApiUrls.MGA_AMEND + '/oldnew-dataview/' + data.refNo + '/' + data.seqNo + '/' + data.amendNo, this.requestHeaders);
  }
  deleteAmendHistory(data: any) {
    return this.httpService.delete(this.mgaUrl + 'amend/' + data.refNo + '/' + data.seqNo + '/' + data.amendNo, this.requestHeaders);
  }
  // - ------------Amendment End--------- -

  // - ------------Renewal Start --------- -

  saveRenewDetails(data, body): Observable<any> {
    return this.httpService.post(this.mgaUrl + ApiUrls.MGA_RENEW + '/' + data.refNo + '/' + data.bcrSeqNo + '/' + data.bcrAmendNo, body, this.requestHeaders);
  }
  // - ------------Renewal End --------- -

  fetchExchangeRate(fromCurrencyCode, toCurrencyCode, onDate) {
    return this.httpService.get(this.mgaFinanceUrl
      + 'exchange-rate-mgmt/getExchangeRate?fromCurrencyCode=' + fromCurrencyCode
      + '&toCurrencyCode=' + toCurrencyCode + '&onDate=' + onDate);
  }

  validateRefNo(refNo) {
    return this.httpService.get(this.mgaUrl + 'contracts/validate/refno/' + refNo, this.requestHeaders);
  }
  getBaseCurrencyDivision(divisionCode) {
    return this.httpService.get(this.commonBaseUrl + 'appcodes-mgmt/divisonCurrency/company/' + this.companyCode + '/division/' + divisionCode, this.requestHeaders);
  }

  // - ------------Manual Accounting Starts --------- -

  fetchAllTechAccList(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'headers', this.requestHeaders);
  }
  fetchAllTechAccDetails(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'details', this.requestHeaders);
  }

  fetchTechAccListById(id): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'tamanual/header/' + id, this.requestHeaders);
  }
  fetchTechAccDetailsById(id): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'tamanual/details/' + id, this.requestHeaders);
  }
  reversalTAManual(batchId){
    return this.httpService.put(this.mgaUrl + 'tamanual/reverse/' + batchId, this.requestHeaders);
  }
  // fetchTAManual(tranType, letter) {
  //   return this.httpService.get(this.mgaFinanceUrl + 'glacnt/getGlMainAcnts/' + letter, this.requestHeaders);
  // }
  fetchTAAccTypes(body) {
    return this.httpService.post(this.mgaUrl + 'tamanual/ta-types/ACC_TYPE', body, this.requestHeaders);

  }
  fetchCoaDetails(key) {
    return this.httpService.get(this.mgaUrl + 'tamanual/coa/' + key, this.requestHeaders);
  }
  fetchIntroducerCustomer(customerName) {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customers/cusname/' + customerName, this.requestHeaders);
  }
  deleteTAManualEntry(bdId, coaId) {
    return this.httpService.delete(this.mgaUrl + 'tamanual/accdetail/' + bdId + '/' + coaId, this.requestHeaders);
  }
  fetchTransactionType(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'transdoc-mgmt/acc-types/TRAN_TYPE', this.requestHeaders);
  }
  fetchContractList(transType): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'tamanual/contractIds/' + transType, this.requestHeaders)
  }
  fetchContractDetails(transType, obj): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'tamanual/contractId/details?trantype=' + transType, obj, this.requestHeaders)
  }
  fetchAccCurrency(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'currency-mgmt/tacurrency', this.requestHeaders);
  }
  saveTechAccountingDetails(body): Observable<any> {
    return this.httpService.post(this.mgaCommonUrl + 'techacc', body, this.requestHeaders);
  }
  saveTechAccountingHeaders(body): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'tamanual/' + this.divisionCode + '/' + this.departmentCode, body, this.requestHeaders);
  }
  updateTechAccountingHeader(bhId, formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'tamanual/update/' + bhId + '/' + this.divisionCode + '/' + this.departmentCode, formData);
  }
  approveTechAccount(bhId, formData) {
    return this.httpService.put(this.mgaUrl + 'tamanual/approve/' + bhId + '/' + this.divisionCode, formData);
  }
  accountSearch(formData) {
    return this.httpService.post(this.mgaUrl + 'tamanual/filtersearch', formData, this.requestHeaders);
  }
  accountAdvancedSearch(formData){
    return this.httpService.get(this.mgaUrl + 'tamanual/advanceSearch/viewAccount/accBatchDocId?adTransIdFrm=' + formData.adTransIdFrm +'&adTransIdTo=' + formData.adTransIdTo + '&dateFm=' + formData.dateFm + '&dateTo=' + formData.dateTo, this.requestHeaders);
  }
  fetchRevenueDetails(trans_desc, trans_id, bhId) {
    return this.httpService.get(this.mgaUrl + 'tamanual/accdetail/' + trans_desc + '/' + trans_id + '/' + bhId, this.requestHeaders);
  }
  fetchSubProductDetails() {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/techaccsubproduct/' + this.companyCode + '/' + this.divisionCode, this.requestHeaders);
  }
  delteAccountingDetails(bdId) {
    return this.httpService.delete(this.mgaUrl + 'tamanual/accdetail/' + bdId, this.requestHeaders);
  }
  getMGA(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/custshortnames', this.requestHeaders);
  }
  getMGACustomer(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/tacustomers', this.requestHeaders);
  }
  getContractIds(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'tamanual/contract-ids-dd', this.requestHeaders);
  }
  getCoinsCustList(refNo, seqNo, amendNo, prodSrNo, custCode): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'coinsCustList/' + refNo + '/' + seqNo + '/' + amendNo + '/' + prodSrNo + '/' + custCode, this.requestHeaders);
  }
  getClosingDate(formData) {
    return this.httpService.post(this.mgaUrl + 'tamanual/treatyacc-closedt', formData, this.requestHeaders);
  }
  // - ------------Manual Accounting Ends --------- -

  // - ------------Mga Code mapping Starts --------- -
  getMgaCodeMapping(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'mgacodemapping', this.requestHeaders);
  }
  getMgaList(): Observable<any> {
    return this.httpService.get(this.mgaFinanceUrl + 'api/customer/shortName/MGA', this.requestHeaders);
  }
  getMgaDd(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'mgacodemapping/shortName/MGA', this.requestHeaders)
  }

  getCodeTypeList(): Observable<any> {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/mgaCodeType/MGA_CODE_MAP', this.requestHeaders);
  }
  saveCodeMapping(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'mgacodemapping/save', formData);
  }
  updateCodeMapping(formData): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'mgacodemapping/update', formData);
  }
  deleteCodeMapping(mcmMga, mcmType, mcmMgaVal): Observable<any> {
    return this.httpService.delete(this.mgaUrl + 'mgacodemapping/delete/' + mcmMga + '/' + mcmType + '/' + mcmMgaVal);
  }
  codeMappingFilterSearch(formData): Observable<any> {
    return this.httpService.post(this.mgaUrl + 'mgacodemapping/filtersearch', formData);
  }
  getOurMgaCode(value): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'mgaCodeType/MGA_CODE_MAP/' + value);
  }
  // - ------------Mga Code mapping Ends --------- -
  // -------------- MGA Production Summary services ----------
  getChartData(formData) {
    return this.httpService.post(this.mgaUrl + 'dashboard/chart', formData);
  }

  getTableData(formData) {
    return this.httpService.post(this.mgaUrl + 'dashboard/gridData', formData);
  }

  getContractList(): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'dashboard/BinderRefIdList', this.requestHeaders);
  }

  // -------------- MGA Production Summary services ----------
  //--------------- MGA Terms % Update --------------
  sendMGAGridLoad(data) {
    this.termPerUpdate.next(data);
  }
  getMGAGridLoad(): Observable<any> {
    return this.termPerUpdate.asObservable();
  }

  //Share Percentage for Coinsurer
  sendCoinsSharePer(data) {
    this.sharePercentage.next(data);
  }

  getCoinsSharePer(): Observable<any> {
    return this.sharePercentage.asObservable();
  }

  sendSavedCoinsData(data) {
    this.savedData.next(data);
  }

  getSavedCoinsData(): Observable<any> {
    return this.savedData.asObservable();
  }
  sendSavedDataTerms(data) {
    this.savedDataForTerm.next(data);
  }
  getSavedTermsData(): Observable<any> {
    return this.savedDataForTerm.asObservable();
  }
  defaultButton(ref, seq, amend, lob): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'lobterms/defaultbutton/' + ref + '/' + seq + '/' + amend + '/' + lob, this.requestHeaders);
  }

  defaultAllTermsButton(ref, seq, amend, lob, prodSrNo, companyCode): Observable<any> {
    return this.httpService.put(this.mgaUrl + 'lobterms/defaultAllTerms/' + ref + '/' + seq + '/' + amend + '/' + lob + '/' + prodSrNo + '/company/' + companyCode, this.requestHeaders);
  }
  appCodesAccFreq(type: string, mcCode: string): Observable<any> {
    return this.httpService.get<any>(environment.mgaUrl + 'bc-master' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.APP_CODES_MAP_PATH + "/" + type + "/" + mcCode, this.requestHeaders);
  }

  entryValidate(ref, seq, amend, busType): Observable<any> {
    return this.httpService.get(this.mgaUrl + 'lobterms/entryvalidate/' + ref + '/' + seq + '/' + amend + '/' + this.companyCode + '/' + busType, this.requestHeaders);
  }
  getCompanyLOBDropdown(company) {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/lob/compcode/' + company, this.requestHeaders);
  }
  getAllSubProduct() {
    return this.httpService.get(this.mgaCommonUrl + 'appcodes-mgmt/lobsubproduct', this.requestHeaders);
  }
  getTAUsers() {
    return this.httpService.get(environment.mgaUrl + 'tamanual/process-users-dd', this.requestHeaders);
  }
}

// {{binder_url}}/lobterms/defaultAllTerms/MS2005{refNo}/1{seqNo}/0{amendNo}/01{lob}/1{prodSrNo}