import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { DocPrintTableComponent } from './components/doc-print-table/doc-print-table.component';
import { EmailTableComponent } from './components/email-table/email-table.component';
import { LoginHistoryArchiveTableComponent } from './components/login-history-archive-table/login-history-archive-table.component';
import { LoginHistoryTableComponent } from './components/login-history-table/login-history-table.component';
import { ReportLogComponent } from './components/report-log/report-log.component';
import { ReportTableComponent } from './components/report-table/report-table.component';
import { SmslogTableComponent } from './components/smslog-table/smslog-table.component';
import { LogsSetupRoutingModule } from './logs-setup-routing.module';


@NgModule({
  declarations: [
    SmslogTableComponent,
    EmailTableComponent,
    ReportTableComponent,
    DocPrintTableComponent,
    LoginHistoryTableComponent,
    LoginHistoryArchiveTableComponent,
    ReportLogComponent
  ],
  imports: [
    CommonModule,
    CommonAppModule,
    LogsSetupRoutingModule
  ]
})
export class LogsSetupModule { }
