import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocPrintTableComponent } from './components/doc-print-table/doc-print-table.component';
import { EmailTableComponent } from './components/email-table/email-table.component';
import { LoginHistoryArchiveTableComponent } from './components/login-history-archive-table/login-history-archive-table.component';
import { LoginHistoryTableComponent } from './components/login-history-table/login-history-table.component';
import { ReportLogComponent } from './components/report-log/report-log.component';
import { ReportTableComponent } from './components/report-table/report-table.component';
import { SmslogTableComponent } from './components/smslog-table/smslog-table.component';

const routes: Routes = [
  {
    path: 'smslog',
    component: SmslogTableComponent,
    data: {
      breadcrumb: 'SMS'
    },
  },
  {
    path: 'emaillog',
    component: EmailTableComponent,
    data: {
      breadcrumb: 'Email'
    },
  },
  {
    path: 'reportlog',
    component: ReportTableComponent,
    data: {
      breadcrumb: 'Report'
    },
  },
  {
    path: 'reportlog/view',
    component: ReportLogComponent,
    data: {
      breadcrumb: 'Report-View'
    },
  },
  {
    path: 'doc-print-log',
    component: DocPrintTableComponent,
    data: {
      breadcrumb: 'Document Print'
    },
  },
  {
    path: 'user-login-history',
    component: LoginHistoryTableComponent,
    data: {
      breadcrumb: 'Login History'
    },
  },
  {
    path: 'user-login-history-archive',
    component: LoginHistoryArchiveTableComponent,
    data: {
      breadcrumb: 'Login History Archive'
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LogsSetupRoutingModule { }
