import { Component } from '@angular/core';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { LogsSetupService } from '../../services/logs-setup.service';

@Component({
  selector: 'app-smslog-table',
  templateUrl: './smslog-table.component.html',
  styleUrls: ['./smslog-table.component.scss']
})

export class SmslogTableComponent {

  public defaultColDef;
  smslogCols: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';
  smsLogDetails: any;

  constructor(
    private loaderService: LoaderService,
    private logService: LogsSetupService,
    private toastService: ToastService
  ) {
    this.defaultColDef = {
      resizable: true,
      filter: true,
      sortable: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.smslogCols = [
      {
        field: 'slgId',
        headerName: 'ID',
        tooltipField: 'slgId',
        headerTooltip: 'ID',
      },
      {
        field: 'slgRefNo',
        headerName: 'Mobile Number',
        tooltipField: 'slgRefNo',
        headerTooltip: 'Mobile Number',

      },
      {
        field: 'slgRemarks',
        headerName: 'Remarks',
        tooltipField: 'slgRemarks',
        headerTooltip: 'Remarks',
      },
      {
        field: 'slgRunDate',
        headerName: 'Run Date',
        headerTooltip: 'Run Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.slgRunDate) {
            return moment(params.data.slgRunDate).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        field: 'slgMsgTo',
        headerName: 'Message To',
        headerTooltip: 'Message To',
        tooltipField: 'slgMsgTo',

      },
      {
        field: 'slgMsgText',
        headerName: 'Message Text',
        headerTooltip: 'Message Text',
        tooltipField: 'slgMsgText',
      },
      {
        field: 'slgMsgStatus',
        headerName: 'Status',
        headerTooltip: 'Status',
        tooltipField: 'slgMsgStatus',
      },
      {
        field: 'slgMsgDate',
        headerName: 'Sent date',
        headerTooltip: 'Sent date',
        tooltipField: 'slgMsgDate',
        valueGetter: function (params) {
          if (params && params.data && params.data.slgMsgDate) {
            return moment(params.data.slgMsgDate).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        field: 'slgSentTime',
        headerName: 'Sent Time',
        headerTooltip: 'Sent Time',
        tooltipField: 'slgSentTime',
      },
      {
        field: 'slgUnicode',
        headerName: 'Unicode',
        headerTooltip: 'Unicode',
        tooltipField: 'slgUnicode',
      },
      {
        field: 'slgLongMesg',
        headerName: 'Long Msg',
        headerTooltip: 'Long Msg',
        tooltipField: 'slgLongMesg',
      },
      {
        field: 'slgUserId',
        headerName: 'User Id',
        headerTooltip: 'User Id',
        tooltipField: 'slgUserId'
      },

    ];
    this.retrieveSMSlog();
  }

  retrieveSMSlog() {
    this.logService.retrieveSmsDetails().subscribe(resp => {
      this.smsLogDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any,) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return }
}
