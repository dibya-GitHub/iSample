import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
import { LogsSetupService } from '../../services/logs-setup.service';

@Component({
  selector: 'app-email-table',
  templateUrl: './email-table.component.html',
  styleUrls: ['./email-table.component.scss']
})
export class EmailTableComponent implements OnInit {
  public defaultColDef;
  emailLog: any[];
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';
  emailLogDetails: any;

  constructor(
    private loaderService: LoaderService,
    private logService: LogsSetupService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.emailLog = [
      {
        field: 'elId',
        headerName: 'ID',
        headerTooltip: 'ID',
        tooltipField: 'elId',
      },
      {
        field: 'elTo',
        headerName: 'Email To',
        headerTooltip: 'Email To',
        tooltipField: 'elTo',
      },
      {
        field: 'elCc',
        headerName: 'Email CC',
        headerTooltip: 'Email CC',
        tooltipField: 'elCc',
      },
      {
        field: 'elBcc',
        headerName: 'Email BCC',
        headerTooltip: 'Email BCC',
        tooltipField: 'elBcc',
        resizable: true
      },
      {
        field: 'elFrom',
        headerName: 'Email From',
        headerTooltip: 'Email From',
        tooltipField: 'elFrom',
      },
      {
        field: 'elSubject',
        headerName: 'Email Subject',
        headerTooltip: 'Email Subject',
        tooltipField: 'elSubject',
      },
      {
        field: 'elBody',
        headerName: 'Email body',
        headerTooltip: 'Email body',
        tooltipField: 'elBody',
      },
      {
        field: 'elAttachYn',
        headerName: 'Attachment YN',
        headerTooltip: 'Attachment YN',
        tooltipField: 'elAttachYn',
        resizable: true
      },
      {
        field: 'elStatus',
        headerName: 'Status',
        headerTooltip: 'Status',
        tooltipField: 'elStatus',
      },
      {
        field: 'elSentDt',
        headerName: 'Sent Date',
        headerTooltip: 'Sent Date',
        tooltipField: 'elSentDt',
        valueGetter: function (params) {
          if (params && params.data && params.data.elSentDt) {
            return moment(params.data.elSentDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        field: 'elCrDt',
        headerName: 'Created Date',
        headerTooltip: 'Created Date',
        tooltipField: 'elCrDt',
        valueGetter: function (params) {
          if (params && params.data && params.data.elCrDt) {
            return moment(params.data.elCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },

    ];
    this.retrieveEmailLogs();
  }

  retrieveEmailLogs() {
    this.logService.retrieveEmailDetails().subscribe(resp => {
      this.emailLogDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return }

}
