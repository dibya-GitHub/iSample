import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
<<<<<<< HEAD
import * as moment from 'moment';
=======
import { ToastrService } from 'ngx-toastr';
import { SessionStorageService } from 'angular-web-storage';
import { LogsSetupService } from '../../services/logs-setup.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { LogsSetupService } from '../../services/logs-setup.service';


@Component({
  selector: 'app-report-table',
  templateUrl: './report-table.component.html',
  styleUrls: ['./report-table.component.scss']
})
export class ReportTableComponent implements OnInit {
  public defaultColDef;
  reportLog: any;
  reportLogDetails: any
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';

  constructor(
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
<<<<<<< HEAD
=======
    private session: SessionStorageService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private logService: LogsSetupService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.reportLog = [
      {
        field: 'repSrNo',
        headerName: 'Rep Sr No',
        tooltipField: 'repSrNo',
      },
      {
        field: 'repId',
        headerName: 'Rep Id',
        tooltipField: 'repId',
      },
      {
        field: 'repCompCode',
        headerName: 'Rep Comp Code',
        tooltipField: 'repCompCode',
      },
      {
        field: 'repCrUid',
        headerName: 'Rep Created Id',
        tooltipField: 'repCrUid',
      },
      {
        field: 'repCrDt',
        headerName: 'Rep Created Date',
        tooltipField: 'repCrDt',
        valueGetter: function (params) {
          if (params && params.data && params.data.repCrDt) {
            return moment(params.data.repCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        field: 'Action',
        headerName: 'Actions',
<<<<<<< HEAD
        sortable: false,
        filter: false,
        enableRowGroup: false,
=======
        filter: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        template:
          `<a>
                <i class="fa fa-eye fa-icon"  data-action-type="View" title="View" aria-hidden="true"></i>
            </a>`
      }
    ];
    this.retrieveReportLog();
  }
  retrieveReportLog() {
    this.logService.retrieveReportLogs().subscribe(resp => {
      this.reportLogDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error("Error in Retrive Data");
      this.loaderService.isBusy = false;
    })
  }


  onGridReady(params) {
    this.gridApi = params.api;
    // this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any,) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      console.log('rowselectdata::', data, 'event ', e);
      let actionType = e.event.target.getAttribute("data-action-type");
      if (actionType) {
        this.router.navigate(['/logs-setup/reportlog/view'], { queryParamsHandling: 'merge', queryParams: { repSrNo: data.repSrNo, action: 'view' } });
      }
    }
  }

}