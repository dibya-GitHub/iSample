import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { LogsSetupService } from '../../services/logs-setup.service';


@Component({
  selector: 'app-report-log',
  templateUrl: './report-log.component.html',
  styleUrls: ['./report-log.component.css']
})
export class ReportLogComponent implements OnInit {
  logList: any;
  reportLogFrm: UntypedFormGroup;
  reportFormArray: any;
  reportFormArray2: any;
  @Input('repLogInfo') repLog;
  repId: any;
  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private loaderService: LoaderService,
    private logService: LogsSetupService
    ) { }

  ngOnInit() {
    this.repId = this.logService.getParamValue('repSrNo');
    this.createReportLog();
  }

  createReportLog() {
    this.loaderService.isBusy = true;
    const arr = [];
    const arr2 = [];
    const group = {
      repSrNo: [''],
      repId: [''],
      repCompCode: '',
      repLangCode: '',
    }
    for (let index = 1; index <= 25; index++) {
      arr.push(index);
      group['repValue' + index] = new UntypedFormControl();
    }
    for (let index = 26; index <= 50; index++) {
      arr2.push(index);
      group['repValue' + index] = new UntypedFormControl();
    }
    this.reportLogFrm = this.fb.group(group);
    this.reportFormArray = arr;
    this.reportFormArray2 = arr2;
    this.loadData();
  }



  loadData() {
    this.logService.retriveRepLogById(this.repId).subscribe(resp => {
      if (resp != null) {
        this.reportLogFrm.patchValue(resp);
        this.loaderService.isBusy = false;
      }
      this.loaderService.isBusy = false;
    }, err => {
      this.loaderService.isBusy = false;
    })
  }
  back() {
    this.route.navigate(['logs-setup/reportlog'], { queryParams: { action: undefined }, queryParamsHandling: 'merge' });
  }


}
