import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { LogsSetupService } from '../../services/logs-setup.service';

@Component({
  selector: 'app-login-history-archive-table',
  templateUrl: './login-history-archive-table.component.html',
  styleUrls: ['./login-history-archive-table.component.scss']
})
export class LoginHistoryArchiveTableComponent implements OnInit {

  public defaultColDef;
  user: any;
  loginHistory: any;
  loginHistoryLogDetails: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';

  constructor(
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private logService: LogsSetupService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.user = this.session.get('userId');
    this.loginHistory = [
      {
        field: 'loghUserId',
        headerName: 'Login ID',
        tooltipField: 'loghUserId',
      },
      {
        field: 'loghSessionId',
        headerName: 'Login ID',
        tooltipField: 'loghUserId',
      },
      {
        field: 'loghIpAddress',
        headerName: 'Login Device',
        tooltipField: 'loghDevice',
      },
      {
        field: 'loghDevice',
        headerName: 'Login Device',
        tooltipField: 'loghDevice',
      },
      {
        field: 'loghDevice',
        headerName: 'Device Name',
        tooltipField: 'loghDevice',
      },
      {
        field: 'loghBrowser',
        headerName: 'Browser',
        tooltipField: 'loghBrowser',
      },
      {
        field: 'loghLoginDt',
        headerName: 'Login From',
        valueGetter: function (params) {
          if (params && params.data && params.data.loghLoginDt) {
            return moment(params.data.loghLoginDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
        // valueFormatter: dateFormatter
      },
      {
        field: 'loghLogoutDt',
        headerName: 'Logout Date',
        valueGetter: function (params) {
          if (params && params.data && params.data.loghLogoutDt) {
            return moment(params.data.loghLogoutDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
        // valueFormatter: dateFormatter
      },
    ];
    this.retrieveLoginHistory();
  }

  retrieveLoginHistory() {
    this.logService.retrieveLoginDetails(this.user, 'archeive').subscribe(resp => {
      this.loginHistoryLogDetails = resp.list;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any,) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return }
}
