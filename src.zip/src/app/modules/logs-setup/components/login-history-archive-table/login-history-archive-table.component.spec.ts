import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginHistoryArchiveTableComponent } from './login-history-archive-table.component';

describe('LoginHistoryArchiveTableComponent', () => {
  let component: LoginHistoryArchiveTableComponent;
  let fixture: ComponentFixture<LoginHistoryArchiveTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginHistoryArchiveTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginHistoryArchiveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
