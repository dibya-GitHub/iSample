import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { LogsSetupService } from '../../services/logs-setup.service';

@Component({
  selector: 'app-doc-print-table',
  templateUrl: './doc-print-table.component.html',
  styleUrls: ['./doc-print-table.component.scss']
})
export class DocPrintTableComponent implements OnInit {

  private defaultColDef;
  docprintLog: any[];
  docprintLogLogDetails: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  gridApi: any;
  quickSearchValue: any = '';
  constructor(
    private toastService: ToastService,
    private loaderService: LoaderService,
    private logService: LogsSetupService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.docprintLog = [
      {
        field: 'tphId',
        headerName: 'ID',
        tooltipField: 'tphId',
      },
      {
        field: 'tphDocType',
        headerName: 'Document Type',
        tooltipField: 'tphDocType',
      },
      {
        field: 'tphRefNo1',
        headerName: 'Ref No 1',
        tooltipField: 'tphRefNo1',
      },
      {
        field: 'tphRefNo2',
        headerName: 'Ref No 2',
        tooltipField: 'tphRefNo2',
        resizable: true
      },
      {
        field: 'tphRepId',
        headerName: 'Report ID',
        tooltipField: 'tphRepId',
      },
      {
        field: 'tphRepName',
        headerName: 'Report Name',
        tooltipField: 'tphRepName',
      },
      {
        field: 'tphPrintUid',
        headerName: 'Print By',
        tooltipField: 'tphPrintUid',
      },
      {
        field: 'tphPrintDt',
        headerName: 'Print Date',
        valueFormatter: dateFormatter
      },

    ];
    this.retrieveDocPrint();
  }

  retrieveDocPrint() {
    this.logService.retrieveDocPrintLogDetails().subscribe(resp => {
      this.docprintLogLogDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Error in Retrive Data");
    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any,) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  displayRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }


}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return }

}
