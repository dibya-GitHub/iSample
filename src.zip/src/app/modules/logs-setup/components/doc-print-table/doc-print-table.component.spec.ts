import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocPrintTableComponent } from './doc-print-table.component';

describe('DocPrintTableComponent', () => {
  let component: DocPrintTableComponent;
  let fixture: ComponentFixture<DocPrintTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocPrintTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocPrintTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
