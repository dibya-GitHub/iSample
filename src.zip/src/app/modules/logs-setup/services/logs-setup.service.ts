import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { Observable } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
<<<<<<< HEAD
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';

=======
import { SessionStorageService } from 'angular-web-storage';
import { environment } from 'src/environments/environment';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@Injectable({
  providedIn: 'root'
})
export class LogsSetupService {
  requestOption: any
  reportUrl: any = environment.reportBaseUrl;
<<<<<<< HEAD
  commonBaseUrl: any = environment.commonBaseUrl;
  constructor(
    private route: ActivatedRoute,
    private session: SessionStorageService,
    private httpService: HttpClient,
    private authService: AuthService
  ) {
    const headersOpt = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })
    this.requestOption = { headers: headersOpt };
  }

  loadLogsById(params: any): Observable<any> {
    return this.httpService.get<any>(this.commonBaseUrl + 'smslog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.RUN_DATE_PATH + "/" + params, this.requestOption);
  }

  retrieveSmsDetails(): Observable<any> {
    return this.httpService.get(this.commonBaseUrl + 'smslog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.SMS_LOG_PATH, this.requestOption);
  }
  retrieveEmailDetails(): Observable<any> {
    return this.httpService.get(this.commonBaseUrl + 'emaillog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.EMAIL_LOG_PATH, this.requestOption);
  }

  retrieveDocPrintLogDetails(): Observable<any> {
    return this.httpService.get(this.commonBaseUrl + 'docprintlog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.authService.getInstanceCode() + "/" + ApiUrls.DOCPRINT_LOG, this.requestOption);
  }

  retrieveLoginDetails(user: string, type: any): Observable<any> {
    return this.httpService.get<any>(this.commonBaseUrl + ApiUrls.USER_CONTROLLER_PATH + "/" + ApiUrls.USER_LOGIN_DETAILS + "/" + user + "?type=" + type, this.requestOption);
  }

  retrieveReportLogs(): Observable<any> {
    return this.httpService.get<any>(this.reportUrl + '/reportlog-mgmt' + "/" + "instance/" + this.authService.getInstanceCode() + "/reportlogs");
  }

  retriveRepLogById(repSrNo: any): Observable<any> {
    return this.httpService.get(this.commonBaseUrl + 'reportlog-mgmt/' + ApiUrls.REP_SR_NO + '/' + repSrNo, this.requestOption);
=======
  globalUrl: any = environment.commonBaseUrl;
  instanceId: any;
  constructor(private httpService: HttpClient, private route: ActivatedRoute,
    private session: SessionStorageService, private authService: AuthService) {
    const headersOpt = new Headers({ 'company': this.session.get('companyCode'), 'Content-Type': 'application/json' })
    this.requestOption = { headers: headersOpt };
    this.instanceId = this.authService.getInstanceCode();
  }

  loadLogsById(params: any): Observable<any> {
    return this.httpService.get<any>(this.globalUrl + 'smslog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.RUN_DATE_PATH + "/" + params, this.requestOption);
  }

  retrieveSmsDetails(): Observable<any> {
    return this.httpService.get(this.globalUrl + 'smslog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.SMS_LOG_PATH, this.requestOption);
  }
  retrieveEmailDetails(): Observable<any> {
    return this.httpService.get(this.globalUrl + 'emaillog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.EMAIL_LOG_PATH, this.requestOption);
  }

  retrieveDocPrintLogDetails(): Observable<any> {
    return this.httpService.get(this.globalUrl + 'docprintlog-mgmt' + "/" + ApiUrls.INSTANCE + "/" + this.instanceId + "/" + ApiUrls.DOCPRINT_LOG, this.requestOption);
  }

  retrieveLoginDetails(user: string, type: any): Observable<any> {
    return this.httpService.get<any>(this.globalUrl + ApiUrls.USER_CONTROLLER_PATH + "/" + ApiUrls.USER_LOGIN_DETAILS + "/" + user + "?type=" + type, this.requestOption);
  }

  retrieveReportLogs(): Observable<any> {
    return this.httpService.get<any>(this.reportUrl + 'reportlog-mgmt' + "/" + "instance/" + this.instanceId + "/reportlogs");
  }

  retriveRepLogById(repSrNo: any): Observable<any> {
    return this.httpService.get(this.globalUrl + 'reportlog-mgmt/' + ApiUrls.REP_SR_NO + '/' + repSrNo, this.requestOption);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  getParamValue(paramName) {
    let paramVal;
    this.route.queryParams.subscribe(params => {
      paramVal = params[paramName];

    });
    return paramVal;

  }

}