import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';

import { Component, ElementRef, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { AccountingDashboardService } from '../services/accounting-dashboard.service';
<<<<<<< HEAD
=======
import { KeyedWrite } from '@angular/compiler';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-accounting-dashboard',
  templateUrl: './accounting-dashboard.component.html',
  styleUrls: ['./accounting-dashboard.component.scss']
})
export class AccountingDashboardComponent {

  dashboardForm: UntypedFormGroup;
  yearList: any;
  contractList: any;
  accountingRowData: any = [];
  calculationRowData: any;
  paginationPageSize: number;
  rowGroupPanelShow: string;
  columnData: any;
  titleData: any;
  productGrossPremList: any;
  productGrossClaimList: any;
  fullData: any;

  currentYear: number = new Date().getFullYear();
  minDate: any;
  maxDate: any;
  currentMinDate: any;
  currentmaxDate: any;
  showProductDetails: boolean = false;
  @ViewChild('approveModal1') approveModal1: ElementRef;
  approvalStatus: string = '';
  batchId: any;
  reinsuredDropdownData: any;
  applCompany: any;
  forApprovalData: any;
<<<<<<< HEAD
=======
  accountProcess: any;
  searchObj: any;
  contractMonthFlag: any;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private modalService: BsModalService,
    private session: SessionStorageService,
    private accountDashboardService: AccountingDashboardService,
  ) { }

  ngOnInit(): void {
    this.loaderService.isBusy = true;
    this.createForm();
<<<<<<< HEAD
    this.retrieveAllContracts();
    this.retrieveContractYear();
    // this.minDate = this.currentMinDate = getFirstDayOfYear(this.currentYear);
    // this.maxDate = getLastDayOfYear(this.currentYear);
  }

  retrieveContractYear() {
    this.accountDashboardService.retrieveContractYear(ApiUrls.MGA_MGMT_PATH).subscribe(resp => {
      this.yearList = resp;
    })
  }
  getAllData(obj) {
    this.accountDashboardService.getProductCalc(obj).subscribe((res: any) => {
      if (res.messageType == 'S') {
        this.fullData = res;
        this.columnData = res.Data;
        this.titleData = res.Title;
        this.approvalStatus = res.approvalStatus;
        this.batchId = res.batchId;
        this.applCompany = res.applCompany;
        this.productGrossPremList = res.productGrossPremList;
        this.productGrossClaimList = res.productGrossClaimList;
        this.columnData.forEach((element, value) => {
          Object.keys(element).forEach((key, value) => {
            if (element[key] === null) {
              element[key] = 0;
            }
            if (typeof element[key] == 'number') {
              element[key] = currencyDecimalFormatter(element[key])
            }
          });

        });
        this.loaderService.isBusy = false;
      } else {
        this.loaderService.isBusy = false;
        this.toastService.error(res.message);
        this.columnData = [];
        this.showProductDetails = false;
      }
    }, error => {
      this.toastService.warning(error.error.message);
      this.loaderService.isBusy = false;
      this.columnData = [];
      this.showProductDetails = false;
    })
=======
    this.getContractMonthFlag();
    this.accountProcess = JSON.parse(sessionStorage.getItem('AccountingProcess'));
    //this.retrieveAllContracts();
    this.retrieveContractYear();
    //this.accountProcess = JSON.parse(localStorage.getItem('AccountingProcess'));
    if (this.accountProcess) {
      this.getAllContractByYear(this.accountProcess.year, 'AccView');
    }
    // this.minDate = this.currentMinDate = getFirstDayOfYear(this.currentYear);
    // this.maxDate = getLastDayOfYear(this.currentYear);
  }
  getContractMonthFlag() {
    this.accountDashboardService.getContractMonthFlag().subscribe(resp => {
      this.contractMonthFlag = resp;
      this.contractMonthFlag = Number(this.contractMonthFlag);
    })
  }
  retrieveContractYear() {
    this.loaderService.isBusy = true;
    this.accountDashboardService.retrieveContractYear(ApiUrls.MGA_MGMT_PATH).subscribe(resp => {
      this.yearList = resp;
      if (!this.accountProcess) {
        this.loaderService.isBusy = false;
      }
    })
  }
  getAllData(obj, keyword) {
    this.loaderService.isBusy = true;
    this.searchObj = obj;
    if (keyword == '' || keyword == 'AccView') {
      this.accountDashboardService.getProductCalc(obj).subscribe((res: any) => {
        if (res.messageType == 'S') {
          this.fullData = res;
          this.columnData = res.Data;
          this.titleData = res.Title;
          this.approvalStatus = res.approvalStatus;
          this.batchId = res.batchId;
          this.applCompany = res.applCompany;
          this.productGrossPremList = res.productGrossPremList;
          this.productGrossClaimList = res.productGrossClaimList;
          this.productGrossClaimOsList = res.productGrossClaimOsList;
          this.productGrossCommList = res.productGrossCommList;
          this.columnData.forEach((element, value) => {
            Object.keys(element).forEach((key, value) => {
              if (element[key] === null) {
                element[key] = 0;
              }
              if (typeof element[key] == 'number') {
                element[key] = currencyDecimalFormatter(element[key])
              }
            });

          });
          this.fetchReinsurer();
          //this.loaderService.isBusy = false;
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error(res.message);
          this.columnData = [];
          this.showProductDetails = false;
        }
      }, error => {
        this.toastService.warning(error.error.message);
        this.loaderService.isBusy = false;
        this.columnData = [];
        this.showProductDetails = false;
      })
    } else {
      this.fetchReinsurer();
      //this.loaderService.isBusy = false;
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  doSearch(keyword) {
    this.loaderService.isBusy = true;
    this.showProductDetails = (keyword == 'productDetail' ? true : false);
    if (this.fullData && this.showProductDetails) {
      setTimeout(() => {
        document.getElementById('showProduct').scrollIntoView({
          behavior: 'smooth'
        });
      }, 200);
    }
    let formData = this.dashboardForm.getRawValue();
    if (this.dashboardForm.valid) {
      let obj = {
        contract: (formData.contract == '' ? null : formData.contract),
        year: (formData.year == '' ? null : formData.year),
        uwYear: (formData.uwYear == '' ? null : formData.uwYear),
        currentMonth: (formData.currentMonth == '' ? null : (moment(formData.currentMonth, 'DD-MM-YYYY').format('MMM')).toUpperCase()),
        processedMonth: (formData.processedMonth == '' ? null : (moment(formData.processedMonth, 'MMM-YYYY').format('MMM')).toUpperCase()),
      };
<<<<<<< HEAD
      if (keyword == '') {
        this.getAllData(obj);
      } else {
        this.loaderService.isBusy = false;
      }
      this.fetchReinsurer();
=======
      this.getAllData(obj, keyword);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    } else {
      this.validateAllFormFields(this.dashboardForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
<<<<<<< HEAD
=======
  productGrossCommList: any;
  productGrossClaimOsList: any;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  fetchDataFromApplicableCompanie(data) {
    this.loaderService.isBusy = true;
    this.accountDashboardService.fetchDataFromApplicableCompanie(data).subscribe((res: any) => {
      this.fullData = res;
      this.columnData = res.Data;
      this.titleData = res.Title;
      this.approvalStatus = res.approvalStatus;
      this.batchId = res.batchId;
      this.productGrossPremList = res.productGrossPremList;
      this.productGrossClaimList = res.productGrossClaimList;
<<<<<<< HEAD
=======
      this.productGrossClaimOsList = res.productGrossClaimOsList;
      this.productGrossCommList = res.productGrossCommList;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.columnData.forEach((element, value) => {
        Object.keys(element).forEach((key, value) => {
          if (element[key] === null) {
            element[key] = 0;
          }
          if (typeof element[key] == 'number') {
<<<<<<< HEAD
            element[key] = element[key].toFixed(2);
=======
            element[key] = currencyDecimalFormatter(element[key])
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          }
        });

      });
      this.loaderService.isBusy = false;
    })

  }
  onClicked(event) {
    let formData = this.dashboardForm.getRawValue();
    this.applCompany = event.target.value;
    let obj = {
      contract: (formData.contract == '' ? null : formData.contract),
      year: (formData.year == '' ? null : formData.year),
      uwYear: (formData.uwYear == '' ? null : formData.uwYear),
      currentMonth: (formData.currentMonth == '' ? null : (moment(formData.currentMonth, 'DD-MM-YYYY').format('MMM')).toUpperCase()),
      processedMonth: (formData.processedMonth == '' ? null : (moment(formData.processedMonth, 'MMM-YYYY').format('MMM')).toUpperCase()),
      reinsurer: event.target.value,
    };
    this.fetchDataFromApplicableCompanie(obj);
  }
  fetchReinsurer() {
<<<<<<< HEAD
=======
    this.loaderService.isBusy = true;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    let formData = this.dashboardForm.getRawValue();
    let obj = {
      contract: (formData.contract == '' ? null : formData.contract),
      year: (formData.year == '' ? null : formData.year),
      companyCode: this.session.get('companyCode')
    };
    this.accountDashboardService.fetchReinsurer(obj).subscribe((res: any) => {
      this.reinsuredDropdownData = res.reinsuredList;
      let data = {
        contract: (formData.contract == '' ? null : formData.contract),
        year: (formData.year == '' ? null : formData.year),
        uwYear: (formData.uwYear == '' ? null : formData.uwYear),
        currentMonth: (formData.currentMonth == '' ? null : (moment(formData.currentMonth, 'DD-MM-YYYY').format('MMM')).toUpperCase()),
        processedMonth: (formData.processedMonth == '' ? null : (moment(formData.processedMonth, 'MMM-YYYY').format('MMM')).toUpperCase()),
        reinsurer: ''
      };
      this.forApprovalData = [];
      for (let index = 0; index < this.reinsuredDropdownData.length; index++) {
        const element = this.reinsuredDropdownData[index];
        data.reinsurer = element.key;
        this.accountDashboardService.fetchDataFromApplicableCompanie(data).subscribe((res: any) => {
          let responseData = res.Data;
          responseData = responseData.filter(datum => datum.ttyMonthStatus === 'C');
          responseData.forEach(element => {
            element.ttyCompCode = this.session.get('companyCode');
            element.ttyDeptCode = this.session.get('departmentCode');
            element.ttyContRefNo = formData.contract;
            element.ttySeqNo = 0;
            element.ttyAmendNo = 0;
            element.ttyAcntYear = formData.year;
            element.ttyLobCode = "0";
            element.ttyProdCode = "0";
            element.ttyCurr = "GBP";
            element.ttyBatchId = 0;
            this.forApprovalData.push(element);
          });
          // this.loaderService.isBusy = false;
        })

      }
<<<<<<< HEAD
=======
      this.loaderService.isBusy = false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    })
  }
  doApprove() {
    this.loaderService.isBusy = true;
    let formData = this.dashboardForm.getRawValue();
    if (this.dashboardForm.valid) {
      let obj = {
        contract: (formData.contract == '' ? null : formData.contract),
        year: (formData.year == '' ? null : formData.year),
        uwYear: (formData.uwYear == '' ? null : formData.uwYear),
        currentMonth: (formData.currentMonth == '' ? null : (moment(formData.currentMonth, 'DD-MM-YYYY').format('MMM')).toUpperCase()),
        processedMonth: (formData.processedMonth == '' ? null : (moment(formData.processedMonth, 'MMM-YYYY').format('MMM')).toUpperCase()),
      };
      var body;
      body = this.forApprovalData;
      this.accountDashboardService.doApprove(obj, body).subscribe((resp: any) => {
<<<<<<< HEAD
        if (resp.messageType == 'S') {
          this.approvalStatus = resp.approvalStatus;
          this.batchId = resp.batchId;
          this.toastService.success(resp.message);
          this.loaderService.isBusy = false;
          this.closeModal(1);
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error(resp.message);
        }
=======
        if (resp["messageType"] && resp["messageType"] == 'E') {
          this.toastService.error(resp["message"]);
        } else if (resp["messageType"] && resp["messageType"] == 'S') {
          this.approvalStatus = resp.approvalStatus;
          this.batchId = resp.batchId;
          this.toastService.success(resp.message);          
          this.closeModal(1);
        } else if (resp["messageType"] && resp["messageType"] == 'W') {
          this.toastService.warning(resp.message);
        }
        this.loaderService.isBusy = false;
        // if (resp.messageType == 'S') {
        //   this.approvalStatus = resp.approvalStatus;
        //   this.batchId = resp.batchId;
        //   this.toastService.success(resp.message);
        //   this.loaderService.isBusy = false;
        //   this.closeModal(1);
        // } else {
        //   this.loaderService.isBusy = false;
        //   this.toastService.error(resp.message);
        // }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }, error => {
        this.toastService.error(error.error.message);
        this.loaderService.isBusy = false;
      })
    } else {
      this.validateAllFormFields(this.dashboardForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  createForm() {
    this.dashboardForm = this.fb.group({
      contract: ['', Validators.required],
<<<<<<< HEAD
      year: [''],
=======
      year: ['', Validators.required],
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      uwYear: [''],
      currentMonth: ['', Validators.required],
      processedMonth: ['', Validators.required],
    });
  }
  reset() {
    this.dashboardForm.patchValue({
      contract: '',
      year: '',
      uwYear: '',
      currentMonth: '',
      processedMonth: '',
    });
    this.columnData = [];
    this.showProductDetails = false;
  }

  retrieveAllContracts() {
    this.loaderService.isBusy = true;
    this.accountDashboardService.fetchAllContracts(ApiUrls.QS_ACNT_MGMT).subscribe(resp => {
      this.contractList = resp;
    });
    this.loaderService.isBusy = false;
  }
  getContractLists(event) {
<<<<<<< HEAD
    if (event.value != '') {
      this.accountDashboardService.getUwYear(ApiUrls.QS_ACNT_MGMT, event.value).subscribe(resp => {
        this.dashboardForm.patchValue({ year: resp });
        if (resp) {
          this.fetchCurrencyMonth(event.value, resp);
        }
        this.dashboardForm.patchValue({
          currentMonth: '',
          processedMonth: '',
        });
        this.dashboardForm.get('uwYear').setValue((this.yearList.find(data => data.key == resp)).key);

      })
=======
    let contact = event.value ? event.value : event;
    let year = this.dashboardForm.get("year").value;

    if (contact) {
      this.fetchCurrentMonth(contact, year);
      this.dashboardForm.get("currentMonth").reset();
      this.dashboardForm.get("processedMonth").reset();
      //this.dashboardForm.get('uwYear').setValue((this.yearList.find(data => data.key == year)).key);
      // this.accountDashboardService.getUwYear(ApiUrls.QS_ACNT_MGMT, contact).subscribe(resp => {
      //   //this.dashboardForm.patchValue({ year: resp });
      //   if (resp) {
      //     this.fetchCurrencyMonth(contact, resp);
      //   }
      //   this.dashboardForm.get("currentMonth").reset();
      //   this.dashboardForm.get("processedMonth").reset();
      //   // this.dashboardForm.patchValue({
      //   //   currentMonth: '',
      //   //   processedMonth: '',
      //   // });
      //   this.dashboardForm.get('uwYear').setValue((this.yearList.find(data => data.key == resp)).key);

      // })
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    } else {
      this.dashboardForm.reset();
    }
  }
<<<<<<< HEAD
  fetchCurrencyMonth(contract, year) {
    let data = { contract: contract, year: year };
    this.accountDashboardService.getCurrentMonth(data).subscribe(resp => {
    }, error => {
      this.minDate = this.currentMinDate = getFirstDayOfYear(year);
      this.patchCurrenctMonth(error.error.text, year);
    })
  }
  patchCurrenctMonth(month, year) {
    month = month.toLowerCase();
    var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
    month = months.indexOf(month);
    const date = new Date(year, month, 1)
    this.maxDate = new Date(moment(date).endOf('month').format('YYYY-MM-DD hh:mm'));
    // this.dashboardForm.get('currentMonth').setValue(this.maxDate);
=======
  getAllContractByYear(event, from) {
    let year = event.value ? event.value : event;
    this.loaderService.isBusy = true;
    this.accountDashboardService.getAllContractByYear(year).subscribe(resp => {
      this.contractList = resp;
      if (from == 'AccView') {
        //let currMonth =  this.accountProcess.currentMonth +'-' + this.accountProcess.year;
        let month = this.accountProcess.currentMonth.toLowerCase();
        var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
        month = months.indexOf(month);
        const date = new Date(this.accountProcess.year, month, 1)
        let currMonth = new Date(moment(date).endOf('month').format('YYYY-MM-DD hh:mm'));
        let processmonth = this.accountProcess.processedMonth.toLowerCase();
        var procesmonths = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
        processmonth = procesmonths.indexOf(processmonth);
        const date1 = new Date(this.accountProcess.year, processmonth, 1)
          let proceMonth = new Date(moment(date1).endOf('month').format('YYYY-MM-DD hh:mm'));
          this.dashboardForm.patchValue({
            contract: this.accountProcess.contract,
            year: this.accountProcess.year,
            uwYear: this.accountProcess.uwYear,
            currentMonth: currMonth,
            processedMonth: proceMonth
        })  
        
        //this.getContractLists(this.accountProcess.contract)
        this.doSearch('AccView');
        //this.getAllData(this.accountProcess);
        //localStorage.removeItem('AccountingProcess');        
        sessionStorage.removeItem('AccountingProcess');
      } else {
        this.dashboardForm.get("contract").reset();
        this.dashboardForm.get("currentMonth").reset();
        this.dashboardForm.get("processedMonth").reset();
        this.loaderService.isBusy = false;
      }
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  fetchCurrentMonth(contract, year) {
    let data = { contract: contract, year: year };
    this.accountDashboardService.getCurrentMonth(data).subscribe(resp => {
      //this.patchCurrentMonth(resp, year)
    }, error => {
      this.minDate = this.currentMinDate = getFirstDayOfYear(year);
      this.patchCurrentMonth(error.error.text, year);
    })
  }
  patchCurrentMonth(month, year) {
    month = month.toLowerCase();
    var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
    month = months.indexOf(month);
    const date = new Date(year, month, 1);
    if (this.contractMonthFlag) {
      this.maxDate = new Date(moment(date).endOf('month').format('YYYY-MM-DD hh:mm'));
    } else {
      this.maxDate = getLastDayOfYear(year);
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  onValueChangeProcessed(event) {
    if (event != undefined) {
      this.dashboardForm.get('processedMonth').reset();
      let day = moment(event).endOf('month').format('DD');
      let month = moment(event).format('MM');
      let year = moment(event).format('YYYY');
      this.currentMinDate = getMinDateForCurrentMonth(day, month, year);
<<<<<<< HEAD
      this.currentmaxDate = getMaxDateForCurrentMonth(day, month, year);
=======
      this.currentmaxDate = getMaxDateForCurrentMonth(day, month, year, this.contractMonthFlag);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup['controls']).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  showDialogbox() {
<<<<<<< HEAD
=======
    //this.fetchReinsurer();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.open(this.approveModal1, 1, 'modal-sm');
  }
  showViewAccounting() {
    let contract = this.dashboardForm.get('contract').value;
<<<<<<< HEAD
    let obj = contract.split('~');
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'refNo': obj[0], 'seqNo': obj[1], 'docType': 'QS_ACNT', 'amendNo': obj[2] } });
=======
    sessionStorage.setItem('AccountingProcess', JSON.stringify(this.searchObj));
    //localStorage.setItem("AccountingProcess",JSON.stringify(this.searchObj));
    let obj = contract.split('~');
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'refNo': obj[0], 'seqNo': obj[1], 'docType': 'QS_ACNT', 'amendNo': obj[2], 'batchId': this.batchId } });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val, backdrop: true, ignoreBackdropClick: true });
  }
  closeModal(id: number) {
    this.modalService.hide(id);
  }
}
function getFirstDayOfYear(year) {
  return new Date(year, 0, 1);
}
function getLastDayOfYear(year) {
  return new Date(year, 11, 31);
}
function getMinDateForCurrentMonth(day, month, year) {
  if (month == "01") {
    return new Date(year, month - 1, 1);
  } else {
    return new Date(year, 0, 1);
  }
}
<<<<<<< HEAD
function getMaxDateForCurrentMonth(day, month, year) {
  if (month == "01") {
    return new Date(year, month - 1, day);
  } else {
    return new Date(year, month - 2, day);
=======
function getMaxDateForCurrentMonth(day, month, year, flag) {
  if (flag) {
    if (month == "01") {
      return new Date(year, month - 1, day);
    } else {
      return new Date(year, month - 2, day);
    }
  } else {
    return getLastDayOfYear(year);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
}
function currencyDecimalFormatter(arg0: any): any {
  if (arg0 != null) {
    return Intl.NumberFormat('en-US',
      { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format((arg0));
  } else {
    return;
  }
}

