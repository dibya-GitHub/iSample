import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AccountingDashboardService {
    treatyUrl: any = environment.treatyBaseUrl;
    mgaUrl: any = environment.mgaUrl;

    constructor(
        private _httpService: HttpClient,
    ) {
    }
    getProductCalc(data): Observable<any> {
        return this._httpService.get(this.treatyUrl + 'qs_acnt-mgmt/get-cmonth-data-calc/' + data.contract + '/' + data.year + '/' + data.processedMonth + '/' + data.currentMonth);
    }
    fetchDataFromApplicableCompanie(data) {
        return this._httpService.get(this.treatyUrl + 'qs_acnt-mgmt/get-cmonth-show-data-reins/' + data.contract + '/' + data.year + '/' + data.processedMonth + '/' + data.currentMonth + '/' + data.reinsurer);
    }
    fetchReinsurer(data) {
        return this._httpService.get(this.treatyUrl + 'qs_acnt-mgmt/get-appl-comp/' + data.contract + '/' + data.year + '/' + data.companyCode);
    }
    fetchAllContracts(path: any): Observable<any> {
        return this._httpService.get(this.treatyUrl + path + "/get-all-contract-id");
    }
    getUwYear(path: any, data) {
        return this._httpService.get(this.treatyUrl + path + "/get-uwyear/" + data);
    }
    retrieveContractYear(path: string): Observable<any> {
        return this._httpService.get<any>(this.treatyUrl + path + "/" + ApiUrls.TREATY_MAPPING_PATH + "/year");
    }
    doApprove(data, body): Observable<any> {
        return this._httpService.post(this.treatyUrl + 'qs_acnt-mgmt/approve-qs-contract/' + data.contract + '/' + data.year + '/' + data.currentMonth, body);
    }
<<<<<<< HEAD
    getCurrentMonth(data){
        return this._httpService.get(this.treatyUrl + 'qs_acnt-mgmt/get-current-month/' + data.contract + '/' + data.year);
    }
=======
    getCurrentMonth(data) {
        return this._httpService.get(this.treatyUrl + 'qs_acnt-mgmt/get-current-month/' + data.contract + '/' + data.year);
    }
    getAllContractByYear(year) {
        return this._httpService.get(this.treatyUrl + 'qs_acnt-mgmt/get-all-contract-id-by-uwyear/' + year);
    }
    getContractMonthFlag() {
        return this._httpService.get(this.treatyUrl + "/help-mgmt/get-contract-month-flag");
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
}
