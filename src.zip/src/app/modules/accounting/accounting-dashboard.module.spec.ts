import { AccountingDashboardModule } from './accounting-dashboard.module';

describe('AccountingDashboardModule', () => {
  let accountingDashboardModule: AccountingDashboardModule;

  beforeEach(() => {
    accountingDashboardModule = new AccountingDashboardModule();
  });

  it('should create an instance', () => {
    expect(accountingDashboardModule).toBeTruthy();
  });
});
