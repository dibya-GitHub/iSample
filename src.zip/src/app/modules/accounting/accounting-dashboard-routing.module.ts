import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountingDashboardComponent } from './accounting-dashboard/accounting-dashboard.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'accounting-dashboard',
    pathMatch: 'full'
  }, 
  {
    path: 'accounting-dashboard',
    component: AccountingDashboardComponent,
    data: {
      breadcrumb: { skip: true }
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountingDashboardRoutingModule { }
