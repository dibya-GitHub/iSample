import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/shared/shared.module';
import { AccountingDashboardRoutingModule } from './accounting-dashboard-routing.module';
import { AccountingDashboardComponent } from './accounting-dashboard/accounting-dashboard.component';
import { DropdownModule } from 'primeng/dropdown';
<<<<<<< HEAD
=======
import { TabsModule } from 'ngx-bootstrap/tabs';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@NgModule({
  declarations: [
    AccountingDashboardComponent
  ],
  imports: [
    CommonModule,
    AccountingDashboardRoutingModule,
    SharedModule,
<<<<<<< HEAD
    DropdownModule
=======
    DropdownModule,
    TabsModule
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ]
})
export class AccountingDashboardModule { }
