<<<<<<< HEAD
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
=======
import { Component, OnInit, Input } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, Validators, UntypedFormControl } from '@angular/forms'
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { SessionStorageService } from 'angular-web-storage';
import { Inject } from '@angular/core';
import { ElementRef } from '@angular/core';
import { ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';


@Component({
  selector: 'app-trust-fund',
  templateUrl: './trust-fund.component.html',
  styleUrls: ['./trust-fund.component.css']
})
export class TrustFundComponent implements OnInit {
  addFlag: boolean = true;
  paginationPageSize: any;
  showForm: boolean = false;
  trustFundForm: UntypedFormGroup;
  columnDefs = [];
  rowData = [];
  @Input() trustFund
  @Input() refNo;
  @Input() seqNo;
  @Input() amendNo;
  @Input() action;
  private gridColumnApi: any;
  private gridApi: any;
  selectedData: any
  @ViewChild('confirmModal') confirmModal: ElementRef;
  @ViewChild('trigger') tr: ElementRef;
<<<<<<< HEAD
  constructor(
    private fb: UntypedFormBuilder,
=======
  constructor(private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,
<<<<<<< HEAD
    private modalService: BsModalService
    ) { }
=======
    private modalService: BsModalService) { }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  ngOnInit() {
    this.columnDefs = [
      {
        headerName: 'Trust Fund', field: 'tfFundDesc', sortable: true
      },

      {
        headerName: '%', field: 'tfFundPerc', editable: false,
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: 'Actions',
        field: 'actions',
        template:
          ` <a>
<<<<<<< HEAD
        <i class="fa fa-file-pen"  data-action-type="Edit"  title="Edit" aria-hidden="true"></i>
        <i class="fa fa-trash"  data-action-type="Delete"  title="Delete" aria-hidden="true"></i>
=======
        <i class="fa fa-file-pen"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        <i class="fa fa-trash fa-icon fa-danger" data-action-type="Delete" title="Delete" aria-hidden="true"></i>
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        </a>`
      },

    ];
    if ('edit' == this.action) {
      this.reterieveTrustfund();
    }
    this.createForm();

    this.paginationPageSize = 3;
  }

  createForm() {
    this.trustFundForm = this.fb.group({
      tfRefNo: '',
      tfSeqNo: '',
      tfAmendNo: '',
      tfLayer: 'Layer 1',
      tfFundCode: ['', Validators.required],
      tfFundPerc: '',
      tfStatus: '',
      tfCrUid: this.session.get('userId'),
      tfCrDt: new Date(),

    })
  }

  addNewTrust() {
    this.trustFundForm.reset();
    this.showForm = true;
    this.addFlag = false;
  }
  reterieveTrustfund() {
    let obj = {
      tfRefNo: this.refNo,
      tfAmendNo: this.amendNo,
      tfSeqNo: this.seqNo,
      tfLayer: 'Layer 1',
    }

    this.treatyService.reterieveTrustFund(obj).subscribe(resp => {
      // let arr = [];
      console.table('trustfundListbyId', resp.trustFundList);
      this.rowData = resp.trustFundList;

    })
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");

      switch (actionType) {
        case "Edit":
          return this.onActionEditRow(data);
        case "Delete":
          return this.onActionRemoveRow(data);

      }
    }

  }
  public onActionEditRow(data: any) {

    let obj = {
      tfRefNo: data.mttyTrustFundPK.tfRefNo,
      tfSeqNo: data.mttyTrustFundPK.tfSeqNo,
      tfAmendNo: data.mttyTrustFundPK.tfAmendNo,
      tfLayer: data.mttyTrustFundPK.tfLayer,
      tfFundCode: data.mttyTrustFundPK.tfFundCode
    }
    this.treatyService.reterieveTrustById(obj).subscribe(resp => {
      let data = resp.trustFundList;
      this.trustFundForm.patchValue({
        tfRefNo: data.mttyTrustFundPK.tfRefNo,
        tfSeqNo: data.mttyTrustFundPK.tfSeqNo,
        tfAmendNo: data.mttyTrustFundPK.tfAmendNo,
        tfLayer: data.mttyTrustFundPK.tfLayer,
        tfFundCode: data.mttyTrustFundPK.tfFundCode,
        tfFundPerc: data.tfFundPerc,
        tfStatus: data.tfStatus,
        tfCrUid: this.session.get('userId'),
        tfCrDt: new Date(),
      })
      this.showForm = true;
      this.addFlag = false;
    })



  }

  public onActionRemoveRow(data: any) {
    this.selectedData = data;
    this.open(this.confirmModal, 'modal-sm');
  }
  saveTrustFund() {
    //const selectedRow = this.gridApi.getSelectedRows();
    if (this.trustFundForm.valid) {
      let temp = {
        mttyTrustFundPK:
        {
          tfRefNo: this.refNo,
          tfSeqNo: this.seqNo,
          tfAmendNo: this.amendNo,
          tfLayer: 'Layer 1',
          tfFundCode: this.trustFundForm.get('tfFundCode').value,
        },

        tfFundPerc: this.trustFundForm.get('tfFundPerc').value,
        tfStatus: 'A',
        tfCrUid: this.session.get('userId'),
        tfCrDt: new Date(),
      }
      this.loaderService.isBusy = true;
      this.treatyService.saveTrustFund(temp).subscribe(resp => {
        this.toastService.success("Successfully Saved");
        this.reterieveTrustfund();
        this.showForm = false;
        this.addFlag = true;
        this.loaderService.isBusy = false;
      }, error => {
      })
    } else {
      this.validateAllFormFields(this.trustFundForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  deleteTrustFund() {
    let data = this.selectedData;
    let obj = {
      tfRefNo: data.mttyTrustFundPK.tfRefNo,
      tfSeqNo: data.mttyTrustFundPK.tfSeqNo,
      tfAmendNo: data.mttyTrustFundPK.tfAmendNo,
      tfLayer: data.mttyTrustFundPK.tfLayer,
      tfFundCode: data.mttyTrustFundPK.tfFundCode
    }
    this.treatyService.deleteTrustById(obj).subscribe(resp => {
      let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
      element.click();
      this.toastService.success("Deleted Successfully");
      this.reterieveTrustfund();
    })

  }

  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  close() {
    this.showForm = false;
    this.addFlag = true;
  }
<<<<<<< HEAD
  closeModal(){
=======
  closeModal() {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.modalService.hide();
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
      if (control instanceof UntypedFormControl) {
=======
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTrustFundGrid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  Validations() {
    var tfFundPerc = parseFloat(this.trustFundForm.get('tfFundPerc').value);
    if (tfFundPerc > 100) {
      this.toastService.warning(" Percentage should not be greater than 100 ")
    } else if (tfFundPerc == 0) {
<<<<<<< HEAD
      this.toastService.warning(" Percentage should be  greater than 0 ");
=======
      this.toastService.warning(" Percentage should be greater than 0 ");
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }

}
