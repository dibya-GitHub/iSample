import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrustFundComponent } from './trust-fund.component';

describe('TrustFundComponent', () => {
  let component: TrustFundComponent;
  let fixture: ComponentFixture<TrustFundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrustFundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrustFundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
