<<<<<<< HEAD
import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { TreatyService } from 'src/app/shared/services/treaty.service';

=======
import { Component, OnInit, Input, Inject } from '@angular/core';
import { UntypedFormArray, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { SessionStorageService } from 'angular-web-storage';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-treaty-reinst',
  templateUrl: './treaty-reinst.component.html',
  styleUrls: ['./treaty-reinst.component.css']
})
export class TreatyReinstComponent implements OnInit {
  reinstItem: UntypedFormArray;
  reInstlCols = [];
  reInstDetails = [];
  reInstForm: UntypedFormGroup;
  @Input() action: any;
  @Input() amendNo: any;
  @Input() refNo: any;
  @Input() layer: any;
  showForm: boolean;
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
<<<<<<< HEAD
=======
    private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private session: SessionStorageService,
  ) { }

  ngOnInit() {
    this.reInstlCols = [
      { field: 'instlno', header: 'Reinstate No' },
      { field: 'value', header: 'Value' }

    ]
    this.reInstForm = this.fb.group({
      reInstList: this.fb.array([])
    })
    this.reteriveReInstByLayer()
  }
  createReinstForm(index) {
    // alert("Index"+index)
    return this.fb.group({
      tiRefNo: this.refNo,
      tiAmendNo: this.amendNo,
      tiLayer: this.layer,
      tiReinstNo: index,
      tiReinstPerc: '',
      tiStatus: 'A',
      tiCrUid: this.session.get('userId'),
      tiCrDt: '',
      tiUpdUid: '',
      tiUpdDt: ''
    });
  }

  reteriveReInstByLayer() {
    let obj = {
      tiRefNo: this.refNo,
      tiAmendNo: this.amendNo,
      tiLayer: this.layer
    }
    this.treatyService.reteriveReInstByLayer(obj).subscribe(resp => {
      this.reInstDetails = resp.reInstList
      console.log(resp.reInstList)
    })
  }

  addReinst(reinstNo) {
    const reinstItem = this.reInstForm.get('reInstList') as UntypedFormArray;
    let length = reinstItem.length
    if ("add" == this.action || "edit" == this.action) {
      // alert(1)
      for (var j = 0; j < length; j++) {
        //console.log("control 2 remove");
        reinstItem.removeAt(0);
      }
    }
    for (var i = 1; i <= reinstNo; i++) {
      // console.log("control 2 push");
      reinstItem.push(this.createReinstForm(i));
    }
    this.scriptcall('reinstate');

  }



  scriptcall(id) {
    //   $('#' + id).DataTable().destroy();
    // setTimeout(() => {
    //   $('#' + id).DataTable({paging: false,info:false}).draw();
    // }, 500);
  }

  get formData() { return this.reInstForm.get('reInstList'); }
}
