import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyReinstComponent } from './treaty-reinst.component';

describe('TreatyReinstComponent', () => {
  let component: TreatyReinstComponent;
  let fixture: ComponentFixture<TreatyReinstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyReinstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyReinstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
