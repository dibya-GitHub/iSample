<<<<<<< HEAD
import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as _ from 'lodash';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { DocumentComponent } from 'src/app/shared/components/document/document.component';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Utils } from 'src/app/utils';
import { EGNPComponent } from '../egnp/egnp.component';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
import { DirtyCheckerService } from './../../../../shared/services/dirty-checker.service';

declare var $: any;
=======
import { Component, OnInit, Inject, ViewChild, ElementRef, Output, EventEmitter, Input } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl, UntypedFormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { TreatyService } from 'src/app/shared/services/treaty.service';
//import { LocalService } from 'src/app/shared/message.service';
import { DatePipe } from '@angular/common';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
declare var $: any;
import * as moment from 'moment';
import { ToastService } from 'src/app/services/toast.service';
import { DocumentService } from 'src/app/shared/components/document/document.service';
import { EGNPComponent } from '../egnp/egnp.component';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
import { FacRiskPerilComponent } from '../fac-risk-peril/fac-risk-peril.component';
import { LoaderService } from 'src/app/services/loader.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ColDefUtil } from '@ag-grid-enterprise/all-modules';
//import { ReinsurersComponent } from 'src/app/treaty/reinsurers/reinsurers.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-contract-form',
  templateUrl: './contract-form.component.html',
  styleUrls: ['./contract-form.component.css'],
  providers: [DatePipe]
})
export class ContractFormComponent implements OnInit {
  userName: any;
  userList: any;
  url: any;
  variable: any;
  prgForm: UntypedFormGroup;
  showModal: boolean = false;
  prgmList: any = [];
  dashBoard: any;
  ContrctRef: any;
  RefErr: any = '';
  sDate: string;
  enddt: string;
  EndDateErr: boolean;
  startdt: string;
  showlabel: boolean = false;
  ishideElmnt: boolean = false;
  @ViewChild(EGNPComponent) child: EGNPComponent;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  @Output() retrieveSavedData = new EventEmitter();
  @Output() contractApplPolicy = new EventEmitter();
  contractForm: UntypedFormGroup;
  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() action: string;
  @Input() seqNo: number;

  treatyType: any = [];
  attachmentBasisList: any = [];
  contractType: any = [];
  currencyList: any = [];

  isValidDate: boolean;
  egnpAmt: number;
  showTab: boolean = false;
  status: string;
  xolType: string;

  baseCurr: string
  type: string;
  egnpDisplay: boolean = false;
  showbtn: boolean = false;

  userId: string;

  showBtnDiv: boolean = true;
  btnName: string = 'Save';

  layerbtnDiv: boolean = true;
  showReinsurerPremium: boolean = false;

  closeResult: string;
  loginCurr: any;
  disable: boolean = false;
  thCrDt: any;
  createdDate: string;
  currencyLabel: any;
  contType: any;
  contDataType: any;
  renewedLabel: string = 'Max Claim Notification Days';
  ProrataFlag: boolean = true;
  appPol: boolean;
  contTypeKey: any;
  contTypeVal: any;
  documents: any[];
  isDocumentNeedsToBeUpdated: boolean;
  isNew = true;
  documentTypes: any[];
  documentRefId: string;
  PolicyDetails: any;
  policyList: any;
  transactionSeriesId: any;
  transactionId: any;
  SIcurrency: any;
  premCurrency: any;
  @Input() amndSrNo;
<<<<<<< HEAD
  baseCurrencyCode: any;
  buyRate1: any;
  @ViewChild(DocumentComponent) uploadDoc: DocumentComponent;

  reportingPeriodFlag: boolean = false;
  reportPeriodList: any = [];
  reportingFlg: boolean = false;
  FreqList: any;
  constructor(
    private fb: UntypedFormBuilder,
=======
  @Input()
  facXol: boolean = true;
  reportingFlg: boolean = false;
  FreqList: any;
  facXolform: boolean = false;
  get docRefId() {
    if (this.refNo && this.amendNo && this.seqNo && !this.isNew) {
      return this.refNo + this.amendNo + this.seqNo;
    } else {
      return;
    }
  }

  constructor(private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private treatyService: TreatyService,
    private route: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private datePipe: DatePipe,
<<<<<<< HEAD
    private modalService: BsModalService,
    private wizardHelperService: TreatyWizardHelperService,
    private dirtyChecker: DirtyCheckerService
=======
    private wizardHelperService: TreatyWizardHelperService, //private localService: LocalService
    private docService: DocumentService,
    private modalService: BsModalService
  ) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032


<<<<<<< HEAD
  ) {
    this.getBaseCurrencies();
=======
  open(content, val) {
    this.modalService.show(content, { class: val });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  ngOnInit() {
    if (this.refNo == undefined) {
      this.documentRefId = Utils.makeRandomWord('CONT-', 32);
    }
    this.createdDate = this.datePipe.transform(new Date(), ApiUrls.Contract_Form_Date)

    this.userId = this.session.get('userId');
    this.contType = this.treatyService.getParamValue('type');
    this.status = this.treatyService.getParamValue('status');
    this.loginCurr = this.session.get('baseCurrency');
    this.dashBoard = this.session.get('userDashboard')
    this.baseCurr = this.loginCurr;
    // if (this.contType == 'FP') {
    //   this.appPol = true;     
    //   this.facXolform = false;
    //   this.facXol = true;
    // } else if (this.contType == 'FX') {      
    //   this.facXol = false;
    //   this.appPol = false;
    //   this.facXolform = true;
    // } else {
    //   this.facXol = true;      
    //   this.facXolform = false;
    // }
    this.contractTypeFunc();
    this.ContractForm();
    this.dropdownServices();
    this.contractValidiations();
    this.reteriveProgrameList('');
    this.getDocumentTypes();

    this.treatyService.reterieveUWriterList().subscribe(resp => {
      this.userList = resp.userList;
      this.setCreatedUserName(this.userId);

    }, error => { });
    if (this.seqNo > 1) {
      //alert();
      this.contractForm.patchValue({
        thRefNo: this.refNo
      });
      this.disable = true;
    } else { this.disable = false; }

    if ('edit' === this.action) {
      this.contractTypeFunc();
      this.editTreatyForm();
      this.btnName = 'Update';
      this.disable = true;
      this.isNew = false;
    } else if ('view' === this.action) {
      this.btnName = 'Update';
      this.disable = false;
      this.editTreatyForm();
      this.contractForm.disable();
      this.isNew = false;
    } else if ('addsequnce' === this.action) {
      this.contractTypeFunc();
      this.editTreatyForm();
      this.btnName = 'add';
      this.disable = true;
      this.isNew = false;
    }
  }
  ngAfterViewInit() {
    window.scrollTo(0, 0);
  }
  getBaseCurrencies() {
    this.treatyService.getBaseCurrencyDivision()
      .subscribe(data => {
        this.baseCurrencyCode = data;
        this.session.set('baseCurrencyCode', JSON.stringify(this.baseCurrencyCode));
        this.baseCurrencyCode = JSON.parse(this.session.get('baseCurrencyCode')).baseCurrency1;
        console.log(this.baseCurrencyCode);

      });
  }
  setCreatedUserName(userId: string) {
    if (this.userList) {
      const createdUser = this.userList.find(user => user.key === userId);
      this.userName = createdUser.value;
    }
  }

  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }
  getDocumentTypes() {

    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res;
      }, err => {
      });
  }

  dropdownServices() {
    this.treatyService.appCodesList(ApiUrls.NON_PROPORTIONAL_TREATY_TYPE).subscribe(resp => {
      this.treatyType = resp.appcodeList;
    })
    this.treatyService.appCodesList(ApiUrls.ATTACHMENT_BASIS_TYPE).subscribe(resp => {
      this.attachmentBasisList = resp.appcodeList;
    })

    this.treatyService.retrievecurrencyList().subscribe(resp => {
      this.currencyList = resp.currencyList;
    });
    this.treatyService.reteriveProgrameList('PROGRAMME').subscribe(resp => {
      this.prgmList = resp.appcodeList;
    }, error => { });
    // this.ngAfterViewInit();
    this.treatyService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
      this.reportPeriodList = resp;
    }, error => { });
  }

  ContractForm() {
    this.contractForm = this.fb.group({
      thRefNo: ['', Validators.required],
      thSeqNo: this.seqNo,
      thAmendNo: '0',
      thTtyDesc: ['', Validators.required],
      thStartDt: ['', Validators.required],
      thEndDt: ['', Validators.required],
      thUwYear: '',
      thContractType: ['', 'FP' === this.contractType ? '' : Validators.required],
      thAttachBasis: [undefined],
      thXlType: [undefined],
      thCurr: [this.baseCurrencyCode, Validators.required],
      thEpiAmt: '',
      thFixedRate: '',
      thAdjustPeriod: '',
      thClmNotifyDays: '',
      thRemarks: [''],
      thCrUid: this.userId,
      thCrDt: this.datePipe.transform(new Date(), ApiUrls.DATE_FORMAT),
      thApprUid: undefined,
      thApprDt: undefined,
      ttyHdrPK: '',
      thStatus: 'A',
      thApprSts: 'P',
      thProgCode: '',
      thXolDesc: '',
      thContractTypeDesc: '',
      thPolNo: [, this.appPol ? Validators.required : ''],
      thPolSeqNo: [, this.appPol ? Validators.required : ''],
      thPolUwYear: [, this.appPol ? Validators.required : ''],
      thFlex01: undefined,
      thFlex02: undefined,
      thFlex03: undefined,
      thFlex04: undefined,
      thFlex05: undefined,
      thFlex06: undefined,
      thFlex07: undefined,
      thFlex08: undefined,
      thLloydsSrpRegion: '',
      thLloydsSrpClass: '',
      thLloydsSrpReinst: '',
      thPrvContRefNo: undefined,
      thPrvContAmendNo: undefined,
      thPrvContSeqNo: undefined,
      thPlaLimit: undefined,
<<<<<<< HEAD
      thClaLimit: undefined,
      thNoOfAdj: undefined,
      thRepPeriod : undefined,
      thRepPeriodUnit : undefined
      // thAcStmtFreq: [undefined, Validators.required],
=======
      thNoOfAdj: undefined,
      thFlex10: undefined,
      thRepPeriod: undefined,
      thRepPeriodUnit: undefined,
      thPolBroker: undefined,
      thPolType: undefined,
      thCedent: undefined,
      thPolAssured: undefined,
      thSiAmnt: undefined,
      thPremAmnt: undefined,
      thSiCurr: undefined,
      thPremCurr: undefined

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    })
  }
  contractTypeFunc() {
    this.treatyService.appCodesList(ApiUrls.CONTRACT_TYPE).subscribe(resp => {
      this.contractType = resp.appcodeList;
      for (var i = 0; i < this.contractType.length; i++) {
        this.contTypeKey = this.contractType[i].key;
        if (this.contType == this.contTypeKey) {
          this.contTypeVal = this.contractType[i].item_text;
          this.contractForm.patchValue({
            thContractType: this.contTypeKey
          })
        }
      }
    })
  }
  editTreatyForm() {

    this.loaderService.isBusy = true;

    this.treatyService.retrieveContractDetails(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      let result = resp.treatyArray;
      // this.localService.sendMessage(result.thXlType);
      this.xolType = result.thXlType;
      // alert('xolType'+this.xolType);
      this.type = result.thXlType;
      // alert('type'+this.type);
      this.egnpAmt = result.thEpiAmt;
      this.baseCurr = result.thCurr;
      if (result && result.thFlex05) {
        this.documentRefId = result.thFlex05;
      }
      this.contractForm.patchValue(result);
      this.contractForm.patchValue({
        thRefNo: result.ttyHdrPK.thRefNo,
        thStartDt: this.datePipe.transform(result.thStartDt, ApiUrls.DATE_FORMAT),
        thEndDt: this.datePipe.transform(result.thEndDt, ApiUrls.DATE_FORMAT),
        thCrDt: this.datePipe.transform(result.thCrDt, ApiUrls.DATE_FORMAT),
        thApprDt: this.datePipe.transform(result.thApprDt, ApiUrls.DATE_FORMAT),
      });
<<<<<<< HEAD
      this.SIcurrency = result.thFlex08;
      this.premCurrency = result.thFlex09;
      if(result.thContractType == 'TX' && result.thAttachBasis == 'RAD'){
=======
      this.SIcurrency = result.thContractType == 'FX' ? result.thSiCurr : result.thFlex08;
      this.premCurrency = result.thContractType == 'FX' ? result.thPremCurr : result.thFlex09;
      if (result.thContractType == 'TX' && result.thAttachBasis == 'RAD') {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.reportingFlg = true;
        this.contractForm.get('thRepPeriod').setValidators([Validators.required]);
        this.contractForm.get('thRepPeriod').updateValueAndValidity();
        this.contractForm.get('thRepPeriodUnit').setValidators([Validators.required]);
        this.contractForm.get('thRepPeriodUnit').updateValueAndValidity();
      } else {
        this.reportingFlg = false;
        this.contractForm.get('thRepPeriod').clearValidators();
        this.contractForm.get('thRepPeriod').updateValueAndValidity();
        this.contractForm.get('thRepPeriodUnit').clearValidators();
        this.contractForm.get('thRepPeriodUnit').updateValueAndValidity();
      }
      this.createdDate = this.datePipe.transform(result.thCrDt, ApiUrls.DATE_FORMAT),
        this.contractForm.patchValue({
          thRefNo: result.ttyHdrPK.thRefNo,
          thAmendNo: result.ttyHdrPK.thAmendNo,
          thSeqNo: result.ttyHdrPK.thSeqNo,
          thTtyDesc: result.thTtyDesc,
          thUwYear: result.thUwYear,
          thContractType: result.thContractType,
          thAttachBasis: result.thAttachBasis,
          thXlType: result.thFlex10 ? result.thFlex10 : result.thXlType,
          thCurr: result.thCurr,
          thEpiAmt: result.thEpiAmt,
          thFixedRate: result.thFixedRate,
          thAdjustPeriod: result.thAdjustPeriod,
          thClmNotifyDays: result.thClmNotifyDays,
          thRemarks: result.thRemarks,
          thCrUid: result.thCrUid,
          thCrDt: this.datePipe.transform(result.thCrDt, ApiUrls.DATE_FORMAT),
          thApprUid: result.thApprUid,
          // thApprDt: this.datePipe.transform(result.thApprDt, ApiUrls.DATE_FORMAT),
          thStatus: result.thStatus,
          thStartDt: this.datePipe.transform(result.thStartDt, ApiUrls.DATE_FORMAT),
          thEndDt: this.datePipe.transform(result.thEndDt, ApiUrls.DATE_FORMAT),
          thApprSts: result.thApprSts,
          ttyHdrPK: result.ttyHdrPK,
          thProgCode: result.thProgCode,
          thLloydsSrpRegion: result.thLloydsSrpRegion,
          thLloydsSrpClass: result.thLloydsSrpClass,
          thLloydsSrpReinst: result.thLloydsSrpReinst,
          thPrvContRefNo: result.thPrvContRefNo,
          thPrvContAmendNo: result.thPrvContAmendNo,
          thPrvContSeqNo: result.thPrvContSeqNo,
          thPlaLimit: result.thPlaLimit,
<<<<<<< HEAD
          thClaLimit: result.thClaLimit,
          thNoOfAdj: result.thNoOfAdj,
          thRepPeriod: result.thRepPeriod,
          thRepPeriodUnit : result.thRepPeriodUnit,
=======
          thNoOfAdj: result.thNoOfAdj,
          thRepPeriod: result.thRepPeriod,
          thRepPeriodUnit: result.thRepPeriodUnit,
          thFlex01: result.thContractType == 'FX' ? this.datePipe.transform(result.thStartDt, ApiUrls.DATE_FORMAT) : '',
          thFlex02: result.thContractType == 'FX' ? this.datePipe.transform(result.thEndDt, ApiUrls.DATE_FORMAT) : '',
          thPolAssured: result.thPolAssured,
          thPolNo: result.thPolNo
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        });
      this.setCreatedUserName(result.thCrUid);
      this.createdDate = this.datePipe.transform(result.thCrDt, ApiUrls.Contract_Form_Date)

      //this.retrieveSavedData.emit(result);
      this.contractForm.get('thContractType').disable();
      // this.contractForm.get('thRefNo').disable();
      this.loaderService.isBusy = false;
      this.showTab = true;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  missingDocType: boolean = false

  checkDocType() {
    let docType = this.uploadDoc.unsavedFiles
    for (var i = 0; i < docType.length; i++) {
      if (docType[i].entityRefType == undefined) {
        return this.missingDocType = true;

      }
<<<<<<< HEAD
    }
  }
  saveForm() {
    this.contractForm.get('thContractType').enable();
    // this.contractForm.get('thXlType').enable();
    // this.contractForm.get('thAttachBasis').enable();
    if (this.RefErr === '') {
      if (this.contractForm.valid) {
        var dirty = this.dirtyChecker.validateDirtyCheck(this.contractForm);
        this.missingDocType = false;
        this.checkDocType();
        if (this.uploadDoc.unsavedFiles.length >= 0 && this.missingDocType == false) {
          if (this.uploadDoc.fileList.length !== 0) {
            this.uploadDoc.saveAllDocument();
          }
          this.loaderService.isBusy = true;
          const contractData = this.contractForm.value;
          contractData.thStartDt = moment(this.contractForm.get('thStartDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
          contractData.thEndDt = moment(this.contractForm.get('thEndDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
          // contractData.thApprDt = contractData.thEndDt;
          contractData.thCrDt = moment(this.contractForm.get('thCrDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
          let pla = this.contractForm.get("thPlaLimit").value;
          let cla = this.contractForm.get("thClaLimit").value;
          let thPlaLimit = pla ? parseFloat(pla) : 0;
          let thClaLimit = cla ? parseFloat(cla) : 0;
          // contractData.amndSrNo = this.amndSrNo;
          contractData.thFlex05 = this.documentRefId;
          if ('edit' === this.action) {
            if (thClaLimit >= thPlaLimit || this.contType != 'TP') {
              delete contractData.thApprDt;
              this.treatyService.updateTreatyContract(contractData, this.amndSrNo).subscribe(resp => {
                if (dirty) {
                  this.toastService.success('Successfully Saved');
                }
                this.treatyService.myMethod(this.contractForm.value);
=======
      this.loaderService.isBusy = true;
      const contractData = this.contractForm.value;
      contractData.thStartDt = moment(this.contractForm.get('thStartDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      contractData.thEndDt = moment(this.contractForm.get('thEndDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      contractData.thApprDt = contractData.thEndDt;
      contractData.thCrDt = moment(this.contractForm.get('thCrDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      // contractData.amndSrNo = this.amndSrNo;
      let xolType = contractData.thXlType;
      if (xolType == 'CXLD') {
        contractData.thXlType = 'CXL';
        contractData.thFlex10 = xolType;
      } else {
        contractData.thXlType = xolType;
        contractData.thFlex10 = xolType;
      }

      if (contractData.thContractType == 'FX') {
        contractData.thFlex01 = moment(this.contractForm.get('thFlex01').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
        contractData.thFlex02 = moment(this.contractForm.get('thFlex02').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      }

      if ('edit' === this.action) {
        console.log(contractData)
        this.treatyService.updateTreatyContract(contractData, this.amndSrNo).subscribe(resp => {
          this.toastService.success('Successfully Saved');
          this.treatyService.myMethod(this.contractForm.value);
          this.retrieveSavedData.emit(this.contractForm.value);
          this.wizardHelperService.goNext();
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        contractData.ttyHdrPK = {
          thRefNo: this.contractForm.get('thRefNo').value,
          thAmendNo: '0',
          thSeqNo: this.contractForm.get('thSeqNo').value
        }
        console.log('.......', contractData);
        this.treatyService.saveTreatyContract(contractData).subscribe(resp => {

          // if (this.isDocumentNeedsToBeUpdated) {
          if (this.isNew && this.documents && (this.documents.length > 0)) {
            const gridFSIds = [];
            this.documents.forEach((document) => {
              gridFSIds.push(document.gridFSId);
            });
            this.docService.mapPolicy(
              gridFSIds,
              contractData.ttyHdrPK.thRefNo +
              contractData.ttyHdrPK.thAmendNo +
              contractData.ttyHdrPK.thSeqNo)
              .subscribe(res => {
                this.toastService.success('Successfully Saved');
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
                this.retrieveSavedData.emit(this.contractForm.value);
                this.wizardHelperService.goNext();
                this.loaderService.isBusy = false;
              }, error => {
                this.loaderService.isBusy = false;
                this.toastService.error(error.error.message);
              })
            } else {
              this.toastService.warning('CLA Limit should be equal or greater than PLA Limit');
              this.loaderService.isBusy = false;
            }
          } else {
<<<<<<< HEAD
            contractData.ttyHdrPK = {
              thRefNo: this.contractForm.get('thRefNo').value,
              thAmendNo: '0',
              thSeqNo: this.contractForm.get('thSeqNo').value
            }
            if (thClaLimit >= thPlaLimit) {
              delete contractData.thApprDt;
              this.treatyService.saveTreatyContract(contractData).subscribe(resp => {
                if (dirty) {
                  this.toastService.success('Successfully Saved');
                }
                this.retrieveSavedData.emit(this.contractForm.value);
                this.wizardHelperService.goNext();
                this.loaderService.isBusy = false;
=======
            this.toastService.success('Successfully Saved');
            this.retrieveSavedData.emit(this.contractForm.value);
            this.wizardHelperService.goNext();
            this.loaderService.isBusy = false;
          }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

              }, error => {
                this.loaderService.isBusy = false;
                this.toastService.error(error.error.message);
              })
            } else {
              this.toastService.warning('CLA Limit should be equal or greater than PLA Limit');
              this.loaderService.isBusy = false;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.warning('Save All Uploaded Documents');
        }

      } else {
        this.validateAllFormFields(this.contractForm);
        this.retrieveSavedData.emit('error');
        this.toastService.warning('Enter Mandatory fields');
      }
    } else {
      this.loaderService.isBusy = false;
      this.toastService.warning('Contract Already Exists');
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      // this.toastService.add({severity:'error',summary: field +' is '+ control.status});
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  validateDates(eDate) {
    const context = this;
    setTimeout(() => {
      //this.contractForm.get('thStartDt').value;
      const sDate = context.contractForm.get('thStartDt').value;
      eDate = context.contractForm.get('thEndDt').value;
      context.isValidDate = true;
      if ((!sDate || !eDate)) {
        context.isValidDate = false;
        return;
      }
      const mStartDate = moment(sDate);
      const mEndDate = (typeof (eDate) === 'string') ? moment(eDate, 'DD/MM/YYYY') : moment(eDate);
      const isBefore = mEndDate.isSameOrBefore(mStartDate);
      if (mStartDate && mEndDate && isBefore) {
        context.isValidDate = false;
        context.EndDateErr = true;
      } else {
        context.EndDateErr = false;
      }
    }, 200);
  }
  minDate: any;
  setUwYear(value) {
    if (value) {
      const startDate = moment(value.getDate() + '/' + (value.getMonth() + 1) + '/' + value.getFullYear(), 'D/M/YYYY');
      //const startDate = moment(new Date());
      //alert(startDate);     
      const endDate = moment(startDate).add(1, 'year').add(-1, 'days');
      this.minDate = new Date(value.getFullYear(), value.getMonth(), value.getDate());
      const data = {
        thEndDt: endDate.format('DD/MM/YYYY'),
        thUwYear: startDate.format('YYYY')
      };
      this.contractForm.patchValue(data);
      this.setBaseCurrency(this.contractForm.get('thCurr').value);
    }

  }
  changeTab(event) {

    if ('0' == event.index) {
      this.layerbtnDiv = true;
      this.showReinsurerPremium = false;
    } else if ('1' == event.index) {
      this.layerbtnDiv = false;
      let obj = {
        refno: this.refNo,
        amendNo: this.amendNo,
        userId: this.userId
      }
      this.treatyService.retrieveReinstPro(obj).subscribe(resp => {
        this.showReinsurerPremium = true;
      }, error => {
      });
    }
  }

  showLayerBtn(data) {
    if ('Y' == data) {
      this.showbtn = true;
    } else {
      this.showbtn = false;
    }
  }

  stateChange(data) {
    this.action = data;
  }

  setContractRefNo(val) {
    if ('add' != this.action) {
      return false;
    }
    this.refNo = val;
    this.amendNo = '0';

    this.treatyService.checkCntrctRefNo(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      if (resp.messageType === 'F') {
        this.RefErr = resp.message;

      } else {
        this.RefErr = '';
      }
    }, error => {

    })
  }
  showReportingPeriod(evnt) {
    evnt.value == 'RAD' ? this.reportingPeriodFlag = true : this.reportingPeriodFlag = false;
  }
  setBaseCurrency(event) {
    setTimeout(() => {
      var currCode, dt, onDate;
      currCode = (typeof event === 'object') ? event.value : event;
      dt = this.contractForm.get('thStartDt').value;
      if (dt == null || dt == undefined || dt == "") {
        this.toastService.warning('Choose Accounting Date');
      } else {
        if (this.baseCurrencyCode) {
          onDate = moment(dt, 'DD-MM-YYYY').format('YYYY-MM-DD');
          this.treatyService.fetchExchangeRate(currCode, this.baseCurrencyCode, onDate).subscribe((data: any) => {
            this.buyRate1 = (_.isEmpty(data)) ? 0 : data.buyRate;
            if (this.buyRate1 == 0) {
              this.toastService.warning("Exchange Rate is not Available for the Contract Year.");
            }
            this.contractForm.get('thFixedRate').setValue(this.buyRate1);
          })
        }
      }
    }, 100);
  }
  Date(val) {
    this.startdt = this.contractForm.get('thStartDt').value;
    this.enddt = val;

    if (this.startdt >= this.enddt) {
      this.contractForm.patchValue({
        thEndDt: val
      })
    } else {
      this.EndDateErr = true;
    }
  }

  reteriveProgrameList(flag) {
    this.loaderService.isBusy = true;
    let type = 'PROGRAMME';
    this.treatyService.reteriveProgrameList(type).subscribe(resp => {
      this.prgmList = resp.appcodeList;
      // this.ngAfterViewInit();    
      if (flag)
        this.contractForm.get('thProgCode').setValue(this.prgForm.get('acCode').value);
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  showDialog() {
    this.createProgrameFrm();
    this.showModal = true;
    this.showDialogbox();
  }

  showDialogbox() {

    this.openDialog(this.confirmcontent, 'modal-lg');
  }

  openDialog(content, val) {
    this.modalService.show(content, { class: val });
  }
  createProgrameFrm() {
    this.prgForm = this.fb.group({
      acId: '',
      acInstId: '',
      acType: '',
      acCode: ['', Validators.required],
      acDesc: ['', Validators.required],
      acLongDesc: '',
      acCodeByLobYn: '0',
      prgCode: '',
      acCrUid: this.session.get('userId'),
      acCrDt: new Date(),
      acUpdUid: '',
      acUpdDt: ''
    })
  }

  savePrograme() {
    if (this.prgForm.valid) {
      let type = 'PROGRAMME';
      this.loaderService.isBusy = true;
      this.treatyService.savePrograme(type, this.prgForm.value).subscribe(resp => {
        this.toastService.success('Successfully Saved');
        this.reteriveProgrameList('Y');
        this.loaderService.isBusy = false;
        this.modalService.hide();
      }, error => {
        this.loaderService.isBusy = false;
      })
    } else {
      this.validateAllFormFields(this.prgForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }

  contractValidiations() {
    const thAttachBasis = this.contractForm.get('thAttachBasis');
    if (this.contType == 'TP') {
      this.ProrataFlag = false;
      this.appPol = false;
      this.currencyLabel = 'Contract Currency'
      this.renewedLabel = 'Renewed Form'
      // thAttachBasis.clearValidators();
    }
    else if (this.contType == 'TX') {
      this.currencyLabel = 'EGNPI Currency';
      this.showlabel = true;
      thAttachBasis.enable();
      this.contractForm.get('thXlType').enable();
      thAttachBasis.setValidators([Validators.required]);
      this.reportingPeriod();
    } else if (this.contType == 'FP') {
      this.showlabel = true;
      this.appPol = true;
      this.facXolform = false;
      this.facXol = true;
      this.currencyLabel = 'EGNPI Currency';
      this.contractForm.get('thAttachBasis').setValue('RAD');
      this.contractForm.get('thXlType').setValue('RXL');
      this.contractForm.get('thXlType').disable();
      this.contractForm.get('thAttachBasis').disable();
      thAttachBasis.clearValidators();
      this.getApplicablePolicy();

    } else if (this.contType == 'FX') {
      this.facXol = false;
      this.appPol = false;
      this.facXolform = true;
      this.showlabel = true;
      this.currencyLabel = 'GNPI Currency';
      this.contractForm.get('thAttachBasis').setValue('RAD');
      this.contractForm.get('thXlType').setValue('RXL');
      this.contractForm.get('thXlType').disable();
      this.contractForm.get('thAttachBasis').disable();
      thAttachBasis.setValidators([Validators.required]);
      //this.getApplicablePolicy();
    }
    // thAttachBasis.updateValueAndValidity();
  }

  back() {
    this.route.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
  }
  closeModal() {
    this.modalService.hide();
  }
  getApplicablePolicy() {
    this.treatyService.getPolicy().subscribe(resp => {
      this.policyList = resp;
    }, error => { });
  }

  getApplicablePolicyDetails(policyNo) {

    var policyNo = this.contractForm.get('thPolNo').value;
    // alert(policyNo)
    this.policyList.forEach((value, key) => {
      if (this.policyList[key].policyNo == policyNo) {
        this.transactionId = this.policyList[key].transactionId;
        this.transactionSeriesId = this.policyList[key].transactionSeriesId;
      }
    });
    this.treatyService.getPolicyDetails(this.transactionId, this.transactionSeriesId).subscribe(resp => {
      this.PolicyDetails = resp;
      this.SIcurrency = resp.sumInsuredCurrencyCode;
      this.premCurrency = resp.estimatedPremiumCurrencyCode
      this.contractForm.patchValue({
        thPolNo: resp.policyNumber,
        thPolSeqNo: resp.sequenceNumber,
        thPolUwYear: resp.underWritingYear,
        thFlex01: moment(resp.inceptionDate, "DD-MM-YYYY").format("DD/MM/YYYY"),
        thFlex02: moment(resp.expiryDate, "DD-MM-YYYY").format("DD/MM/YYYY"),
        thFlex03: resp.placingBrokerName,
        thFlex04: resp.cedant + '-' + resp.cedantName,
        thFlex05: resp.excessAmount,
        thFlex06: resp.sumInsuredAmount,
        thFlex07: resp.sumInsuredAmount,
        thFlex08: resp.sumInsuredCurrencyCode,
        thFlex09: resp.estimatedPremiumCurrencyCode
      })
    }, error => {
      this.toastService.error("Enter Valid policy");
    })
  }
<<<<<<< HEAD
  reportingPeriod(){
=======
  onChangeXolType(event) {
    let xol = event.value;
    if (xol == 'CXLD') {
      this.contractForm.patchValue({
        thXlType: 'CXL', thFlex10: xol
      });
    } else {
      this.contractForm.patchValue({
        thXlType: xol, thFlex10: xol
      });
    }
    console.log(xol);
  }
  reportingPeriod() {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.treatyService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
      this.FreqList = resp;
    }, error => { });
  }
<<<<<<< HEAD
  adjBasisOnChange(event){
    let value = event.value;  
    if(value == 'RAD'){
=======
  adjBasisOnChange(event) {
    let value = event.value;
    if (value == 'RAD') {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.reportingFlg = true;
      this.contractForm.get('thRepPeriod').setValidators([Validators.required]);
      this.contractForm.get('thRepPeriod').updateValueAndValidity();
      this.contractForm.get('thRepPeriodUnit').setValidators([Validators.required]);
      this.contractForm.get('thRepPeriodUnit').updateValueAndValidity();
    } else {
      this.reportingFlg = false;
      this.contractForm.get('thRepPeriod').clearValidators();
      this.contractForm.get('thRepPeriod').updateValueAndValidity();
      this.contractForm.get('thRepPeriodUnit').clearValidators();
      this.contractForm.get('thRepPeriodUnit').updateValueAndValidity();
      this.contractForm.get('thRepPeriod').reset();
      this.contractForm.get('thRepPeriodUnit').reset();
    }
<<<<<<< HEAD
  
=======

  }
  ngAfterViewInit() {
    window.scrollTo(0, 0);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
}
