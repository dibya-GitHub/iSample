import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
@Component({
  selector: 'app-treaty-perils',
  templateUrl: './treaty-perils.component.html',
  styleUrls: ['./treaty-perils.component.scss']
})
export class TreatyPerilsComponent implements OnInit {

  showPerilFrm: boolean;
  selectForm: any;
  defaultColDef: any;
  quickSearchValue: any;
  dropdownList: any;
  perilItem = [];
  perilData: any;
  dropdownSettings: {};
  perilCols = [];
  rowData = [];
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  deletePeril: any;
  gridColumnApi: any;
  gridApi: any;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  @Input() seqNo: any;
  @Input() refNo: any;
  @Input() amendNo: any;
  @Input() action: any;
  @Input() layerPriority: any;
  @Input() contType: any;
  @Input() amndSrNo: any;
  @Input() LayerData: any;
  @Input() year: any;

  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.perilCols = [
      {
        headerName: "Products",
        field: "perilDesc",
        tooltipField: 'perilDesc', sortable: true,
        valueGetter: function (params) {
          let paramStrings1 = params.data.perilDesc;
          return paramStrings1;
        },
      },
      { field: 'cedingBasisDesc', headerName: 'Ceding Basis', sortable: true },
      { field: 'cedingTypeDesc', headerName: 'Ceding Type', sortable: true },
      { field: 'tpLimit', headerName: 'Limit', valueFormatter: currencyFormatter, sortable: true, cellStyle: { textAlign: 'right' } },
      { field: 'tpPerc', headerName: 'Percentage', valueFormatter: currencyFormatter4, sortable: true, cellStyle: { textAlign: 'right' } },
      { field: 'tlCessionLimit', headerName: 'Cession Limit', valueFormatter: currencyFormatter, sortable: true, cellStyle: { textAlign: 'right' } },
      {
        headerName: 'Action',
        field: 'actions',
        filter: false,
        sortable: false,
        enableRowGroup: false,
        template:
          `<a>
          <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
         </a>&nbsp;
         <a>
          <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
         </a>`,
        cellStyle: { textAlign: 'center' }
      },
    ]
  }
  ngOnInit() {
    this.selectForm = this.fb.group({
      selectperil: [],
      peril: "",
      tpLimit: "",
      tpPerc: "",
      // tpLines: "",
      tlCessionLimit: ""
    });
    this.getPerilDetails(this.layerPriority.tlPriority);
  }
  back() {
    this.showPerilFrm = false;
    this.selectForm.reset();
  }
  showDialogbox() {
    this.open(this.confirmcontent, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
  }

  addPeril() {
    let cedingType;
    cedingType = this.layerPriority.tlCedingType;
    this.selectForm.reset();
    // this.selectForm.get('selectperil').value('');
    this.selectForm.patchValue({
      tlCessionLimit: this.layerPriority.tlCessionLimit,
    });
    if (cedingType == '01') { //Lines Only
      this.selectForm.get('tpPerc').disable();
      this.selectForm.get('tpLimit').disable();
      // this.selectForm.get('tpLines').enable();
      // this.selectForm.get('tpLines').setValue(this.layerPriority.tlLines);
    } else if (cedingType == '02') { //Percentage Only
      this.selectForm.get('tpPerc').setValue(this.layerPriority.tlPerc);
      this.selectForm.get('tpPerc').enable();
      this.selectForm.get('tpLimit').disable();
      // this.selectForm.get('tpLines').disable();
    } else if (cedingType == '03') { //Limits Only
      this.selectForm.get('tpPerc').disable();
      this.selectForm.get('tpLimit').enable();
      this.selectForm.get('tpLimit').setValue(this.layerPriority.tlLimit);
      // this.selectForm.get('tpLines').disable();
    } else if (cedingType == '04') { //Lines With Limits
      this.selectForm.get('tpPerc').disable();
      this.selectForm.get('tpLimit').enable();
      this.selectForm.get('tpLimit').setValue(this.layerPriority.tlLimit);
      // this.selectForm.get('tpLines').enable();
      // this.selectForm.get('tpLines').setValue(this.layerPriority.tlLines);
    } else if (cedingType == '05') { //Percentage with Limits
      this.selectForm.get('tpPerc').enable();
      this.selectForm.get('tpPerc').setValue(this.layerPriority.tlPerc);
      this.selectForm.get('tpLimit').enable();
      this.selectForm.get('tpLimit').setValue(this.layerPriority.tlLimit);
      // this.selectForm.get('tpLines').disable();
    }
    if (!this.layerPriority.tlPriority) {
      this.toastService.warning('Please Select the layer');
      return false;
    }

    this.action = 'Add';
    this.showPerilFrm = true;
    if (this.contType == 'FX') {
      this.treatyService.facXolPerilDropdown(this.refNo).subscribe(resp => {
        this.dropdownList = resp.riskList;

      }, error => {
        this.toastService.error("Error in Retrieving Product " + error);
      })
    } else if (this.contType == 'TP') {
      this.loaderService.isBusy = true;
      this.callQSdropdown();
    } else {
      this.loaderService.isBusy = true;
      this.dropdown();
    }
  }
  callQSdropdown() {
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      layer: this.layerPriority.tlPriority,
      year: this.year
    };
    this.treatyService.perilCodesForQS(obj).subscribe(resp => {
      if (resp.messageType == 'S') {
        this.dropdownList = resp.appcodeList;
        this.loaderService.isBusy = false;
      } else {
        this.loaderService.isBusy = false;
        this.dropdownList = [];
        this.toastService.error(resp.message);
      }
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    });
  }
  dropdown() {
    this.treatyService.perilCodesList1(this.refNo, this.seqNo, this.layerPriority.tlPriority).subscribe(resp => {
      this.dropdownList = resp;
      this.loaderService.isBusy = false;
    });
  }

  savePerils(layerNo) {
    this.loaderService.isBusy = true;
    var limit = this.selectForm.get('tpLimit').value ? this.selectForm.get('tpLimit').value.toString().replace(/,/g, '') : 0;
    var perc = this.selectForm.get('tpPerc').value ? this.selectForm.get('tpPerc').value.toString().replace(/,/g, '') : 0;
    var maxRec = this.selectForm.get('tlCessionLimit').value ? this.selectForm.get('tlCessionLimit').value.toString().replace(/,/g, '') : 0;
    // var tplines = this.selectForm.get('tpLines').value ? this.selectForm.get('tpLines').value.toString().replace(/,/g, '') : 0;
    let param = {
      tpRefNo: this.refNo,
      tpSeqNo: this.seqNo,
      tpAmendNo: this.amendNo,
      tpLayer: this.layerPriority.tlPriority,
      tpPeril: ""
    }
    let obj = {
      perilList: this.perilItem,
      tpStatus: "A",
      tpCrUid: this.session.get('userId'),
      tpCrDt: new Date(),
      tpLimit: limit,
      tpPerc: perc,
      // tpLines: tplines,
      tlCessionLimit: maxRec,
      tpUpdDt: new Date(),
      tpUpdUid: this.session.get('userId'),
      mttyPerilPK: param,
      ttyPerilPK: param
    };
    if (this.perilItem && this.perilItem.length > 0) {
      this.treatyService.savePerilDetails(obj, this.amndSrNo).subscribe(resp => {
        this.toastService.success("Successfully Saved");
        this.showPerilFrm = false;
        this.getPerilDetails(this.layerPriority.tlPriority);
        this.perilItem = [];
      }, error => {
        this.toastService.error("Error in saving Product");
        this.loaderService.isBusy = false;
      })
    } else {
      this.toastService.warning("Select atleast one Product");
      this.loaderService.isBusy = false;
    }
  }

  deletePerilDetails() {
    this.loaderService.isBusy = true;
    this.treatyService.deletePerilById(this.deletePeril.tpRefNo, this.deletePeril.tpPeril, this.deletePeril.tpAmendNo, this.deletePeril.tpLayer, this.deletePeril.tpSeqNo, this.amndSrNo).subscribe(resp => {
      this.getPerilDetails(this.layerPriority.tlPriority);
      this.modalService.hide();
      this.toastService.success("Product Deleted Successfully");
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
      this.modalService.hide();
    })
  }
  updatePeril(layer) {
    this.loaderService.isBusy = true;
    this.perilData.tpLimit = this.selectForm.get('tpLimit').value ? this.selectForm.get('tpLimit').value.toString().replace(/,/g, '') : 0;
    this.perilData.tpPerc = this.selectForm.get('tpPerc').value ? this.selectForm.get('tpPerc').value.toString().replace(/,/g, '') : 0;
    this.perilData.tlCessionLimit = this.selectForm.get('tlCessionLimit').value ? this.selectForm.get('tlCessionLimit').value.toString().replace(/,/g, '') : 0;
    // this.perilData.tpLines = this.selectForm.get('tpLines').value ? this.selectForm.get('tpLines').value.toString().replace(/,/g, '') : 0;
    this.perilData.tpUpdUid = this.session.get('userId');
    this.perilData.tpUpdDt = new Date();
    let param = {
      tpRefNo: this.refNo,
      tpSeqNo: this.seqNo,
      tpAmendNo: this.amendNo,
      tpLayer: this.layerPriority.tlPriority,
      tpPeril: ""
    }
    this.perilData.mttyPerilPK = param;
    this.perilData.ttyPerilPK = param;
    this.treatyService.updatedPeril(this.perilData.tpPeril, this.perilData, this.amndSrNo).subscribe(resp => {
      this.toastService.success("Product Updated Sucessfully");
      this.selectForm.reset();
      this.showPerilFrm = false;
      this.getPerilDetails(this.layerPriority.tlPriority);
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    });
  }
  getPerilDetails(layerNo) {
    this.loaderService.isBusy = true;
    this.treatyService.getSelectedPerilList(layerNo, this.refNo, this.amendNo, this.seqNo).subscribe((resp: any) => {
      this.rowData = resp;
      this.treatyService.setProductGridInfo(this.rowData);
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
    this.gridApi.sizeColumnsToFit();

  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("treaty_Grid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onBtExport() {
    if (this.gridApi) {
      let columnKeys = ['perilDesc', 'cedingBasisDesc', 'cedingTypeDesc', 'tpLimit', 'tpPerc', 'tlCessionLimit'];
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'treaty_products.xlsx',
        skipHeader: false,
        sheetName: 'Treaty Products',
        columnKeys: columnKeys,
      });
    }
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Delete":
          this.deletePeril = data;
          return this.showDialogbox();
        case "Edit":
          return this.editPeril(data);

      }
    }

  }
  editPeril(data) {
    let cedingType = this.layerPriority.tlCedingType;
    this.perilData = data;
    this.action = "Edit";
    this.showPerilFrm = true;
    this.selectForm.patchValue({
      peril: data.perilDesc,
      tpLimit: data.tpLimit,
      tpPerc: data.tpPerc,
      // tpLines: data.tpLines,
      tlCessionLimit: data.tlCessionLimit
    });
    if (cedingType == '01') { //Lines Only
      this.selectForm.get('tpPerc').disable();
      this.selectForm.get('tpLimit').disable();
      // this.selectForm.get('tpLines').enable();
      // this.selectForm.get('tpLines').setValue(this.layerPriority.tlLines);
    } else if (cedingType == '02') { //Percentage Only
      this.selectForm.get('tpPerc').setValue(data.tpPerc);
      this.selectForm.get('tpPerc').enable();
      this.selectForm.get('tpLimit').disable();
      // this.selectForm.get('tpLines').disable();
    } else if (cedingType == '03') { //Limits Only
      this.selectForm.get('tpPerc').disable();
      this.selectForm.get('tpLimit').enable();
      this.selectForm.get('tpLimit').setValue(data.tpLimit);
      // this.selectForm.get('tpLines').disable();
    } else if (cedingType == '04') { //Lines With Limits
      this.selectForm.get('tpPerc').disable();
      this.selectForm.get('tpLimit').enable();
      this.selectForm.get('tpLimit').setValue(data.tpLimit);
      // this.selectForm.get('tpLines').enable();
      // this.selectForm.get('tpLines').setValue(data.tpLines);
    } else if (cedingType == '05') { //Percentage with Limits
      this.selectForm.get('tpPerc').enable();
      this.selectForm.get('tpPerc').setValue(data.tpPerc);
      this.selectForm.get('tpLimit').enable();
      this.selectForm.get('tpLimit').setValue(data.tpLimit);
      // this.selectForm.get('tpLines').disable();
    }

  }
}
function currencyFormatter(params) {
  if (params != null) {
    return Intl.NumberFormat('en-US',
      { minimumFractionDigits: 2 }).format((params.value));
  } else { return '' }
}
function currencyFormatter4(params) {
  if (params != null) {
    return Intl.NumberFormat('en-US',
      { minimumFractionDigits: 4 }).format((params.value));
  } else { return '' }
}
