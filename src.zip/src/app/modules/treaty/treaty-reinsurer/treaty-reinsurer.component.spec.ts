import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/treaty/treaty-reinsurer/treaty-reinsurer.component.spec.ts
import { TreatyReinsurerComponent } from './treaty-reinsurer.component';

describe('TreatyReinsurerComponent', () => {
  let component: TreatyReinsurerComponent;
  let fixture: ComponentFixture<TreatyReinsurerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyReinsurerComponent ]
=======
import { PlaNotificationComponent } from './pla-notification.component';

describe('PlaNotificationComponent', () => {
  let component: PlaNotificationComponent;
  let fixture: ComponentFixture<PlaNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaNotificationComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/pla-notification/pla-notification.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/treaty/treaty-reinsurer/treaty-reinsurer.component.spec.ts
    fixture = TestBed.createComponent(TreatyReinsurerComponent);
=======
    fixture = TestBed.createComponent(PlaNotificationComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/pla-notification/pla-notification.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
