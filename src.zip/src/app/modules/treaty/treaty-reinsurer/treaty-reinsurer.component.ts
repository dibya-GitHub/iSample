import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent2 } from './../radiorender/radiorender2.component';

@Component({
  selector: 'app-treaty-reinsurer',
  templateUrl: './treaty-reinsurer.component.html',
  styleUrls: ['./treaty-reinsurer.component.scss']
})
export class TreatyReinsurerComponent implements OnInit {
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  quickSearchValue: any;
  hideAddFlag: boolean = true;
  private gridApi;
  private gridColumnApi;
  public summaryColumns;
  public columnDefs;
  defaultColDef: any;
  private defaultColGroupDef;
  private columnTypes;
  public rowData = [];
  bottomData: any[];
  private statusBar
  trReins: any;
  trLayer: any;
  trAmendNo: any;
  trRefNo: any;
  sharePerc: number;
  totShare: number;
  btnName: string = 'Save';
  totalPremium: number = 0;
  totalDepPremium: number = 0;
  showForm: boolean = false;
  @Input()
  details: any;
  cols: any[];
  isShowGrid: boolean;
  _layer: string;
  reinsurerList: any;
  sharePrem: number;
  share: number;
  totalShareFlag: boolean = false;
  DepFlag: boolean = true;
  AdjFlag: boolean = true;
  Val_Dep_Prem: boolean;
  Val_Adj_Rate: boolean;
  totalSharePerc: number = 0;
  pinnedBottomRowData: any[];
  getRowStyle: (params: any) => { 'font-weight': string; };
  broker: any;
  selectedReinsurer: any;
  layerReinsurer: any;
  set layer(value: string) {

    if (this._layer == value)
      return;
    this._layer = value;
  }
  @Input()
  get layer(): string {
    return this._layer;
  }
  @Input() action: any;
  @Input() amendNo: any;
  @Input() refNo: any;
  @Input() seqNo: number;
  @Input() amndSrNo: any;
  @Input() layerPriority: any;

  reBrkList: any;
  reInsList: any;
  accntList = [];
  reInsFrm: UntypedFormGroup;
  display: boolean = false;
  collapsed: boolean = true;
  headerTittle: string;
  private _minPremium: string;
  @Input() minPremium: string;

  @Input() depPremium;
  @Input() adjustRate;
  @Input() prem: any;
  @Input() depPremPerc;
  @Input() egnpiAmt;
  @Input() contractType;
  @Input() RateType;
  @Input() tlDesc: string;
  @Input() LayerData;
  @ViewChild('trigger') tr: ElementRef;

  @ViewChild('content') content: ElementRef;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;

  prem_label: string;
  public context;
  public frameworkComponents;
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private modalService: BsModalService,
    private session: SessionStorageService,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.defaultColDef = {
      resizable: true,
      enableRowGroup: true,
      sortable: true,
      editable: false
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
    this.retrieveAccntToList();
    this.retriveBrokerList();

  }

  ngOnInit() {

    this.document.body.scrollTop = 5;
    this.isShowGrid = true;
    if ('TP' == this.contractType) {
      this.columnDefs = [
        {
          headerName: "Select",
          field: 'trSrNo',
          cellRenderer: "radioButtonRenderer",
          cellStyle: { textAlign: 'center' },
          filter: false,
          sortable: false,
          enableRowGroup: false,
        },
        {
          field: 'trReins',
          headerName: 'Reinsurer',
          sortable: true,
          tooltipField: "reinsDesc",
          valueGetter: function (params) {
            if (params.data !== undefined) {
              return params.data.trReins + ' - ' + params.data.reinsDesc;
            }
          },
          filter: true,
        },
        {
          field: 'trBroker',
          headerName: 'Broker',
          sortable: true,
          tooltipField: "brokerDesc",
          valueGetter: function (params) {
            if (params.data && params.data.trBroker) {
              return params.data.trBroker + ' - ' + params.data.brokerDesc;
            } else {
              return "";
            }
          },
          filter: true
        },
        {
          field: 'trBrkRefNo',
          headerName: 'Reference',
          sortable: true,
          filter: true
        },
        {
          field: 'trAcntTo',
          headerName: 'Accounting To',
          sortable: true,
          filter: true,
          valueGetter: function (params) {
            if (params.data !== undefined) {
              return params.data.trAcntTo + ' - ' + params.data.trAcntDesc;
            }
          },
        },
        {
          field: 'trSharePerc',
          headerName: 'Share',
          sortable: true,
          cellStyle: { textAlign: 'right' },
          filter: true,
          valueFormatter: currencyFormatter4
        },
        {
          headerName: 'Action',
          field: 'actions',
          template:
            `<a>
          <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
         </a>&nbsp;
         <a>
          <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
         </a>`,
          cellStyle: { textAlign: 'center' },
          filter: false,
          sortable: false,
          enableRowGroup: false,
        },
      ];
    }
    this.statusBar = {
      statusPanels: [
        {
          statusPanel: "agTotalRowCountComponent",
          align: "right"
        },
        { statusPanel: "agFilteredRowCountComponent" },
        { statusPanel: "agSelectedRowCountComponent" },
        { statusPanel: "agAggregationComponent" }
      ]
    };
    this.createReInsForm();
    this.loadGrid();
    this.retrieveAccntTo();
    this.agGridOptions();
  }

  loadGrid() {
    this.showForm = false;
    this.details = [];

    if ("view" == this.action) {
      this.showForm = false;
    }

    this.reterieveReInsGrid();

  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent2
    };
  }
  selectedRowData1(cell) {
    this.selectedReinsurer = cell.data;
    this.layerReinsurer = this.selectedReinsurer.trReins;
    console.log(this.selectedReinsurer);
    // let srNo = this.selectedReinsurer.rowIndex;
    // console.log(srNo);

    // this.sendLOBDetail_Id.emit(SrNo);
    // this.lobRowDetailEvent.emit(this.selectedLob);
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
  }
  createReInsForm() {
    this.reInsFrm = this.fb.group({
      trId: [undefined],
      trReins: ['', Validators.required],
      trBroker: '',
      trAcntTo: ['', Validators.required],
      trSharePerc: [, Validators.required],
      trBrkRefNo: '',
      trStatus: 'P',
      trCrUid: this.session.get('userId'),
      trCrDt: new Date(),
      trUpdUid: '',
      trUpdDt: ''

    })
    if (this.RateType == 'FR') {
      this.reInsFrm.get('trAdjustRate').disable();
    }
  }

  retrieveReInsList(refNo) {
    this.loaderService.isBusy = true;
    this.treatyService.fetchReInsList(ApiUrls.REINS_MGMT_PATH, refNo).subscribe(resp => {
      this.reInsList = resp;
      this.loaderService.isBusy = false;
    }, error => { this.loaderService.isBusy = false; })
  }
  retriveBrokerList() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveBrokerList(ApiUrls.REINS_MGMT_PATH, 'RI_BRK').subscribe(resp => {
      this.reBrkList = (resp as any[]).map(brk => {
        brk.displayText = brk.customerCode + ' - ' + brk.customerName;
        return brk;
      });
      this.loaderService.isBusy = false;

    }, error => { this.loaderService.isBusy = false; })
  }
  retrieveAccntTo() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveAccntTo().subscribe(resp => {
      this.accntList = resp.appcodeList;
      this.loaderService.isBusy = false;
    }, err => {
      this.toastService.error('Error');
      this.loaderService.isBusy = false;
    })
  }

  save(buttonName) {
    this.reInsFrm.get('trReins').enable();
    this.reInsFrm.get('trBroker').enable();
    if (this.reInsFrm.valid) {
      this.loaderService.isBusy = true;
      var share = parseFloat(this.reInsFrm.get('trSharePerc').value);
      if (this.action == 'edit') {
        if (this.sharePerc == undefined) {
          this.sharePerc = 0;
        }
        var totSharPerc = this.sharePerc + share;
        if (totSharPerc > 100 && share != 0) {
          this.loaderService.isBusy = false;
          this.toastService.warning('Total share percentage cant greater than 100 %');
          return false;
        } else {
          this.reInsFrm.patchValue({
            trStatus: 'P',
            trUpdUid: this.session.get('userId'),
            trUpdDt: new Date(),
            trReins: this.reInsFrm.get('trReins').value,
          })
          const reinsData = this.reInsFrm.value;
          reinsData.trUpdUid = this.session.get('userId');
          reinsData.trUpdDt = new Date();
          reinsData.trRefNo = this.refNo;
          reinsData.trAmendNo = this.amendNo;
          reinsData.trLayer = this.layerPriority.tlPriority;
          reinsData.trSeqNo = this.seqNo;
          this.treatyService.updateReInsById(reinsData, this.amndSrNo).subscribe(resp => {
            this.toastService.success('Updated Successfully');
            this.reInsFrm.reset();
            if (buttonName == 'save') {
              this.showForm = false;
              this.hideAddFlag = true;
            } else {
              this.showForm = true;
              this.hideAddFlag = false;
              this.addReinsurer();
              this.reInsFrm.patchValue({
                trPrem: '',
                trDepPrem: '',
              })
            }
            this.totShare = 0;
            this.reterieveReInsGrid();

          }, error => {
            this.reInsFrm.get('trReins').disable();
            this.reInsFrm.get('trBroker').disable();
            this.loaderService.isBusy = false;
            this.toastService.error(error.error.message);
          })
        }

      } else {
        if (this.totShare == undefined) {
          this.totShare = 0;
        }
        let totSharPerc = this.totShare + share;
        if (totSharPerc > 100 && share != 0) {
          this.loaderService.isBusy = false;
          this.toastService.warning(' Total share percentage cant greater than 100 %');
          return false;
        } else {
          this.reInsFrm.patchValue({
            trStatus: 'P',
            trCrUid: this.session.get('userId'),
            trCrDt: new Date(),
            trUpdUid: this.session.get('userId'),
            trUpdDt: new Date(),
            trReins: this.reInsFrm.get('trReins').value,
          })
          const reinsData = this.reInsFrm.value;
          reinsData.trRefNo = this.refNo;
          reinsData.trAmendNo = this.amendNo;
          reinsData.trLayer = this.layerPriority.tlPriority;
          reinsData.trSeqNo = this.seqNo;
          this.treatyService.insertReinsrer(reinsData, this.amndSrNo).subscribe((resp: any) => {
            if (resp.messageType == 'W') {
              this.toastService.warning(resp.message);
            } else {
              this.toastService.success("Saved Successfully");
              this.reInsFrm.reset();
              this.showForm = false;
              this.hideAddFlag = true;
            }
            this.totShare = 0;
            this.reterieveReInsGrid();
          }, error => {
            this.loaderService.isBusy = false;
            this.toastService.error(error.error.message);
            this.reInsFrm.get('trReins').disable();
            this.reInsFrm.get('trBroker').enable();
          });
        }
      }
    } else {
      this.validateAllFormFields(this.reInsFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  reterieveReInsGrid() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: this.layerPriority.tlPriority,
      seqNo: this.seqNo
    }
    this.treatyService.retrieveReInsByLayer(obj).subscribe((resp: any) => {
      this.loaderService.isBusy = false;
      let share: number = 0;

      this.rowData = resp;
      if (this.rowData.length > 0) {
        this.context.componentParent.selectedRowId1 = this.rowData[0].trSrNo;
        this.selectedRowData1({ data: this.rowData[0] });
        for (var i = 0; i < this.rowData.length; i++) {

          let mimpre = (parseFloat(this.rowData[i].trSharePerc) * (parseFloat(this.minPremium))) / 100;
          let deppre = (parseFloat(this.rowData[i].trSharePerc) * (parseFloat(this.depPremium))) / 100;
          share = share + parseFloat(this.rowData[i].trSharePerc);
          this.totShare = share;
          this.rowData[i].minPremium = mimpre;
          this.rowData[i].depPremium = deppre;
          this.totalSharePerc = this.totalSharePerc + this.rowData[i].trSharePerc;
          this.totalPremium = this.totalPremium + this.rowData[i].trPrem;
          this.totalDepPremium = this.totalDepPremium + this.rowData[i].trDepPrem;
        }
        if (this.totShare != 0) { this.totalShareFlag = true }
      } else {
        this.totShare = 0;
        if (this.totShare != 0) { this.totalShareFlag = true }
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  // reinstSummaryDetails() {
  //   this.bottomData = [
  //     {
  //       reinsDesc: 'Total',
  //       brokerDesc: '',
  //       trAcntDesc: '',
  //       trAdjustRate: '',
  //       trSharePerc: this.totalSharePerc,
  //       trPrem: this.totalPremium,
  //       trDepPrem: this.totalDepPremium,
  //       action: '',
  //     }
  //   ];
  // }

  addReinsurer() {
    this.hideAddFlag = false;
    this.reInsFrm.get('trReins').enable();
    this.reInsFrm.get('trBroker').enable();
    this.retrieveReInsList(this.refNo);
    this.action = 'add'
    this.btnName = 'Save';
    this.showForm = true;
    if (this.reInsFrm.value != null) {
      this.reInsFrm.reset();
    }
  }

  back() {
    this.showForm = false;
    this.hideAddFlag = true;
  }

  edit(data: any) {
    this.action = 'edit';
    this.retrieveReInsList(this.refNo);
    this.showForm = true;
    this.hideAddFlag = false;
    this.btnName = 'Update';
    if (this.totShare > 0) {
      this.sharePerc = this.totShare - parseFloat(data.trSharePerc);
    } else {
      this.sharePerc = 0;
    }
    this.reinsurerList = data;
    var resp = data;
    if (resp.trBroker != null) {
      this.retrieveAccntTo();
    }
    this.reInsFrm.patchValue(data);
    // this.reInsFrm.get('trReins').setValue(data.trReins);
    this.reInsFrm.get('trReins').disable();
    this.reInsFrm.get('trBroker').disable();
  }

  fetchAddInfo(event) {
    event = event.value;
    this.treatyService.retrieveReInsAddlInfo(event).subscribe(resp => {
      this.retrieveAccntToList();
    })
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  loadAccTo() {
    this.retrieveAccntTo();
  }

  deleteReIns() {
    this.loaderService.isBusy = true;
    let obj = {
      trRefNo: this.trRefNo,
      trAmendNo: this.trAmendNo,
      trLayer: this.trLayer,
      trReins: this.trReins,
      trSeqNo: this.seqNo,
      broker: this.broker
    }
    this.treatyService.deleteReInsById(obj, this.amndSrNo).subscribe(resp => {
      this.toastService.success('Deleted Succcessfully');
      this.modalService.hide();
      this.showForm = false;
      this.reterieveReInsGrid();
      this.loaderService.isBusy = false;
      this.selectedReinsurer = undefined;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  retrieveAccntToList() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveAccntToList(ApiUrls.APP_CODES_MGMT_PATH).subscribe(resp => {
      this.accntList = resp.appcodeList;
      this.loaderService.isBusy = false;
    }, err => {
      this.toastService.error("Error in fetching Accounting To");
    })
  }

  showDialogbox(reInsInfo: any) {
    this.trRefNo = reInsInfo.trRefNo,
      this.trAmendNo = reInsInfo.trAmendNo,
      this.trLayer = reInsInfo.trLayer,
      this.trReins = reInsInfo.trReins,

      this.open(this.confirmcontent, 'modal-sm');
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("treaty_Grid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.edit(data);
        case "Delete":
          this.broker = data.trBroker
          return this.showDialogbox(data);
      }
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  onBtExport() {
    if (this.gridApi) {
      let columnKeys = ['trReins', 'trBroker', 'trBrkRefNo', 'trAcntTo', 'trSharePerc'];
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'treaty_reinsurer.xlsx',
        skipHeader: false,
        sheetName: 'Treaty Reinsurer',
        columnKeys: columnKeys,
      });
    }
  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
    this.gridApi.sizeColumnsToFit();

  }
}
function currencyFormatter(params) {
  if (params && params.value != null && params.value != undefined) {
    let vl = parseFloat(params.value);
    return vl.toFixed(2);
  } else {
    return '';
  }
}
function currencyFormatter4(params) {
  if (params && params.value != null && params.value != undefined) {
    let vl = parseFloat(params.value);
    return vl.toFixed(4);
  } else {
    return '';
  }
}