<<<<<<< HEAD
import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
=======
import { Component, OnInit, Input, ViewChild, AfterViewInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { SessionStorageService } from 'angular-web-storage';
import { Inject } from '@angular/core';
import { ApiUrls } from 'src/app/api-urls';
// import { ActionRenderComponent } from 'src/app/treaty/action-render/action-render.component';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
// import { ActionRenderComponent } from 'src/app/treaty/action-render/action-render.component';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';

// import { DropdownRenderComponent } from 'src/app/treaty/dropdown-render/dropdown-render.component';

declare var $: any;


@Component({
  selector: 'app-outward-llyods',
  templateUrl: './outward-llyods.component.html',
  styleUrls: ['./outward-llyods.component.css']
})
export class OutwardLlyodsComponent implements OnInit {
  trustFundInfo = [];
  trFundCode: any;
  gridColumnApi: any;
  gridApi: any;

  columnDef = [];
  rowData = [];
  rowInfo = [];
  columnDefs = [];
  llyClassList = [];
  llyRegionList = [];
  llyodsFrm: UntypedFormGroup;
  private context;
  private frameworkComponents;
  @Input() refNo;
  @Input() seqNo;
  @Input() amendNo;
  @Input() action;
  @Input() trustFund;
  @Input() riskLlyods
  rowDataClicked1 = {};
  rowDataClicked2 = {};
  private rowSelection;
<<<<<<< HEAD
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService
  ) { }
=======
  constructor(private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService) { }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  ngOnInit() {

    // this.frameworkComponents = {

    //   dropdownRender: AgDropdwonComponent,
    //   actionrender: DropdownRenderComponent
    // };
    this.reteriveSrpRegionList();
    this.reteriveSrpClassList();
    if ('edit' == this.action) {
      this.reteriveTreatyLloyds();
      // this.reterieveTrustFund();

    }
    this.columnDefs = [
      {
        headerName: 'Trust Fund', field: 'mttyTrustFundPK.tfFundCode'
      },
      { headerName: 'Perc', field: 'tfFundPerc', editable: false },
      {
        headerName: 'Actions',
        field: 'actions',
        width: 150,
        template:
          ` <a>
        <i class="pi pi-plus" data-action-type="Add" title="Add" aria-hidden="true" ></i>
        <i class="pi pi-trash"  data-action-type="Remove" title="Delete" aria-hidden="true"></i>
        <i class="pi pi-save"  data-action-type="Save" title="Save" aria-hidden="true"></i>
        </a>`
      },
      { field: 'mttyTrustFundPK.tfRefNo', headerName: 'RefNo', sortable: true, hide: true },
      { field: 'mttyTrustFundPK.tfSeqNo', headerName: 'AmendNo', sortable: true, hide: true },
      { field: 'mttyTrustFundPK.tfAmendNo', headerName: 'LayerNo', sortable: true, hide: true },
      { field: 'mttyTrustFundPK.tfLayer', headerName: 'Status', sortable: true, hide: true },
      { field: 'tfStatus', headerName: 'UserId', sortable: true, hide: true },
      { field: 'tfCrUid', headerName: 'UserId', sortable: true, hide: true },
      { field: 'tfCrDt', headerName: 'UserId', sortable: true, hide: true },
      { field: 'tfUpdUid', headerName: 'UserId', sortable: true, hide: true },
      { field: 'tfUpdDt', headerName: 'UserId', sortable: true, hide: true },

    ];



    this.context = { componentParent: this };
    this.rowSelection = "multiple";
    this.createForm();

    //this.onGridReady(params)
  }
  /*createForm(){
    this.llyodsFrm =this.fb.group({
      tyRefNo:'',
      tySeqNo:'',
      tyAmendNo:'',
      tyLayer:'',
      tyRiskCode:'',
      tyRiskPerc:'',
      tyStatus:'',
      tyCrUid:'',
      tyCrDt:'',
      tyUpdUid:'', 
      tyUpdDt:''
    })
  }*/
  createForm() {
    this.llyodsFrm = this.fb.group({
      thRefNo: '',
      thSeqNo: '',
      thAmendNo: '',
      thLloydsSrpClass: '',
      thLloydsSrpRegion: '',
      thLloydsSrpReinst: '',
    })
  }

  reteriveSrpRegionList() {
    this.loaderService.isBusy = true;
    this.treatyService.appCodesList(ApiUrls.LLY_REGION).subscribe(resp => {
      this.llyRegionList = resp.appcodeList;
      this.loaderService.isBusy = false;
      this.ngAfterViewInit();
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  reteriveSrpClassList() {
    this.loaderService.isBusy = true;
    this.treatyService.appCodesList(ApiUrls.LLY_CLASS).subscribe(resp => {
      this.llyClassList = resp.appcodeList;
      this.loaderService.isBusy = false;
      this.ngAfterViewInit();
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  ngAfterViewInit() {

    // $('.selectpicker').selectpicker({ dropupAuto: false });
    // setTimeout(() => {
    //   $('.selectpicker').selectpicker('refresh');
    // }, 500);

  }
  updateLlyods() {
    this.llyodsFrm.get('thRefNo').setValue(this.refNo)
    this.llyodsFrm.get('thSeqNo').setValue(this.seqNo)
    this.llyodsFrm.get('thAmendNo').setValue(this.amendNo)
    this.loaderService.isBusy = true;
    this.treatyService.updateTreatyLlyods(this.llyodsFrm.value).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.toastService.success('Update Successfully');
      this.llyodsFrm.reset();
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    })

  }

  reteriveTreatyLloyds() {

    this.loaderService.isBusy = true;

    this.treatyService.retrieveContractDetails(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      let result = resp.treatyArray;
      this.llyodsFrm.patchValue({
        thRefNo: result.ttyHdrPK.thRefNo,
        thAmendNo: result.ttyHdrPK.thAmendNo,
        thSeqNo: result.ttyHdrPK.thSeqNo,
        thLloydsSrpRegion: result.thLloydsSrpRegion,
        thLloydsSrpClass: result.thLloydsSrpClass,
        thLloydsSrpReinst: result.thLloydsSrpReinst,
      })
      this.ngAfterViewInit()
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  onAddRow() {
    var newItem = createNewRowData();
    var res = this.gridApi.updateRowData({ add: [newItem] });
    // printResult(res);
  }
  onRemoveSelected() {
    var selectedData = this.gridApi.getSelectedRows();
    var res = this.gridApi.updateRowData({ remove: selectedData });
    //printResult(res);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");

      switch (actionType) {
        case "Add":
          return this.onActionAddRow(data);
        case "Remove":
          return this.onActionRemoveRow(data);
        case "Save":
          return this.onActionSaveRow();
      }
    }

  }

  public onActionAddRow(data: any) {
    this.onAddRow();
  }

  public onActionRemoveRow(data: any) {
    this.onRemoveSelected();
  }
  onActionSaveRow() {
    const selectedRow = this.gridApi.getSelectedRows();
    let temp = {
      mttyTrustFundPK:
      {
        tfRefNo: selectedRow[0].mttyTrustFundPK.tfRefNo,
        tfSeqNo: selectedRow[0].mttyTrustFundPK.tfSeqNo,
        tfAmendNo: selectedRow[0].mttyTrustFundPK.tfAmendNo,
        tfLayer: selectedRow[0].mttyTrustFundPK.tfLayer,
        tfFundCode: selectedRow[0].mttyTrustFundPK.tfFundCode,
      },

      tfFundPerc: selectedRow[0].tfFundPerc,
      tfStatus: 'A',
      tfCrUid: this.session.get('userId'),
      tfCrDt: new Date(),
      tfUpdUid: '',
      tfUpdDt: ''
    }
    if (temp) {
      // this.treatyService.saveTrustFund(temp).subscribe(resp => {
      // }, error => {
      // })
      this.loaderService.isBusy = true;
      this.treatyService.saveTrustFund(temp).subscribe(resp => {
        this.toastService.success(" Updated Successfully ");
        this.loaderService.isBusy = false;
      }, error => {
        this.toastService.error(error.error.message);
      })
    } else {
      // TODO;
    }

  }
  rowSelected(event) {
    const selectedRow = this.gridApi.getSelectedRows();
  }

  selectedRowData(param: any) {
    this.trFundCode = param;
  }

  reterieveTrustFund() {
    let obj = {
      tfRefNo: this.refNo,
      tfAmendNo: this.amendNo,
      tfSeqNo: this.seqNo,
      tfLayer: 'Layer 1',
    }

    // this.treatyService.reterieveTrustFund(obj).subscribe(resp => {
    //   let arr = [];
    //   if (resp.trustFundList.length > 0) {
    //     for (var i = 0; i < resp.trustFundList.length; i++) {
    //       this.onAddRow();
    //      let tempTrustFund = {
    //       mttyTrustFundPK:{
    //         tfRefNo: resp.trustFundList[i].mttyTrustFundPK.tfRefNo,
    //         tfSeqNo: resp.trustFundList[i].mttyTrustFundPK.tfSeqNo,
    //         tfAmendNo: resp.trustFundList[i].mttyTrustFundPK.tfAmendNo,
    //         tfLayer: resp.trustFundList[i].mttyTrustFundPK.tfLayer,
    //         tfFundCode: resp.trustFundList[i].mttyTrustFundPK.tfFundCode,
    //       },

    //         tfFundPerc: resp.trustFundList[i].tfFundPerc,
    //         tfStatus: resp.trustFundList[i].tfStatus,
    //         tfCrUid: resp.trustFundList[i].tfCrUid,
    //         tfCrDt: resp.trustFundList[i].tfCrUid,
    //       }
    //       arr.push(tempTrustFund); 
    //     }
    //     this.rowData = arr;
    //   }else{
    //     this.onAddRow();
    //   }
    // })
  }
  reteriveTrustFundList() {
    this.treatyService.appCodesList(ApiUrls.FUND_CODE).subscribe(resp => {
      this.trustFundInfo = resp.appcodeList;
      //this.ngAfterViewInit();
    })
  }

  reterieveRiskLlyods() {
    this.onAddRow();
  }
  onAddRow1() {
    var newItem = createNewRowDatas();
    var res = this.gridApi.updateRowData({ add: [newItem] });
    // printResult(res);
  }

}
function createNewRowData() {
  var newData = {
    tfFundCode: '',
    tfFundPerc: '',
    action: ''
  };
  return newData;
}
function createNewRowDatas() {
  var newData = {
    tyRiskCode: '',
    tyRiskPerc: '',
    action: ''
  };
  return newData;
}
