import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardLlyodsComponent } from './outward-llyods.component';

describe('OutwardLlyodsComponent', () => {
  let component: OutwardLlyodsComponent;
  let fixture: ComponentFixture<OutwardLlyodsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutwardLlyodsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutwardLlyodsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
