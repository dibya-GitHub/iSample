import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { zip } from 'rxjs';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent2 } from '../radiorender/radiorender2.component';
import { RadiorenderComponent } from './../../mga-contract/components/radiorender/radiorender.component';

@Component({
  selector: 'app-treaty-appr-contract',
  templateUrl: './treaty-appr-contract.component.html',
  styleUrls: ['./treaty-appr-contract.component.scss']
})
export class TreatyApprContractComponent implements OnInit {
  action: any;
  refNo: any;
  amendNo: any;
  seqNo: any;
  contractType: any;
  documentTypes: any;
  documents: any;
  isDocumentNeedsToBeUpdated: any;
  getRowStyle: any;
  treatyArray: any;
  contractInfoForm: UntypedFormGroup;
  agTypeDataList: any;
  applicableCompanyList:any;
  showChild_TabScreen: boolean = false;

  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  public defaultColDef;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;

  public context1;
  public frameworkComponents1;

  public getRowHeight;

  applicableCompanyShowEntry = 10;
  treatyTypeShowEntry = 10;
  reinsurerShowEntry = 10;
  perilShowEntry = 10;
  termChild1ShowEntry = 10;
  termChild2ShowEntry = 10;
  termChild3ShowEntry = 10;
  termChild4ShowEntry = 10;

  public defaultColDefReins;
  columnDefsReins = [];
  pinnedBottomRowData: any;
  reinsurerList: any;
  layerPriority: any;
  perilList: any;
  public perilCols: any;
  rowTermsData: any;

  public columnTermsDefs: any;
  public columnFCDefs: any;
  public columnSSCDefs: any;
  public columnProfitCommDefs: any;
  profitComm: any;
  rowTermsScaleCommData: any;
  layerData: any;

  public treatyTypeGridApi;
  public reinsurerGridApi;
  public perilGridApi;
  public termChild1GridApi;
  public termChild2GridApi;
  public termChild3GridApi;
  public termChild4GridApi;
  activeIndex: number;
  selectedReinsurer: any;
  documentRefId: string;
  SSCForm: UntypedFormGroup;
  scaleComm: any;
  lossRatioSSC: any;
  slidingScaleRateForm: UntypedFormGroup;
  slidingScaleRateList: any;
  public columnDefsSSC;
  freqList: any;
  profitCommForm: UntypedFormGroup;
  pcData: any;

  premiumReserveForm: UntypedFormGroup;
  hideApplicableRate: boolean = false;
  bankTypeLists: any;
  // fixedCommData: any;
  sscGridApi: any;
  applicableCompanyGridApi: any;
  public columnDefsApplicableCompany;

  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
  ) {
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
  }

  ngOnInit() {
    this.action = this.treatyService.getParamValue('action');
    this.refNo = this.treatyService.getParamValue('refNo');
    this.amendNo = this.treatyService.getParamValue('amendNo');
    this.seqNo = this.treatyService.getParamValue('seqNo');
    this.contractType = this.treatyService.getParamValue('contractType');
    this.columnDefsApplicableCompany = [
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "mttyCompPk.toDivnCode",
        sortable: true,
        enableRowGroup: true,
        cellStyle: { textAlign: 'left' },        
        valueGetter: function (params) {
          if (params && params.data && params.data.mttyCompPk.toDivnCode && params.data.toDivnCodeDesc) {
            return params.data.mttyCompPk.toDivnCode + ' - ' + params.data.toDivnCodeDesc;
          } else if (params && params.data && params.data.mttyCompPk.toDivnCode) {
            return params.data.mttyCompPk.toDivnCode;
          } else { return '' }
        },
      },
    ]
    this.columnDefs = [
      {
        headerName: "Select",
        field: 'tlPriority',
        cellStyle: { textAlign: 'center' },
        cellRenderer: "radioButtonRenderer",
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        headerName: "Treaty Type",
        field: "ttyLayerPK.tlLayer",
        sortable: true,
      },
      {
        headerName: "Treaty Basis",
        field: "tlTtyBasisDesc",
        sortable: true,
      },
      {
        headerName: "Open Years",
        field: "tlOpenYears",
      },
      {
        headerName: "Ceding Basis",
        field: "tlCedingBasisDesc",
      },
      {
        headerName: "Adjust Broker Perc",
        field: "tlAdjBrkPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
      },
      {
        headerName: "Ceding Type",
        field: "tlCedingTypeDesc",
      },
      {
        headerName: "Premium Limit",
        field: "tlLimit",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      },
      {
        headerName: "Percentage",
        field: "tlPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
      },
      {
        headerName: "Alloc On",
        field: "tlAllocOnDesc",
        cellStyle: { textAlign: 'left' }
      },
      {
        headerName: "Cession Limit",
        field: "tlCessionLimit",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter
      },
      {
        headerName: "Acnt Freq",
        field: "tlAcntFreqDesc",
        cellStyle: { textAlign: 'left' }
      }
    ];
    this.defaultColDef = this.defaultColDefReins = {
      resizable: true,
      enableRowGroup: true,
      sortable: true,
      filter: true,
    };

    this.columnDefsReins = [
      {
        headerName: "Select",
        field: 'trSrNo',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        field: 'trReins',
        headerName: 'Reinsurer',
        sortable: true,
        tooltipField: "reinsDesc",
        valueGetter: function (params) {
          if (params && params.data && params.data.trReins) {
            return params.data.trReins + ' - ' + params.data.reinsDesc;
          } else {
            return '';
          }
        },
        filter: true,
      },
      {
        field: 'trBroker',
        headerName: 'Broker',
        sortable: true,
        tooltipField: "brokerDesc",
        valueGetter: function (params) {
          if (params && params.data && params.data.trBroker) {
            return params.data.trBroker + ' - ' + params.data.brokerDesc;
          } else {
            return '';
          }
        },
        filter: true
      },
      {
        field: 'trBrkRefNo',
        headerName: 'Reference',
        sortable: true,
        filter: true
      },
      {
        field: 'trAcntTo',
        headerName: 'Accounting To',
        sortable: true,
        filter: true,
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.trAcntTo + ' - ' + params.data.trAcntDesc;
          }
        },
      },
      {
        field: 'trSharePerc',
        headerName: 'Share',
        sortable: true,
        cellStyle: { textAlign: 'right' },
        filter: true,
        valueFormatter: currencyFormatter4
      },
    ];
    this.perilCols = [
      {
        headerName: "Products",
        field: "perilDesc",
        tooltipField: 'perilDesc', sortable: true,
        valueGetter: function (params) {
          let desc = params.data.perilDesc;
          return desc;
        },
      },
      { field: 'cedingBasisDesc', headerName: 'Ceding Basis', sortable: true },
      { field: 'cedingTypeDesc', headerName: 'Ceding Type', sortable: true },
      { field: 'tpLimit', headerName: 'Limit', valueFormatter: currencyFormatter, sortable: true, cellStyle: { textAlign: 'right' } },
      { field: 'tpPerc', headerName: 'Percentage', valueFormatter: currencyFormatter4, sortable: true, cellStyle: { textAlign: 'right' } },
      { field: 'tlCessionLimit', headerName: 'Cession Limit', valueFormatter: currencyFormatter, sortable: true, cellStyle: { textAlign: 'right' } }
    ];

    this.columnTermsDefs = [
      {
        headerName: "Sr no",
        field: "srNo",
        cellStyle: { textAlign: 'center' },
        filter: true,
        width: 100,
      },
      {
        headerName: "Code",
        filter: true,
        field: "tmCommCodeDesc",
      },
      {
        headerName: "Type",
        filter: true,
        field: "tmRecPayTypeDesc",
      },
      {
        headerName: "Calculation Type",
        filter: true,
        field: "tmCalcTypeDesc",
      },

      {
        headerName: "Percentage",
        field: "tmCommPerc",
        filter: true,
        sortable: true,
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4
      },
      {
        headerName: "Amount",
        filter: true,
        field: "tmAmt",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      }
    ];

    this.columnFCDefs = [
      {
        headerName: "Notes/Remarks",
        field: "tmRemarks",
        filter: true,
      },
      {
        headerName: "Based On",
        filter: true,
        field: "tmBasedOn",
      },
      {
        headerName: "Rate %",
        field: "tmCommPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4
      },
      {
        headerName: "Effective From",
        field: "tmEffFmDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.tmEffFmDt) {
            return moment(params.data.tmEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filter: true,
      },
      {
        headerName: "Effective To",
        field: "tmEffToDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.tmEffToDt) {
            return moment(params.data.tmEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filter: true,
      },
    ];

    this.columnSSCDefs = [
      {
        headerName: "Sr no",
        field: "srNo",
        cellStyle: { textAlign: 'center' },
        filter: true,
        width: 100,
      },
      {
        headerName: "Loss Ratio From",
        field: "tsMinLrPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
        filter: true,

      },
      {
        headerName: "Loss Ratio To",
        field: "tsMaxLrPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
        filter: true,
      },
      {
        headerName: "Applicable Commission",
        field: "tsCommPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
        filter: true,
      }
    ];
    this.columnProfitCommDefs = [
      {
        headerName: "Provisional Commissoin %",
        field: "tadPcProvPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
        filter: true,
      },
      {
        headerName: "Adjust After Years (in Months)",
        cellStyle: { textAlign: 'right' },
        field: "tadPcAdjustYear",
        filter: true,
      },
      {
        headerName: "Final Profit Commission %",
        field: "tadPcFinalPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
        filter: true,

      },
      {
        headerName: "Management Expenses",
        field: "tadPcMgtPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
        filter: true,

      }
    ];

    this.columnDefsSSC = [
      {
        headerName: "Loss Ratio From",
        headerTooltip: "Loss Ratio From",
        field: "tsMinLrPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
      },
      {
        headerName: "Loss Ratio To",
        headerTooltip: "Loss Ratio To",
        field: "tsMaxLrPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
      },
      {
        headerName: "Applicable Commission",
        headerTooltip: "Applicable Commission",
        field: "tsCommPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
      },
    ];
    this.createContractInfoForm();
    this.agGridOptions();
    this.createSSCFormTable();
    this.getFreqList();

  }
  getFreqList() {
    this.treatyService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
      this.freqList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    })
  }
  createSSCFormTable() {
    this.SSCForm = this.fb.group({
      tmSscProv: [undefined],
      tmSscEvlFrq: [undefined],
      tmSscFirstEvlDt: [undefined],
      tmSscLastEvlDt: [undefined],
    })
    this.slidingScaleRateForm = this.fb.group({
      tmSscMinLr: [undefined],
      tmSscMaxLr: [undefined],
      tmSscLrDiff: [undefined],
      tmSscMinComm: [undefined],
      tmSscMaxComm: [undefined],
      tmSscCommDiff: [undefined],
    })
    this.profitCommForm = this.fb.group({
      tmPcFirstEvlDt: [undefined],
      tmPcEvlFrq: [undefined],
      tmPcLastEvlDt: [undefined],
      tmPcMePerc: [undefined],
      tmPcFirstCashEvlDt: [undefined],
    })
    this.premiumReserveForm = this.fb.group({
      tadPwResPerc: [undefined],
      tadPwIntPerc: [undefined],
      tadPwResRel: [undefined],
      tadPwProcFreq: [undefined],
      tadRiExpPerc: [undefined],
      tadBnkIntReq: [undefined],
      tadBnkCurr: [undefined],
    })
  }
  getTermSSCgridData(reinsId) {
    this.scaleComm = [];
    console.log(this.selectedReinsurer);

    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: reinsId
    };
    this.treatyService.getSlidingScaleComm(obj, 'SSC').subscribe((resp: any) => {
      this.scaleComm = resp.termCommList;

      if (this.scaleComm.length > 0) {
        this.SSCForm.patchValue({
          tmSscProv: this.scaleComm[0].tmSscProv,
          tmSscEvlFrq: this.scaleComm[0].tmSscEvlFrq,
          tmSscFirstEvlDt: moment(this.scaleComm[0].tmSscFirstEvlDt).format('DD/MM/YYYY'),
          tmSscLastEvlDt: (this.scaleComm[0].tmSscLastEvlDt == null) ? "" : moment(this.scaleComm[0].tmSscLastEvlDt).format('DD/MM/YYYY'),
        })
      } else {
        this.SSCForm.reset();
      }
      this.SSCForm.disable();
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
    this.treatyService.getSlidingScaleLossRatioComm(obj, 'SSC').subscribe((resp: any) => {
      this.lossRatioSSC = resp.lrCommList;
      if (this.lossRatioSSC.length > 0) {
        this.slidingScaleRateForm.patchValue({
          tmSscMinLr: this.lossRatioSSC[0].tmSscMinLr,
          tmSscMaxLr: this.lossRatioSSC[0].tmSscMaxLr,
          tmSscLrDiff: this.lossRatioSSC[0].tmSscLrDiff,
          tmSscMinComm: this.lossRatioSSC[0].tmSscMinComm,
          tmSscMaxComm: this.lossRatioSSC[0].tmSscMaxComm,
          tmSscCommDiff: this.lossRatioSSC[0].tmSscCommDiff,
        })
        this.getSlidingScaleLossRatioList();
      } else {
        this.slidingScaleRateForm.reset();
        this.slidingScaleRateList = [];
      }
      this.slidingScaleRateForm.disable();

    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });

    this.treatyService.getSlidingScaleComm(obj, 'PC').subscribe((resp: any) => {
      this.pcData = resp.termCommList;

      if (this.pcData.length > 0) {
        this.profitCommForm.patchValue({
          tmPcFirstEvlDt: moment(this.pcData[0].tmPcFirstEvlDt).format('DD/MM/YYYY'),
          tmPcLastEvlDt: moment(this.pcData[0].tmPcLastEvlDt).format('DD/MM/YYYY'),
          tmPcFirstCashEvlDt: moment(this.pcData[0].tmPcFirstCashEvlDt).format('DD/MM/YYYY'),
          tmPcEvlFrq: this.pcData[0].tmPcEvlFrq,
          tmPcMePerc: this.pcData[0].tmPcMePerc,
        })
      } else {
        this.profitCommForm.reset();
      }
      this.profitCommForm.disable();
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });

    this.treatyService.getSlidingScaleComm(obj, 'PC').subscribe((resp: any) => {
      this.pcData = resp.termCommList;

      if (this.pcData.length > 0) {
        this.profitCommForm.patchValue({
          tmPcFirstEvlDt: moment(this.pcData[0].tmPcFirstEvlDt).format('DD/MM/YYYY'),
          tmPcLastEvlDt: moment(this.pcData[0].tmPcLastEvlDt).format('DD/MM/YYYY'),
          tmPcFirstCashEvlDt: moment(this.pcData[0].tmPcFirstCashEvlDt).format('DD/MM/YYYY'),
          tmPcEvlFrq: this.pcData[0].tmPcEvlFrq,
          tmPcMePerc: this.pcData[0].tmPcMePerc,
        })
      } else {
        this.profitCommForm.reset();
      }
      this.profitCommForm.disable();
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });


  }
  getSlidingScaleLossRatioList() {
    this.slidingScaleRateList = [];
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.selectedReinsurer.trReins
    };
    this.treatyService.getSlidingScaleLossRatioComm(obj, 'SSC').subscribe((resp: any) => {
      this.slidingScaleRateList = resp.sscList;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  createContractInfoForm() {
    this.retrieveContractForm();
    this.contractInfoForm = this.fb.group({

      thRefNo: this.refNo,
      thSeqNo: this.seqNo,
      thAmendNo: this.amendNo,
      thTtyDesc: [undefined],
      thContractType: this.contractType,
      thAttachBasis: null,
      thXlType: null,
      thStartDt: [undefined],
      thEndDt: [undefined],
      thUwYear: [undefined],
      thAmendType: null,
      thAmendStartDt: null,
      thAmendEndDt: null,
      thCurr: [undefined],
      thFixedRate: [undefined],
      thEpiAmt: null,
      thPlaLimit: [undefined],
      thClaLimit: [undefined],
      thAcStmtFreq: [undefined],
      thAdjustPeriod: [undefined],
      thClmNotifyDays: null,
      thRemarks: [undefined],
      thApprUid: [undefined],
      thApprDt: [undefined],
      thApprSts: [undefined],
      thStatus: [undefined],
      thCrUid: [undefined],
      thCrDt: [undefined],
      thUpdUid: [undefined],
      thUpdDt: [undefined],
      thAcStmtFreqDesc: [undefined],
      thCurrDesc: [undefined],
    })

  }
  retrieveContractForm() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveContractDetails(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      this.treatyArray = resp.treatyArray;
      this.documentRefId = this.treatyArray.thFlex05;
      if (this.treatyArray && this.treatyArray.thStartDt) {
        this.treatyArray.thStartDt = moment(this.treatyArray.thStartDt).format('DD/MM/YYYY');
      } else if (this.treatyArray) {
        this.treatyArray.thStartDt = undefined;
      }
      if (this.treatyArray && this.treatyArray.thEndDt) {
        this.treatyArray.thEndDt = moment(this.treatyArray.thEndDt).format('DD/MM/YYYY');
      } else if (this.treatyArray) {
        this.treatyArray.thEndDt = undefined;
      }
      if (this.treatyArray && this.treatyArray.thCrDt) {
        this.treatyArray.thCrDt = moment(this.treatyArray.thCrDt).format('DD/MM/YYYY');
      } else if (this.treatyArray) {
        this.treatyArray.thCrDt = undefined;
      }
      if (this.treatyArray && this.treatyArray.thUpdDt) {
        this.treatyArray.thUpdDt = moment(this.treatyArray.thUpdDt).format('DD/MM/YYYY');
      } else if (this.treatyArray) {
        this.treatyArray.thUpdDt = undefined;
      }
      this.contractInfoForm.patchValue(this.treatyArray);
      this.loaderService.isBusy = false;
      this.contractInfoForm.disable();

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error);
    })
    this.onTreatyReinsurerGridReady();
    this.getAllApplicableCompanyList();
  }
  getAllApplicableCompanyList() {
    let obj = {
      'refNo': this.refNo,
      'amendNo': this.amendNo,
      'seqNo': this.seqNo
    };
    this.treatyService.getAllApplicableCompanies(obj).subscribe((resp: any) => {
      this.applicableCompanyList = resp;
    }, error => {
      this.toastService.error(error);
    });
  }
  onTreatyReinsurerGridReady() {
    let obj = {
      'refNo': this.refNo,
      'amendNo': this.amendNo,
      'seqNo': this.seqNo
    };

    this.treatyService.retrieveLayerListById(obj).subscribe(resp => {
      this.agTypeDataList = resp.layerList;
      for (var i = 0; i < this.agTypeDataList.length; i++) {
        this.agTypeDataList[i].tlCessionLimit = (this.agTypeDataList[i].tlCessionLimit == null) ? 0 : this.agTypeDataList[i].tlCessionLimit; // ag-grid filter search was showing blanks instead of zero if null.
      }
      if (this.agTypeDataList.length > 0) {
        this.context.componentParent.selectedRowId = this.agTypeDataList[0].tlPriority;
        this.selectedRowData({ data: this.agTypeDataList[0] });
      }
    });
  }
  selectedRowData(cell) {
    this.layerPriority = cell.data.tlPriority;
    this.layerData = cell.data;
    setTimeout(() => {
      this.showChild_TabScreen = true;
      this.activeIndex = 0;
      this.reterieveReInsList(this.layerPriority);
      this.getPerilDetails(this.layerPriority);
    }, 300);
  }
  reterieveReInsList(layerId) {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: layerId,
      seqNo: this.seqNo
    };
    this.treatyService.retrieveReInsByLayer(obj).subscribe((resp: any) => {
      this.reinsurerList = resp;
      if (this.reinsurerList.length > 0) {
        this.context.componentParent.selectedRowId1 = this.reinsurerList[0].trSrNo;
        this.selectedRowData1({ data: this.reinsurerList[0] });
      } else {
        this.selectedReinsurer == undefined;
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  selectedRowData1(cell) {
    console.log(cell);
    this.selectedReinsurer = cell.data;
    this.getTermsData(cell.data.trLayer)
    this.getTermSSCgridData(cell.data.trReins);
  }
  getPerilDetails(layerNo) {
    this.loaderService.isBusy = true;
    this.treatyService.getSelectedPerilList(layerNo, this.refNo, this.amendNo, this.seqNo).subscribe((resp: any) => {
      this.perilList = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  getTermsData(layerId) {
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.selectedReinsurer.trReins
    };
    this.loaderService.isBusy = true;
    zip(
      this.treatyService.getTreatyTermsComm(layerId, obj),
      this.treatyService.retrieveBankType('TTY_BNK_CUR'),
      this.treatyService.getAllFixedComm(obj, 'FC'),
      this.treatyService.getTreatyProfitComm(layerId, obj),
    ).subscribe(([termsComm, bankTypeLists, fixedComm, profitComm]: any[]) => {
      this.rowTermsData = termsComm;
      if (this.rowTermsData.length > 0) {
        this.rowTermsData.forEach((element, value) => {
          element.srNo = value + 1;
        })
      }
      this.bankTypeLists = bankTypeLists.appcodeList,
        // this.fixedCommData = fixedComm.termCommList;
      this.profitComm = profitComm;
      if (this.profitComm.length > 0) {
        this.profitComm = this.profitComm[this.profitComm.length - 1];
        this.premiumReserveForm.patchValue({
          tadPwResPerc: this.profitComm.tadPwResPerc,
          tadPwIntPerc: this.profitComm.tadPwIntPerc,
          tadPwResRel: this.profitComm.tadPwResRel,
          tadPwProcFreq: this.profitComm.tadPwProcFreq,
          tadRiExpPerc: this.profitComm.tadRiExpPerc,
          tadBnkIntReq: (this.profitComm.tadBnkIntReq == 'true') ? 'Yes' : 'No',
          tadBnkCurr: this.profitComm.tadBnkCurr,
        })
        this.enableApplicableRate(this.premiumReserveForm.get('tadBnkIntReq').value);
      } else {
        this.premiumReserveForm.reset();
        this.enableApplicableRate(this.premiumReserveForm.get('tadBnkIntReq').value);
      }
      this.premiumReserveForm.disable();
      this.loaderService.isBusy = false;
    },
      err => {
        this.loaderService.isBusy = false;
        this.toastService.error(err);
      }
    );
  }
  enableApplicableRate(evnt) {
    this.hideApplicableRate = (evnt == 'Yes') ? true : false;
    if (!this.hideApplicableRate) {
      this.premiumReserveForm.get('tadBnkCurr').setValue('')
    } else {
      this.premiumReserveForm.get('tadBnkCurr').setValue(this.profitComm.tadBnkCurr);
    }
  }
  // tabswitch(e) {
  //   this.loaderService.isBusy = true;
  //   if (!e || !e.heading) {
  //     return;
  //   }
  //   if (e.heading === 'REINSURER') {
  //     this.reterieveReInsList(this.layerPriority);
  //   } else if (e.heading === 'Terms') {
  //     this.getTermsData(this.layerPriority);
  //   } else if (e.heading === 'Perils') {
  //     this.getPerilDetails(this.layerPriority);
  //   }
  //   this.showChild_TabScreen = true;
  // }
  handleChange(e) {
    this.loaderService.isBusy = true;
    if (e.index === 0) {
      this.reterieveReInsList(this.layerPriority);
    } else if (e.index === 1) {
      this.getPerilDetails(this.layerPriority);
      this.selectedReinsurer = undefined;
    } else if (e.index === 2) {
      this.getTermsData(this.layerPriority);
    }
    this.showChild_TabScreen = true;
  }
  back() {
    this.route.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
  }


  displayedRowCount(gridApi: any) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
    gridApi.sizeColumnsToFit();
    
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allLayerTreatyType").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
    this.context1 = { componentParent: this };

    this.frameworkComponents1 = {
      radioButtonRenderer: RadiorenderComponent2
    }
  }

  onGridReady(params, gridName) {
    if (gridName === 'treatyType') {
      this.treatyTypeGridApi = params.api;
    } else if (gridName === 'reinsurer') {
      this.reinsurerGridApi = params.api;
    } else if (gridName === 'peril') {
      this.perilGridApi = params.api;
    } else if (gridName === 'termChild1') {
      this.termChild1GridApi = params.api;
    } else if (gridName === 'termChild2') {
      this.termChild2GridApi = params.api;
    } else if (gridName === 'termChild3') {
      this.termChild3GridApi = params.api;
    } else if (gridName === 'termChild4') {
      this.termChild4GridApi = params.api;
    } else if (gridName === 'sliding_scale') {
      this.sscGridApi = params.api;
    } else if (gridName === 'applicableCompany') {
      this.applicableCompanyGridApi = params.api;
    }
    params.api.sizeColumnsToFit();
  }

  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }
  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res.appcodeList;
      }, err => {
      });
  }
}
function currencyFormatter(params) {
  if (params != null && params.value !== undefined) {
    return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT,
      {
        minimumFractionDigits: 2
      }
    ).format((params.value));
  } else { return '0.00' }
}
function currencyFormatter4(params) {
  if (params && params.value != null && params.value != undefined) {
    let vl = parseFloat(params.value);
    return vl.toFixed(4);
  } else {
    return '';
  }
}