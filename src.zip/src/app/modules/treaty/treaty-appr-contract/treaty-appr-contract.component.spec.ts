import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyApprContractComponent } from './treaty-appr-contract.component';

describe('TreatyApprContractComponent', () => {
  let component: TreatyApprContractComponent;
  let fixture: ComponentFixture<TreatyApprContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyApprContractComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyApprContractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
