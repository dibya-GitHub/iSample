<<<<<<< HEAD
import { Utils } from './../../../utils';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
=======
import { Component, ViewChild, ElementRef } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiUrls } from 'src/app/api-urls';
import { SessionStorageService } from 'angular-web-storage';
import { Inject } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { BreadcrumbService } from 'xng-breadcrumb';
<<<<<<< HEAD
import { RadiorenderComponent } from './../radiorender/radiorender.component';
=======
import { ToastService } from 'src/app/services/toast.service';
import { RadiorenderComponent } from './../radiorender/radiorender.component';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { LoaderService } from 'src/app/services/loader.service';
import { HttpErrorResponse } from '@angular/common/http';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
declare var $: any;

@Component({
  selector: 'app-treaty-contract',
  templateUrl: './treaty-contract.component.html',
  styleUrls: ['./treaty-contract.component.css']
})

export class TreatyContractComponent {
  public gridOptions;
  private gridApi;
  private gridColumnApi;
  public defaultColDef;
  private defaultColGroupDef;
  private columnTypes;
  public context;
  public frameworkComponents;
  public components;
  amendmentForm: UntypedFormGroup;
  NCBflag: boolean;
  quickSearchValue: string = '';
  paginationPageSize: number;
  rowGroupPanelShow: string;
  contType: any;
  seqNo: any;
  viewdocument: boolean = false;
  docList: any;
  errMsg: boolean = false;
  showRenewal: boolean;
  userList: any;
  EditBtnFlag: boolean = false;
  yearList: any[];
  amndNo: any;
<<<<<<< HEAD
  isRadioActive: boolean = false;
=======
  //sequence: boolean = false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  refNo: any;
  transId: any;
  contractTypeList: any[];
  xolTypeList: any[];
  contractSrchFrm: UntypedFormGroup;
  status: string;
  reportParam: any[];
  selectedArray = [];
  dashBoard: string;
  transId: any;
  contractType: any;
  AdjustBtnFlag: boolean = false;
  ViewBtnFlag: boolean;

  columnDefs = [];
  rowData = [];
  statuses: { key: string; value: string; }[];
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  totalCount: number;
  pendingCount: number;
  approvedCount: number;
  treatyData: any;
  displayedRowLength: any;

  @ViewChild('trigger') tr: ElementRef;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  @ViewChild('contcTypeModal') contcTypeModal: ElementRef;
  @ViewChild('amendmentContent') amendmentContent: ElementRef;
  ncbCount: any;
  adjustReinstPremCount: any;
  adjustdepositPremiumCount: any;
  recoveryCount: any;
  renewalCount: any;
  SelectedRowData: any;
  recoveryTransId: any;
  adjustdepositPremAprvdCount: any;
  contractDesc: any = '';
  amendmentCount: any;
<<<<<<< HEAD
  amndSrNo: any;
  isContAvail: boolean = true;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private treatyService: TreatyService,
=======
  startDate: any;
  amndSrNo: any;
  renewalForm : UntypedFormGroup;
  isRadioActive: boolean = false;
  isContAvail: boolean = false;

  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private router: Router,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
<<<<<<< HEAD
    private breadcrumbService: BreadcrumbService,
=======
    private breadcrumbService: BreadcrumbService
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
  }

  ngOnInit() {
    this.breadcrumbService.set('contact-grid', 'Home');
    this.columnDefs = [
      {
        field: 'thFlex01',
        headerName: 'Select',
        checkboxSelection: false,
        cellRenderer: 'radioButtonRenderer',
        cellStyle: { textAlign: 'center' },
        width: 110,
<<<<<<< HEAD
        enableRowGroup: false,
=======
        sortable: false,
        filter: false,
        enableRowGroup: false
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },
      {
        field: 'ttyHdrPK.thRefNo',
        headerName: 'Ref No',
        headerTooltip: 'Contract Ref No',
        tooltipField: 'athlete',
      },
      {
        field: 'ttyHdrPK.thSeqNo',
        headerName: 'Seq No',
        headerTooltip: 'Contract Seq No',
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'thTtyDesc',
        headerName: 'Description',
        tooltipField: 'thTtyDesc',
      },
      {
        field: 'thStartDt',
        headerName: 'Period From',
<<<<<<< HEAD
        // cellRenderer: 'strtDateCellRenderer',
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.thStartDt) {
            return moment(params.data.thStartDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams1,
      },
      {
        field: 'thEndDt',
        headerName: 'Period To',
<<<<<<< HEAD
        // cellRenderer: 'endDateCellRenderer',
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.thEndDt) {
            return moment(params.data.thEndDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams1,
      },
      {
        field: 'thUwYear',
        headerName: 'Year of Account',
        headerTooltip: 'Protection Year',
        cellStyle: { textAlign: 'center' },
      },
      {
        field: 'thContractDesc',
        headerName: 'Contract Type',
        tooltipField: 'thContractDesc',
      },
      // {
      //   field: 'thXlTypeDesc',
      //   headerName: 'XOL Type',
      //   cellStyle: { textAlign: 'left' },
      //   tooltipField: 'thXlTypeDesc',
      // },
      {
        field: 'thApprUid',
        headerName: 'Approved by',
        cellStyle: {
          width: '130px',
          height: '31px',
          textAlign: 'left'
        },
      },
      {
        field: 'thApprSts',
        headerName: 'Status',
        cellStyle: { textAlign: 'center' },
        headerTooltip: 'Status',
        valueGetter: function (params) {
          if (params && params.data && params.data.thApprSts) {
            if (params.data.thApprSts === 'A') {
              return 'Approved';
            } else {
              return 'Pending';
            }
          } else {
            return '';
          }
        },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.value) {
              return params.value == 'Pending';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element">' + params.value + '</span>';
          } else {
            return '<span class="ag-element">' + params.value + '</span>';
          }
        },
      }
    ];

    this.components = {
      // strtDateCellRenderer: strtDateCellRenderer,
      // endDateCellRenderer: endDateCellRenderer,
      statusCellRenderer: statusCellRenderer
    };
    this.createForm();
    this.retrieveContractType();
    this.retrieveXolType();
    this.retrieveContractYear();
    this.reterieveUWriterList();
    //this.retrieveContractGrid();
    this.search()
    this.statuses = [
      {
        key: '',
        value: 'All'
      },
      {
        key: 'A',
        value: 'Approved'
      },
      {
        key: 'P',
        value: 'Pending'
      },
    ];

<<<<<<< HEAD
=======
    //this.contractSrchFrm.get('thCrUid').setValue('');
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.contractSrchFrm.get('thApprUid').setValue('');
    this.dashBoard = this.session.get('userDashboard')
    this.agGridOptions();
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 10;
    this.createAmendmentForm();
    this.createRenewalForm();
  }

  createForm() {
    this.contractSrchFrm = this.fb.group({
      thContractType: '',
      thRefNo: '',
      thTtyDesc: '',
      thUwYear: '',
      thXlType: '',
<<<<<<< HEAD
      thApprUid: '',
      thStatus: ''
=======
      //thCrUid: '',
      thStatus: '',
      thApprUid:''
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    });
  }
  reset() {

    this.contractSrchFrm.patchValue({
      thContractType: '',
      thRefNo: '',
      thTtyDesc: '',
      thUwYear: '',
      thXlType: '',
<<<<<<< HEAD
      thApprUid: '',
      thStatus: ''
=======
      thCrUid: '',
      thStatus: '',
      thApprUid:''
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    });
    this.contractSrchFrm.get('thApprUid').enable();
    this.pageChanged({ page: 1 });
    this.search();
  }

  search() {
    this.loaderService.isBusy = true;
    let formData = this.contractSrchFrm.getRawValue();
    let obj = {
      thRefNo: (formData.thRefNo == '' ? null : formData.thRefNo),
      thContractType: (formData.thContractType == '' ? null : formData.thContractType),
      thTtyDesc: (formData.thTtyDesc == '' ? null : formData.thTtyDesc),
      thUwYear: (formData.thUwYear == '' ? null : formData.thUwYear),
      thXlType: (formData.thXlType == '' ? null : formData.thXlType),
      thApprUid: (formData.thApprUid == '' ? null : formData.thApprUid),
<<<<<<< HEAD
=======
      //thCrUid: (formData.thCrUid == '' ? null : formData.thCrUid),
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      thStatus: (formData.thStatus == '' ? null : formData.thStatus),
    };
    this.treatyService.searchContract(obj, ApiUrls.TREATY_MGMT_PATH).subscribe(resp => {
      this.treatyData = JSON.parse(JSON.stringify(resp.treatyArray));
      this.rowData = resp.treatyArray;
      this.calculateFilterCounts();
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
    this.isRadioActive = false;
  }

  retrieveContractGrid() {
    this.loaderService.isBusy = true;
    let userId = this.session.get('userId');

    this.treatyService.retrieveContractGrid(userId, ApiUrls.TREATY_MGMT_PATH).subscribe(resp => {
      this.treatyData = JSON.parse(JSON.stringify(resp.treatyArray));
      this.rowData = resp.treatyArray;
      this.calculateFilterCounts();
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  onStatusChange(status) {
    // this.searchSkeletonInfo(this.constructFormData(1), false);   
    if (status) {
      this.rowData = this.treatyData.filter(datum => datum.thApprSts === status);
    } else {
      this.rowData = this.treatyData;
    }
  }
  calculateFilterCounts() {
    if (this.rowData) {
      this.totalCount = this.rowData.length;
      this.pendingCount = this.rowData.filter(datum => datum.thApprSts === 'P').length;
      this.approvedCount = this.rowData.filter(datum => datum.thApprSts === 'A').length;
    }
  }

  View(mode) {
    if (this.refNo == null || this.refNo == '') {
      this.toastService.warning('Please Select ');
    }
    else if (mode == 'view') {
      let obj = { 'action': mode, 'refNo': this.refNo, 'amendNo': this.amndNo, 'status': this.status, 'seqNo': this.seqNo, 'contractType': this.contType }
<<<<<<< HEAD
      if (this.contractType == 'TP') {
        this.router.navigate(['/treaty/treaty-appr-contract'], { queryParams: obj, skipLocationChange: true });
      } else {
        this.router.navigate(['/treaty/approved-contract'], { queryParams: obj, skipLocationChange: true });
      }

    } else {
      let obj = { 'action': mode, 'refNo': this.refNo, 'amendNo': this.amndNo, 'amendSrNo': this.amndSrNo, 'type': this.contractType, 'seqNo': this.seqNo, 'status': this.status }
=======
      
      if (this.contractType == 'TP') {
        this.router.navigate(['/treaty-qs/treaty-appr-contract'], { queryParams: obj, skipLocationChange: true });
      } else {
        this.router.navigate(['/treaty/approved-contract'], { queryParams: obj, skipLocationChange: true });
      }
    } else {
      // let obj = { 'action': mode, 'refNo': this.refNo, 'amendNo': this.amndNo, 'type': this.contractType, 'seqNo': this.seqNo, 'status': this.status };

      // this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
      
      let obj = { 'action': mode, 'refNo': this.refNo, 'amendNo': this.amndNo, 'amendSrNo': this.amndSrNo, 'type': this.contractType, 'seqNo': this.seqNo, 'status': this.status };
      if (this.contractType == 'TP') {
        this.router.navigate(['/treaty-qs/outward-treaty'], { queryParams: obj, skipLocationChange: true });
      } else {
        this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
      }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

    }
  }

  retrieveXolType() {
    this.treatyService.retrieveXolType(ApiUrls.APP_CODES_MGMT_PATH).subscribe(resp => {
      this.xolTypeList = resp.appcodeList;
      this.xolTypeList.unshift({ key: '', value: 'All' });

    })
  }
  retrieveContractType() {
    this.treatyService.fetchContractType(ApiUrls.APP_CODES_MGMT_PATH).subscribe(resp => {
      this.contractTypeList = resp.appcodeList;
      this.contractTypeList.unshift({ key: '', value: 'All' });
    });
  }

  newContract(mode) {
    var obj;
    if ('seq' == mode) {
      this.treatyService.retrieveNextSeqNo(this.refNo, this.amndNo).subscribe(resp => {
        var maxSeqNo = parseInt(resp.seqMax) + 1;
        var obj = {
          'action': 'addsequnce',
          'refNo': this.refNo,
          'amendNo': this.amndNo,
          'seqNo': maxSeqNo,
          'type': this.contractType
        }
        this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
      })
    } else {
      this.open(this.contcTypeModal, 'modal-dialog-centered modal-md');
      obj = {
        'action': 'add',
        'amendNo': this.amndNo,
        'seqNo': 1
      }
    }
    // this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
  }

  selectedRowData(val: any) {
    this.loaderService.isBusy = true;
    this.isRadioActive = true;
<<<<<<< HEAD
    this.refNo = val.data.ttyHdrPK.thRefNo;
    this.amndNo = val.data.ttyHdrPK.thAmendNo;
    this.amndSrNo = val.data.thAmendSrNo;
=======
    //this.sequence = true;
    this.refNo = val.data.ttyHdrPK.thRefNo;
    this.amndNo = val.data.ttyHdrPK.thAmendNo;
    this.amndSrNo = val.data.thAmendSrNo;

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.seqNo = val.data.ttyHdrPK.thSeqNo;
    this.contractType = val.data.thContractType;
    this.status = val.data.thApprSts;
    this.contType = val.data.thContractType;
    this.contractDesc = val.data.thTtyDesc;
    this.startDate = val.data.thStartDt;
    if (this.status == 'A') {
      this.treatyService.getContractCount(this.refNo, this.seqNo, this.amndNo).subscribe(resp => {
        this.adjustdepositPremiumCount = resp.depositPremCount;
        this.adjustdepositPremAprvdCount = resp.depositPremApprovedcount;
        this.adjustReinstPremCount = resp.adjustReinstPremCount;
        this.ncbCount = resp.ncbCount;
        this.renewalCount = resp.renewalCount;
        this.recoveryCount = resp.recoveryCount;
        this.recoveryTransId = resp.recoveryTransId;
        this.amendmentCount = resp.amendmentCount;
        this.loaderService.isBusy = false;
      }, err => {
        this.loaderService.isBusy = false;
      })

      this.treatyService.NCBstatus(this.refNo, this.seqNo).subscribe(resp => {
        var count = resp;
        if (count != 0) {
          this.NCBflag = true
        } else {
          this.NCBflag = false
        }
      }, error => { });
    } else {
      this.loaderService.isBusy = false;
    }

    if (val.data.thContractType === 'TP' || 'FP' === val.data.thContractType) {
      if ('P' == val.data.thApprSts) {
        this.EditBtnFlag = true;
        this.AdjustBtnFlag = false;
        this.ViewBtnFlag = true;
      } else if ('A' == val.data.thApprSts) {
        this.ViewBtnFlag = true;
        this.EditBtnFlag = false;
        this.AdjustBtnFlag = true;
      }
    } else if (val.data.thContractType === 'TX' || 'FX' === val.data.thContractType) {
      if ('P' == val.data.thApprSts) {
        this.ViewBtnFlag = false;
        this.EditBtnFlag = true;
        this.AdjustBtnFlag = false;
      } else if ('A' == val.data.thApprSts) {
        this.ViewBtnFlag = true;
        this.EditBtnFlag = false;
        this.AdjustBtnFlag = true;
      }
    }

    this.viewdocument = true;
    // this.loaderService.isBusy = false;
  }
  retrieveContractYear() {
    this.treatyService.retrieveContractYear(ApiUrls.TREATY_MGMT_PATH).subscribe(resp => {
      this.yearList = resp;
      this.yearList.unshift({ key: '', value: 'All' });
    })
  }

  reterieveUWriterList() {
    this.treatyService.fetchUWriterList().subscribe(resp => {
      this.userList = resp.userList;
<<<<<<< HEAD
      this.userList.unshift({ value: '', key: 'All' });
=======
      this.userList.unshift({ key: 'All', value: '' });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

    })
  }

  pushSelectedDocs(event, value) {
    if (event.target.checked == true) {
      this.selectedArray.push(value);
    } else {
      var index = this.selectedArray.indexOf(value);
      this.selectedArray.splice(index, 1)
    }
  }
  changeStatus(evnt) {
    this.contractSrchFrm.get('thApprUid').enable();
    if (evnt.value == 'P') {
      this.contractSrchFrm.get('thApprUid').setValue("");
      this.contractSrchFrm.get('thApprUid').disable();
    }
  }
  disableXolType(evnt) {
    this.contractSrchFrm.get('thXlType').enable();
    if (evnt.value == 'TP') {
      this.contractSrchFrm.get('thXlType').setValue("");
      this.contractSrchFrm.get('thXlType').disable();
    }
  }
  printDoc(contant) {
    if (this.refNo == null || this.refNo == '') {
      this.toastService.warning('Please Select and Proceed');
      return false;
    }
    let obj = {
      compCode: this.session.get('companyCode'),
      instId: this.session.get('instanceId'),
      divn: this.session.get('userDivnCode'),
      tranType: 'TTY_XOL'
    }
    this.treatyService.fetchReportParamList(obj).subscribe(resp => {
      this.reportParam = resp.reportParamList;
    })
    this.modalService.show(contant, { class: 'modal-dialog-centered modal-lg' });
<<<<<<< HEAD
=======
    // this.modalService.open(contant, { size: 'modal-lg' }).result.then((result) => {
    // }, (reason) => {
    // });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  }

  printDocument() {
    if (this.selectedArray.length == 0) {
      this.toastService.warning('Please Select atleast one checkBox');
      return false;
    }
    for (var i = 0; i < this.selectedArray.length; i++) {
      for (var j = 0; j < this.reportParam.length; j++) {
        if (this.reportParam[j].rmRepId == this.selectedArray[i]) {
          let selectedRmtype = this.reportParam[j].rmType;
          var params = {
            refNo: this.refNo,
            amendNo: this.amndNo,
            compCode: this.session.get('companyCode'),
            repId: this.selectedArray[0],
            seqNo: this.seqNo,
            docType: selectedRmtype
          }
          this.treatyService.fetchReportUrl(params)
            .subscribe(result => {
              var url = result.resultUrl;
              var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
          width=0,height=0,left=-1000,top=-1000`;
              var winRef = window.open(url, 'Reports' + (++i), param);

            });
        }

      }
    }
  }

  adjustPrem(premtype: any) {
    var title;
    if (this.refNo == null || this.refNo == '' || this.refNo == undefined) {
      this.toastService.warning('Please Select ');
      return false;
    }
    if (ApiUrls.ADJUST_TYPE_DEP == premtype) {
      title = 'XOL Adjutment - Deposit';
      this.router.navigate(['/treaty/adjust-premium'], { queryParams: { 'refNo': this.refNo, 'seqNo': this.seqNo, 'amendNo': this.amndNo, 'type': premtype, 'title': title, contDesc: this.contractDesc }, skipLocationChange: true });
    } else if ('NCB' == premtype) {
      title = 'No Claim Bonus';
      //this.router.navigate(['/treaty/adjust-premium'], { queryParams: { 'refNo': this.refNo, 'seqNo': this.seqNo, 'amendNo': this.amndNo, 'type': premtype, 'title': title }, skipLocationChange: true });      
      this.router.navigate(['/treaty/adjust-ncb'], { queryParams: { 'refNo': this.refNo, 'seqNo': this.seqNo, 'amendNo': this.amndNo, 'type': premtype, 'title': title, contDesc: this.contractDesc }, skipLocationChange: true });
    } else if ('REINST_PREM' == premtype) {
      title = 'XOL Adjutment - Reinstatement';
      this.router.navigate(['/treaty/adjust-premium'], { queryParams: { 'refNo': this.refNo, 'seqNo': this.seqNo, 'amendNo': this.amndNo, 'type': premtype, 'title': title, contDesc: this.contractDesc }, skipLocationChange: true });
    }
  }

  renewContract() {
    this.renewalForm.reset();
    if (this.refNo == null || this.refNo == '') {
      this.toastService.warning('Please Select ');
    } else {
      this.showRenewal = true;
      this.showDialogbox();
    }
  }
  createAmendmentForm() {
    this.amendmentForm = this.fb.group({
      tcaiRefNo: this.refNo,
      tcaiSeqNo: this.seqNo,
      tcaiAmendNo: this.amndNo,

      tcaiAmendSrNo: [undefined],
      tcaiAmendRef: [undefined, Validators.required],
      tcaiAmendStartDate: [undefined, Validators.required],
      tcaiAmendDesc: [undefined],
      tcaiAmendType: [undefined],
      tcaiCreatedUserId: this.session.get('userId'),
      tcaiCreatedDate: new Date(),
      tcaiUpdatedUserId: this.session.get('userId'),
      tcaiUpdatedDate: new Date()
    });
  }

  goToAmendment() {
    this.amendmentForm.reset();
    if (this.refNo == null || this.refNo == '' || this.refNo == undefined) {
      this.toastService.warning('Please Select ');
      return false;
    } else {
      let obj = {
        refNo: this.refNo,
        seqNo: this.seqNo,
        amendNo: this.amndNo
      };
      this.treatyService.fetchAmendmentSrNo(obj).subscribe(resp => {
        if (resp.id.tcaiAmendSrNo) {
          this.amendmentForm.patchValue({
            tcaiAmendSrNo: resp.id.tcaiAmendSrNo,
            tcaiAmendStartDate: new Date(moment(this.startDate, 'YYYY-MM-DD').toDate()),
          })
        }
      }, error => {
        this.toastService.error("Error in Fetching Details");
      })
<<<<<<< HEAD
      this.open(this.amendmentContent, 'modal-dialog-centered modal-lg');
=======
      this.open(this.amendmentContent, 'modal-lg');
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }
  cancel() {
    this.modalService.hide();
    this.amendmentForm.reset();
  }
  saveAmendment() {
    let formValue = this.amendmentForm.value;
    if (this.amendmentForm.valid) {
      this.loaderService.isBusy = true;
      let formData = {
        id: {
          tcaiRefNo: this.refNo,
          tcaiSeqNo: this.seqNo,
          tcaiAmendNo: this.amndNo,
          tcaiAmendSrNo: formValue.tcaiAmendSrNo
        },
        tcaiAmendRef: formValue.tcaiAmendRef,
<<<<<<< HEAD
        tcaiAmendStartDate: Utils.formatDate_YYYY_MM_DD(formValue.tcaiAmendStartDate),
=======
        tcaiAmendStartDate: moment(formValue.tcaiAmendStartDate).format('YYYY-MM-DD'),
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        tcaiAmendDesc: formValue.tcaiAmendDesc,
        tcaiAmendType: 'I',
        tcaiCreatedUserId: this.session.get('userId'),
        tcaiCreatedDate: new Date(),
        tcaiUpdatedUserId: this.session.get('userId'),
        tcaiUpdatedDate: new Date()
      };
      this.treatyService.myMethod(formData);

      this.treatyService.saveAmendmentDetails(formData).subscribe(resp => {
        // this.toastService.success("Successfully Saved");
        if (resp) {
          let obj = { 'action': 'edit', 'refNo': this.refNo, 'amendNo': this.amndNo, 'type': this.contractType, 'seqNo': this.seqNo, 'status': this.status, 'amendSrNo': formValue.tcaiAmendSrNo }
          this.modalService.hide();
<<<<<<< HEAD
          this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
=======
          if (this.contractType == 'TP') {
            this.router.navigate(['/treaty-qs/outward-treaty'], { queryParams: obj, skipLocationChange: true });
          } else {
            this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
          }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        }
        this.loaderService.isBusy = false;
      }, error => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this.loaderService.isBusy = false;
            this.toastService.error(error.error.message);
          } else {
            switch (error.status) {
              case 400:
                this.loaderService.isBusy = false;
                this.toastService.warning(error.error.message);
                break;
              default:
                this.loaderService.isBusy = false;
                this.toastService.error(error.error.message);
                break;
            }
          }
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        }
      });

    } else {
      this.validateAllFormFields(this.amendmentForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  goToAmendmentHistory() {
    if (this.refNo == null || this.refNo == '' || this.refNo == undefined) {
      this.toastService.warning('Please Select ');
      return false;
    }
    else {
      this.router.navigate(['/treaty/amend-history'], { queryParams: { 'refNo': this.refNo, 'seqNo': this.seqNo, 'amendNo': this.amndNo, contDesc: this.contractDesc }, skipLocationChange: true });
    }
  }

  goToCashAdvance() {
    if (this.refNo == null || this.refNo == '' || this.refNo == undefined) {
      this.toastService.warning('Please Select ');
      return false;
    }
    else {
      let obj = { 'refNo': this.refNo, 'amendNo': this.amndNo, 'status': this.status, 'seqNo': this.seqNo, 'contractType': this.contType,'contDesc': this.contractDesc}
      this.router.navigate(['/treaty/cash-advance'], { queryParams: obj, skipLocationChange: true });      
    }
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }

  showDialogbox() {
<<<<<<< HEAD
    this.open(this.confirmcontent, 'modal-dialog-centered modal-md');
  }

  Proceed(newRefno: any) {
    let obj = {
      thRefNo: this.refNo,
      thAmendNo: this.amndNo,
      newthRefNo: newRefno,
      userId: this.session.get('userId'),
      thSeqNo: this.seqNo
    }
    if (obj.newthRefNo != '') {
      this.treatyService.treatyRenewal(obj).subscribe(resp => {
        if (resp.message == null) {
          this.modalService.hide();
          // this.toastService.add({ severity: 'success', detail: 'Deleted Succcessfully' });
          let obj = { 'action': 'edit', 'refNo': newRefno, 'amendNo': this.amndNo, 'seqNo': this.seqNo, 'status': this.status, 'type': this.contractType }
          this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
        } else {
          this.toastService.error(resp.message);
        }
      }, error => {

      })
=======
    this.open(this.confirmcontent, 'modal-lg');
  }

  Proceed() {
    if (this.renewalForm.valid) {
      let formData = this.renewalForm.getRawValue();
      let obj = {
        thRefNo: this.refNo,
        thAmendNo: this.amndNo,
        newthRefNo: formData.newRefno,
        userId: this.session.get('userId'),
        thSeqNo: this.seqNo
      }
      if (obj.newthRefNo != '') {
        this.treatyService.treatyRenewal(obj).subscribe(resp => {
          if (resp.message == null) {
            this.modalService.hide();
            // this.toastService.add({ severity: 'success', detail: 'Deleted Succcessfully' });
            let obj = { 'action': 'edit', 'refNo': formData.newRefno, 'amendNo': this.amndNo, 'seqNo': this.seqNo, 'status': this.status }
            this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
          } else {
            this.toastService.error(resp.message);
          }
        }, error => {
  
        })
      }
    } else {
      this.validateAllFormFields(this.renewalForm);      
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
   

  }

  newContType(action, type) {
    var obj = {
      'action': 'add',
      'amendNo': this.amndNo,
      'seqNo': 1,
      'type': type
    }
    if (type == 'TP') {
      this.router.navigate(['/treaty-qs/outward-treaty'], { queryParams: obj, skipLocationChange: true });

    } else {
      this.router.navigate(['/treaty/outward-treaty'], { queryParams: obj, skipLocationChange: true });
    }
    // { queryParams: obj, skipLocationChange: true }
    this.modalService.hide()
  }

  testTreatyType() {
    this.router.navigate(['/treaty/treaty-type']);
  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: null,
      enableFilter: true
    };

    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('treatyGrid').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.search();
    //this.retrieveContractGrid();
    this.gridApi.sizeColumnsToFit();

  }
  selectedRow(val: any) {
<<<<<<< HEAD
=======
    //this.sequence = true;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.refNo = val.ttyHdrPK.thRefNo;
    this.amndNo = val.ttyHdrPK.thAmendNo;
    this.seqNo = val.ttyHdrPK.thSeqNo;
    this.contractType = val.thContractType;
    this.status = val.thApprSts;
    this.contType = val.thContractType;
    if (val.thContractType === 'TP' || 'FP' === val.thContractType) {
      if ('P' == val.thApprSts) {
        this.EditBtnFlag = true;
        this.AdjustBtnFlag = false;
        this.ViewBtnFlag = true;
      } else if ('A' == val.thApprSts) {
        this.ViewBtnFlag = true;
        this.EditBtnFlag = false;
        this.AdjustBtnFlag = true;
      }
    } else if (val.thContractType === 'TX' || 'FX' === val.thContractType) {
      if ('P' == val.thApprSts) {
        this.ViewBtnFlag = false;
        this.EditBtnFlag = true;
        this.AdjustBtnFlag = true;
      } else if ('A' == val.thApprSts) {
        this.ViewBtnFlag = true;
        this.EditBtnFlag = false;
        this.AdjustBtnFlag = true;
      }
    }


    this.viewdocument = true;
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: false,
        fileName: 'treaty_contract.xlsx',
        skipHeader: false,
        sheetName: 'Treaty Contract',
<<<<<<< HEAD
        columnKeys: ['ttyHdrPK.thRefNo', 'ttyHdrPK.thSeqNo', 'thTtyDesc', 'thStartDt', 'thEndDt', 'thUwYear', 'thContractDesc', 'thApprUid', 'thApprSts'],
=======
        columnKeys: ['ttyHdrPK.thRefNo','ttyHdrPK.thSeqNo', 'thTtyDesc', 'thStartDt', 'thEndDt', 'thUwYear', 'thContractDesc', 'thApprUid', 'thApprSts'],
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        processCellCallback: (params) => {
          if (params.column.colId == "thStartDt") {
            if (params.value == null || params.value == undefined) {
              return '';
            } else {
              return params.value;
            }
          } else if (params.column.colId == 'thEndDt') {
            if (params.value == null || params.value == undefined) {
              return '';
            } else {
              return params.value;
            }
          } else if (params.column.colId == 'thApprSts') {
            if (params.value == 'A')
              return 'Approved';
            else if (params.value == 'P')
              return 'Pending'
            else
              return params.value;
          } else {
            return params.value;
          }

        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
    this.gridApi.sizeColumnsToFit();
  }
  ContractRecovery() {
    let obj = {
      refno: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amndNo,
      type: 'Recovered',
      transactionId: this.recoveryTransId[0]
    }
    // if (this.recoveryCount != 0) {
    this.router.navigate(['/treaty/recovery-enquiry'], { queryParams: obj });
    // } else {
    //   this.router.navigate(['/treaty/recovery-enquiry']);
    // }

  }
<<<<<<< HEAD
=======

  viewAccounting() {
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'refNo': this.refNo, 'transId': this.transId, 'seqNo': this.seqNo, 'docType': 'DEP_PREM', 'amendNo': this.amndNo } });
  }

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
      if (control instanceof UntypedFormControl) {
=======
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

<<<<<<< HEAD
  viewAccounting() {
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'refNo': this.refNo, 'transId': this.transId, 'seqNo': this.seqNo, 'docType': 'DEP_PREM', 'amendNo': this.amndNo } });
  }
  closeModal() {
    this.modalService.hide();
  }
=======
  closeModal() {
    this.modalService.hide();
  }

  createRenewalForm() {
    this.renewalForm = this.fb.group({
      newRefno: [undefined, Validators.required],      
    });
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
}

function keyCreator(params) {
  var countryObject = params.value;
  return countryObject.name;
}

function statusCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    if ('A' == params.data.thApprSts) {
      status = 'Approved'
    } else {
      status = 'Pending'
    }
    return status;
  }
}
function strtDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.thStartDt).format('DD/MM/YYYY');
  }
}

function endDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.thEndDt).format('DD/MM/YYYY')
  }
}
var filterParams1 = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};