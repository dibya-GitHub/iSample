import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyContractComponent } from './treaty-contract.component';

describe('TreatyContractComponent', () => {
  let component: TreatyContractComponent;
  let fixture: ComponentFixture<TreatyContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyContractComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyContractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
