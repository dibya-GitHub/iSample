<<<<<<< HEAD
import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
=======
import { Component, OnInit, Input, Output, Inject, EventEmitter } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Router } from '@angular/router';
import { ApiUrls } from 'src/app/api-urls';
import { UntypedFormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ViewChild } from '@angular/core';
import { ElementRef } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { ToastService } from 'src/app/services/toast.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { EditviewrenderComponent } from '../editviewrender/editviewrender.component';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
declare var $: any;

@Component({
  selector: 'app-egnp-contract',
  templateUrl: './egnp-contract.component.html',
  styleUrls: ['./egnp-contract.component.css'],
  providers: [DatePipe, MycurrencyPipe]
})
export class EgnpContractComponent implements OnInit {
  deleteEGNP: any[];
  gridApi: any;
  public bottomData;
  public egnpSummaryColumn;
  public columnDefs;
  public defaultColDef;
  public getRowHeight;
  private gridOptions;
  public frameworkComponents;
  public context;
  private autoGroupColumnDef;
  userId: any;
  dropdownSettings: {};
  perilItem = [];
  perilCols = [];
  perilDetails = [];
  dropdownList = [];
  showPerilFrm: boolean;
  selectedItems = [];
  selectForm: UntypedFormGroup;
  layerNum: string;
  amendNo: any;
  compcode: any;
  showForm: boolean = false;
  code4: any;
  code3: any;
  code2: any;
  code1: any;
  code: any;
  lobList: any;
  divnList: any;
  compList: any;

  details: any[];
  cols: any[];

  epiForm: UntypedFormGroup;

  //action: string;
  display: boolean = false;
  collapsed: boolean = true;
  refNo: string;
  totalPremium: number = 0;
  baseCurrency: string = "";
  changeaction: string;
  @Input() contractNo: string;
  @Input() contractAmendNo: any;
  @Input() contractCurrency: string;
  @Input() action: string;
  @Input() seqNo: string;
  @Input() basecurr: any;
  @Input() contractType: any;
  @Input() egnpiLabel: string;
  @Input() egnpiAmt: string;
  @Input() xolTypeId: string;
  @Input() amndSrNo: any;
  @Output() getEgnpiAmt = new EventEmitter();
  @ViewChild('trigger') tr: ElementRef;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;

  code5: any;
  wizardLabel: string;
  temp: any;
  AddFlag: boolean = true;
  loding = false;
  showEntriesOptionSelected = 5;
  quickSearchValue: string = '';
  showEntriesOptions = [5, 10, 20, 50, 100];
  pinnedBottomRowData: any;
  private getRowStyle;

<<<<<<< HEAD
  constructor(
    private fb: UntypedFormBuilder,
=======
  constructor(private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private cpipe: MycurrencyPipe,
    private session: SessionStorageService,
    private modalService: BsModalService,
<<<<<<< HEAD
    private wizardHelperService: TreatyWizardHelperService
  ) {
=======
    private wizardHelperService: TreatyWizardHelperService) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.columnDefs = [


      {
        headerName: "Company",
        field: "companyName",
        sortable: true,
        enableRowGroup: true
      },
      {
        headerName: "Branch",
        field: "branch",
        sortable: true,
        enableRowGroup: true
      },
      {
        headerName: "Class",
        field: "classDesc",
        enableRowGroup: true
      },
      {
        headerName: "Premium",
        field: "tePrem",
        sortable: true,
        //valueFormatter: numberFormatter,
        headerClass: 'right-align-class',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tePrem) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.tePrem));
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        //cellRenderer: currencyFormatter
      },
      {
        headerName: 'Action',
        cellRendererFramework: EditviewrenderComponent,
         cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
<<<<<<< HEAD
      //   template:
      //     `<a>
      //         <i class="fa fa-file-pen fa-icon" style="color:#009ca6; font-size: 1.55em "  data-action-type="Edit"  title="Edit" aria-hidden="true" ></i>&nbsp;&nbsp;
      //         <i class="fa fa-trash fa-icon"  style="color:#009ca6; font-size: 1.55em" data-action-type="Remove"  title="Delete" aria-hidden="true"></i>
      //       </a>`
      // }
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    ];

    this.egnpSummaryColumn = [

      {
        headerName: "group",
        field: "class",
      },

      {
        headerName: "Company",
        field: "companyName",
      },
      {
        headerName: "Branch",
        field: "branch",
      },
      {
        headerName: "Class",
        field: "classDesc",
      },
      {
        headerName: "Premium",
        field: "tePrem",
        cellStyle: { textAlign: 'right' },
        valueFormatter: numberFormatter,
      },
      {
        headerName: "Action",
      }
    ];

    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true
    };
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      if (params.node.data != null)
        var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
  }

  ngOnInit() {

    this.userId = this.session.get('userId');
    this.changeaction = "save"

    if ('Proportional Treaty' == this.contractType) {
      this.wizardLabel = "EPI";
    } else {
      this.wizardLabel = "EGNPI";
    }
    this.userId = this.session.get('userId');
    this.changeaction = "save";

    this.epiFormgrpup();
    this.retrieveEpiDetails();
    this.retrieveCompDetails();


  }

  egnpSummaryDetails() {
    this.bottomData = [
      {
        class: 'Total',
        companyName: '',
        branch: '',
        classDesc: '',
        tePrem: this.totalPremium,
        Action: ''

      }
    ];
  }

  groupRowAggNodes(nodes) {
    var result = {
      tePrem: 0,
    };
    nodes.forEach(function (node) {
      var data = node.group ? node.aggData : node.data;
      if (typeof data.tePrem === "number") {
        result.tePrem += data.tePrem;
      }
    });
    return result;
  }

  proceed() {
    this.wizardHelperService.goNext();
  }


  epiFormgrpup() {
    this.epiForm = this.fb.group({
      teRefNo: this.refNo,
      teAmendNo: this.amendNo,
      tePrem: ['', Validators.required],
      teStatus: 'A',
      teCrUid: this.session.get('userId'),
      teCrDt: new Date(),
      teCompany: ['', Validators.required],
      teDivision: ['', Validators.required],
      teLob: ['', Validators.required],
      ttyEpiPK: '',
      teSeqNo: this.seqNo,
    })
  }
  retrieveEpiDetails() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveEpiDetailsById(this.contractNo, this.contractAmendNo, this.seqNo).subscribe(resp => {
      this.details = resp.egnpList;
      this.totalPremium = 0;
      if (this.details) {
        this.pinnedBottomRowData = createData(1, this.details, "Bottom");
      }
      for (var i = 0; i < this.details.length; i++) {
        this.totalPremium = this.totalPremium + parseFloat(this.details[i].tePrem);
      }
      this.egnpSummaryDetails();
      var objPk = {
        ttyHdrPK: { thRefNo: this.contractNo, thSeqNo: this.seqNo, thAmendNo: this.contractAmendNo },
      }
      this.treatyService.updateEpiAmount(this.totalPremium, objPk).subscribe(resp => {
        //this.toastService.success("Epi Amount Successfully Updated");
      });
      this.getEgnpiAmt.emit(this.totalPremium);
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;

    });
  }

  addEgnpi() {
    this.epiForm.reset()
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'add';
    if (this.action == 'add') {
      this.epiForm.controls['teCompany'].enable();
      this.epiForm.controls['teDivision'].enable();
      this.epiForm.controls['teLob'].enable();
      this.changeaction = 'save';
    }
    this.epiForm.reset()
  }
  editEpi(data: any) {
    this.AddFlag = false;
    this.retrieveCompDetails();
    this.treatyService.retrieveDivnDetails(data.ttyEpiPK.teCompany).subscribe(resp => {
      this.divnList = resp.divisionList;
    })
    this.retrieveLobDetail();
<<<<<<< HEAD
    // this.collapsed = !this.collapsed;
=======
    console.log(data);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.showForm = true;
    this.action = 'edit';
    this.code = data.ttyEpiPK.teRefNo
    this.code1 = data.ttyEpiPK.teAmendNo
    this.code2 = data.ttyEpiPK.teCompany
    this.code3 = data.ttyEpiPK.teDivision
    this.code4 = data.ttyEpiPK.teLob

    let objpk = {
      teRefNo: this.code,
      teAmendNo: this.code1,
      teCompany: this.code2,
      teDivision: this.code3,
      teLob: this.code4,
      teSeqNo: this.seqNo
    }
    this.treatyService.retrieveEgnpById(objpk).subscribe(result => {
      let resp = result.premiunList;
      this.epiForm.patchValue({
        teRefNo: resp.ttyEpiPK.teRefNo,
        teAmendNo: resp.ttyEpiPK.teAmendNo,
        tePrem: resp.tePrem,
        teStatus: resp.teStatus,
        teCrUid: resp.teCrUid,
        teCrDt: resp.teCrDt,
        teCompany: resp.ttyEpiPK.teCompany,
        teDivision: resp.ttyEpiPK.teDivision,
        teLob: resp.ttyEpiPK.teLob,
        ttyEpiPK: resp.ttyEpiPK,
        teSeqNo: resp.teSeqNo
      })
    });

    if (this.action == 'edit') {
      this.epiForm.controls['teCompany'].disable();
      this.epiForm.controls['teDivision'].disable();
      this.epiForm.controls['teLob'].disable();
      this.changeaction = "update"
    } else {
      this.epiForm.controls['teCompany'].enable();
      this.epiForm.controls['teDivision'].enable();
      this.epiForm.controls['teLob'].enable();
      this.changeaction = "update"
    }

  }
  save() {
    if (this.epiForm.valid) {
      // this.loaderService.isBusy = true;

      var objPk = {
        teRefNo: this.contractNo,
        teAmendNo: this.contractAmendNo,
        teCompany: this.epiForm.get('teCompany').value,
        teDivision: this.epiForm.get('teDivision').value,
        teLob: this.epiForm.get('teLob').value,
        teSeqNo: this.seqNo

      }
      if (this.action == 'edit') {
        this.epiForm.controls['teCompany'].enable()
        this.epiForm.controls['teDivision'].enable()
        this.epiForm.controls['teLob'].enable()
        this.epiForm.patchValue({
          ttyEpiPK: objPk,
          tePrem: this.epiForm.get("tePrem").value,
        })

        this.treatyService.updateEgnpById(this.epiForm.value, this.seqNo, this.amndSrNo).subscribe(resp => {
          this.toastService.success("Successfully Updated");
          // this.countChange.emit(resp.messageType);
          if (resp.mTtyEpiList) {
            this.details = resp.mTtyEpiList;
          }
          this.retrieveEpiDetails();
          this.showForm = false;
          this.AddFlag = true;

          //  this.retrieveEpiDetails();
        }, error => {
        })

      } else {


        this.epiForm.patchValue({
          ttyEpiPK: objPk,
          teStatus: 'A',
          teCrUid: this.session.get('userId'),
          teCrDt: new Date(),
          tePrem: this.epiForm.get("tePrem").value

        })
        //alert(this.epiForm.get("tePrem").value);
        this.treatyService.insertEgnp(this.epiForm.value, this.amndSrNo).subscribe(resp => {
          this.toastService.success("Successfully Saved");
          this.retrieveEpiDetails();
          // this.display = !this.display;
          this.epiForm.reset()
          this.showForm = false;
          this.AddFlag = true;

        }, error => {
        })
      }
    } else {
      this.validateAllFormFields(this.epiForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }


  retrieveCompDetails() {
    this.treatyService.retrieveCompDetails().subscribe(resp => {
      //this.applySelect();
      this.compList = resp.companyList;
    })
  }
  retrieveDivnetails(event) {

<<<<<<< HEAD
    // this.loaderService.isBusy = true;
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.compcode = event.value;
    this.treatyService.retrieveDivnDetails(this.compcode).subscribe(resp => {
      this.divnList = resp.divisionList;
    }, error => {
    })
  }
  retrieveLobDetails() {
    //alert(1);
    this.treatyService.retrieveLobDetails().subscribe(resp => {
      this.lobList = resp.lobList;
      for (var i = 0; i < this.details.length; i++) {
        for (var lob = 0; lob < this.lobList.length; lob++) {
          var lobListDesc = this.lobList[lob].value;
          var classDesc = this.details[i].classDesc
          var company = this.epiForm.get('teCompany').value;
          var division = this.epiForm.get('teDivision').value;
          // alert(lobListDesc+"-"+classDesc +"," +this.details[i].teCompany+"-" +company+","+this.details[i].teDivision+"-"+division)
          if (lobListDesc == classDesc && this.details[i].ttyEpiPK.teCompany == company && this.details[i].ttyEpiPK.teDivision == division) {
            this.lobList = $.grep(this.lobList, function (e) {
              return e.value != classDesc;
            });
          }
        }
      }
    })
  }

  retrieveLobDetail() {
    this.treatyService.retrieveLobDetails().subscribe(resp => {
      this.lobList = resp.lobList;
    })
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
      if (control instanceof UntypedFormControl) {
=======
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });


  }

  deleteEpi(data) {
    this.treatyService.deleteEgnpList(this.deleteEGNP, this.seqNo, this.amndSrNo).subscribe(resp => {
      this.modalService.hide();
      this.retrieveEpiDetails();
      this.toastService.success("Deleted Successfully");
      this.epiForm.reset()
      this.showForm = false;
      this.AddFlag = true;

    }, error => {
      this.modalService.hide();
      this.toastService.error(error.error.message);
    });
  }

  back() {
    this.showForm = false;
    this.AddFlag = true;

  }

  goPrevious() {
    this.wizardHelperService.goPrevious();
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    this.retrieveEpiDetails();


  }
  rowGroupOpened(params) {
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.editEpi(data);
        case "Remove":
          this.deleteEGNP = data.ttyEpiPK
          return this.showDialogbox(data);
      }
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  showDialogbox(data) {
    this.open(this.confirmcontent, 'modal-sm');
  }
  open(content, val) {
<<<<<<< HEAD
    this.modalService.show(content, { class: val });
=======
    this.modalService.show(content, { id: 1, class: val });
    // this.modalService.show(content, { size: val }).result.then((result) => {
    // }, (reason) => {
    // });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  applEgnpiData(data) {
    this.details = data;
    this.retrieveEpiDetails();

    this.pinnedBottomRowData = createData(1, this.details, "Bottom");
    this.getEgnpiAmt.emit(this.totalPremium);
  }

  onBtExport(gridApi: any) {
    if (gridApi) {
      gridApi.exportDataAsExcel({
        columnKeys:['companyName','branch','classDesc','tePrem'],
        processCellCallback: (params) => {
          if (params.column.colId == "tePrem"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }
        }
      });
    }
  }
  closeModal() {
    this.modalService.hide();
  }
}
function numberFormatter(params) {
  if (params.value != null)
    var currencyVal = Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  return currencyVal;
}
function createData(count, data, prefix) {
  var result = [];
  var sum = 0;
  for (var i = 0; i < data.length; i++) {
    sum = sum + data[i].tePrem;
  }
  for (var i = 0; i < count; i++) {
    result.push({
      companyName: 'Total',
      tePrem: sum
    });
  }
  return result;
}
function currencyFormatter(params) {
  if(params && params.value){   
    let cost = Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); 
    return cost; //'<span title="' + cost + '">'+cost+'</span>'
  } else {
    return ''
  }
}
