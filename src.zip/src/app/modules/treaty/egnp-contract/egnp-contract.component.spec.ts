import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EgnpContractComponent } from './egnp-contract.component';

describe('EgnpContractComponent', () => {
  let component: EgnpContractComponent;
  let fixture: ComponentFixture<EgnpContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EgnpContractComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EgnpContractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
