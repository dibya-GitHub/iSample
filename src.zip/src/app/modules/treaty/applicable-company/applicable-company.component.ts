import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
@Component({
  selector: 'app-applicable-company',
  templateUrl: './applicable-company.component.html',
  styleUrls: ['./applicable-company.component.scss']
})
export class ApplicableCompanyComponent implements OnInit {
  contTypeVal = 'Applicable Companies';
  @Input() action: string;
  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() seqNo: number;
  @Input() contractType;
  @Input() basecurr;
  @Input() fullContractType: string;
  @Input() xolType;
  @Input() amndSrNo: any;

  showForm: boolean;
  actionBtn: boolean = true;

  applicableCompanyForm: UntypedFormGroup;
  applicableCompanyList: any = [];
  private gridApi;
  public gridOptions;
  public defaultColDef;
  public getRowHeight;
  columnDefs = [];
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  quickSearchValue: string = '';
  temp: any;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  lobCompanyList: any = [];
  lobProductList: any = [];
  divisionCode: any;
  companyCode: any;
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private session: SessionStorageService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private wizardHelper: TreatyWizardHelperService,
    private modalService: BsModalService
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true
    };
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      if (params.node.data != null)
        var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
    this.columnDefs = [
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "mttyCompPk.toDivnCode",
        sortable: true,
        enableRowGroup: true,
        cellStyle: { textAlign: 'left' },        
        valueGetter: function (params) {
          if (params && params.data && params.data.mttyCompPk.toDivnCode && params.data.toDivnCodeDesc) {
            return params.data.mttyCompPk.toDivnCode + ' - ' + params.data.toDivnCodeDesc;
          } else if (params && params.data && params.data.mttyCompPk.toDivnCode) {
            return params.data.mttyCompPk.toDivnCode;
          } else { return '' }
        },
      },
      {
        headerName: "Action",
        template:
          `<a>
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
          </a>`,
        cellStyle: { textAlign: 'center' },
        resizable: false,
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
    ];
  }

  ngOnInit(): void {
    this.divisionCode = this.session.get('divisionCode');
    this.companyCode = this.session.get('companyCode');
    this.createApplicableProductForm();
    // this.getApplicableCompanies();
    this.getAllApplicableCompanies();
  }
  getApplicableCompanies() {
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
    };
    this.treatyService.getApplicableCompanies(obj).subscribe((resp: any) => {
      this.lobCompanyList = resp.list;
      this.lobCompanyList = (this.lobCompanyList as any).map(code => {
        code.value = code.key + ' - ' + code.value;
        return code;
      });
    }, error => {
      this.toastService.error(error);
    });
  }
  getAllApplicableCompanies() {
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
    };
    this.treatyService.getAllApplicableCompanies(obj).subscribe((resp: any) => {
      this.applicableCompanyList = resp;
    }, error => {
      this.toastService.error(error);
    });
  }
  createApplicableProductForm() {
    this.applicableCompanyForm = this.fb.group({
      toCompCode: ['', Validators.required],
    })
  }
  back() {
    this.showForm = false;
    this.applicableCompanyForm.reset();
  }
  close() {
    this.modalService.hide();
  }
  goPrevious() {
    this.wizardHelper.goPrevious();
  }
  nextStep() {
    if (this.contractType == 'TP') {
      if (this.applicableCompanyList.length > 0) {
        this.wizardHelper.goNext();
      } else {
        this.toastService.warning("Add atleast 1 Applicable Company for this Contract");
      }
    } else {
      this.wizardHelper.goNext();
    }

  }
  addApplicableCompany() {
    this.applicableCompanyForm.reset();
    this.showForm = true;
    this.actionBtn = true;
    this.action = 'add';
    this.applicableCompanyForm.reset();
    // this.applicableCompanyForm.get('toCompCode').enable();
    this.getApplicableCompanies();
  }
  saveForm() {
    this.loaderService.isBusy = true;
    if (this.applicableCompanyForm.valid) {
      console.log(this.applicableCompanyForm);
      // let data = this.applicableCompanyForm.value;
      let data =
      {
        "mttyCompDtoPk": {
          "toRefNo": this.refNo,
          "toSeqNo": this.seqNo,
          "toAmendNo": this.amendNo,
          "toDivnCode": this.applicableCompanyForm.get('toCompCode').value,
          "toCompCode": this.companyCode,
        }
      }
      this.treatyService.saveApplicableCompanies(data).subscribe(resp => {
        this.toastService.success('Successfully Updated');
        this.showForm = false;
        this.loaderService.isBusy = false;
        this.getAllApplicableCompanies();
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      })
    } else {
      this.validateAllFormFields(this.applicableCompanyForm);
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  deleteRow() {
    this.loaderService.isBusy = true;
    if (this.temp && this.temp.mttyCompPk.toRefNo) {
      this.treatyService.deleteApplicableCompany(this.temp.mttyCompPk).subscribe(() => {
        this.toastService.success('Deleted Succcessfully.');
        this.getAllApplicableCompanies();
        this.close();
        this.showForm = false;
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      })
    } else {
      this.loaderService.isBusy = false;
      this.toastService.error('Error in Deleting Data');
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: false,
        fileName: 'applicable_company.xlsx',
        skipHeader: false,
        sheetName: 'Applicable Companies',
        columnKeys: ['mttyCompPk.toDivnCode']
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
  showDialogbox(data: any) {
    this.temp = data;
    this.open(this.confirmModal, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("applicableCompanyTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
   </a>`;
  }
}
