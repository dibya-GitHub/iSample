import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicableCompanyComponent } from './applicable-company.component';

describe('ApplicableCompanyComponent', () => {
  let component: ApplicableCompanyComponent;
  let fixture: ComponentFixture<ApplicableCompanyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplicableCompanyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicableCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
