import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';

@Component({
  selector: 'app-treaty-cashadvance',
  templateUrl: './treaty-cashadvance.component.html',
  styleUrls: ['./treaty-cashadvance.component.scss']
})
export class TreatyCashadvanceComponent implements OnInit {
  bsCurr: any;
  refNo: any;
  amendNo: any;
  loginId: any;
  seqNo: any;
  thContractType: any;
  contDesc: any;
  contractAmendNo: any;
  contractNo: any;
  cashAdvanceForm: UntypedFormGroup;
  cashAdvanceReinsForm: UntypedFormGroup;
  contractHeaderForm: UntypedFormGroup;
  gridApi: any;
  showEntriesOptionSelected = 5;
  quickSearchValue: string = '';
  showEntriesOptions = [5, 10, 20, 50, 100];
  cashAdvanceDetails: any;
  cashAdvanceReinsDetails: any;
  cashAdvanceAdjDetails: any;
  defaultColDef: any;
  cashAdcolumnDefs: any;
  public context;
  showForm: boolean = false;
  action: string;
  contractCode: string;
  cashAdvformReadonly: boolean = false;
  showReinsDetail: boolean = false;
  actionReins: string;
  showFormReins: boolean = false;
  gridApiReins: any;
  showEntriesOptionSelectedReins = 5;
  quickSearchValueReins: string = '';
  showEntriesOptionsReins = [5, 10, 20, 50, 100];
  gridApiAdDt: any;
  showEntriesOptionSelectedAdDt = 5;
  quickSearchValueAdDt: string = '';
  showEntriesOptionsAdDt = [5, 10, 20, 50, 100];
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  currencyList: any;
  showRefNoDropdown: boolean = false;
  showSubmitBtns:boolean = false;
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private toastService: ToastService,
    private modalService: BsModalService,
    private router: Router,
  ) {
    this.cashAdvanceColDef();
    this.cashAdvanceReinsColDef();
  }

  ngOnInit(): void {
    this.bsCurr = this.session.get('baseCurrency');
    //this.action = this.treatyService.getParamValue('action');
    this.refNo = this.treatyService.getParamValue('refNo') == undefined ? this.contractNo : this.treatyService.getParamValue('refNo');
    this.amendNo = this.treatyService.getParamValue('amendNo') == undefined ? this.contractAmendNo : this.treatyService.getParamValue('amendNo');
    this.loginId = this.session.get('userId') == undefined ? "test" : this.session.get('userId');
    this.seqNo = this.treatyService.getParamValue('seqNo');
    this.thContractType = this.treatyService.getParamValue('contractType');
    this.contDesc = this.treatyService.getParamValue('contDesc');
    this.contractCode = this.refNo + '/' + this.seqNo;
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false
    };
    if (!this.refNo) {
      this.getAllApprovedContract();
      this.showRefNoDropdown = true;
      this.cashAdvanceDetails = [];
    } else {
      this.showRefNoDropdown = false;
      this.getAllCashAdvance();
    }
    this.createCashAdvHeaderForm();
    //this.getAllCashAdvance();
    this.createCashAdvanceForm();
    this.createCashAdReinsForm();
    this.getcontractHeader();
    this.reterieveReInsList();
    this.cashAdjustmentDtscolumn();
    this.getCurrency();
  }
  createCashAdvHeaderForm() {
    this.contractHeaderForm = this.fb.group({
      contRefNo: "",
      contDesc: ""
    })
  }
  reset() {
    this.contractHeaderForm.patchValue({
      contRefNo: '',
      contDesc: '',
    });
    this.pageChanged({ page: 1 });
  }
  getcontractHeader() {
    this.contractHeaderForm.patchValue({
      contRefNo: this.refNo + ' / ' + this.seqNo,
      contDesc: this.contDesc
    })
  }
  cashAdvanceColDef() {
    this.cashAdcolumnDefs = [
      {
        headerName: "CA Ref ID",
        field: "tXlAdvancePk.txvTransId",
      },
      {
        headerName: "CA Sr No",
        field: "tXlAdvancePk.txvSrNo",
      },
      {
        headerName: "Contract",
        field: "txvTtyRefNo",
        valueGetter: function (params) {
          if (params.data && params.data.txvTtyRefNo && params.data.txvTtySeqNo) {
            return params.data.txvTtyRefNo + " / " + params.data.txvTtySeqNo;
          } else {
            return params.data.txvTtyRefNo;
          }
        },
      },
      {
        headerName: "Remarks",
        field: "txvRemarks",
      },
      {
        headerName: "Status",
        field: "txvApprSts",
        valueGetter: function (params) {
          if (params.data.txvApprSts && params.data.txvApprSts == 'A') {
            return 'Approved'
          } else if (params.data.txvApprSts && params.data.txvApprSts == 'P') {
            return 'Pending';
          } else {
            return ''
          }
        }
      },
      {
        headerName: "Approved By",
        field: "txvApprUid",
      },
      {
        headerName: "Approved On",
        field: "txvApprDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.txvApprDt) {
            return moment(params.data.txvApprDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        headerName: "Action",
        field: "tXlAdvancePk.txvTransId",
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
        cellRenderer: function (params) {
          if (params.data.txvApprSts && params.data.txvApprSts == 'A') {
            return `<a> <i class="fa fa-eye fa-icon" data-action-type="View"  title="View" aria-hidden="true" ></i>
            </a>`
          } else if (params.data.txvApprSts && params.data.txvApprSts == 'P') {
            return ` <a>
            <i class="fa fa-file-pen fa-icon" data-action-type="Edit"  title="Edit Rebate" aria-hidden="true" ></i>
            &nbsp;&nbsp;
            <i class="fa fa-solid fa-gear fa-icon" data-action-type="Process"  title="Process" aria-hidden="true" ></i>
            </a>`;
          } else {
            return ''
          }
        }

      },
    ]
  }

  cashAdReinscolumnDefs: any;
  cashAdvanceReinsColDef() {
    this.cashAdReinscolumnDefs = [
      {
        headerName: "Reinsurer / Broker",
        field: "tvcCustName",
      },
      {
        headerName: "Created date",
        field: "tvcCrDt",
        valueGetter: function (params) {
          if (params && params.data && params.data.tvcCrDt) {
            return moment(params.data.tvcCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        headerName: "Currency",
        field: "tvcAcntCurr",
      },
      {
        headerName: "Advance Amt FC",
        field: "tvcAmt",
        valueGetter: function (params) {
          if (params.data && params.data.tvcAmt) {
            return Number(params.data.tvcAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Adjusted FC",
        field: "tvcAdjFCAmt",
        valueGetter: function (params) {
          if (params.data && params.data.tvcAdjFCAmt) {
            return Number(params.data.tvcAdjFCAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Balance FC",
        field: "tvcBalFCAmt",
        valueGetter: function (params) {
          if (params.data && params.data.tvcBalFCAmt) {
            return Number(params.data.tvcBalFCAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Advance Amt FC",
        field: "tvcttyAmt",
        valueGetter: function (params) {
          if (params.data && params.data.tvcttyAmt) {
            return Number(params.data.tvcttyAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Adjusted LC",
        field: "tvcttyAdjLCAmt",
        valueGetter: function (params) {
          if (params.data && params.data.tvcttyAdjLCAmt) {
            return Number(params.data.tvcttyAdjLCAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Balance LC",
        field: "tvcttyBalLCAmt",
        valueGetter: function (params) {
          if (params.data && params.data.tvcttyBalLCAmt) {
            return Number(params.data.tvcttyBalLCAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Action",
        field: "tvcTransId",
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
        cellRenderer: function (params) {
          if (params.data.txvApprSts && params.data.txvApprSts == 'P') {
            return ` <a>
            <i class="fa fa-file-pen fa-icon" data-action-type="Edit"  title="Edit" aria-hidden="true" ></i></a>
            &nbsp;&nbsp;<a>
            <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete"  title="Delete" aria-hidden="true"></i>
            </a>`;
          } else if (params.data.txvApprSts && params.data.txvApprSts == 'A') {
            return `<a> <i class="fa fa-eye fa-icon" data-action-type="View"  title="View Adjustment" aria-hidden="true" ></i>
            </a>`;
          } else {
            return ''
          }
        }

      },
    ]
  }
  createCashAdvanceForm() {
    this.cashAdvanceForm = this.fb.group({
      txvTtyRefNo: ['', Validators.required],
      txvTtySeqNo: "",
      txvClmNo: "",
      txvEvent: "",
      txvLossDesc: ['', Validators.required],
      txvApprSts: "",
      txvApprUid: "",
      tvcTransId: "",
      tvcSrNo: "",
      contractCode: "",
      claimNo: "",
      contractDesc: ['', Validators.required],
      transSNo: "",
      eventID: "",
      txvRemarks: "",
      txvTransId: [''],
      txvSrNo: [''],
    })
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  rowGroupOpened(params) {
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "View":
          return this.viewCashAdvance(data);
        case "Edit":
          return this.editCashAdvance(data);
        case "Process":
          this.processCashAdvance(data);
      }
    }
  }
  showAdjustmentDetail: boolean = false;
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  addCashAdvance() {
    this.cashAdvanceForm.reset();
    this.cashAdvanceForm.patchValue({ txvTtyRefNo: this.contractCode, contractDesc: this.contDesc });
    this.showForm = true;
    this.cashAdvformReadonly = false;
    this.action = 'Add';
  }
  saveCashAdv() {
    if (this.cashAdvanceForm.valid) {
      let data = this.cashAdvanceForm.getRawValue();
      if (this.action == 'Add') {
        this.loaderService.isBusy = true;
        let requestData = {
          txvTtyRefNo: data.txvTtyRefNo,
          txvClmNo: data.txvClmNo,
          txvEvent: data.txvEvent,
          txvLossDesc: data.txvLossDesc,
          txvApprSts: 'P',
          txvApprUid: this.loginId,
          txvRemarks: data.txvRemarks
        }
        this.treatyService.saveCashAdvance(requestData).subscribe(resp => {
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.toastService.success(resp["message"]);
            this.showForm = false;
            this.getAllCashAdvance();
          }
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        });
      } else {
        this.loaderService.isBusy = true;
        let requestData = {
          txvTtyRefNo: data.txvTtyRefNo,
          txvClmNo: data.txvClmNo,
          txvEvent: data.txvEvent,
          txvLossDesc: data.txvLossDesc,
          txvApprSts: 'P',
          txvApprUid: this.loginId,
          txvTtySeqNo: data.txvTtySeqNo,
          txvRemarks: data.txvRemarks,
          tXlAdvancePk: {
            txvTransId: data.txvTransId,
            txvSrNo: data.txvSrNo
          }
        }
        this.treatyService.updateCashAdvance(requestData).subscribe(resp => {
          if (resp["messageType"] && resp["messageType"] == 'ERROR') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.toastService.success(resp["message"]);
            this.showForm = false;
            this.getAllCashAdvance();
          }
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        })
      }
    } else {
      this.validateAllFormFields(this.cashAdvanceForm);
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      // console.log(field);
      const control = formGroup.get(field);
      //console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        //console.log(formGroup.get(field));
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  cancel() {
    this.cashAdvanceForm.reset();
    this.showForm = false;
    this.action = '';
  }

  cashAdvDtail: any;
  editCashAdvance(data) {
    this.loaderService.isBusy = true;
    this.cashAdvanceForm.reset();
    this.showForm = true;
    this.showReinsDetail = false;
    this.action = 'Edit';
    this.treatyService.getCashAdvanceById(data.txvTtyRefNo, data.tXlAdvancePk.txvTransId, data.tXlAdvancePk.txvSrNo).subscribe(resp => {
      this.cashAdvDtail = resp;
      this.cashAdvanceForm.patchValue({
        txvTtyRefNo: this.cashAdvDtail.txvTtyRefNo,
        txvClmNo: this.cashAdvDtail.txvClmNo,
        txvEvent: this.cashAdvDtail.txvEvent,
        txvLossDesc: this.cashAdvDtail.txvLossDesc,
        txvApprSts: this.cashAdvDtail.txvApprSts,
        txvApprUid: this.cashAdvDtail.txvApprUid,
        contractDesc: this.contDesc,
        txvTransId: this.cashAdvDtail.tXlAdvancePk.txvTransId,
        txvSrNo: this.cashAdvDtail.tXlAdvancePk.txvSrNo,
        txvTtySeqNo: this.cashAdvDtail.txvTtySeqNo,
        txvRemarks: this.cashAdvDtail.txvRemarks,
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })

  }

  processData: any;
  processCashAdvance(data) {
    this.showReinsDetail = true;
    this.processData = data;
    this.fetchAllReinsCashAdvDetails();
    this.getContractCurrency();
    this.goToBottom();
  }
  viewCashAdvance(data) {
    this.loaderService.isBusy = true;
    this.showForm = true;
    this.action = 'View';
    this.treatyService.getCashAdvanceById(data.txvTtyRefNo, data.tXlAdvancePk.txvTransId, data.tXlAdvancePk.txvSrNo).subscribe(resp => {
      this.cashAdvDtail = resp;
      this.cashAdvanceForm.patchValue({
        txvTtyRefNo: this.cashAdvDtail.txvTtyRefNo,
        txvClmNo: this.cashAdvDtail.txvClmNo,
        txvEvent: this.cashAdvDtail.txvEvent,
        txvLossDesc: this.cashAdvDtail.txvLossDesc,
        txvApprSts: this.cashAdvDtail.txvApprSts,
        txvApprUid: this.cashAdvDtail.txvApprUid,
        contractDesc: this.contDesc,
        txvTransId: this.cashAdvDtail.tXlAdvancePk.txvTransId,
        txvSrNo: this.cashAdvDtail.tXlAdvancePk.txvSrNo,
        txvTtySeqNo: this.cashAdvDtail.txvTtySeqNo
      });
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  getAllCashAdvance() {
    this.loaderService.isBusy = true;
    this.treatyService.getAllCashAdvanceDetails(this.refNo, this.seqNo).subscribe(resp => {
      this.cashAdvanceDetails = resp;
      this.showSubmitBtns = true;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  createCashAdReinsForm() {
    this.cashAdvanceReinsForm = this.fb.group({
      tvcTransId: '',
      tvcSrNo: '',
      tvcCustCode: ['', Validators.required],
      tvcAcntCurr: ['', Validators.required],
      tvcTtyCurr: '',
      tvcAmt: ['', Validators.required],
      tvcttyAmt: '',
      tvcRemarks: '',
      tvcCrDt: '',
      tvcCrUid: ''
    })
  }

  addCashAdvanceReins() {
    this.cashAdvanceReinsForm.reset();
    this.showFormReins = true;
    this.actionReins = 'Add';
    this.cashAdvanceReinsForm.patchValue({
      tvcTransId: this.processData.tXlAdvancePk.txvTransId,
      tvcSrNo: this.processData.tXlAdvancePk.txvSrNo,
      tvcRemarks: this.processData.txvRemarks,
      tvcAcntCurr: this.contractCurr,
      tvcTtyCurr: this.contractCurr,
    });
  }
  reInsList: any;
  reterieveReInsList() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveReInsList(ApiUrls.REINS_MGMT_PATH, ApiUrls.REINS_CML_ID).subscribe(resp => {
      this.reInsList = resp.reInsList;
      //this.reBrkList = resp.reInsList;
      console.log("reinsurer retrieved", resp);
      this.loaderService.isBusy = false;

    }, error => { this.loaderService.isBusy = false; })
  }
  cashAdvanceCustData: any;
  editCashAdvanceReins(data) {
    this.cashAdvanceReinsForm.reset();
    this.showFormReins = true;
    this.showAdjustmentDetail = false;
    this.actionReins = 'Edit';
    this.treatyService.getCashAdvanceCustById(data.tvcTransId, data.tvcSrNo, data.tvcCustCode).subscribe(resp => {
      this.cashAdvanceCustData = resp;
      this.cashAdvanceReinsForm.patchValue({
        tvcCustCode: this.cashAdvanceCustData.tXlAdvanceCustPk.tvcCustCode,
        tvcRemarks: this.cashAdvanceCustData.tvcRemarks,
        tvcAcntCurr: this.cashAdvanceCustData.tvcAcntCurr,
        tvcAmt: this.cashAdvanceCustData.tvcAmt,
        tvcttyAmt: this.cashAdvanceCustData.tvcttyAmt,
        tvcTtyCurr: this.cashAdvanceCustData.tvcTtyCurr,
        tvcTransId: this.cashAdvanceCustData.tXlAdvanceCustPk.tvcTransId,
        tvcSrNo: this.cashAdvanceCustData.tXlAdvanceCustPk.tvcSrNo,

      });
    });

  }
  cancelReins() {
    this.showFormReins = false;
    this.actionReins = '';
  }
  //Reinsurer Cash Advance Grid
  onGridSizeChangedReins(params) {
    var gridWidth = document.getElementById("allCashAdvReinsTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReadyReins(params) {
    this.gridApiReins = params.api;
    this.gridApiReins.sizeColumnsToFit();
  }
  rowGroupOpenedReins(params) {
    params.api.sizeColumnsToFit();
  }
  displayedRowCountReins() {
    if (this.gridApiReins) {
      return this.gridApiReins.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onRowClickedReins(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.editCashAdvanceReins(data);
        case "Delete":
          this.showReinsDetail = true;
          return this.showDialogbox(data);
        case "View":
          this.showAdjustmentDetail = true;
          this.getAllAdjustmentDetails();
          return;
      }
    }
  }
  onFirstDataRenderedReins(params) {
    params.api.sizeColumnsToFit();
  }

  pageChangedReins(event: any): void {
    this.gridApiReins.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChangeReins(event: any) {
    this.gridApiReins.paginationSetPageSize(this.showEntriesOptionSelectedReins);
    this.gridApiReins.paginationGoToPage(0);
  }

  onQuickFilterChangedReins() {
    this.gridApiReins.setQuickFilter(this.quickSearchValueReins);
  }
  cashAdvCusDel: any;
  showDialogbox(reInsInfo: any) {
    this.cashAdvCusDel = reInsInfo;
    this.open(this.confirmcontent, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }

  closeModal() {
    this.modalService.hide();
  }
  //Adjustment Detail Grid
  cashAdDtcolumnDefs: any;
  cashAdjustmentDtscolumn() {
    this.cashAdDtcolumnDefs = [
      {
        headerName: "Rec Ref",
        field: "RecRef",
      },
      {
        headerName: "Layer",
        field: "Layer",
      },
      {
        headerName: "Recovery",
        field: "Recovery",
      },
      {
        headerName: "Claim Recovered",
        field: "ClaimRecoveredFC",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Cash Advance Adjusted FC",
        field: "AdjustedFC",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Claim Recovery",
        field: "ClaimRecovery",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Cash Advance",
        field: "CashAdvance",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Claim Recovered",
        field: "ClaimRecovered",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Cash Advance Adjusted LC",
        field: "AdjustedLC",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Claim Recovery",
        field: "ClaimRecoveryLC",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Cash Advance",
        field: "CashAdvanceLC",
        cellStyle: { textAlign: 'right' },
      },

    ]
  }

  getAllAdjustmentDetails() {
    this.cashAdvanceAdjDetails = [
      {
        "RecRef": "301-0", "Layer": "1", "Recovery": "209-3456", "ClaimRecoveredFC": "1,000,000.00",
        "AdjustedFC": "7,50,00.00", "ClaimRecovery": "2,50,000.00", "CashAdvance": '-7,50,000.00',
        "ClaimRecovered": "5,55,555.56", "AdjustedLC": "4,16.666.67", "ClaimRecoveryLC": "1,38,888.89",
        "CashAdvanceLC": "-4,16,666.67"
      }
    ]
    this.goToBottom();
  }
  onGridSizeChangedAdDt(params) {
    var gridWidth = document.getElementById("allAdDtTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReadyAdDt(params) {
    this.gridApiAdDt = params.api;
    this.gridApiAdDt.sizeColumnsToFit();
  }
  rowGroupOpenedAdDt(params) {
    params.api.sizeColumnsToFit();
  }
  displayedRowCountAdDt() {
    if (this.gridApiAdDt) {
      return this.gridApiAdDt.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onRowClickedAdDt(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        // case "Edit":
        //   return this.editCashAdvanceReins(data);
        // case "Delete":
        //   this.showReinsDetail = true;
        //   return this.showDialogbox(data);
        //   case "View":
        //   this.showAdjustmentDetail = true;
        //   return;
      }
    }
  }
  onFirstDataRenderedAdDt(params) {
    params.api.sizeColumnsToFit();
  }

  pageChangedAdDt(event: any): void {
    this.gridApiAdDt.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChangeAdDt(event: any) {
    this.gridApiAdDt.paginationSetPageSize(this.showEntriesOptionSelectedAdDt);
    this.gridApiAdDt.paginationGoToPage(0);
  }
  closeAdDetails() {
    this.showAdjustmentDetail = false;
  }
  saveReins() {
    if (this.cashAdvanceReinsForm.valid) {
      let data = this.cashAdvanceReinsForm.getRawValue();
      if (this.actionReins == 'Add') {
        this.loaderService.isBusy = true;
        let formData = {
          tXlAdvanceCustPk:
          {
            tvcTransId: data.tvcTransId,
            tvcSrNo: data.tvcSrNo,
            tvcCustCode: data.tvcCustCode
          },
          tvcAcntCurr: data.tvcAcntCurr,
          tvcAmt: data.tvcAmt,
          tvcTtyCurr: data.tvcTtyCurr,
          tvcttyAmt: data.tvcttyAmt,
          tvcRemarks: data.tvcRemarks,
          tvcCrDt: new Date(),
          tvcCrUid: this.loginId
        }

        this.treatyService.saveCashAdvanceCust(formData).subscribe(resp => {
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.toastService.success(resp["message"]);
            this.showFormReins = false;
            this.fetchAllReinsCashAdvDetails();
          }
          this.loaderService.isBusy = false;
        }, error => {
          if (error instanceof HttpErrorResponse) {
            if (error.error instanceof ErrorEvent) {
              this.loaderService.isBusy = false;
              this.toastService.error(error.error.message);
            } else {
              switch (error.status) {
                case 400:
                  this.loaderService.isBusy = false;
                  this.toastService.warning(error.error.message);
                  break;
                default:
                  this.loaderService.isBusy = false;
                  this.toastService.error(error.error.message);
                  break;
              }
            }
          } else {
            this.loaderService.isBusy = false;
            this.toastService.error(error.error.message);
          }
        });
      } else {
        this.loaderService.isBusy = true;
        let formData = {
          tXlAdvanceCustPk:
          {
            tvcTransId: data.tvcTransId,
            tvcSrNo: data.tvcSrNo,
            tvcCustCode: data.tvcCustCode
          },
          tvcAcntCurr: data.tvcAcntCurr,
          tvcAmt: data.tvcAmt,
          tvcTtyCurr: data.tvcTtyCurr,
          tvcttyAmt: data.tvcttyAmt,
          tvcRemarks: data.tvcRemarks,
          tvcCrDt: new Date(),
          tvcCrUid: this.loginId
        }

        this.treatyService.updateCashAdvanceCust(formData).subscribe(resp => {
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.toastService.success(resp["message"]);
            this.showFormReins = false;
            this.fetchAllReinsCashAdvDetails();
          }
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        });
      }
    } else {
      this.validateAllFormFields(this.cashAdvanceReinsForm);
    }

  }

  goToBottom() {
    setTimeout(() => {
      window.scrollTo({ left: 0, top: document.body.scrollHeight, behavior: "smooth" });
    }, 200);
  }

  getCurrency() {
    this.treatyService.retrievecurrencyList().subscribe(resp => {
      this.currencyList = resp.currencyList;
    });
  }

  fetchAllReinsCashAdvDetails() {
    this.loaderService.isBusy = true;
    this.treatyService.getAllCustCashAdvance(this.processData.tXlAdvancePk.txvTransId, this.processData.tXlAdvancePk.txvSrNo).subscribe(resp => {
      this.cashAdvanceReinsDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  contractCurr: any;
  getContractCurrency() {
    this.treatyService.getContractCurrency(this.refNo, this.seqNo, this.amendNo ? this.amendNo : 0).subscribe(resp => {
      this.contractCurr = resp.contractCurr;
    });
  }

  deleteCashAdvReIns() {
    this.loaderService.isBusy = true;
    this.treatyService.deleteCashAdvCust(this.cashAdvCusDel.tvcTransId, this.cashAdvCusDel.tvcSrNo, this.cashAdvCusDel.tvcCustCode).subscribe(resp => {
      this.cashAdvanceCustData = resp;
      if (resp["messageType"] && resp["messageType"] == 'E') {
        this.toastService.error(resp["message"]);
      } else if (resp["messageType"] && resp["messageType"] == 'S') {
        this.toastService.success(resp["message"]);
        this.modalService.hide();
        this.fetchAllReinsCashAdvDetails();
      }
      this.loaderService.isBusy = false;
    });

  }

  back() {
    this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'home' } });
  }
  contractRefList: any;
  getAllApprovedContract() {
    this.treatyService.contReferenceList().subscribe(resp => {
      this.contractRefList = resp
      console.log("Reference list ---- ->", this.contractRefList)
    }, err => { })
  }

  getContratDt(event) {
    let contNo = event.value;
    console.log('event :' + event.key);
    const ContDet = contNo.split("-");
    this.refNo = ContDet[0];
    this.seqNo = ContDet[1];
    this.contractCode = this.refNo + '/' + this.seqNo;
    this.contDesc = ContDet[2];
    this.contractHeaderForm.patchValue({ contDesc: ContDet[2] });
  }
  transId: any;
  amndNo: any;
  viewAccounting() {
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'refNo': this.refNo, 'transId': this.transId, 'seqNo': this.seqNo, 'docType': 'CASH_ADV', 'amendNo': this.amendNo } });
  }
}
