import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyCashadvanceComponent } from './treaty-cashadvance.component';

describe('TreatyCashadvanceComponent', () => {
  let component: TreatyCashadvanceComponent;
  let fixture: ComponentFixture<TreatyCashadvanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TreatyCashadvanceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TreatyCashadvanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
