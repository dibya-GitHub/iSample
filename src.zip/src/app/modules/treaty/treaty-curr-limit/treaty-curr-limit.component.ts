<<<<<<< HEAD
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { LoaderService } from 'src/app/services/loader.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';

=======
import { Component, OnInit, Input, Inject } from '@angular/core';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { ViewChild } from '@angular/core';
import { ElementRef } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { ToastService } from 'src/app/services/toast.service';
import { LoaderService } from 'src/app/services/loader.service';
import { BsModalService } from 'ngx-bootstrap/modal';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@Component({
  selector: 'app-treaty-curr-limit',
  templateUrl: './treaty-curr-limit.component.html',
  styleUrls: ['./treaty-curr-limit.component.css']
})
export class TreatyCurrLimitComponent implements OnInit {
  premium: any[];
  @Input() action: any;
  @Input() amendNo: any;
  @Input() refNo: any;
  @Input() seqNo: any;
  @Input() CurrType: any;
  @Input() Curr: any;
  details: any[];
  _layer: string;
  Curr_List: any;
  tcRefNo: any;
  tcAmendNo: any;
  tcLayer: any;
  tcCurr: any;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  Curr_type: any;

  set layer(value: string) {
    this._layer = value;
    this.toggleModal();
  }
  @Input()
  get layer(): string {
    return this._layer;
  }

<<<<<<< HEAD
  constructor(
    private treatyService: TreatyService,
    private modalService: BsModalService,
    private loaderService: LoaderService
  ) { }
=======
  constructor(private treatyService: TreatyService,
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private modalService: BsModalService,
    private loaderService: LoaderService) { }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  ngOnInit() {
    this.premium = [
      // { field: 'tcCurrDesc', header: 'Currency' },
      { field: 'mttyCurrPK', header: 'Currency', subFields: 'tcCurr' },
      { field: 'tcFixedRate', header: 'ROE' },
      { field: 'tcMinPrem', header: 'Minimum' },
      { field: 'tcDepPrem', header: 'Deposit' },
      { field: 'tcMinPremLc1', header: 'Minimum' },
      { field: 'tcDepPremLc1', header: 'Deposit' },
      { field: 'Action', header: 'Action' }

    ];
    this.toggleModal();
  }
  toggleModal() {

    this.details = [];
    if ("view" == this.action) {
      // this.showForm=false;
    }
    this.retrieveTreatyCurrList();
  }

  retrieveTreatyCurrList() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: this.layer,
      seqNo: this.seqNo,
      curr: this.Curr,
      type: 'PR'
    }
    this.treatyService.retrieveCurrencyPremById(obj).subscribe(resp => {
      //  for(var i=0;i<resp.length;i++){
      //   this.details=resp[i];
      //  }
      this.details = resp;
      this.scriptcall('currency-premium');
      this.loaderService.isBusy = false;
    }, error => {
      this.scriptcall('currency-premium');
      this.loaderService.isBusy = false;
    })
  }

  scriptcall(id) {
    // $('#'+id).DataTable().destroy(); 
    //  setTimeout(() => {
    //   $('#'+id).DataTable().draw();
    //  }, 100);
  }

  editPremiumData(data) {
    let objPk = {
      refNo: data.mttyCurrPK.tcRefNo,
      amdNo: data.mttyCurrPK.tcAmendNo,
      layer: data.mttyCurrPK.tcLayer,
      curr: data.mttyCurrPK.tcCurr,
      seqNo: data.mttyCurrPK.tcSeqNo,
      type: data.mttyCurrPK.tcType
    }

    this.treatyService.retrieveCurrencyPremById(objPk).subscribe(resp => {
      // this.showForm=true;
      for (var i = 0; i < resp.length; i++) {
        this.Curr_List = resp[i];
      }
      // this.ttyCurrFrm.patchValue({
      //       tcCurr:this.Curr_List.mttyCurrPK.tcCurr,
      //       tcFixedRate:this.Curr_List.tcFixedRate
      //     })
    }, error => {
    })
  }
  // ngAfterViewInit() {

  //   $('.selectpicker').selectpicker();
  //   setTimeout(() => {
  //   $('.selectpicker').selectpicker('refresh');
  //   }, 500);
  //   }

  deleteCurr(currInfo: any) {
    let obj = {
      tcRefNo: this.tcRefNo,
      tcAmendNo: this.tcAmendNo,
      tcLayer: this.tcLayer,
      tcCurr: this.tcCurr,
      tcSeqNo: this.seqNo,
      tcType: 'PR'
    }
    // this.treatyService.deleteTrCurrById(obj).subscribe(resp => {
    //   this.loaderService.isBusy = true;
    //   let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
    //   element.click();
    //   this.toastService.success('Deleted Succcessfully');
    //   this.retrieveTreatyCurrList();
    //   this.loaderService.isBusy = false;
    // }, error => {
    //   this.loaderService.isBusy = false;
    // })

  }

  showDialogbox(currInfo: any) {
    this.tcRefNo = currInfo.mttyCurrPK.tcRefNo,
      this.tcAmendNo = currInfo.mttyCurrPK.tcAmendNo,
      this.tcLayer = currInfo.mttyCurrPK.tcLayer,
      this.tcCurr = currInfo.mttyCurrPK.tcCurr,
      this.Curr_type = currInfo.mttyCurrPK.tcType;
    this.open(this.confirmcontent, 'modal-sm');
  }
  open(content, val) {
<<<<<<< HEAD
    this.modalService.show(content, { class: val });
  }
  closeModal(){
=======
    this.modalService.show(content, { class: val }); 
   }
   closeModal(){
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.modalService.hide();
  }
}
