import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustmentPremiumComponent } from './adjustment-premium.component';

describe('AdjustmentPremiumComponent', () => {
  let component: AdjustmentPremiumComponent;
  let fixture: ComponentFixture<AdjustmentPremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdjustmentPremiumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdjustmentPremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
