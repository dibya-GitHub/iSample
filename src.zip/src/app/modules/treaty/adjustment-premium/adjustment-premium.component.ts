import { DatePipe } from '@angular/common';
import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
<<<<<<< HEAD
import { UntypedFormGroup } from '@angular/forms';
=======
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { AGNPIComponent } from '../agnpi/agnpi.component';
import { EditviewrenderComponent } from '../editviewrender/editviewrender.component';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
declare var $: any;

@Component({
  selector: 'app-adjustment-premium',
  templateUrl: './adjustment-premium.component.html',
  styleUrls: ['./adjustment-premium.component.css'],
  providers: [DatePipe]
})
export class AdjustmentPremiumComponent implements OnInit {
  userList: any;
  recGridApi: any;
  reinstGridApi: any;
  adjGridApi: any;
  contractGridApi: any;
  @ViewChild('content') content: any;
  @ViewChild('agNpComponent') agnpiModal: AGNPIComponent;
  gridtitle: string;
  adjustmentList: any[];
  themeColor: any;
  AdjustmentCoumn: any[];
  AdjustmentCoumnView: any[];
  processId: string;
  createddate: string;
  processby: string;
  seqNo: number;
  seqcount: any;
  seqList: any;
  disableform: any;
  type: string;
  filename = [];
  myFiles: string[] = [];
  upload: boolean = true;
  dashBoard: any;

  uploadedFiles: any[] = [];

  contractForm: UntypedFormGroup;
  recoveryColumn: any[];
  layerColumn: any[];
  reinsurerColumn: any[];
  contractColumn: any[];

  transId: string;
  amendNo: string = '0';
  currency: string;

  showContractDivs: boolean = false;
  ShowRecoveryDivs: boolean = false;
  showAdjustmentDiv: boolean = false;
  showDepPrint: boolean = false;
  showReinsPrint: boolean = false;
  details: any[];
  layerDetails: any[];
  reinsurerDetails: any[];
  recoveryDetails: any[];
  contractDetails: any = [];
  currencyList: any = [];
  treatyType: any = [];

  layerNo: string;
  totalRecoveredPaid: number = 0;
  totalReInstPaid: number = 0;

  totalAdjustRate: number = 0;
  totalPremium: number = 0;
  totalDepositPremium: number = 0;
  totalFinalPremium: number = 0;
  totalXLRecovered: number = 0;
  totalLayerReInstPaid: number = 0;
  totalActualInst: number = 0;
  totalPremBalance: number = 0;
  totalReinstBalance: number = 0;

  totalReinsurerShare: number = 0;
  totalreinsurerDeposit: number = 0;
  totalActualAdjust: number = 0;
  totalReinsurerPremBal: number = 0;
  totalReinsurerReinstPaid: number = 0;
  totalReinsurerActualReinstPaid: number = 0;
  totalReinsurerReinstBal: number = 0;

  totalLayerLimits: number = 0;
  totalLayerExcess: number = 0;

  totalReinsAdjustRate: number = 0;
  totalReinsTotalPrem: number = 0;

  action: string;
  display: string = 'block';
  disabled: boolean = false;
  showReinsurer: boolean = false;
  showViewBtn: boolean = false;
  showEditBtn: boolean = false;

  referenceNo: string;
  mode: string;
  gridApi: any;
  gridColumnApi: any;
  showEntriesOptionSelected = 5;

  private gridOptions;
  defaultColDef: any;
  getRowHeight;
  frameworkComponents;
  context;
  txaTransId: any;
  AddFlag: boolean = true;
  @Output() toggleModal = new EventEmitter<any>();
  rowGroupPanelShow: string;
  paginationPageSize: number;
  rowSelection: any;
  initSearchValue: string = '';
  contractSearchValue: string = '';
  adjustSearchValue: string = '';
  reinsurerSearchValue: string = '';
  summarySearchValue: string = '';
  showSummaryEntriesOptionSelected = 5;
  showContractEntriesOptionSelected = 5;
  showAdjEntriesOptionSelected = 5;
  showReinstEntriesOptionSelected = 5;
  showRecEntriesOptionSelected = 5;
  showEntriesOptions = [5, 10, 20, 50, 100];
  gridApiReinsurer: any;
  gridApiAdjust: any;
  gridApiContract: any;
  gridApiRecovery: any;
  recoverySearchValue: any;
  documentTypes: any[];
  reInsSummaryColumn: any[];
  reinsSummaryDetails: any;
  documentRefId: string;
  pinnedBottomReinsurerData: any[];
  pinnedBottomSummaryData: any[];
  pinnedBottomLayerData: any[];
  refNo;
  docType;
  title;
  documents: any[];
  isDocumentNeedsToBeUpdated: boolean;
  canEdit = false;
  contractDesc: any = '';
  getRowStyle: (params: any) => { 'font-weight': string; };
<<<<<<< HEAD

  constructor(
    private treatyService: TreatyService,
=======
  public components;
  constructor(private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private route: Router,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private datePipe: DatePipe,
<<<<<<< HEAD
    private modalService: BsModalService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    // private agnpicomponent :AGNPIComponent
=======
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false,      
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
    this.activatedRoute.queryParams.subscribe(params => {
<<<<<<< HEAD
      this.transId = params['transId'];
=======
      this.transId = params['refNo'];
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.seqNo = params['seqNo'];
      this.docType = params['docType'];
      this.amendNo = params['amendNo']
      this.title = params['title']
      if (this.title === 'viewAccounting') {
        this.action = 'view';
        this.showAdjustmentDiv = false;
        this.type = 'DEP_PREM'
        this.documentRefId = 'A-' + this.transId + '-' + this.type;
        this.addAdjustmentPremium('view');
      }
      if (this.title === 'viewAccountingReins') {
        this.action = 'view';
        this.showAdjustmentDiv = false;
        this.type = 'REINST_PREM'
        this.documentRefId = 'A-' + this.transId + '-' + this.type;
        this.addAdjustmentPremium('view');
      }
    });
<<<<<<< HEAD
    /* this.activatedRoute.queryParams.subscribe(params => {
      this.referenceNo = params['refNo']; 
      this.seqNo = params['seqNo'];
      this.type = params['docType']
      this.loadAdjustmentPremium();
      this.loadseqencenumber()
      this.agGridOptions();     
    }); */
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  ngOnInit() {
    this.rowSelection = 'single'
    if (this.session.get("themeColor")) {
      this.themeColor = this.session.get("themeColor").split('-');
      this.themeColor = this.themeColor[0];
    }
    if (this.title !== 'viewAccounting' && this.title !== 'viewAccountingReins') {
      this.type = this.treatyService.getParamValue('type');
    }
<<<<<<< HEAD


=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    if (this.type == 'DEP_PREM') {
      this.gridtitle = 'Adjustment - Deposit Premium'
    } else if (this.type == 'NCB') {
      this.gridtitle = 'No Claim Bonus';
    } else {
      this.gridtitle = 'Adjustment - Reinstatement Premium'
    }
    this.referenceNo = this.treatyService.getParamValue('refNo');
    this.contractDesc = this.treatyService.getParamValue('contDesc');
    this.seqNo = this.treatyService.getParamValue('seqNo');
    this.mode = this.treatyService.getParamValue('mode');
    this.action = this.treatyService.getParamValue('action')
    this.dashBoard = this.session.get("userDashboard")
    this.action = this.treatyService.getParamValue('type');
    this.amendNo = this.treatyService.getParamValue('amendNo');
    this.documentRefId = 'A-' + this.transId + '-' + this.type;
    this.getDocumentTypes();
    this.recoveryColumn = [
      {
        field: 'tacTtyRefNo',
        headerName: 'Recovery Ref',
        sortable: true,
        tooltipField: 'tacTtyRefNo',
      },
      {
        field: 'tacRecApprDt',
        headerName: 'Date',
        sortable: true,
        tooltipField: 'tacRecApprDt',
        valueFormatter: this.dateFormatter
      },
      {
        field: 'tacXlType',
        headerName: 'Risk/CAT',
        sortable: true,
        tooltipField: 'tacXlType',
        valueGetter: function (params) {
          if (params.data.tacXlType != null && params.data.riskDesc != null) {
            return params.data.tacXlType + '-' + params.data.riskDesc
          } else {
            return params.data.tacXlType;
          }
        }
      },
      {
        field: 'tacClmNo',
        headerName: 'Claim No/Event',
        sortable: true,
        tooltipField: 'tacClmNo',
      },
      {
        field: 'tacPremCurr',
        headerName: 'Currency',
        headerClass: 'right-align-class',
        sortable: true,
        tooltipField: 'tacPremCurr',
      },
      {
        field: 'tacRecovered',
        headerName: 'Recovered',
        headerClass: 'right-align-class',
        cellStyle: { textAlign: 'right' },
        sortable: true,
        valueFormatter: numberFormatter,
        tooltipField: 'tacRecovered',
      },

    ];

    if (ApiUrls.ADJUST_TYPE_DEP == this.type || ApiUrls.ADJUST_TYPE_REINST == this.type) {
      this.AdjustmentCoumn = [
        {
          field: 'txaTransId',
          headerName: 'Process Id',
          sortable: true,
          tooltipField: 'txaTransId',
          enableRowGroup: false,
          filter:true
        },
        {
          field: 'txaTtyRefNo&txaTtySeqNo',
          headerName: 'Reference No',
          sortable: true,
          tooltipField: 'TxaTtySeqNo',
          enableRowGroup: false,
          filter:true,
          valueGetter: function (params) {
            if (params.data.txaTtySeqNo != null && params.data.txaTtySeqNo != 'null') {
              var reference = params.data.txaTtyRefNo + ' - ' + params.data.txaTtySeqNo;
              return reference;
            } else {
              return params.data.txaTtyRefNo
            }

          }
        },
        {
          field: 'txaCrDt',
          headerName: 'Processed Date',
          cellRenderer: prDateCellRenderer,
          valueGetter: function (params) {
            if (params && params.data && params.data.txaCrDt) {
              return moment(params.data.txaCrDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          sortable: true,          
          enableRowGroup: false,
          filter:true,
          filterParams: filterParamsPrDt,
        },
        {
          field: 'txaCrUid',
          headerName: 'Processed By',
          sortable: true,
          tooltipField: 'txaCrUid',
          enableRowGroup: false,
          filter:true,
        },
        {
          field: 'txaApprDt',
          headerName: 'Approved Date',
          valueGetter: function (params) {
            if (params && params.data && params.data.txaApprDt) {
              return moment(params.data.txaApprDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          sortable: true,          
          enableRowGroup: false,
          filter:true,
        },
        {
          field: 'ApprovedBy',
          headerName: 'Approved By',
          sortable: true,
          tooltipField: 'ApprovedBy',
          enableRowGroup: false,
          filter:true,
        },
        {
          field: 'txaApprSts',
          headerName: 'Status',
          sortable: true,
          filter:true,
        },
        {
          headerName: 'Action',
          cellRendererFramework: EditviewrenderComponent,
          cellStyle: { textAlign: 'center' },
          sortable: false,
          filter: false,
          enableRowGroup: false,
        }

      ]
      // this.components = {
      //   prDateCellRenderer: prDateCellRenderer,
        
      // };
      this.contractColumn = [
        {
          field: 'txlAdjTtyPK.tatTtyRefNo',
          headerName: 'Contract',
          sortable: true,
          tooltipField: 'txlAdjTtyPK.tatTtyRefNo',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'tatTtyDesc',
          headerName: 'Description',
          sortable: true,
          tooltipField: 'tatTtyDesc',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'tatProgCode',
          headerName: 'Program Code',
          sortable: true,
          tooltipField: 'tatProgCode',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'tatXlType',
          headerName: 'XL Type',
          color: '',
          sortable: true,
          tooltipField: 'tatXlType',
          enableRowGroup: true,
          filter:true,
        },
        { field: 'tatStartDt', 
          headerName: 'Start Date', 
          sortable: true, 
          cellRenderer: strtDateCellRenderer,
          enableRowGroup: true, 
          valueGetter: function (params) {
            if (params && params.data && params.data.tatStartDt) {
              return moment(params.data.tatStartDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          filter:true,
          filterParams: filterParams,
        },
        { field: 'tatEndDt', 
          headerName: 'End Date', 
          sortable: true, 
          enableRowGroup: true,
          cellRenderer: endDateCellRenderer,
          valueGetter: function (params) {
            if (params && params.data && params.data.tatEndDt) {
              return moment(params.data.tatEndDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          filter:true,
          filterParams: filterParams,
         },        
        {
          field: 'tatCurr',
          headerName: 'Currency',
          sortable: true,
          tooltipField: 'tatCurr',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'tatEpi',
          headerName: 'EGNPI',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tatEpi',
          filter:true,
          valueGetter: function (params) {
            var tatEpi = Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.data.tatEpi).toFixed(2));
            return tatEpi;
          }
        },
        {
          field: 'tatApi',
          headerName: 'AGNPI',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tatEpi',
          filter:true,
          valueGetter: function (params) {
            var tatApi = Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.data.tatApi).toFixed(2));
            return tatApi;
          }
        },
        {
          headerName: "Action",
          field: 'txlAdjTtyPK.tatTtyRefNo',
          cellStyle: { textAlign: 'center' },
          filter:false,
          cellRenderer: actionRender,   
        }
      ]

      this.AdjustmentCoumnView = [
        {
          field: 'txaTransId',
          headerName: 'Process Id',
          sortable: true,
          tooltipField: 'txaTransId',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'TxaTtySeqNo',
          headerName: 'Reference No',
          sortable: true,
          tooltipField: 'TxaTtySeqNo',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'txaCrDt',
          headerName: 'Processed Date',
          cellRenderer: prDateCellRenderer,
          valueGetter: function (params) {
            if (params && params.data && params.data.txaCrDt) {
              return moment(params.data.txaCrDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          sortable: true,          
          enableRowGroup: true,
          filter:true,
          filterParams: filterParamsPrDt,
        },
        // {
        //   field: 'txaCrDt',
        //   headerName: 'Processed Date',
        //   cellRenderer : prDateCellRenderer,
        //   valueFormatter: this.dateFormatter,
        //   sortable: true,
        //   tooltipField: 'txaCrDt',
        //   enableRowGroup: true,
        //   filter:true,
        // },
        {
          field: 'txaCrUid',
          headerName: 'Processed By',
          sortable: true,
          tooltipField: 'txaCrUid',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'txaApprDt',
          headerName: 'Approved Date',
          valueFormatter: this.dateFormatter,
          sortable: true,
          tooltipField: 'txaApprDt',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'ApprovedBy',
          headerName: 'Approved By',
          sortable: true,
          tooltipField: 'ApprovedBy',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'txaApprSts',
          headerName: 'Status',
          sortable: true,
          filter:true,
        },
        {
          headerName: "Action",
          field: 'txaTransId',
          cellStyle: { textAlign: 'center' },
          filter:false,
          cellRenderer: actionRenderAdjPrem,                    
        }

      ];
      this.reInsSummaryColumn = [
        {
          field: 'tarBroker',
          headerName: 'Broker',
          tooltipField: 'tarBroker',
          filter:true,
        },
        {
          field: 'tarPremCurr',
          headerName: 'Prem CCY',
          tooltipField: 'tarPremCurr',
          filter:true,
        },
        {
          field: 'tarReinstActl',
          headerName: 'Accounting Premium',
          tooltipField: 'tarReinstActl',
          cellStyle: { textAlign: 'right' },
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarDepPaid',
          headerName: 'Deposit Premium',
          tooltipField: 'tarDepPaid',
          cellStyle: { textAlign: 'right' },
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarReinstBal',
          headerName: 'Balance Due',
          tooltipField: 'tarReinstBal',
          cellStyle: { textAlign: 'right' },
          valueFormatter: numberFormatter,
          filter:true,
        },
      ];
    }

    if (ApiUrls.ADJUST_TYPE_DEP == this.type) {
      this.layerColumn = [
        {
          field: 'talTtySeqNo',
          headerName: 'Sequence No',
          sortable: true,
          tooltipField: 'talTtySeqNo',
          filter:true,
        },
        {
          field: 'txlAdjLayerPK.talLayer',
          headerName: 'Layer',
          sortable: true,
          tooltipField: 'txlAdjLayerPK.talLayer',
          filter:true,
        },
        {
          field: 'talLimitCurr',
          headerName: 'Currency',
          sortable: true,
          tooltipField: 'talLimitCurr',
          filter:true,
        },
        {
          field: 'talLimit',
          headerName: 'Limit',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talLimit',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talDeductible',
          headerName: 'Excess',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talDeductible',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talRecoverd',
          headerName: 'XL Recovered',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talRecoverd',
          filter:true,
        },
        {
          field: 'talAdjRate',
          headerName: 'Adjust Rate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talAdjRate',
          filter:true,
        },
        {
          field: 'talPrem',
          headerName: '100% Prem',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talPrem',
          valueFormatter: numberFormatter,
          cellRenderer: 'agGroupCellRenderer',
          aggFunc: 'sum',
          cellRendererParams: {
            footerValueGetter: (params) => params.value

          },
          filter:true,
        },
        {
          field: 'talDepPaid',
          headerName: 'Deposit Paid',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talDepPaid',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talFinalPrem',
          headerName: 'Final Prem',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talFinalPrem',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talPremBal',
          headerName: 'Balance Prem',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talPremBal',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          headerName: "Action",
          field: 'txlAdjLayerPK.talLayer',
          cellStyle: { textAlign: 'center' },
          filter:false,
          cellRenderer: function (params) {
            if (params.value) {
              return ` <a>
              <i class="fa fa-eye fa-icon"  data-action-type="Recovery"  title="View" aria-hidden="true"></i>&nbsp;&nbsp;
              &nbsp;`
            } else {
              return ``;
            }

          }
        }
      ]
    } else if (ApiUrls.ADJUST_TYPE_REINST == this.type) {
      this.layerColumn = [
        {
          field: 'talTtySeqNo',
          headerName: 'Sequence No',
          sortable: true,
          tooltipField: 'talTtySeqNo',
          filter:true,
        },
        {
          field: 'txlAdjLayerPK.talLayer',
          headerName: 'Layer',
          sortable: true,
          tooltipField: 'txlAdjLayerPK.talLayer',
          filter:true,
        },
        {
          field: 'talLimitCurr',
          headerName: 'Currency',
          sortable: true,
          tooltipField: 'talLimitCurr',
          filter:true,
        },
        {
          field: 'talLimit',
          headerName: 'Limit',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talLimit',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talDeductible',
          headerName: 'Excess',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talDeductible',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talAdjRate',
          headerName: 'Adjust Rate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talAdjRate',
          filter:true,
        },
        {
          field: 'talDepPaid',
          headerName: 'Deposit Paid',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talDepPaid',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talFinalPrem',
          headerName: 'Final Prem',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talFinalPrem',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talRecoverd',
          headerName: 'XL Recovered',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talRecoverd',
          filter:true,
        },
        {
          field: 'talReinstPaid',
          headerName: 'Reinst Paid',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talReinstPaid',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talReinstActl',
          headerName: 'Actual Reinstate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talReinstActl',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talReinstBal',
          headerName: 'Balance Reinstate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talReinstBal',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          headerName: "Action",
          field: 'txlAdjLayerPK.talLayer',
          cellStyle: { textAlign: 'center' },
          filter:false,
          cellRenderer: function (params) {
            if (params.value) {
              return ` <a>
              <i class="fa fa-eye fa-icon"  data-action-type="Recovery"  title="View" aria-hidden="true"></i>&nbsp;&nbsp;
              &nbsp;`
            } else {
              return ``;
            }
          }
        }
      ]
    }

    if (ApiUrls.ADJUST_TYPE_DEP == this.type) {
      this.reinsurerColumn = [
        {
          field: 'txlAdjReinsPK.tarReins',
          headerName: 'Reinsurer',
          sortable: true,
          tooltipField: 'txlAdjReinsPK.tarReins',
          filter:true,
        },
        {
          field: 'tarBroker',
          headerName: 'Broker',
          sortable: true,
          tooltipField: 'tarBroker',
          filter:true,
        },
        {
          field: 'tarAcntTo',
          headerName: 'Account To',
          sortable: true,
          tooltipField: 'tarAcntTo',
          filter:true,
        },
        {
          field: 'tarAdjRate',
          headerName: 'Adjust Rate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarAdjRate',
          filter:true,
        },
        {
          field: 'tarSharePerc',
          headerName: 'Share %',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarSharePerc',
          filter:true,
        },
        {
          field: 'tarDepPaid',
          headerName: 'Deposit Paid',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarDepPaid',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarFinalPrem',
          headerName: 'Actual Adjust',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarFinalPrem',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarPremBal',
          headerName: 'Balance Prem',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarPremBal',
          valueFormatter: numberFormatter,
          filter:true,
        },

      ]
    } else if (ApiUrls.ADJUST_TYPE_REINST == this.type) {
      this.reinsurerColumn = [
        {
          field: 'txlAdjReinsPK.tarReins',
          headerName: 'Reinsurer',
          sortable: true,
          tooltipField: 'txlAdjReinsPK.tarReins',
          filter:true,
        },
        {
          field: 'tarBroker',
          headerName: 'Broker',
          sortable: true,
          tooltipField: 'tarBroker',
          filter:true,
        },
        {
          field: 'tarAcntTo',
          headerName: 'Account To',
          sortable: true,
          tooltipField: 'tarAcntTo',
          filter:true,
        },
        {
          field: 'tarAdjRate',
          headerName: 'Adjust Rate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarAdjRate',
          filter:true,
        },
        {
          field: 'tarSharePerc',
          headerName: 'Share %',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarSharePerc',
          filter:true,
        },
        {
          field: 'tarFinalPrem',
          headerName: 'Final Premium',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarFinalPrem',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarReinstPaid',
          headerName: 'Reinstate Paid',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarReinstPaid',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarReinstActl',
          headerName: 'Actual Reinstate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarReinstActl',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarReinstBal',
          headerName: 'Balance Reinstate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarReinstBal',
          valueFormatter: numberFormatter,
          filter:true,
        },
      ]
    }

    if ('NCB' == this.type) {
      this.AdjustmentCoumn = [
        {
          field: 'txaTransId',
          headerName: 'Process Id',
          sortable: true,
          tooltipField: 'txaTransId',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'TxaTtySeqNo',
          headerName: 'Reference No',
          sortable: true,
          tooltipField: 'TxaTtySeqNo',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'txaCrDt',
          headerName: 'Processed Date',
          cellRenderer: prDateCellRenderer,
          valueGetter: function (params) {
            if (params && params.data && params.data.txaCrDt) {
              return moment(params.data.txaCrDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          sortable: true,          
          enableRowGroup: true,
          filter:true,
          filterParams: filterParamsPrDt,
        },
        // {
        //   field: 'txaCrDt',
        //   headerName: 'Processed Date',
        //   valueFormatter: this.dateFormatter,
        //   sortable: true,
        //   tooltipField: 'txaCrDt',
        //   enableRowGroup: true
        // },
        {
          field: 'txaCrUid',
          headerName: 'Processed By',
          sortable: true,
          tooltipField: 'txaCrUid',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'txaApprDt',
          headerName: 'Approved Date',
          valueFormatter: this.dateFormatter,
          sortable: true,
          tooltipField: 'txaApprDt',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'ApprovedBy',
          headerName: 'Approved By',
          sortable: true,
          tooltipField: 'ApprovedBy',
          enableRowGroup: true,
          filter:true,
        },
        {
          field: 'txaApprSts',
          headerName: 'Status',
          sortable: true,
          tooltipField: 'txaApprSts',
          filter:true,
        },
        {
          headerName: 'Action',
          cellRendererFramework: EditviewrenderComponent,
          cellStyle: { textAlign: 'center' },
          sortable: false,
          filter: false,
          enableRowGroup: false,
        }
      ];

      this.layerColumn = [
        {
          field: 'talTtySeqNo',
          headerName: 'Sequence No',
          sortable: true,
          tooltipField: 'talTtySeqNo',
          filter:true,
        },
        {
          field: 'txlAdjLayerPK.talLayer',
          headerName: 'Layer',
          sortable: true,
          tooltipField: 'txlAdjLayerPK.talLayer',
          filter:true,
        },
        {
          field: 'talLimitCurr',
          headerName: 'Currency',
          sortable: true,
          tooltipField: 'talLimitCurr',
          filter:true,
        },
        {
          field: 'talLimit',
          headerName: 'Limit',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talLimit',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talDeductible',
          headerName: 'Excess',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talDeductible',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talRecoverd',
          headerName: 'XL Recovered',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talRecoverd',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'talFinalPrem',
          headerName: 'Final Prem',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'talFinalPrem',
          valueFormatter: numberFormatter,
          filter:true,
        },

      ];
      this.reinsurerColumn = [
        {
          field: 'txlAdjReinsPK.tarReins',
          headerName: 'Reinsurer',
          sortable: true,
          tooltipField: 'txlAdjReinsPK.tarReins',
          filter:true,
        },
        {
          field: 'tarBroker',
          headerName: 'Broker',
          sortable: true,
          tooltipField: 'tarBroker',
          filter:true,
        },
        {
          field: 'tarAcntTo',
          headerName: 'Account To',
          sortable: true,
          tooltipField: 'tarAcntTo',
          filter:true,
        },
        {
          field: 'tarSharePerc',
          headerName: 'Share %',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarSharePerc',
          filter:true,
        },
        {
          field: 'tarAdjRate',
          headerName: 'Adjust Rate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarAdjRate',
          filter:true,          
        },
        {
          field: 'tarPrem',
          headerName: 'Final Premium',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarPrem',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarReinstPaid',
          headerName: 'Reinstate Paid',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarReinstPaid',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarReinstActl',
          headerName: 'Actual Reinstate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarReinstActl',
          valueFormatter: numberFormatter,
          filter:true,
        },
        {
          field: 'tarReinstBal',
          headerName: 'Balance Reinstate',
          headerClass: 'right-align-class',
          cellStyle: { textAlign: 'right' },
          sortable: true,
          tooltipField: 'tarReinstBal',
          valueFormatter: numberFormatter,
          filter:true,
        },
      ];
    }

    this.loadAdjustmentPremium();
    this.loadseqencenumber()
    this.agGridOptions();


    this.treatyService.appCodesList(ApiUrls.NON_PROPORTIONAL_TREATY_TYPE).subscribe(resp => {
      // this.ngAfterViewInit();
      this.treatyType = resp.appcodeList;
    })

    if ("back" == this.mode) {
      this.fetchContractDetails();
      // this.recalculate();
    } else if ("view" == this.action) {
      this.disabled = true;
      this.display = 'none';
    }

  }

  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }

  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res.appcodeList;
      }, err => {
      });
  }

  loadseqencenumber() {
    this.loaderService.isBusy = true;
    this.treatyService.loadingseqno(this.referenceNo).subscribe(data => {
      this.seqList = data.seqList
      let count = this.seqList.length
      this.seqcount = count;
      if (this.seqcount == 1) {
        this.seqNo = this.seqList[0]
      }
<<<<<<< HEAD
      // this.selectScript();
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.loadAdjustmentPremium()
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  loadAdjustmentPremium() {
    this.treatyService.loadAdjustPrem(this.referenceNo, this.type, this.seqNo).subscribe(data => {
      this.adjustmentList = data.adjList;
<<<<<<< HEAD

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  setseqno(SeqNoValue: any) {
    this.seqNo = SeqNoValue
  }
  addAdjustmentPremium(mode) {
    this.AddFlag = false;
    this.showAdjustmentDiv = false;
    if ((!this.seqNo || !this.transId) && 'add' != mode) {
      this.toastService.success('Select Process Id' + this.transId + '-' + this.seqNo);
      return false;
    }
    if ('view' == mode) {
      this.action = 'view';
      this.showAdjustmentDiv = false;
      this.fetchContractDetails();
    } else if ('add' == mode) {
      let obj = {
        mode: mode,
        refNo: this.referenceNo,
        seqNo: this.seqNo,
        type: this.type,
        transId: this.transId,
        amendNo: this.amendNo,
        title: mode

      }
      this.AddFlag = false
      this.showAdjustmentDiv = true
      this.router.navigate(['/treaty/edit-adjust-prem'], { queryParams: obj, skipLocationChange: false });
    }
    else {
      let obj = {
        mode: mode,
        refNo: this.referenceNo,
        seqNo: this.seqNo,
        type: this.type,
        transId: this.transId,
        amendNo: this.amendNo,
        title: mode

      }
      this.router.navigate(['/treaty/edit-adjust-prem'], { queryParams: obj, skipLocationChange: false });

    }
  }
  createForm(data) {
    var process = data.txaCrUid
    this.treatyService.reterieveUWriterList().subscribe(resp => {
      this.userList = resp.userList;
      if (this.userList) {
        const createdUser = this.userList.find(user => user.key === process);
        this.processby = createdUser.value;
      }
    }, error => { });
    this.createddate = this.datePipe.transform(data.txaCrDt, ApiUrls.DATE_FORMAT);
    this.processId = data.txaTransId;
  }

  fetch(refNo, seqNo) {
    this.seqNo = seqNo;
    this.disableform = "data";
    this.showAdjustmentDiv = false;
    this.loaderService.isBusy = true;
    this.treatyService.callAdjustmentProcedure(refNo, seqNo, this.type, this.session.get('userId')).subscribe(resp => {
      this.transId = resp.transId;
      this.ShowRecoveryDivs = false;
      this.action = 'add';
      this.fetchContractDetails();
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    });
  }

  selectedRow(data: any) {
    this.showViewBtn = true;
    this.transId = data.txaTransId;
    this.seqNo = data.txaTtySeqNo;
    if ("Pending" == data.txaApprSts) {
      this.showEditBtn = true;
    } else {
      this.showEditBtn = false;
    }

  }

  fetchContractDetails() {
    this.treatyService.fetchAdjustmentContractDetails(this.transId).subscribe(resp => {
      this.createForm(resp.contractDetails);
      this.showContractDivs = true;
      if (this.type == 'DEP_PREM') {
        this.showDepPrint = true
      } else if (this.type == 'NCB') {
      } else {
        this.showReinsPrint = true
      }
      this.loaderService.isBusy = false;
      this.retrieveXLContractDetails(resp.contractDetails);
    })
  }

  retrieveXLContractDetails(data) {

    this.treatyService.retrieveXLContractDetails(data.txaTransId, data.txaTtyRefNo, 0).subscribe(resp => {
      this.contractDetails = resp.contractList;
      //  this.scriptcall('contract-table');
      this.ShowRecoveryDivs = true;
      this.retrieveAdjRecoveryDetail();
      this.transId = data.txaTransId;
      this.retriveReinsSummary(this.transId,this.type);
    }, error => {

    })
  }

  approve() {
    this.loaderService.isBusy = true;
    let obj = {
      transId: this.transId,
      company: this.session.get("companyCode"),
      divn: this.session.get("userDivnCode"),
      dept: this.session.get("userDeptCode"),
      userId: this.session.get("userId")
    }

    this.treatyService.recalculateAdjustmentProcedure(obj).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.toastService.success('Approved Successfully');
      this.modalService.hide();
      this.disabled = true;
      this.display = 'none';
      this.action = 'view';
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
      this.disabled = false;
      this.display = 'block';
    })
  }
  retrieveAdjRecoveryDetail() {

    this.treatyService.retrieveAdjLayer(this.transId).subscribe(resp => {
      this.layerDetails = resp.layerList;
      if (this.layerDetails) {
        this.pinnedBottomLayerData = LayerData(1, this.layerDetails, "Bottom");
      }
<<<<<<< HEAD
      // for (var i = 0; i < this.layerDetails.length; i++) {
      //   this.totalLayerLimits = this.totalAdjustRate + this.layerDetails[i].talLimit;
      //   this.totalLayerExcess = this.totalAdjustRate + this.layerDetails[i].talDeductible;
      //   this.totalAdjustRate = this.totalAdjustRate + this.layerDetails[i].talAdjRate;
      //   this.totalPremium = this.totalPremium + this.layerDetails[i].talPrem;
      //   this.totalDepositPremium = this.totalDepositPremium + this.layerDetails[i].talDepPaid;
      //   this.totalFinalPremium = this.totalFinalPremium + this.layerDetails[i].talFinalPrem;
      //   this.totalXLRecovered = this.totalXLRecovered + this.layerDetails[i].talRecoverd;
      //   this.totalLayerReInstPaid = this.totalLayerReInstPaid + this.layerDetails[i].talReinstPaid;
      //   this.totalActualInst = this.totalActualInst + this.layerDetails[i].talReinstActl;
      //   this.totalPremBalance = this.totalPremBalance + this.layerDetails[i].talPremBal;
      //   this.totalReinstBalance = this.totalReinstBalance + this.layerDetails[i].talReinstBal;
      // }

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.retrieveReinsurerAdj(this.layerDetails[0]);
      this.loaderService.isBusy = false;
    })

  }

  retrieveReinsurerAdj(details) {
<<<<<<< HEAD
    this.transId = details.txlAdjLayerPK.talTransId
=======
    this.transId = details.txlAdjLayerPK.talTransId;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    if (details == null || details == '') { this.reinsurerDetails = []; } else {
      let obj = {
        transId: details.txlAdjLayerPK.talTransId,
        layer: details.txlAdjLayerPK.talLayer,
        tarRefNo: details.talTtyRefNo,
        tarSeqNo: details.talTtySeqNo,
        tarAmendNo: details.talTtyAmendNo,
        type: this.type
      }
      // this.layerNo = obj.layer;
      this.layerNo = details.talDesc != null ? details.txlAdjLayerPK.talLayer + '-' + details.talDesc : details.txlAdjLayerPK.talLayer;
      this.treatyService.retrieveReinsurerAdj(obj).subscribe(resp => {
        this.reinsurerDetails = resp;

        if (this.reinsurerDetails) {
          this.pinnedBottomReinsurerData = ReinsurerData(1, this.reinsurerDetails, "reinsurer");
        }
        this.retriveReinsSummary(details.txlAdjLayerPK.talTransId,this.type);
      }, error => {
        this.reinsurerDetails = [];
      })
    }
  }
<<<<<<< HEAD
  retriveReinsSummary(transId) {
    this.treatyService.retriveReinsSummaryDetails(transId).subscribe(resp => {
=======
  retriveReinsSummary(transId,type) {
    this.treatyService.retriveReinsSummaryDetails(transId,type).subscribe(resp => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.reinsSummaryDetails = resp;
      if (this.reinsSummaryDetails) {
        this.pinnedBottomSummaryData = ReinsurerData(1, this.reinsSummaryDetails, "summary");
      }
    }, error => {
      this.toastService.error(error.error.message);
      this.reinsSummaryDetails =[];
    });
  }

  changeCount(data) {
    if (data != "") {
      this.contractForm.get('txaApi').setValue(data);
    }
  }

  viewReinsurer(recTransId, recTranSrNo) {
    let obj = {
      transId: recTransId,
      tranSrNo: recTranSrNo,
      action: 'view',
      approveStatus: this.action,
      processId: this.transId,
      refNo: this.referenceNo
    }
    this.router.navigate(['/treaty/recovery'], { queryParams: obj, skipLocationChange: true });
  }

  printDocument(docType) {
    if (docType == 'DEP_PREM_ADJ') {
      var params = {
        refNo: this.transId,
        amendNo: "",
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_004',
        docType: docType,
        seqNo: "",
      }
    } else if (docType == 'REINST_ADJ') {
      var params = {
        refNo: this.transId,
        amendNo: "",
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_005',
        docType: docType,
        seqNo: "",
      }

    }
    this.treatyService.fetchReportUrl(params)
      .subscribe(result => {
        var url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
      width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(url, 'Reports', param);

      });
  }

  viewAccounting(docType) {
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'refNo': this.referenceNo, 'transId': this.transId, 'seqNo': this.seqNo, 'amendNo': this.amendNo, 'docType': docType } });
    //this.router.navigate(['/mga-view-accounting'], { queryParams: { batchId: '595', binder:  'DEP_PREM_ADJ',status:'A' } });
  }
  closeModal() {
    this.modalService.hide();
  }
  readUrl(e) {
    // alert();
    this.loaderService.isBusy = true;
    let file: File = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    let formData: FormData = new FormData();

    for (var i = 0; i < this.myFiles.length; i++) {
      formData.append("file", this.myFiles[i], this.filename[i].name);
    }

    // formData.append('file', file, file.name);
    formData.append('tdiRefNo', this.referenceNo);
    // formData.append('tdiAmendNo','0');
    formData.append('doctype', "XL-ADJ");
    formData.append('userId', this.session.get("userId"));
    var uploadDocumentReponse = this.treatyService.uploadDoc(formData);
    // this.upload = uploadDocumentReponse._isScalar;

    this.loaderService.isBusy = false;
  }

  retrieveRecoveryAdj(details) {
    this.transId = details.txlAdjLayerPK.talTransId;
    this.modalService.show(this.content, { class: 'modal-lg' });
<<<<<<< HEAD

    this.treatyService.retrieveAdjRecoveryDetails(details.txlAdjLayerPK.talTransId, details.talTtySeqNo, details.talTtyRefNo, details.talTtyAmendNo).subscribe(resp => {
=======
    this.treatyService.retrieveAdjRecoveryDetails(details.txlAdjLayerPK.talTransId, details.talTtySeqNo, this.referenceNo, details.talTtyAmendNo).subscribe(resp => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.recoveryDetails = resp.recoveryList;
    });
  }
  onGridSizeChanged(params) {
    console.log(params)
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  onGridInitReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onGridContractReady(params) {
    this.gridApiContract = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiContract.sizeColumnsToFit();
  }
  displayedContractRowCount() {
    if (this.gridApiContract) {
      return this.gridApiContract.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridAdjustmentReady(params) {
    this.gridApiAdjust = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiAdjust.sizeColumnsToFit();
  }
  displayedAdjustRowCount() {
    if (this.gridApiAdjust) {
      return this.gridApiAdjust.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridReinsurerReady(params) {
    this.gridApiReinsurer = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiReinsurer.sizeColumnsToFit();
  }
  displayedReinsurerRowCount() {
    if (this.gridApiReinsurer) {
      return this.gridApiReinsurer.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridRecoveryReady(params) {
    this.gridApiRecovery = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiRecovery.sizeColumnsToFit();
  }
  displayedRecoveryRowCount() {
    if (this.gridApiRecovery) {
      return this.gridApiRecovery.getDisplayedRowCount();
    } else {
      return;
    }
  }


  onRowClicked(e, title) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.transId = data.txaTransId;
      switch (actionType) {
        case "Edit":
          return this.addAdjustmentPremium('edit');
        case "View":
          this.documentRefId = 'A-' + this.transId + '-' + this.type;
          return this.addAdjustmentPremium('view');
        case "Recovery":
          return this.retrieveRecoveryAdj(data);
        case "AGNPI":
          let agnpi = {
            transId: data.txlAdjTtyPK.tatTransId,
            amendNo: data.txlAdjTtyPK.tatTtyAmendNo,
            currency: data.tatCurr,
            epi: data.tatEpi,
            seqNo: data.txlAdjTtyPK.tatTtySeqNo,
            refNo: data.txlAdjTtyPK.tatTtyRefNo,
            action: 'View'
          }
          return this.agnpiModal.toggleModal(agnpi)
      }
      switch (title) {
        case 'layer':
          return this.retrieveReinsurerAdj(data);
        case 'AGNPI':
          break
      }
    }
  }

  rowHeight() {
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
  }

  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.AdjustmentCoumn,
      rowData: null,
      filter: true
    };

    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
    this.frameworkComponents = {

      radioButtonRenderer: RadiorenderComponent
    };
  }

  dateFormatter(params) {
    if (params.value) {
      return moment(params.value).format('DD/MM/YYYY');
    }
  }
  close() {
    this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
  }


  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    //alert(gridApi+"--"+qickSearch);
    gridApi.setQuickFilter(qickSearch);
  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
  }

  onGridReady(params, gridName: any) {
    if (gridName === 'contract') {
      this.contractGridApi = params.api;
    } else if (gridName === 'adjustment') {
      this.adjGridApi = params.api;
    } else if (gridName === 'reinsurer') {
      this.reinstGridApi = params.api;
    } else if (gridName === 'recovery') {
      this.recGridApi = params.api;
    }
    params.api.sizeColumnsToFit();
  }
  displayRowCount(gridApi: any) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
}
function numberFormatter(params) {
  if (params != null) {
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else { return; }
}
function ReinsurerData(count, data, prefix) {
  var result = [];
  var tarReinstPaid = 0;
  var sumtarFinalPrem = 0;
  var sumtarSharePerc = 0;
  var tarReinstActl = 0;
  var tarReinstBal = 0;
  var tarDepPaid = 0;
  var tarPremBal = 0;
  var tarNcbPerc = 0;
  var tarNcbAmt = 0;
  for (var i = 0; i < data.length; i++) {
    tarReinstActl = tarReinstActl + data[i].tarReinstActl;
    tarReinstPaid = tarReinstPaid + data[i].tarReinstPaid;
    sumtarFinalPrem = sumtarFinalPrem + data[i].tarFinalPrem;
    sumtarSharePerc = sumtarSharePerc + data[i].tarSharePerc;
    tarReinstBal = tarReinstBal + data[i].tarReinstBal;
    tarDepPaid = tarDepPaid + data[i].tarDepPaid;
    tarPremBal = tarPremBal + data[i].tarPremBal;
    tarNcbPerc = tarNcbPerc + data[i].tarNcbPerc;
    tarNcbAmt = tarNcbAmt + data[i].tarNcbAmt;
  }
  for (var i = 0; i < count; i++) {
    if (prefix == 'reinsurer') {
      result.push({
        txlAdjReinsPK: {
          tarReins: 'Total'
        },
        tarReinstPaid: tarReinstPaid,
        tarFinalPrem: sumtarFinalPrem,
        tarSharePerc: sumtarSharePerc,
        tarReinstActl: tarReinstActl,
        tarReinstBal: tarReinstBal,
        tarDepPaid: tarDepPaid,
        tarPremBal: tarPremBal
      });
    } else {
      result.push({
        tarBroker: 'Total',
        tarReinstPaid: tarReinstPaid,
        tarFinalPrem: sumtarFinalPrem,
        tarSharePerc: sumtarSharePerc,
        tarReinstActl: tarReinstActl,
        tarReinstBal: tarReinstBal,
        tarDepPaid: tarDepPaid,
        tarPremBal: tarPremBal
      });
    }
  }
  return result;
}

function LayerData(count, data, prefix) {
  var result = [];
  var excessMin = [];
  var talLimit = 0;
  var talDeductible = 0;
  var talRecoverd = 0;
  var talAdjRate = 0;
  var talPrem = 0;
  var talDepPaid = 0;
  var talFinalPrem = 0;
  var talPremBal = 0;
  var talReinstPaid = 0;
  var talReinstActl = 0;
  var talReinstBal = 0;
  for (var i = 0; i < data.length; i++) {
    talLimit = talLimit + data[i].talLimit;
    talRecoverd = talRecoverd + data[i].talRecoverd;
    talAdjRate = talAdjRate + data[i].talAdjRate;
    talPrem = talPrem + data[i].talPrem;
    talDepPaid = talDepPaid + data[i].talDepPaid;
    talFinalPrem = talFinalPrem + data[i].talFinalPrem;
    talPremBal = talPremBal + data[i].talPremBal;
    talReinstPaid = talReinstPaid + data[i].talReinstPaid
    talReinstActl = talReinstActl + data[i].talReinstActl
    talReinstBal = talReinstBal + data[i].talReinstBal
    excessMin.push(data[i].talDeductible);
    talDeductible = Math.min(...excessMin);
  }
  for (var i = 0; i < count; i++) {
    result.push({
      talTtySeqNo: 'Total',
      talLimit: talLimit,
      talDeductible: talDeductible,
      talRecoverd: talRecoverd,
      talAdjRate: talAdjRate,
      talPrem: talPrem,
      talDepPaid: talDepPaid,
      talFinalPrem: talFinalPrem,
      talPremBal: talPremBal,
      talReinstPaid: talReinstPaid,
      talReinstActl: talReinstActl,
      talReinstBal: talReinstBal
    });
  }
  return result;
}
function prDateCellRenderer(params) {
  if (params.data && params.data.txaCrDt) {
    return moment(params.data.txaCrDt).format('DD/MM/YYYY');
  } else {
    return '';
  }
}
var filterParamsPrDt = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-eye fa-icon" style="color:#009ca6;" data-action-type="AGNPI"  title="View" aria-hidden="true"></i>&nbsp;&nbsp;
    </a>`;
  }
}

function actionRenderAdjPrem(params){
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-eye fa-icon" style="color:#009ca6" data-action-type="View"  title="View" aria-hidden="true"></i>
</a>`;
  }
}
function strtDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.tatStartDt).format('DD/MM/YYYY');
  }
}

function endDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.tatEndDt).format('DD/MM/YYYY')
  }
}
var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};