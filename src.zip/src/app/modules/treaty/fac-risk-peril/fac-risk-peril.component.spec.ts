import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacRiskPerilComponent } from './fac-risk-peril.component';

describe('FacRiskPerilComponent', () => {
  let component: FacRiskPerilComponent;
  let fixture: ComponentFixture<FacRiskPerilComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacRiskPerilComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacRiskPerilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
