<<<<<<< HEAD
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
=======
import { Component, OnInit, Inject, Input, Output, EventEmitter } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Router } from '@angular/router';
//import { ConfirmationService } from 'primeng/components/common/api';
import { SessionStorageService } from 'angular-web-storage';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
declare var $: any;

@Component({
  selector: 'app-fac-risk-peril',
  templateUrl: './fac-risk-peril.component.html',
  styleUrls: ['./fac-risk-peril.component.css']
})
export class FacRiskPerilComponent implements OnInit {
  gridColumnApi: any;
  gridApi: any;
  risk_peril: any[];
  showRiskFlag: boolean = false;
  riskForm: any;
  updateAction: boolean;
  riskDetails: any;
  tkSiCurr: any;
  PerilDropdownList: any;
  @Input() refNo: any;
  @Input() amendNo: any;
  @Input() seqNo: any;
  @Input() basecurr: string;
  @Input() contractType: string;
  @Input() egnpiLabel: string;
  @Input() egnpiAmt: string;
  @Input() ApplPolicyData: any;
  @Input() contractData: any;
  @Output() getEgnpiAmt = new EventEmitter();
  @Output() getGnpiData = new EventEmitter();

  riskList: any;
  editRespList: any;
  SIcurr: any;
  tkPremCurr: any;
  PremCurr: any;
  tkRiskSrNo: any;
  tkPeril: any;
  RiskObj: any
  totFacPremFc: number;
  totalFacFlag: boolean;
  totFacSiFc: number;
  totRiskPremFc: number;
  totRiskSiFc: number;
  perilDesc: any;
  RiskNo: any;
  tkPerilKey: any;
  AddFlag: boolean = true;
  quickSearchValue: string = '';
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  defaultColDef:any;
  private getRowHeight;
  private gridOptions;
  private frameworkComponents;
  selectedPeril: string[];
  pinnedBottomRowData: any
  context: any = this;
  facGnpiData: { facList: any; total: any; };
<<<<<<< HEAD
  constructor(
    private fb: UntypedFormBuilder,
=======
  edit:boolean=false;
  constructor(private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private treatyService: TreatyService,
    private cpipe: MycurrencyPipe,
<<<<<<< HEAD
    private session: SessionStorageService,
    private wizardHelper: TreatyWizardHelperService
  ) { }
=======
    private session: SessionStorageService,   
    private wizardHelper: TreatyWizardHelperService) { 
      this.defaultColDef = {
        resizable: true,
        sortable: true,
        filter: false,
        enableRowGroup: false,
     };
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032


  ngOnInit() {
    this.risk_peril = [
      { field: 'tkRiskDesc', headerName: 'Risk', sortable: true, },
      { field: 'ttyRiskPk.tkPeril', headerName: 'Peril', sortable: true },
      { field: 'tkTxnRiskSiFc', headerName: '100 % Sum Insured', type: 'number', headerClass: 'right-align-class', sortable: true, cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter },
      { field: 'tkTxnRiskPremFc', headerName: '100 % Premium', type: 'number', headerClass: 'right-align-class', sortable: true, cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter },
      { field: 'tkTxnXsSiFc', headerName: 'Total Excess SI', type: 'number', headerClass: 'right-align-class', sortable: true, cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter },
      { field: 'tkTxnXsPremFc', headerName: 'Total Excess Prem', type: 'number', headerClass: 'right-align-class', sortable: true, cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter },
      { field: 'tkFacPerc', headerName: 'FAC XL Share %', type: 'number', sortable: true,cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter },
      { field: 'tkTxnFacSiFc', headerName: 'FAC XL Limit', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter },
      { field: 'tkTxnFacPremFc', headerName: 'FAC XL Premium', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter },
      {
        headerName: 'Action',
        field: 'ttyRiskPk.tkPeril',
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
        cellRenderer: function (params) {
          if (params.value) {
            return ` <a>
            <i class="fa fa-file-pen fa-icon"  data-action-type="Edit"  title="Edit" aria-hidden="true"></i>
            &nbsp;
            <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete"  title="Delete" aria-hidden="true"></i>
            </a>`
          } else {
            return ``;
          }
        }
      },

    ];
    this.PerilDropdown();
    this.riskPerilForm();
    this.retriveRiskData();
    //console.log("Pol Data: "+this.ApplPolicyData)
    //console.log("Pol Data: "+this.contractData)

  }

  PerilDropdown() {
    this.treatyService.appCodesList(ApiUrls.APP_PERIL_TYPE).subscribe(resp => {
      this.PerilDropdownList = resp.appcodeList;
<<<<<<< HEAD
=======
      //console.log("peril dropdown", this.PerilDropdownList);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    });
  }

  riskPerilForm() {
    this.riskForm = this.fb.group({
      tkRefNo: '',
      tkSeqNo: '',
      tkAmendNo: '',
      tkRiskSrNo: '',
      tkPeril: ['', Validators.required],
      tkRiskDesc: ['', Validators.required],
      tkSiCurr: '',
      tkRiskSiFc: ['', Validators.required],
      tkTxnFacSiLc1: '',
      tkTxnFacSiLc2: '',
      tkTxnFacSiLc3: '',
      tkPremCurr: '',
      tkRiskPremFc: ['', Validators.required],
      tkTxnFacPremLc1: '',
      tkTxnFacPremLc2: '',
      tkTxnFacPremLc3: '',
      tkFacPerc: ['', Validators.required],
      tkTxnFacSiFc: ['', Validators.required],
      tkFacSiLc1: '',
      tkFacSiLc2: '',
      tkFacSiLc3: '',
      tkTxnFacPremFc: ['', Validators.required],
      tkFacPremLc1: '',
      tkFacPremLc2: '',
      tkFacPremLc3: '',
      tkStatus: 'P',
      tkCrUid: this.session.get('userId'),
      tkCrDt: new Date(),
      tkUpdUid: '',
      tkUpdDt: '',
      ttyRiskPk: '',
      tkTxnRiskSiFc:'',
      tkTxnRiskPremFc:['', Validators.required],
      tkTxnXsSiFc:'',
      tkTxnXsPremFc:'',
      tkCompCode:'',
      tkDivnCode:'',
      policyType:'',
      policySource:'',
      companyName:'',
      tkPolNo:'',
      tkPolType:'',
      tkPolAssured:''
    })

  }

  goNext() {
    this.wizardHelper.goNext();
  }

  goPrevious() {
    this.wizardHelper.goPrevious();
  }
  gnpiList:any;
  policyType:any;
  policySource:any;
  retriveRiskData() {
<<<<<<< HEAD
    this.treatyService.retrieveRisk(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
=======
    //console.log("retrieve", this.refNo, this.amendNo, this.seqNo);
    this.treatyService.retrieveRisk(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      //console.log("Risk details", resp.riskList);
      // console.log("Risk details2",resp.riskList.ttyRiskPk.tkPeril);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.riskDetails = resp.riskList;
      this.gnpiList = resp.gnpiList;
      this.policyType = resp.policyType;
      this.policySource = resp.policySource;
      //this.companyName =  this.riskDetails.
      this.totFacPremFc = 0;
      this.totFacSiFc = 0;
      this.totRiskPremFc = 0;
      this.totRiskSiFc = 0;
      if (this.riskDetails) {
        this.pinnedBottomRowData = createData(1, this.riskDetails, "Bottom");
        this.facGnpiData = {
          facList: this.riskDetails,
          total: this.pinnedBottomRowData[0]
        };
        this.getGnpiData.emit(this.facGnpiData);
      }
      for (var i = 0; i < resp.riskList.length; i++) {
        // this.riskDetails = this.riskList[i];
<<<<<<< HEAD
        this.tkSiCurr = resp.riskList[i].tkSiCurr;
        this.tkPremCurr = resp.riskList[i].tkPremCurr
        this.totFacPremFc += this.riskDetails[i].tkFacPremFc;
        this.totFacSiFc += this.riskDetails[i].tkFacSiFc;
=======
        //console.log("Risk details2", resp.riskList[i].ttyRiskPk.tkPeril);
        this.tkSiCurr = resp.riskList[i].tkSiCurr;
        this.tkPremCurr = resp.riskList[i].tkPremCurr
        //console.log("Risk details 2 ", this.riskDetails, " -- ", this.tkSiCurr)
        this.totFacPremFc += this.riskDetails[i].tkTxnFacPremFc;
        this.totFacSiFc += this.riskDetails[i].tkTxnFacSiFc;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.totRiskPremFc += this.riskDetails[i].tkRiskPremFc;
        this.totRiskSiFc += this.riskDetails[i].tkRiskSiFc;
        var PerilKey = resp.riskList[i].ttyRiskPk.tkPeril;
        var tkRiskSrNo = resp.riskList[i].ttyRiskPk.tkRiskSrNo;
      }
      var riskSrNo = this.riskDetails.length;
      this.RiskNo = riskSrNo + 1;
      if (this.totFacPremFc != 0) { this.totalFacFlag = true }
      this.getEgnpiAmt.emit(this.totFacPremFc);
      this.getGnpiData.emit(this.facGnpiData);
    }, error => {

      this.totFacPremFc = 0;
      if (this.totFacPremFc != 0) { this.totalFacFlag = true }
    })
  }
  facXol:boolean = false;
  addrisk() {
    this.showRiskFlag = true;
    this.updateAction = false;
    this.AddFlag = false;
    this.edit = false;
    this.riskForm.reset();
    this.riskForm.get('tkRiskSrNo').enable();
    this.riskForm.get('tkPeril').enable();
<<<<<<< HEAD
    if (this.contractData) {
=======
    //console.log(" Add Risk Form", this.contractData)
    if (this.contractData.thContractType == 'FX') {      
      this.facXol = true;
      this.riskForm.get('tkRiskDesc').clearValidators();
      this.riskForm.get('tkRiskDesc').updateValueAndValidity();
      this.riskForm.get('tkPeril').clearValidators();
      this.riskForm.get('tkPeril').updateValueAndValidity();      
    } else {
      this.facXol = false;
      this.riskForm.get('tkRiskDesc').setValidators([Validators.required]);
      this.riskForm.get('tkRiskDesc').updateValueAndValidity();
      this.riskForm.get('tkPeril').setValidators([Validators.required]);
      this.riskForm.get('tkPeril').updateValueAndValidity();
    }
    if (this.contractData) {
      //console.log("Add Risk", this.contractData);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.riskForm.patchValue({
        tkRiskSiFc: this.contractData.thFlex06,
        tkRiskPremFc: this.contractData.thFlex07
      });
    }

  }
companyName:any;
  editRisk(detail) {
<<<<<<< HEAD
=======
    //console.log("risk edit", detail)
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.showRiskFlag = true
    this.AddFlag = false;
    this.updateAction = true;
    this.tkRiskSrNo = detail.ttyRiskPk.tkRiskSrNo;
    this.tkPeril = detail.ttyRiskPk.tkPeril;
    this.edit = true;
    if (this.contractData.thContractType == 'FX') {      
      this.facXol = true;
      this.riskForm.get('tkRiskDesc').clearValidators();
      this.riskForm.get('tkRiskDesc').updateValueAndValidity();
      this.riskForm.get('tkPeril').clearValidators();
      this.riskForm.get('tkPeril').updateValueAndValidity();      
    } else {
      this.facXol = false;
      this.riskForm.get('tkRiskDesc').setValidators([Validators.required]);
      this.riskForm.get('tkRiskDesc').updateValueAndValidity();
      this.riskForm.get('tkPeril').setValidators([Validators.required]);
      this.riskForm.get('tkPeril').updateValueAndValidity();
    }
    let data = {
      tkRefNo: detail.ttyRiskPk.tkRefNo,
      tkAmendNo: detail.ttyRiskPk.tkAmendNo,
      tkSeqNo: detail.ttyRiskPk.tkSeqNo,
      tkRiskSrNo: detail.ttyRiskPk.tkRiskSrNo,
      tkPeril: detail.ttyRiskPk.tkPeril,
    }

    this.treatyService.retrieveRiskById(data).subscribe(resp => {
      this.editRespList = resp.riskList;
      this.riskForm.get('tkRiskSrNo').disable();
      this.riskForm.get('tkPeril').disable();
      this.riskForm.patchValue({
        tkRefNo: this.editRespList.ttyRiskPk.tkRefNo,
        tkAmendNo: this.editRespList.ttyRiskPk.tkAmendNo,
        tkSeqNo: this.editRespList.ttyRiskPk.tkSeqNo,
        tkRiskSrNo: this.editRespList.ttyRiskPk.tkRiskSrNo,
        tkPeril: this.editRespList.ttyRiskPk.tkPeril,
        tkRiskSiFc: this.cpipe.transform(this.editRespList.tkRiskSiFc),
        tkRiskPremFc: this.cpipe.transform(this.editRespList.tkRiskPremFc),
        tkFacPerc: this.cpipe.transform(this.editRespList.tkFacPerc),
        tkTxnFacSiFc: this.cpipe.transform(this.editRespList.tkTxnFacSiFc),
        tkTxnFacPremFc: this.cpipe.transform(this.editRespList.tkTxnFacPremFc),
        tkTxnRiskSiFc:this.editRespList.tkTxnRiskSiFc,
        tkTxnRiskPremFc:this.editRespList.tkTxnRiskPremFc,
        tkCompCode:this.editRespList.tkCompCode,
        tkDivnCode:this.editRespList.tkDivnCode,
        tkRiskDesc:this.editRespList.tkRiskDesc,
        tkPolType:this.contractData.thPolType,
        policySource:this.policySource,
        tkPolNo:this.contractData.thPolNo,
        tkPolAssured:this.contractData.thPolAssured
      });
      this.SIcurr = this.editRespList.tkSiCurr;
      this.PremCurr = this.editRespList.tkPremCurr;
      //console.log("Patch form", this.riskForm.value)
    }, error => { });

  }

  saveRiskPeril() {
    if (this.riskForm.valid) {
      this.loaderService.isBusy = true;
      let data = {
        tkRefNo: this.refNo,
        tkAmendNo: this.amendNo,
        tkSeqNo: this.seqNo,
        tkRiskSrNo: this.RiskNo,//this.riskForm.get('tkRiskSrNo').value,
        tkPeril: this.riskForm.get('tkPeril').value,
      }
      var perilkey = this.riskForm.get('tkPeril').value;
      for (var i = 0; i < this.PerilDropdownList.length; i++) {
        var riskKey = this.PerilDropdownList[i].key;
        if (riskKey == perilkey) {
          var riskDesc = this.PerilDropdownList[i].item_text;
        }
      }
  
      this.riskForm.patchValue({
        ttyRiskPk: data,
        tkRiskDesc: riskDesc
      })
      const formValue = this.riskForm.value
      formValue.tkStatus = 'P';
      formValue.tkCrUid = this.session.get('userId');
      formValue.tkCrDt = new Date();
      formValue.tkRiskPremFc = formValue.tkRiskPremFc ? formValue.tkRiskPremFc.replace(/,/g, '') : '0';
      formValue.tkRiskSiFc = formValue.tkRiskSiFc ? formValue.tkRiskSiFc.replace(/,/g, '') : '0';
      formValue.tkTxnFacPremFc = formValue.tkTxnFacPremFc ? formValue.tkTxnFacPremFc.replace(/,/g, '') : '0';
      formValue.tkFacPerc = formValue.tkFacPerc ? formValue.tkFacPerc.replace(/,/g, '') : '0';
      formValue.tkTxnFacSiFc = formValue.tkTxnFacSiFc ? formValue.tkTxnFacSiFc.replace(/,/g, '') : '0';
  
      this.treatyService.insertRiskDetails(formValue).subscribe(resp => {
        //console.log("Risk details", resp);
        this.retriveRiskData();
        this.riskForm.reset();
        this.close();
        this.loaderService.isBusy = false;
      }, error => {
        //console.log("ERROR");
        this.loaderService.isBusy = false;
      })
    } else {
      this.validateAllFormFields(this.riskForm);
    }

<<<<<<< HEAD
    this.riskForm.patchValue({
      ttyRiskPK: data,
      tkRiskDesc: riskDesc
    })
    const formValue = this.riskForm.value
    formValue.tkStatus = 'P';
    formValue.tkCrUid = this.session.get('userId');
    formValue.tkCrDt = new Date();
    formValue.tkRiskPremFc = formValue.tkRiskPremFc ? formValue.tkRiskPremFc.replace(/,/g, '') : '0';
    formValue.tkRiskSiFc = formValue.tkRiskSiFc ? formValue.tkRiskSiFc.replace(/,/g, '') : '0';
    formValue.tkFacPremFc = formValue.tkFacPremFc ? formValue.tkFacPremFc.replace(/,/g, '') : '0';
    formValue.tkFacPerc = formValue.tkFacPerc ? formValue.tkFacPerc.replace(/,/g, '') : '0';
    formValue.tkFacSiFc = formValue.tkFacSiFc ? formValue.tkFacSiFc.replace(/,/g, '') : '0';

    this.treatyService.insertRiskDetails(formValue).subscribe(resp => {
      this.retriveRiskData();
      this.riskForm.reset();
      this.close();
    }, error => {

    })

  }
  updateRiskPeril() {
=======
  }
  updateRiskPeril() {
    if (this.riskForm.valid) {
      this.loaderService.isBusy = true;
    //console.log("risk update  form", this.riskForm.value)
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    let data = {
      tkRefNo: this.refNo,
      tkAmendNo: this.amendNo,
      tkSeqNo: this.seqNo,
      tkRiskSrNo: this.riskForm.get('tkRiskSrNo').value, //this.RiskNo
      tkPeril: this.riskForm.get('tkPeril').value,
    }

    this.riskForm.patchValue({
      ttyRiskPk: data
    })
    const formValue = this.riskForm.value
    formValue.tkStatus = 'P';
    formValue.tkCrUid = this.session.get('userId');
    formValue.tkCrDt = new Date();
    formValue.tkRiskPremFc = formValue.tkRiskPremFc ? formValue.tkRiskPremFc.replace(/,/g, '') : '0';
    formValue.tkRiskSiFc = formValue.tkRiskSiFc ? formValue.tkRiskSiFc.replace(/,/g, '') : '0';
    formValue.tkTxnFacPremFc = formValue.tkTxnFacPremFc ? formValue.tkTxnFacPremFc.replace(/,/g, '') : '0';
    formValue.tkFacPerc = formValue.tkFacPerc ? formValue.tkFacPerc.replace(/,/g, '') : '0';
    formValue.tkTxnFacSiFc = formValue.tkTxnFacSiFc ? formValue.tkTxnFacSiFc.replace(/,/g, '') : '0';    

    this.treatyService.updateRiskById(formValue).subscribe(resp => {
<<<<<<< HEAD
=======
      //console.log("risk update", resp);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.riskForm.reset();
      this.showRiskFlag = false;
      this.AddFlag = true;
      this.retriveRiskData();
      this.loaderService.isBusy = false;
    }, error => { 
      this.loaderService.isBusy = false;
    });
  } else {
    this.validateAllFormFields(this.riskForm);
    this.loaderService.isBusy = false;
  }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      //console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  deleteRisk(detail) {
    let data = {
      tkRefNo: detail.ttyRiskPk.tkRefNo,
      tkAmendNo: detail.ttyRiskPk.tkAmendNo,
      tkSeqNo: detail.ttyRiskPk.tkSeqNo,
      tkRiskSrNo: detail.ttyRiskPk.tkRiskSrNo,
      tkPeril: detail.ttyRiskPk.tkPeril,
    }
    this.treatyService.deleteRiskById(data).subscribe(resp => {
      this.retriveRiskData();
    }, error => { });

  }

  close() {
    this.riskForm.reset();
    this.showRiskFlag = false
    this.AddFlag = true;
  }

  calculateFacXL() {
<<<<<<< HEAD
=======
    //console.log("risk share", this.riskForm.get("tkFacPerc").value, " - ", this.riskForm.get("tkFacPerc").value);
    //console.log("risk SI", this.riskForm.get("tkRiskSiFc").value, " - ", this.riskForm.get("tkRiskSiFc").value);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    let FacXLshare = parseFloat(this.riskForm.get("tkFacPerc").value);
    var Pol_SI_FC = parseFloat(this.riskForm.get("tkTxnRiskSiFc").value);
    var Pol_prem_fc = parseFloat(this.riskForm.get('tkTxnRiskPremFc').value);
    let Fac_si_fc = (FacXLshare / 100) * Pol_SI_FC;
    let Fac_prem_fc = (FacXLshare / 100) * Pol_prem_fc;
<<<<<<< HEAD
    this.riskForm.get('tkFacSiFc').setValue(this.cpipe.transform(Fac_si_fc.toString()));
    this.riskForm.get('tkFacPremFc').setValue(this.cpipe.transform(Fac_prem_fc.toString()));
=======
    this.riskForm.get('tkTxnFacSiFc').setValue(this.cpipe.transform(Fac_si_fc.toString()));
    this.riskForm.get('tkTxnFacPremFc').setValue(this.cpipe.transform(Fac_prem_fc.toString()));
    //console.log("pol-si - ", Pol_SI_FC, " pol prem - ", Pol_prem_fc, " Fac-SI - ", Fac_si_fc, " Fac Prem ", Fac_prem_fc);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
<<<<<<< HEAD
=======
      //console.log('rowselectdata::', data);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      let actionType = e.event.target.getAttribute("data-action-type");

      switch (actionType) {
        case "Edit":
          return this.editRisk(data);
        case "Delete":
          return this.deleteRisk(data)
      }
    }

  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("MasterGrid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  rowGroupOpened(params) {
    params.api.sizeColumnsToFit();
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  calculateFacShare(){
    setTimeout(() => {
    var riskSumIns = parseFloat(this.riskForm.get('tkTxnRiskSiFc').value ? this.riskForm.get('tkTxnRiskSiFc').value.toString().replace(/,/g, '') : 0);
    var xlLimit = parseFloat(this.riskForm.get('tkTxnFacSiFc').value ? this.riskForm.get('tkTxnFacSiFc').value.toString().replace(/,/g, '') : 0);
    let facPer = ((xlLimit/riskSumIns)*100).toFixed(7);
    this.riskForm.patchValue({tkFacPerc:facPer});
    this.calculateFacXlPrim()
    //this.riskForm.get('tkFacPerc').setValue(facPer.toString());
  }, 300);
  }
  calculateFacXlPrim(){
    setTimeout(() => {
      var riskPrem =  parseFloat(this.riskForm.get('tkTxnRiskPremFc').value ? this.riskForm.get('tkTxnRiskPremFc').value.toString().replace(/,/g, '') : 0);
      var facPerc =  parseFloat(this.riskForm.get('tkFacPerc').value ? this.riskForm.get('tkFacPerc').value.toString().replace(/,/g, '') : 0);
      let facXlPrem = ((riskPrem*facPerc)/100).toFixed(7);
      //this.riskForm.get('tkTxnFacPremFc').setValue(facXlPrem.toString());
      this.riskForm.patchValue({tkTxnFacPremFc:facXlPrem});
    },300);
  }
}
function numberFormatter(params) {
  if(params.value) {
    return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.value));//Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else {
    return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));;
  }

}

function createData(count, data, prefix) {
  var result = [];
  var tkTxnRiskSiFc = 0;
  var tkTxnRiskPremFc = 0;
  var tkTxnXsSiFc = 0;
  var tkTxnXsPremFc = 0;
  var tkFacPerc = 0;
  var tkTxnFacSiFc = 0;
  var tkTxnFacPremFc = 0;
  for (var i = 0; i < data.length; i++) {
    tkTxnRiskSiFc = tkTxnRiskSiFc + data[i].tkTxnRiskSiFc;
    tkTxnRiskPremFc = tkTxnRiskPremFc + data[i].tkTxnRiskPremFc;
    tkTxnXsSiFc = tkTxnXsSiFc + data[i].tkTxnXsSiFc;
    tkTxnXsPremFc = tkTxnXsPremFc + data[i].tkTxnXsPremFc;
    tkFacPerc = tkFacPerc + data[i].tkFacPerc;
    tkTxnFacSiFc = tkTxnFacSiFc + data[i].tkTxnFacSiFc;
    tkTxnFacPremFc = tkTxnFacPremFc + data[i].tkTxnFacPremFc;
  }
  for (var i = 0; i < count; i++) {
    result.push({
      tkRiskDesc: 'Total',
      tkTxnRiskSiFc: tkTxnRiskSiFc,
      tkTxnRiskPremFc: tkTxnRiskPremFc,
      tkTxnXsSiFc: tkTxnXsSiFc,
      tkTxnXsPremFc: tkTxnXsPremFc,
      tkFacPerc: tkFacPerc,
      tkTxnFacSiFc: tkTxnFacSiFc,
      tkTxnFacPremFc: tkTxnFacPremFc
    });
  }

  return result;
}
