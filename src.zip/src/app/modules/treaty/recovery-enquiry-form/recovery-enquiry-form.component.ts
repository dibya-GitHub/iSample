import { DatePipe } from '@angular/common';
import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { DocumentService } from 'src/app/shared/components/document/document.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { AgGridCheckboxComponent } from '../ag-grid-checkbox/ag-grid-checkbox.component';
import { HiperLinkComponent } from './ag-hiperlink.component';
declare var $: any;

@Component({
  selector: 'app-recovery-enquiry-form',
  templateUrl: './recovery-enquiry-form.component.html',
  styleUrls: ['./recovery-enquiry-form.component.css'],
  providers: [DatePipe]
})

export class RecoveryEnquiryFormComponent {

  treatyCurr: any;
  osRetnTty = 0;
  paidRetnTty = 0;
  headeFlage: boolean = true;
  showEntriesOptions = [5, 10, 20, 50, 100];
  claimsShowEntriesOptionSelected = 5;
  contractShowEntriesOptionSelected = 5;
  layerShowEntriesOptionSelected = 5;
  reinstShowEntriesOptionSelected = 5;
  contractQuickSearchValue: string = '';
  claimsQuickSearchValue: string = '';
  layerQuickSearchValue: string = '';
  reinstQuickSearchValue: string = '';
  paginationPageSize: number;
  claimsGridApi: any;
  layerGridApi: any;
  reinstGridApi: any;
  defaultColDef;
  getRowHeight;
  context;
  frameworkComponents;
  layerColumn;
  rowSelection;
  reinsurerSummaryData : any =[];
  layerSummaryColumn;
  bottomData: any =[];
  seqcount: any;
  seqList: any;
  seqNo: any;
  upload: boolean = true;
  dashBoard: any;
  url: string;
  variable: any;
  showrecoveryform: any;

  @ViewChild('confirmcontent') confirmation: ElementRef;
  @ViewChild('content') content: ElementRef;
  @ViewChild('aadContentTemplate') aadContentTemplate: ElementRef;

  @Input() vamendNo: string;
  @Input() vtransId: string;
  @Input() vaction: string;
  contractDetailForm: UntypedFormGroup;
  details: any = [];
  layerDetails: any = [];
  reinsurerDetails: any = [];
  cols: any[];
  reinsurerColumn: any[];
  showContractDetails: boolean = false;
  showLayerDetails: boolean = false;
  transId: string;
  tranSrNo: string;
  amount: any;
  layer: string = '1';
  totalRecover: number = 0;
  totalRecoverable: number = 0;
  totalRolDeposit: number = 0;
  totalReInstPremium: number = 0;
  totalReinsurerShare: number = 0;
  totalRecovered: number = 0;
  totalReinsurerReinst: number = 0;
  disabled: boolean = false;
  action: string;
  showPrintBtn: boolean = false;
  //flag: boolean = true;
  display: string = 'block;'
  processId: string;
  documentTypes: any[];
  claim_contRef: any;
  claim_No: any;
  claim_SeqNo: any;
  claim_Event: any;
  showAadGrid: boolean;
  aadGridData: any[];
  aadObj: Object;
  documentRefId: string;
  gridOptionsDetail: any;
  event: any;
  documents: any[];
  isDocumentNeedsToBeUpdated: boolean;
  isNew = true;
  rowClassRules: any;
  rowGroupPanelShow: string;
  approveBtn: boolean;
  layerDesc: any = null;
  excessMin: number[];
  maxExcess: number;
  totalLimit: any = 0;
  totalMaxRec: any = 0;
  contractColumn: any;
  contractData: any = [];
  contractGridApi: any;

  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private modalService: BsModalService,
    private datePipe: DatePipe,
    private session: SessionStorageService,
    private docService: DocumentService,

  ) {
    const context = this;
    this.rowGroupPanelShow = "always";
    this.cols = [
      {
        field: 'txlClmPK.txcClmNo',
        headerName: 'Claim No',
        filter: true,
        sortable: true,
        tooltipField: 'txlClmPK.txcClmNo'
      },
      {
        field: 'txcLossDt',
        headerName: 'Loss Date',
        //valueFormatter: dateFormatter,
        cellRenderer: apprDateCellRenderer,
        valueGetter: function (params) {
          if (params && params.data && params.data.txcLossDt) {
            return moment(params.data.txcLossDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
        filter: true,
        sortable: true,
        // tooltipValueGetter: function (params) {
        //   return { value: moment(params.value).format('DD/MM/YYYY') };
        // }
      },
      {
        field: 'txcLossDesc',
        headerName: 'Loss Desc',
        sortable: true,
        filter: true,
        tooltipField: 'txcLossDesc'
      },
      {
        field: 'txcCustName',
        headerName: 'Insured',
        sortable: true,
        filter: true,
        tooltipField: 'txcCustName',
        ColId: "Insured",
        suppressAggFuncInHeader: function (data) {
          data
        }
      },
      {
        field: 'txcPaidDt',
        headerName: 'Payment Date',
        cellRenderer: apprDateCellRenderer,
        valueGetter: function (params) {
          if (params && params.data && params.data.txcPaidDt) {
            return moment(params.data.txcPaidDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
        //valueFormatter: dateFormatter,
        sortable: true,
        filter: true,
        // tooltipValueGetter: function (params) {
        //   return { value: moment(params.value).format('DD/MM/YYYY') };
        // }
      },
      {
        field: 'txcPolNo',
        headerName: 'Policy Ref',
        sortable: true,
        filter: true,
        tooltipField: 'txcPolNo'
      },
      {
        field: 'txcCurr',
        headerName: 'CCY',
        sortable: true,
        filter: true,
        tooltipField: 'txcCurr'
      },
      {
        field: 'txcIncurred',
        headerName: 'Incurred',
        sortable: true,
        filter: true,
        //tooltipField: 'txcIncurred',
        valueGetter: function (params) {
          if(params.data && params.data.txcIncurred) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txcIncurred));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txcOsPay',
        headerName: 'OS Payment',
        sortable: true,
        filter: true,
        //tooltipField: 'txcOsPay',
        valueGetter: function (params) {
          if(params.data && params.data.txcOsPay) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txcOsPay));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txcPaid',
        headerName: 'Paid',
        sortable: true,
        filter: true,
        //tooltipField: 'txcPaid',
        valueGetter: function (params) {
          if(params.data && params.data.txcPaid) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txcPaid));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txcPaidRetn',
        headerName: 'Paid Retention',
        filter: true,
        sortable: true,
        //tooltipField: 'txcPaidRetn',
        valueGetter: function (params) {
          if(params.data && params.data.txcPaidRetn) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txcPaidRetn));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txcOsRetn',
        headerName: 'OS Rentention',
        sortable: true,
        filter: true,
        //tooltipField: 'txcOsRetn',
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.txcOsRetn) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txcOsRetn));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: 'Process YN',
        editable: false,
        cellClass: 'no-border',
        cellRendererFramework: AgGridCheckboxComponent,
        field: 'txcProcYn',
        cellStyle: { textAlign: 'center' }
      }
      //  { isDisable : (this.action === 'view')}},
    ]

    this.layerColumn = [
      {
        field: 'txlTtySeqNo',
        headerName: "Sequence No",
        //subFields: 'concate',
        filter: true,
        sortable: true,
        tooltipField: 'txlTtySeqNo'
      },
      {
        field: 'txlLayerPK.txlLayer',
        headerName: 'Layer',
        sortable: true,
        filter: true,
        tooltipField: 'txlLayerPK.txlLayer',
        valueGetter: function (params) {
          if (params.data.txlLayerPK.txlLayer != null && params.data.txlLayerPK.txlLayer != "null") {
            if (params.data.layerDesc != null && params.data.layerDesc != 'null') {
              return params.data.txlLayerPK.txlLayer + '-' + params.data.layerDesc;
            } else {
              return params.data.txlLayerPK.txlLayer;
            }
          }
        }
      },
      {
        field: 'txlAttachBasis',
        headerName: 'XOL Type',
        sortable: true,
        filter: true,
        tooltipField: 'txlAttachBasis'
      },
      {
        field: 'txlPremCurr',
        headerName: 'CCY',
        sortable: true,
        filter: true,
      },
      {
        field: 'txlLimit',
        headerName: 'Limit',
        sortable: true,
        filter: true,
        //tooltipField: 'txlLimit',
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlLimit) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlLimit));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txlDeductible',
        headerName: 'Excess',
        sortable: true,
        filter: true,
        //tooltipField: 'txlDeductible',
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlDeductible) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlDeductible));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "AAD",
        field: 'tlAad',
        cellStyle: { color: 'blue', 'font-weight': 'bold' },
        valueFormatter: currencyFormatter,
        cellRendererFramework: HiperLinkComponent,
        valueGetter: function (params) {
          if (params.data.tlAad != "null") {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.tlAad));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellRendererParams: {
          event: (event, data) => {
            context.onRefClicked(data);
          }
        },
      },
      {
        field: 'txlMaxRec',
        headerName: 'Max Recoverable',
        sortable: true,
        filter: true,
        //tooltipField: 'txlMaxRec',
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlMaxRec) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlMaxRec));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txlRecoverd',
        headerName: 'Recovered',
        sortable: true,
        filter: true,
        //tooltipField: 'txlRecoverd',
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlRecoverd) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlRecoverd));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txlRecovery',
        headerName: 'Recoverable',
        sortable: true,
        filter: true,
        //tooltipField: 'txlRecovery',
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlRecovery) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlRecovery));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: {
          color: 'blue',
          textAlign: 'right'
        }
      },
      {
        field: 'txlDepPremRol',
        headerName: 'RoL Deposit',
        sortable: true,
        filter: true,
        valueGetter: function (params) {
          if(params.data && params.data.txlDepPremRol) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlDepPremRol));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txlReinstPerc',
        headerName: 'Reinst %',
        sortable: true,
        filter: true,
        valueGetter: function (params) {
          if(params.data && params.data.txlReinstPerc) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlReinstPerc));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txlReinstPrem',
        headerName: 'Reinst Prem',
        sortable: true,
        filter: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlReinstPrem) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlReinstPrem));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { color: 'blue', textAlign: 'right' }
      },
      {
        field: 'txlTtySeqNo',
        headerName: "Action",
        cellRenderer:actionRenderLayer,
        // template:
        //   `<a>
        //       <i class=" fa fa-eye fa-icon" data-action-type="View" title="View" aria-hidden="true" ></i>
        //   </a>`,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
    ]
    this.layerSummaryColumn = [
      {
        field: 'txlTtySeqNo',
        headerName: "Reference No",
        //subFields: 'concate',
        sortable: true,
      },
      {
        field: 'txlLayerPK.txlLayer',
        headerName: 'Layer',
        sortable: true,
      },
      {
        field: 'txlAttachBasis',
        headerName: 'XOL Type',
        sortable: true,
      },
      {
        field: 'txlPremCurr',
        headerName: 'CCY',
        sortable: true,
      },
      {
        field: 'txlLimit',
        headerName: 'Limit',
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlLimit) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlLimit));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
      },
      {
        field: 'txlDeductible',
        headerName: 'Excess',
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlDeductible) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlDeductible));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
      },
      {
        headerName: "AAD",
        field: 'tlAad',
        cellStyle: { color: 'blue', 'font-weight': 'bold' },
      },
      {
        field: 'txlMaxRec',
        headerName: 'Max Recoverable',
        sortable: true,
      },
      {
        field: 'txlRecoverd',
        headerName: 'Recovered',
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlRecoverd) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlRecoverd));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: {         
          textAlign: 'right'
        }
      },
      {
        field: 'txlRecovery',
        headerName: 'Recoverable',
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlRecovery) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlRecovery));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: {
          color: 'blue',
          textAlign: 'right'
        }
      },
      {
        field: 'txlDepPremRol',
        headerName: 'RoL Deposit',
        sortable: true,
        valueGetter: function (params) {
          if(params.data && params.data.txlDepPremRol) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlDepPremRol));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txlReinstPerc',
        headerName: 'Reinst %',
        sortable: true,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'txlReinstPrem',
        headerName: 'Reinst Prem',
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txlReinstPrem) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txlReinstPrem));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: {
          color: 'blue',
          textAlign: 'right'
        }
      },
      {
        field: '',
        headerName: 'Action',
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },
    ]
    this.reinsurerColumn = [
      {
        field: 'txlReinsPK.txiReins',
        headerName: 'Reinsurer',
        tooltipField: 'txlReinsPK.txiReins',
        //subFields: 'concate',
        sortable: true,
      },
      {
        field: 'txiBroker',
        headerName: 'Broker',
        tooltipField: 'txiBroker',
        //subFields: 'concate',
        sortable: true,
      },
      {
        field: 'txiAcntTo',
        headerName: 'Accounting To',
        tooltipField: 'txiAcntTo',
        //subFields: 'concate',
        sortable: true,
      },
      {
        field: 'txiSharePerc',
        headerName: 'Share %',
        cellStyle: { textAlign: 'right' },
        //subFields: 'concate',
        sortable: true,
      },
      {
        field: 'txiRecovery',
        headerName: 'Recoverable',
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txiRecovery) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txiRecovery));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: {
          color: 'blue',
          textAlign: 'right'
        },
        //subFields: 'concate',
        sortable: true,
      },
      {
        field: 'txiReinstPrem',
        headerName: 'Reinst Prem',
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.txiReinstPrem) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.txiReinstPrem));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: {
          color: 'blue',
          textAlign: 'right'
        },
        //subFields: 'concate', 
        sortable: true,
      }
    ];
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false
    };
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
    this.rowSelection = 'single';
    this.recoveryContractGrid();
  }

  recoveryContractGrid() {
    this.contractColumn = [
      {
        field: 'transId',
        headerName: 'Rec Ref',
        tooltipField: 'transId',
        //subFields: 'concate',
      },
      {
        field: 'transSrNo',
        headerName: 'Rec Sr No',
        tooltipField: 'transSrNo',
        //subFields: 'concate',
      },
      {
        field: 'contractReference',
        headerName: 'Cont Ref',
        tooltipField: 'contractReference',
        //subFields: 'concate',
        valueGetter: function (params) {
          if (params.data.contractReference != null && params.data.contractSequence != null) {
            return params.data.contractReference + '-' + params.data.contractSequence
          } else {
            return params.data.contractReference
          }
        }
      },
      {
        field: 'claimNo',
        headerName: 'Claim No',
        tooltipField: 'claimNo',
        //subFields: 'concate',
      },
      {
        field: 'event',
        headerName: 'Event',
        tooltipField: 'event',
        //subFields: 'concate',
        valueGetter: function (params) {
          if (params.data.event != null && params.data.event != null) {
            return params.data.event + '-' + params.data.eventDesc
          } else {
            return params.data.event
          }
        }
      },
      {
        field: 'approverDate',
        headerName: 'Approved Date',
        tooltipField: 'approverDate',
        //subFields: 'concate',
        cellRenderer: apprDateCellRenderer,
        //valueFormatter: dateFormatter,
        valueGetter: function (params) {
          if (params && params.data && params.data.approverDate) {
            return moment(params.data.approverDate).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
      },
      {
        field: 'approverName',
        headerName: 'Approved By',
        tooltipField: 'approverName',
        //subFields: 'concate',
      },
      {
        field: 'approveStatus',
        headerName: 'Status',
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.data.approveStatus == 'A') {
              return params.data.approveStatus == 'A';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.data.approveStatus == 'P') {
              return params.data.approveStatus == 'P';
            }
          },
        },
        cellRenderer: activityStatus,
        valueGetter: function (params) {
          if (params.data && params.data.approveStatus && params.data.approveStatus == 'A') {
            return 'Approved';
          } else if (params.data && params.data.approveStatus && params.data.approveStatus == 'P'){
            return 'Pending';
          } else {
            return '';
          }

        }
      },
      {
        headerName: "Action",
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
    ]
  }

  recoveryContract(transId) {
    this.treatyService.recoveryContractDetails(transId).subscribe(resp => {
      this.contractData = resp;
      if (this.action != 'add') {
        this.transId = this.contractData[0].transId;
        this.tranSrNo = this.contractData[0].transSrNo;
        // this.approveBtn = this.contractData[0].approveStatus == 'A' ? false : true;
        this.action = this.contractData[0].approveStatus == 'A' ? 'view' : 'edit';
        this.loadContractDetails();
        this.getDocumentTypes();
      }
    }, err => {
      // this.toastService.error('Error in Contract Data');
    });
  }

  ngOnInit() {
    const context = this;
    this.action = this.treatyService.getParamValue('action');
    this.transId = this.treatyService.getParamValue('transId');
    this.tranSrNo = this.treatyService.getParamValue('tranSrNo');
    this.processId = this.treatyService.getParamValue('processId');
    this.seqNo = this.treatyService.getParamValue('seqNo');
    this.dashBoard = this.session.get("userDashboard");
    this.claim_contRef = this.treatyService.getParamValue("claimRefNo");
    this.claim_SeqNo = this.treatyService.getParamValue('claimSeqNo');
    this.claim_No = this.treatyService.getParamValue('claimNo');
    this.claim_Event = this.treatyService.getParamValue('claimEvent');
    if (this.claim_No || this.claim_SeqNo || this.claim_contRef) {
      this.fetch(this.claim_contRef, this.claim_SeqNo, this.claim_No, this.claim_Event)
    }
    if (this.action != 'add') {
      this.recoveryContract(this.transId);
    }
    // this.ClaimRecovery();
    // this.getDocumentTypes();
    this.rowClassRules = {
      'lite-green-bg': function (params) {
        return (params.data.txcStatus === 'A');
      },
      'lite-orange-bg': 'data.txcStatus === \'P\''
    };

    this.contractDetailForm = this.fb.group({
      contractrefno: "",
      seqno: "",
      claimno: "",
      event: "",
      eventDesc: "",
      recrefno: "",

    })

    if ("view" == this.action) {
      this.display = 'none';
      this.disabled = true;
      // this.loadContractDetails();
      this.isNew = false;
      this.approveBtn = false;
    } else if ('edit' == this.action) {
      // this.loadContractDetails();
      this.isNew = false;
      // this.approveBtn = true;
    }
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: AgGridCheckboxComponent
    };
    this.paginationPageSize = 10;
  }

  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }

  getDocumentTypes() {
    this.documentRefId = 'R-' + this.transId + "-" + this.tranSrNo;
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_RECOVERY')
      .subscribe(res => {
        this.documentTypes = res.appcodeList;
      }, err => {
      });
  }

  fetch(refNo: string, SeqNoValue: any, claimNo: string, event: string) {
    this.seqNo = SeqNoValue
    // this.approveBtn = true;
    if (this.seqNo == "All") {
      this.seqNo = "";
      this.showrecoveryform = "data"
    } else {
      this.showrecoveryform = "alldata"
    }


    this.showContractDetails = false;
    this.showLayerDetails = false;
    if (refNo == null || refNo == "") {
      this.toastService.warning("Please Enter Reference No");
      return false;
    } else if (this.seqNo == undefined || this.seqNo == null) {
      this.toastService.warning("Please Select Sequence No");
      return false;
    } else if ((claimNo == null || claimNo == "") && (event == null || event == "")) {
      this.toastService.warning("Either Claim No Or Event is required");
      return false;
    } else {
      this.loaderService.isBusy = true;
      let obj = { txrTtyRefNo: refNo, txrClmNo: claimNo, txrSeqNo: this.seqNo, txrEvent: event, txrCrUid: this.session.get('userId') };
      this.treatyService.callRecoveryClaimProcedure(obj).subscribe(resp => {
        this.showContractDetails = true;
        this.headeFlage = false;
        var result = resp.details;
        this.recoveryContract(resp.transId);

        if (result != null) {
          this.transId = result.txlRecPK.txrTransId;
          this.tranSrNo = result.txlRecPK.txrTranSrNo;
          let date = this.datePipe.transform(result.txrStartDt, ApiUrls.DATE_FORMAT);
          let year = date.split('-')[2];
          this.contractDetailForm.patchValue({
            contractrefno: result.txrTtyRefNo,
            seqno: result.txrSeqNo,
            claimno: result.txrClmNo,
            event: result.txrEvent,
            eventDesc: result.eventDesc,
            recrefno: result.txlRecPK.txrTransId + "-" + result.txlRecPK.txrTranSrNo,
            userId: result.txrCrUid
          })
          this.loadseqencenumber();
          if ("view" == this.action) {
            this.display = 'none';
            this.disabled = true;
            this.loadContractDetails();
            this.isNew = false;
            this.approveBtn = false;
          } else if ('edit' == this.action) {
            this.loadContractDetails();
            this.isNew = false;
            // this.approveBtn = true;
          }
          this.contractDetailForm.disable();
          this.treatyService.fetchTrasactionDetails(this.transId, this.tranSrNo).subscribe(resp => {

            this.details = resp.claimList;
            for (var i = 0; i < this.details.length; i++) {
              this.details[i].txcProcYn = 1 == this.details[i].txcProcYn ? true : false;
              this.details[i].highestSrNo = this.tranSrNo;
              this.paidRetnTty = this.paidRetnTty + this.details[i].txcPaidRetnTty;
              this.osRetnTty = this.osRetnTty + this.details[i].txcOsRetnTty;

            }
            this.loaderService.isBusy = false;
            let obj = {
              transId: this.transId,
              tranSrNo: this.tranSrNo,
              company: this.session.get("companyCode"),
              divn: this.session.get("userDivnCode"),
              dept: this.session.get("userDeptCode"),
            }
            //this.treatyService.updateProcessYN().subscribe
            this.headeFlage = false;
            this.treatyService.calculateRecoveryAmt(obj).subscribe(resp => {
              this.amount = resp.amount;
            })
          }, error => {
            this.loaderService.isBusy = false;
            this.showContractDetails = false;
            this.showLayerDetails = false;
          })
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error("No data");
        }
      }, error => {
        this.toastService.error(error.error.message);
        this.loaderService.isBusy = false;
        this.showContractDetails = false;
        this.showLayerDetails = false;
      })
    }
  }
  getrefno(refno: any) {
    this.transId = refno
    this.loadseqencenumber();
  }

  loadseqencenumber() {
    this.loaderService.isBusy = true;
    this.treatyService.loadingseqno(this.transId).subscribe(data => {
      this.seqList = data.seqList
      // for(var i=0; i<this.seqList.length;i++){
      //   this.seqList[i];
      // }
      let count = this.seqList.length

      this.seqcount = count;
      if (this.seqcount == 1) {
        this.seqNo = this.seqList[0]
      }

      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  processRecovery() {
    this.loaderService.isBusy = true;
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      company: this.session.get("companyCode"),
      divn: this.session.get("userDivnCode"),
      dept: this.session.get("userDeptCode"),
      userId: this.session.get("userId"),
      seqNo: this.seqNo
    }
    this.getDocumentTypes();

    this.treatyService.processRecovery(obj).subscribe(resp => {
      this.showLayerDetails = true;
      this.treatyService.fetchRecoveryLayerDetails(this.transId, this.tranSrNo).subscribe(resp => {
        this.layerDetails = resp.layerList;
        this.approveBtn = true;
        this.loaderService.isBusy = false;
        this.totalRolDeposit = 0;
        this.totalReInstPremium = 0;
        this.totalRecoverable = 0;
        this.excessMin = [];
        this.totalLimit = 0;
        this.totalMaxRec = 0;
        for (var i = 0; i < this.layerDetails.length; i++) {
          this.totalRecover = this.totalRecover + this.layerDetails[i].txlRecoverd;
          this.totalRecoverable = this.totalRecoverable + this.layerDetails[i].txlRecovery;
          this.totalReInstPremium = this.totalReInstPremium + this.layerDetails[i].txlDepPremRol;
          this.totalReInstPremium = this.totalReInstPremium + this.layerDetails[i].txlReinstPrem;
          this.totalRolDeposit = this.totalRolDeposit + this.layerDetails[i].txlDepPremRol;
          this.totalLimit = this.totalLimit + this.layerDetails[i].txlLimit;
          this.totalMaxRec = this.totalMaxRec + this.layerDetails[i].txlMaxRec;
          this.excessMin.push(this.layerDetails[i].txlDeductible);
          this.maxExcess = Math.min(...this.excessMin);
        }

        let obj = {
          txlTransId: this.transId,
          txlTranSrNo: this.tranSrNo,
          txlLayer: this.layerDetails.length != 0 ? this.layerDetails[0].txlLayerPK.txlLayer : '1',
          layerDesc: this.layerDetails[0].layerDesc
        }

        this.layerSummaryDetails();
        this.showReInsurerDetails(obj, obj.layerDesc);

      }, error => {
        this.loaderService.isBusy = false;
      })

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })

  }

  showReInsurerDetails(detail, layerDesc) {
    this.loaderService.isBusy = true;
    this.layer = detail.txlLayer;
    this.layerDesc = layerDesc != null ? ' - ' + layerDesc : null;
    this.totalReinsurerShare = 0;
    this.totalRecovered = 0;
    this.totalReinsurerReinst = 0;

    this.treatyService.fetchXolReinsurerDetails(detail).subscribe(resp => {
      this.reinsurerDetails = resp.reinsurerList;

      for (var i = 0; i < this.reinsurerDetails.length; i++) {
        this.totalReinsurerShare = this.totalReinsurerShare + this.reinsurerDetails[i].txiSharePerc;
        this.totalRecovered = this.totalRecovered + this.reinsurerDetails[i].txiRecovery;
        this.totalReinsurerReinst = this.totalReinsurerReinst + this.reinsurerDetails[i].txiReinstPrem;
      }
      this.loaderService.isBusy = false;
      this.approveBtn = this.action == 'view' ? false : true;
      this.reinsurerSummaryDetails();
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    })
  }

  approve() {
    if (this.isDocumentNeedsToBeUpdated) {
      this.toastService.warning('Save all documents then try again.');
      return;
    }
    this.loaderService.isBusy = true;
    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      company: this.session.get("companyCode"),
      divn: this.session.get("userDivnCode"),
      dept: this.session.get("userDeptCode"),
      userId: this.session.get("userId")
    }

    this.treatyService.approveXolRecovery(obj).subscribe(resp => {
      if (this.documents && this.documents.length > 0) {
        const gridFSIds = [];
        this.documents.forEach((document) => {
          gridFSIds.push(document.gridFSId);
        });
        this.docService.mapPolicy(
          gridFSIds,
          obj.transId +
          obj.tranSrNo)
          .subscribe(res => {
            this.loaderService.isBusy = false;
            this.toastService.success(resp.message);
            this.disabled = true;
            this.display = "none";
            this.showPrintBtn = true;
          }, err => {
            this.toastService.error('Document(s) not saved.');
          });
      } else {
        this.loaderService.isBusy = false;
        this.toastService.success(resp.message);
        this.modalService.hide();
        this.disabled = true;
        this.display = "none";
        this.showPrintBtn = true;
      }

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
      this.disabled = false;
      this.display = "block";
    })
  }

  loadContractDetails() {
    this.showContractDetails = true;
    this.showrecoveryform = "alldata"

    this.loaderService.isBusy = true;
    this.treatyService.fetchContractDetails(this.transId, this.tranSrNo).subscribe(resp => {
      var result: any = resp.details;
      if (result != null) {
        this.transId = result.txlRecPK.txrTransId;
        this.tranSrNo = result.txlRecPK.txrTranSrNo;
        let date = this.datePipe.transform(result.txrStartDt, ApiUrls.DATE_FORMAT);
        //let year = date.split('-')[2];
        let year = date.split('/')[2];
        this.treatyCurr = result.txrTtyCurr;
        this.contractDetailForm.patchValue({
          contractrefno: result.txrTtyRefNo,
          seqno: result.txrSeqNo,
          claimno: result.txrClmNo,
          event: result.txrEvent,
          eventDesc: result.eventDesc,
          recrefno: result.txlRecPK.txrTransId + "-" + result.txlRecPK.txrTranSrNo,
          userId: result.txrCrUid
        })
        this.contractDetailForm.disable();
        this.treatyService.fetchTrasactionDetails(this.transId, this.tranSrNo).subscribe(resp => {
          this.details = resp.claimList;
          for (var i = 0; i < this.details.length; i++) {
            this.details[i].highestSrNo = this.tranSrNo;
            this.details[i].txcProcYn = 1 == this.details[i].txcProcYn ? true : false;
            this.paidRetnTty = this.paidRetnTty + this.details[i].txcPaidRetnTty;
            this.osRetnTty = this.osRetnTty + this.details[i].txcOsRetnTty;
          }

          this.loaderService.isBusy = false;
          let obj = {
            transId: this.transId,
            tranSrNo: this.tranSrNo,
            company: this.session.get("companyCode"),
            divn: this.session.get("userDivnCode"),
            dept: this.session.get("userDeptCode"),
          }
          //this.treatyService.updateProcessYN().subscribe
          this.treatyService.calculateRecoveryAmt(obj).subscribe(resp => {
            this.amount = resp.amount;
          })
        }, error => {
          this.loaderService.isBusy = false;
          this.showContractDetails = false;
          this.showLayerDetails = false;
        })
        if ('view' == this.action) {
          this.showLayerDetails = true;
          this.treatyService.fetchRecoveryLayerDetails(this.transId, this.tranSrNo).subscribe(resp => {
            this.layerDetails = resp.layerList;
            this.totalRolDeposit = 0;
            this.totalReInstPremium = 0;
            this.totalRecoverable = 0;
            this.excessMin = [];
            for (var i = 0; i < this.layerDetails.length; i++) {
              this.totalRecover = this.totalRecover + this.layerDetails[i].txlRecoverd;
              this.totalRecoverable = this.totalRecoverable + this.layerDetails[i].txlRecovery;
              // this.totalReInstPremium=this.totalReInstPremium+this.layerDetails[i].txlDepPremRol;
              this.totalReInstPremium = this.totalReInstPremium + this.layerDetails[i].txlReinstPrem;
              this.totalRolDeposit = this.totalRolDeposit + this.layerDetails[i].txlDepPremRol;
              this.excessMin.push(this.layerDetails[i].txlDeductible);
              this.maxExcess = Math.min(...this.excessMin);
              this.totalLimit = this.totalLimit + this.layerDetails[i].txlLimit;
              this.totalMaxRec = this.totalMaxRec + this.layerDetails[i].txlMaxRec;
            }
            this.layerSummaryDetails();
            let obj = {
              txlTransId: this.transId,
              txlTranSrNo: this.tranSrNo,
              txlLayer: this.layerDetails.length != 0 ? this.layerDetails[0].txlLayerPK.txlLayer : '1',
              layerDesc: this.layerDetails[0].layerDesc
            }
            this.showReInsurerDetails(obj, obj.layerDesc);
          }, error => {
            this.loaderService.isBusy = false;
          })
        } else {
          this.showLayerDetails = false;
          this.loaderService.isBusy = false;
        }
      }
    }, error => {
      this.loaderService.isBusy = true;
      this.toastService.error(error.error.message);
      // this.disabled=false;
    });

  }

  layerSummaryDetails() {
    this.bottomData = [
      {
        txlTtySeqNo: 'Total',
        txlFlex01: '',
        txlProgCode: '',
        txlLayerPK: { txlLayer: '' },
        txlAttachBasis: '',
        txlPremCurr: '',
        txlLimit: this.totalLimit,//this.totalLimit
        txlDeductible: this.maxExcess,//this.maxExcess,
        txlMaxRec: '',//this.totalMaxRec
        txlRecoverd: this.totalRecover,
        txlRecovery: this.totalRecoverable,
        txlDepPremRol: this.totalRolDeposit,
        txlReinstPerc: '',
        txlReinstPrem: this.totalReInstPremium

      }
    ];
  }

  reinsurerSummaryDetails() {
    this.reinsurerSummaryData = [
      {
        txlReinsPK: { txiReins: 'Total' },
        txiBroker: '',
        txiAcntTo: '',
        txiSharePerc: this.totalReinsurerShare + "%",
        txiRecovery: this.totalRecovered,
        txiReinstPrem: this.totalReinsurerReinst
      }
    ]
  }

  printDocument(docType) {
    if (docType == 'XL_REINST') {
      var params = {
        refNo: this.transId,
        amendNo: this.tranSrNo,
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_003',
        docType: docType
      }
    } else {
      var params = {
        refNo: this.transId,
        amendNo: this.tranSrNo,
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_002',
        docType: docType
      }
    }

    this.treatyService.fetchReportUrl(params)
      .subscribe(result => {
        var url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
    width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(url, 'Reports', param);

      });
  }
  backAdjust() {

    let obj = {
      transId: this.transId,
      tranSrNo: this.tranSrNo,
      processId: this.processId,
      mode: 'back',
      action: this.treatyService.getParamValue('approveStatus'),
      refNo: this.treatyService.getParamValue('refNo')
    }
    // alert(this.treatyService.getParamValue('approveStatus'));
    this.router.navigate(['/treaty/adjust-premium'], { queryParams: obj, skipLocationChange: true });
  }


  readUrl(e) {
    this.loaderService.isBusy = true;
    let file: File = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    let formData: FormData = new FormData();
    formData.append('file', file, file.name);
    formData.append('tditransId', this.transId);
    formData.append('tditranSrNo', this.tranSrNo);
    formData.append('doctype', "XL-RECOVERY");
    formData.append('userId', this.session.get("userId"));
    var uploadDocumentReponse = this.treatyService.uploadDoc(formData);
    this.upload = uploadDocumentReponse._isScalar;
    this.loaderService.isBusy = false;
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params, gridName: any) {
    this.gridOptionsDetail = params.api;
    if (gridName === 'claims') {
      this.claimsGridApi = params.api;
    } else if (gridName === 'layer') {
      this.layerGridApi = params.api;
    } else if (gridName === 'reinst') {
      this.reinstGridApi = params.api;
    } else if (gridName === 'contract') {
      this.contractGridApi = params.api;
    }
    params.api.sizeColumnsToFit();
  }
  displayedRowCount(gridApi) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }


  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: AgGridCheckboxComponent
    };
  }
  public onRowClicked(e) {
    //alert(e.data.cbox+"-"+e.data.txcCompany);
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "ViewClaim":
          this.transId = data.transId;
          this.tranSrNo = data.transSrNo;
          // this.approveBtn = data.approveStatus == 'A' ? false : true;
          this.action = data.approveStatus == 'A' ? 'view' : 'edit';
          return this.loadContractDetails();
        case "View":
          return this.showReInsurerDetails(data.txlLayerPK, data.layerDesc);
      }
    }
  }

  public onTransanctionLayerRowClicked(e, title) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");

      switch (actionType) {
        case "View":
          return this.showReInsurerDetails(data.txlLayerPK, data.layerDesc);
        case "HyperLink":
          if (data.tlAad != "null") {
            return this.showAADDetails(data);
          }
      }

      if (title == 'layer') {
        let obj = {
          txlLayer: data.txlLayerPK.txlLayer,
          txlTranSrNo: data.txlLayerPK.txlTranSrNo,
          txlTransId: data.txlLayerPK.txlTransId,
          layerDesc: data.layerDesc
        }
        this.showReInsurerDetails(obj, obj.layerDesc);
      }
    }
  }

  showAADDetails(data) {
    let obj = {
      txlLayer: data.txlLayerPK.txlLayer,
      txlTtySeqNo: data.txlTtySeqNo,
      txlTtyRefNo: data.txlTtyRefNo,
      tlAad: data.tlAad,
      txlPremCurr: data.txlPremCurr
    }
    this.treatyService.getAadData(obj).subscribe(resp => {
      this.aadGridData = resp;
      this.aadObj = obj;
      this.viewAAD(this.aadContentTemplate);
      this.showAadGrid = true;
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    })
  }

  viewAAD(data: any) {
    this.open(data, 'modal-sm');
<<<<<<< HEAD
  }

=======
    // this.modalService.open(data, { size: 'modal-lg' }).result.then((result) => {
    // }, (reason) => {
    //   //  this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  processCheckBoxGrid(event, data) {
    let body = data.data.txlClmPK;
    this.loaderService.isBusy = true;
    this.treatyService.updateProcessYN(body, event.target.checked ? "1" : "0").subscribe(resp => {
      // this.details = [];
      this.treatyService.fetchTrasactionDetails(this.transId, this.tranSrNo).subscribe(resp => {
        this.loaderService.isBusy = false;
        this.details = resp.claimList;
        for (var i = 0; i < this.details.length; i++) {
          this.details[i].highestSrNo = this.tranSrNo;
          this.details[i].txcProcYn = 1 == this.details[i].txcProcYn ? true : false;
          // this.paidRetnTty=this.paidRetnTty+this.details[i].txcPaidRetnTty;
          //this.osRetnTty=this.osRetnTty+this.details[i].txcOsRetnTty;
        }
        let obj = {
          transId: this.transId,
          tranSrNo: this.tranSrNo,
          company: this.session.get("companyCode"),
          divn: this.session.get("userDivnCode"),
          dept: this.session.get("userDeptCode"),
        }

        this.treatyService.calculateRecoveryAmt(obj).subscribe(resp => {
          this.amount = resp.amount;
        }, error => {
          this.loaderService.isBusy = false;
        })
      }, error => {
        this.loaderService.isBusy = false;
      })
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  onSelectionChanged(event, gridApi: any) {

    let selectedRows = gridApi.getSelectedRows();

    let selectedRowsString = '';
    selectedRows.forEach(function (selectedRow, index) {
      if (index !== 0) {
        selectedRowsString += ', ';
      }
      selectedRowsString += selectedRow.athlete;
    });


  }

  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    // alert(gridApi);
    gridApi.setQuickFilter(qickSearch);
  }
  onBtExportCont(gridApi: any) {
    if (gridApi) {
      gridApi.exportDataAsExcel({
        columnKeys: ['transId','transSrNo','contractReference','claimNo','event','approverDate',
        'approverName','approveStatus'] 
      });
    }
  }
  onBtExportLayer(gridApi: any) {
    if (gridApi) {
      gridApi.exportDataAsExcel({
        columnKeys: ['txlTtySeqNo','txlLayerPK.txlLayer','txlAttachBasis','txlPremCurr','txlLimit',
        'txlDeductible','tlAad','txlMaxRec','txlRecoverd','txlRecovery','txlDepPremRol','txlReinstPerc','txlReinstPrem'],
        processCellCallback: (params) => {
          if (params.column.colId == "txlLimit" || params.column.colId == "txlDeductible" || params.column.colId == "tlAad"
          || params.column.colId == "txlMaxRec" || params.column.colId == "txlRecoverd" || params.column.colId == "txlRecovery"
          || params.column.colId == "txlDepPremRol" || params.column.colId == "txlReinstPrem"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }
        }
      });
    }
  }
  onBtExport(gridApi: any) {
    if (gridApi) {
      gridApi.exportDataAsExcel({
        processCellCallback: (params) => {
          if(params.column.colId == "txcIncurred" || params.column.colId == "txcOsPay" || params.column.colId == "txcPaid"
          || params.column.colId == "txcPaidRetn" || params.column.colId == "txcOsRetn"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }
        }
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
  }
  onRefClicked(data) {
  }
  confirmationBlock() {
    this.open(this.confirmation, 'modal-sm');
<<<<<<< HEAD
=======
    // this.modalService.open(this.confirmation, { size: 'modal-sm' }).result.then((result) => {
    // }, (reason) => {
    // });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  ClaimRecovery() {
    if (this.claim_Event || (this.claim_No && this.claim_SeqNo && this.claim_contRef)) {

    }
  }

  viewAccounting(docType) {
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'docType': docType } });
<<<<<<< HEAD
    //this.router.navigate(['/mga-view-accounting'], { queryParams: { batchId: '595', binder:  'DEP_PREM_ADJ',status:'A' } });
  }

=======
  }

  closeModal() {
    this.modalService.hide();
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
}
function numberFormatter(params) {
  return params.value.toFixed(2);
}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return }

}
function currencyFormatter(params) {
  return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
}
function activityStatus(params) {
  if (params.data.approveStatus === undefined || params.data.approveStatus === null) {
    return '';
  } else if (params.data.approveStatus == 'A') {
    return '<span class="ag-element"> Approved </span>';
  } else if (params.data.approveStatus == 'P') {
    return '<span class="ag-element"> Pending </span>';
  }
}
function actionRender(params) {
  if (params.data.approveStatus === undefined || params.data.approveStatus === null) {
    return '';
  } else if (params.data.approveStatus == 'A') {
    return `<a>
    <i class=" fa fa-eye fa-icon" data-action-type="ViewClaim" title="View" aria-hidden="true" ></i>
</a>
    `;
  } else {
    return `    
    <a>
<<<<<<< HEAD
    <i class=" fa fa-file-pen fa-icon" data-action-type="ViewClaim" style="font-size: 1.55em" title="Edit" aria-hidden="true" ></i>
=======
    <i class=" fa fa-file-pen fa-icon" data-action-type="ViewClaim" title="Edit" aria-hidden="true" ></i>
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
</a> `
  }
}
function apprDateCellRenderer(params) {
  if (params && params.value) {
    return moment(params.value,'DD/MM/YYYY').format('DD/MM/YYYY');
  } else {
    return '';
  }
}

var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};
function actionRenderLayer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class=" fa fa-eye fa-icon" data-action-type="View" title="View" aria-hidden="true" ></i>
</a>`;
  }
}