import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoveryEnquiryFormComponent } from './recovery-enquiry-form.component';

describe('RecoveryEnquiryFormComponent', () => {
  let component: RecoveryEnquiryFormComponent;
  let fixture: ComponentFixture<RecoveryEnquiryFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecoveryEnquiryFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoveryEnquiryFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
