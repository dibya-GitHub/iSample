import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'hiperLink',
    template: `
    <a class="bold-cls" (click)="linkClicked($event)" data-action-type="HyperLink">{{ value }}</a>`,
    styles: ['a { color: #036aff }']
})
export class HiperLinkComponent {
    @Input()
    value: any;
    data: any;
    show_dialog: Boolean = false;
    private event: any;

    constructor(private route: Router) { }
    agInit(params: any) {
        this.data = params.data;
        this.value = params.value;
        if (params.colDef.cellRendererParams) {
            this.event = params.colDef.cellRendererParams.event;
        }
    }

    linkClicked(event) {
        if (this.event) {
            this.event(event, this.data);
        }
    }
}
