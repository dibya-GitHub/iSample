import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
declare var $: any;

@Component({
  selector: 'app-risk-llyods',
  templateUrl: './risk-llyods.component.html',
  styleUrls: ['./risk-llyods.component.css']
})
export class RiskLlyodsComponent implements OnInit {
  addFlag: boolean = true;
  paginationPageSize: number;

  public gridApi;
  public columnDefs;
  public defaultColDef;
  public getRowHeight;
  public rowData = [];
  showRiskLlyodsFlag: boolean = false;
  closeResult: string;
  riskLlyodsForm: UntypedFormGroup;
  selectedRiskLlyodsData = [];
  selectedRiskLlyodsPercentageOn = [];
  @Input() seqNo: any;
  @Input() refNo: any;
  @Input() amendNo: any;
  @Input() action: any;
  tyId: any;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  temp: any;

  constructor(
    private fb: UntypedFormBuilder,
    private riskLlyodsService: TreatyService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService
  ) {
    this.columnDefs = [
      {
        headerName: "Risks",
        field: "tyRiskDesc",
        sortable: true,
        tooltipField: "tyRiskDesc",
      },
      {
        headerName: "%",
        field: "tyRiskPerc",
        sortable: true,
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Action",
        template:
          `<a>
              <i class="fa fa-file-pen" data-action-type="Edit"  title="Edit" aria-hidden="true" ></i>
<<<<<<< HEAD
              <i class="fa fa-trash" data-action-type="Remove"  title="Delete" aria-hidden="true"></i>
          </a>`
      }
    ];
=======
              <i class="fa fa-trash fa-icon fa-danger" data-action-type="Remove"  title="Delete" aria-hidden="true"></i>
          </a>`
      }
    ];

    this.defaultColDef = {
      resizable: true,
      enableRowGroup: true,
      sortable: true,
      editable: false
    };
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 35;
      }
    };
  }

  ngOnInit() {
    this.riskLlyodsForm = this.fb.group({
      tyRefNo: '',
      tySeqNo: '',
      tyAmendNo: '',
      tyLayer: 'Layer 1',
      tyRiskCode: ['', Validators.required],
      tyRiskPerc: '',
      tyStatus: '',
      tyCrUid: this.session.get('userId'),
      tyCrDt: new Date(),
    })
    this.riskLlyodsService.appCodesList(ApiUrls.TREATY_RISK_LLOYDS_CODE).subscribe(resp => {
      this.selectedRiskLlyodsData = resp.appcodeList;
      this.ngAfterViewInit();

    });
    this.onRiskLlyodsGridReady();
    this.paginationPageSize = 3;
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.onActionEditRiskLlyodsRow(data);
        case "Remove":
          return this.showDialogbox(data);
      }
    }
  }

  onActionEditRiskLlyodsRow(data) {
    this.loaderService.isBusy = true;
    this.action = 'edit';

    let obj = {

      tyRefNo: data.mttyRiskLloydsPK.tyRefNo,
      tySeqNo: data.mttyRiskLloydsPK.tySeqNo,
      tyAmendNo: data.mttyRiskLloydsPK.tyAmendNo,
      tyLayer: 'Layer 1',
      tyRiskCode: data.mttyRiskLloydsPK.tyRiskCode,
    }
    this.riskLlyodsService.getRiskLlyodsById(obj).subscribe((result) => {
      result = result.riskLloydsList;
      this.riskLlyodsForm.patchValue({
        tyRefNo: result.mttyRiskLloydsPK.tyRefNo,
        tySeqNo: result.mttyRiskLloydsPK.tySeqNo,
        tyAmendNo: result.mttyRiskLloydsPK.tyAmendNo,
        tyLayer: result.mttyRiskLloydsPK.tyLayer,
        tyRiskCode: result.mttyRiskLloydsPK.tyRiskCode,
        tyRiskPerc: result.tyRiskPerc
      });
    });
    this.showRiskLlyodsFlag = true;
    this.addFlag = false;
    this.loaderService.isBusy = false;
  }
  close() {
    this.showRiskLlyodsFlag = false;
    this.addFlag = true;
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
<<<<<<< HEAD
=======
  }
  closeModal() {
    this.modalService.hide();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  deleteRiskLloyds() {

    let obj = {

      tyRefNo: this.refNo,
      tySeqNo: this.seqNo,
      tyAmendNo: this.amendNo,
      tyLayer: 'Layer 1',
      tyRiskCode: this.temp.mttyRiskLloydsPK.tyRiskCode,
    }
    if (this.temp) {
      this.loaderService.isBusy = true;
      this.riskLlyodsService.deleteRiskLlyodsDetailById(obj).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully');
        this.onRiskLlyodsGridReady();
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    } else {
      this.toastService.warning('select record to delete');
    }
  }
  addNewRiskLlyods() {
    this.action = 'add';
    this.riskLlyodsForm.reset();
    this.showRiskLlyodsFlag = true;
    this.addFlag = false;
  }
  saveRiskLlyodsForm() {
    let formValue = this.riskLlyodsForm.value;
    if (this.riskLlyodsForm.valid) {
      let formData = {
        mttyRiskLloydsPK:
        {
          tyRefNo: this.refNo,
          tySeqNo: this.seqNo,
          tyAmendNo: this.amendNo,
          tyLayer: 'Layer 1',
          tyRiskCode: formValue.tyRiskCode,
        },
        tyRiskPerc: formValue.tyRiskPerc,
        tyStatus: 'P',
        tyCrUid: this.session.get('userId'),
        tyCrDt: new Date(),
      }

      this.loaderService.isBusy = true;
      this.riskLlyodsService.saveRiskLlyodsDetails(formData).subscribe(resp => {
        this.toastService.success("Successfully Saved");
        this.onRiskLlyodsGridReady();
        this.showRiskLlyodsFlag = false;
        this.addFlag = true;
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      });

    } else {
      this.validateAllFormFields(this.riskLlyodsForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  showDialogbox(val: any) {
    this.temp = val;
    this.open(this.confirmModal, 'modal-sm');
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.onRiskLlyodsGridReady();
  }
  onRiskLlyodsGridReady() {
    let data = {
      tyRefNo: this.refNo,
      tyAmendNo: this.amendNo,
      tySeqNo: this.seqNo,
      tyLayer: 'Layer 1'
    }
    this.riskLlyodsService.retrieveRiskLlyodsByRefId(data).subscribe(resp => {
      this.rowData = resp.trustFundList;
      this.ngAfterViewInit();
      this.gridApi.sizeColumnsToFit();
    })
  }

  ngAfterViewInit() {

    $('.selectpicker').selectpicker({ dropupAuto: false });
    setTimeout(() => {
      $('.selectpicker').selectpicker('refresh');
    }, 500);
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  closeModal() {
    this.modalService.hide();
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("riskLlyodGrid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  Validations(val) {
    var tyRiskPerc = parseFloat(val);
    if (tyRiskPerc > 100) {
      this.toastService.warning(" Percentage should not be greater than 100.")
    } else if (tyRiskPerc == 0) {
      this.toastService.warning(" Percentage should be  greater than 0.");
    }
  }
}
