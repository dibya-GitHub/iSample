import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskLlyodsComponent } from './risk-llyods.component';

describe('RiskLlyodsComponent', () => {
  let component: RiskLlyodsComponent;
  let fixture: ComponentFixture<RiskLlyodsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiskLlyodsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiskLlyodsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
