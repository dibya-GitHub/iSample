import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EGNPComponent } from './egnp.component';

describe('EGNPComponent', () => {
  let component: EGNPComponent;
  let fixture: ComponentFixture<EGNPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EGNPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EGNPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
