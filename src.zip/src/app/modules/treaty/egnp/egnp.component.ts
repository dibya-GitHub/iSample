<<<<<<< HEAD
import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
=======
import { Component, OnInit, Input, Output, Inject, EventEmitter } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Router } from '@angular/router';
import { UntypedFormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ViewChild } from '@angular/core';
import { ElementRef } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
declare var $: any;

@Component({
  selector: 'app-egnp',
  templateUrl: './egnp.component.html',
  styleUrls: ['./egnp.component.css'],
  providers: [DatePipe]
})
export class EGNPComponent implements OnInit {
  compcode: any;
  showForm: boolean = false;
  code4: any;
  code3: any;
  code2: any;
  code1: any;
  code: any;
  lobList: any;
  divnList: any;
  compList: any;

  details: any[];
  cols: any[];

  epiForm: UntypedFormGroup;

  action: string;
  display: boolean = false;
  collapsed: boolean = true;
  refNo: string;
  totalPremium: number = 0;
  baseCurrency: string = "";
  changeaction: string;
  @Input() amendNo: string;
  @Input() amndSrNo: any;
  @Output() countChange = new EventEmitter();
  @ViewChild('trigger') tr: ElementRef;
  @ViewChild('content') content: ElementRef;

<<<<<<< HEAD
  constructor(
    private fb: UntypedFormBuilder,
=======
  constructor(private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,
    private modalService: BsModalService
    ) { }

  ngOnInit() {
    this.changeaction = "save"
    this.cols = [
      { field: 'companyName', header: 'Company', type: '' },
      { field: 'branch', header: 'Branch', type: '' },
      { field: 'classDesc', header: 'Class', type: '' },
      { field: 'tePrem', header: 'Premium', type: 'number' },
      { field: 'Action', header: 'Action', type: 'number' }
    ];
    this.epiForm = this.fb.group({
      teRefNo: this.refNo,
      teAmendNo: this.amendNo,
      tePrem: ['', Validators.required],
      teStatus: 'A',
      teCrUid: this.session.get('userId'),
      teCrDt: new Date(),
      teCompany: ['', Validators.required],
      teDivision: ['', Validators.required],
      teLob: ['', Validators.required],
      ttyEpiPK: ''
    })
  }
  retrieveEpiDetails() {
    this.loaderService.isBusy = true;

    this.treatyService.retrieveEpiDetailsById(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      this.details = resp.egnpList;
      let result: any = resp.egnpList;
      for (var i = 0; i < result.length; i++) {
        this.totalPremium = this.totalPremium + parseInt(result[i].tePrem);
      }
      this.loaderService.isBusy = false;
    }, error => {
      // this.scriptcall('egnpi');
      this.loaderService.isBusy = false;
    });
  }
  seqNo(refNo: string, amendNo: string, seqNo: any) {
    throw new Error("Method not implemented.");
  }

  toggleModal(refNo, currency, mode) {
    if (refNo == null || refNo == "") {
      this.toastService.warning("Please Enter Reference No ");
    } else if (currency == null || currency == "") {
      this.toastService.warning("Please Select Currency ");
    } else {
      this.action = mode;
      this.refNo = refNo;
      this.baseCurrency = currency;
      //alert(currency);
      this.retrieveEpiDetails();
      // this.display = !this.display;
<<<<<<< HEAD
      this.open(this.content, 'modal-lg');
    }
  }

  open(content, val) {
    this.modalService.show(content, { class: val });
=======
      this.open(this.content, 1,'modal-lg');
    }
  }

  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val });
    // this.modalService.show(content, { size: 'modal-lg' }).result.then((result) => {
    //   // this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   //  this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  add() {
    this.showForm = true;

    //this.collapsed = !this.collapsed;

    this.action = 'add';
    this.retrieveCompDetails();
    // this.retrieveDivnetails();
    this.retrieveLobDetails();

  }
  editEpi(data: any) {
    this.retrieveCompDetails();
    // this.retrieveDivnetails();
    this.treatyService.retrieveDivnDetails(data.ttyEpiPK.teCompany).subscribe(resp => {
      //this.applySelect();
      this.divnList = resp.divisionList;
    })
    this.retrieveLobDetails();
    // this.collapsed = !this.collapsed;
    this.showForm = true;
    this.action = 'edit';
    this.code = data.ttyEpiPK.teRefNo
    this.code1 = data.ttyEpiPK.teAmendNo
    this.code2 = data.ttyEpiPK.teCompany
    this.code3 = data.ttyEpiPK.teDivision
    this.code4 = data.ttyEpiPK.teLob
    let objpk = {
      teRefNo: this.code,
      teAmendNo: this.code1,
      teCompany: this.code2,
      teDivision: this.code3,
      teLob: this.code4
    }
    this.treatyService.retrieveEgnpById(objpk).subscribe(result => {
      let resp = result.premiunList;
      this.epiForm.patchValue({
        teRefNo: resp.ttyEpiPK.teRefNo,
        teAmendNo: resp.ttyEpiPK.teAmendNo,
        tePrem: resp.tePrem,
        teStatus: resp.teStatus,
        teCrUid: resp.teCrUid,
        teCrDt: resp.teCrDt,
        teCompany: resp.ttyEpiPK.teCompany,
        teDivision: resp.ttyEpiPK.teDivision,
        teLob: resp.ttyEpiPK.teLob,
        ttyEpiPK: resp.ttyEpiPK
      })


    })
    this.epiForm.controls['teCompany'].disable()
    this.epiForm.controls['teDivision'].disable()
    this.epiForm.controls['teLob'].disable()
    this.changeaction = "update"


  }
  save() {
    if (this.epiForm.valid) {
      this.loaderService.isBusy = true;
      var objPk = {
        teRefNo: this.refNo,
        teAmendNo: this.amendNo,
        teCompany: this.epiForm.get('teCompany').value,
        teDivision: this.epiForm.get('teDivision').value,
        teLob: this.epiForm.get('teLob').value
      }
      if (this.action == 'edit') {
        this.epiForm.controls['teCompany'].enable()
        this.epiForm.controls['teDivision'].enable()
        this.epiForm.controls['teLob'].enable()
        this.epiForm.patchValue({
          ttyEpiPK: objPk
        })
<<<<<<< HEAD
        this.treatyService.updateEgnpById(this.epiForm.value, this.seqNo, this.amndSrNo).subscribe(resp => {
          this.toastService.success("successfully updated");
=======
        console.log(this.epiForm.value)
        this.treatyService.updateEgnpById(this.epiForm.value,this.seqNo,this.amndSrNo).subscribe(resp => {
          this.toastService.success( "Successfully Updated" );
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          this.countChange.emit(resp.messageType);
          this.retrieveEpiDetails();
          this.loaderService.isBusy = false;
          this.showForm = false;

          //  this.retrieveEpiDetails();
        }, error => {
          this.loaderService.isBusy = false;
        })

      } else {


        this.epiForm.patchValue({
          ttyEpiPK: objPk,
          teStatus: 'A',
          teCrUid: this.session.get('userId'),
          teCrDt: new Date(),

        })

<<<<<<< HEAD
        this.treatyService.insertEgnp(this.epiForm.value, this.amndSrNo).subscribe(resp => {
          this.toastService.success("successfully saved");
=======
        this.treatyService.insertEgnp(this.epiForm.value,this.amndSrNo).subscribe(resp => {
          this.toastService.success( "Successfully Saved");
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          this.countChange.emit(resp.messageType);
          this.loaderService.isBusy = false;
          this.retrieveEpiDetails();
          // this.display = !this.display;
          this.epiForm.reset()
          this.showForm = false;
        }, error => {
          this.loaderService.isBusy = false;
        })
      }
    } else {
      this.validateAllFormFields(this.epiForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }


  retrieveCompDetails() {
    this.treatyService.retrieveCompDetails().subscribe(resp => {
      // this.applySelect();
      this.compList = resp.companyList;

    })
  }
  retrieveDivnetails(event) {
    this.loaderService.isBusy = true;
    this.compcode = event.target.value;
    this.treatyService.retrieveDivnDetails(this.compcode).subscribe(resp => {
      this.divnList = resp.divisionList;
      this.loaderService.isBusy = false;
      //this.applySelect();
    }, error => { this.loaderService.isBusy = false; })
  }
  retrieveLobDetails() {
    this.treatyService.retrieveLobDetails().subscribe(resp => {
      this.lobList = resp.lobList;
      // this.applySelect();
    })
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
      if (control instanceof UntypedFormControl) {
=======
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });


  }

  deleteEpi(data) {
    // this.confirmationService.confirm({
    //   message: 'Do you want to delete this ?',
    //   header: 'Delete Confirmation',
    //   icon: 'pi pi-info-circle',
    //   accept: () => {
    this.loaderService.isBusy = true;
    this.treatyService.deleteEgnpList(data.ttyEpiPK, this.seqNo, this.amndSrNo).subscribe(resp => {
      this.retrieveEpiDetails();
    }, error => {
      this.loaderService.isBusy = false;
    })
    //   },
    //   reject: () => {
    //   }
    // })
  }

  back() {
    this.showForm = false;
  }

}
