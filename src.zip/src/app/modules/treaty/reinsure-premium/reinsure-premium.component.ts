import { DatePipe, DOCUMENT } from '@angular/common';
import { Component, ElementRef, EventEmitter, Inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
<<<<<<< HEAD
=======
// import * as Module from 'module';

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
declare var $: any;

@Component({
  selector: 'app-reinsure-premium',
  templateUrl: './reinsure-premium.component.html',
  styleUrls: ['./reinsure-premium.component.css']
})
export class ReinsurePremiumComponent implements OnInit {
  summaryGridApi: any;
  instGridApi: any;
  layerGridApi: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  summaryShowEntriesOptionSelected = 5;
  instShowEntriesOptionSelected = 5;
  layerShowEntriesOptionSelected = 5;
  summaryQuickSearchValue: string = '';
  reintQuickSearchValue: string = '';
  layerQuickSearchValue: string = '';
  public columnDefs;
  public summaryColumns;
  public defaultColDef;
  private getRowHeight;
  public context;
  private frameworkComponents;
  readonly: boolean = false;
  instlDetails: any = [];
  bottomData: any[] = [];
  showForm: boolean = false;
  instlFrm: UntypedFormGroup;
  WarrDays: any;
  noOfInst: any;
  total: number;
  custDeposit: any;
  showreinsur: any[];
  custName: any;
  currencyList: any;
  currencyCode: any;
  totcustDep: any;
  strCustDepPrem: any;
  strCustPrem: any;
  showReinst: boolean;
  instlCols: any = [];
  reInstDetails: any = [];
  totCustdepPrm: any;
  totCustPrm: any;
  totStlDepPrm: any;
  totstlPrem: any;
  customer: any;
  // amendNo: any;
  // refNo: any;
  showInstlment: boolean;
  isShowLayer: boolean;
  layerCols: any[];
  displayForm: boolean;
  details: any;
  layerDetails: any[];
  cols: any[];
  display: boolean = false;
  totalPremium: number = 0;
  totalDepPremium: number = 0;
  @Input() contractNo: string;
  @Input() contractAmendNo: string;
  @Input() action: string;

  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() egnpiAmt: number;
  @Input() seqNo: number;
  @Input() basecurr;
  @Input() fullContractType: string;
  @Input() contractType: string;
  @Input() egnpiLabel: string;
  @Output() approve = new EventEmitter<any>();
  @Output() print = new EventEmitter<any>();
  @Input() btnAction: string;
  @Input() showPrintBtn: any;
  @Input() showAproveBtn: any;
  @Input() amndSrNo: any;
  @ViewChild('trigger') tr: ElementRef;
  @ViewChild('contents') contents: ElementRef;
  @ViewChild('approvecontent') approveContent: ElementRef;
  @ViewChild('confirmContent') confirmContent: ElementRef;
  @ViewChild('rebatecontent') rebatecontent: ElementRef;
  @Input() sequenceNo: any;
  selectedId: any;
  componentParent: any = {};
  documentTypes: any;
  docId: string;
  documents: any;
  isDocumentNeedsToBeUpdated: any;
  pinnedBottomRowData: any;
  getRowStyle: (params: any) => { 'font-weight': string; };
  rebateForm: UntypedFormGroup;
  rebateCustomer: string;
  totalRebateAmt: any;
  totalNetAmt: any;
  selectedRowId: any;
  isFreezeAndConfirm: boolean = false;

  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
    private datePipe: DatePipe,
    private toastService: ToastService,
<<<<<<< HEAD
    private wizardHelper: TreatyWizardHelperService,
    private cpipe: MycurrencyPipe,
    @Inject(DOCUMENT) private document: Document
  ) {
=======
    private wizardHelper: TreatyWizardHelperService, private cpipe: MycurrencyPipe,
    @Inject(DOCUMENT) private document: Document) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };

    this.rebateFormGroup();

  }
  rebateFormGroup() {
    this.rebateForm = this.fb.group({
      strRebateAmt: ['', Validators.required],
      strRebatePerc: [undefined, Validators.required],
      strCustDepPrem: undefined,
      ttyReinsPremPK: undefined,
      custName: undefined,
      strCustPrem: undefined
    });
  }
  ngOnInit() {
    this.agGridOptions();
    this.loaderService.isBusy = true;
    this.displayForm = false;
    this.refNo = this.contractNo;
    this.amendNo = this.contractAmendNo;
    this.docId = 'C-' + this.refNo + '-' + this.seqNo + '-' + this.amendNo;
    //this.action=this.action;
    this.columnDefs = [
      {
        headerName: "Select",
        field: 'id',
        cellRenderer: "radioButtonRenderer",
<<<<<<< HEAD
        // cellRenderer: function (params) {
        //   if (params.value) {
        //     return "radioButtonRenderer"
        //   } else {
        //     return ``;
        //   }
        // }
        // hide: false,
        // lockVisible: true,
        // function (params) {
        //   if (params.value == null) {
        //     return false
        //   } else {
        //     return true
        //   }
        // },
        cellStyle: { textAlign: 'center' },
        field: 'accToDesc',
        filter: false,
        sortable: false,
        enableRowGroup: false,

=======
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },
      {
        headerName: "Reinsurer/Broker",
        field: "custName",
        sortable: true,
        valueGetter: function (params) {
          if (params.data.ttyReinsPremPK.strCustomer != null && params.data.custName != null) {
            return params.data.ttyReinsPremPK.strCustomer + '-' + params.data.custName;
          } else {
            return params.data.custName;
          }
        }
      },
      {
        headerName: "Account To",
        field: "accToDesc",
        sortable: true,
      },
      {
        headerName: "Prem CCY",
        field: "ttyReinsPremPK.strPremCurr",
        sortable: true,
      },
      {
        headerName: "100% Premium",
        field: "strCustPrem",
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.strCustPrem) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.strCustPrem));
          } else {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Deposit Premium",
        field: "strCustDepPrem",
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.strCustDepPrem) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.strCustDepPrem));
          } else {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Rebate (%)",
        field: "strRebatePerc",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.strRebatePerc) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.strRebatePerc));
          } else {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' },
        // editable: true
      },
      {
        headerName: "Rebate Amount",
        field: "strRebateAmt",
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.strRebateAmt) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.strRebateAmt));
          } else {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          }
        },
        cellStyle: { textAlign: 'right' },
        // editable: true
      },
      {
        headerName: "Net Amount",
        field: "strCustDepNetPrem",
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.strCustDepNetPrem) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.strCustDepNetPrem));
          } else {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          }
        },
        // valueGetter: netAmountCalc,
        cellStyle: { textAlign: 'right' },
        // editable: true
      },
      {
        headerName: "Action",
        field: "custName",
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
        cellRenderer: function (params) {
          if (params.value) {
            return ` <a>
            <i class="fa fa-file-pen fa-icon" data-action-type="EditRebate"  title="Edit Rebate" aria-hidden="true" ></i>
            &nbsp;&nbsp;
            <i class="fa fa-eye fa-icon" data-action-type="View"  title="View" aria-hidden="true" ></i>
            </a>`
          } else {
            return ``;
          }
        }
      }
    ];

    this.summaryColumns = [
      {
        field: 'select', headerName: 'Select',
        // width: 90 
      },
      {
        field: 'custName', headerName: 'custName',
        // width: 90 
      },
      {
        field: 'accToDesc', headerName: 'Accounting To',
        //  width: 90 
      },
      {
        field: 'currency', headerName: 'Prem CCY',
        // width: 90
      },
      {
        field: 'strCustPrem', headerName: '100% Premium',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.strCustPrem) {
            return Number(params.data.strCustPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        // , width: 120
      },
      {
        field: 'strCustDepPrem', headerName: 'Dep Premium',
        cellStyle: { textAlign: 'right' },// valueGetter: currencyFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.strCustDepPrem) {
            return Number(params.data.strCustDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        //  width: 120
      }, {
        headerName: "Rebate (%)",
        field: "strRebatePerc",
        // valueFormatter: currencyFormatter,
        cellStyle: { textAlign: 'center' }
      },
      {
        headerName: "Rebate Amount",
        field: "strRebateAmt",
        //valueGetter: currencyFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.strRebateAmt) {
            return Number(params.data.strRebateAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Net Amount",
        field: "strCustDepNetPrem",
        valueGetter: function (params) {
          if (params.data && params.data.strCustDepNetPrem) {
            return Number(params.data.strCustDepNetPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        //valueGetter: currencyFormatter,
        // valueGetter: netAmountCalc,
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: 'Action',
        field: 'action',
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },
    ];


    this.layerCols = [
      {
        headerName: "Layer",
        field: "tttyLayerPremPK.stlLayer",
        sortable: true,
        valueGetter: function (params) {
          var reference = params.data.tttyLayerPremPK.stlLayer
          if (reference == null || reference == "null") {
            return "";
          } else {
            return reference + '-' + params.data.layerDesc;

          }

        }
      },
      {
        headerName: "Prem CCY",
        field: "stlPremCurr",
        sortable: true,
      },
      {
        headerName: "Layer 100% Premium",
        field: "stlPrem",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.stlPrem) {
            return Number(params.data.stlPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Layer Deposit Premium",
        field: "stlDepPrem",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.stlDepPrem) {
            return Number(params.data.stlDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Share %",
        field: "stlSharePerc",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.stlSharePerc) {
            return Number(params.data.stlSharePerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "100% Premium",
        field: "stlCustPrem",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.stlCustPrem) {
            return Number(params.data.stlCustPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Deposit Premium",
        field: "stlCustDepPrem",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.stlCustDepPrem) {
            return Number(params.data.stlCustDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      }
    ];



    this.showreinsur = [
      {
        headerName: "Installment No",
        field: "ttyInstPK.tinInstNo",
        sortable: true,
      },
      {
        headerName: "Installment Date",
        field: "tinInstDt",
        sortable: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.tinInstDt) {
            return moment(params.data.tinInstDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        headerName: "Due Date",
        field: "tinDueDt",
        sortable: true,
        valueGetter: function (params) {
          if (params && params.data && params.data.tinDueDt) {
            return moment(params.data.tinDueDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
      },
      {
        headerName: "Installment %",
        field: "tinInstPerc",
        sortable: true,
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params.data && params.data.tinInstPerc) {
            return Number(params.data.tinInstPerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
      },
      {
        headerName: "Contract CCY",
        field: "tinPremCurr",
        sortable: true,
      },
      {
        headerName: "Deposit Premium",
        field: "tinDepPrem",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.tinDepPrem) {
            return Number(params.data.tinDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Accounting CCY",
        field: "tinInstCurr",
        sortable: true,
      },
      {
        headerName: "Fixed Rate",
        field: "tinFixedRate",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.tinFixedRate) {
            return Number(params.data.tinFixedRate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Prem in Accounting CCY",
        field: "tinInstFc",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.tinInstFc) {
            return Number(params.data.tinInstFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Rebate in Accounting CCY",
        field: "tinRebateFc",
        sortable: true,
        valueGetter: function (params) {
          if (params.data && params.data.tinRebateFc) {
            return Number(params.data.tinRebateFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Action",
<<<<<<< HEAD
        template:
          `<a>
                <i class="fa fa-file-pen fa-icon" data-action-type="Edit"  title="Edit" aria-hidden="true" ></i>
            </a>`,
        cellStyle: { textAlign: 'center' }
=======
        field: "ttyInstPK.tinInstNo",
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    ];
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false
    };
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
    this.getDocumentTypes();
    this.reterievePremGrid();
    this.createInstlForm();
    this.document.body.scrollTop = 10;
  }
  onClickConfirmQuote() {
    let obj = {
      refNo: this.refNo,
      amendNo: this.amendNo,
      seqNo: this.seqNo
    };
    this.treatyService.confirmQuote(obj).subscribe((result: any) => {
      if (result["messageType"] && result["messageType"] == 'E') {
        this.toastService.error(result["message"]);
        this.loaderService.isBusy = false;
      } else if (result["messageType"] && result["messageType"] == 'S') {
        this.isFreezeAndConfirm = true;
        this.loaderService.isBusy = false;
      }
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error("Somthing went wrong");
    });
  }

  toggleModal(refNo, amendNo) {
    //this.display=!this.display;
    this.refNo = refNo;
    this.amendNo = amendNo;
    this.reterievePremGrid();
  }

<<<<<<< HEAD
=======
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  reterievePremGrid() {
    let obj = {
      refNo: this.refNo,
      seqNo: this.sequenceNo,
      amendNo: this.amendNo
<<<<<<< HEAD

    }
    this.treatyService.retrievePremDetails(obj).subscribe(resp => {
=======
    };
    this.treatyService.retrievePremDetails(obj).subscribe((resp: any) => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (resp.reinsPremiumList != null && resp.reinsPremiumList.length > 0) {
        this.pinnedBottomRowData = createData(1, resp.reinsPremiumList, "Bottom");
        this.strCustPrem = resp.totCustPrem;
        this.strCustDepPrem = resp.totCustDepPrem;
        let j = 0;
        this.totalRebateAmt = 0;
        this.totalNetAmt = 0;
        this.totalDepPremium = 0;
        this.totalPremium = 0;
        this.details = resp.reinsPremiumList.map((prem) => {
          prem.id = j++;
          return prem;
        });
        for (var i = 0; i < this.details.length; i++) {
          this.totalPremium = this.totalPremium + this.details[i].strCustPrem;
          this.totalDepPremium = this.totalDepPremium + this.details[i].strCustDepPrem;
          this.totalRebateAmt = this.totalRebateAmt + this.details[i].strRebateAmt;
          this.totalNetAmt = this.totalNetAmt + this.details[i].strCustDepNetPrem;
        }
        this.reinsurerSummaryDetails();
        if (this.details.length) {
          this.componentParent.selectedRowId = this.details[0].id;
          this.selectedRowData({ data: this.details[0] });
        }
      } else {
        this.details = resp.reinsPremiumList;
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.details = [];
      this.loaderService.isBusy = false;
    })
  }

  reinsurerSummaryDetails() {
    this.bottomData = [
      {
        select: 'Total',
        // custName: '',
        // accToDesc: '',
        strCustPrem: this.totalPremium,
        strCustDepPrem: this.totalDepPremium,
        strRebatePerc: '',
        strRebateAmt: this.totalRebateAmt,
        strCustDepNetPrem: this.totalNetAmt,
        action: '',
      }
    ];
  }
  viewLayer(data: any) {
    //this.isShowLayer=true;
    this.loaderService.isBusy = true;
    this.treatyService.retrieveLayerDetails(data).subscribe(resp => {
      this.totstlPrem = resp.reinsLayerList[0].totStlPrm;
      this.totStlDepPrm = resp.reinsLayerList[0].totStlDepPrm;
      this.totCustPrm = resp.reinsLayerList[0].totCustPrm;
      this.totCustdepPrm = resp.reinsLayerList[0].totCustdepPrm;
      this.custName = data.custName
      this.layerDetails = resp.reinsLayerList;
      // this.display = !this.display;
      this.loaderService.isBusy = false;
<<<<<<< HEAD
      this.open(this.contents, 'modal-md');

=======
      this.openDialog(this.contents, 'modal-lg')
      //this.open(this.contents, 'modal-lg');
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }, error => {
      this.loaderService.isBusy = false;
    })


  }

  showInstalment(data: any) {
    this.refNo = data.ttyReinsPremPK.strRefNo;
    this.amendNo = data.ttyReinsPremPK.strAmendNo;
    this.customer = data.ttyReinsPremPK.strCustomer;
    this.currencyCode = data.ttyReinsPremPK.strPremCurr;
    this.totcustDep = data.strCustDepPrem;
    this.isShowLayer = false;
    this.showInstlment = true;
    this.custName = data.custName;
    this.noOfInst = data.strNoOfInst;
    this.WarrDays = data.strWarrDays;
    this.reterieveReInstDetails();
  }
  setWarentyDays(days) {
    this.WarrDays = days;
  }
  setInstallmentNo(no) {
    this.noOfInst = no;
  }
  applyInstl() {

    if (this.noOfInst != '') {
      let obj = {
        refNo: this.refNo,
        seqNo: this.sequenceNo,
        amendNo: this.amendNo,
        customer: this.customer,
        company: this.session.get('companyCode'),
        division: this.session.get('userDivnCode'),
        userId: this.session.get('userId'),
        noOfInst: this.noOfInst,
        warDays: this.WarrDays
      }
      this.loaderService.isBusy = true;
      this.treatyService.retrieveInstPro(obj, this.amndSrNo).subscribe(resp => {
        // this.loadCurrList();
        this.reterieveReInstDetails();
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
      })
    }
    else {
      this.toastService.warning('Enter No Of Instalment');
    }
  }

  reterieveReInstDetails() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amendNo: this.amendNo,
      customer: this.customer,
      seqNo: this.sequenceNo
    }
    this.treatyService.reterieveReInst(obj).subscribe(resp => {
      //this.searchselectscript();
      this.reInstDetails = resp.instDetailsList;
      this.loaderService.isBusy = false;
      this.showReinst = true;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  changePerc(event: any) {
    let perc = event.target.value;
    let value = (this.totcustDep * perc) / 100;
    this.instlFrm.get('tinDepPrem').setValue(value);
    this.instlFrm.get('tinInstFc').setValue(value);

  }
  //  saveInstl(){
  //    if(this.custDeposit==this.reInstDetails[0].totDepositPremium)
  //    {
  //   this.treatyService.updateInstlment(this.reInstDetails).subscribe(resp=>{

  //   })
  //    }else{
  //      this.toastService.error('Total Premium Not Match' );
  //    }
  //  }

  loadCurrList() {
    this.loaderService.isBusy = true;
    this.treatyService.retrievecurrencyList().subscribe(resp => {
      this.currencyList = resp.currencyList;
      this.searchselectscript();
      this.loaderService.isBusy = false;
    })
  }

  nextStep() {
    this.wizardHelper.goNext();
  }
  previousStep() {
    this.wizardHelper.goPrevious();
  }
  minDate: any;
  editInstl(data: any) {
    this.instlFrm.reset();
    let obj = {
      tinInstNo: data.ttyInstPK.tinInstNo,
      tinRefNo: this.refNo,
      tinAmendNo: this.amendNo,
      tinCustomer: this.customer,
      tinSeqNo: this.sequenceNo,
    }
    this.treatyService.reterieveInstlById(obj).subscribe(resp => {
      this.readonly = true;
      this.instlDetails = resp.instDetailsList;
      this.showForm = true;
      this.loadCurrList();

      let dueDate = this.datePipe.transform(new Date(this.instlDetails[0].tinDueDt), ApiUrls.DATE_FORMAT).split("-");
      let instlDate = this.datePipe.transform(new Date(this.instlDetails[0].tinInstDt), ApiUrls.DATE_FORMAT).split("-");
      let year = instlDate[0];
      var month = instlDate[1];
      let day = instlDate[2];

      let dueyear = dueDate[0];
      var duemonth = dueDate[1];
      let dueday = dueDate[2];
<<<<<<< HEAD

=======
      this.minDate = new Date(this.instlDetails[0].tinInstDt);
      console.log(year, month, day)
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.instlFrm.patchValue({
        tinRefNo: this.instlDetails[0].ttyInstPK.tinRefNo,
        tinAmendNo: this.instlDetails[0].ttyInstPK.tinAmendNo,
        tinInstType: this.instlDetails[0].ttyInstPK.tinInstType,
        tinCustomer: this.instlDetails[0].ttyInstPK.tinCustomer,
        tinInstNo: this.instlDetails[0].ttyInstPK.tinInstNo,
        tinInstDt: this.datePipe.transform(this.instlDetails[0].tinInstDt, ApiUrls.DATE_FORMAT),
        tinDueDt: this.datePipe.transform(this.instlDetails[0].tinDueDt, ApiUrls.DATE_FORMAT),
        tinInstPerc: this.instlDetails[0].tinInstPerc,
        tinPremCurr: this.instlDetails[0].tinPremCurr,
        tinDepPrem: this.instlDetails[0].tinDepPrem,
        tinInstCurr: this.instlDetails[0].tinInstCurr,
        tinFixedRate: this.instlDetails[0].tinFixedRate,
        tinInstFc: this.instlDetails[0].tinInstFc,
        tinCrDt: this.instlDetails[0].tinCrDt,
        tinCrUid: this.instlDetails[0].tinCrUid,
        tinInstLc1: this.instlDetails[0].tinInstLc1,
        tinInstLc2: this.instlDetails[0].tinInstLc2,
        tinInstLc3: this.instlDetails[0].tinInstLc3,
        tinStatus: this.instlDetails[0].tinStatus,
        tinRebateFc: this.instlDetails[0].tinRebateFc,
        tinRebateAmt: this.instlDetails[0].tinRebateAmt,
        tinRebateLc1: this.instlDetails[0].tinRebateLc1,
        tinRebateLc2: this.instlDetails[0].tinRebateLc2,
        tinRebateLc3: this.instlDetails[0].tinRebateLc3,
        tinRebatePerc: this.instlDetails[0].tinRebatePerc
      })
    }, error => { });
  }


  createInstlForm() {
    this.instlFrm = this.fb.group({
      tinRefNo: '',
      tinAmendNo: '',
      tinInstType: '',
      tinCustomer: '',
      tinInstNo: '',
      tinInstDt: ['', Validators.required],
      tinDueDt: ['', Validators.required],
      tinInstPerc: '',
      tinPremCurr: ['', Validators.required],
      tinDepPrem: ['', Validators.required],
      tinInstCurr: ['', Validators.required],
      tinFixedRate: '',
      tinInstFc: ['', Validators.required],
      tinStatus: '',
      tinCrUid: this.session.get('userId'),
      tinCrDt: '',
      tinInstLc1: '',
      tinInstLc2: '',
      tinInstLc3: '',
      tinUpdDt: '',
      ttyInstPK: '',
      tinRebateFc: undefined,
      tinRebateAmt: undefined,
      tinRebateLc1: undefined,
      tinRebateLc2: undefined,
      tinRebateLc3: undefined,
      tinRebatePerc: undefined
    })
  }

  updateInstlment() {
    if (this.instlFrm.valid) {
      var depPremval = this.instlFrm.get('tinDepPrem').value;
      var instFC = this.instlFrm.get('tinInstFc').value
      if (depPremval) {
        if (typeof depPremval === 'string') {
          this.instlFrm.get('tinDepPrem').value.replace(/,/g, '');
        } else { }
      } else { depPremval = 0 }

      if (instFC) {
        if (typeof instFC === 'string') {
          this.instlFrm.get('tinInstFc').value.replace(/,/g, '')
        } else { }
      } else { instFC = 0 }

      let objPk = {
        tinSeqNo: this.sequenceNo,
        tinRefNo: this.instlFrm.get('tinRefNo').value,
        tinAmendNo: this.instlFrm.get('tinAmendNo').value,
        tinInstType: this.instlFrm.get('tinInstType').value,
        tinCustomer: this.instlFrm.get('tinCustomer').value,
        tinInstNo: this.instlFrm.get('tinInstNo').value,
      }
      const instlData = this.instlFrm.value;
      instlData.ttyInstPK = objPk
      instlData.tinInstDt = moment(this.instlFrm.get("tinInstDt").value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      instlData.tinDueDt = moment(this.instlFrm.get("tinDueDt").value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      instlData.tinInstFc = instFC
      instlData.tinDepPrem = depPremval
      this.treatyService.updateInstlment(instlData, this.amndSrNo).subscribe(resp => {
        this.close();
        this.toastService.success('Updated Successfully');
        this.reterieveReInstDetails();
      })
    } else {
      this.validateAllFormFields(this.instlFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  changeCurrency(event: any) {
    let curr = event.value;
    let params = {
      fromcurr: this.instlFrm.get('tinPremCurr').value,
      tocurr: curr,
      fromamount: this.instlFrm.get('tinDepPrem').value
    }
    this.treatyService.currConverstaion(params).subscribe(resp => {
      this.instlFrm.get('tinInstFc').setValue(resp.convrtCurr);
    })
  }

  premiumrate(event) {
    let val = event.target.value * this.instlFrm.get('tinDepPrem').value;
    this.instlFrm.get('tinInstFc').setValue(val);
  }

  close() {
    this.showForm = false;
    this.readonly = false;
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
=======
      console.log(field + ":" + control.status);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  searchselectscript() {

    // $('.selectpicker').selectpicker();
    // setTimeout(() => {

    // $('.selectpicker').selectpicker('refresh');
    // },500);
  }
  // selectedRowData(params) {
  //   this.selectedRowData = params.data.id;
  //   this.setSelectedValue({target:{checked: true}}, params.data);

  // } 
  setSelectedValue(event, detail) {
    this.readonly = false;
    if (event.target.checked) {
      this.selectedId = detail;
      this.showInstalment(this.selectedId);
    }
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params, gridName: any) {
    if (gridName === 'summary') {
      this.summaryGridApi = params.api;
    } else if (gridName === 'installment') {
      this.instGridApi = params.api;
    } else if (gridName === 'viewlayer') {
      this.layerGridApi = params.api;
    }
    params.api.sizeColumnsToFit();

  }
  displayedSummayRowCount() {
    if (this.summaryGridApi) {
      return this.summaryGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  displayedInstRowCount() {
    if (this.instGridApi) {
      return this.instGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  displayedLayerRowCount() {
    if (this.layerGridApi) {
      return this.layerGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  agGridOptions() {
    this.context = this;
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent,
      // genderCellRenderer: GenderCellRenderer
    };
  }
  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    // alert(gridApi);
    gridApi.setQuickFilter(qickSearch);
  }
  onBtExport(gridApi: any) {
    if (gridApi) {
      gridApi.exportDataAsExcel({
        columnKeys: ['custName', 'accToDesc', 'ttyReinsPremPK.strPremCurr', 'strCustPrem', 'strCustDepPrem', 'strRebatePerc', 'strRebateAmt', 'strCustDepNetPrem'],
        processCellCallback: (params) => {
          if (params.column.colId == "strCustPrem" || params.column.colId == "strCustDepPrem"
            || params.column.colId == "strRebatePerc" || params.column.colId == "strRebateAmt" || params.column.colId == "strCustDepNetPrem") {
            if (params && params.value) {
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          } else {
            return params.value;
          }
        }
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
  }

  selectedRowData(cell) {
    let detail = cell.data;
    this.readonly = false;
    this.selectedId = detail;
    this.showInstalment(this.selectedId);
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "View":
          return this.viewLayer(data);
        case "Edit":
          return this.editInstl(data);
        case "EditRebate":
          this.rebateForm.reset();
          this.rebateForm.patchValue(data);
          this.rebateCustomer = data.ttyReinsPremPK.strCustomer + '-' + this.rebateForm.get('custName').value
<<<<<<< HEAD
=======
          console.log('selected Rebate ----- ', this.rebateForm.getRawValue())
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          return this.openDialog(this.rebatecontent, 'modal-md')
      }
    }

  }
  closeModal() {
    this.modalService.hide();
  }
  public onRowReinsurTwoClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.editInstl(data);
        // case "Remove":
        // return this.showDialogbox(data);
      }
    }
  }

  approveBlock() {
    this.open(this.approveContent, 'modal-sm');
  }
  confirmationBlock() {
<<<<<<< HEAD
    this.open(this.confirmation, 'modal-sm');
=======
    this.open(this.confirmContent, 'modal-sm');
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  getDocumentTypes() {
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res.appcodeList;
      }, err => {
      });
  }
  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }

  onCellValueChanged(params) {
  }
  openDialog(content, val) {
    this.open(content, val);
  }
  updateRebate() {
<<<<<<< HEAD
    var data = this.rebateForm.getRawValue();
    this.treatyService.updateRebate(data).subscribe(resp => {
      this.reterievePremGrid();
      this.modalService.hide();
      this.toastService.success(resp.message);
    }, err => {
      this.toastService.error('Error in Updating Rebate');
    });
=======
    if (this.rebateForm.valid) {
      var data = this.rebateForm.getRawValue();
      console.log('rebateForm ---', data)
      this.treatyService.updateRebate(data).subscribe(resp => {
        this.reterievePremGrid();
        this.modalService.hide();
        this.toastService.success(resp.message);
      }, err => {
        this.toastService.error('Error in Updating Rebate');
      });
    } else {
      this.validateAllFormFields(this.rebateForm);
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  rebateCalc() {
    var rebateAmt = 0;
    var rebatePerc = 0;
    var reinsDepPrem = 0;
    var netAmt = 0;
    rebateAmt = 0;
    rebatePerc = parseFloat(this.rebateForm.get('strRebatePerc').value);
    reinsDepPrem = parseFloat(this.rebateForm.get('strCustDepPrem').value);
    rebateAmt = (reinsDepPrem * rebatePerc) / 100;
    netAmt = reinsDepPrem - rebateAmt
    this.rebateForm.patchValue({
      // strRebatePerc:rebatePerc,
      strRebateAmt: rebateAmt.toFixed(5)
    });

  }
<<<<<<< HEAD
  closeModal() {
    this.modalService.hide();
=======

  removeNegative(event) {
    var k;
    k = event.keyCode;
    // console.log(k);
    if (k == 189 || k == 187 || k == 107 || k == 109) {
      return false;
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
}


function numberFormatter(params) {
  return params.value.toFixed(2);
}
function dateFormatter(params) {
  return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
}
function currencyFormatter(params) {
  if (params.value != null && params.value != 'null') {
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');//Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value.toFixed(2)));
  } else {
    return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  }
}
function createData(count, data, prefix) {
  var result = [];
  let sum100Prem = 0;
  let sumDepPrem = 0;
  for (var i = 0; i < data.length; i++) {
    sum100Prem = sum100Prem + data[i].strCustPrem;
    sumDepPrem = sumDepPrem + data[i].strCustDepPrem;
  }
  for (var i = 0; i < count; i++) {
    result.push({
      accToDesc: 'Total',
      strCustPrem: sum100Prem,
      strCustDepPrem: sumDepPrem,
    });
  }
  return result;
}
function netAmountCalc(params) {
  // var context = this;
  if (params.data.strCustDepPrem != null && params.data.strRebateAmt != null) {
    // context.totalNetAmt = params.data.strCustDepPrem - params.data.strRebateAmt;
    return params.data.strCustDepPrem - params.data.strRebateAmt;
  } else if (params.data.strCustDepPrem != null && params.data.strRebateAmt == null) {
    // context.totalNetAmt = params.data.strCustDepPrem;
    return params.data.strCustDepPrem;
  } else {
    return '';
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
              <i class="fa fa-file-pen fa-icon" data-action-type="Edit"  title="Edit" aria-hidden="true" ></i>
            </a>`;
  }
}