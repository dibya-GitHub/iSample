import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReinsurePremiumComponent } from './reinsure-premium.component';

describe('ReinsurePremiumComponent', () => {
  let component: ReinsurePremiumComponent;
  let fixture: ComponentFixture<ReinsurePremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReinsurePremiumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReinsurePremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
