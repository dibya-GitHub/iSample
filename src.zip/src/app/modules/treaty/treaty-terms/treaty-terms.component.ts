<<<<<<< HEAD
import { HttpErrorResponse } from '@angular/common/http';
import { Utils } from './../../../utils';
import { Component, ElementRef, Input, OnInit, TemplateRef, ViewChild, SimpleChanges } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { zip } from 'rxjs';
=======
import { Component, OnInit, Inject, Input, ViewChild, ElementRef } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { ApiUrls } from 'src/app/api-urls';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { NumericEditorComponent } from './numeric-editor.component';
import * as moment from 'moment';
import * as _ from 'lodash';

declare var $: any;

@Component({
  selector: 'app-treaty-terms',
  templateUrl: './treaty-terms.component.html',
  styleUrls: ['./treaty-terms.component.css']
})
export class TreatyTermsComponent implements OnInit {
  treatyTermsForm: UntypedFormGroup;
  SSCForm: UntypedFormGroup;
  slidingScaleRateForm: UntypedFormGroup;
  fixedCommissionForm: UntypedFormGroup;
  profitCommForm: UntypedFormGroup;
  premiumReserveForm: UntypedFormGroup;
  items: UntypedFormArray;

  addFlag: boolean = true;
  gridApi: any;
  sscGridApi: any;
  public columnTermsDefs;
  public columnSSCDefs;
  public columnProfitCommDefs;
  public columnPreReserveDefs;

  public defaultColDef;
  public getRowHeight;
  public rowTermsData = [];
  public rowSSCData = [];
  public rowProfitCommData = [];
  public rowPreReserveData = [];
  quickSearchValue: string = '';

  showTermsFlag: boolean = false;
  closeResult: string;
<<<<<<< HEAD
=======
  treatyTermsForm: UntypedFormGroup;
  selectedTermsData = [];
  selectedTermsPercentageOn = [];
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  @Input() seqNo: any;
  @Input() refNo: any;
  @Input() amendNo: any;
  @Input() amndSrNo: any;
  @Input() action: any;
  @Input() layer: any;
  @Input() layerPriority: any;
  @Input() layerReinsurer: any;
  tmId: any;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  temp: any;
<<<<<<< HEAD

  termsCode: any;
  termsType: any;
  termsCalcType: any;
  termsComm: any;
  scaleComm: any;
  profitComm: any;
  pcData: any;
  bankTypeLists: any;
  disableAddrow: boolean = false;

  deleteIndex: any;
  index: any;
  modalRef: BsModalRef;
  freqList: any;
  hideApplicableRate: boolean = false;
  lossRatioSSC: any = [];
  userId = this.session.get('userId');
  slidingScaleRateList: any = [];
  public columnDefsSSC;
  tmSrNoSSC: any;
  tmSrNoSlidingRate: any;
  tmSrNoPC: any;

  tadSrNoPr: any;
  fixedCommissionList: any = [];
  tmSrNoFC: any;
  items_fc: UntypedFormArray;
  minDate: any;
  maxDate: any;
  premMethodList: any;
  disableAddrowFC: boolean = false;
  infoLoading: boolean = false;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  reins;
=======
  modalRef: BsModalRef;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
<<<<<<< HEAD
    private modalService: BsModalService,
    private modService: BsModalService
=======
    private modalService: BsModalService
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) {
    this.columnTermsDefs = [
      {
        headerName: "Sr no",
        field: "tmReins",
        cellStyle: { textAlign: 'center' },
        width: 100,
      },
      {
        headerName: "Term",
        field: "tmCommCodeDesc",
      },
      {
        headerName: "Receivables / Payables Type",
        field: "tmRecPayTypeDesc",
      },
      {
        headerName: "Calculation Type",
        field: "tmCalcTypeDesc",
      },
      {
        headerName: "Percentage",
        field: "tmCommPerc",
        sortable: true,
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter
      },
      {
        headerName: "Amount",
        field: "tmAmt",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      },
      {
        headerName: "Action",
        cellStyle: { textAlign: 'center' },
        width: 150,
        filter: false,
        sortable: false,
        enableRowGroup: false,
        template:
          `<a>
<<<<<<< HEAD
          <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
         </a>&nbsp;
         <a>
          <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
         </a>`
      },
    ];
    this.columnDefsSSC = [
      {
        headerName: "Loss Ratio From",
        headerTooltip: "Loss Ratio From",
        field: "tsMinLrPerc",
        width: 210,
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
        editable: true,
        cellEditorFramework: NumericEditorComponent,
      },
      {
        headerName: "Loss Ratio To",
        headerTooltip: "Loss Ratio To",
        field: "tsMaxLrPerc",
        width: 210,
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
        editable: true,
        cellEditorFramework: NumericEditorComponent,
      },
      {
        headerName: "Applicable Commission",
        headerTooltip: "Applicable Commission",
        field: "tsCommPerc",
        width: 210,
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
        editable: true,
        cellEditorFramework: NumericEditorComponent,
      },
      {
        headerName: "Action",
        cellStyle: { textAlign: 'center' },
        cellRenderer: actionCellRenderer,
        editable: false,
        colId: "action"
=======
              <i class="fa fa-file-pen" data-action-type="Edit"  title="Edit" aria-hidden="true" ></i>
              <i class="fa fa-trash fa-icon fa-danger" data-action-type="Remove"  title="Delete" aria-hidden="true"></i>
          </a>`
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    ];
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 100;
      } else {
        return 35;
      }
    };
  }
  ngOnChanges(changes: SimpleChanges): void {
    let change: any = changes;
    if (change.layerReinsurer) {
      this.onTreatyTermsGridReady();
      this.getTermSSCgridData();
      this.onTreatyProfitComm();
      let item = (this.fixedCommissionForm.get('items_fc') as UntypedFormArray)
      while (item.value.length != 0) {
        item.removeAt(0)
      }
      this.getAllFixedComm();
    }

  }
  ngOnInit() {
    this.layerPriority = (typeof (this.layerPriority) == 'object') ? this.layerPriority.tlPriority : this.layerPriority;
    console.log(this.layerPriority)
    console.log("layer: "+this.layerReinsurer)

    this.treatyTermsForm = this.fb.group({
      tmCommCode: [undefined, Validators.required],
      tmCommPerc: [''],
      tmRecPayType: [undefined, Validators.required],
      tmCalcType: [undefined, Validators.required],
      tmAmt: [''],
      tmFcYn:''
    })

    this.SSCForm = this.fb.group({
      tmSscProv: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      tmSscEvlFrq: [undefined, Validators.required],
      tmSscFirstEvlDt: [undefined, Validators.required],
      tmSscLastEvlDt: [undefined],
    })
    this.slidingScaleRateForm = this.fb.group({
      tmSscMinLr: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      tmSscMaxLr: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      tmSscLrDiff: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      tmSscMinComm: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      tmSscMaxComm: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      tmSscCommDiff: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
    }, {
      validator: [this.graterValidator("tmSscMinLr", "tmSscMaxLr"), this.graterValidator("tmSscMinComm", "tmSscMaxComm")]
    })
    this.profitCommForm = this.fb.group({
      tmPcFirstEvlDt: [undefined, Validators.required],
      tmPcEvlFrq: [undefined, Validators.required],
      tmPcLastEvlDt: [undefined, Validators.required],
      tmPcMePerc: [undefined, Validators.required],
      tmPcFirstCashEvlDt: [undefined, Validators.required],
    })
    this.premiumReserveForm = this.fb.group({
      tadPwResPerc: [undefined, Validators.required],
      tadPwIntPerc: [undefined, Validators.required],
      tadPwResRel: [undefined, Validators.required],
      tadPwProcFreq: [undefined, Validators.required],
      tadBnkIntReq: [undefined],
      tadRiExpPerc: [undefined],
      tadBnkCurr: [undefined, Validators.required],
    })
    this.onTreatyTermsGridReady();
    this.getTermsData();
    this.createFCTable();
    this.reins = this.layerReinsurer.trReins;
  }

  createFCTable() {
    this.fixedCommissionForm = this.fb.group({
      tmRemarks: [undefined],
      tmBasedOn: [undefined],
      tmCommPerc: [undefined],
      tmEffFmDt: [undefined, Validators.required],
      tmEffToDt: [undefined],
      tmStatus: [undefined],
      tmId: [undefined],
      items_fc: this.fb.array([])
    })
    this.treatyService.getCoinPrmMtd().subscribe(resp => {
      this.premMethodList = resp;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
    this.getAllFixedComm();
  }
  getAllFixedComm(action?: string) {
    this.infoLoading = true;
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.layerReinsurer.trReins
    };
    this.treatyService.getAllFixedComm(obj, 'FC').subscribe((resp: any) => {
      this.fixedCommissionList = resp.termCommList;
      if (this.fixedCommissionList.length) {
        for (let i = 0; i < this.fixedCommissionList.length; i++) {
          this.fixedCommissionList[i].edited = true;
          this.fixedCommissionList[i].tmEffFmDt = (this.fixedCommissionList[i].tmEffFmDt == null) ? "" : new Date(this.fixedCommissionList[i].tmEffFmDt);
          this.fixedCommissionList[i].tmEffToDt = (this.fixedCommissionList[i].tmEffToDt == null) ? "" : new Date(this.fixedCommissionList[i].tmEffToDt);
          if (action != 'save') {
            this.addItem_FC();
          }
          (this.fixedCommissionForm.get('items_fc') as UntypedFormArray)
            .at(i)
            .get('tmId').setValue(this.fixedCommissionList[i].tmId, { emitEvent: true });
          this.fixedCommissionForm.patchValue({
            items_fc: this.fixedCommissionList
          })
        }
      } else {
        let item = (this.fixedCommissionForm.get('items_coins') as UntypedFormArray);
        while (item.value.length != 0) {
          item.removeAt(0)
        }
      }
      this.infoLoading = false;
      this.loaderService.isBusy = false;
    }, error => {
      this.infoLoading = false;
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }
  addItem_FC(): void {
    this.items_fc = this.fixedCommissionForm.get('items_fc') as UntypedFormArray;
    if (_.size(this.items_fc) > 0) {
      var size = _.size(this.items_fc) - 1;
      this.items_fc.push(
        this.createItemFC()
      );
      setTimeout(() => {
        for (let i = 0; i < this.items_fc.value.length; i++) {
          if (this.items_fc.value[i].edited == false) {
            this.disableAddrowFC = true;
          } else {
            this.disableAddrowFC = false;
          }
        }
      }, 100);
    } else {
      this.items_fc.push(this.createItemFC(this.minDate, this.maxDate));
      setTimeout(() => {
        for (let i = 0; i < this.items_fc.value.length; i++) {
          if (this.items_fc.value[i].edited == false) {
            this.disableAddrowFC = true;
          } else {
            this.disableAddrowFC = false;
          }
        }
      }, 100);
    }
  }
  createItemFC(date?: any, endDate?: any): UntypedFormGroup {
    return this.fb.group({
      tmRemarks: [undefined],
      tmBasedOn: [undefined, Validators.required],
      tmCommPerc: [undefined, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
      tmEffFmDt: [date, Validators.required],
      tmEffToDt: [endDate],
      tmStatus: [''],
      tmId: undefined,
      edited: false,
    }
      , {
        validator: [this.dateValidators("tmEffFmDt", "tmEffToDt")]
      }
    );
  }
  dateValidators(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group['controls'][firstKey];
      const second = group['controls'][secondKey];
      const message = "Should be in Contract Period";
      const message1 = "Must be greater than Eff From Date";
      if (first.value && first.value < this.minDate || first.value > this.maxDate) {
        first.setErrors({ dateValidator: message });
        return { dateValidator: true };
      }
      if (second.value && second.value < first.value) {
        second.setErrors({ dateValidator: message1 });
        return { dateValidator: true };
      } else {
        second.setErrors(null);
      }
    };
  }

  saveFCForm(item, action, formName) {
    this.loaderService.isBusy = true;
    if (formName == 'fixedComm') {
      if (item.valid) {
        let formData = item.value;
        if (action == 'save') {
          let obj = {
            tmAmendNo: this.amendNo,
            tmRefNo: this.refNo,
            tmSeqNo: this.seqNo,
            tmCrDt: new Date(),
            tmCrUid: this.userId,
            tmUpdDt: new Date(),
            tmUpdUid: this.userId,
            tmStatus: 'P',
            tmFlex01: "RITERMS",
            tmLayer: this.layerReinsurer.trLayer,
            tmReins: this.layerReinsurer.trReins,
            tmBroker: this.layerReinsurer.trBroker,
            tmCommCode: "56",
            tmFcYn: 'Y'
          };

          Object.assign(formData, obj);
          formData = Utils.clean(formData);
          console.log(formData);

          this.treatyService.saveTreatyTermsComm(formData, this.amndSrNo).subscribe((resp: any) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Saved');
              this.getAllFixedComm('save');
              this.disableAddrowFC = false;
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in upload!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    // this.showErrorDialogBox(error.error.message);
                    this.toastService.error(error.error.message);
                    this.decline();
                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in upload!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in upload!");
            }
          })
        } else {
          let formData = item.value;
          let obj = {
            tmAmendNo: this.amendNo,
            tmRefNo: this.refNo,
            tmSeqNo: this.seqNo,
            tmCrDt: new Date(),
            tmCrUid: this.userId,
            tmUpdDt: new Date(),
            tmUpdUid: this.userId,
            tmStatus: 'P',
            tmFlex01: "RITERMS",
            tmLayer: this.layerReinsurer.trLayer,
            tmReins: this.layerReinsurer.trReins,
            tmBroker: this.layerReinsurer.trBroker,
            tmCommCode: "56",
            tmFcYn: 'Y',
            tmId: formData.tmId,

          };
          Object.assign(formData, obj);

          formData = Utils.clean(formData);
          console.log(formData);

          this.treatyService.updateTreatyTermsComm(formData, this.amndSrNo).subscribe((resp: any) => {
            if (resp.messageType == 'S') {
              this.toastService.success('Successfully Updated');
              this.getAllFixedComm('save');
              this.loaderService.isBusy = false;
            } else if (resp.messageType == 'U') {
              this.loaderService.isBusy = false;
              this.toastService.success(resp.message);
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error(resp.message);
            }
          }, error => {
            if (error instanceof HttpErrorResponse) {
              if (error.error instanceof ErrorEvent) {
                this.loaderService.isBusy = false;
                this.toastService.error("Error in Updating!");
              } else {
                switch (error.status) {
                  case 400:
                    this.loaderService.isBusy = false;
                    // this.showErrorDialogBox(error.error.message);
                    this.toastService.error(error.error.message);

                    break;
                  default:
                    this.loaderService.isBusy = false;
                    this.toastService.error("Error in Updating!");
                    break;
                }
              }
            } else {
              this.loaderService.isBusy = false;
              this.toastService.error("Error in Updating!");
            }
          })
        }
      } else {
        this.validateAllFormFields(item);
        this.toastService.warning('Enter mandatory fields');
        this.loaderService.isBusy = false;
      }
    }
  }


  ConfirmDefault() {
    if (this.fixedCommissionForm.value['items_fc'].length !== 0) {
      this.loaderService.isBusy = true;
      // this.mgaService.defaultAllTermsButton(this.refNo, this.seqNo, this.amendNo, this.lobInfo.bpLobCode, this.lobSrNo, this.lobInfo.bpCompCode).subscribe(res => {
      //   this.toastService.success('updated successfully');
      //   this.loaderService.isBusy = false;
      //   this.modalRef.hide();
      // })
    } else {
      this.toastService.warning('Add Data in Commission')
    }
  }
  createItem(data?: any): UntypedFormGroup {
    return this.fb.group({
      tsMinLrPerc: [undefined, Validators.required],
      tsMaxLrPerc: [undefined, Validators.required],
      tsCommPerc: [undefined, Validators.required],
      edited: false,
      tsId: undefined,
    }, {
      validator: [this.graterValidator("tsMinLrPerc", "tsMaxLrPerc")]
    });
  }

  onChangeCalcType(evnt) {
    let key = evnt.value;
    this.treatyTermsForm.get('tmCommPerc').enable();
    if (key == '01') {
      // this.treatyTermsForm.get('tmCommPerc').setValue(null);
      // this.treatyTermsForm.get('tmCommPerc').disable();
      this.treatyTermsForm.get('tmAmt').enable();
    } else if (key == '02') {
      this.treatyTermsForm.get('tmAmt').setValue(null);
      this.treatyTermsForm.get('tmAmt').disable();
    }
    
  }
  getTermSSCgridData(action?: any) {
    this.scaleComm = [];
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.layerReinsurer.trReins
    };
    this.treatyService.getSlidingScaleComm(obj, 'SSC').subscribe((resp: any) => {
      this.scaleComm = resp.termCommList;

      if (this.scaleComm.length > 0) {
        this.tmSrNoSSC = this.scaleComm[0].tmId;
        this.SSCForm.patchValue({
          tmSscProv: this.scaleComm[0].tmSscProv,
          tmSscEvlFrq: this.scaleComm[0].tmSscEvlFrq,
          tmSscFirstEvlDt: moment(this.scaleComm[0].tmSscFirstEvlDt).format('DD/MM/YYYY'),
          tmSscLastEvlDt: (this.scaleComm[0].tmSscLastEvlDt == null) ? "" : moment(this.scaleComm[0].tmSscLastEvlDt).format('DD/MM/YYYY'),
        })
      } else {
        this.tmSrNoSSC = 0;
        this.SSCForm.reset();
      }
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
    this.treatyService.getSlidingScaleLossRatioComm(obj, 'SSC').subscribe((resp: any) => {
      this.lossRatioSSC = resp.lrCommList;
      if (this.lossRatioSSC.length > 0) {
        this.tmSrNoSlidingRate = this.lossRatioSSC[0].tmId;
        this.slidingScaleRateForm.patchValue({
          tmSscMinLr: this.lossRatioSSC[0].tmSscMinLr,
          tmSscMaxLr: this.lossRatioSSC[0].tmSscMaxLr,
          tmSscLrDiff: this.lossRatioSSC[0].tmSscLrDiff,
          tmSscMinComm: this.lossRatioSSC[0].tmSscMinComm,
          tmSscMaxComm: this.lossRatioSSC[0].tmSscMaxComm,
          tmSscCommDiff: this.lossRatioSSC[0].tmSscCommDiff,
        })
        this.getSlidingScaleLossRatioList();
      } else {
        this.tmSrNoSlidingRate = 0;
        if (action != 'save') {
          this.slidingScaleRateForm.reset();
        }
        this.slidingScaleRateList = [];
      }
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });

    this.treatyService.getSlidingScaleComm(obj, 'PC').subscribe((resp: any) => {
      this.pcData = resp.termCommList;

      if (this.pcData.length > 0) {
        this.tmSrNoPC = this.pcData[0].tmId;
        this.profitCommForm.patchValue({
          tmPcFirstEvlDt: moment(this.pcData[0].tmPcFirstEvlDt).format('DD/MM/YYYY'),
          tmPcLastEvlDt: moment(this.pcData[0].tmPcLastEvlDt).format('DD/MM/YYYY'),
          tmPcFirstCashEvlDt: moment(this.pcData[0].tmPcFirstCashEvlDt).format('DD/MM/YYYY'),
          tmPcEvlFrq: this.pcData[0].tmPcEvlFrq,
          tmPcMePerc: this.pcData[0].tmPcMePerc,
        })
      } else {
        this.tmSrNoPC = 0;
        this.profitCommForm.reset();
      }
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }

  getTermsData() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.layerReinsurer.trReins
    };
    console.log(this.layerPriority);
    this.layerPriority = (typeof (this.layerPriority) == 'object') ? this.layerPriority.tlPriority : this.layerPriority;
    zip(
      this.treatyService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT'),
      this.treatyService.retrieveBankType('TTY_BNK_CUR'),
      this.treatyService.getTreatyTermsCode(),
      this.treatyService.getTreatyTermsType(),
      this.treatyService.getTreatyTermsCalcType(),
      this.treatyService.getTreatyTermsComm(this.layerPriority, obj),
      this.treatyService.getSlidingScaleComm(obj, 'SSC'),
      this.treatyService.getSlidingScaleComm(obj, 'PC'),
      this.treatyService.getSlidingScaleLossRatioComm(obj, 'SSC'),
      this.treatyService.getTreatyProfitComm(this.layerPriority, obj),
    ).subscribe(([freqList, bankTypeLists, termsCode, termsType, termsCalcType, termsComm, scaleComm, pcData, lossComm, profitComm]: any[]) => {
      this.freqList = freqList,
        this.bankTypeLists = bankTypeLists.appcodeList,
        this.termsCode = termsCode;
      this.termsType = termsType.appcodeList;
      this.termsCalcType = termsCalcType.appcodeList;
      this.termsComm = termsComm;
      this.scaleComm = scaleComm.termCommList;
      this.pcData = pcData.termCommList;
      this.lossRatioSSC = lossComm.lrCommList;
      this.profitComm = profitComm;
      this.loaderService.isBusy = false;
      // if (this.profitComm.length > 0) {
      //   this.profitComm = this.profitComm[this.profitComm.length - 1];
      // }
      console.log(this.scaleComm);

      if (this.scaleComm.length > 0) {
        this.tmSrNoSSC = this.scaleComm[0].tmId;
        this.SSCForm.patchValue({
          tmSscProv: this.scaleComm[0].tmSscProv,
          tmSscEvlFrq: this.scaleComm[0].tmSscEvlFrq,
          tmSscFirstEvlDt: moment(this.scaleComm[0].tmSscFirstEvlDt).format('DD/MM/YYYY'),
          tmSscLastEvlDt: (this.scaleComm[0].tmSscLastEvlDt == null) ? "" : moment(this.scaleComm[0].tmSscLastEvlDt).format('DD/MM/YYYY'),
        })
      } else {
        this.tmSrNoSSC = 0;
        this.SSCForm.reset();
      }
      if (this.lossRatioSSC.length > 0) {
        this.tmSrNoSlidingRate = this.lossRatioSSC[0].tmId;
        this.slidingScaleRateForm.patchValue({
          tmSscMinLr: this.lossRatioSSC[0].tmSscMinLr,
          tmSscMaxLr: this.lossRatioSSC[0].tmSscMaxLr,
          tmSscLrDiff: this.lossRatioSSC[0].tmSscLrDiff,
          tmSscMinComm: this.lossRatioSSC[0].tmSscMinComm,
          tmSscMaxComm: this.lossRatioSSC[0].tmSscMaxComm,
          tmSscCommDiff: this.lossRatioSSC[0].tmSscCommDiff,
        })
      } else {
        this.tmSrNoSlidingRate = 0;
        this.slidingScaleRateForm.reset();
      }
      if (this.pcData.length > 0) {
        this.tmSrNoPC = this.pcData[0].tmId;
        this.profitCommForm.patchValue({
          tmPcFirstEvlDt: moment(this.pcData[0].tmPcFirstEvlDt).format('DD/MM/YYYY'),
          tmPcLastEvlDt: moment(this.pcData[0].tmPcLastEvlDt).format('DD/MM/YYYY'),
          tmPcFirstCashEvlDt: moment(this.pcData[0].tmPcFirstCashEvlDt).format('DD/MM/YYYY'),
          tmPcEvlFrq: this.pcData[0].tmPcEvlFrq,
          tmPcMePerc: this.pcData[0].tmPcMePerc,
        })
      } else {
        this.tmSrNoPC = 0;
        this.profitCommForm.reset();
      }
      if (this.profitComm.length > 0) {
        this.tadSrNoPr = this.profitComm[0].tadId;
        this.premiumReserveForm.patchValue({
          tadPwResPerc: this.profitComm[0].tadPwResPerc,
          tadPwIntPerc: this.profitComm[0].tadPwIntPerc,
          tadPwResRel: this.profitComm[0].tadPwResRel,
          tadPwProcFreq: this.profitComm[0].tadPwProcFreq,
          tadRiExpPerc: this.profitComm[0].tadRiExpPerc,
          tadBnkIntReq: (this.profitComm[0].tadBnkIntReq == 'true'),
          tadBnkCurr: this.profitComm[0].tadBnkCurr,
        })
        this.enableApplicableRate(this.premiumReserveForm.get('tadBnkIntReq').value);
      } else {
        this.tadSrNoPr = 0;
        this.premiumReserveForm.reset();
      }
    },
      err => {
        this.loaderService.isBusy = false;
        this.toastService.error(err);
      }
    );
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.onActionEditTermSingleRow(data);
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
  enableApplicableRate(evnt) {
    this.hideApplicableRate = evnt;
    if (!this.hideApplicableRate) {
      this.premiumReserveForm.get('tadBnkCurr').clearValidators();
      this.premiumReserveForm.get('tadBnkCurr').setValue('')
    } else {
      this.premiumReserveForm.get('tadBnkCurr').setValidators(Validators.required);
      this.premiumReserveForm.get('tadBnkCurr').setValue(this.profitComm[0].tadBnkCurr);
    }
  }
  onActionEditTermSingleRow(data) {
    this.loaderService.isBusy = true;
    this.action = 'edit';
    let Obj = {
      tmId: data.tmId,
    }
    this.treatyService.getTreatyTermsById(Obj).subscribe((result) => {
      this.tmId = result.commissionList.tmId;
      this.treatyTermsForm.patchValue({
        tmId: result.commissionList.tmId,
        tmRefNo: result.commissionList.tmRefNo,
        tmSeqNo: result.commissionList.tmSeqNo,
        tmAmendNo: result.commissionList.tmAmendNo,
        tmLayer: result.commissionList.tmLayer,
        tmCommCode: result.commissionList.tmCommCode,
        tmCommPerc: result.commissionList.tmCommPerc,
        tmCedingBasis: result.commissionList.tmCedingBasis,
        tmCalcType: result.commissionList.tmCalcType,
        tmRecPayType: result.commissionList.tmRecPayType,
        tmAmt: result.commissionList.tmAmt,
        tmStatus: result.commissionList.tmStatus,
      });
      this.onChangeCalcType({ value: this.treatyTermsForm.get('tmCalcType').value });
    });
    this.showTermsFlag = true;
    this.addFlag = false;
    this.loaderService.isBusy = false;
  }

  closeIt() {
    this.showTermsFlag = false;
    this.addFlag = true;
  }

  open(content, val) {
<<<<<<< HEAD
    this.modalService.show(content, { class: val });
=======
    this.modalService.show(content, { class: val });    
  }
  decline(): void {
    this.modalService.hide();
    this.modalRef.hide();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  deleteReIns() {
    if (this.temp.tmId) {
      this.loaderService.isBusy = true;
      let obj = {
        tmId: this.temp.tmId,
        tmRefNo: this.refNo,
        tmSeqNo: this.seqNo,
        tmAmendNo: this.amendNo
      };
      this.treatyService.deleteTreatyTermsComm(obj, this.amndSrNo).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully.');
        this.onTreatyTermsGridReady();
        this.showTermsFlag = false;
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    } else {
      this.toastService.warning('Select record to delete');
    }
  }

  showDialogbox(val: any) {
    this.temp = val;
    this.open(this.confirmModal, 'modal-sm');
  }
  addNewTerms() {
    this.action = 'add';
    this.treatyTermsForm.reset();
    this.showTermsFlag = true;
    this.addFlag = false;
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
=======
      console.log(field + ":" + control.status);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  saveSSC() {
    this.loaderService.isBusy = true;
    if (this.SSCForm.valid) {
      let formData = this.SSCForm.getRawValue();
      let obj = {
        tmAmendNo: this.amendNo,
        tmRefNo: this.refNo,
        tmSeqNo: this.seqNo,
        tmCrDt: new Date(),
        tmCrUid: this.userId,
        tmUpdDt: new Date(),
        tmUpdUid: this.userId,
        tmStatus: 'P',
        tmFlex01: "RITERMS",
        tmLayer: this.layerReinsurer.trLayer,
        tmReins: this.layerReinsurer.trReins,
        tmBroker: this.layerReinsurer.trBroker,
        tmSscYn: 'Y',
        tmCommCode: "56",
        tmId: undefined
      };
      if (this.tmSrNoSSC) {
        obj.tmId = this.tmSrNoSSC
      }
      Object.assign(formData, obj);
      formData = Utils.clean(formData);
      formData.tmSscFirstEvlDt = (typeof (formData.tmSscFirstEvlDt) == 'string') ? moment(formData.tmSscFirstEvlDt, 'DD/MM/YYYY') : moment(formData.tmSscFirstEvlDt);
      // formData.tmSscLastEvlDt = (typeof (formData.tmSscLastEvlDt) == 'string') ? moment(formData.tmSscLastEvlDt, 'DD/MM/YYYY') : moment(formData.tmSscLastEvlDt);
      formData.tmSscLastEvlDt = (formData.tmSscLastEvlDt == undefined) ? null : new Date(formData.tmSscLastEvlDt);

      this.treatyService.saveSlidingScaleComm(formData).subscribe((resp: any) => {
        if (resp.messageType == 'S') {
          this.toastService.success('Successfully Saved');
          this.getTermSSCgridData('save');
          this.loaderService.isBusy = false;
        } else if (resp.messageType == 'U') {
          this.loaderService.isBusy = false;
          this.toastService.success(resp.message);
        } else {
          this.loaderService.isBusy = false;
          this.toastService.error(resp.message);
        }
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      })
    } else {
      this.validateAllFormFields(this.SSCForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  saveSlidingRateForm() {
    this.loaderService.isBusy = true;
    if (this.slidingScaleRateForm.valid) {
      let formData = this.slidingScaleRateForm.getRawValue();
      let obj = {
        tmAmendNo: this.amendNo,
        tmRefNo: this.refNo,
        tmSeqNo: this.seqNo,
        tmCrDt: new Date(),
        tmCrUid: this.userId,
        tmUpdDt: new Date(),
        tmUpdUid: this.userId,
        tmStatus: 'P',
        tmFlex01: "RITERMS",
        tmLayer: this.layerReinsurer.trLayer,
        tmReins: this.layerReinsurer.trReins,
        tmBroker: this.layerReinsurer.trBroker,
        tmSscYn: 'Y',
        tmCommCode: "56",
        tmId: undefined
      };
      if (this.tmSrNoSlidingRate) {
        obj.tmId = this.tmSrNoSlidingRate
      }
      Object.assign(formData, obj);
      formData = Utils.clean(formData);

      if (this.scaleComm.length > 0) {
        this.treatyService.saveTreatyTermsComm(formData, this.amndSrNo).subscribe((resp) => {
          this.toastService.success('Successfully Saved');
          this.getTermSSCgridData();
          this.getSlidingScaleLossRatioList();
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        this.loaderService.isBusy = false;
        this.toastService.warning("Before Apply Loss Ratio, Please Save Provisional Commission");
      }
    } else {
      this.validateAllFormFields(this.slidingScaleRateForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  getSlidingScaleLossRatioList() {
    this.slidingScaleRateList = [];
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.layerReinsurer.trReins
    };
    this.treatyService.getSlidingScaleLossRatioComm(obj, 'SSC').subscribe((resp: any) => {
      this.slidingScaleRateList = resp.sscList;
    }, error => {
      this.toastService.error(error);
      this.loaderService.isBusy = false;
    });
  }

  saveTermsForm(action) {
    if (this.treatyTermsForm.valid) {
      this.loaderService.isBusy = true;
      this.treatyService.checkProvisonComm(this.refNo,this.seqNo, this.amendNo,this.reins).subscribe(resp => {
        let flag = resp["flag"];
        if(flag == false){
          this.toastService.warning("Provisional Commission already exists, So Fixed Commission cannot be selected");
          return false;          
        }
      });
      let formData = this.treatyTermsForm.value;
      this.layerPriority = (typeof (this.layerPriority) == 'object') ? this.layerPriority.tlPriority : this.layerPriority;
      let term = formData.tmCommCode == '02'? 'Y':'';
      if (action == 'update') {
        formData.tmLayer = this.layerPriority;
        formData.tmRefNo = this.refNo;
        formData.tmSeqNo = this.seqNo;
        formData.tmStatus = 'P';
        formData.tmAmendNo = this.amendNo;
        formData.tmCrUid = this.session.get('userId');
        formData.tmCrDt = new Date();
        formData.tmId = this.tmId;
        formData.tmUpdDt = new Date();
        formData.tmUpdUid = this.session.get('userId');
        formData.tmCustCode = this.layerReinsurer.trReins;
        formData.tmFcYn = term;
        this.treatyService.updateTreatyTermsComm(formData, this.amndSrNo).subscribe(resp => {          
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.showTermsFlag = false;
            this.addFlag = true;
            this.toastService.success("Successfully Updated");  
            this.onTreatyTermsGridReady();         
          } else if (resp["messageType"] && resp["messageType"] == 'W') {
            this.toastService.warning("Fixed Commission cannot be selected");
          }         
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.errMessage);
        });
      } else {
        formData.tmLayer = this.layerPriority;
        formData.tmRefNo = this.refNo;
        formData.tmSeqNo = this.seqNo;
        formData.tmStatus = 'P';
        formData.tmAmendNo = this.amendNo;
        formData.tmCrUid = this.session.get('userId');
        formData.tmCrDt = new Date();
        formData.tmCustCode = this.layerReinsurer.trReins;
        formData.tmFcYn = term;
        this.treatyService.saveTreatyTermsComm(formData, this.amndSrNo).subscribe(resp => {         
          if (resp["messageType"] && resp["messageType"] == 'E') {
            this.toastService.error(resp["message"]);
          } else if (resp["messageType"] && resp["messageType"] == 'S') {
            this.showTermsFlag = false;
            this.addFlag = true;
            this.toastService.success("Successfully Saved");
            this.onTreatyTermsGridReady();         
          } else if (resp["messageType"] && resp["messageType"] == 'W') {
            this.toastService.warning("Fixed Commission cannot be selected");
          }
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.errMessage);
        });
      }
    } else {
      this.validateAllFormFields(this.treatyTermsForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  saveProfitCommForm() {
    this.loaderService.isBusy = true;
    if (this.profitCommForm.valid) {
      let formData = this.profitCommForm.getRawValue();
      let obj = {
        tmAmendNo: this.amendNo,
        tmRefNo: this.refNo,
        tmSeqNo: this.seqNo,
        tmCrDt: new Date(),
        tmCrUid: this.userId,
        tmUpdDt: new Date(),
        tmUpdUid: this.userId,
        tmStatus: 'P',
        tmFlex01: "RITERMS",
        tmLayer: this.layerReinsurer.trLayer,
        tmReins: this.layerReinsurer.trReins,
        tmBroker: this.layerReinsurer.trBroker,
        tmPcYn: 'Y',
        tmCommCode: "56",
        tmId: undefined
      };
      if (this.tmSrNoPC) {
        obj.tmId = this.tmSrNoPC
      }
      Object.assign(formData, obj);
      formData = Utils.clean(formData);
      formData.tmPcFirstEvlDt = (typeof (formData.tmPcFirstEvlDt) == 'string') ? moment(formData.tmPcFirstEvlDt, 'DD/MM/YYYY') : moment(formData.tmPcFirstEvlDt);
      formData.tmPcLastEvlDt = (typeof (formData.tmPcLastEvlDt) == 'string') ? moment(formData.tmPcLastEvlDt, 'DD/MM/YYYY') : moment(formData.tmPcLastEvlDt);
      formData.tmPcFirstCashEvlDt = (typeof (formData.tmPcFirstCashEvlDt) == 'string') ? moment(formData.tmPcFirstCashEvlDt, 'DD/MM/YYYY') : moment(formData.tmPcFirstCashEvlDt);
      this.treatyService.saveTreatyTermsComm(formData, this.amndSrNo).subscribe(resp => {

        this.toastService.success("Successfully Saved");
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      });
    } else {
      this.validateAllFormFields(this.profitCommForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  savePremiumReserveForm() {
    this.layerPriority = (typeof (this.layerPriority) == 'object') ? this.layerPriority.tlPriority : this.layerPriority;

    if (this.premiumReserveForm.valid) {
      this.loaderService.isBusy = true;
      let formData = this.premiumReserveForm.value;
      formData.tadLayer = this.layerPriority;
      formData.tadRefNo = this.refNo;
      formData.tadSeqNo = this.seqNo;
      formData.tadStatus = 'P';
      formData.tadAmendNo = this.amendNo;
      formData.tadCrUid = this.session.get('userId');
      formData.tadCrDt = new Date();
      formData.tadUpdUid = this.session.get('userId');
      formData.tadUpdDt = new Date();
      formData.tadCustCode = this.layerReinsurer.trReins;
      if (this.tadSrNoPr) {
        formData.tadId = this.tadSrNoPr
      }

      this.treatyService.saveTreatyPremiumReserve(formData, this.amndSrNo).subscribe(resp => {
        this.showTermsFlag = false;
        this.addFlag = true;
        this.toastService.success("Successfully Saved");
        this.onTreatyProfitComm();
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      });
    } else {
      this.validateAllFormFields(this.premiumReserveForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  onGridReady(params, gridName: any) {
    if (gridName === 'term') {
      this.gridApi = params.api;
    } else if (gridName === 'ssc') {
      this.sscGridApi = params.api;
    }
    params.api.sizeColumnsToFit();
    this.onTreatyTermsGridReady();
  }
  onTreatyTermsGridReady() {
    this.loaderService.isBusy = true;
    this.layerPriority = (typeof (this.layerPriority) == 'object') ? this.layerPriority.tlPriority : this.layerPriority;

    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.layerReinsurer.trReins
    };
    this.treatyService.getTreatyTermsComm(this.layerPriority, obj).subscribe((resp: any) => {
      this.rowTermsData = resp;
      this.loaderService.isBusy = false;
      this.rowTermsData.map((el, val) => {
        el.tmReins = val + 1;
      })
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.message);
    })
  }

  onTreatyProfitComm() {
    this.loaderService.isBusy = true;
    this.layerPriority = (typeof (this.layerPriority) == 'object') ? this.layerPriority.tlPriority : this.layerPriority;

    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo,
      tmCustCode: this.layerReinsurer.trReins
    };
    this.treatyService.getTreatyProfitComm(this.layerPriority, obj).subscribe((resp: any) => {
      this.profitComm = resp;
      this.loaderService.isBusy = false;
      if (this.profitComm.length > 0) {
        // this.profitComm = this.profitComm[this.profitComm.length - 1];
        this.tadSrNoPr = this.profitComm[0].tadId;
        this.premiumReserveForm.patchValue({
          tadPwResPerc: this.profitComm[0].tadPwResPerc,
          tadPwIntPerc: this.profitComm[0].tadPwIntPerc,
          tadPwResRel: this.profitComm[0].tadPwResRel,
          tadPwProcFreq: this.profitComm[0].tadPwProcFreq,
          tadRiExpPerc: this.profitComm[0].tadRiExpPerc,
          tadBnkIntReq: (this.profitComm[0].tadBnkIntReq == 'true'),
          tadBnkCurr: this.profitComm[0].tadBnkCurr,
        })
        this.enableApplicableRate(this.premiumReserveForm.get('tadBnkIntReq').value);

      } else {
        this.tadSrNoPr = 0;
        this.premiumReserveForm.reset();
        this.enableApplicableRate(this.premiumReserveForm.get('tadBnkIntReq').value);
      }
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.message);
    })
  }

  onTreatyTermsSSCGridReady(action) {
    this.layerPriority = (typeof (this.layerPriority) == 'object') ? this.layerPriority.tlPriority : this.layerPriority;

    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo
    };

  }
  openConfirmModal(template: TemplateRef<any>, tmId, index) {
    this.deleteIndex = tmId;
    this.index = index;
    this.modalRef = this.modService.show(template, { class: 'modal-sm' });
  }
  decline(): void {
    this.modalService.hide();
    this.modalRef.hide();
  }
  confirm(tmId, index): void {
    this.loaderService.isBusy = true;
    if (tmId == null) {
      this.items_fc.removeAt(this.index);
      this.modalRef.hide();
      this.loaderService.isBusy = false;
      this.disableAddrow = false;
    } else {
      let obj = {
        tmId: tmId,
        tmRefNo: this.refNo,
        tmSeqNo: this.seqNo,
        tmAmendNo: this.amendNo
      };
      this.treatyService.deleteFixedComm(obj, this.amndSrNo).subscribe(() => {
        this.toastService.success('Deleted Succcessfully.');
        this.loaderService.isBusy = false;
        this.items_fc.removeAt(index);
        this.disableAddrow = false;
        this.modalRef.hide();
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    }
  }

  onBtExport(gridApi: any) {
    if (gridApi) {
      let columnKeys = ['tmReins', 'tmCommCodeDesc', 'tmRecPayTypeDesc', 'tmCalcTypeDesc', 'tmCommPerc', 'tmAmt'];
      gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'treaty_terms.xlsx',
        skipHeader: false,
        sheetName: 'Treaty Terms',
        columnKeys: columnKeys,
      });
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onGridSizeChanged(params, gridId) {
    var gridWidth = document.getElementById(gridId).offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  graterValidator(firstKey: string, secondKey: string): ValidatorFn {
    return (group: UntypedFormGroup): { [key: string]: any } => {
      const first = group.controls[firstKey];
      const second = group.controls[secondKey];
      const message =
        "Must be greater or equal to the Loss ratio From %";
      if (second.value > first.value) {
      } else if (second.value == first.value) {
      } else {
        second.setErrors({ equalValue: message });
        return { equalValue: true };
      }
    };
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
    gridApi.sizeColumnsToFit();
  }
  displayRowCount(gridApi: any) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onRowClickedSSC(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action");
      switch (actionType) {
        case "Edit":
          return this.onActionEditSSC(e);
        case "Delete":
          return this.onActionEditSSC(e);
      }
    }
  }
  onRowEditingStarted(params) {
    params.api.refreshCells({
      columns: ["action"],
      rowNodes: [params.node],
      force: true
    });
  }
  onRowEditingStopped(params) {
    params.api.refreshCells({
      columns: ["action"],
      rowNodes: [params.node],
      force: true
    });
  }
  onActionEditSSC(params) {
    if (params.column.colId === "action" && params.event.target.dataset.action) {
      let action = params.event.target.dataset.action;
      if (action === "edit") {
        params.api.startEditingCell({
          rowIndex: params.node.rowIndex,
          colKey: params.columnApi.getDisplayedCenterColumns()[0].colId
        });
      }
      if (action === "delete") {
        this.deleteCell(params);
      }
      if (action === "update") {
        this.updateCell(params);
      }
      if (action === "cancel") {
        params.api.stopEditing(true);
      }
    }
  }
  deleteCell(params) {
    this.loaderService.isBusy = false;
    let data = params.data;
    this.treatyService.deleteSSCInfo(data).subscribe((resp) => {
      params.api.applyTransaction({
        remove: [params.node.data]
      });
      if (resp["messageType"] && resp["messageType"] == 'E') {
        this.toastService.error(resp["message"]);
      } else if (resp["messageType"] && resp["messageType"] == 'D') {
        this.toastService.success("Deleted Successfully!");
      } else {
        this.toastService.success(resp["message"]);
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.message);
    })
  }
  updateCell(params) {
    this.loaderService.isBusy = false;
    params.api.stopEditing(false);
    let data = params.data;
    this.treatyService.updateSSCInfo(data, data.tsRefNo).subscribe((resp) => {
      if (resp["messageType"] && resp["messageType"] == 'E') {
        this.toastService.error(resp["message"]);
      } else if (resp["messageType"] && resp["messageType"] == 'U') {
        this.toastService.success("Updated Successfully!");
      } else {
        this.toastService.success(resp["message"]);
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.message);
    })
  }
  SscProvFlg:boolean = false;
 checkforTerm(){
  if(this.rowTermsData.length > 0) {
    var isPresent = this.rowTermsData.some(function(el){ return el.tmCommCodeDesc === "Fixed Commission"});
    if(isPresent){
      this.SscProvFlg = true;
      this.SSCForm.get('tmSscProv').clearValidators();
      this.SSCForm.get('tmSscProv').updateValueAndValidity();
    } else {
      this.SscProvFlg = false;
      this.SSCForm.get('tmSscProv').setValidators([Validators.required]);
      this.SSCForm.get('tmSscProv').updateValueAndValidity();      
    }
  }  
 }
}
function currencyFormatter(params) {
  if (params && params.value != null && params.value != undefined) {
    let vl = parseFloat(params.value);
    return vl.toFixed(4);
  } else {
    return '';
  }
}
function actionCellRenderer(params) {
  let eGui = document.createElement("div");

  let editingCells = params.api.getEditingCells();
  let isCurrentRowEditing = editingCells.some((cell) => {
    return cell.rowIndex === params.node.rowIndex;
  });

  if (isCurrentRowEditing) {
    eGui.innerHTML = `
          <a>
            <i class="fa fa-refresh fa-icon"  data-action="update" title="Update" aria-hidden="true"></i>
          </a>&nbsp;&nbsp;
          <a>
            <i class="fa fa-close fa-icon fa-danger"  data-action="cancel" title="Cancel" aria-hidden="true"></i>
          </a>
        `;
  } else {
    eGui.innerHTML = `
          <a>
            <i class="fa fa-file-pen fa-icon"  data-action="edit" title="Edit" aria-hidden="true"></i>
          </a>&nbsp;&nbsp;
          <a>
            <i class="fa fa-trash fa-icon fa-danger"  data-action="delete" title="Delete" aria-hidden="true"></i>
          </a>
        `;
  }

  return eGui;
}