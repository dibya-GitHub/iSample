import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyTermsComponent } from './treaty-terms.component';

describe('TreatyTermsComponent', () => {
  let component: TreatyTermsComponent;
  let fixture: ComponentFixture<TreatyTermsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyTermsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyTermsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
