import { Component, ViewContainerRef, ViewChild, AfterViewInit } from '@angular/core';
import { ICellEditorAngularComp } from '@ag-grid-community/angular';

@Component({
    selector: 'numeric-cell',
    template: `<p-inputNumber #input mode="decimal" [useGrouping]="false" autocomplete="off"
		inputStyleClass="form-control rightAlign" [(ngModel)]="value" required
		[minFractionDigits]="2" [maxFractionDigits]="4" placeholder="Enter Accounting CCY Net Amount"
		></p-inputNumber>
        `
})
export class NumericEditorComponent implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: number;
    @ViewChild('input', { read: ViewContainerRef }) public input;
    agInit(params: any): void {
        this.params = params;
        this.value = this.params.value;
    }
    getValue(): any {
        return this.value;
    }
    ngAfterViewInit() {
        this.input.element.nativeElement.focus();
    }
}
