<<<<<<< HEAD
import { ICellRendererAngularComp } from '@ag-grid-community/angular';
import { Component } from '@angular/core';
=======
import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from '@ag-grid-community/angular';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-editviewrender',
  template: `<a>
<<<<<<< HEAD
  <i class="Px-2 fa fa-file-pen fa-icon" *ngIf="canEditShow" style="color:#009ca6" data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true" ></i>
  <i class="Px-2 fa fa-eye fa-icon" style="color:#009ca6" *ngIf="canViewShow"  data-action-type="View"  title="View" aria-hidden="true"></i>
  <i class="Px-2 fa fa-file-pen fa-icon" style="color:#009ca6; font-size: 1.55em "  data-action-type="Edit"  title="Edit" aria-hidden="true"  *ngIf="canShowEgnp"></i>&nbsp;&nbsp;
  <i class="Px-2 fa fa-trash fa-icon"  style="color:#009ca6; font-size: 1.55em" data-action-type="Remove"  title="Delete" aria-hidden="true" *ngIf="canShowEgnp"></i>
=======
  <i class="Px-2 fa fa-file-pen fa-icon" *ngIf="canEditShow" style="color:#009ca6" data-action-type="Edit" title="Edit" aria-hidden="true" ></i>
  <i class="Px-2 fa fa-eye fa-icon" style="color:#009ca6" *ngIf="canViewShow"  data-action-type="View"  title="View" aria-hidden="true"></i>
  <i class="Px-2 fa fa-file-pen fa-icon" style="color:#009ca6;"  data-action-type="Edit"  title="Edit" aria-hidden="true"  *ngIf="canShowEgnp"></i>&nbsp;&nbsp;
  <i class="Px-2 fa fa-trash fa-icon fa-danger"   data-action-type="Remove"  title="Delete" aria-hidden="true" *ngIf="canShowEgnp"></i>
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  </a>`,


  styleUrls: ['./editviewrender.component.scss']
})
export class EditviewrenderComponent implements ICellRendererAngularComp {
  public params: any;
  canViewShow: boolean;
  canEditShow: boolean;
  canShowEgnp: boolean;
  agInit(params: any): void {
    this.params = params;
    if (this.params && this.params.data) {
      if (this.params.data.txaApprSts == "Approved") {
        this.canViewShow = true;
      } else if (this.params.data.txaApprSts == "Pending") {
        this.canEditShow = true;
      } else if (this.params.data.ttyEpiPK != undefined && this.params.data.ttyEpiPK != null) {
        if (this.params.data.companyName != null) {
          this.canShowEgnp = true;
        }

      }
    }
    // console.log("Radio render.....", this.params)
  }

  public invokeParentMethod(e) {

  }
  refresh(): boolean {
    return false;
  }
}
