import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditviewrenderComponent } from './editviewrender.component';

describe('EditviewrenderComponent', () => {
  let component: EditviewrenderComponent;
  let fixture: ComponentFixture<EditviewrenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditviewrenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditviewrenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
