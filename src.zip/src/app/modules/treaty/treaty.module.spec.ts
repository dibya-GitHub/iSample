import { TreatyModule } from './treaty.module';

describe('TreatyModule', () => {
  let treatyModule: TreatyModule;

  beforeEach(() => {
    treatyModule = new TreatyModule();
  });

  it('should create an instance', () => {
    expect(treatyModule).toBeTruthy();
  });
});
