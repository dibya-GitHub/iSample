import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AadTotalComponent } from './aad-total.component';

describe('AadTotalComponent', () => {
  let component: AadTotalComponent;
  let fixture: ComponentFixture<AadTotalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AadTotalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AadTotalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
