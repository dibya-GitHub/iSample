<<<<<<< HEAD
import { DatePipe, DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
=======
import { Component, OnInit, Inject, Input, ViewChild, ElementRef } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, UntypedFormControl, UntypedFormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { TreatyService } from 'src/app/shared/services/treaty.service';
//import { LocalService } from 'src/app/shared/message.service';
import { DatePipe } from '@angular/common';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
import { DOCUMENT } from '@angular/common';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';


@Component({
  selector: 'app-approved-contract',
  templateUrl: './approved-contract.component.html',
  styleUrls: ['./approved-contract.component.css'],
  providers: [MycurrencyPipe],
})
export class ApprovedContractComponent implements OnInit {
  reShareTotal = 0;
  layerPrem = 0;
  layerAdjPremTotal = 0;
  layerBottomData: any[];
  LayerSummary: any[];
  layerRolDepPremTotal = 0;
  layerDepPremTotal = 0;
  layerPremTotal = 0;
  reDepPremTotal = 0;
  rePremTotal = 0;
  reinstDepPremTotal = 0;
  reinstPremTotal = 0;
  reinsurerTotal: any = [];
  reinsurerBottomData: any =  [];
  reinsurerSummaryBottomData: any = [];
  rowSelection: string;
  selectedLayerDesc: any;
  reinstList: any[];
  reinsurerList: any[];
  showPerilEntriesPeril = 5;
  showEgnpOptionSelected = 5;
  showLayerOptionSelected = 5;
  showReinsurerOptionSelected = 5;
  showLimitOptionSelected = 5;
  showPremiumEntriesSelected = 5;
  showReinstOptionSelected = 5;
  showReinsEntriesOptions = [5, 10, 20, 50, 100];
  showInstallOptionSelected = 5;
  tlMaxRec: any;
  tlNoOfReinst: any;
  perilSearchValue: any;
  reinstSearchValue: any;
  premiumSearchValue: any;
  limitSearchValue: any;
  reinsurerSearchValue: any;
  layerSearchValue: any;
  egnpSearchValue: any;
  gridApiegnp: any;
  gridApilayer: any;
  gridApilimit: any;
  gridApipremium: any;
  gridApireinsurer: any;
  gridApiperil: any;
  gridApireinst: any;
  gridApiinstall: any;
  installSearchValue: any;
  summarySearchValue: any;
  reInstData = [];
  public frameworkComponents: any;
  context: any;
  gridColumnApi: any;
  gridApi: any;
  action: any;
  refNo: any;
  amendNo: any;
  loginId: any;
  contractAmendNo: any;
  contractNo: any;
  contractForm: UntypedFormGroup;
  thRefNo: any;
  thAmendNo: any;
  thTtyDesc: any;
  thUwYear: any;
  thContractType: any;
  thAttachBasis: any;
  thXlType: any;
  thCurr: any;
  thEpiAmt: any;
  thFixedRate: any;
  thAdjustPeriod: any;
  thClmNotifyDays: any;
  thRemarks: any;
  thCrUid: any;
  thProgCode: any;
  ttyHdrPK: any;
  thApprSts: any;
  thEndDt: any;
  thStartDt: any;
  thApprUid: any;
  thApprDt: any;
  thCrDt: any;
  thStatus: any;
  treatyType: any;
  typexol: any;
  contractTypeList: any;
  typecontract: any;
  attachmentBasisList: any;
  attchbasis: any;
  details: any;
  egnpi: any[];
  layer: any[];
  reinsurer: any[];
  totalPremium: number = 0;
  // @Input() seqNo: string;
  reInsurerArrayList: any;
  seqNo: any;
  thSeqNo: any;
  selectedLayerId: any;
  showReinsurer: boolean;
  layerId: any;
  layerArrayList: any;
  layerNo: any;
  reinsDetails: any = [];
  currencyDetails: any = [];
  currency: any = [];
  perilDetails: any[];
  perilCols: any[];
  reinsurerSummary: any[];
  reinsumDetails: any[];
  customer: any;
  reInstDetails: any[];
  InstallmentFlag: boolean;
  showreinsur: any[];
  layerDetails: any;
  custName: any;
  totstlPrem: any;
  totStlDepPrm: any;
  totCustPrm: any;
  totCustdepPrm: any;
  layerCols: any[];
  ReinsurerFlag: boolean;
  layerSumDetails: any[];
  reinsBrokerId: any;
  tlLimitCurr: any;
  tlLimit: string;
  tlDeductible: string;
  tlAad: any;
  tlPremCurr: any;
  tlRateType: any;
  tlAdjustRate: any;
  tlBcLoadFact: any;
  tlBcMinRate: string;
  tlPremRol: any;
  tlPrem: string;
  tlDepPremPerc: any;
  tlMinPrem: string;
  tlReinstUnltdYn: boolean;
  tlDepPremRol: any;
  tlDepPrem: string;
  @ViewChild('content') content: ElementRef;
  @ViewChild('content2') content2: ElementRef;
  rateList: any[];
  AdjRate: any;
  RateType: any;
  currencyList: any[];
  Appl_curr: any;
  premium: any[];
  bsCurr: any;
  PremCurrdetails: any;
  RiskFlag: boolean;
  egnpiFlag: boolean;
  riskDetails: any[];

  totFacPremFc: number;
  tkSiCurr: number;
  tkPremCurr: number;
  totFacSiFc: number;
  totRiskPremFc: number;
  totRiskSiFc: number;
  totalFacFlag: boolean;
  risk_peril: any[];
  layerFXFlag: boolean;
  AggDeduct: any;
  titleType: string;
  layerAdjRate: any;
  coloumnDefs = [];
  rowData = [];
  egnpInfo: any;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  documents: any[];
  isDocumentNeedsToBeUpdated: boolean;
  documentTypes: any[];
  pinnedBottomRowData: any;
  excessMinVal: number[];
  layerExcessMin: any;
  layerLimit: any;
  layerDepPremPerc: any;
  getRowStyle: (params: any) => { 'font-weight': string; };
  thPlaLimit: any;
  thNoOfAdj: any;
  totalRebateAmt: any = 0;
  totalNetAmt: any = 0;
  @Input()
  get docRefId(): string {
    if (this.refNo && this.amendNo && this.seqNo) {
      return 'C-' + this.refNo + '-' + this.seqNo + '-' + this.amendNo;
    } else {
      return;
    }
  }
  canEdit = false;
  FreqList: any;
  repPeriod:any;
  repPeriodUnit:any;
<<<<<<< HEAD
  reportingFlg:boolean = false;
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  constructor(
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private datePipe: DatePipe,
    private cpipe: MycurrencyPipe,
<<<<<<< HEAD
    private modalService: BsModalService,
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    @Inject(DOCUMENT) private document: Document
  ) {
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
  }

  ngOnInit() {
    this.bsCurr = this.session.get('baseCurrency');
    this.action = this.treatyService.getParamValue('action');
    this.refNo = this.treatyService.getParamValue('refNo') == undefined ? this.contractNo : this.treatyService.getParamValue('refNo');
    this.amendNo = this.treatyService.getParamValue('amendNo') == undefined ? this.contractAmendNo : this.treatyService.getParamValue('amendNo');
    this.loginId = this.session.get('userId') == undefined ? "test" : this.session.get('userId');
    this.seqNo = this.treatyService.getParamValue('seqNo');
    this.thContractType = this.treatyService.getParamValue('contractType');
    this.rowSelection = 'single'
    this.getDocumentTypes();

    if (this.thContractType == 'FX') {
      this.titleType = 'Risk and Peril';
      this.layerFXFlag = false;
      this.RiskFlag = true;
      this.egnpiFlag = false;
      this.retriveRiskData();

      this.risk_peril = [
        { field: 'ttyRiskPK.tkRiskSrNo', headerName: 'Risk', cellStyle: { textAlign: 'right' }, resizable: true, tooltipField: 'companyName', enableRowGroup: true, },
        { field: 'ttyRiskPK.tkPeril', headerName: 'Peril', cellStyle: { textAlign: 'right' }, resizable: true, tooltipField: 'companyName', enableRowGroup: true, },
        { field: 'tkRiskSiFc', headerName: '100 % Sum Insured', cellStyle: { textAlign: 'right' },
         //valueFormatter: currencyFormatter, 
         valueGetter: function (params) {
          if(params.data && params.data.tkRiskSiFc) {            
            return Number(params.data.tkRiskSiFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
         resizable: true, tooltipField: 'companyName', enableRowGroup: true, },
        { field: 'tkRiskPremFc', headerName: '100 % Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tkRiskPremFc) {            
            return Number(params.data.tkRiskPremFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        resizable: true, tooltipField: 'companyName', enableRowGroup: true, },
        { field: 'tkFacPerc', headerName: 'FAC XL Share %', cellStyle: { textAlign: 'right' },
         //valueFormatter: currencyFormatter,
         valueGetter: function (params) {
          if(params.data && params.data.tkFacPerc) {            
            return Number(params.data.tkFacPerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
         resizable: true, tooltipField: 'companyName', enableRowGroup: true, },
        { field: 'tkFacSiFc', headerName: 'FAC XL Limit', cellStyle: { textAlign: 'right' },
         //valueFormatter: currencyFormatter,
         valueGetter: function (params) {
          if(params.data && params.data.tkFacSiFc) {            
            return Number(params.data.tkFacSiFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
         resizable: true, tooltipField: 'companyName', enableRowGroup: true, },
        { field: 'tkFacPremFc', headerName: 'FAC XL Premium', cellStyle: { textAlign: 'right' },
         //valueFormatter: currencyFormatter,
         valueGetter: function (params) {
          if(params.data && params.data.tkFacPremFc) {            
            return Number(params.data.tkFacPremFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
          resizable: true, tooltipField: 'companyName', enableRowGroup: true, }

      ];

      this.layer = [
        {
          headerName: "Layer",
          field: "ttyLayerPK.tlLayer",
          sortable: true, resizable: true,filter: true,
        },

        {
          headerName: "Limit Curr",
          field: "tlLimitCurr",
          sortable: true,
          filter: true,
          tooltipField: 'tlLimitCurr',
          valueGetter: function (params) {
            return params.data.tlLimitCurr;
          },
          cellStyle: { textAlign: 'left' }, resizable: true
        },
        {
          headerName: "Limit",
          field: "tlLimit",
          sortable: true,
          filter: true,
          //tooltipField: 'tlLimit',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlLimit) {            
              return Number(params.data.tlLimit).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' }, resizable: true
        },
        {
          headerName: "Excess",
          field: "tlDeductible",
          sortable: true,
          filter: true,
          //tooltipField: 'tlDeductible',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDeductible) {            
              return Number(params.data.tlDeductible).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' }, resizable: true
        },
        {
          headerName: "Prem Curr",
          field: "tlPremCurr",
          sortable: true,
          filter: true,
          tooltipField: 'tlPremCurr',
          valueGetter: function (params) {
            return params.data.tlPremCurr;
          },
          cellStyle: { textAlign: 'left' }, resizable: true
        },
        {
          headerName: "Premium",
          field: "tlPrem",
          sortable: true,
          filter: true,
          tooltipField: 'tlPrem',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlPrem) {            
              return Number(params.data.tlPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' }, resizable: true
        },
        {
          headerName: "Rate",
          field: "tlAdjustRate",
          sortable: true,
          filter: true,
          tooltipField: 'tlAdjustRate',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlAdjustRate) {            
              return Number(params.data.tlAdjustRate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },

        {
          headerName: "RoL 100% Prem",
          field: "tlPremRol",
          sortable: true,
          filter: true,
          tooltipField: 'tlPremRol',
          valueFormatter: numberFormatter,
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Dep Prem",
          field: "tlDepPrem",
          sortable: true,
          filter: true,
          tooltipField: 'tlDepPrem',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDepPrem) {            
              return Number(params.data.tlDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Dep Prem %",
          field: "tlDepPremPerc",
          sortable: true,
          filter: true,
          //tooltipField: 'tlDepPremPerc',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDepPremPerc) {            
              return Number(params.data.tlDepPremPerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },

        {
          headerName: "RoL Dep Prem",
          field: "tlDepPremRol",
          sortable: true,
          filter: true,
          tooltipField: 'tlDepPremRol',
          //valueFormatter: numberFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDepPremRol) {            
              return Number(params.data.tlDepPremRol).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Reinst",
          field: "tlNoOfReinst",
          sortable: true,
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Action",
          field: "ttyLayerPK.tlLayer",
          cellRenderer: actionRenderLayer,
          cellStyle: { textAlign: 'center' },
          resizable: true,
          filter: false,
        }
      ];

    } else {
      this.titleType = 'EGNPI';
      this.layerFXFlag = true;
      this.RiskFlag = false;
      this.egnpiFlag = true;
      this.retrieveEgnpiForm();
      this.egnpi = [
        { field: 'companyName', headerName: 'Company', sortable: true, resizable: true, tooltipField: 'companyName', enableRowGroup: true, },
        { field: 'branch', headerName: 'Branch', sortable: true, resizable: true, tooltipField: 'branch', enableRowGroup: true, },
        { field: 'classDesc', headerName: 'Class', sortable: true, resizable: true, tooltipField: 'classDesc', enableRowGroup: true, },
        {
          field: 'tePrem', headerName: 'Premium', sortable: true, cellStyle: { textAlign: 'right' },
           //valueFormatter: currencyFormatter,
           valueGetter: function (params) {
            if(params.data && params.data.tePrem) {            
              return Number(params.data.tePrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
           resizable: true, tooltipField: 'tePrem', enableRowGroup: true,
          //   valueGetter: function (params) {
          //   if (params.data != null)
          //     var reference = params.data.tePrem;
          //   return reference;
          // }
        },

      ];
      this.egnpInfo = [
        { field: 'companyName', headerName: 'Company', sortable: true, resizable: true, tooltipField: 'companyName', enableRowGroup: true, filter:true},
        { field: 'branch', headerName: 'Branch', sortable: true, resizable: true, tooltipField: 'branch', enableRowGroup: true, filter:true},
        { field: 'classDesc', headerName: 'Class', sortable: true, resizable: true, tooltipField: 'classDesc', enableRowGroup: true, filter:true},
        { field: 'tePrem', headerName: 'Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.tePrem) {            
            return Number(params.data.tePrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
         sortable: true, resizable: true, tooltipField: 'tePrem', enableRowGroup: true ,filter:true},

      ];
      // this.layer = [
      //   { field: 'radio', headerName: 'layer' ,cellRenderer: "radioButtonRenderer",},
      //   { field: 'ttyLayerPK.tlLayer', headerName: 'Layer',sortable: true,resizable: true,tooltipField: 'ttyLayerPK.tlLayer', enableRowGroup: true,},
      //   { field: 'tlLimit', headerName: 'Limit',cellStyle: { textAlign: 'right' },valueFormatter: currencyFormatter,resizable: true,tooltipField: 'tlLimit', enableRowGroup: true, },
      //   { field: 'tlPrem', headerName: '100% Prem',cellStyle: { textAlign: 'right' },valueFormatter: currencyFormatter,sortable: true,resizable: true,tooltipField: 'tlPrem', enableRowGroup: true, },
      //   { field: 'tlPremRol', headerName: 'RoL 100% Prem',cellStyle: { textAlign: 'right' },valueFormatter: currencyFormatter,sortable: true,resizable: true,tooltipField: 'tlPremRol', enableRowGroup: true,},
      //   { field: 'tlDepPrem', headerName: 'Deposit Premium',cellStyle: { textAlign: 'right' },valueFormatter: currencyFormatter, sortable: true,resizable: true,tooltipField: 'tlDepPrem', enableRowGroup: true, },
      //   { field: 'tlDepPremRol', headerName: 'RoL Deposit Prem',cellStyle: { textAlign: 'right' },valueFormatter: currencyFormatter,sortable: true,resizable: true,tooltipField: 'tlDepPremRol', enableRowGroup: true, },
      //   { field: 'tlNoOfReinst', headerName: 'Reinstatement',sortable: true,resizable: true,tooltipField: 'tlNoOfReinst', enableRowGroup: true, },
      //   {
      //     headerName: 'Action', 
      //     field: 'action',
      //     template:
      //       ` <a>
      //     <i class="fa fa-eye fa-icon" style="color:#009ca6"  data-action-type="View" title="View Layer" aria-hidden="true"></i>

      //     </a>`
      //   },

      // ];

      this.layer = [
        // {
        //   headerName: "Select ",
        //   field: 'ttyLayerPK.tlLayer',
        //   cellRenderer: "radioButtonRenderer",
        //   cellStyle: { textAlign: 'center' },resizable: true
        // },
        {
          headerName: "Layer",
          field: "ttyLayerPK.tlLayer",
          sortable: true,
          valueGetter: function (params) {
            return params.data.ttyLayerPK.tlLayer + " - " + params.data.tlDesc;
          }, resizable: true
        },

        {
          headerName: "Limit Curr",
          field: "tlLimitCurr",
          sortable: true,
          filter: true,
          tooltipField: 'tlLimitCurr',
          valueGetter: function (params) {
            return params.data.tlLimitCurr;
          },
          cellStyle: { textAlign: 'left' },
          resizable: true
        },
        {
          headerName: "Limit",
          field: "tlLimit",
          sortable: true,
          filter: true,
          tooltipField: 'tlLimit',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlLimit) {            
              return Number(params.data.tlLimit).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Excess",
          field: "tlDeductible",
          sortable: true,
          filter: true,
          tooltipField: 'tlDeductible',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDeductible) {            
              return Number(params.data.tlDeductible).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Prem Curr",
          field: "tlPremCurr",
          sortable: true,
          filter: true,
          tooltipField: 'tlPremCurr',
          valueGetter: function (params) {
            return params.data.tlPremCurr;
          },
          cellStyle: { textAlign: 'left' },
          resizable: true
        },
        {
          headerName: "Premium",
          field: "tlPrem",
          sortable: true,
          filter: true,
          tooltipField: 'tlPrem',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlPrem) {            
              return Number(params.data.tlPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Rate",
          field: "tlAdjustRate",
          sortable: true,
          filter: true,
          tooltipField: 'tlAdjustRate',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlAdjustRate) {            
              return Number(params.data.tlAdjustRate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },

        {
          headerName: "RoL 100% Prem",
          field: "tlPremRol",
          sortable: true,
          filter: true,
          tooltipField: 'tlPremRol',
          //valueFormatter: numberFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlPremRol) {            
              return Number(params.data.tlPremRol).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Dep Prem",
          field: "tlDepPrem",
          sortable: true,
          filter: true,
          tooltipField: 'tlDepPrem',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDepPrem) {            
              return Number(params.data.tlDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Dep Prem %",
          field: "tlDepPremPerc",
          sortable: true,
          filter: true,
         // tooltipField: 'tlDepPremPerc',
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDepPremPerc) {            
              return Number(params.data.tlDepPremPerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },

        {
          headerName: "RoL Dep Prem",
          field: "tlDepPremRol",
          sortable: true,
          filter: true,
          tooltipField: 'tlDepPremRol',
          //valueFormatter: numberFormatter,
          valueGetter: function (params) {
            if(params.data && params.data.tlDepPremRol) {            
              return Number(params.data.tlDepPremRol).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' },
          resizable: true
        },
        {
          headerName: "Reinst",
          field: "tlNoOfReinst",
          sortable: true,
          cellStyle: { textAlign: 'right' },
          resizable: true,
          filter: true,
        },
        {
          headerName: "Action",
          field: "ttyLayerPK.tlLayer",
          cellRenderer: actionRenderLayer,
          cellStyle: { textAlign: 'center' },
          resizable: true,
          filter: false,
        }
      ];


      this.premium = [
        // { field: 'tcCurrDesc', headerName: 'Currency' },
        { field: 'mttyCurrPK.tcCurr', headerName: 'Currency', sortable: true, resizable: true, tooltipField: 'mttyCurrPK.tcCurr', enableRowGroup: false, filter: true,},
        { field: 'tcFixedRate', headerName: 'ROE', sortable: true, resizable: true, 
          //valueFormatter: currencyFormatter, 
          valueGetter: function (params) {
            if(params.data && params.data.tcFixedRate) {            
              return Number(params.data.tcFixedRate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          cellStyle: { textAlign: 'right' }, tooltipField: 'tcFixedRate', enableRowGroup: false, filter: true,},
        { field: 'tcMinPrem', headerName: 'Minimum Prem', cellStyle: { textAlign: 'right' }, 
          //valueFormatter: currencyFormatter, 
          valueGetter: function (params) {
            if(params.data && params.data.tcMinPrem) {            
              return Number(params.data.tcMinPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          sortable: true, resizable: true, tooltipField: 'tcMinPrem', enableRowGroup: false, filter: true,},
        { field: 'tcDepPrem', headerName: 'Deposit Prem', cellStyle: { textAlign: 'right' }, 
          //valueFormatter: currencyFormatter, 
          valueGetter: function (params) {
            if(params.data && params.data.tcDepPrem) {            
              return Number(params.data.tcDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          sortable: true, resizable: true, tooltipField: 'tcDepPrem', enableRowGroup: false, filter: true,},
        { field: 'tcMinPremLc1', headerName: 'Minimum Prem (' + this.bsCurr + ')', cellStyle: { textAlign: 'right' }, 
          //valueFormatter: currencyFormatter, 
          valueGetter: function (params) {
            if(params.data && params.data.tcMinPremLc1) {            
              return Number(params.data.tcMinPremLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          sortable: true, resizable: true, tooltipField: 'tcMinPremLc1', enableRowGroup: false, filter: true,},
        { field: 'tcDepPremLc1', headerName: 'Deposit Prem (' + this.bsCurr + ')', cellStyle: { textAlign: 'right' }, 
          //valueFormatter: currencyFormatter, 
          valueGetter: function (params) {
            if(params.data && params.data.tcDepPremLc1) {            
              return Number(params.data.tcDepPremLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            } else {
              return '';
            }
          },
          sortable: true, resizable: true, tooltipField: 'tcDepPremLc1', enableRowGroup: false, filter: true,},
      ];
    }
    this.reinsurer = [
<<<<<<< HEAD
      { field: 'reinsDesc', headerName: 'Reinsurer', sortable: true, resizable: true, tooltipField: 'reinsDesc', enableRowGroup: true, },
      { field: 'brokerDesc', headerName: 'Broker', sortable: true, resizable: true, tooltipField: 'brokerDesc', enableRowGroup: true, },
      { field: 'trBrkRefNo', headerName: 'Broker Ref', sortable: true, resizable: true, tooltipField: 'trBrkRefNo', enableRowGroup: true, },
      { field: 'trAcntDesc', headerName: 'Accounting To', sortable: true, resizable: true, tooltipField: 'trAcntDesc', enableRowGroup: true, },
      { field: 'countryDesc', headerName: 'Reinsurer Country', sortable: true, resizable: true, tooltipField: 'countryDesc', enableRowGroup: true, },
      { field: 'amBest', headerName: 'AM Best', sortable: true, resizable: true, tooltipField: 'amBest', enableRowGroup: true, },
      { field: 'spRating', headerName: 'S&P', sortable: true, resizable: true, tooltipField: 'spRating', enableRowGroup: true, },
      { field: 'trSharePerc', headerName: 'Share %', sortable: true, resizable: true, tooltipField: 'trSharePerc', enableRowGroup: true, cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter },
      { field: 'trPrem', headerName: '100% Premium', cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter, sortable: true, resizable: true, tooltipField: 'minPremium', enableRowGroup: true, },
      { field: 'trDepPrem', headerName: 'Dep Premium', cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter, sortable: true, resizable: true, tooltipField: 'depPremium', enableRowGroup: true, },
      { field: 'trNcbPerc', headerName: 'NCB %', sortable: true, resizable: true, tooltipField: 'trNcbPerc', enableRowGroup: true, cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter }
=======
      { field: 'reinsDesc', headerName: 'Reinsurer', sortable: true, resizable: true, tooltipField: 'reinsDesc', enableRowGroup: false, filter: true,},
      { field: 'brokerDesc', headerName: 'Broker', sortable: true, resizable: true, tooltipField: 'brokerDesc', enableRowGroup: false, filter: true,},
      { field: 'trBrkRefNo', headerName: 'Broker Ref', sortable: true, resizable: true, tooltipField: 'trBrkRefNo', enableRowGroup: false, filter: true,},
      { field: 'trAcntDesc', headerName: 'Accounting To', sortable: true, resizable: true, tooltipField: 'trAcntDesc', enableRowGroup: false, filter: true,},
      { field: 'countryDesc', headerName: 'Reinsurer Country', sortable: true, resizable: true, tooltipField: 'countryDesc', enableRowGroup: false, filter: true,},
      { field: 'amBest', headerName: 'AM Best', sortable: true, resizable: true, tooltipField: 'amBest', enableRowGroup: false, filter: true,},
      { field: 'spRating', headerName: 'S&P', sortable: true, resizable: true, tooltipField: 'spRating', enableRowGroup: false, filter: true,},
      { field: 'trSharePerc', headerName: 'Share %', sortable: true, resizable: true, tooltipField: 'trSharePerc', enableRowGroup: false, cellStyle: { textAlign: 'right' }, 
        //valueFormatter: numberFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.trSharePerc) {            
            return Number(params.data.trSharePerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        filter: true,},
      { field: 'trPrem', headerName: '100% Premium', cellStyle: { textAlign: 'right' },
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.trPrem) {            
            return Number(params.data.trPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'minPremium', enableRowGroup: false, filter: true,},
      { field: 'trDepPrem', headerName: 'Dep Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.trDepPrem) {            
            return Number(params.data.trDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'depPremium', enableRowGroup: false, filter: true,},
      { field: 'trNcbPerc', headerName: 'NCB %', sortable: true, resizable: true, tooltipField: 'trNcbPerc', enableRowGroup: false, cellStyle: { textAlign: 'right' }, filter: true,}

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    ];
    this.currency = [
      { field: 'mttyCurrPK.tcCurr', headerName: 'Currency', sortable: true, resizable: true, tooltipField: 'mttyCurrPK.tcCurr', enableRowGroup: false, filter: true,},
      { field: 'tcFixedRate', headerName: 'ROE', sortable: true, resizable: true, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tcFixedRate) {            
            return Number(params.data.tcFixedRate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        cellStyle: { textAlign: 'right' }, tooltipField: 'tcFixedRate', enableRowGroup: false, filter: true,},
      { field: 'tcLimit', headerName: 'Limit', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tcFixedRate) {            
            return Number(params.data.tcFixedRate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'tcLimit', enableRowGroup: false, filter: true,},
      { field: 'tcDeductible', headerName: 'Excess', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tcDeductible) {            
            return Number(params.data.tcDeductible).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'tcDeductible', enableRowGroup: false, filter: true,},
      { field: 'tcAad', headerName: 'Aggregate Deductible', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
         valueGetter: function (params) {
          if(params.data && params.data.tcAad) {            
            return Number(params.data.tcAad).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'tcAad', enableRowGroup: false, filter: true,},
    ];
    this.perilCols = [
      {
        headerName: "Perils",
        field: "perilDesc",
        tooltipField: 'perilDesc', sortable: true,
        valueGetter: function (params) {
          let paramStrings1 = params.data.tpPeril + "-" + params.data.perilDesc;
          return paramStrings1;
        },
        filter: true,
      },
      { field: 'tpLimit', headerName: 'Limit', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tpLimit) {            
            return Number(params.data.tpLimit).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true,filter: true, },
      { field: 'tpDeductible', headerName: 'Excess', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tpDeductible) {            
            return Number(params.data.tpDeductible).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true,filter: true,},
      { field: 'tpMaxRec', headerName: 'Maximum Recoverable', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tpMaxRec) {            
            return Number(params.data.tpMaxRec).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true,filter: true, },
    ]
    this.reinsurerSummary = [
      // { field: 'select', headerName: 'Select ',cellRenderer: "radioButtonRenderer",sortable: true,resizable: true,enableRowGroup: true, },
      {
        field: 'custName', headerName: 'Reinsurer/Broker', linkField: 'yes', sortable: true, resizable: true, enableRowGroup: false,
        valueGetter: function (params) {
          if (params.data.ttyReinsPremPK.strCustomer != null && params.data.custName != null) {
            return params.data.ttyReinsPremPK.strCustomer + '-' + params.data.custName;
          } else {
            return params.data.custName;
          }
        },
        filter: true,
      },
      { field: 'accToDesc', headerName: 'Account To', sortable: true, resizable: true, enableRowGroup: false, filter: true,},
      { field: 'ttyReinsPremPK.strPremCurr', headerName: 'Prem CCY', sortable: true, resizable: true, enableRowGroup: false, filter: true,},
      { field: 'strCustPrem', headerName: '100% Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.strCustPrem) {            
            return Number(params.data.strCustPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, enableRowGroup: false, filter: true,},
      { field: 'strCustDepPrem', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' },
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.strCustDepPrem) {            
            return Number(params.data.strCustDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, enableRowGroup: false, filter: true,},

      {
        headerName: "Rebate (%)",
        field: "strRebatePerc",
        sortable: true,
        resizable: true,
        valueGetter: function (params) {
          if(params.data && params.data.strRebatePerc) {            
            return Number(params.data.strRebatePerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },       
        // valueFormatter: currencyFormatter,
        cellStyle: { textAlign: 'right' },
        filter: true,
      },
      {
        headerName: "Rebate Amount",
        field: "strRebateAmt",
        sortable: true,
        resizable: true,       
        valueGetter: function (params) {
          if(params.data && params.data.strRebateAmt) {            
            return Number(params.data.strRebateAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          }
        },
        //valueFormatter: currencyFormatter,
        cellStyle: { textAlign: 'right' },
        filter: true,
      },
      {
        headerName: "Net Amount",
        field: "strCustDepPrem",
        sortable: true,
        resizable: true,
        valueFormatter: currencyFormatter,
        valueGetter: netAmountCalc,
        cellStyle: { textAlign: 'right' },
        filter: false,
        // editable: true
      }, {
        headerName: 'Action',
        field: 'custName',     
        cellRenderer: actionRenderRBS,   
        // template:
        //   ` <a>
        // <i class="fa fa-eye fa-icon" style="color:#009ca6" data-action-type="Install" title="View Reinsurer" aria-hidden="true"></i>
       
        // </a>`,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },

    ];
    this.reinsurerTotal = [
      {
        field: 'custName', headerName: 'custName',filter: true,
        // width: 90 
      },
      {
        field: 'accToDesc', headerName: 'Accounting To',filter: true,
        //  width: 90 
      },
      {
        field: 'currency', headerName: 'Prem CCY',filter: true,
        // width: 90
      },
      {
        field: 'strCustPrem', headerName: '100% Premium',
        cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter ,
        valueGetter: function (params) {
          if(params.data && params.data.strCustPrem) {            
            return Number(params.data.strCustPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        filter: true,
        // , width: 120
      },
      {
        field: 'strCustDepPrem', headerName: 'Dep Premium',
        cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.strCustDepPrem) {            
            return Number(params.data.strCustDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        filter: true,
        //  width: 120
      }, {
        headerName: "Rebate (%)",
        field: "strRebatePerc",
        // valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.strRebatePerc) {            
            return Number(params.data.strRebatePerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        cellStyle: { textAlign: 'center' },
        filter: true,
      },
      {
        headerName: "Rebate Amount",
        field: "strRebateAmt",
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.strRebateAmt) {            
            return Number(params.data.strRebateAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        cellStyle: { textAlign: 'right' },
        filter: true,
      },
      {
        headerName: "Net Amount",
        field: "strCustDepNetPrem",
        valueFormatter: currencyFormatter,
        // valueGetter: function (params) {
        //   if(params.data && params.data.strCustDepNetPrem) {            
        //     return Number(params.data.strCustDepNetPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        //   } else {
        //     return '';
        //   }
        // },
        valueGetter: netAmountCalc,
        cellStyle: { textAlign: 'right' },
        filter: true,
      },
      {
        headerName: 'Action',
        field: 'action',
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },

    ];
    this.showreinsur = [
      { field: 'ttyInstPK.tinInstNo', headerName: 'Installment No', sortable: true, resizable: true, tooltipField: 'ttyInstPK.tinInstNo', enableRowGroup: false, filter: true,},
      {
        field: 'tinInstDt', headerName: 'Installment Date', sortable: true, resizable: true, tooltipField: 'tinInstDt', enableRowGroup: false,filter: true,
        valueGetter: (param) => {
          return moment(param.data.tinInstDt).format('DD/MM/YYYY')
        }
      },
      {
        field: 'tinDueDt', headerName: 'Due Date ', sortable: true, resizable: true, tooltipField: 'tinDueDt', enableRowGroup: false, filter: true,valueGetter: (param) => {
          return moment(param.data.tinDueDt).format('DD/MM/YYYY')
        }
      },
      { field: 'tinInstPerc', headerName: 'Installment %', sortable: true, resizable: true, tooltipField: 'tinInstPerc', enableRowGroup: false, filter: true,},
      { field: 'tinPremCurr', headerName: 'Contract CCY', sortable: true, resizable: true, tooltipField: 'tinPremCurrDesc', enableRowGroup: false, filter: true,},
      { field: 'tinDepPrem', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.tinDepPrem) {            
            return Number(params.data.tinDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'tinDepPrem', enableRowGroup: false, filter: true,},
      { field: 'tinInstCurr', headerName: 'Accounting CCY', sortable: true, resizable: true, tooltipField: 'tinInstCurrDesc', enableRowGroup: false ,filter: true,},
      { field: 'tinFixedRate', headerName: 'Fixed Rate', sortable: true, resizable: true, tooltipField: 'tinFixedRate', enableRowGroup: false, cellStyle: { textAlign: 'right' } ,filter: true,},
      { field: 'tinInstFc', headerName: 'Prem in Accounting CCY ', sortable: true, cellStyle: { textAlign: 'right' }, resizable: true, tooltipField: 'tinInstFc', enableRowGroup: false,
        //valueFormatter: currencyFormatter ,
        valueGetter: function (params) {
          if(params.data && params.data.tinInstFc) {            
            return Number(params.data.tinInstFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        filter: true,},
      {
        headerName: "Rebate in Accounting CCY",
        field: "tinRebateFc",
        sortable: true,
        //valueFormatter: currencyFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.tinRebateFc) {            
            return Number(params.data.tinRebateFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        cellStyle: { textAlign: 'right' },
        filter: true,        
      }, 
    ];
    this.layerCols = [
      {
        field: 'tttyLayerPremPK.stlLayer', headerName: 'Layer', sortable: true, resizable: true, tooltipField: 'tttyLayerPremPK.stlLayer', enableRowGroup: true, filter: true, valueGetter: function (params) {
          var reference = params.data.tttyLayerPremPK.stlLayer + ' - ' + params.data.layerDesc;
          return reference;
        }
      },
      { field: 'stlPremCurr', headerName: 'Prem CCY', sortable: true, resizable: true, tooltipField: 'currency', enableRowGroup: true, },
      { field: 'stlPrem', headerName: 'Layer 100% Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.stlPrem) {            
            return Number(params.data.stlPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'stlPrem', enableRowGroup: true, filter: true,},
      { field: 'stlDepPrem', headerName: 'Layer Deposit Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.stlDepPrem) {            
            return Number(params.data.stlDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'stlDepPrem', enableRowGroup: true, filter: true,},
      { field: 'stlSharePerc', headerName: 'Share %', sortable: true, resizable: true, tooltipField: 'stlSharePerc', enableRowGroup: true, cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter, filter: true,},
      { field: 'stlCustPrem', headerName: '100% Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.stlCustPrem) {            
            return Number(params.data.stlCustPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'stlCustPrem', enableRowGroup: true, filter: true,},
      { field: 'stlCustDepPrem', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' }, 
        //valueFormatter: currencyFormatter, 
        valueGetter: function (params) {
          if(params.data && params.data.stlCustDepPrem) {            
            return Number(params.data.stlCustDepPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
          }
        },
        sortable: true, resizable: true, tooltipField: 'stlCustDepPrem', enableRowGroup: true, filter: true,},

    ];

    this.LayerSummary = [
      { field: 'ttyLayerPK.tlLayer', headerName: 'Reinsurer/Broker', filter: true,},
      { field: 'tlLimitCurr', headerName: 'Account To', },
      { field: 'tlLimit', headerName: 'Prem CCY', valueFormatter: currencyFormatter, filter: true,},
      { field: 'tlDeductible', headerName: '100% Premium', valueFormatter: currencyFormatter,filter: true, },
      { field: 'tlPremCurr', headerName: 'Deposit Premium' },
      { field: 'tlPrem', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter,filter: true, },
      { field: 'tlAdjustRate', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter,filter: true, },
      { field: 'tlPremRol', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter ,filter: true,},
      { field: 'tlDepPrem', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter ,filter: true,},
      { field: 'tlDepPremPerc', headerName: 'Deposit Premium' ,filter: true,},
      { field: 'tlDepPremRol', headerName: 'Deposit Premium', cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter ,filter: true,},
      { field: 'tlNoOfReinst', headerName: 'Deposit Premium', filter: true,},
      {
        headerName: 'Action', 
        field: 'action',
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },

    ];

    this.document.body.scrollTop = 5;
    this.retrieveContractForm();
    this.retrieveLayerForm();
    this.reterievePremGrid();
    this.context = { componentParent: this };
    this.frameworkComponents = {

      radioButtonRenderer: RadiorenderComponent
    };
  }
  reportingFlg:boolean = false;
  retrieveContractForm() {

    this.loaderService.isBusy = true;

    this.treatyService.retrieveContractDetails(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      let result = resp.treatyArray;
<<<<<<< HEAD
=======
      let xol = result.thFlex10?result.thFlex10 : result.thXlType;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      let adjBasis = result.thAttachBasis;
      let contractType = result.thContractType;
      let repPeriod = result.thRepPeriod;
      this.repPeriodUnit = result.thRepPeriodUnit?result.thRepPeriodUnit:'';
      if(adjBasis == 'RAD' && contractType == 'TX'){
        this.reportingFlg = true;
      } else {
        this.reportingFlg = false;
      }
      if (result.thApprSts == 'A') {
        this.treatyService.appCodesList(ApiUrls.NON_PROPORTIONAL_TREATY_TYPE).subscribe(resp => {
          this.treatyType = resp.appcodeList;
          for (var i = 0; i < this.treatyType.length; i++) {
            this.typexol = this.treatyType[i].label
            if (this.typexol == xol) {
              this.thXlType = this.treatyType[i].item_text;
            }
          }
        })


        this.treatyService.appCodesList(ApiUrls.ATTACHMENT_BASIS_TYPE).subscribe(resp => {
          this.attachmentBasisList = resp.appcodeList;
          for (var i = 0; i < this.attachmentBasisList.length; i++) {
            this.attchbasis = this.attachmentBasisList[i].item_id
            if (this.attchbasis == result.thAttachBasis) {
              this.thAttachBasis = this.attachmentBasisList[i].item_text;
            }
          }
        })


        this.treatyService.appCodesList(ApiUrls.CONTRACT_TYPE).subscribe(resp => {
          this.contractTypeList = resp.appcodeList;
          for (var i = 0; i < this.contractTypeList.length; i++) {
            this.typecontract = this.contractTypeList[i].item_id
            if (this.typecontract == result.thContractType) {
              this.thContractType = this.contractTypeList[i].item_text;
            }
          }

        })


        this.treatyService.retrievecurrencyList().subscribe(resp => {
          this.currencyList = resp.currencyList;
          for (var i = 0; i < this.currencyList.length; i++) {
            this.Appl_curr = this.currencyList[i].key;
            if (this.Appl_curr == result.thCurr) {
              this.thCurr = this.currencyList[i].value;
            }
          }
        })
        this.treatyService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
          this.FreqList = resp;
          for (var i = 0; i < this.FreqList.length; i++) {
            let period = this.FreqList[i].key
            if (period == repPeriod) {
              this.repPeriod = this.FreqList[i].value;
            }
          }
        }, error => { });

<<<<<<< HEAD
        this.treatyService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
          this.FreqList = resp;
          for (var i = 0; i < this.FreqList.length; i++) {
            let period = this.FreqList[i].key
            if (period == repPeriod) {
              this.repPeriod = this.FreqList[i].value;
            }
          }
        }, error => { });
        
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.thRefNo = result.ttyHdrPK.thRefNo,
          this.thAmendNo = result.ttyHdrPK.thAmendNo,
          this.thTtyDesc = result.thTtyDesc,
          this.thUwYear = result.thUwYear,
          // this.thContractType= result.thContractType,
          // this.thAttachBasis= result.thAttachBasis,
          // this.thXlType= result.thXlType,
          // this.thCurr = result.thCurr,
          this.thNoOfAdj = result.thNoOfAdj;
        this.thPlaLimit = result.thPlaLimit;
        this.thEpiAmt = result.thEpiAmt,
          this.thFixedRate = result.thFixedRate,
          this.thAdjustPeriod = result.thAdjustPeriod,
          this.thClmNotifyDays = result.thClmNotifyDays,
          this.thRemarks = result.thRemarks,
          this.thCrUid = result.thCrUid,
          this.thCrDt = this.datePipe.transform(result.thCrDt, ApiUrls.DATE_FORMAT),
          this.thApprUid = result.thApprUid,
          this.thApprDt = this.datePipe.transform(result.thApprDt, ApiUrls.DATE_FORMAT),
          this.thStatus = result.thStatus,
          this.thStartDt = this.datePipe.transform(result.thStartDt, ApiUrls.DATE_FORMAT),
          this.thEndDt = this.datePipe.transform(result.thEndDt, ApiUrls.DATE_FORMAT),
          this.thApprSts = "Approved",
          this.ttyHdrPK = result.ttyHdrPK,
          this.thProgCode = result.thProgCode
        this.thSeqNo = result.thSeqNo,
          this.thRemarks = result.thRemarks

        this.loaderService.isBusy = false;

      } else {
        // alert("Status is pending");
      }

    }, error => {
      this.loaderService.isBusy = false;

    })
  }

  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }

  getDocumentTypes() {

    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', 'OW_CONTRACT')
      .subscribe(res => {
        this.documentTypes = res.appcodeList;
      }, err => {
      });
  }

  retriveRiskData() {
    this.treatyService.retrieveRisk(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      this.riskDetails = resp.riskList;
      this.totFacPremFc = 0;
      this.totFacSiFc = 0;
      this.totRiskPremFc = 0;
      this.totRiskSiFc = 0;

      for (var i = 0; i < resp.riskList.length; i++) {
        // this.riskDetails = this.riskList[i];
        this.tkSiCurr = resp.riskList[i].tkSiCurr;
        this.tkPremCurr = resp.riskList[i].tkPremCurr
        this.totFacPremFc += this.riskDetails[i].tkFacPremFc;
        this.totFacSiFc += this.riskDetails[i].tkFacSiFc;
        this.totRiskPremFc += this.riskDetails[i].tkRiskPremFc;
        this.totRiskSiFc += this.riskDetails[i].tkRiskSiFc;
      }
      if (this.totFacPremFc != 0) { this.totalFacFlag = true }
    }, error => {
      this.totFacPremFc = 0;
      if (this.totFacPremFc != 0) { this.totalFacFlag = true }
    })
  }

  retrieveEgnpiForm() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveEpiDetailsById(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      this.details = resp.egnpList;
      this.rowData = resp.egnpList;
      if (this.rowData) {
        this.pinnedBottomRowData = createData(1, this.rowData, "Bottom");
      }

      // let result: any = resp.egnpList;
      for (var i = 0; i < this.details.length; i++) {
        this.totalPremium = this.totalPremium + parseFloat(this.details[i].tePrem);
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  retrieveLayerForm() {
    this.layerPremTotal = 0;
    this.layerDepPremTotal = 0;
    this.layerRolDepPremTotal = 0;
    this.layerAdjPremTotal = 0;
    this.layerPrem = 0;
    this.layerLimit = 0;
    this.layerExcessMin = 0;
    this.excessMinVal = [];
    let obj = {
      'refNo': this.refNo,
      'amendNo': this.amendNo,
      'seqNo': this.seqNo
    }
    this.treatyService.retrieveLayerListById(obj).subscribe(result => {
      this.layerArrayList = result.layerList;
      for (var i = 0; i < this.layerArrayList.length; i++) {
        this.layerPremTotal = this.layerPremTotal + this.layerArrayList[i].tlPremRol;
        this.layerDepPremTotal = this.layerDepPremTotal + this.layerArrayList[i].tlDepPrem;
        this.layerRolDepPremTotal = this.layerRolDepPremTotal + this.layerArrayList[i].tlDepPremRol;
        this.layerAdjPremTotal = this.layerAdjPremTotal + this.layerArrayList[i].tlAdjustRate;
        this.layerPrem = this.layerPrem + this.layerArrayList[i].tlPrem
        this.excessMinVal.push(this.layerArrayList[i].tlDeductible);
        this.layerExcessMin = Math.min(...this.excessMinVal);
        this.layerLimit = this.layerLimit + this.layerArrayList[i].tlLimit;
        // this.layerDepPremPerc = this.layerDepPremPerc + this.layerArrayList[i].tlDepPremPerc;
      }
      this.layerSummaryDetails();
      this.selectedRow(this.layerArrayList[0]);
      this.loaderService.isBusy = false;
    }, error => { });
  }
  layerSummaryDetails() {
    this.layerBottomData = [
      {
        ttyLayerPK: { tlLayer: 'Total' },
        tlLimitCurr: '',
        tlLimit: this.layerLimit,
        tlDeductible: this.layerExcessMin,
        tlPremCurr: '',
        tlPrem: this.layerPrem,
        tlAdjustRate: this.layerAdjPremTotal,
        tlPremRol: this.layerPremTotal,
        tlDepPrem: this.layerDepPremTotal,
        tlDepPremPerc: '',
        tlDepPremRol: this.layerRolDepPremTotal,
        tlNoOfReinst: '',
        action: ''
      }
    ];
  }



  setSelectedValue(event, details) {
    if (event.target.checked) {
      this.selectedLayerId = details.ttyLayerPK.tlLayer;
      if (details.tlDesc != null && details.tlDesc != undefined && details.tlDesc != '') {
        this.selectedLayerDesc = details.tlDesc;
      } else { this.selectedLayerDesc = 'No Description' }

      this.showReinsurer = true;
      if (this.thContractType == 'FX') {
        this.reterieveReInsForm(this.selectedLayerId);
        this.retrieveTreatyCurrList(this.selectedLayerId);
        this.retrivePerilDetails(this.selectedLayerId);
      } else {
        this.reterieveReInsForm(this.selectedLayerId);
        this.retrieveTreatyCurrList(this.selectedLayerId);
        this.retrivePerilDetails(this.selectedLayerId);
        this.retrieveCurrPremiumList(this.selectedLayerId);
      }
    } else {
      this.selectedLayerId = "";
    }
  }

  reterieveReInsForm(layerNo) {
    this.loaderService.isBusy = true;
    this.rePremTotal = 0;
    this.reDepPremTotal = 0;
    this.reShareTotal = 0;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: layerNo,
      seqNo: this.seqNo
    };
    this.treatyService.retrieveReInsByLayer(obj).subscribe(resp => {
      this.reinsDetails = resp;
      for (var i = 0; i < this.reinsDetails.length; i++) {
        this.rePremTotal = this.rePremTotal + this.reinsDetails[i].trPrem;
        this.reDepPremTotal = this.reDepPremTotal + this.reinsDetails[i].trDepPrem;
        this.reShareTotal = this.reShareTotal + this.reinsDetails[i].trSharePerc;
      }
      this.reinsurerDetails();
      this.showInstal(this.reinsDetails[0]);
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
    })

  }
  reinsurerDetails() {
    this.reinsurerBottomData = [
      {
        reinsDesc: 'Total',
        brokerDesc: '',
        trAcntDesc: '',
        countryDesc: '',
        amBest: '',
        spRating: '',
        trSharePerc: this.reShareTotal,
        trPrem: this.rePremTotal,
        trDepPrem: this.reDepPremTotal,

      }
    ];
  }
  retrieveTreatyCurrList(layerNo) {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: layerNo,
      seqNo: this.seqNo,
      type: 'LI'
    }
    this.treatyService.retrieveCurrencyById(obj).subscribe(resp => {
      // for(var i=0;i<resp.length;i++){
      this.currencyDetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  retrieveCurrPremiumList(layerNo) {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: layerNo,
      seqNo: this.seqNo,
      type: 'PR'
    }
    this.treatyService.retrieveCurrencyPremById(obj).subscribe(resp => {
      //  for(var i=0;i<resp.length;i++){
      //   this.details=resp[i];
      //  }
      this.PremCurrdetails = resp;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  retrivePerilDetails(layerNo) {
    this.loaderService.isBusy = true;
    this.treatyService.getSelectedPerilList(layerNo, this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
<<<<<<< HEAD
      this.perilDetails = resp.perilList;
=======
      this.perilDetails = resp;
      console.log("PerilDetails", this.perilDetails)
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  reterievePremGrid() {
    let obj = {
      refNo: this.refNo,
      seqNo: this.seqNo,
      amendNo: this.amendNo

    }


    this.treatyService.retrievePremDetails(obj).subscribe(resp => {
      this.reinsumDetails = resp.reinsPremiumList;
      this.reinstPremTotal = 0;
      this.reinstDepPremTotal = 0;
      this.totalRebateAmt = 0;
      this.totalNetAmt = 0;
      
        for (var i = 0; i < this.reinsumDetails.length; i++) {
          this.reinstPremTotal = this.reinstPremTotal + this.reinsumDetails[i].strCustPrem;
          this.reinstDepPremTotal = this.reinstDepPremTotal + this.reinsumDetails[i].strCustDepPrem;
          this.totalRebateAmt = this.totalRebateAmt + this.reinsumDetails[i].strRebateAmt;
          this.totalNetAmt = this.totalNetAmt + this.reinsumDetails[i].strCustDepNetPrem;
        }
        this.reinsurerSummaryDetails();     
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.reinsumDetails = [];
    })
  }


  reinsurerSummaryDetails() {
    this.reinsurerSummaryBottomData = [

      {
        custName: 'Total',
        // custName: '',
        // accToDesc: '',
        strCustPrem: this.reinstPremTotal,
        strCustDepPrem: this.reinstDepPremTotal,
        strRebatePerc: '',
        strRebateAmt: this.totalRebateAmt,
        strCustDepNetPrem: this.totalNetAmt,
        action: '',
      }
    ];
  }
  showInstalment(event, val: any) {
    if (event.target.checked) {
      this.reinsBrokerId = val.custName;
      this.refNo = val.ttyReinsPremPK.strRefNo;
      this.amendNo = val.ttyReinsPremPK.strAmendNo;
      this.customer = val.ttyReinsPremPK.strCustomer;
      this.InstallmentFlag = true;
    } else {
      this.reinsBrokerId = ""
    }
    this.reterieveReInstDetails();
  }
  reterieveReInstDetails() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amendNo: this.amendNo,
      customer: this.customer,
      seqNo: this.seqNo
    }
    this.treatyService.reterieveReInst(obj).subscribe(resp => {
      this.reInstDetails = resp.instDetailsList;
      //this.reInstData = resp.instDetailsList
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  viewLayer(data: any) {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveLayerDetails(data).subscribe(resp => {
      this.totstlPrem = resp.reinsLayerList[0].totStlPrm;
      this.totStlDepPrm = resp.reinsLayerList[0].totStlDepPrm;
      this.totCustPrm = resp.reinsLayerList[0].totCustPrm;
      this.totCustdepPrm = resp.reinsLayerList[0].totCustdepPrm;
      this.custName = data.custName
      this.layerSumDetails = resp.reinsLayerList;
      this.ReinsurerFlag = true;
<<<<<<< HEAD
      this.open(this.content2, 'modal-lg');
=======
      //this.modalService.open(this.content2, { size: 'modal-lg', windowClass: 'vw-80' }).result.then((result) => { }, (reason) => { });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.loaderService.isBusy = false;

    }, error => {
    })


  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  viewLayerDetails(event, details) {
    this.selectedLayerId = details.ttyLayerPK.tlLayer;
    if (details.tlDesc != null && details.tlDesc != undefined && details.tlDesc != '') {
      this.selectedLayerDesc = details.tlDesc;
    } else { this.selectedLayerDesc = 'No Description' }
    this.treatyService.retrieveReInstDetails(this.refNo, this.amendNo, this.seqNo, details.ttyLayerPK.tlLayer).subscribe(resp => {
      this.reInsurerArrayList = resp.reInstList;
    }, error => { });
    this.treatyService.appCodesList(ApiUrls.APP_RATE_TYPE).subscribe(resp => {
      this.rateList = resp.appcodeList;
      for (var i = 0; i < this.rateList.length; i++) {
        this.RateType = this.rateList[i].item_id
        if (this.RateType == details.tlRateType) {
          this.tlRateType = this.rateList[i].item_text;
        }
      }
    });
    this.tlLimitCurr = details.tlLimitCurr,
      this.tlLimit = this.cpipe.transform(details.tlLimit),
      this.tlDeductible = this.cpipe.transform(details.tlDeductible),
      this.tlAad = details.tlAad,
      this.tlPremCurr = details.tlPremCurr,
      // this.tlRateType= details.tlRateType,
      this.tlAdjustRate = details.tlAdjustRate,
      this.tlBcLoadFact = details.tlBcLoadFact,
      this.tlBcMinRate = this.cpipe.transform(details.tlBcMinRate),
      this.tlBcMinRate = this.cpipe.transform(details.tlBcMaxRate),
      this.tlPrem = this.cpipe.transform(details.tlPrem),
      this.tlPremRol = details.tlPremRol,
      this.tlMinPrem = this.cpipe.transform(details.tlMinPrem),
      this.tlDepPremPerc = details.tlDepPremPerc,
      this.tlDepPrem = this.cpipe.transform(details.tlDepPrem),
      this.tlDepPremRol = details.tlDepPremRol,
      this.tlNoOfReinst = details.tlNoOfReinst,
      this.tlMaxRec = this.cpipe.transform(details.tlMaxRec);
    this.tlReinstUnltdYn = details.tlReinstUnltdYn == "1" ? true : false

<<<<<<< HEAD
    this.open(this.content, 'modal-lg');

=======
    //this.modalService.open(this.content, { size: 'modal-lg' }).result.then((result) => { }, (reason) => { });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }



  onGridSizeChanged(params) {
<<<<<<< HEAD
    var gridWidth = document.getElementById("engpiGrid").offsetWidth;
=======
    console.log(params)
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  rowGroupOpened(params) {
    params.api.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  public onRowClicked(e, title) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      // this.selectedRow(data);
      if ('layer' == title) {
        this.selectedRow(data);
      } else if (title == 'reinst') {
        this.showInstal(data);
      }
      //  else{
      //    this.viewLayer(data);
      //  }
      switch (actionType) {
        case "View":
          return this.viewLayerDetails(e, data);
        case 'Install':
          return this.viewLayer(data);
      }
    }

  }
  showInstal(data) {
    this.reinsBrokerId = data.custName;
    if (data && data.ttyReinsPremPK) {
      this.refNo = data.ttyReinsPremPK.strRefNo;
      this.amendNo = data.ttyReinsPremPK.strAmendNo;
      this.customer = data.ttyReinsPremPK.strCustomer;
    }
    this.InstallmentFlag = true;
    this.reterieveReInstDetails();
  }

  selectedRow(data) {
    // if (event.target.checked) {
    this.selectedLayerId = data.ttyLayerPK.tlLayer;
    if (data.tlDesc != null && data.tlDesc != undefined && data.tlDesc != '') {
      this.selectedLayerDesc = data.tlDesc;
    } else { this.selectedLayerDesc = 'No Description' }
    this.showReinsurer = true;
    if (this.thContractType == 'FX') {
      this.reterieveReInsForm(this.selectedLayerId);
      this.retrieveTreatyCurrList(this.selectedLayerId);
      this.retrivePerilDetails(this.selectedLayerId);
    } else {
      this.reterieveReInsForm(this.selectedLayerId);
      this.retrieveTreatyCurrList(this.selectedLayerId);
      this.retrivePerilDetails(this.selectedLayerId);
      this.retrieveCurrPremiumList(this.selectedLayerId);
    }
    // } else {
    // this.selectedLayerId = "";
    // }

  }


  onQuickFilterChanged(mode) {
    if (mode == 'egnp') {
      this.gridApiegnp.setQuickFilter(this.egnpSearchValue);
    } else if (mode == 'layer') {
      this.gridApilayer.setQuickFilter(this.layerSearchValue);
    } else if (mode == 'reinsurer') {
      this.gridApireinsurer.setQuickFilter(this.reinsurerSearchValue);
    } else if (mode == 'limit') {
      this.gridApilimit.setQuickFilter(this.limitSearchValue);
    } else if (mode == 'premium') {
      this.gridApipremium.setQuickFilter(this.premiumSearchValue);
    } else if (mode == 'peril') {
      this.gridApiperil.setQuickFilter(this.perilSearchValue);
    } else if (mode == 'reinst') {
      this.gridApireinst.setQuickFilter(this.reinstSearchValue);
    } else if (mode == 'install') {
      this.gridApiinstall.setQuickFilter(this.installSearchValue);
    } else if (mode == 'summary') {
      this.gridApi.setQuickFilter(this.summarySearchValue);
    }
  }
  onGridEgnpReady(params) {
    this.gridApiegnp = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiegnp.sizeColumnsToFit();
  }
  displayedEgnpRowCount() {
    if (this.gridApiegnp) {
      return this.gridApiegnp.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridLayerReady(params) {
    this.gridApilayer = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApilayer.sizeColumnsToFit();
  }
  displayedLayerRowCount() {
    if (this.gridApilayer) {
      return this.gridApilayer.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridReinsurerReady(params) {
    this.gridApireinsurer = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApireinsurer.sizeColumnsToFit();
  }
  displayedReinsurerRowCount() {
    if (this.gridApireinsurer) {
      return this.gridApireinsurer.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridLimitReady(params) {
    this.gridApilimit = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApilimit.sizeColumnsToFit();
  }
  displayedLimitRowCount() {
    if (this.gridApilimit) {
      return this.gridApilimit.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridPremiumReady(params) {
    this.gridApipremium = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApipremium.sizeColumnsToFit();
  }
  displayedPremiumRowCount() {
    if (this.gridApipremium) {
      return this.gridApipremium.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridPerilReady(params) {
    this.gridApiperil = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiperil.sizeColumnsToFit();
  }
  displayedPerilRowCount() {
    if (this.gridApiperil) {
      return this.gridApiperil.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridReinstReady(params) {
    this.gridApireinst = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApireinst.sizeColumnsToFit();
  }
  displayedReinstRowCount() {
    if (this.gridApireinst) {
      return this.gridApireinst.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridinstallmentReady(params) {
    this.gridApiinstall = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiinstall.sizeColumnsToFit();
  }
  displayedInstallmentRowCount() {
    if (this.gridApiinstall) {
      return this.gridApiinstall.getDisplayedRowCount();
    } else {
      return;
    }
  }

  groupRowAggNodes(nodes) {
    var result = {
      tePrem: 0,
    };
    nodes.forEach(function (node) {
      var data = node.group ? node.aggData : node.data;
      if (typeof data.tePrem === "number") {
        result.tePrem += data.tePrem;
      }
    });
    return result;
  }
  closeModal() {
    this.modalService.hide();
  }
  pageChanged(event: any, mode): void {
    // this.gridApi.paginationGoToPage(event.page - 1);
    if (mode == 'egnp') {
      this.gridApiegnp.paginationGoToPage(event.page - 1);
    } else if (mode == 'layer') {
      this.gridApilayer.paginationGoToPage(event.page - 1);
    } else if (mode == 'reinsurer') {
      this.gridApireinsurer.paginationGoToPage(event.page - 1);
    } else if (mode == 'limit') {
      this.gridApilimit.paginationGoToPage(event.page - 1);
    } else if (mode == 'premium') {
      this.gridApipremium.paginationGoToPage(event.page - 1);
    } else if (mode == 'peril') {
      this.gridApiperil.paginationGoToPage(event.page - 1);
    } else if (mode == 'reinst') {
      this.gridApireinst.paginationGoToPage(event.page - 1);
    } else if (mode == 'install') {
      this.gridApiinstall.paginationGoToPage(event.page - 1);
    } else if (mode == 'summary') {
      this.gridApi.paginationGoToPage(event.page - 1);
    }
  }

  onPaginationCountChange(event: any, mode) {
    // this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    // this.gridApi.paginationGoToPage(0);
    if (mode == 'egnp') {
      this.gridApiegnp.paginationSetPageSize(this.showEgnpOptionSelected);
      this.gridApiegnp.paginationGoToPage(0);
    } else if (mode == 'layer') {
      this.gridApilayer.paginationSetPageSize(this.showLayerOptionSelected);
      this.gridApilayer.paginationGoToPage(0);
    } else if (mode == 'reinsurer') {
      this.gridApireinsurer.paginationSetPageSize(this.showReinsurerOptionSelected);
      this.gridApireinsurer.paginationGoToPage(0);
    } else if (mode == 'limit') {
      this.gridApilimit.paginationSetPageSize(this.showLimitOptionSelected);
      this.gridApilimit.paginationGoToPage(0);
    } else if (mode == 'premium') {
      this.gridApipremium.paginationSetPageSize(this.showPremiumEntriesSelected);
      this.gridApipremium.paginationGoToPage(0);
    } else if (mode == 'peril') {
      this.gridApiperil.paginationSetPageSize(this.showPerilEntriesPeril);
      this.gridApiperil.paginationGoToPage(0);
    } else if (mode == 'reinst') {
      this.gridApireinst.paginationSetPageSize(this.showReinstOptionSelected);
      this.gridApireinst.paginationGoToPage(0);
    } else if (mode == 'install') {
      this.gridApiinstall.paginationSetPageSize(this.showInstallOptionSelected);
      this.gridApiinstall.paginationGoToPage(0);
    } else if (mode == 'summary') {
      this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
      this.gridApi.paginationGoToPage(0);
    }
  }

}
function currencyFormatter(params) {
  if (params && params.value ) {
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));    
  } else {
    return '';
  }
}
// return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value.toFixed(2)));

function numberFormatter(params) {
  return params.value.toFixed(2);
}
function createData(count, data, prefix) {
  var result = [];
  var egnpiPremium = 0;
  for (var i = 0; i < data.length; i++) {
    egnpiPremium = egnpiPremium + data[i].tePrem
  }
  for (var i = 0; i < count; i++) {
    result.push({
      companyName: 'Total',
      tePrem: egnpiPremium,
    });
  }
  return result;
}
function netAmountCalc(params) {
  if (params.data.strCustDepPrem != null && params.data.strRebateAmt != null) {
    return params.data.strCustDepPrem - params.data.strRebateAmt;
  } else if (params.data.strCustDepPrem != null && params.data.strRebateAmt == null) {
    return params.data.strCustDepPrem;
  } else {
    return '';
  }
}
function actionRenderLayer(params) {
  if (params.value === undefined || params.value === null) {
     return '';
  } else {
     return `<a>
     <i class="fa fa-eye fa-icon" style="color:#009ca6" data-action-type="View" title="View Layer" aria-hidden="true"></i>
     </a>`;
  }
}
function actionRenderRBS(params) {
  if (params.value === undefined || params.value === null) {
     return '';
  } else {
     return ` <a>
     <i class="fa fa-eye fa-icon" style="color:#009ca6" data-action-type="Install" title="View Reinsurer" aria-hidden="true"></i>    
     </a>`;
  }
}