import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyLayerFormComponent } from './treaty-layer-form.component';

describe('TreatyLayerFormComponent', () => {
  let component: TreatyLayerFormComponent;
  let fixture: ComponentFixture<TreatyLayerFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyLayerFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyLayerFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
