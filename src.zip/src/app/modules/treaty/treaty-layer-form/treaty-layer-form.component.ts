<<<<<<< HEAD
import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, EventEmitter, Inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
=======
import { Component, EventEmitter, Inject, Input, OnInit, Output, ViewChild, ElementRef } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { DOCUMENT } from '@angular/common';
import { SessionStorageService } from 'angular-web-storage';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
<<<<<<< HEAD
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
=======
import { LoaderService } from 'src/app/services/loader.service';
import { BsModalService } from 'ngx-bootstrap/modal';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

declare var $: any;
@Component({
  selector: 'app-treaty-layer-form',
  templateUrl: './treaty-layer-form.component.html',
  styleUrls: ['./treaty-layer-form.component.css'],
  providers: [MycurrencyPipe]
})

export class TreatyLayerFormComponent implements OnInit {
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  quickSearchValue: any;
  gridApi: any;
  public columnDefs;
  public layerColumns;
  public defaultColDef;
  public getRowHeight;
  public context;
  public frameworkComponents;
  pinnedBottomRowData: any;
  excessMin: number[];
  cols = [];
  layerForm: UntypedFormGroup;
  layerArrayList: any[];
  bottomData: any[];
  selectedLayerId: string;
  formDetails: any;
  reInsurerArrayList: any;
  totalPremium: number = 0;
  minimumExcess: number = 0;
  maxExcess: number = 0;
  maxlimit: number = 0;
  totalLimit: number = 0;
  totalDepPremium: number = 0;
  @Input() refNo: string;
  @Input() amendNo: string;
  layerAction: string = 'add';
  @Input() egnpiAmt: number;
  @Input() seqNo: number;
  @Input() contractType;
  @Input() basecurr;
  @Input() fullContractType: string;
  @Input() egnpiLabel: string;
  @Input() xolType;
  @Output() layerEvent = new EventEmitter();
  @Output() sendLayerHeading = new EventEmitter();
  @Input() facGnpiData: any;
  @Input() amndSrNo: any;
  //baseCurr: string = this.session.get('baseCurrency');
  AdjFlag: boolean;
  BurnFlag: boolean;
  showForm: boolean;
  FlatFlag: boolean;
  premium_title: string;
  rol_premium_title: string;
  rateList: any;
  currencyList: any;
  coverageBasisList: any;
  ActionBtn: boolean;
  layerLength: number;
  layerBean: any;
  layercount: any;
  coverageFlag: boolean;
  selectedRowId: any;
  LayerData: any;
  LayerName: any;
  maxtkTxnFacSiFc: any = 0;

  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
<<<<<<< HEAD
=======
    private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private wizardHelper: TreatyWizardHelperService,
    private cpipe: MycurrencyPipe,
    @Inject(DOCUMENT) private document: Document,
    private modalService: BsModalService) { }


  ngOnInit() {
    this.loaderService.isBusy = true;
    this.agGridOptions();
    if (this.facGnpiData && this.facGnpiData.facList) {
      this.maxtkTxnFacSiFc = Math.max(...this.facGnpiData.facList.map(o => o.tkTxnFacSiFc));
      console.log(this.maxtkTxnFacSiFc)
    }
    this.columnDefs = [
      {
        headerName: "Select",
        field: 'ttyLayerPK.tlLayer',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
<<<<<<< HEAD
        filter: false,
        sortable: false,
=======
        sortable: false,
        filter: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        enableRowGroup: false,
      },
      {
        headerName: "Layer",
        field: "tlDesc",
        sortable: true,
        filter: true,
        //tooltipField: 'tlDesc',
        cellRenderer: function (params) {
          if (params.data && params.data.tlDesc && params.data.ttyLayerPK && params.data.ttyLayerPK.tlLayer) {
            return params.data.ttyLayerPK.tlLayer + " - " + params.data.tlDesc;
          } else if (params.data && !params.data.tlDesc && params.data.ttyLayerPK && params.data.ttyLayerPK.tlLayer) {
            return params.data.ttyLayerPK.tlLayer;
          } else {
            return '';
          }
        },
        valueGetter: function (params) {
          if (params.data && params.data.tlDesc && params.data.ttyLayerPK && params.data.ttyLayerPK.tlLayer) {
            return params.data.ttyLayerPK.tlLayer + " - " + params.data.tlDesc;
          } else if (params.data && !params.data.tlDesc && params.data.ttyLayerPK && params.data.ttyLayerPK.tlLayer) {
            return params.data.ttyLayerPK.tlLayer;
          } else {
            return '';
          }
        },
      },
      {
        headerName: "Limit CCY",
        field: "tlLimitCurr",
        sortable: true,
        filter: true,
        //tooltipField: 'tlLimitCurr',
        // valueGetter: function (params) {
        //   return params.data.tlLimitCurr;
        // },
        cellStyle: { textAlign: 'left' }
      },
      {
        headerName: "Premium Limit",
        field: "tlLimit",
        sortable: true,
        filter: true,
        //tooltipField: 'tlLimit',
        valueGetter: function (params) {
          if (params.data && params.data.tlLimit) {
            // let excess = Number(params.data.tlLimit).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');           
            // return excess;
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlLimit));
          } else if (params.data && !params.data.tlLimit) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        //valueFormatter: currencyFormatter,
        cellStyle: { textAlign: 'right' },
        //cellRenderer: decimalFormatter
      },
      {
        headerName: "Excess",
        field: "tlDeductible",
        sortable: true,
        filter: true,
        //tooltipField: 'tlDeductible',
        valueGetter: function (params) {
          if (params.data && params.data.tlDeductible) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlDeductible));
          } else if (params.data && !params.data.tlDeductible) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Prem CCY",
        field: "tlPremCurr",
        sortable: true,
        filter: true,
        //tooltipField: 'tlPremCurr',
        valueGetter: function (params) {
          if (params.data && params.data.tlPremCurr) {
            return params.data.tlPremCurr;
          } else {
            return '';
          }
        },
        cellStyle: { textAlign: 'left' }
      },
      {
        headerName: "Premium",
        field: "tlPrem",
        sortable: true,
        filter: true,
        valueGetter: function (params) {
          if (params.data && params.data.tlPrem) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlPrem));
          } else if (params.data && !params.data.tlPrem) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Rate",
        field: "tlAdjustRate",
        sortable: true,
        filter: true,
        //tooltipField: 'tlAdjustRate',
        valueGetter: function (params) {
          if (params.data && params.data.tlAdjustRate) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlAdjustRate));
          } else if (params.data && !params.data.tlAdjustRate) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        // valueGetter: function (params) {
        //   return params.data.tlAdjustRate;
        // },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "RoL 100% Prem",
        field: "tlPremRol",
        sortable: true,
        filter: true,
        //tooltipField: 'tlPremRol',
        valueGetter: function (params) {
          if (params.data && params.data.tlPremRol) {
            //return Intl.NumberFormat('en-US').format((params.data.tlDeductible).toFixed(2));
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlPremRol));
          } else if (params.data && !params.data.tlPremRol) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Dep Prem",
        field: "tlDepPrem",
        sortable: true,
        filter: true,
        //tooltipField: 'tlDepPrem',
        valueGetter: function (params) {
          if (params.data && params.data.tlDepPrem) {
            //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.data.tlDepPrem).toFixed(2));
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlDepPrem));
          } else if (params.data && !params.data.tlDepPrem) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Dep Prem %",
        field: "tlDepPremPerc",
        sortable: true,
        filter: true,
        //tooltipField: 'tlDepPremPerc',
        valueGetter: function (params) {
          if (params.data && params.data.tlDepPremPerc) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlDepPremPerc));
          } else if (params.data && !params.data.tlDepPremPerc) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      /*{
        headerName: "Deposit Premium",
        field: "tlPremCurr&tlDepPrem&tlDepPremPerc",
        sortable: true,
        filter:true,
        tooltipField: 'tlPremCurr&tlDepPrem&tlDepPremPerc',
        valueGetter: function (params) {
          let paramString2;
          let paramStrings1 = params.data.tlPremCurr+' '+Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format( (params.data.tlDepPrem).toFixed(2));
          if (params.data.tlAdjustRate != null) {
            paramString2 = ' (' + params.data.tlDepPremPerc + '%)';
          } else {
            paramString2 = '';
          }
          return paramStrings1 + paramString2;
        },
        cellStyle: { textAlign: 'right',fontWeight:600 }
      },*/
      {
        headerName: "RoL Dep Prem",
        field: "tlDepPremRol",
        sortable: true,
        filter: true,
        //tooltipField: 'tlDepPremRol',
        //valueFormatter: numberFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.tlDepPremRol) {
            //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.data.tlDepPrem).toFixed(2));
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.tlDepPremRol));
          } else if (params.data && !params.data.tlDepPremRol) {
            return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
          } else {
            return;
          }
        },
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Reinst",
        field: "tlNoOfReinst",
        sortable: true,
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: "Action",
<<<<<<< HEAD
        template:
          ` <a>
          <i class="fa fa-file-pen fa-icon" font-size: 1.55em" data-action-type="Edit" title="Edit" aria-hidden="true"></i>
          &nbsp;
          <i class="Px-2 fa fa-trash fa-icon"   font-size: 1.55em" data-action-type="Remove"  title="Delete" aria-hidden="true"></i>
          </a>`,
        cellStyle: { textAlign: 'center' }
=======
        field: 'ttyLayerPK.tlLayer',
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    ];
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    // this.getRowHeight = function (params) {
    //   var isBodyRow = params.node.rowPinned === undefined;
    //   var isFullWidth = params.node.data.fullWidth;
    //   if (isBodyRow && isFullWidth) {
    //     return 55;
    //   } else {
    //     return 40;
    //   }
    // };
    this.document.body.scrollTop = 15;
    this.LoadGrid();
    this.LayerFormGroup();
    this.layerColumns = [
      {
        headerName: "Select",
        field: "ttyLayerPK.tlLayer",
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      { headerName: "Layer", field: "ttyLayerPK1" },
      { headerName: "Layer Cur", field: "tlLimitCurr" },
      { headerName: "Limit", field: "tlLimit", cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter },
      { headerName: "Excess", field: "tlDeductible", cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter },
      { headerName: "Premium cur", field: "tlPremCurr" },
      { headerName: "Premium", field: "tlPrem", cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter },
      { headerName: "Rate", field: "tlAdjustRate" },
      { headerName: "Rol 100%", field: "tlPremRol" },
      { headerName: "Dep Premium", field: "tlDepPrem", cellStyle: { textAlign: 'right' }, valueFormatter: currencyFormatter },
      { headerName: "Dep Premium %", field: "tlDepPremPerc" },
      { headerName: "Rol Dep Premium", field: "tlDepPremRol" },
      { headerName: "Reinst", field: "tlNoOfReinst" },
      { headerName: "Action", field: "action" },
    ]
  }

  LayerFormGroup() {
    this.layerForm = this.fb.group({
      tlAttachBasis: '',
      tlLimitCurr: ["", Validators.required],
      tlLimit: ['', Validators.required],
      tlDeductible: ["", Validators.required],
      tlAad: '',
      tlPremCurr: [{ value: '', disabled: true, }, Validators.required],
      tlRateType: ['', Validators.required],
      tlAdjustRate: '',
      tlBcLoadFact: ['', !this.BurnFlag ? "" : Validators.required],
      tlBcMinRate: ['', !this.BurnFlag ? "" : Validators.required],
      tlBcMaxRate: ['', !this.BurnFlag ? "" : Validators.required],
      tlPrem: ['', Validators.required],
      //tlPremRol: ['', Validators.required],
      tlPremRol: [''],
      tlMinPrem: '',
      tlDepPremPerc: ['', "FX" == this.contractType ? "" : Validators.required],
      tlDepPrem: '',
      tlDepPremRol: '',
      tlReinstUnltdYn: false,
      tlNoOfReinst: '0',
      tlMaxRec: '',
      tlStatus: 'A',
      tlCrUid: "",
      tlCrDt: '',
      ttyLayerPK: '',
      reinsurerList: this.fb.array([]),
      tlDesc: ['', Validators.required]
    });
  }

  dropdown() {
    this.treatyService.retrievecurrencyList().subscribe(resp => {
      this.currencyList = resp.currencyList;

    });
    this.treatyService.appCodesList(ApiUrls.APP_RATE_TYPE).subscribe(resp => {
      if ('FX' == this.contractType) {
        this.rateList = $.grep(resp.appcodeList, function (e) {
          return e.item_id != 'BR';
        });
        //this.rateList = data;
      } else {
        this.rateList = resp.appcodeList;
      }
    });
    this.treatyService.retrieveCoverageBasisList(ApiUrls.APP_COVERAGE_BASIS_TYPE, ApiUrls.NON_PROPORTIONAL_TREATY_TYPE, this.xolType).subscribe(resp => {
      this.coverageBasisList = resp.appcodeList;
    })
  }

  LoadGrid() {
    this.totalPremium = 0;
    this.totalDepPremium = 0;
    this.maxExcess = 0;
    this.maxlimit = 0;
    let obj = {
      'refNo': this.refNo,
      'amendNo': this.amendNo,
      'seqNo': this.seqNo
    }
    this.treatyService.retrieveLayerListById(obj).subscribe(result => {
      this.loaderService.isBusy = false;
      this.excessMin = [];
      this.layerArrayList = result.layerList;
      if (this.layerArrayList) {
        this.pinnedBottomRowData = createData(1, this.layerArrayList, this.excessMin);
      }
      if (this.layerArrayList && this.layerArrayList.length > 0) {
        this.selectedRowId = this.layerArrayList[0].ttyLayerPK.tlLayer;
        this.selectedRowData({ data: this.layerArrayList[0] });
      } else {
        this.selectedRowData({ data: this.layerArrayList[0] });
      }
      var excess = 0;
      for (var i = 0; i < this.layerArrayList.length; i++) {
        this.totalPremium = this.totalPremium + this.layerArrayList[i].tlPrem;
        this.totalDepPremium = this.totalDepPremium + this.layerArrayList[i].tlDepPrem;
        this.maxExcess = this.maxExcess + this.layerArrayList[i].tlDeductible;
        this.excessMin.push(this.layerArrayList[i].tlDeductible);
        //this.maxExcess = Math.min(...this.excessMin);
        this.maxlimit = this.maxlimit + this.layerArrayList[i].tlLimit;
      }
      this.totalLimit = this.maxExcess + this.maxlimit - this.minimumExcess;
      this.layerSummaryDetails();
      this.layerLength = this.layerArrayList.length;
      this.layercount = this.layerLength + 1;
      this.showForm = false
      this.layerForm.reset();
    });
  }

  layerSummaryDetails() {
    this.bottomData = [
      {
        ttyLayerPK: { tlLayer: 'Total' },
        tlLimit: this.maxlimit,
        tlDeductible: this.maxExcess,
        tlPrem: this.totalPremium,
        tlDepPrem: this.totalDepPremium,
      }
    ];
  }

  addLayer() {
    this.dropdown();
    var controlIndex = 0
    this.layerForm.reset();
    this.showForm = true
    this.ActionBtn = false;
    this.addReInstList(0);
    this.AdjFlag = true;
    this.BurnFlag = false;
    this.FlatFlag = false;
    this.layerForm.get('tlDesc').setValue('Layer ' + this.layercount);
    var flag = this.layerForm.get('tlReinstUnltdYn').value;
    var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value);
    if (flag == true) {
      this.layerForm.get('tlNoOfReinst').setValue("0");
      this.layerForm.get('tlNoOfReinst').disable();
      this.layerForm.get('tlMaxRec').setValue("0");
      this.layerForm.get('tlMaxRec').enable();
      this.addReInstList(0);
    } else {
      this.layerForm.get('tlNoOfReinst').setValue("0");
      this.layerForm.get('tlNoOfReinst').enable();
      this.layerForm.get('tlMaxRec').setValue(Layer_limit);
      this.layerForm.get('tlMaxRec').disable();
      this.addReInstList(0);
    }
    if (this.contractType == 'TX') {
      this.coverageFlag = true;
      this.layerForm.get('tlAttachBasis').setValue(this.xolType);
      this.layerForm.get('tlAttachBasis').enable();
    } else {
      this.coverageFlag = false;
      this.layerForm.get('tlAttachBasis').setValue('');
      this.layerForm.get('tlAttachBasis').disable();
    }

    if (this.contractType == 'FX' && this.layerLength == 0) {
      this.layerForm.get('tlDeductible').setValue('0');
      this.layerForm.get('tlDeductible').disable();
      this.layerForm.get('tlLimit').setValue(this.maxtkTxnFacSiFc);
    } else {
      this.layerForm.get('tlDeductible').enable();
    }
    if (this.contractType == 'FX') {
      this.layerForm.patchValue({ tlRateType: 'FR' });
      this.layerForm.get('tlDepPremPerc').setValue("100.0000000");
      this.AdjFlag = false;
      this.BurnFlag = false;
      this.FlatFlag = true;
      // this.disabled = true;
      this.layerForm.get('tlDepPremPerc').clearValidators();
      this.layerForm.get('tlDepPremPerc').updateValueAndValidity();
    } else {
      this.disabled = false;
      this.layerForm.get('tlDepPremPerc').setValidators([Validators.required]);
      this.layerForm.get('tlDepPremPerc').updateValueAndValidity();
    }
    if ("WXL" == this.xolType && this.layercount == 1) {
      this.layerForm.get('tlDeductible').setValue('0');
      this.layerForm.get('tlDeductible').disable();
    }
    this.layerForm.patchValue({
      tlLimitCurr: this.basecurr,
      tlPremCurr: this.basecurr
    });
    if (this.layercount != 1) {
      var prevLayerLimit = parseFloat(this.layerArrayList[this.layercount - 2].tlLimit)
      var prevLayerExcess = parseFloat(this.layerArrayList[this.layercount - 2].tlDeductible)
      var currentLayerExcess = prevLayerLimit + prevLayerExcess

      this.layerForm.get('tlDeductible').setValue(currentLayerExcess);
    }

  }
  getPremiumCurrency(event) {
    this.layerForm.patchValue({
      tlPremCurr: event.value
    });

  }

  saveLayer() {
    this.layerForm.get('tlAttachBasis').enable();
    this.layerForm.get('tlDeductible').enable();
    if (this.layerForm.valid) {
      var limit = this.layerForm.get('tlLimit').value;
      var tlDeductible = this.layerForm.get('tlDeductible').value;
      var tlAad = this.layerForm.get('tlAad').value;
      var tlMinPrem = this.layerForm.get('tlMinPrem').value ? this.layerForm.get('tlMinPrem').value.toString().replace(/,/g, '') : 0
      var tlPrem = this.layerForm.get('tlPrem').value;
      var tlPremRol = this.layerForm.get('tlPremRol').value ? this.layerForm.get('tlPremRol').value.toString().replace(/,/g, '') : 0
      var tlDepPrem = this.layerForm.get('tlDepPrem').value ? this.layerForm.get('tlDepPrem').value.toString().replace(/,/g, '') : 0
      var tlDepPremPerc = this.layerForm.get('tlDepPremPerc').value
      // ? this.layerForm.get('tlDepPremPerc').value.replace(/,/g, '') : 0
      var tlDepPremRol = this.layerForm.get('tlDepPremRol').value ? this.layerForm.get('tlDepPremRol').value.toString().replace(/,/g, '') : 0
      var tlMaxRec = this.layerForm.get('tlMaxRec').value ? this.layerForm.get('tlMaxRec').value.toString().replace(/,/g, '') : 0
      tlMinPrem = parseFloat(tlMinPrem);
      tlDepPrem = parseFloat(tlDepPrem);
      tlDepPremPerc = parseFloat(tlDepPremPerc);

      if (this.layerForm.get('tlReinstUnltdYn').value == true) {
        this.layerForm.get('tlReinstUnltdYn').setValue('1');
      } else {
        this.layerForm.get('tlReinstUnltdYn').setValue('0');
      }

      let param = {
        tlRefNo: this.refNo,
        tlSeqNo: this.seqNo,
        tlAmendNo: this.amendNo,
        tlLayer: this.layercount
      }
      this.layerForm.patchValue({
        ttyLayerPK: param,
        tlLimit: limit,
        tlDeductible: tlDeductible,
        tlMinPrem: tlMinPrem,
        tlAad: tlAad,
        tlPrem: tlPrem,
        tlPremRol: tlPremRol,
        tlDepPrem: tlDepPrem,
        tlDepPremPerc: tlDepPremPerc,
        tlDepPremRol: tlDepPremRol,
        tlMaxRec: tlMaxRec,
        tlStatus: 'A',
        tlCrDt: new Date(),
        tlCrUid: this.session.get('userId')
      })
      this.layerBean = this.layerForm.getRawValue();
      let resurerBean: any = this.layerBean.reinsurerList;
      if (tlMinPrem > tlDepPrem) {
        this.toastService.warning("Minimum Premium should be less than Deposit Premium");
        // this.editLayer(this.layerBean);
      } else if (tlDepPremPerc > 100) {
        this.toastService.warning("Deposit Premium should be less than 100");
      } else {
        this.treatyService.saveLayerInfo(this.layerBean, this.amndSrNo).subscribe(resp => {
          if (resurerBean.length > 0) {
            for (var i = 0; i < resurerBean.length; i++) {
              resurerBean[i].tiLayer = param.tlLayer;
              resurerBean[i].ticrUid = this.session.get('userId');
              resurerBean[i].tiCrDt = new Date();
            }
            this.treatyService.saveReInstDetails(resurerBean).subscribe(resp => {
              this.loaderService.isBusy = false;
              this.toastService.success("Successfully Saved");
            })
          } else {
            this.toastService.success("Successfully Saved");
          }
          this.LoadGrid();
          if (this.contractType === 'FX') {
            var facGNPIList;
            var perilData = [];
            this.maxtkTxnFacSiFc = Math.max(...this.facGnpiData.facList.map(o => o.tkTxnFacSiFc));
            console.log(this.maxtkTxnFacSiFc)
            this.facGnpiData.facList.forEach(element => {
              facGNPIList = {
                ttyPerilPK: {
                  tpRefNo: element.ttyRiskPK.tkRefNo,
                  tpSeqNo: element.ttyRiskPK.tkSeqNo,
                  tpAmendNo: element.ttyRiskPK.tkAmendNo,
                  tpLayer: this.layerBean.ttyLayerPK.tlLayer,
                  tpPeril: element.ttyRiskPK.tkPeril
                },
                tpStatus: 'A',
                tpCrUid: element.tkCrUid,
                tpCrDt: element.tkCrDt
              };
              perilData.push(facGNPIList)
            });
            this.treatyService.facPerilSave(perilData, this.layerBean.ttyLayerPK.tlLayer).subscribe(resp => {
            }, error => {
              this.toastService.error(error.error.message);
            })
          }


          // this.callCurrProcedure(this.layerBean.ttyLayerPK.tlLayer);
          this.showForm = false;
          let obj = {
            minPremium: this.layerBean.tlMinPrem,
            depPrem: this.layerBean.tlDepPrem,
            adjustRate: this.layerBean.tlAdjustRate,
            prem: this.layerBean.tlPrem,
            depPremPerc: this.layerBean.tlDepPremPerc,
            tlAdjustRate: this.layerBean.tlAdjustRate,
            tlDepPremPerc: this.layerBean.tlDepPremPerc,
            tlLimitCurr: this.layerBean.tlLimitCurr,
            tlPremCurr: this.layerBean.tlPremCurr,
            tlLimit: this.layerBean.tlLimit,
            tlDeductible: this.layerBean.tlDeductible,
            tlAad: this.layerBean.tlAad
          }
          this.layerEvent.emit(obj);
        }, error => {
          this.toastService.error(error.message);
        });
      }
    } else {
      this.validateAllFormFields(this.layerForm);
      this.layerEvent.emit("error");
    }
  }

  updateLayer() {
    this.layerForm.get('tlAttachBasis').enable();
    this.layerForm.get('tlDeductible').enable();
    if (this.layerForm.valid) {
      //  alert(this.layerForm.get('tlMinPrem').value);
      var limit = this.layerForm.get('tlLimit').value;
      var tlDeductible = this.layerForm.get('tlDeductible').value;
      var tlAad = this.layerForm.get('tlAad').value;
      var tlMinPrem = this.layerForm.get('tlMinPrem').value ? this.layerForm.get('tlMinPrem').value.toString().replace(/,/g, '') : 0
      var tlPrem = this.layerForm.get('tlPrem').value;
      var tlPremRol = this.layerForm.get('tlPremRol').value ? this.layerForm.get('tlPremRol').value.toString().replace(/,/g, '') : 0
      var tlDepPrem = this.layerForm.get('tlDepPrem').value ? this.layerForm.get('tlDepPrem').value.toString().replace(/,/g, '') : 0
      var tlDepPremPerc = this.layerForm.get('tlDepPremPerc').value;
      var tlMaxRec = this.layerForm.get('tlMaxRec').value ? this.layerForm.get('tlMaxRec').value.toString().replace(/,/g, '') : 0
      //  ? this.layerForm.get('tlDepPremPerc').value.replace(/,/g, '') : 0
      var tlDepPremRol = this.layerForm.get('tlDepPremRol').value ? this.layerForm.get('tlDepPremRol').value.toString().replace(/,/g, '') : 0
      tlMinPrem = parseFloat(tlMinPrem);
      tlDepPrem = parseFloat(tlDepPrem);
      tlDepPremPerc = parseFloat(tlDepPremPerc);

      if (this.layerForm.get('tlReinstUnltdYn').value == true) {
        this.layerForm.get('tlReinstUnltdYn').setValue('1');
      } else {
        this.layerForm.get('tlReinstUnltdYn').setValue('0');
      }
      let param = {
        tlRefNo: this.refNo,
        tlSeqNo: this.seqNo,
        tlAmendNo: this.amendNo,
        tlLayer: this.selectedLayerId
      }
      this.layerForm.patchValue({
        ttyLayerPK: param,
        tlLimit: limit,
        tlDeductible: tlDeductible,
        tlMinPrem: tlMinPrem,
        tlAad: tlAad,
        tlPrem: tlPrem,
        tlPremRol: tlPremRol,
        tlDepPrem: tlDepPrem,
        tlDepPremPerc: tlDepPremPerc,
        tlDepPremRol: tlDepPremRol,
        tlMaxRec: tlMaxRec,
        // tlStatus:'A',
        // tlCrDt:new Date(),
        // tlCrUid:this.session.get('userId')
      })
      this.layerBean = this.layerForm.getRawValue();
      let resurerBean: any = this.layerBean.reinsurerList;

      if (tlMinPrem > tlDepPrem) {
        this.toastService.warning("Minimum Premium should be less than Deposit Premium");
        this.editLayer(this.layerBean);
      } else if (tlDepPremPerc > 100) {
        this.toastService.warning("Deposit Premium should be less than 100");
      } else {
        this.treatyService.updateLayerInfo(this.layerBean.ttyLayerPK.tlLayer, this.layerBean, this.amndSrNo).subscribe(resp => {
          let tlObj = {
            tlRefNo: this.refNo,
            tlAmendNo: this.amendNo,
            tlLayer: this.selectedLayerId,
            tlSeqNo: this.seqNo
          };
          var flag = this.layerForm.get('tlReinstUnltdYn').value;
          var tlNoOfReinst = this.layerForm.get('tlNoOfReinst').value;
          if (tlNoOfReinst > 0 && flag == 0) {
            this.treatyService.saveReInstDetails(resurerBean).subscribe(resp => {
              this.toastService.success("Successfully Updated");
            })
          } else if (tlNoOfReinst == 0 && flag == 1) {
            this.treatyService.deleteReInstDetails(tlObj).subscribe(() => {
            })
          } else if (tlNoOfReinst == 0 && flag == 0) {
            this.treatyService.deleteReInstDetails(tlObj).subscribe(() => {
            })
          }

          if (resurerBean.length > 0) {
            for (var i = 0; i < resurerBean.length; i++) {
              resurerBean[i].tiLayer = param.tlLayer;
              resurerBean[i].tiCrUid = this.session.get('userId');
              resurerBean[i].tiCrDt = new Date();
            }
            this.treatyService.saveReInstDetails(resurerBean).subscribe(resp => {
              this.loaderService.isBusy = false;
              this.toastService.success("Successfully Updated");
            })
          } else {
            this.toastService.success("Successfully Updated");
          }
          this.LoadGrid();
          // this.callCurrProcedure(this.layerBean.ttyLayerPK.tlLayer);
          this.showForm = false;
          let obj = {
            minPremium: this.layerBean.tlMinPrem,
            depPrem: this.layerBean.tlDepPrem,
            adjustRate: this.layerBean.tlAdjustRate,
            prem: this.layerBean.tlPrem,
            depPremPerc: this.layerBean.tlDepPremPerc,
            tlAdjustRate: this.layerBean.tlAdjustRate,
            tlDepPremPerc: this.layerBean.tlDepPremPerc,
            tlLimitCurr: this.layerBean.tlLimitCurr,
            tlPremCurr: this.layerBean.tlPremCurr,
            tlLimit: this.layerBean.tlLimit,
            tlDeductible: this.layerBean.tlDeductible,
            tlAad: this.layerBean.tlAad
          }
          this.layerEvent.emit(obj);
        }, error => {
          this.layerEvent.emit('error');
          this.toastService.error(error.error.message);
        })
      }


    } else {
      this.validateAllFormFields(this.layerForm);
      this.layerEvent.emit("error");
    }
  }

  editLayer(detail) {
    this.dropdown();
    this.ActionBtn = true;
    this.treatyService.retrieveReInstDetails(this.refNo, this.amendNo, this.seqNo, detail.ttyLayerPK.tlLayer).subscribe(resp => {
      this.reInsurerArrayList = resp.reInstList;

      this.showForm = true;
      this.selectedLayerId = detail.ttyLayerPK.tlLayer;
      this.formDetails = detail;
      let event = { key: this.formDetails.tlRateType };
      this.disableFilelds(event);
      var tlNoOfReinst = this.formDetails.tlNoOfReinst;

      if (this.contractType == 'TX') {
        this.layerForm.get('tlAttachBasis').setValue(this.xolType);
        this.coverageFlag = true;
        this.layerForm.get('tlAttachBasis').enable();
      } else {
        this.layerForm.get('tlAttachBasis').setValue('');
        this.coverageFlag = false;
        this.layerForm.get('tlAttachBasis').disable();
      }

      // if (this.formDetails.tlReinstUnltdYn == "1") {
      //   this.layerForm.get('tlNoOfReinst').disable();
      // } else {
      //   this.layerForm.get('tlNoOfReinst').enable();
      // }

      if ("WXL" == this.xolType && this.formDetails.ttyLayerPK.tlLayer == 1) {
        //this.layerForm.get('tlLimit').setValue('0');
        this.layerForm.get('tlDeductible').disable();
      }
      this.layerForm.get('tlLimitCurr').setValue(this.formDetails.tlLimitCurr);
      this.layerForm.patchValue({
        tlAttachBasis: this.formDetails.tlAttachBasis,
        tlLimitCurr: detail.tlLimitCurr,
        tlLimit: this.formDetails.tlLimit?this.formDetails.tlLimit:this.maxtkTxnFacSiFc,
        tlDeductible: this.formDetails.tlDeductible,
        tlAad: this.formDetails.tlAad,
        tlPremCurr: this.formDetails.tlPremCurr,
        tlRateType: this.formDetails.tlRateType,
        tlAdjustRate: this.formDetails.tlAdjustRate,
        tlBcLoadFact: this.formDetails.tlBcLoadFact,
        tlBcMinRate: this.formDetails.tlBcMinRate,
        tlBcMaxRate: this.formDetails.tlBcMaxRate,
        tlPrem: this.formDetails.tlPrem,
        tlPremRol: this.cpipe.premiumTransform(this.formDetails.tlPremRol),
        tlMinPrem: this.cpipe.transform(this.formDetails.tlMinPrem),
        tlDepPremPerc: this.formDetails.tlDepPremPerc,
        tlDepPrem: this.cpipe.transform(this.formDetails.tlDepPrem),
        tlDepPremRol: this.cpipe.premiumTransform(this.formDetails.tlDepPremRol),
        tlReinstUnltdYn: this.formDetails.tlReinstUnltdYn == "1" ? true : false,
        tlDesc: this.formDetails.tlDesc
      })
<<<<<<< HEAD
=======
      if(this.formDetails?.tlPrem){
        this.calcRolFlatPrem();
      }
      console.log("Edit Patch", this.layerForm)
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.layerForm.get('tlNoOfReinst').setValue(this.formDetails.tlNoOfReinst);
      this.layerForm.get('tlMaxRec').setValue(this.cpipe.transform(this.formDetails.tlMaxRec));
      this.layerForm.get('tlStatus').setValue(this.formDetails.tlStatus);
      this.layerForm.get('tlCrDt').setValue(this.formDetails.tlCrDt);
      this.layerForm.get('tlCrUid').setValue(this.formDetails.tlCrUid);
      if (this.reInsurerArrayList != null && this.reInsurerArrayList.length > 0 && this.layerForm.get('tlNoOfReinst').value != null) {
        for (var j = 0; j < this.reInsurerArrayList.length; j++) {
          if (this.selectedLayerId == this.reInsurerArrayList[j].ttyReinstPK.tiLayer) {
            //alert(this.selectedLayerId);
            this.addReInstList(tlNoOfReinst);
            break;
          }
        }

        const controlArray2 = <UntypedFormArray>this.layerForm.get('reinsurerList');
        let controlIndex = 0;
        for (var k = 0; k < this.reInsurerArrayList.length; k++) {
          if (this.selectedLayerId == this.reInsurerArrayList[k].ttyReinstPK.tiLayer) {
            controlArray2.controls[controlIndex].get('tiRefNo').setValue(this.reInsurerArrayList[k].ttyReinstPK.tiRefNo);
            controlArray2.controls[controlIndex].get('tiAmendNo').setValue(this.reInsurerArrayList[k].ttyReinstPK.tiAmendNo);
            controlArray2.controls[controlIndex].get('tiSeqNo').setValue(this.reInsurerArrayList[k].ttyReinstPK.tiSeqNo);
            controlArray2.controls[controlIndex].get('tiLayer').setValue(this.reInsurerArrayList[k].ttyReinstPK.tiLayer);
            controlArray2.controls[controlIndex].get('tiReinstNo').setValue(this.reInsurerArrayList[k].ttyReinstPK.tiReinstNo);

            controlArray2.controls[controlIndex].get('tiStatus').setValue(this.reInsurerArrayList[k].tiStatus);
            controlArray2.controls[controlIndex].get('tiReinstPerc').setValue(this.reInsurerArrayList[k].tiReinstPerc);
            controlArray2.controls[controlIndex].get('tiCrUid').setValue(this.reInsurerArrayList[k].tiCrUid);
            controlArray2.controls[controlIndex].get('tiCrDt').setValue(this.reInsurerArrayList[k].tiCrDt);
            controlIndex++;
          }
        }
        this.document.body.scrollTop = 15;

      } else {
        const control = <UntypedFormArray>this.layerForm.get('reinsurerList');
        for (var j = 0; j < control.length; j++) {
          control.removeAt(0);
        }
      }
      var flag = this.layerForm.get('tlReinstUnltdYn').value;
      if (flag == true) {
        this.layerForm.get('tlNoOfReinst').disable();
        this.layerForm.get('tlMaxRec').enable();
      } else {
        this.layerForm.get('tlNoOfReinst').enable();
        this.layerForm.get('tlMaxRec').disable();
      }

    }, error => {
      this.toastService.error(error.error.message);
    });
  }

  addReInstList(val): void {

    const control = <UntypedFormArray>this.layerForm.get('reinsurerList');

    let length = control.length;
    if ("add" == this.layerAction || "edit" == this.layerAction) {
      for (var j = 0; j < length; j++) {
        control.removeAt(0);
      }
    }
    for (var i = 1; i <= val; i++) {
      control.push(this.createReinsurerItem(i));
    }
  }

  createReinsurerItem(index): UntypedFormGroup {
    return this.fb.group({
      tiRefNo: this.refNo,
      tiAmendNo: this.amendNo,
      tiSeqNo: this.seqNo,
      tiLayer: this.selectedLayerId,
      tiReinstNo: index,
      tiReinstPerc: '0',
      tiStatus: 'A',
      tiCrUid: this.session.get('userId'),
      tiCrDt: new Date(),
      tiUpdUid: '',
      tiUpdDt: ''
    })
  }

  enableReinst() {
    var flag = this.layerForm.get('tlReinstUnltdYn').value;
    const controlArray = <UntypedFormArray>this.layerForm.get('reinsurerList');
<<<<<<< HEAD
    var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value ? this.layerForm.get('tlLimit').value.toString().replace(/,/g, '') : 0);
=======
    var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    if (flag == true) {
      this.layerForm.get('tlNoOfReinst').setValue("0");
      this.layerForm.get('tlNoOfReinst').disable();
      this.layerForm.get('tlMaxRec').setValue(Layer_limit);
      this.layerForm.get('tlMaxRec').enable();
      this.addReInstList(0);
    } else {
      this.layerForm.get('tlNoOfReinst').setValue("0");
      this.layerForm.get('tlNoOfReinst').enable();
      this.layerForm.get('tlMaxRec').setValue(Layer_limit);
      this.layerForm.get('tlMaxRec').disable();
      this.addReInstList(0);

    }

  }
  setReinst(val) {
<<<<<<< HEAD
    val = parseInt(val);
    if (val > 21) {
=======
    val = val ? parseInt(val) : 0;
    if (val >= 21) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.toastService.warning("No of Reinstatement should be less than 20");
    } else {
      this.addReInstList(val);
      if (val >= 0) {
        var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value);
        let maxRecAmt = (parseFloat(val) + 1) * Layer_limit;
        this.layerForm.get('tlMaxRec').setValue(this.cpipe.transform(maxRecAmt.toString()));
      }
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
=======
      console.log(field + ":" + control.status);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  nextStep() {
    if (this.contractType == 'FX') {
<<<<<<< HEAD
      if (this.facGnpiData.total.tkFacSiFc >= this.maxlimit) {
        this.wizardHelper.goNext();
      } else {
        this.toastService.warning("Layer Limit is to equal or less than GNPI Limit")
      }
=======
      // if (this.facGnpiData.total.tkTxnFacSiFc >= this.maxlimit) {
      //   console.log("success ---- Layer Limit is to equal or less than GNPI Limit")
      this.wizardHelper.goNext();
      // } else {
      //   this.toastService.warning("Layer Limit is to equal or less than GNPI Limit")
      // }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    } else {
      this.wizardHelper.goNext();
    }

  }
  previousStep() {
    this.wizardHelper.goPrevious();
  }

  close() {
    this.showForm = false
    this.layerForm.reset();
  }
  disabled: boolean = false;
  disableFilelds(event) {
    setTimeout(() => {
      var val = event.value ? event.value : event.key;
      if (val == 'AR') {
        this.layerForm.get('tlDepPrem').enable();
        this.AdjFlag = true
        this.BurnFlag = false
        this.FlatFlag = false
        this.premium_title = '100% Premium';
        this.rol_premium_title = 'RoL 100% Premium';
        // this.layerForm.get('tlPrem').reset();
        this.layerForm.get('tlBcLoadFact').reset();
        this.layerForm.get('tlBcMinRate').reset();
        this.layerForm.get('tlBcMaxRate').reset();
        this.layerForm.get('tlPrem').enable();
        this.disabled = false;
        // this.layerForm.get('tlPrem').setValidators([Validators.required]);
        // this.layerForm.get('tlPrem').updateValueAndValidity();
      } else if (ApiUrls.FLAT_RATE == val) {
        this.AdjFlag = false
        this.BurnFlag = false
        this.FlatFlag = true
        this.layerForm.get('tlDepPremPerc').setValue("100.0000000");
        this.layerForm.get('tlDepPrem').disable();
        if (this.contractType == 'FX') {
          this.disabled = true;
          this.layerForm.get('tlDepPremPerc').clearValidators();
          this.layerForm.get('tlDepPremPerc').updateValueAndValidity();
          this.layerForm.get('tlPrem').clearValidators();
          this.layerForm.get('tlPrem').updateValueAndValidity();
        } else {
          this.disabled = false;
          this.layerForm.get('tlDepPremPerc').setValidators([Validators.required]);
          this.layerForm.get('tlDepPremPerc').updateValueAndValidity();
        }
        this.premium_title = 'Flat Premium';
        this.layerForm.get('tlBcLoadFact').reset();
        this.layerForm.get('tlBcMinRate').reset();
        this.layerForm.get('tlBcMaxRate').reset();
        this.rol_premium_title = 'RoL Flat Premium';
        this.layerForm.get('tlAdjustRate').reset();
        // this.layerForm.get('tlPrem').reset();
        // this.layerForm.get('tlPrem').enable();
      } else if (val == 'BR') {
        this.layerForm.get('tlDepPrem').enable();
        this.AdjFlag = false
        this.BurnFlag = true
        this.FlatFlag = false
        this.layerForm.get('tlAdjustRate').reset();
        this.layerForm.get('tlPrem').reset();
        this.layerForm.get('tlPrem').disable();
        this.disabled = false;
        this.layerForm.get('tlPrem').clearValidators();
        this.layerForm.get('tlPrem').updateValueAndValidity();
      }

<<<<<<< HEAD
  disableFilelds(event) {
    var val = event.value;
    if (val == 'AR') {
      this.AdjFlag = true
      this.BurnFlag = false
      this.FlatFlag = false
      this.premium_title = '100% Premium';
      this.rol_premium_title = 'RoL 100% Premium';
      this.layerForm.get('tlPrem').reset();
      this.layerForm.get('tlBcLoadFact').reset();
      this.layerForm.get('tlBcMinRate').reset();
      this.layerForm.get('tlBcMaxRate').reset();
      this.layerForm.get('tlPrem').enable();
    } else if (ApiUrls.FLAT_RATE == val) {
      this.AdjFlag = false
      this.BurnFlag = false
      this.FlatFlag = true
      this.premium_title = 'Flat Premium';
      this.layerForm.get('tlBcLoadFact').reset();
      this.layerForm.get('tlBcMinRate').reset();
      this.layerForm.get('tlBcMaxRate').reset();
      this.rol_premium_title = 'RoL Flat Premium';
      this.layerForm.get('tlAdjustRate').reset();
      this.layerForm.get('tlPrem').reset();
      this.layerForm.get('tlPrem').enable();
    } else if (val == 'BR') {
      this.AdjFlag = false
      this.BurnFlag = true
      this.FlatFlag = false
      this.layerForm.get('tlAdjustRate').reset();
      this.layerForm.get('tlPrem').reset();
      this.layerForm.get('tlPrem').disable();
    }
=======
    }, 300);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  }

  callCurrProcedure(layerId) {
    let obj = {
      tlRefNo: this.refNo,
      tlSeqNo: this.seqNo,
      tlAmendNo: this.amendNo,
      tlLayer: layerId,
      userId: this.session.get('userId'),
      company: this.session.get("companyCode"),
      division: this.session.get("userDivnCode"),
      status: "INS"

    }
    this.treatyService.storedProcedure(obj).subscribe(resp => {
    }, error => {
    });
  }

  setSelectedValue(details) {

    // $('#'+id).attr('checked', true);
    this.selectedLayerId = details.ttyLayerPK.tlLayer;
    let obj = {
      minPremium: details.tlMinPrem,
      depPrem: details.tlDepPrem,
      adjustRate: details.tlAdjustRate,
      prem: details.tlPrem,
      depPremPerc: details.tlDepPremPerc,
      tlAdjustRate: details.tlAdjustRate,
      tlDepPremPerc: details.tlDepPremPerc,
      tlLimitCurr: details.tlLimitCurr,
      tlPremCurr: details.tlPremCurr,
      tlRateType: details.tlRateType,
      tlLimit: details.tlLimit,
      tlDeductible: details.tlDeductible,
      tlAad: details.tlAad,
      tlDesc: details.tlDesc

    }
    this.sendLayerHeading.emit(this.selectedLayerId);
    this.layerEvent.emit(obj);

  }


  //Calculations part for Layer

  calcAdjustment() {
    setTimeout(() => {
      var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value);
      var Layer_AdjustRate = parseFloat(this.layerForm.get('tlAdjustRate').value);
      var Layer_Dep_Perc = parseFloat(this.layerForm.get('tlDepPremPerc').value);
      if (Layer_limit && Layer_AdjustRate && Layer_AdjustRate != null && this.egnpiAmt != undefined && this.egnpiAmt != null) {
        let prem = ((Layer_AdjustRate * this.egnpiAmt) / 100).toFixed(2);
        this.layerForm.get('tlPrem').setValue(prem);

        let rolPremium = ((parseFloat(prem) / Layer_limit) * 100).toFixed(7);
        this.layerForm.get('tlPremRol').setValue(this.cpipe.premiumTransform(rolPremium.toString()));
        if (Layer_Dep_Perc) { this.calcDepPrem(); }

      } if (Layer_limit) {
        this.layerForm.get('tlMaxRec').setValue(Layer_limit);
      }
    }, 300);

  }

  calcRolPrem() {
    setTimeout(() => {
      var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value)
      var Layer_Prem = this.layerForm.get('tlPrem').value;
      var Layer_AdjustRate = parseFloat(this.layerForm.get('tlAdjustRate').value);

      if (Layer_limit && Layer_AdjustRate && Layer_AdjustRate != null && this.egnpiAmt && this.egnpiAmt != null && Layer_Prem) {
        let rolPremium = ((Layer_Prem / Layer_limit) * 100).toFixed(7);
        this.layerForm.get('tlPremRol').setValue(this.cpipe.premiumTransform(rolPremium.toString()));
      }
    }, 300);
  }

  calcDepPrem() {
<<<<<<< HEAD
    var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value ? this.layerForm.get('tlLimit').value.toString().replace(/,/g, '') : 0);
    var Layer_Dep_Perc = parseFloat(this.layerForm.get('tlDepPremPerc').value);
    var Layer_Prem = parseFloat(this.layerForm.get('tlPrem').value ? this.layerForm.get('tlPrem').value.toString().replace(/,/g, '') : 0);
    if (Layer_Dep_Perc && Layer_Prem && Layer_limit) {
      let depPremium = ((Layer_Prem * Layer_Dep_Perc) / 100).toFixed(2);
      let RolDepPremium = (((parseFloat(depPremium) / Layer_limit)) * 100).toFixed(7);
      this.layerForm.get('tlDepPrem').setValue(this.cpipe.transform(depPremium.toString()));
      this.layerForm.get('tlDepPremRol').setValue(this.cpipe.premiumTransform(RolDepPremium.toString()));
    }
    if (Layer_Dep_Perc > 100) {
      this.toastService.warning("Deposit Premium should be less than 100");
    } else if (!Layer_Dep_Perc) {
      this.toastService.warning("Check Mandatory Fields");
=======
    if (this.disabled == true) {
      return false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
    setTimeout(() => {
      var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value);
      var Layer_Dep_Perc = parseFloat(this.layerForm.get('tlDepPremPerc').value);
      var Layer_Prem = this.layerForm.get('tlPrem').value;
      if (Layer_Dep_Perc && Layer_Prem && Layer_limit) {
        let depPremium = ((Layer_Prem * Layer_Dep_Perc) / 100).toFixed(2);
        let RolDepPremium = (((parseFloat(depPremium) / Layer_limit)) * 100).toFixed(7);
        this.layerForm.get('tlDepPrem').setValue(this.cpipe.transform(depPremium.toString()));
        this.layerForm.get('tlDepPremRol').setValue(this.cpipe.premiumTransform(RolDepPremium.toString()));
      }
      if (Layer_Dep_Perc > 100) {
        this.toastService.warning("Deposit Premium should be less than 100");
      } else if (!Layer_Dep_Perc) {
        this.toastService.warning("Check Mandatory Fields");
      }
    }, 300);
  }
  calcRolFlatPrem() {
    setTimeout(() => {
      var rateType = this.layerForm.get('tlRateType').value;
      var Layer_limit = parseFloat(this.layerForm.get('tlLimit').value);
      var Layer_Dep_Perc = parseFloat(this.layerForm.get('tlDepPremPerc').value)
      var Flatprem = this.layerForm.get('tlPrem').value;
      if (Layer_limit && Flatprem) {
        let rolPremium = ((Flatprem / Layer_limit) * 100).toFixed(7);
        this.layerForm.get('tlPremRol').setValue(this.cpipe.premiumTransform(rolPremium.toString()));
      }
      if(rateType == 'FR'){
        let depPremium = ((Flatprem * Layer_Dep_Perc) / 100).toFixed(2);
        this.layerForm.get('tlDepPrem').setValue(this.cpipe.transform(depPremium.toString()));
      }
    }, 300);
  }
  reCalcDepPrem() {
<<<<<<< HEAD
    var DepPrem = parseFloat(this.layerForm.get('tlDepPrem').value ? this.layerForm.get('tlDepPrem').value.toString().replace(/,/g, '') : 0);
    var PremPerc = parseFloat(this.layerForm.get('tlPrem').value ? this.layerForm.get('tlPrem').value.toString().replace(/,/g, '') : 0);
    if (DepPrem && PremPerc) {
      var DepPremPerc = ((DepPrem * 100) / PremPerc).toFixed(7);
      this.layerForm.get('tlDepPremPerc').setValue(DepPremPerc.toString());
      if (parseFloat(DepPremPerc) > 100) {
        this.toastService.warning("Percentage can not be greater than 100.");
      }
    } else { this.toastService.warning("Check Mandatory Fields"); }
=======
    if (this.disabled == true) {
      return false;
    }
    setTimeout(() => {
      var DepPrem = parseFloat(this.layerForm.get('tlDepPrem').value ? this.layerForm.get('tlDepPrem').value.toString().replace(/,/g, '') : 0);
      var PremPerc = this.layerForm.get('tlPrem').value;
      if (DepPrem && PremPerc) {
        var DepPremPerc = ((DepPrem * 100) / PremPerc).toFixed(7);
        console.log("Dep premium percentage recalc", DepPremPerc);
        this.layerForm.get('tlDepPremPerc').setValue(DepPremPerc.toString());
        if (parseFloat(DepPremPerc) > 100) {
          this.toastService.warning("Percentage can not be greater than 100.");
        }
      } else { this.toastService.warning("Check Mandatory Fields"); }
    }, 300);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  minPremValidation() {
    if (this.disabled == true) {
      return false;
    }
    setTimeout(() => {
      var Layer_minPrem = parseFloat(this.layerForm.get('tlMinPrem').value ? this.layerForm.get('tlMinPrem').value.toString().replace(/,/g, '') : 0);
      var Layer_DepPrem = parseFloat(this.layerForm.get('tlDepPrem').value ? this.layerForm.get('tlDepPrem').value.toString().replace(/,/g, '') : 0);

<<<<<<< HEAD
    if (Layer_DepPrem && Layer_minPrem) {
      if (Layer_minPrem > Layer_DepPrem) {
        this.toastService.warning("Minimum Premium should be less than Deposit Premium.");
=======
      if (Layer_DepPrem && Layer_minPrem) {
        if (Layer_minPrem > Layer_DepPrem) {
          this.toastService.warning("Minimum Premium should be less than Deposit Premium.");
        }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    }, 300);
  }
  reCalcAdj() {
    setTimeout(() => {
      var Layer_Prem = this.layerForm.get('tlPrem').value;
      if (Layer_Prem && this.egnpiAmt != undefined && this.egnpiAmt != null) {
        var AdjRate = ((Layer_Prem / this.egnpiAmt) * 100).toFixed(7);
        //  this.layerForm.get('tlAdjustRate').setValue(AdjRate.toString());
      }
    }, 300);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    // this.loadlayergrid("new");
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {

      radioButtonRenderer: RadiorenderComponent
    };
  }
  selectedRowData(cell) {
    let detail = cell.data;
    this.selectedLayerId = cell.data?.ttyLayerPK.tlLayer;
    let obj = {
      minPremium: detail?.tlMinPrem ? detail.tlMinPrem : '',
      depPrem: detail?.tlDepPrem ? detail.tlDepPrem : '',
      adjustRate: detail?.tlAdjustRate ? detail.tlAdjustRate : '',
      prem: detail?.tlPrem ? detail.tlPrem : '',
      depPremPerc: detail?.tlDepPremPerc ? detail.tlDepPremPerc : '',
      tlAdjustRate: detail?.tlAdjustRate ? detail.tlAdjustRate : '',
      tlDepPremPerc: detail?.tlDepPremPerc ? detail.tlDepPremPerc : '',
      tlLimitCurr: detail?.tlLimitCurr ? detail.tlLimitCurr : '',
      tlPremCurr: detail?.tlPremCurr ? detail.tlPremCurr : '',
      tlRateType: detail?.tlRateType ? detail.tlRateType : '',
      tlLimit: detail?.tlLimit ? detail.tlLimit : '',
      tlDeductible: detail?.tlDeductible ? detail.tlDeductible : '',
      tlMaxRec: detail?.tlMaxRec ? detail.tlMaxRec : '',
      tlDesc: detail?.tlDesc ? detail.tlDesc : ''

    }
    this.sendLayerHeading.emit(this.selectedLayerId);
    this.layerEvent.emit(obj);
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          this.layerForm.reset();
          return this.editLayer(data);
        case "Remove":
          this.LayerData = data;
          return this.showDialogbox(data)
        // this.deleteLayer(data);
      }
    }
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        columnKeys: ['tlDesc', 'tlLimitCurr', 'tlLimit', 'tlDeductible', 'tlPremCurr',
          'tlPrem', 'tlAdjustRate', 'tlPremRol', 'tlDepPrem', 'tlDepPremPerc', 'tlDepPremRol', 'tlNoOfReinst'],
        processCellCallback: (params) => {
          if (params.column.colId == "tlLimit" || params.column.colId == 'tlDeductible'
            || params.column.colId == "tlAdjustRate" || params.column.colId == "tlPrem" ||
            params.column.colId == "tlPremRol" || params.column.colId == 'tlDepPrem' || params.column.colId == 'tlDepPremRol') {
            if (params && params.value) {
              let cost = parseFloat((params.value).replace(/,/g, ''));
              return cost; //'<span title="' + cost + '">'+cost+'</span>'
            } else {
              return ''
            }
          } else {
            return params.value;
          }
        }
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
    this.gridApi.sizeColumnsToFit();

  }

  deleteLayer() {
    this.LayerName = this.LayerData.ttyLayerPK.tlLayer;

    let layerData = {
      tlRefNo: this.LayerData.ttyLayerPK.tlRefNo,
      tlSeqNo: this.LayerData.ttyLayerPK.tlSeqNo,
      tlAmendNo: this.LayerData.ttyLayerPK.tlAmendNo,
      tlLayer: this.LayerData.ttyLayerPK.tlLayer,
      tlPriority: this.LayerData.tlPriority ? this.LayerData.tlPriority : 0
    }

    this.treatyService.deleteLayer(layerData).subscribe(resp => {
      this.LoadGrid();
      this.modalService.hide();
      this.toastService.success("Deleted Successfully");
    }, err => {
      this.LoadGrid();
      this.modalService.hide();
      this.toastService.error(err);
    })
  }

  showDialogbox(data) {
    this.open(this.confirmcontent, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
<<<<<<< HEAD
=======
  }
  closeModal() {
    this.modalService.hide();
  }
  removeNegative(event) {
    var k;
    k = event.keyCode;
    // console.log(k);
    if (k == 189 || k == 187 || k == 107 || k == 109) {
      return false;
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
}
function numberFormatter(params) {
  if (params.value) {
    return params.value.toFixed(2);
  } else {
    return '';
  }
}
function currencyFormatter(params) {
  if (params && params.value) {
    //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  } else {
    return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  }
}

function createData(count, data, excessMin) {
  var result = [];
  excessMin = [];
  let sumtlLimit = 0;
  let sumtlDeductible = 0;
  let sumtlPrem = 0;
  let sumtlDepPrem = 0;
  for (var i = 0; i < data.length; i++) {
    sumtlLimit = sumtlLimit + data[i].tlLimit;
    sumtlDeductible = sumtlDeductible + data[i].tlDeductible;
    excessMin.push(data[i].tlDeductible);
    sumtlPrem = sumtlPrem + data[i].tlPrem;
    sumtlDepPrem = sumtlDepPrem + data[i].tlDepPrem;
  }
  for (var i = 0; i < count; i++) {
    result.push({
      // ttyLayerPK1: 'Total',
      tlLimit: sumtlLimit,
      // tlDeductible: sumtlDeductible,
      tlPrem: sumtlPrem,
      tlDepPrem: sumtlDepPrem,
      tlDeductible: Math.min(...excessMin)
    });
  }
  return result;
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-file-pen fa-icon" data-action-type="Edit" title="Edit" aria-hidden="true"></i>
    &nbsp;
    <i class="Px-2 fa fa-trash fa-icon fa-danger" data-action-type="Remove"  title="Delete" aria-hidden="true"></i>
    </a>`;
  }
}
function decimalFormatter(params) {
  if (params && params.value) {
    let cost = Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    return cost; //'<span title="' + cost + '">'+cost+'</span>'
  } else {
    return ''
  }
}