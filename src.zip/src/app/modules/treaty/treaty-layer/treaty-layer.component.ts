<<<<<<< HEAD
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
=======
import { Component, ElementRef, EventEmitter, Inject, Input, Output, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { SessionStorageService } from 'angular-web-storage';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Layer } from './layer';
import { Reinsurer } from './reinsurer';


declare var $: any;

@Component({
  selector: 'app-treaty-layer',
  templateUrl: './treaty-layer.component.html',
  styleUrls: ['./treaty-layer.component.css'],
  providers: [MycurrencyPipe]
})

export class TreatyLayerComponent {

  upload: boolean = true;
  url: string;
  variable: any;
  ishowCoverage: boolean = false;
  showIns: boolean = false;

  display: boolean = false;
  perilItem: any = [];
  currencyList: any = [];
  rateList: any = [];
  coverageBasisList: any = [];
  selectedCars2: string[] = [];
  refNo: string;
  amendNo: string;
  layerBean: Layer;
  resurerBean: Reinsurer;
  layerArrayList: Array<any>;
  reInsurerArrayList: any;
  headerTittle: string;
  totalLimits: number = 0;
  totaldeductable: number = 0;
  totalRolDepositPremium: number = 0;
  totalDepositPremium: number = 0;
  totalAdjustmentRate: number = 0;
  totalMinimumPremium: number = 0;
  totalRolePremium: number = 0;
  totalPremium: number = 0;
  loginId: string;
  layerIndex: number;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  layerForm: UntypedFormGroup;
  layerList: UntypedFormArray;
  layerName: string;
  showCurrency: boolean = false;
  reinsurerForm: UntypedFormGroup;
  reinsurerList: UntypedFormArray;
  layerNo: number;
  @Input() egnpAmt: number;
  @Input() xolType: string;
  @Input() contractNo: string;
  @Input() contractAmendNo: string;
  @Input() baseCurrency: string;
  @Input() amndSrNo: any;
  @Output() showLayerBtn = new EventEmitter();
  @ViewChild('content') content: ElementRef;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  @Output() stateChange = new EventEmitter();
  seqNo: number;
  action: string;
  layerLength: any;
  details: any[];
  cols: any[];
  userId: string;
  dedValue: number = 0;
  showForm: boolean = false;
  showPrintBtn: boolean = false;
  selectForm: UntypedFormGroup;
  layerNum: any;
  slideConfig = { "slidesToShow": 3, "slidesToScroll": 3 };
  formSubmit: boolean = false;
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
<<<<<<< HEAD
=======
    private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
  ) {
    // this.subscription = this.localService.getMessage().subscribe(message => { 
    //   this.message = message; });
    // alert("meaagse "+this.subscription);
  }

  showDialog(index) {
    this.layerNo = index;
    //this.display = true;   
    this.showForm = false;
    this.headerTittle = "Peril for " + "Layer " + (index + 1);
    this.layerNum = "Layer " + (index + 1);
    this.details = [];
    this.perilItem = [];
    // this.treatyService.getSelectedPerilList("Layer " + (index + 1), this.refNo, this.amendNo).subscribe(resp => {
    //   this.scriptcall('peril');
    //   this.details = resp.perilList;       
    // },error=>{
    //   this.scriptcall('peril');
    // })
    this.open(this.content, 'modal-lg');
    this.getPerilDetails(index);
  }

  open(content, val) {
<<<<<<< HEAD
    this.modalService.show(content, { class: val });
=======
    this.modalService.show(content, { class: val });    
  }
  closeModal() {
    this.modalService.hide();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  scriptcall(id) {
    var elementExists = document.getElementById(id);
    if (elementExists) {
      $('#' + id).DataTable().destroy();
    }
    setTimeout(() => {
      $('#' + id).DataTable().draw();
      this.loaderService.isBusy = false;
    }, 500);
  }

  createItem(): UntypedFormGroup {
    return this.fb.group({
      tlAttachBasis: '',
      tlLimitCurr: [this.baseCurrency, Validators.required],
      tlLimit: ['', Validators.required],
      tlDeductible: [this.dedValue, Validators.required],
      tlAad: '',
      tlPremCurr: this.baseCurrency,
      tlRateType: ['', Validators.required],
      tlAdjustRate: '',
      tlBcLoadFact: '',
      tlBcMinRate: '',
      tlBcMaxRate: '',
      tlPrem: ['', Validators.required],
      tlPremRol: ['', Validators.required],
      tlMinPrem: '',
      tlDepPremPerc: ['', Validators.required],
      tlDepPrem: '',
      tlDepPremRol: '',
      tlReinstUnltdYn: '',
      tlNoOfReinst: '0',
      tlMaxRec: '',
      tlStatus: ['A', Validators.required],
      tlCrUid: this.userId,
      tlCrDt: '',
      reinsurerList: this.fb.array([]),
      layerBtnName: 'Save'

    });
  }
  ngOnInit() {
    this.cols = [
      { field: 'key', header: 'Peril Code' },
      { field: 'value', header: 'Peril Desc' },
      { field: 'Action', header: 'Action' }
    ]
    this.userId = this.session.get('userId');
    this.action = this.treatyService.getParamValue('action');
    this.refNo = this.treatyService.getParamValue('refNo') == undefined ? this.contractNo : this.treatyService.getParamValue('refNo');
    this.amendNo = this.treatyService.getParamValue('amendNo') == undefined ? this.contractAmendNo : this.treatyService.getParamValue('amendNo');
    this.loginId = this.session.get('userId') == undefined ? "test" : this.session.get('userId');
    this.dropdown();
    this.treatyService.retrievecurrencyList().subscribe(resp => {
      this.ngAfterViewInit();
      this.currencyList = resp.currencyList;
    })
    this.treatyService.appCodesList(ApiUrls.APP_RATE_TYPE).subscribe(resp => {
      this.ngAfterViewInit();
      this.rateList = resp.appcodeList;
    });

    this.treatyService.retrieveCoverageBasisList(ApiUrls.APP_COVERAGE_BASIS_TYPE, ApiUrls.NON_PROPORTIONAL_TREATY_TYPE, this.xolType).subscribe(resp => {
      this.ngAfterViewInit();
      this.coverageBasisList = resp.appcodeList;
      if (this.coverageBasisList != null) {
        this.ishowCoverage = true;
      } else {
        this.ishowCoverage = false;
      }
    })

    let obj = {
      'refNo': this.refNo,
      'amendNo': this.amendNo
    }
    if ('add' != this.action) {
      this.loaderService.isBusy = true;
      this.treatyService.retrieveLayerListById(obj).subscribe(result => {
        this.layerArrayList = result.layerList;
        if (this.layerArrayList != null && this.layerArrayList.length > 0) {
          if ("edit" == this.action || "view" == this.action) {
            this.layerForm = this.fb.group({
              layerList: this.fb.array([])
            })
            for (var i = 0; i < this.layerArrayList.length; i++) {
              this.addItem(this.action);
            }
            this.loadDefaultValues();
            if ("view" == this.action) {
              this.layerForm.disable();
            }
          }
        } else {
          this.layerForm = this.fb.group({
            layerList: this.fb.array([this.createItem()]),
          })
        }
      }, error => {
        this.loaderService.isBusy = false;
      });
    } else {
      this.layerForm = this.fb.group({
        layerList: this.fb.array([this.createItem()]),
      })
    }

    this.selectedItems = [
      // { item_id: 3, item_text: 'Pune' },
      // { item_id: 4, item_text: 'Navsari' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.selectForm = this.fb.group({
      city: [this.selectedItems]
    });
  }

  dropdown() {
    // this.treatyService.perilCodesList(ApiUrls.APP_PERIL_TYPE,this.refNo).subscribe(resp => {
    //   this.dropdownList = resp.appcodeList;
    //   this.ngAfterViewInit();
    // });
  }

  addItem(action): void {
    this.layerList = this.layerForm.get('layerList') as UntypedFormArray;
    this.layerLength = this.layerList.length;
    //alert(this.action+" " +this.layerLength);
    this.dedValue = 0;
    if ("add" == action) {
      const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
<<<<<<< HEAD
=======
      console.log("1", controlArray.controls[this.layerLength - 1].get('tlLimit').value);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.dedValue = parseFloat(controlArray.controls[this.layerLength - 1].get('tlLimit').value) +
        parseFloat(controlArray.controls[this.layerLength - 1].get('tlDeductible').value);
    }
    this.layerList.push(this.createItem());
    this.showLayerBtn.emit("N");
  }

  addReInstList(index, val): void {
    const control = <UntypedFormArray>this.layerForm.get('layerList');
    const control2 = <UntypedFormArray>control.controls[index].get('reinsurerList');
    let length = control2.length;
    if ("add" == this.action || "edit" == this.action) {
      for (var j = 0; j < length; j++) {
        control2.removeAt(0);
      }
    }
    for (var i = 1; i <= val; i++) {
      control2.push(this.createReinsurerItem(i));
    }
  }

  createReinsurerItem(index): UntypedFormGroup {
    return this.fb.group({
      tiRefNo: this.refNo,
      tiAmendNo: this.amendNo,
      tiLayer: index,
      tiReinstNo: index,
      tiReinstPerc: '0',
      tiStatus: 'A',
      tiCrUid: this.userId,
      tiCrDt: '',
      tiUpdUid: '',
      tiUpdDt: ''
    })
  }

  onItemSelect(item: any) {
    this.perilItem.push(item);
  }

  onDeSelect(items: any) {
    let index = this.perilItem.indexOf(items);
    this.perilItem.splice(index, 1);
  }
  savePerils(layerNo) {
    this.loaderService.isBusy = true;
    let param = {
      tpRefNo: this.refNo,
      tpAmendNo: this.amendNo,
      tpLayer: "Layer " + (layerNo + 1),
      tpPeril: ""
    }
    let obj = {
      perilList: this.perilItem,
      tpStatus: "A",
      tpCrUid: this.userId,
      tpCrDt: new Date(),
      ttyPerilPK: param

    }
    this.treatyService.savePerilDetails(obj, this.amndSrNo).subscribe(resp => {
      this.toastService.success("Successfully Saved");
      this.showForm = false;
      this.getPerilDetails(layerNo);

      this.selectForm.get('peril-select').setValue([]);
    }, error => {
      this.toastService.error("Error in saving Peril");
      this.loaderService.isBusy = false;
    })
  }
  addPeril() {
    this.showForm = true;
    this.dropdown();
  }
  saveLayers(index) {
    this.layerIndex = index;
    this.formSubmit = true;
    const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
    var reinstYn: boolean = controlArray.controls[index].get('tlReinstUnltdYn').value == "" ? false : controlArray.controls[index].get('tlReinstUnltdYn').value;
    // alert(reinstYn);
    var noOfReInst: number = parseInt(controlArray.controls[index].get('tlNoOfReinst').value == null ? "0" : controlArray.controls[index].get('tlNoOfReinst').value);

    // const reinsurerArray= <UntypedFormArray>controlArray.controls[index].get('reinsurerList');
    if (controlArray.controls[index].valid) {
      let layerData = this.layerForm.get("layerList").value;
      this.layerBean = new Layer();
      this.layerBean = layerData[index];
      //this.resurerBean=new Reinsurer();
      let resurerBean: any = layerData[index].reinsurerList;

      // if(reinstYn == false && noOfReInst==0 && resurerBean.length == 0){
      //   this.toastService.add({ severity: 'error', summary: "Please Enter No Of Reinstatement Details For the Layer "+ (index+1) });
      //   return false;
      // }    
      if (this.layerBean.tlMinPrem != null && this.layerBean.tlMinPrem > this.layerBean.tlDepPrem) {
        this.toastService.warning("Minimum Premium Shold be Less or equal to  Deposit Premium for Layer " + (index + 1));
        return false;
      }
      this.loaderService.isBusy = true;

      let param = {
        tlRefNo: this.refNo,
        tlAmendNo: this.amendNo,
        tlLayer: "Layer " + (index + 1)
      }
      // alert("befor "+this.layerBean.tlReinstUnltdYn);
      if (this.layerBean.tlReinstUnltdYn == true) {
        this.layerBean.tlReinstUnltdYn = "1"
      } else {
        this.layerBean.tlReinstUnltdYn = "0"
      }
      // this.layerBean.tlReinstUnltdYn == true ? "1" : "0";
      // alert("after "+this.layerBean.tlReinstUnltdYn);
      this.layerBean.ttyLayerPK = param;
      this.layerBean.tlStatus = 'P';
      this.layerBean.tlCrDt = new Date();
      this.layerBean.tlCrUid = this.userId;
      if ('edit' == this.action) {
        this.treatyService.updateLayerInfo("Layer " + (index + 1), this.layerBean, this.amndSrNo).subscribe(resp => {
          this.loaderService.isBusy = false;
          if (resurerBean.length > 0) {
            for (var i = 0; i < resurerBean.length; i++) {
              resurerBean[i].tiLayer = "Layer " + (index + 1);
              resurerBean[i].tiCrUid = this.userId;
              resurerBean[i].tiCrDt = new Date();

            }
            this.treatyService.saveReInstDetails(resurerBean).subscribe(resp => {
              this.toastService.success("Updated Successfully");
              controlArray.controls[index].get('layerBtnName').setValue("Update");
              this.showLayerBtn.emit("Y");
            })
          } else {
            this.treatyService.deleteReInstDetails(param).subscribe(resp => {

            })
            this.toastService.success("Successfully Saved.");
            controlArray.controls[index].get('layerBtnName').setValue("Update");
            this.showLayerBtn.emit("Y");
          }
          //for(var i=1;i<=layerData.)

        }, error => {
          this.toastService.success(error.message);
          this.loaderService.isBusy = false;
        })
      } else {
        // if(reinstYn != "" && reinstYn != 0 && resurerBean.length > 0){
        //   this.toastService.add({ severity: 'error', summary: "Please Fill Reinstallment values" });
        //   return false;
        // }
        this.treatyService.saveLayerInfo(this.layerBean, this.amndSrNo).subscribe(resp => {
          if (resurerBean.length > 0) {
            for (var i = 0; i < resurerBean.length; i++) {
              resurerBean[i].tiLayer = "Layer " + (index + 1);
              resurerBean[i].tiCrUid = this.userId;
              resurerBean[i].tiCrDt = new Date();

            }
            this.treatyService.saveReInstDetails(resurerBean).subscribe(resp => {
              this.loaderService.isBusy = false;
              this.toastService.success("Successfully Saved");
              controlArray.controls[index].get('layerBtnName').setValue("Update");
              this.showLayerBtn.emit("Y");
            })
          } else {
            this.treatyService.deleteReInstDetails(param).subscribe(resp => {
            });
            this.toastService.success("Successfully Saved");
            controlArray.controls[index].get('layerBtnName').setValue("Update");
            this.showLayerBtn.emit("Y");
          }
          //for(var i=1;i<=layerData.)

        }, error => {
          this.toastService.error(error.message);
        })
      }
    }
  }



  approve() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amendNo: this.amendNo,
      userId: this.loginId,
      divn: this.session.get('userDivnCode'),
      dept: this.session.get('userDeptCode'),
      company: this.session.get('companyCode')
    }
    this.treatyService.approveContract(obj, this.amndSrNo).subscribe(resp => {
      this.toastService.success("Approved Successfully.");
      this.showPrintBtn = true;
      this.action = 'view';
      this.stateChange.emit(this.action);
      this.loaderService.isBusy = false;
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    })
  }

  /*retrieveLayerDetails(){
    let obj={
      'refNo':this.refNo,
      'amendNo':this.amendNo
   }
    this.treatyService.retrieveLayerListById(obj).subscribe(result =>{
     this.layerArrayList=result.layerList;
     for(var i=0;i<this.layerArrayList.length;i++){  
        this.addItem();
     }
    this.loadDefaultValues();
  
        
    })
  }*/

  // deleteRow(index) {
  //   this.confirmationService.confirm({
  //     message: 'Do you want to delete this Layer?',
  //     header: 'Delete Confirmation',
  //     icon: 'pi pi-info-circle',
  //     accept: () => {
  //       //  this.msgs = [{severity:'info', summary:'Confirmed', detail:'Record deleted'}];
  //         this.layerList = this.layerForm.get('layerList') as UntypedFormArray;
  //         this.layerList.removeAt(index);
  //         this.layerLength = this.layerList.length;
  //         this.treatyService.deleteLayer("Layer " + (index + 1), this.refNo, this.amendNo).subscribe(resp => {
  //           this.toastService.add({ severity: 'success', summary: "Layer Deleted Successfully" });
  //           this.showLayerBtn.emit("Y");   
  //         }, error => {
  //           this.toastService.add({ severity: 'error', summary: "error occured while deleting" });
  //         })
  //     },
  //     reject: () => {
  //       //this.toastService.add({ severity: 'error', summary: "error occured while deleting" });
  //     }
  // });    
  // }
  showDialogbox() {
    this.open(this.confirmcontent, 'modal-sm');
  }
  // deleteRow(index) {


  //   this.layerList = this.layerForm.get('layerList') as UntypedFormArray;
  //   this.layerList.removeAt(index);
  //   this.layerLength = this.layerList.length;
  //   this.treatyService.deleteLayer("Layer " + (index + 1), this.refNo, this.amendNo).subscribe(resp => {
  //     let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
  //     element.click();
  //     this.toastService.success("Layer Deleted Successfully");
  //     this.showLayerBtn.emit("Y");


  //   }, error => {
  //     this.toastService.error("error occured while deleting");
  //   })

  // }


  loadDefaultValues() {
    // this.treatyService.retrieveReInstDetails(this.refNo, this.amendNo,this.seqNo).subscribe(resp => {
    //   this.reInsurerArrayList = resp.reInstList;
    //   for (var i = 0; i < this.layerArrayList.length; i++) {
    //     // this.driverInfo=this.driverInfoArray[i];
    //     var index = i;
    //     const controlArray = <UntypedFormArray>this.layerForm.get('layerList');

    //     controlArray.controls[index].get('layerBtnName').setValue('Update');
    //     controlArray.controls[index].get('tlAttachBasis').setValue(this.layerArrayList[i].tlAttachBasis);
    //     controlArray.controls[index].get('tlLimitCurr').setValue(this.layerArrayList[i].tlLimitCurr);
    //     controlArray.controls[index].get('tlLimit').setValue(this.cpipe.transform(this.layerArrayList[i].tlLimit));
    //     controlArray.controls[index].get('tlDeductible').setValue(this.cpipe.transform(this.layerArrayList[i].tlDeductible));
    //     controlArray.controls[index].get('tlAad').setValue(this.layerArrayList[i].tlAad);
    //     controlArray.controls[index].get('tlPremCurr').setValue(this.layerArrayList[i].tlPremCurr);
    //     controlArray.controls[index].get('tlRateType').setValue(this.layerArrayList[i].tlRateType);
    //     controlArray.controls[index].get('tlAdjustRate').setValue(this.layerArrayList[i].tlAdjustRate);
    //     controlArray.controls[index].get('tlBcLoadFact').setValue(this.layerArrayList[i].tlBcLoadFact);
    //     controlArray.controls[index].get('tlBcMinRate').setValue(this.cpipe.transform(this.layerArrayList[i].tlBcMinRate));
    //     controlArray.controls[index].get('tlBcMaxRate').setValue(this.cpipe.transform(this.layerArrayList[i].tlBcMaxRate));
    //     controlArray.controls[index].get('tlPrem').setValue(this.cpipe.transform(this.layerArrayList[i].tlPrem));
    //     controlArray.controls[index].get('tlPremRol').setValue(this.layerArrayList[i].tlPremRol);
    //     controlArray.controls[index].get('tlMinPrem').setValue(this.layerArrayList[i].tlMinPrem);
    //     controlArray.controls[index].get('tlDepPremPerc').setValue(this.layerArrayList[i].tlDepPremPerc);
    //     controlArray.controls[index].get('tlDepPrem').setValue(this.cpipe.transform(this.layerArrayList[i].tlDepPrem));
    //     controlArray.controls[index].get('tlDepPremRol').setValue(this.layerArrayList[i].tlDepPremRol);
    //     controlArray.controls[index].get('tlReinstUnltdYn').setValue(this.layerArrayList[i].tlReinstUnltdYn == "1" ? true : false);
    //     if(this.layerArrayList[i].tlReinstUnltdYn == "1"){
    //       controlArray.controls[index].get('tlNoOfReinst').disable();
    //     }else{
    //       controlArray.controls[index].get('tlNoOfReinst').enable();
    //     }
    //     if("AR" ==this.layerArrayList[i].tlRateType){
    //       controlArray.controls[index].get('tlBcLoadFact').disable();
    //       controlArray.controls[index].get('tlBcMinRate').disable();
    //       controlArray.controls[index].get('tlBcMaxRate').disable();
    //       controlArray.controls[index].get('tlAdjustRate').enable();
    //       // (document.getElementById('tlAdjustRate_' + index) as HTMLInputElement).readOnly = false;
    //       // (document.getElementById('tlBcLoadFact_' + index) as HTMLInputElement).readOnly = true;
    //       // (document.getElementById('tlBcMinRate_' + index) as HTMLInputElement).readOnly = true;
    //       // (document.getElementById('tlBcMaxRate_' + index) as HTMLInputElement).readOnly = true;
    //     }else {
    //       controlArray.controls[index].get('tlBcLoadFact').enable();
    //       controlArray.controls[index].get('tlBcMinRate').enable();
    //       controlArray.controls[index].get('tlBcMaxRate').enable();
    //       controlArray.controls[index].get('tlAdjustRate').disable();
    //       // (document.getElementById('tlAdjustRate_' + index) as HTMLInputElement).readOnly = true;
    //       // (document.getElementById('tlBcLoadFact_' + index) as HTMLInputElement).readOnly = false;
    //       // (document.getElementById('tlBcMinRate_' + index) as HTMLInputElement).readOnly = false;
    //       // (document.getElementById('tlBcMaxRate_' + index) as HTMLInputElement).readOnly = false;
    //     }
    //     var tlNoOfReinst = this.layerArrayList[i].tlNoOfReinst;
    //     controlArray.controls[index].get('tlNoOfReinst').setValue(this.layerArrayList[i].tlNoOfReinst);
    //     controlArray.controls[index].get('tlMaxRec').setValue(this.layerArrayList[i].tlMaxRec);
    //     controlArray.controls[index].get('tlStatus').setValue(this.layerArrayList[i].tlStatus);
    //     controlArray.controls[index].get('tlCrDt').setValue(this.layerArrayList[i].tlCrDt);
    //     controlArray.controls[index].get('tlCrUid').setValue(this.layerArrayList[i].divnCtlCrUidrUid);
    //     if (this.reInsurerArrayList != null && this.reInsurerArrayList.length > 0) {
    //       for (var j = 0; j < this.reInsurerArrayList.length; j++) {
    //         if ("Layer " + (index + 1) == this.reInsurerArrayList[j].ttyReinstPK.tiLayer) {
    //           this.addReInstList(index, tlNoOfReinst);
    //           break;
    //         }
    //       }

    //       const controlArray2 = <UntypedFormArray>controlArray.controls[index].get('reinsurerList');
    //       let controlIndex = 0;
    //       for (var k = 0; k < this.reInsurerArrayList.length; k++) {
    //         if ("Layer " + (index + 1) == this.reInsurerArrayList[k].ttyReinstPK.tiLayer && controlIndex < tlNoOfReinst) {
    //           controlArray2.controls[controlIndex].get('tiRefNo').setValue(this.reInsurerArrayList[controlIndex].ttyReinstPK.tiRefNo);
    //           controlArray2.controls[controlIndex].get('tiAmendNo').setValue(this.reInsurerArrayList[controlIndex].ttyReinstPK.tiAmendNo);
    //           controlArray2.controls[controlIndex].get('tiLayer').setValue(this.reInsurerArrayList[controlIndex].ttyReinstPK.tiLayer);
    //           controlArray2.controls[controlIndex].get('tiReinstNo').setValue(this.reInsurerArrayList[controlIndex].ttyReinstPK.tiReinstNo);

    //           controlArray2.controls[controlIndex].get('tiStatus').setValue(this.reInsurerArrayList[controlIndex].tiStatus);
    //           controlArray2.controls[controlIndex].get('tiReinstPerc').setValue(this.reInsurerArrayList[controlIndex].tiReinstPerc);
    //           controlArray2.controls[controlIndex].get('tiCrUid').setValue(this.reInsurerArrayList[controlIndex].tiCrUid);
    //           controlArray2.controls[controlIndex].get('tiCrDt').setValue(this.reInsurerArrayList[controlIndex].tiCrDt);
    //           controlIndex++;

    //         }
    //       }
    //     }


    //   }
    //  this.loaderService.isBusy = false;
    //   this.calculateLimits();
    //   this.calculateDeductable();
    //   this.calculateRoleDepositPremium();
    //   this.calculateTotalDepositPremium();
    //   this.calculateTotalAdjustmentRate();
    //   this.calculateTotalMinimunPremium();
    //   this.calculateTotalRolePremium();
    //   this.calculateTotalPremium();
    //   this.showLayerBtn.emit("Y");
    // });
    //this.loadReInstDetails();

  }


<<<<<<< HEAD
  disableFilelds(type, index) {
=======
  diableFilelds(type, index) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
    this.calculatePremium(0, index);
    if ("AR" == type) {
      // (document.getElementById('tlAdjustRate_' + index) as HTMLInputElement).readOnly = false;
      // (document.getElementById('tlBcLoadFact_' + index) as HTMLInputElement).readOnly = true;
      // (document.getElementById('tlBcMinRate_' + index) as HTMLInputElement).readOnly = true;
      // (document.getElementById('tlBcMaxRate_' + index) as HTMLInputElement).readOnly = true;
      controlArray.controls[index].get('tlBcLoadFact').disable();
      controlArray.controls[index].get('tlBcMinRate').disable();
      controlArray.controls[index].get('tlBcMaxRate').disable();
      controlArray.controls[index].get('tlAdjustRate').enable();
      controlArray.controls[index].get('tlBcLoadFact').setValue('');
      controlArray.controls[index].get('tlBcMinRate').setValue('');
      controlArray.controls[index].get('tlBcMaxRate').setValue('');

    } else if ("BR" == type) {
      controlArray.controls[index].get('tlAdjustRate').setValue('');
      // (document.getElementById('tlAdjustRate_' + index) as HTMLInputElement).readOnly = true;
      // (document.getElementById('tlBcLoadFact_' + index) as HTMLInputElement).readOnly = false;
      // (document.getElementById('tlBcMinRate_' + index) as HTMLInputElement).readOnly = false;
      // (document.getElementById('tlBcMaxRate_' + index) as HTMLInputElement).readOnly = false;
      controlArray.controls[index].get('tlBcLoadFact').enable();
      controlArray.controls[index].get('tlBcMinRate').enable();
      controlArray.controls[index].get('tlBcMaxRate').enable();
      controlArray.controls[index].get('tlAdjustRate').disable();
    } else {
      // (document.getElementById('tlAdjustRate_' + index) as HTMLInputElement).readOnly = true;
      // (document.getElementById('tlBcLoadFact_' + index) as HTMLInputElement).readOnly = true;
      // (document.getElementById('tlBcMinRate_' + index) as HTMLInputElement).readOnly = true;
      // (document.getElementById('tlBcMaxRate_' + index) as HTMLInputElement).readOnly = true;
      controlArray.controls[index].get('tlBcLoadFact').disable();
      controlArray.controls[index].get('tlBcMinRate').disable();
      controlArray.controls[index].get('tlBcMaxRate').disable();
      controlArray.controls[index].get('tlAdjustRate').disable();
    }
  }



  /*..calculation ........*/
  calculatePremium(rate: number, index) {
    this.calculateTotalAdjustmentRate();
    if (rate != null && this.egnpAmt != undefined && this.egnpAmt != null) {
      let prem = (rate * this.egnpAmt) / 100;
<<<<<<< HEAD
=======
      console.log("premium", prem);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
      controlArray.controls[index].get('tlPrem').setValue(prem);
      this.calculateTotalPremium();

      let limits = controlArray.controls[index].get('tlLimit').value;
      let rolPremium = (prem / limits) * 100;
      controlArray.controls[index].get('tlPremRol').setValue(rolPremium);
      this.calculateTotalRolePremium();

      let depPremiumPercent = controlArray.controls[index].get('tlDepPremPerc').value;
      if (depPremiumPercent != undefined && depPremiumPercent != null && depPremiumPercent != "") {
        let depPremium = (prem * depPremiumPercent) / 100;
        controlArray.controls[index].get('tlDepPrem').setValue(depPremium);
        this.calculateTotalDepositPremium();
        let limits = controlArray.controls[index].get('tlLimit').value;
        let RolDepPremium = (depPremium / limits) * 100;
        controlArray.controls[index].get('tlDepPremRol').setValue(RolDepPremium);
        this.calculateRoleDepositPremium();
      }
    }
  }

  calculateDepositPremium(percent, index) {
    const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
    if ("AR" == controlArray.controls[index].get('tlRateType').value &&
      (controlArray.controls[index].get('tlAdjustRate').value == null || controlArray.controls[index].get('tlAdjustRate').value == "")) {
      this.toastService.warning("Please Enter Adjustment Rate");
      return false;
    } else if ("BR" == controlArray.controls[index].get('tlRateType').value &&
      (controlArray.controls[index].get('tlBcMinRate').value == null || controlArray.controls[index].get('tlBcMinRate').value == "")) {
      this.toastService.warning("Please Enter Minimum Burning Cost Rate.");
      return false;
    }

    let premium = controlArray.controls[index].get('tlPrem').value;
    let depPremium = (premium * percent) / 100;
    controlArray.controls[index].get('tlDepPrem').setValue(depPremium);
    this.calculateTotalDepositPremium();
    let limits = controlArray.controls[index].get('tlLimit').value;
    let RolDepPremium = (depPremium / limits) * 100;
    controlArray.controls[index].get('tlDepPremRol').setValue(RolDepPremium);
    this.calculateRoleDepositPremium();
  }


  calculateMaxRecoverable(val, index) {

    this.addReInstList(index, val);
    const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
    let limits = controlArray.controls[index].get('tlLimit').value;
    //alert("Limit --- " + limits + " Value  "+ (val + 1) * limits)
    let maxRecAmt = (parseFloat(val) + 1) * parseFloat(limits);
    controlArray.controls[index].get('tlMaxRec').setValue(maxRecAmt);
  }

  calculateMaxRecoverableByPercent(layerIndex) {
    const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
    let limits = controlArray.controls[layerIndex].get('tlLimit').value;
    var reinstNo = controlArray.controls[layerIndex].get('tlNoOfReinst').value;
    const control2 = <UntypedFormArray>controlArray.controls[layerIndex].get('reinsurerList');
    var totalPercentage: number = 0;
    if (reinstNo != "" && reinstNo > 0) {
      for (var i = 0; i < reinstNo; i++) {
        totalPercentage = totalPercentage + parseInt(control2.controls[i].get('tiReinstPerc').value == "" ? "0" : control2.controls[i].get('tiReinstPerc').value);
      }
      var maxvalue = (((totalPercentage / 100) * parseInt(limits)) + parseInt(limits));
      controlArray.controls[layerIndex].get('tlMaxRec').setValue(maxvalue);
    } else {
      controlArray.controls[layerIndex].get('tlMaxRec').setValue(limits);
    }
  }

  calculateDefaultMaxrecoverable(index) {
    const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
    const control2 = <UntypedFormArray>controlArray.controls[index].get('reinsurerList');
    let reinstNo = controlArray.controls[index].get('tlNoOfReinst').value;
    if (reinstNo == null || reinstNo == "" || reinstNo == "0") {
      let limits = controlArray.controls[index].get('tlLimit').value;
      controlArray.controls[index].get('tlMaxRec').setValue(limits);
    } else {
      let limits = controlArray.controls[index].get('tlLimit').value;
      var maxValue = limits * (1 + reinstNo);
      controlArray.controls[index].get('tlMaxRec').setValue(maxValue);
      // if(reinstNo !="" && reinstNo >0){
      //   var totalPercentage:number=0;
      //   for(var i=0;i<reinstNo;i++){
      //     totalPercentage=totalPercentage+parseFloat(control2.controls[i].get('tiReinstPerc').value == ""?"0":control2.controls[i].get('tiReinstPerc').value);
      //   }
      //   var maxvalue=(((totalPercentage/100)*parseFloat(limits))+parseFloat(limits));
      //   controlArray.controls[index].get('tlMaxRec').setValue(maxvalue);
      // }
    }
    this.calculateLimits();
  }
  calculateLimits() {
    let layerList = this.layerForm.get("layerList").value;

    if (layerList != null && layerList.length > 0) {

      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      for (var i = 0; i < layerList.length; i++) {
        var layerlimits: number = parseFloat(layerList[i].tlLimit == "" ? 0 : layerList[i].tlLimit);
        total = total + layerlimits;
      }

      this.totalLimits = total;
    }
  }
  calculateDeductable() {
    let layerList = this.layerForm.get("layerList").value;
    if (layerList != null && layerList.length > 0) {
      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      //  for (var i = 0; i < layerList.length; i++) {
      var layerlimits: number = parseFloat(layerList[0].tlDeductible == "" ? 0 : layerList[0].tlDeductible);
      total = total + layerlimits;
      // }
      this.totaldeductable = total;
    }
  }
  calculateRoleDepositPremium() {
    let layerList = this.layerForm.get("layerList").value;
    if (layerList != null && layerList.length > 0) {
      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      for (var i = 0; i < layerList.length; i++) {
        var layerlimits: number = parseFloat(layerList[i].tlDepPremRol == "" ? 0 : layerList[i].tlDepPremRol);
        total = total + layerlimits;
      }
      this.totalRolDepositPremium = total;
    }
  }

  calculateTotalDepositPremium() {
    let layerList = this.layerForm.get("layerList").value;
    if (layerList != null && layerList.length > 0) {
      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      for (var i = 0; i < layerList.length; i++) {
        var layerlimits: number = parseFloat(layerList[i].tlDepPrem == "" ? 0 : layerList[i].tlDepPrem);
        total = total + layerlimits;
      }
      this.totalDepositPremium = total;
    }
  }
  calculateTotalAdjustmentRate() {
    let layerList = this.layerForm.get("layerList").value;
    if (layerList != null && layerList.length > 0) {
      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      for (var i = 0; i < layerList.length; i++) {
        if ('AR' == layerList[i].tlRateType) {
          var layerlimits: number = parseFloat(layerList[i].tlAdjustRate == "" ? 0.0 : layerList[i].tlAdjustRate);
          total = total + layerlimits;
        }
      }
      this.totalAdjustmentRate = total;
    }
  }
  calculateTotalMinimunPremium() {
    let layerList = this.layerForm.get("layerList").value;
    if (layerList != null && layerList.length > 0) {
      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      for (var i = 0; i < layerList.length; i++) {
        var layerlimits: number = parseFloat(layerList[i].tlLimit == "" ? 0 : layerList[i].tlMinPrem);
        total = total + layerlimits;
      }
      this.totalMinimumPremium = total;
    }
  }
  calculateTotalRolePremium() {
    let layerList = this.layerForm.get("layerList").value;
    if (layerList != null && layerList.length > 0) {
      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      for (var i = 0; i < layerList.length; i++) {
        var layerlimits: number = parseFloat(layerList[i].tlLimit == "" ? 0 : layerList[i].tlPremRol);
        total = total + layerlimits;
      }
      this.totalRolePremium = total;
    }
  }
  calculateTotalPremium() {
    let layerList = this.layerForm.get("layerList").value;
    if (layerList != null && layerList.length > 0) {
      //this.deptCode=departmentList[0].costCode;
      var total: number = 0;
      for (var i = 0; i < layerList.length; i++) {
        var layerlimits: number = parseFloat(layerList[i].tlLimit == "" ? 0 : layerList[i].tlPrem);
        total = total + layerlimits;
      }
      this.totalPremium = total;
    }
  }

  enableReinst(event, index) {
    const controlArray = <UntypedFormArray>this.layerForm.get('layerList');
    const controlArray2 = <UntypedFormArray>controlArray.controls[index].get('reinsurerList');

    if (event.target.checked) {
      controlArray.controls[index].get('tlNoOfReinst').setValue("0");
      controlArray.controls[index].get('tlNoOfReinst').disable();
      this.addReInstList(index, 0);
      // this.calculateMaxRecoverableByPercent(index);
      controlArray.controls[index].get('tlMaxRec').setValue('');
    } else {
      controlArray.controls[index].get('tlNoOfReinst').setValue("0");
      controlArray.controls[index].get('tlNoOfReinst').enable();
      this.addReInstList(index, 0);
      this.calculateDefaultMaxrecoverable(index)
    }

  }

  printDocument() {

    var params = {
      refNo: this.refNo,
      amendNo: this.amendNo,
      compCode: this.session.get("companyCode"),
      repId: 'RI_SCH_001',
      docType: 'DEP_PREM'
    }
    this.treatyService.fetchReportUrl(params)
      .subscribe(result => {
        var url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
      width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(url, 'Reports', param);

      });

  }
  ngAfterViewInit() {

    $('.selectpicker').selectpicker();
    setTimeout(() => {
      $('.selectpicker').selectpicker('refresh');
    }, 500);
  }

  percentageValidaton(val, index) {
    let value = val.replace('?:\b|-)([1-9]{1,2}[0]?|100)\b/');
  }
  closeModal() {
    this.modalService.hide();
  }
  getPerilDetails(layerNo) {
    this.loaderService.isBusy = true;
    this.layerNum = "Layer " + (layerNo + 1);
    this.treatyService.getSelectedPerilList("Layer " + (layerNo + 1), this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      this.details = resp.perilList;
      this.scriptcall('peril');
      this.loaderService.isBusy = false;
    }, error => {
      this.scriptcall('peril');
      this.loaderService.isBusy = false;
    })
  }


  deletePerilDetails(detail) {
    this.loaderService.isBusy = true;
    this.treatyService.deletePerilById(this.refNo, detail.key, this.amendNo, this.layerNum, this.seqNo, this.amndSrNo).subscribe(resp => {
      this.getPerilDetails(this.layerNo);
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }
  readUrl(e) {
    this.loaderService.isBusy = true;
    let file: File = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    let formData: FormData = new FormData();
    formData.append('file', file, file.name);
    formData.append('tdiRefNo', this.refNo);
    formData.append('doctype', "XL-CON");
    formData.append('userId', this.session.get("userId"));
    var uploadDocumentReponse = this.treatyService.uploadDoc(formData);
    // this.upload = uploadDocumentReponse._isScalar;
    this.loaderService.isBusy = false;
  }

  getLayerFormControls() {
    return (this.layerForm.get('layerList') as UntypedFormArray);
  }
}