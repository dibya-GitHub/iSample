import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyLayerComponent } from './treaty-layer.component';

describe('TreatyLayerComponent', () => {
  let component: TreatyLayerComponent;
  let fixture: ComponentFixture<TreatyLayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyLayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyLayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
