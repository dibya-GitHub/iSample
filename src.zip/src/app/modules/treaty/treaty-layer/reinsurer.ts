export class Reinsurer {
    ttyReinstPK:any;
    tiReinstPerc:number;
    tiRefNo:string;
    tiAmendNo:string;
    tiLayer:string;
    tiReinstNo:string;    
    tiStatus:string;
    tiCrUid:string;
    tiCrDt:Date;
    tiUpdUid:string;
    tiUpdDt:Date;
}
