import { DatePipe } from '@angular/common';
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
<<<<<<< HEAD
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
=======
import { ApiUrls } from 'src/app/api-urls';
import { DatePipe } from '@angular/common'; import * as moment from 'moment';
declare var $: any;
import { AGNPIComponent } from '../agnpi/agnpi.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { ToastService } from 'src/app/services/toast.service';
import { DocumentService } from 'src/app/shared/components/document/document.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { AGNPIComponent } from '../agnpi/agnpi.component';
import { EditviewrenderComponent } from '../editviewrender/editviewrender.component';
<<<<<<< HEAD
import { RadiorenderComponent } from '../radiorender/radiorender.component';
declare var $: any;
=======
import { LoaderService } from 'src/app/services/loader.service';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { param } from 'jquery';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-edit-adjust-premium',
  templateUrl: './edit-adjust-premium.component.html',
  styleUrls: ['./edit-adjust-premium.component.css'],
  providers: [DatePipe]
})
export class EditAdjustPremiumComponent implements OnInit {
  userList: any;
  rowSelection: string;
  recGridApi: any;
  reinstGridApi: any;
  adjGridApi: any;
  @ViewChild('content') content: ElementRef;
  @ViewChild('agNpComponent') agnpiModal: AGNPIComponent;

  showPrintBtn = false;
  showContractDivs = false;
  ShowRecoveryDivs = false;
  searchDiv = false;
  mode: string;
  transId: string;
  seqNo: string;
  type: string;

  details: any[];
  layerDetails: any[];
  reinsurerDetails: any[] = [];
  recoveryDetails: any[];
  contractDetails: any = [];

  layerNo: string;
  totalRecoveredPaid: number = 0;
  totalReInstPaid: number = 0;

  totalAdjustRate: number = 0;
  totalPremium: number = 0;
  totalDepositPremium: number = 0;
  totalFinalPremium: number = 0;
  totalXLRecovered: number = 0;
  totalLayerReInstPaid: number = 0;
  totalActualInst: number = 0;
  totalPremBalance: number = 0;
  totalReinstBalance: number = 0;

  totalReinsurerShare: number = 0;
  totalreinsurerDeposit: number = 0;
  totalActualAdjust: number = 0;
  totalReinsurerPremBal: number = 0;
  totalReinsurerReinstPaid: number = 0;
  totalReinsurerActualReinstPaid: number = 0;
  totalReinsurerReinstBal: number = 0;

  totalLayerLimits: number = 0;
  totalLayerExcess: number = 0;

  totalReinsAdjustRate: number = 0;
  totalReinsTotalPrem: number = 0;

  filename = [];
  myFiles: string[] = [];
  upload: boolean = true;

  referenceNo: string;
  seqcount: any;
  seqList: any;

  processId: string;

  gridtitle: string;

  processBy: string;
  createdDate: string;

  recoveryColumn: any[];
  layerColumn: any[];
  reinsurerColumn: any[]; 
  contractColumn: any[];
  AdjustmentCoumn: any[];
  AdjustmentCoumnView: any[];
  reInsSummaryColumn: any[];
  action: string;
  amendNo: string = '0';

  defaultColDef: any;
  getRowHeight;
  frameworkComponents;
  context;
  contractGridApi: any;
  gridColumnApi: any;
  showContractEntriesOptionSelected = 5;
  showAdjEntriesOptionSelected = 5;
  showReinstEntriesOptionSelected = 5;
  showRecEntriesOptionSelected = 5;
  showEntriesOptions = [5, 10, 20, 50, 100];
  gridApiReinsurer: any;
  gridApiAdjust: any;
  gridApiContract: any;
  gridApiRecovery: any;
  recoverySearchValue: any;
  initSearchValue: string = '';
  contractSearchValue: string = '';
  adjustSearchValue: string = '';
  reinsurerSearchValue: string = '';
  summarySearchValue: string = '';
  showSummaryEntriesOptionSelected = 5;
  pinnedBottomLayerData: any[];
  @ViewChild('confirmcontent') confirmation: ElementRef;
  reinsSummaryDetails: any = [];
  documentRefId: string;
  showApproveBtn: boolean = false;
  getRowStyle: (params: any) => { 'font-weight': string; };

  @Input()
  get docRefId(): string {
    if (this.type && this.transId) {
      return this.transId + this.type;
    } else {
      return;
    }
  }
  documents: any[];
  documentTypes: any[];
  isDocumentNeedsToBeUpdated: boolean;
  adjForm: UntypedFormGroup;
  pinnedBottomReinsurerData: any[];
  pinnedBottomSummaryData: any[];
<<<<<<< HEAD

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private treatyService: TreatyService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
    private datePipe: DatePipe,
    private docService: DocumentService
  ) {
=======
  public components;
  constructor(private treatyService: TreatyService,
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private router: Router, private datePipe: DatePipe,
    private docService: DocumentService, private modalService: BsModalService,) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false,      
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
  }

  ngOnInit() {
    this.rowSelection = 'single'
    this.type = this.treatyService.getParamValue('type');
    this.referenceNo = this.treatyService.getParamValue('refNo');
    // alert( "1"+this.referenceNo);
    this.seqNo = this.treatyService.getParamValue('seqNo');
    this.mode = this.treatyService.getParamValue('mode');
    this.transId = this.treatyService.getParamValue('transId');
    this.amendNo = this.treatyService.getParamValue('amendNo');
    this.documentRefId = 'A-' + this.transId + '-' + this.type;
    this.action = this.mode;
    this.adjForm = this.fb.group({
      contractRef: this.referenceNo,
      seqNo: this.seqNo,
    })
    this.adjForm.get('contractRef').setValue(this.referenceNo)
    this.adjForm.get('seqNo').setValue(this.seqNo)
    this.getDocumentTypes();
    if ("add" == this.mode) {
      this.searchDiv = true;
    } else {
      this.searchDiv = false;
      this.fetchContractDetails();
    }
    if (this.type == 'DEP_PREM') {
      this.gridtitle = 'Adjustment - Deposit Premium'
    } else if (this.type == 'NCB') {
      this.gridtitle = 'No Claim Bonus';
    } else {
      this.gridtitle = 'Adjustment - Reinstatement Premium'
    }
    this.loadseqencenumber();

    if (ApiUrls.ADJUST_TYPE_DEP == this.type || ApiUrls.ADJUST_TYPE_REINST == this.type) {

      this.recoveryColumn = [
        { field: 'tacTtyRefNo', headerName: 'Recovery Ref', sortable: true, tooltipField: 'tacTtyRefNo', filter:true,},
        { field: 'tacRecApprDt', headerName: 'Date', sortable: true, tooltipField: 'tacRecApprDt', filter:true,},
        {
          field: 'tacXlType', headerName: 'Risk/CAT', sortable: true, tooltipField: 'tacXlType', filter:true,
          valueGetter: function (params) {
            if (params.data.tacXlType != null && params.data.riskDesc != null) {
              return params.data.tacXlType + '-' + params.data.riskDesc
            } else {
              return params.data.tacXlType;
            }
          }
        },
        { field: 'tacClmNo', headerName: 'Claim No/Event', sortable: true, tooltipField: 'tacClmNo', filter:true,},
        {
          field: 'tacPremCurr', headerName: 'Currency', headerClass: 'right-align-class',
          //  cellStyle: { textAlign: 'right' },
          sortable: true, tooltipField: 'tacPremCurr',filter:true,
        },
        { field: 'tacRecovered', headerName: 'Recovered', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tacRecovered', valueFormatter: numberFormatter, filter:true,},

      ]


      this.AdjustmentCoumn = [
        { field: 'txaTransId', headerName: 'Process Id', sortable: true, tooltipField: 'txaTransId', enableRowGroup: true, filter:true,},
        { field: 'TxaTtySeqNo', headerName: 'Reference No', sortable: true, tooltipField: 'TxaTtySeqNo', enableRowGroup: true, filter:true, },
        { field: 'txaCrDt', headerName: 'Processed Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaCrDt', enableRowGroup: true,filter:true, },
        { field: 'txaCrUid', headerName: 'Processed By', sortable: true, tooltipField: 'txaCrUid', enableRowGroup: true,filter:true, },
        { field: 'txaApprDt', headerName: 'Approved Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaApprDt', enableRowGroup: true,filter:true, },
        { field: 'ApprovedBy', headerName: 'Approved By', sortable: true, tooltipField: 'ApprovedBy', enableRowGroup: true, filter:true, },
        { field: 'txaApprSts', headerName: 'Status', sortable: true, tooltipField: 'txaApprSts',filter:true, },
        {
          
          headerName: 'Action',
          cellRendererFramework: EditviewrenderComponent,
          cellStyle: { textAlign: 'center' },
          sortable: false,
          filter: false,
          enableRowGroup: false,
        }
      ];
      this.contractColumn = [
        { field: 'txlAdjTtyPK.tatTtyRefNo', headerName: 'Contract', sortable: true, tooltipField: 'txlAdjTtyPK.tatTtyRefNo', filter:true,},
        { field: 'tatTtyDesc', headerName: 'Description', sortable: true, tooltipField: 'tatTtyDesc', filter:true, },
        { field: 'tatProgCode', headerName: 'Program Code', sortable: true, tooltipField: 'tatProgCode', filter:true,},
        { field: 'tatXlType', headerName: 'XL Type', color: '', sortable: true, tooltipField: 'tatXlType', filter:true, },
        { field: 'tatStartDt', 
          headerName: 'Start Date', 
          sortable: true, 
          cellRenderer: 'strtDateCellRenderer',          
          valueGetter: function (params) {
            if (params && params.data && params.data.tatStartDt) {
              return moment(params.data.tatStartDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          filter:true,
          filterParams: filterParams,
        },
        {
          field: 'tatEndDt',
          headerName: 'End Date',
          sortable: true,          
          cellRenderer: 'endDateCellRenderer',
          valueGetter: function (params) {
            if (params && params.data && params.data.tatEndDt) {
              return moment(params.data.tatEndDt).format('DD/MM/YYYY');
            } else {
              return '';
            }
          },
          filter:true,
          filterParams: filterParams,
         },
        { field: 'tatCurr', headerName: 'Currency', sortable: true, tooltipField: 'tatEpi',filter:true, },
        { field: 'tatEpi', headerName: 'EGNPI', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tatEpi', valueFormatter: numberFormatter, filter:true,},
        { field: 'tatApi', headerName: 'AGNPI', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tatApi', valueFormatter: numberFormatter, filter:true,},
        {
<<<<<<< HEAD
          headerName: "Action", cellStyle: { textAlign: 'center' }, template:
            `<a>
            <i class="fa fa-file-pen fa-icon" style="color:#009ca6" data-action-type="AGNPI"  title="Edit" aria-hidden="true"></i>&nbsp;&nbsp;
      </a>`  }
=======
          headerName: "Action",
          field: 'txlAdjTtyPK.tatTtyRefNo',
          sortable: false,
          filter: false,
          enableRowGroup: false,
          cellStyle: { textAlign: 'center' },
          cellRenderer: function (params) {
            if (params.value) {
              return `<a>
                        <i class="fa fa-file-pen fa-icon" style="color:#009ca6" data-action-type="AGNPI"  title="Edit" aria-hidden="true"></i>&nbsp;&nbsp;
                      </a>`
            } else {
              return ``;
            }
          },
          //      template:
          //       `<a>
          //       <i class="fa fa-file-pen fa-icon" style="color:#009ca6" data-action-type="AGNPI"  title="Edit" aria-hidden="true"></i>&nbsp;&nbsp;
          // </a>`  
        }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      ]
      this.components = {
        strtDateCellRenderer: strtDateCellRenderer,
        endDateCellRenderer: endDateCellRenderer
      };
      this.AdjustmentCoumnView = [
        { field: 'txaTransId', headerName: 'Process Id', sortable: true, tooltipField: 'txaTransId', enableRowGroup: true,  filter: true},
        { field: 'TxaTtySeqNo', headerName: 'Reference No', sortable: true, tooltipField: 'TxaTtySeqNo', enableRowGroup: true ,  filter: true},
        { field: 'txaCrDt', headerName: 'Processed Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaCrDt', enableRowGroup: true, filter: true },
        { field: 'txaCrUid', headerName: 'Processed By', sortable: true, tooltipField: 'txaCrUid', enableRowGroup: true , filter: true},
        { field: 'txaApprDt', headerName: 'Approved Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaApprDt', enableRowGroup: true, filter: true },
        { field: 'ApprovedBy', headerName: 'Approved By', sortable: true, tooltipField: 'ApprovedBy', enableRowGroup: true, filter: true },
        { field: 'txaApprSts', headerName: 'Status', sortable: true, tooltipField: 'txaApprSts' },
        {
<<<<<<< HEAD
          headerName: "Action", cellStyle: { textAlign: 'center' }, template:
            `<a>
                <i class="fa fa-file-pen fa-icon"  style="color:#009ca6" data-action-type="Edit" style="font-size: 1.55em" title="Edit" aria-hidden="true" ></i>
                &nbsp;&nbsp;
                </a>`
=======
          headerName: "Action",field: 'txaTransId', cellStyle: { textAlign: 'center' }, 
          filter: false ,
                cellRenderer: function (params) {
                  if (params.value) {
                    return ` <a>
                    <i class="fa fa-file-pen fa-icon"  style="color:#009ca6" data-action-type="Edit" title="Edit" aria-hidden="true" ></i>
                    &nbsp;&nbsp;
                    </a>`
            } else {
              return ``;
            }
          }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        }

      ];
      this.reInsSummaryColumn = [
        { field: 'tarBroker', headerName: 'Broker', tooltipField: 'tarBroker', filter: true },
        { field: 'tarPremCurr', headerName: 'Prem CCY', tooltipField: 'tarPremCurr', filter: true },
        { field: 'tarReinstActl', headerName: 'Accounting Premium', tooltipField: 'tarReinstActl', cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter, filter: true },
        { field: 'tarDepPaid', headerName: 'Deposit Premium', tooltipField: 'tarDepPaid', cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter, filter: true },
        { field: 'tarReinstBal', headerName: 'Balance Due', tooltipField: 'tarReinstBal', cellStyle: { textAlign: 'right' }, valueFormatter: numberFormatter, filter: true },
      ];
    }
    if (ApiUrls.ADJUST_TYPE_DEP == this.type) {

      this.layerColumn = [
        { field: 'talTtySeqNo', headerName: 'Seq No', sortable: true, tooltipField: 'talTtySeqNo', filter: true },
        { field: 'txlAdjLayerPK.talLayer', headerName: 'Layer', sortable: true, tooltipField: 'txlAdjLayerPK.talLayer', filter: true },
        { field: 'talLimitCurr', headerName: 'Currency', sortable: true, tooltipField: 'talLimitCurr', filter: true },
        { field: 'talLimit', headerName: 'Limit', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talLimit', valueFormatter: numberFormatter, filter: true },
        { field: 'talDeductible', headerName: 'Excess', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talDeductible', valueFormatter: numberFormatter, filter: true },
        { field: 'talRecoverd', headerName: 'XL Recovered', sortable: true, tooltipField: 'talRecoverd', filter: true , valueFormatter: numberFormatter},
        { field: 'talAdjRate', headerName: 'Adjust Rate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talAdjRate', valueFormatter: numberFormatter, filter: true },
        { field: 'talPrem', headerName: '100% Prem', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talPrem', valueFormatter: numberFormatter, filter: true },
        { field: 'talDepPaid', headerName: 'Deposit Paid', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talDepPaid', valueFormatter: numberFormatter, filter: true },
        { field: 'talFinalPrem', headerName: 'Final Prem', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talFinalPrem', valueFormatter: numberFormatter, filter: true },
        { field: 'talPremBal', headerName: 'Balance Prem', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talPremBal', valueFormatter: numberFormatter, filter: true },
        {
          headerName: "Action",
          field: 'txlAdjLayerPK.talLayer',
          cellStyle: { textAlign: 'center' },          
          filter: true,
          cellRenderer: function (params) {
            if (params.value) {
              return ` <a>	
             <i class="fa fa-eye fa-icon"  data-action-type="Recovery"  title="View" aria-hidden="true"></i>&nbsp;&nbsp;	
             &nbsp;`
            } else {
              return ``;
            }
          }
        }
      ]
    } else if (ApiUrls.ADJUST_TYPE_REINST == this.type) {
      this.layerColumn = [
        { field: 'talTtySeqNo', headerName: 'Sequence No', sortable: true, tooltipField: 'talTtySeqNo', filter: true },
        { field: 'txlAdjLayerPK.talLayer', headerName: 'Layer', sortable: true, tooltipField: 'txlAdjLayerPK.talLayer', filter: true },
        { field: 'talLimitCurr', headerName: 'Currency', sortable: true, tooltipField: 'talLimitCurr', filter: true },
        { field: 'talLimit', headerName: 'Limit', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talLimit', valueFormatter: numberFormatter, filter: true },
        { field: 'talDeductible', headerName: 'Excess', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talDeductible', valueFormatter: numberFormatter, filter: true },
        { field: 'talAdjRate', headerName: 'Adjust Rate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talAdjRate', valueFormatter: numberFormatter, filter: true },
        { field: 'talDepPaid', headerName: 'Deposit Paid', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talDepPaid', valueFormatter: numberFormatter, filter: true },
        { field: 'talFinalPrem', headerName: 'Final Prem', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talFinalPrem', valueFormatter: numberFormatter, filter: true },
        { field: 'talRecoverd', headerName: 'XL Recovered', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talRecoverd', valueFormatter: numberFormatter, filter: true },
        { field: 'talReinstPaid', headerName: 'Reinst Paid', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talReinstPaid', valueFormatter: numberFormatter, filter: true },
        { field: 'talReinstActl', headerName: 'Actual Reinstate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talReinstActl', valueFormatter: numberFormatter, filter: true },
        { field: 'talReinstBal', headerName: 'Balance Reinstate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talReinstBal', valueFormatter: numberFormatter, filter: true },
        {
          headerName: "Action",
          field: 'txlAdjLayerPK.talLayer',
          cellStyle: { textAlign: 'center' },
          filter: false,
          cellRenderer: function (params) {
            if (params.value) {
              return ` <a>	
             <i class="fa fa-eye fa-icon"  data-action-type="Recovery"  title="View" aria-hidden="true"></i>&nbsp;&nbsp;	
             &nbsp;`
            } else {
              return ``;
            }
          }
        }
      ];
    }


    if (ApiUrls.ADJUST_TYPE_DEP == this.type) {
      this.reinsurerColumn = [
        { field: 'txlAdjReinsPK.tarReins', headerName: 'Reinsurer', sortable: true, tooltipField: 'txlAdjReinsPK.tarReins', filter: true },
        { field: 'tarBroker', headerName: 'Broker', sortable: true, tooltipField: 'tarBroker', filter: true },
        { field: 'tarAcntTo', headerName: 'Account To', sortable: true, tooltipField: 'tarAcntTo', filter: true },
        { field: 'tarAdjRate', headerName: 'Adjust Rate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarAdjRate',cellRenderer: rateformatter, filter: true },
        { field: 'tarSharePerc', headerName: 'Share %', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarSharePerc', valueFormatter: numberFormatter, filter: true },
        { field: 'tarDepPaid', headerName: 'Deposit Paid', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter, tooltipField: 'tarDepPaid', filter: true },
        { field: 'tarFinalPrem', headerName: 'Actual Adjust', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarFinalPrem', valueFormatter: numberFormatter, filter: true },
        { field: 'tarPremBal', headerName: 'Balance Prem', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarPremBal', valueFormatter: numberFormatter, filter: true },

      ]
    } else if (ApiUrls.ADJUST_TYPE_REINST == this.type) {
      this.reinsurerColumn = [
        { field: 'txlAdjReinsPK.tarReins', headerName: 'Reinsurer', sortable: true, tooltipField: 'txlAdjReinsPK.tarReins', filter: true },
        { field: 'tarBroker', headerName: 'Broker', sortable: true, tooltipField: 'tarBroker', filter: true },
        { field: 'tarAcntTo', headerName: 'Account To', sortable: true, tooltipField: 'tarAcntTo', filter: true },
        { field: 'tarAdjRate', headerName: 'Adjust Rate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarAdjRate',cellRenderer: rateformatter, filter: true },
        { field: 'tarSharePerc', headerName: 'Share %', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarSharePerc', valueFormatter: numberFormatter, filter: true },
        { field: 'tarFinalPrem', headerName: 'Actual Adjust', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarFinalPrem', valueFormatter: numberFormatter, filter: true }, 
        { field: 'tarReinstPaid', headerName: 'Reinstate Paid', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarReinstPaid', valueFormatter: numberFormatter, filter: true },
        { field: 'tarReinstActl', headerName: 'Actual Reinstate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarReinstActl', valueFormatter: numberFormatter, filter: true },
        { field: 'tarReinstBal', headerName: 'Balance Reinstate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarReinstBal', valueFormatter: numberFormatter, filter: true },
      ]
    }

    if ('NCB' == this.type) {
      this.AdjustmentCoumn = [
        { field: 'txaTransId', headerName: 'Process Id', sortable: true, tooltipField: 'txaTransId', enableRowGroup: true, filter: true },
        { field: 'TxaTtySeqNo', headerName: 'Reference No', sortable: true, tooltipField: 'TxaTtySeqNo', enableRowGroup: true, filter: true},
        { field: 'txaCrDt', headerName: 'Processed Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaCrDt', enableRowGroup: true, filter: true },
        { field: 'txaCrUid', headerName: 'Processed By', sortable: true, tooltipField: 'txaCrUid', enableRowGroup: true, filter: true},
        { field: 'txaApprDt', headerName: 'Approved Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaApprDt', enableRowGroup: true, filter: true },
        { field: 'ApprovedBy', headerName: 'Approved By', sortable: true, tooltipField: 'ApprovedBy', enableRowGroup: true, filter: true},
        { field: 'txaApprSts', headerName: 'Status', sortable: true, tooltipField: 'txaApprSts', filter: true },
        {
          headerName: 'Action',
          cellRendererFramework: EditviewrenderComponent, cellStyle: { textAlign: 'center' },
          sortable: false,
          filter: false,
          enableRowGroup: false,
        }
      ];

      this.layerColumn = [
        { field: 'talTtySeqNo', headerName: 'Sequence No', sortable: true, tooltipField: 'talTtySeqNo', filter: true },
        { field: 'txlAdjLayerPK.talLayer', headerName: 'Layer', sortable: true, tooltipField: 'txlAdjLayerPK.talLayer', filter: true },
        { field: 'talLimitCurr', headerName: 'Currency', sortable: true, tooltipField: 'talLimitCurr', filter: true },
        { field: 'talLimit', headerName: 'Limit', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talLimit', valueFormatter: numberFormatter, filter: true },
        { field: 'talDeductible', headerName: 'Excess', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talDeductible', valueFormatter: numberFormatter, filter: true },
        { field: 'talRecoverd', headerName: 'XL Recovered', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talRecoverd', valueFormatter: numberFormatter, filter: true },
        { field: 'talFinalPrem', headerName: 'Final Prem', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'talFinalPrem', valueFormatter: numberFormatter, filter: true },

      ];
      this.reinsurerColumn = [
        { field: 'txlAdjReinsPK.tarReins', headerName: 'Reinsurer', sortable: true, tooltipField: 'txlAdjReinsPK.tarReins', filter: true },
        { field: 'tarBroker', headerName: 'Broker', sortable: true, tooltipField: 'tarBroker', filter: true },
        { field: 'tarAcntTo', headerName: 'Account To', sortable: true, tooltipField: 'tarAcntTo', filter: true },
        { field: 'tarSharePerc', headerName: 'Share %', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarSharePerc', filter: true },
        { field: 'tarAdjRate', headerName: 'Adjust Rate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarAdjRate',cellRenderer: rateformatter, filter: true },
        { field: 'tarPrem', headerName: 'Final Premium', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarPrem', valueFormatter: numberFormatter, filter: true },
        { field: 'tarReinstPaid', headerName: 'Reinstate Paid', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarReinstPaid', valueFormatter: numberFormatter, filter: true },
        { field: 'tarReinstActl', headerName: 'Actual Reinstate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarReinstActl', valueFormatter: numberFormatter, filter: true },
        { field: 'tarReinstBal', headerName: 'Balance Reinstate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, tooltipField: 'tarReinstBal', valueFormatter: numberFormatter, filter: true },
      ]
    }

  }

  loadseqencenumber() {

    this.loaderService.isBusy = true;
    this.treatyService.loadingseqno(this.referenceNo).subscribe(data => {
      this.seqList = data.seqList
      let count = this.seqList.length

      this.seqcount = count;
      if (this.seqcount == 1) {
        this.seqNo = this.seqList[0]
      }
      // this.selectScript();
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  fetch(refNo, seqNo) {
    this.seqNo = seqNo;
    this.loaderService.isBusy = true;
    this.treatyService.callAdjustmentProcedure(refNo, seqNo, this.type, this.session.get("userId")).subscribe(resp => {
      this.transId = resp.transId;
      this.ShowRecoveryDivs = false;
      this.searchDiv = false;
      this.fetchContractDetails();
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    });
  }



  fetchContractDetails() {
    this.treatyService.fetchAdjustmentContractDetails(this.transId).subscribe(resp => {
      this.showContractDivs = true;
      this.createForm(resp.contractDetails);
      this.loaderService.isBusy = false;
      //this.retrieveAgnpiDetails();
      this.retrieveXLContractDetails(resp.contractDetails);
    })
  }

  createForm(data) {
    var process = data.txaCrUid
    this.treatyService.reterieveUWriterList().subscribe(resp => {
      this.userList = resp.userList;
      if (this.userList) {
        const createdUser = this.userList.find(user => user.key === process);
        this.processBy = createdUser.value;
      }
    }, error => { });


    this.createdDate = this.datePipe.transform(data.txaCrDt, ApiUrls.DATE_FORMAT);
    this.processId = data.txaTransId;

  }

  getDocumentTypes() {
    let mcType = '';
    if (this.type === 'DEP_PREM') {
      mcType = 'OW_ADJ_DEP';
    } else {
      mcType = 'OW_ADJ_REINST';
    }
    this.treatyService.appCodesAccFreq('DMS_DOC_TYPE', mcType)
      .subscribe(res => {
        this.documentTypes = res.appcodeList;
      }, err => {
      });
  }

  getDocuments(documents) {
    this.documents = documents.fileList;
    this.isDocumentNeedsToBeUpdated = documents.isDocumentNeedsToBeUpdated;
  }


  retrieveXLContractDetails(data) {

    this.treatyService.retrieveXLContractDetails(data.txaTransId, data.txaTtyRefNo, 0).subscribe(resp => {
      this.contractDetails = resp.contractList;
      this.retriveReinsSummary(this.transId,this.type);
      // this.scriptcall('contract-table');
    }, error => {

    })
  }

  recalculate() {

    this.loaderService.isBusy = true;
    let obj = {
      transId: this.processId,
      company: this.session.get("companyCode"),
      divn: this.session.get("userDivnCode"),
      dept: this.session.get("userDeptCode"),
      userId: this.session.get("userId"),
      type: this.type
    }

    this.treatyService.recalculateAdjustment(obj).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.ShowRecoveryDivs = true;
      this.showApproveBtn = true;
      this.retrieveAdjRecoveryDetail();


    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
      this.showApproveBtn = false;
    })
  }

  approve() {
    if (this.isDocumentNeedsToBeUpdated) {
      this.toastService.warning('Save all documents then try again.');
      return;
    }
    this.loaderService.isBusy = true;
    let obj = {
      transId: this.treatyService.getParamValue('transId'),
      company: this.session.get("companyCode"),
      divn: this.session.get("userDivnCode"),
      dept: this.session.get("userDeptCode"),
      userId: this.session.get("userId")
    }

    this.treatyService.recalculateAdjustmentProcedure(obj).subscribe(resp => {
      if (this.documents && this.documents.length > 0) {
        const gridFSIds = [];
        this.documents.forEach((document) => {
          gridFSIds.push(document.gridFSId);
        });
        this.docService.mapPolicy(
          gridFSIds,
          obj.transId)
          .subscribe(res => {
            this.loaderService.isBusy = false;
            this.toastService.success("Approved Successfully");
            this.modalService.hide();
            this.showPrintBtn = true;
            this.showApproveBtn = false;
          }, err => {
            this.toastService.warning('Document(s) not saved.');
          });
      } else {
        this.loaderService.isBusy = false;
        this.modalService.hide();
        this.toastService.success("Approved Successfully");
        this.showPrintBtn = true;
        this.showApproveBtn = true;

      }

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);

    })
  }

  retrieveAdjRecoveryDetail() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveAdjLayer(this.processId).subscribe(resp => {
      this.layerDetails = resp.layerList;
      if (this.layerDetails) {
        this.pinnedBottomLayerData = LayerData(1, this.layerDetails, "Bottom");
      }
      this.retrieveReinsurerAdj(this.layerDetails[0]);
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })

  }
<<<<<<< HEAD
  retriveReinsSummary(transId) {
=======
  retriveReinsSummary(transId,type) {
    console.log("process Id - ", this.processId, "transId", transId)
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    // transId = this.treatyService.getParamValue('transId');
    transId = this.processId
    this.treatyService.retriveReinsSummaryDetails(transId,type).subscribe(resp => {
      this.reinsSummaryDetails = resp;
      if (this.reinsSummaryDetails) {
        this.pinnedBottomSummaryData = ReinsurerData(1, this.reinsSummaryDetails, "summary");
      }
    }, error => {
      this.toastService.error(error.error.message);
      this.reinsSummaryDetails = [];
    });
  }
  retrieveReinsurerAdj(details) {
    if (details == null || details == '') { this.reinsurerDetails = []; } else {
      this.transId = details.txlAdjLayerPK.talTransId;
      this.loaderService.isBusy = true;
      let obj = {
        transId: details.txlAdjLayerPK.talTransId,
        layer: details.txlAdjLayerPK.talLayer,
        tarRefNo: details.talTtyRefNo,
        tarSeqNo: details.talTtySeqNo,
        tarAmendNo: details.talTtyAmendNo,
        type: this.type
      }
      // this.layerNo = obj.layer;	
      this.layerNo = details.talDesc != null ? details.txlAdjLayerPK.talLayer + '-' + details.talDesc : details.txlAdjLayerPK.talLayer;
      this.treatyService.retrieveReinsurerAdj(obj).subscribe(resp => {
        this.reinsurerDetails = resp;
        if (this.reinsurerDetails) {
          this.pinnedBottomReinsurerData = ReinsurerData(1, this.reinsurerDetails, "reinsurer");
        }
        this.loaderService.isBusy = false;
<<<<<<< HEAD
        this.retriveReinsSummary(this.transId);
=======
        console.log("this.reinsurerDetails", this.reinsurerDetails);
        this.retriveReinsSummary(this.transId,this.type);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.totalReinsurerShare = 0;
        this.totalreinsurerDeposit = 0;
        this.totalActualAdjust = 0;
        this.totalReinsTotalPrem = 0;
        this.totalReinsAdjustRate = 0;
        this.totalReinsurerPremBal = 0;
        this.totalReinsurerReinstPaid = 0;
        this.totalReinsurerActualReinstPaid = 0;
        this.totalReinsurerReinstBal = 0;

        for (var i = 0; i < this.reinsurerDetails.length; i++) {
          // alert( this.reinsurerDetails[i].tarSharePerc);
          this.totalReinsurerShare = this.totalReinsurerShare + this.reinsurerDetails[i].tarSharePerc;
          this.totalreinsurerDeposit = this.totalreinsurerDeposit + this.reinsurerDetails[i].tarDepPaid;
          this.totalActualAdjust = this.totalActualAdjust + this.reinsurerDetails[i].tarFinalPrem;
          this.totalReinsTotalPrem = this.totalReinsTotalPrem + this.reinsurerDetails[i].tarPrem;
          this.totalReinsAdjustRate = this.totalReinsAdjustRate + this.reinsurerDetails[i].tarAdjRate;
          this.totalReinsurerPremBal = this.totalReinsurerPremBal + this.reinsurerDetails[i].tarPremBal;
          this.totalReinsurerReinstPaid = this.totalReinsurerReinstPaid + this.reinsurerDetails[i].tarReinstPaid;
          this.totalReinsurerActualReinstPaid = this.totalReinsurerActualReinstPaid + this.reinsurerDetails[i].tarReinstActl;
          this.totalReinsurerReinstBal = this.totalReinsurerReinstBal + this.reinsurerDetails[i].tarReinstBal;
        }

        // this.scriptcall('reinsurer_table');
      }, error => {
        //  this.scriptcall('reinsurer_table');
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
        this.reinsurerDetails = [];
      });
    }
  }


  printDocument(docType) {
    var params = {
      refNo: this.transId,
      amendNo: "",
      compCode: this.session.get("companyCode"),
      repId: 'RI_SCH_004',
      docType: docType
    }
    this.treatyService.fetchReportUrl(params)
      .subscribe(result => {
        var url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
           width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(url, 'Reports', param);

      });
  }


  readUrl(e) {
    // alert();
    this.loaderService.isBusy = true;
    let file: File = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    let formData: FormData = new FormData();

    for (var i = 0; i < this.myFiles.length; i++) {
      formData.append("file", this.myFiles[i], this.filename[i].name);
    }

    // formData.append('file', file, file.name);
    formData.append('tdiRefNo', this.referenceNo);
    // formData.append('tdiAmendNo','0');
    formData.append('doctype', "XL-ADJ");
    formData.append('userId', this.session.get("userId"));
    var uploadDocumentReponse = this.treatyService.uploadDoc(formData);
    // this.upload = uploadDocumentReponse._isScalar;

    this.loaderService.isBusy = false;
  }


  retrieveRecoveryAdj(details) {
<<<<<<< HEAD
=======
    // this.modalService.open(this.content, { size: 'modal-lg' }).result.then((result) => {
    // }, (reason) => {
    //   //  this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.open(this.content, 'modal-lg');
    this.treatyService.retrieveAdjRecoveryDetails(details.txlAdjLayerPK.talTransId, details.talTtySeqNo, this.referenceNo, details.talTtyAmendNo).subscribe(resp => {
      this.recoveryDetails = resp.recoveryList;
      // this.scriptcall('recoverable-table'); 
      if (this.recoveryDetails.length > 0) {
        for (var i = 0; i < this.recoveryDetails.length; i++) {
          this.totalRecoveredPaid = this.totalRecoveredPaid + this.recoveryDetails[i].tacRecovered;
          this.totalReInstPaid = this.totalReInstPaid + this.recoveryDetails[i].tacReinstPaid;
        }
      }

    });


  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }

  changeCount(event) {

    this.transId = event.transId;
    let obj = {
      tatApi: event.amount,
      txlAdjTtyPK: {
        tatTransId: event.transId,
        tatTtyRefNo: event.refNo,
        tatTtyAmendNo: '0',
        tatTtySeqNo: event.seqNo
      }
    }
    this.treatyService.updateAgnpAmt(this.transId, obj).subscribe(resp => {
      let obj = {
        txaTransId: event.transId,
        txaTtyRefNo: this.referenceNo
      }
      this.retrieveXLContractDetails(obj);

      this.transId = event.transId
      this.retriveReinsSummary(this.transId,this.type);
    });
  }

  // onQuickFilterChanged(mode) {
  //   if (mode == 'init') {
  //     // this.gridApi.setQuickFilter(this.initSearchValue);
  //   } else if (mode == 'contract') {
  //     this.contractGridApi.setQuickFilter(this.contractSearchValue);
  //   } else if (mode == 'adjustment') {
  //     this.adjGridApi.setQuickFilter(this.adjustSearchValue);
  //   } else if (mode == 'reinsurer') {
  //     this.reinstGridApi.setQuickFilter(this.reinsurerSearchValue);
  //   } else if (mode == 'recovery') {
  //     this.recGridApi.setQuickFilter(this.recoverySearchValue);
  //   }

  // }

  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    //alert(gridApi+"--"+qickSearch);
    gridApi.setQuickFilter(qickSearch);
  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
  }

  onGridReady(params, gridName: any) {
    if (gridName === 'contract') {
      this.contractGridApi = params.api;
    } else if (gridName === 'adjustment') {
      this.adjGridApi = params.api;
    } else if (gridName === 'reinsurer') {
      this.reinstGridApi = params.api;
    } else if (gridName === 'recovery') {
      this.recGridApi = params.api;
    }
    params.api.sizeColumnsToFit();
  }

  displayedRowCount() {
    // if (this.gridApi) {
    //   return this.gridApi.getDisplayedRowCount();
    // } else {
    //   return;
    // }
  }
  onGridContractReady(params) {
    this.gridApiContract = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiContract.sizeColumnsToFit();
  }
  displayedContractRowCount() {
    if (this.gridApiContract) {
      return this.gridApiContract.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridAdjustmentReady(params) {
    this.gridApiAdjust = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiAdjust.sizeColumnsToFit();
  }
  displayedAdjustmentRowCount() {
    if (this.gridApiAdjust) {
      return this.gridApiAdjust.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridReinsurerReady(params) {
    this.gridApiReinsurer = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiReinsurer.sizeColumnsToFit();
  }
  displayedReinsurerRowCount() {
    if (this.gridApiReinsurer) {
      return this.gridApiReinsurer.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridRecoveryReady(params) {
    this.gridApiRecovery = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiRecovery.sizeColumnsToFit();
  }
  displayedRecoveryRowCount() {
    if (this.gridApiRecovery) {
      return this.gridApiRecovery.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onRowClicked(e, title) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.transId = data.txaTransId;
      switch (actionType) {
        case "Edit":
        //  this.addAdjustmentPremium('edit');
        //  return this.addAdjustmentPremium('edit');
        case "View":
        //  return this.addAdjustmentPremium('view');
        case "Recovery":
          return this.retrieveRecoveryAdj(data);
        case "AGNPI":
          let agnpi = {
            transId: data.txlAdjTtyPK.tatTransId,
            amendNo: data.txlAdjTtyPK.tatTtyAmendNo,
            currency: data.tatCurr,
            epi: data.tatEpi,
            seqNo: data.txlAdjTtyPK.tatTtySeqNo,
            refNo: data.txlAdjTtyPK.tatTtyRefNo,
            action: 'Edit'
          }
          return this.agnpiModal.toggleModal(agnpi)
      }
      switch (title) {
        case 'layer':
          return this.retrieveReinsurerAdj(data);
      }
    }
  }
  onGridSizeChanged(params) {
    console.log(params)
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  rowHeight() {
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
  }

  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }

  dateFormatter(params) {
    if (params.value != null) {
      return moment(params.value).format('DD/MM/YYYY');
    } else { return }
  }

  close() {
    this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
  }

  confirmationBlock() {
<<<<<<< HEAD
    this.open(this.confirmation, 'modal-sm');
=======
    this.openDialog(this.confirmation, 'modal-sm')
    // this.modalService.open(this.confirmation, { size: 'modal-sm' }).result.then((result) => {
    // }, (reason) => {
    // });
  }
  openDialog(content, val) {
    this.open(content, val);
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  closeModal() {
    this.modalService.hide();
  }
  displayRowCount(gridApi: any) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  closeModal() {
    this.modalService.hide();
  }

}
function numberFormatter(params) {
<<<<<<< HEAD
=======
  //console.log("Conversion Formatter ", params)
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  if (params != null) {
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else { return ''; }

}

function rateformatter(params) {
  if (params && params.value) {
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');    
  } else { 
    return ''; 
  }
}

function ReinsurerData(count, data, prefix) {
  var result = [];
  var tarReinstPaid = 0;
  var sumtarFinalPrem = 0;
  var sumtarSharePerc = 0;
  var tarReinstActl = 0;
  var tarReinstBal = 0;
  var tarDepPaid = 0;
  var tarPremBal = 0;
  for (var i = 0; i < data.length; i++) {
    tarReinstActl = tarReinstActl + data[i].tarReinstActl;
    tarReinstPaid = tarReinstPaid + data[i].tarReinstPaid;
    sumtarFinalPrem = sumtarFinalPrem + data[i].tarFinalPrem;
    sumtarSharePerc = sumtarSharePerc + data[i].tarSharePerc;
    tarReinstBal = tarReinstBal + data[i].tarReinstBal;
    tarDepPaid = tarDepPaid + data[i].tarDepPaid;
    tarPremBal = tarPremBal + data[i].tarPremBal;
  }
  for (var i = 0; i < count; i++) {
    if (prefix == 'reinsurer') {
      result.push({
        txlAdjReinsPK: {
          tarReins: 'Total'
        },
        // tarBroker: 'Total',
        tarReinstPaid: tarReinstPaid,
        tarFinalPrem: sumtarFinalPrem,
        tarSharePerc: sumtarSharePerc,
        tarReinstActl: tarReinstActl,
        tarReinstBal: tarReinstBal,
        tarDepPaid: tarDepPaid,
        tarPremBal: tarPremBal,        
      });
    } else {
      result.push({
        // txlAdjReinsPK: {
        //   tarReins: 'Total'
        // },
        tarBroker: 'Total',
        tarReinstPaid: tarReinstPaid,
        tarFinalPrem: sumtarFinalPrem,
        tarSharePerc: sumtarSharePerc,
        tarReinstActl: tarReinstActl,
        tarReinstBal: tarReinstBal,
        tarDepPaid: tarDepPaid,
        tarPremBal: tarPremBal
      });
    }
  }
  return result;
}
function LayerData(count, data, prefix) {
  var result = [];
  var talLimit = 0;
  var talDeductible = 0;
  var talRecoverd = 0;
  var talAdjRate = 0;
  var talPrem = 0;
  var talDepPaid = 0;
  var talFinalPrem = 0;
  var talPremBal = 0;
  var talReinstPaid = 0;
  var talReinstActl = 0;
  var talReinstBal = 0;
  for (var i = 0; i < data.length; i++) {
    talLimit = talLimit + data[i].talLimit;
    talDeductible = talDeductible + data[i].talDeductible;
    talRecoverd = talRecoverd + data[i].talRecoverd;
    talAdjRate = talAdjRate + data[i].talAdjRate;
    talPrem = talPrem + data[i].talPrem;
    talDepPaid = talDepPaid + data[i].talDepPaid;
    talFinalPrem = talFinalPrem + data[i].talFinalPrem;
    talPremBal = talPremBal + data[i].talPremBal;
    talReinstPaid = talReinstPaid + data[i].talReinstPaid
    talReinstActl = talReinstActl + data[i].talReinstActl
    talReinstBal = talReinstBal + data[i].talReinstBal
  }
  for (var i = 0; i < count; i++) {
    result.push({
      talTtySeqNo: 'Total',
      talLimit: talLimit,
      talDeductible: talDeductible,
      talRecoverd: talRecoverd,
      talAdjRate: talAdjRate,
      talPrem: talPrem,
      talDepPaid: talDepPaid,
      talFinalPrem: talFinalPrem,
      talPremBal: talPremBal,
      talReinstPaid: talReinstPaid,
      talReinstActl: talReinstActl,
      talReinstBal: talReinstBal
    });
  }
  return result;
}
function strtDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.tatStartDt).format('DD/MM/YYYY');
  }
}

function endDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.tatEndDt).format('DD/MM/YYYY')
  }
}
var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};