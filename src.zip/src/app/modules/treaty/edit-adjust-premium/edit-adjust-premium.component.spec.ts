import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAdjustPremiumComponent } from './edit-adjust-premium.component';

describe('EditAdjustPremiumComponent', () => {
  let component: EditAdjustPremiumComponent;
  let fixture: ComponentFixture<EditAdjustPremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditAdjustPremiumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAdjustPremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
