import { ToastService } from './../../../services/toast.service';
import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Utils } from 'src/app/utils';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { LoaderService } from './../../../services/loader.service';

@Component({
  selector: 'app-transaction-query',
  templateUrl: './transaction-query.component.html',
  styleUrls: ['./transaction-query.component.scss']
})
export class TransactionQueryComponent implements OnInit {
  transactionQueryForm: UntypedFormGroup;
  searchForm: UntypedFormGroup;
  transactionByList: any = [
    { "key": "0", "value": "Doc No" },
    { "key": "1", "value": "Customer" },
    { "key": "2", "value": "Contract" },
    { "key": "3", "value": "Claim No" },
    { "key": "4", "value": "Event" }
  ];
  formName: any = undefined;
  resultArray: any = [];

  keyword: any = 'value';
  initialValue: any = '';
  eventData: any;
  isLoadingResult: boolean;
  errorMsg: string;


  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  printBtn: boolean = false;
  goToBtn: boolean = false;
  redirectPageName: any;
  selectedRow: any;
  paramList: any;
  autoSelect: boolean = false;
  reportParam: any;

  constructor(
    private fb: UntypedFormBuilder,
    private route: Router,
    private toastService:ToastService,
    private loaderService: LoaderService,
    private treatyService: TreatyService,
    private session: SessionStorageService,
  ) { }

  ngOnInit() {
    this.loaderService.isBusy = true;
    this.getMasterData();
    this.createSearchForm();
    this.columnDefs = [
      {
        headerName: "Select",
        field: 'adId',
        cellRenderer: "radioButtonRenderer",
        cellStyle: { textAlign: 'center' },
        width: 150,
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        headerName: "Company",
        headerTooltip: 'Company',
        field: "adDivnCodeDesc",
        valueGetter: function (params) {
          if (params.data !== undefined) {
            return params.data.adCustCodeDesc;
          }
        },
      },
      {
        headerName: "Doc Date",
        headerTooltip: "Doc Date",
        field: "adDocDt",
        valueFormatter: Utils.dateFormatter,
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value) {
            return Utils.formatMilliSecToDate(parseInt(params.value));
          }
        },
      },
      {
        headerName: "Doc No",
        headerTooltip: "Doc No",
        field: "adDocNo",
        cellRenderer: (param) => {
          if (param.data.adDocNo) {
            return param.data.adTranCode + ' - ' + param.data.adDocNo;
          }
        },
        valueGetter: function (params) {
          if (params.data && params.data.adTranCode && params.data.adDocNo) {
            return params.data.adTranCode + ' - ' + params.data.adDocNo;
          } else {
            return "";
          }
        },
      },
      {
        headerName: "Narration",
        headerTooltip: "Narration",
        field: "adNarration",
        tooltipField: 'adNarration'
      },
      {
        headerName: "Currency",
        headerTooltip: "Currency",
        field: "adCurrCode",
      },
      {
        headerName: "Dr/Cr",
        headerTooltip: "Dr Cr",
        field: "adDrcrFlag",
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'D') {
            return '<span class="ag-element"> Dr </span>';
          } else if (params.value === 'C') {
            return '<span class="ag-element"> Cr </span>';
          }
        },
      },
      {
        headerName: "Amount (TC)",
        headerTooltip: "Amount (TC)",
        field: "adAmtLc1",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      },
      {
        headerName: "Amount (FC)",
        headerTooltip: "Amount (FC)",
        field: "adAmtFc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      },
      {
        headerName: "Main Account",
        headerTooltip: "Main Account",
        field: "mainAcntCodeDesc",
      },

      {
        headerName: "Sub Account",
        headerTooltip: "Sub Account",
        field: "subAcntCodeDesc",
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Contract Ref No",
        headerTooltip: "Contract Ref No",
        field: "adFlex08",
      },
      {
        headerName: "Year of Accounts",
        headerTooltip: "Year of Accounts",
        field: "adFlex02",
        width: 250,
      },
      {
        headerName: "Product",
        headerTooltip: 'Product',
        field: "adProductDesc",
        tooltipField: 'adProductDesc'
      },
    ];
    this.agGridOptions();
    this.defaultColDef = {
      resizable: true,
      enableRowGroup: true,
      sortable: true,
      filter: true
    };
  }
  createSearchForm() {
    this.transactionQueryForm = this.fb.group({
      searchType: [undefined],
    });
    this.searchForm = this.fb.group({
      tranCode: [undefined],
      docNo: [undefined],
      docDate: [undefined],
      customerCode: [undefined],
      startDate: [undefined],
      endDate: [undefined],
      trtyRefNo: [undefined],
      eventCode: "",
      claimNo: [undefined],
    });
  }
  onSelectTransactionBy(event) {
    this.clearValidators();
    this.searchForm.reset();
    this.formName = event.value;
    this.isLoadingResult = false;
    if (this.formName == 0) {
      this.searchForm.get('tranCode').setValidators([Validators.required]);
      this.searchForm.get('docNo').setValidators([Validators.required]);
      this.searchForm.updateValueAndValidity();
    } else if (this.formName == 1) {
      this.searchForm.get('customerCode').setValidators([Validators.required]);
      this.searchForm.get('startDate').setValidators([Validators.required]);
      this.searchForm.get('endDate').setValidators([Validators.required]);
      this.searchForm.updateValueAndValidity();
    } else if (this.formName == 2) {
      this.searchForm.get('trtyRefNo').setValidators([Validators.required]);
      this.searchForm.updateValueAndValidity();

    } else if (this.formName == 3) {
      this.searchForm.get('claimNo').setValidators([Validators.required]);
      this.searchForm.updateValueAndValidity();

    } else if (this.formName == 4) {
      this.searchForm.get('eventCode').setValidators([Validators.required]);
      this.searchForm.updateValueAndValidity();

    }
  }
  clearValidators() {
    this.searchForm.get('tranCode').clearValidators();
    this.searchForm.get('docNo').clearValidators();
    this.searchForm.get('docDate').clearValidators();
    this.searchForm.get('customerCode').clearValidators();
    this.searchForm.get('startDate').clearValidators();
    this.searchForm.get('endDate').clearValidators();
    this.searchForm.get('trtyRefNo').clearValidators();
    this.searchForm.get('eventCode').clearValidators();
    this.searchForm.get('claimNo').clearValidators();

    this.searchForm.get('tranCode').updateValueAndValidity();
    this.searchForm.get('docNo').updateValueAndValidity();
    this.searchForm.get('docDate').updateValueAndValidity();
    this.searchForm.get('customerCode').updateValueAndValidity();
    this.searchForm.get('startDate').updateValueAndValidity();
    this.searchForm.get('endDate').updateValueAndValidity();
    this.searchForm.get('trtyRefNo').updateValueAndValidity();
    this.searchForm.get('eventCode').updateValueAndValidity();
    this.searchForm.get('claimNo').updateValueAndValidity();

  }
  getMasterData() {
    this.loaderService.isBusy = false;
  }
  search(formName) {
    this.loaderService.isBusy = true;
    let formData = this.searchForm.getRawValue();
    this.goToBtn = this.printBtn = false;
    if (this.searchForm.valid) {
      if (formName == 0) {
        this.treatyService.fetchAllTransByTranCode(formData).subscribe(resp => {
          this.resultArray = resp;
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        })
      } else if (formName == 1) {
        formData.startDate = Utils.formatDateToServer(formData.startDate);
        formData.endDate = Utils.formatDateToServer(formData.endDate);
        formData.customerCode = formData.customerCode.key;
        this.treatyService.fetchAllTrans(formData).subscribe(resp => {
          this.resultArray = resp;
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        })
      } else if (formName == 2) {
        formData.trtyRefNo = formData.trtyRefNo.key;
        this.treatyService.fetchAllTransByRefNo(formData).subscribe(resp => {
          this.resultArray = resp;
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        })
      } else if (formName == 3) {
        formData.claimNo = formData.claimNo.key;
        this.treatyService.fetchAllTransByClaimNo(formData).subscribe(resp => {
          this.resultArray = resp;
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        })
      } else if (formName == 4) {
        formData.eventCode = formData.eventCode.key;
        this.treatyService.fetchAllTransByEventNo1(formData).subscribe(resp => {
          this.resultArray = resp;
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
        })
      }
    } else {
      this.validateAllFormFields(this.searchForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  back() {
    this.route.navigate(['treaty/contract-grid']);
  }
  getServerResponse(event, name) {
    this.isLoadingResult = true;
    if (name == 'eventCode') {
      if (event != "" && event.length >= 3) {
        this.treatyService.fetchAllTransByEventNo(event).subscribe((resp: any) => {
          this.eventData = resp.eventDropDown;
          this.isLoadingResult = false;
          if (this.eventData.length > 0) {
            this.errorMsg = "Data Found"
          } else {
            this.errorMsg = "No Data Found!";
          }
        }, error => {
          this.errorMsg = "No Data Found!";
        });
      }
    } else if (name == 'customerCode') {
      if (event != "" && event.length >= 3) {
        this.treatyService.fetchAllTransByCustomerCode(event).subscribe((resp: any) => {
          this.eventData = resp.customerDropDown;
          this.isLoadingResult = false;
          if (this.eventData.length > 0) {
            this.errorMsg = "Data Found"
          } else {
            this.errorMsg = "No Data Found!";
          }
        }, error => {
          this.errorMsg = "No Data Found!";
        });
      }
    } else if (name == 'claimNo') {
      if (event != "" && event.length >= 3) {
        this.treatyService.fetchAllTransByClaimNo1(event).subscribe((resp: any) => {
          this.eventData = resp.eventDropDown;
          this.isLoadingResult = false;
          if (this.eventData.length > 0) {
            this.errorMsg = "Data Found"
          } else {
            this.errorMsg = "No Data Found!";
          }
        }, error => {
          this.errorMsg = "No Data Found!";
        });
      }
    } else if (name == 'trtyRefNo') {
      if (event != "" && event.length >= 3) {
        this.treatyService.fetchAllTransByRefNo1(event).subscribe((resp: any) => {
          this.eventData = resp.contractDropDown;
          this.isLoadingResult = false;
          if (this.eventData.length > 0) {
            this.errorMsg = "Data Found"
          } else {
            this.errorMsg = "No Data Found!";
          }
        }, error => {
          this.errorMsg = "No Data Found!";
        });
      }
    }
  }

  selectEvent(item, name) {
    if (name == 'eventCode') {
      this.searchForm.patchValue({
        eventCode: item.value
      });
    } else if (name == 'customerCode') {
      this.searchForm.patchValue({
        customerCode: item.value
      });
    } else if (name == 'claimNo') {
      this.searchForm.patchValue({
        claimNo: item.value
      });
    } else if (name == 'trtyRefNo') {
      this.searchForm.patchValue({
        trtyRefNo: item.value
      });
    }
  }
  searchCleared(name) {
    this.eventData = [];
    if (name == 'eventCode') {
      this.searchForm.patchValue({
        eventCode: ""
      });
    } else if (name == 'customerCode') {
      this.searchForm.patchValue({
        customerCode: ""
      });
    } else if (name == 'claimNo') {
      this.searchForm.patchValue({
        claimNo: ""
      });
    } else if (name == 'trtyRefNo') {
      this.searchForm.patchValue({
        trtyRefNo: ""
      });
    }

  }
  onChangeSearch(val: string) {

  }
  onFocused(e) {
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
    } else {
      this.gridOptions.api.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
    this.gridApi.sizeColumnsToFit();
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("agSearchResultGrid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  selectedRowData(cell) {
    this.printBtn = true;
    this.goToBtn = true;
    this.selectedRow = cell.data;
    this.transactionByList.forEach(el => {
      if (el.key == this.formName) {
        this.redirectPageName = el.value;
      }
    })
    if (this.selectedRow.adDocType == 'DEP_PREM') {
      this.redirectPageName = 'Deposit Premium';
    } else if (this.selectedRow.adDocType == 'BIND_CLM') {
      this.redirectPageName = 'Claim';
    } else if (this.selectedRow.adDocType == 'BIND_TAM') {
      this.redirectPageName = 'TA Manual';
    }
  }
  params: any;
  printDocument() {

    if (this.selectedRow.adDocType == 'DEP_PREM') {
      this.redirectPageName = 'Deposit Premium';
      this.params = {
        refNo: this.selectedRow.adTtyRefNo,
        amendNo: this.selectedRow.adTtyAmendNo,
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_001',
        docType: this.selectedRow.adDocType,
        seqNo: this.selectedRow.adTtySeqNo
      }
    } else if (this.selectedRow.adDocType == 'BIND_CLM') {
      this.redirectPageName = 'Claim';
      this.params = {
        refNo: this.selectedRow.adTtyRefNo,
        amendNo: this.selectedRow.adTtyAmendNo,
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_007',
        docType: this.selectedRow.adDocType,
        seqNo: this.selectedRow.adTtySeqNo
      }

    } else if (this.selectedRow.adDocType == 'BIND_TAM') {
      this.redirectPageName = 'TA Manual';
      this.params = {
        refNo: this.selectedRow.adTransId,
        amendNo: "TA_DC_NOTE",
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_005',
        docType: this.selectedRow.adDocType,
        seqNo: '',
      }
    }
    this.treatyService.fetchReportUrl(this.params)
      .subscribe(result => {
        var url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
          width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(url, 'Reports', param);

      });
  }
}
function currencyFormatter(params) {
  if (params != null) {
    return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else { return; }
}