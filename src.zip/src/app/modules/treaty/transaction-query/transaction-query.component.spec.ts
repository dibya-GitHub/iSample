import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/treaty/transaction-query/transaction-query.component.spec.ts
import { TransactionQueryComponent } from './transaction-query.component';

describe('TransactionQueryComponent', () => {
  let component: TransactionQueryComponent;
  let fixture: ComponentFixture<TransactionQueryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransactionQueryComponent ]
=======
import { AmendmentHistoryComponent } from './amendment-history.component';

describe('AmendmentHistoryComponent', () => {
  let component: AmendmentHistoryComponent;
  let fixture: ComponentFixture<AmendmentHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmendmentHistoryComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/amendment-history/amendment-history.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/treaty/transaction-query/transaction-query.component.spec.ts
    fixture = TestBed.createComponent(TransactionQueryComponent);
=======
    fixture = TestBed.createComponent(AmendmentHistoryComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/amendment-history/amendment-history.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
