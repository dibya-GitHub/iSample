<<<<<<< HEAD
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
=======
import { Component, OnInit, ViewChild, ElementRef, Inject } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
<<<<<<< HEAD
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
declare var $: any;
=======
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
declare var $: any;
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { ToastService } from 'src/app/services/toast.service';
import { LoaderService } from 'src/app/services/loader.service';
import * as moment from 'moment';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-recovery-enquiry',
  templateUrl: './recovery-enquiry.component.html',
  styleUrls: ['./recovery-enquiry.component.css']
})

export class RecoveryEnquiryComponent implements OnInit {
  displayButton: boolean;
  rowGroupPanelShow: string;
  recoveryData: any;
  quickSearchValue: string = '';
  paginationPageSize: number;
  gridApi: any;
  public columnDefs;
  private defaultColDef;
  private getRowHeight;
  public context;
  public frameworkComponents;
  private components;
  viewdoc: boolean;
  dashBoard: any;
  tranSrNo: any;
  transId: any;
  enquiryForm: UntypedFormGroup;
  details: any[];
  contractTypeList: any[];
  userList = [];
  eventList = [];
  transDateList = [];
  statusList = [{ key: "", value: "All" }, { key: "A", value: "Approved" }, { key: "P", value: "Pending" }];
  reportParam: any[];
  selectedArray = [];
  seqNo: any;
  action: string;
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  totalCount: number;
  pendingCount: number;
  ApprovedCount: number;
  @ViewChild('trigger') tr: ElementRef;
  tranSrNoList: any;
  referenceList: any;
  polciyList: any = [];
  claimList: any;
  ActiveTab: any;
  type: any;
  contractRefList: any;
  contractRefno: any;
  contractSeqNo: any;
  policyRefList:any;
  constructor(
    private fb: UntypedFormBuilder,
<<<<<<< HEAD
    private router: Router,
    private toastService: ToastService,
    private treatyService: TreatyService,
=======
    private treatyService: TreatyService,
    private router: Router,
    private toastService: ToastService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService
  ) {
    this.columnDefs = [
      {
        headerName: "Select",
        cellRenderer: "radioButtonRenderer",
        field: 'txrSeqNo',
<<<<<<< HEAD
        filter: false,
        sortable: false,
        enableRowGroup: false,
=======
        checkboxSelection: false,
        cellStyle: { textAlign: 'center' },
        width: 110,
        sortable: false,
        filter: false,
        enableRowGroup: false
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },
      {
        field: 'txlRecPK.txrTransId',
        headerName: 'Rec Ref No',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'txlRecPK.txrTransId',
        enableRowGroup: true, valueGetter: function (params) {
          if (params.data && params.data.txlRecPK && params.data.txlRecPK.txrTransId) {
            return params.data.txlRecPK.txrTransId;
          }else{
            return '';
          }
        }
      },
      {
        field: 'txrTtyRefNo',
        headerName: 'Contract Ref',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'txrTtyRefNo',
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params.data &&  params.data.txrTtyRefNo){
            return params.data.txrTtyRefNo + '-' + params.data.txrSeqNo;
          } else {
            return '';
          }
        }
      },

      {
        field: 'txrClmNo',
        headerName: 'Claim Ref',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'txrClmNo',
        enableRowGroup: true,
        valueGetter: function (params) {
<<<<<<< HEAD
          if (params.data != undefined && params.data.txrEvent != '') {
            return 'Various';
=======
          if (params.data && params.data.txrClmNo) {
            //console.log('recovery ---- ', params.data.txrEvent)
            return params.data.txrClmNo;            
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          } else {
            return '';
          }
        }
      },
      {
        field: 'eventDesc',
        headerName: 'Event',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'eventDesc',
        enableRowGroup: true,
        valueGetter: function (params) {
          if (params.data && params.data.txrEvent) {
            return params.data.txrEvent + '-' + params.data.eventDesc;
          } else {
            return '';
          }
        } 
      },
      // { field: 'eventDesc', headerName: 'Event', sortable: true, filter: true, resizable: true,
      // tooltipField: 'txrEvent', enableRowGroup: true},
      {
        field: 'policyNo',
        headerName: 'Policy Ref',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'policyNo',
        enableRowGroup: true
      },
      {
        field: 'insuredName',
        headerName: 'Insured Name',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'insuredName',
        enableRowGroup: true
      },
      {
        field: 'txrCrDt',
        headerName: 'Tran Date',        
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'txrCrDt',
        enableRowGroup: true,        
        cellRenderer: tranDateCellRenderer,
        valueGetter: function (params) {
          if (params && params.data && params.data.txrCrDt) {
            return moment(params.data.txrCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
      },
      {
        field: 'paid',
        headerName: 'Paid Retn',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'paid',
        //valueFormatter: currencyFormatter,
        cellStyle: { textAlign: 'right' },
        enableRowGroup: true,
        valueGetter: function (params) {
          if(params && params.data && params.data.paid) {
            return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.paid));
          } else if (params.data && !params.data.paid) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          } else {
            return '';
          }          
        }
      },
      {
        field: 'recoverd',
        headerName: 'Recovered',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'recoverd',
        //valueFormatter: currencyFormatter,
        cellStyle: { textAlign: 'right' },
        enableRowGroup: true,
        valueGetter: function (params) {
          if(params && params.data && params.data.recoverd) {
            return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.recoverd));
          } else if (params.data && !params.data.recoverd) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          } else {
            return '';
          }         
        }
      },
      {
        field: 'balRec',
        headerName: 'Bal Recoverable',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'balRec',
        enableRowGroup: true,
        //valueFormatter: currencyFormatter, 
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if(params && params.data && params.data.balRec) {
            return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.balRec));
          } else if (params.data && !params.data.balRec) {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          } else {
            return '';
          }         
        }
      },

      {
        field: 'txrCrUid',
        headerName: 'User',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'txrCrUid',
        enableRowGroup: true
      },
      {
        field: 'txrStatus',
        headerName: 'Status',
        sortable: true,
        filter: true,
        resizable: true,
        tooltipField: 'txrStatus',
        enableRowGroup: true,
        cellStyle: { textAlign: 'center' },
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params.value) {
              return params.value == 'Approved';
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params.value) {
              return params.value == 'Pending';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value === 'Approved') {
            return '<span class="ag-element"> Approved </span>';
          } else if (params.value === 'Pending') {
            return '<span class="ag-element"> Pending </span>';
          }
        },
      }
    ];
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true
    };
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      if (params.node.data != null)
        var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
  }

  ngOnInit() {

    this.transId = this.treatyService.getParamValue('transactionId');
    this.contractRefno = this.treatyService.getParamValue('refno');
    this.contractSeqNo = this.treatyService.getParamValue('seqNo');
    this.type = this.treatyService.getParamValue('type');
    // this.dropdown();
    this.agGridOptions();
    this.dashBoard = this.session.get("userDashboard");
    this.enquiryForm = this.fb.group({
      txrTransId: [undefined],
      txrTtyRefNo: [undefined],
      txrXlType: [undefined],
      txrClmNo: [undefined],
      txrEvent: '',
      txrStatus: '',
      txrCrDt: '',
      txrCrUid: '',
      policyNo: [undefined]
    });

    if (this.contractRefno != undefined && this.contractSeqNo != undefined) {
      this.ActiveTab = 'Recovered'; ''
      // this.enquiryForm.get('txrTransId').setValue(this.transId);
      this.enquiryForm.get('txrTtyRefNo').setValue(this.contractRefno + '-' + this.contractSeqNo);

      this.searchEnquiry();
    } else {
      this.ActiveTab = 'Pending Recovery';
    }

    this.treatyService.reterieveUWriterList().subscribe(resp => {
      this.userList = resp.userList;
      this.userList.unshift({ key: "", value: "All" });
    }, err => { });


    this.treatyService.retrieveContractType(ApiUrls.APP_CODES_MGMT_PATH).subscribe(resp => {
      this.contractTypeList = resp.appcodeList;
    }, err => { })

    this.treatyService.appCodesList(ApiUrls.APP_EVENT_TYPE).subscribe(resp => {
      this.eventList = resp.appcodeList;
      this.eventList.unshift({ key: "", value: "All" });


    }, err => { })

    this.treatyService.fetchTransactionDate().subscribe(resp => {
      this.transDateList = resp.dateList;
      this.transDateList.unshift({ key: "", value: "All" });
    }, err => { })


    this.treatyService.recReferencList().subscribe(resp => {
      this.referenceList = resp.reference;
      let recRefObj = [];
      for (let i = 0; i < this.referenceList.length; i++){
        recRefObj.push({ 
          key : i,
          value : this.referenceList[i]
        })
      }
      this.referenceList = recRefObj;
    }, err => { });

    this.treatyService.recPolicyList().subscribe((resp:any) => {
      this.polciyList = resp.policy;
      let polObj = [];
      for (let i = 0; i < this.polciyList.length; i++){
        polObj.push({ 
          key : i,
          value : this.polciyList[i]
        })
      }
      this.polciyList = polObj;
    }, err => { });

    this.treatyService.recClaimList().subscribe(resp => {
      this.claimList = resp.claim
      let claimObj = [];
      for (let i = 0; i < this.claimList.length; i++){
        claimObj.push({ 
          key : i,
          value : this.claimList[i]
        })
      }
      this.claimList = claimObj;
    }, err => { });

    this.treatyService.contReferenceList().subscribe(resp => {
      this.contractRefList = resp
    }, err => { })
    this.rowGroupPanelShow = 'always';
  }

  reterieveRecoveryDetails() {
    this.loaderService.isBusy = true;
    this.treatyService.searchRecovery(this.enquiryForm.value).subscribe(resp => {
      this.details = resp.recoveryList;
      for (var i = 0; i < this.details.length; i++) {
        this.tranSrNoList = this.details[i].txlRecPK.txrTranSrNo;
      }
      this.recoveryData = JSON.parse(JSON.stringify(resp.recoveryList));
      //this.details = resp.recoveryList;
      this.calculateFilterCounts();
      // this.scriptcall('reinsure-enquiry');
      this.loaderService.isBusy = false;
    })
  }


  viewEnquiry(mode) {
    if (this.action == undefined) {
      this.toastService.warning('Please Select and Proceed');
    } else {
      //this.router.navigate(["/recovery"],querypar{})
      this.router.navigate(['/treaty/recovery'], { queryParams: { "action": mode, 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'seqNo': this.seqNo }, skipLocationChange: false });
    }
  }

  selectedRowData(cell) {
    let data = cell.data;
    this.displayButton = true;
    this.transId = data.txlRecPK.txrTransId;
    this.tranSrNo = data.txlRecPK.txrTranSrNo
    this.seqNo = data.txrSeqNo;
    this.viewdoc = true;
    if ('Pending' == data.txrStatus) {
      this.action = "edit";
    } else {
      this.action = 'view';
    }
  }

  searchEnquiry() {
    this.loaderService.isBusy = true;
    this.treatyService.searchRecovery(this.enquiryForm.value).subscribe(resp => {
      this.recoveryData = JSON.parse(JSON.stringify(resp.recoveryList));
      this.details = resp.recoveryList;
      this.calculateFilterCounts()
      // this.scriptcall('reinsure-enquiry');
      this.loaderService.isBusy = false;
    })
  }

  printDoc(content) {
    if (this.transId == null || this.transId == "") {
      this.toastService.warning('Please Select and Proceed');
      return false;
    }
    let obj = {
      compCode: this.session.get("companyCode"),
      instId: this.session.get("instanceId"),
      divn: this.session.get("userDivnCode"),
      tranType: 'TTY_XOL_REC'
    }
    this.treatyService.fetchReportParamList(obj).subscribe(resp => {
      this.reportParam = resp.reportParamList;
    })
<<<<<<< HEAD
    this.open(content, 'modal-lg');
  }

  open(content, val) {
    this.modalService.show(content, { class: val });
  }
=======
    this.open(content, 'modal-lg');    
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  pushSelectedDocs(event, id, type) {
    if (event.target.checked == true) {
      let repId = id;
      let docType = type;
      let object = { id: repId, text: docType };
      this.selectedArray.push(object);
    } else {
      var index = this.selectedArray.indexOf(id);
      this.selectedArray.splice(index, 1)
    }
  }

  printDocument() {
    if (this.selectedArray.length == 0) {
      this.toastService.warning('Please Select atleast one checkBox');
      return false;
    }

    for (var i = 0; i < this.selectedArray.length; i++) {

      var params = {
        refNo: this.transId,
        amendNo: this.tranSrNo,
        compCode: this.session.get("companyCode"),
        repId: this.selectedArray[i].id,
        docType: this.selectedArray[i].text
      }
      this.treatyService.fetchReportUrl(params)
        .subscribe(result => {
          var url = result.resultUrl;
          var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
      width=0,height=0,left=-1000,top=-1000`;
          var winRef = window.open(url, 'Reports_' + result.docType, param);

        });
    }
  }

  redirect() {
    this.router.navigate(['/treaty/recovery'], { queryParams: { "action": "add" }, skipLocationChange: false });

  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.reterieveRecoveryDetails();
    this.gridApi.sizeColumnsToFit();
    // this.loadlayergrid("new");
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {

      radioButtonRenderer: RadiorenderComponent
    };
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        columnKeys: ["txlRecPK.txrTransId", "txrTtyRefNo", "txrClmNo","eventDesc","policyNo","insuredName",
        "txrCrDt","paid","recoverd","balRec","txrCrUid","txrStatus"],
        processCellCallback: (params) => {
          if (params.column.colId == "paid" || params.column.colId == "recoverd" 
               || params.column.colId == "balRec"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }
        }
      });
    }
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  onStatusChange(status) {
    // this.searchSkeletonInfo(this.constructFormData(1), false);
    if (status) {
      this.details = this.recoveryData.filter(datum => datum.txrStatus === status);
    } else {
      this.details = this.recoveryData;
    }
    this.displayButton = false;
  }
  calculateFilterCounts() {
    if (this.details) {
      this.totalCount = this.details.length;
      this.pendingCount = this.details.filter(datum => datum.txrStatus === 'Pending').length;
      this.ApprovedCount = this.details.filter(datum => datum.txrStatus === 'Approved').length;
    }
  }

  reset() {
    this.enquiryForm.patchValue({
      txrTransId: '',
      txrTtyRefNo: '',
      txrXlType: '',
      txrClmNo: '',
      txrEvent: '',
      txrStatus: '',
      txrCrDt: '',
      txrCrUid: '',
      policyNo: ''
    });
    this.searchEnquiry();
  }
  closeModal() {
    this.modalService.hide();
  }

}
function numberFormatter(params) {
  return params.value.toFixed(2);
}
function dateFormatter(params) {
  return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
}
function currencyFormatter(params) {
  if (params && params.value) {
    return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));    
  } else {
    return '';
  }
}
function tranDateCellRenderer(params) {
  if (params.data && params.data.txrCrDt) {
    return moment(params.data.txrCrDt).format('DD/MM/YYYY');
  } else {
    return '';
  }
}
var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};