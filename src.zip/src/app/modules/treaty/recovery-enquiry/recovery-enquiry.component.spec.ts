import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoveryEnquiryComponent } from './recovery-enquiry.component';

describe('RecoveryEnquiryComponent', () => {
  let component: RecoveryEnquiryComponent;
  let fixture: ComponentFixture<RecoveryEnquiryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecoveryEnquiryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoveryEnquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
