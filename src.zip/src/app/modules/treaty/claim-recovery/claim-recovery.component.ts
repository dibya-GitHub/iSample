<<<<<<< HEAD
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';

=======
import { Component, OnInit, Inject } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
import { UntypedFormBuilder } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/services/toast.service';
import { LoaderService } from 'src/app/services/loader.service';
import * as moment from 'moment';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-claim-recovery',
  templateUrl: './claim-recovery.component.html',
  styleUrls: ['./claim-recovery.component.scss']
})
export class ClaimRecoveryComponent implements OnInit {

  ClaimRecColumn: any[];
  gridApiCr: any;
  quickSearchValueCr: string = '';
  claimDetails: any;
  showEntriesOptionsCr = [5, 10, 20, 50, 100];
  showEntriesOptionSelectedCr = 10;
  public componentsCR;
  constructor(
<<<<<<< HEAD
=======
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private router: Router,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
<<<<<<< HEAD
    private toastService: ToastService
=======
    private session: SessionStorageService,
    private toasterservice: ToastService
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) { }

  ngOnInit() {
    this.ClaimRecColumn = [
      { field: 'wxrClmNo', headerName: 'Claim No', sortable: true, enableRowGroup: true, filter: true, resizable: true, },
      {
        headerName: 'Event',field: 'wxrEvent',  sortable: true, enableRowGroup: true, filter: true, resizable: true,
        valueGetter: function (params) {
          if (params.data) {
            if (params.data.wxrEvent !== null || params.data.wxrEventDesc !== null) {
              return params.data.wxrEvent + '-' + params.data.wxrEventDesc;
            } else {
              return params.data.wxrEvent;
            }
          }
        },
      },
      {
        field: 'wxrLossDt',
        headerName: 'Loss Date',
        cellRenderer: '',        
        valueGetter: function (params) {
          if (params && params.data && params.data.wxrLossDt) {
            return  moment(params.data.wxrLossDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams2,
        enableRowGroup: true, filter: true, resizable: true,sortable: true,
      },
      // { field: 'wxrEventDesc', headerName: 'Event Desc', sortable: true, tooltipField: 'wxrEventDesc', enableRowGroup: true, filter: true, resizable: true, },
      //{ field: 'wxrLossDt', headerName: 'Loss Date', valueFormatter: dateFormatter, sortable: true, tooltipField: 'wxrLossDt', enableRowGroup: true, filter: true, resizable: true, },
      { field: 'wxrLossDesc', headerName: 'Loss Desc', sortable: true, enableRowGroup: true, filter: true, resizable: true, },
      { field: 'wxrCurr', headerName: 'Curr', sortable: true, enableRowGroup: true, filter: true, resizable: true, },
      { field: 'wxrPaidRetn', headerName: 'Paid Retn', sortable: true, enableRowGroup: true, filter: true, resizable: true,
      valueGetter: function (param){
        if(param && param.data && param.data.wxrPaidRetn) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((param.data.wxrPaidRetn));
        } else if (param.data && !param.data.wxrPaidRetn) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
        } else {
          return ;
        }
      },
       cellStyle: { textAlign: 'right' } },
      { field: 'wxrRecovered', headerName: 'Recovered', sortable: true, filter: true, resizable: true,
      valueGetter: function (param){
        if(param && param.data && param.data.wxrRecovered) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((param.data.wxrRecovered));
        } else if (param.data && !param.data.wxrRecovered) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
        } else {
          return ;
        }
      }, cellStyle: { textAlign: 'right' } },
      {
        field: 'wxrTtyRefNo', headerName: 'Contract Ref', sortable: true, filter: true, resizable: true, valueGetter: function (params) {
          if (params.data != undefined)
            return params.data.wxrTtyRefNo + '-' + params.data.wxrTtySeqNo;
        }
      },
      { field: 'wxrDeductible', headerName: 'Excess', sortable: true, filter: true, resizable: true, valueGetter: function (param){
        if(param && param.data && param.data.wxrDeductible) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((param.data.wxrDeductible));
        } else if (param.data && !param.data.wxrDeductible) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
        } else {
          return ;
        }
      }, cellStyle: { textAlign: 'right' } },
      { field: 'wxrInsName', headerName: 'Insured Name', sortable: true, filter: true, resizable: true, },
      {
        field: 'wxrClmNo',
        headerName: 'Action',
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' }, 
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
    ];
    this.claimRecovery();
    this.componentsCR = {
      cRDateCellRenderer: cRDateCellRenderer,
      
    };
  }

  claimRecovery() {
    this.loaderService.isBusy = true;
    this.treatyService.ClaimRecDetails().subscribe(resp => {
      this.claimDetails = resp.claimRecoveryList;
      this.loaderService.isBusy = false;
    }, err => {
      this.loaderService.isBusy = false;
    })
  }
  onBtExportCr() {
    console.log(this.gridApiCr);
    if (this.gridApiCr) {
      this.gridApiCr.exportDataAsExcel({
        columnKeys:['wxrClmNo','wxrEvent','wxrLossDt','wxrLossDesc','wxrCurr','wxrPaidRetn','wxrRecovered',
        'wxrTtyRefNo','wxrDeductible','wxrInsName'],
        processCellCallback: (params) => {
          if (params.column.colId == "wxrPaidRetn" || params.column.colId == "wxrRecovered" 
              || params.column.colId == "wxrDeductible"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }
        }
      });
    }
  }

  onGridReadyCr(params) {
    this.gridApiCr = params.api;
    // this.gridColumnApi = params.columnApi;
    this.gridApiCr.sizeColumnsToFit();
  }
  onPaginationCountChangeCr(event: any) {
    this.gridApiCr.paginationSetPageSize(this.showEntriesOptionSelectedCr);
    this.gridApiCr.paginationGoToPage(0);
  }
  pageChangedCr(event: any): void {
    this.gridApiCr.paginationGoToPage(event.page - 1);
  }

  displayRowCountCr() {
    if (this.gridApiCr) {
      return this.gridApiCr.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onRowClickedCr(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      console.log('rowselectdata::', data, 'event ', e);
      let obj = {
        action: 'edit',
        claimNo: data.wxrClmNo,
        claimRefNo: data.wxrTtyRefNo,
        claimSeqNo: data.wxrTtySeqNo,
        claimEvent: data.wxrEvent,
        transId: data.wxrTransId,
        tranSrNo: data.wxrSrNo,
        // processId: data,
        seqNo: data.wxrTtySeqNo
      }
      let actionType = e.event.target.getAttribute("data-action-type");
      if (actionType === 'Process') {
        this.router.navigate(['/treaty/recovery'], { queryParams: obj });
      }
    }

  }

  onQuickFilterChangedCr() {
    this.gridApiCr.setQuickFilter(this.quickSearchValueCr);
  }

  refresh() {
    this.loaderService.isBusy = true;
    this.treatyService.refreshClaim().subscribe(resp => {
      this.loaderService.isBusy = false;
      if (resp) {
        this.claimRecovery();
        this.loaderService.isBusy = false;
        this.toastService.success("Refreshed");
      }
    }, err => {
      this.toastService.error("Error in Refreshing");
      this.loaderService.isBusy = false;
    })
  }
  onGridSizeChangedCr(params) {
    var gridWidth = document.getElementById("claimTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  groupChangedCr(params) {
    params.api.sizeColumnsToFit();
  }
}
function dateFormatter(params) {
  if (params != null) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return }

}
function currencyFormatter(params) {
  if (params && params.value) {
    return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else { return '' }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-external-link fa-icon" data-action-type="Process" title="To Recovery" aria-hidden="true"></i>
    </a>`;
  }
}
function cRDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.wxrLossDt).format('DD/MM/YYYY');
  }
}
var filterParams2 = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};