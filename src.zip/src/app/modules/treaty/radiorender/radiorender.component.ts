<<<<<<< HEAD
import { ICellRendererAngularComp } from '@ag-grid-community/angular';
import { Component } from '@angular/core';
=======
import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from '@ag-grid-community/angular';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'app-radiorender',
  template: `<div *ngIf="canShow && params" style="display: block; text-align:center;">
  
  <input type="radio" name="groupname" [value]="params.getValue()"
  [checked]="params.context.componentParent.selectedRowId === params.getValue()"
   (click)="invokeParentMethod($event)">
</div>`,
})
export class RadiorenderComponent implements ICellRendererAngularComp {
  public params: any;
  canShow: boolean;
  agInit(params: any): void {
    this.params = params;
    const value = this.params.getValue();
    if (this.params && this.params.data) {
      this.canShow = true;
    } else {
      this.canShow = false;
    }
    // console.log("Radio render.....", this.params)
  }

  public invokeParentMethod(e) {
    let header = this.params.colDef.headerName;
    if ('Select' == header) {
      if (this.params.context.selectedRowData) {
        this.params.context.selectedRowData(this.params);
      } else {
        this.params.context.componentParent.selectedRowData(this.params)
      }
    } else if ('layer' == header) {
      this.params.context.componentParent.selectedRow(e, this.params)
    } else {
      this.params.context.componentParent.selectedRow(this.params)
      this.params.context.componentParent.showInstal(e, this.params)
    }
  }
  refresh(): boolean {
    return false;
  }
}
