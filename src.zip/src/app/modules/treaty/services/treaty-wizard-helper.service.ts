import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class TreatyWizardHelperService {
    context: any;
    previous:any;
    next:any;
    finish: any;
    constructor() {}

    goNext() {
        this.next.call(this.context );
        // this.next();
    }
    goPrevious() {
        this.previous.call(this.context);
    }

    onFinish() {
        this.finish.call(this.context);
    }

}
