import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LayerTreatyTypeComponent } from './layer-treaty-type.component';

describe('LayerTreatyTypeComponent', () => {
  let component: LayerTreatyTypeComponent;
  let fixture: ComponentFixture<LayerTreatyTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LayerTreatyTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LayerTreatyTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
