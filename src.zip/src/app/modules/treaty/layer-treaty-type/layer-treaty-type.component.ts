<<<<<<< HEAD
import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, EventEmitter, Inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
=======
import { Component, ElementRef, EventEmitter, Inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { SessionStorageService } from 'angular-web-storage';
import { ToastService } from 'src/app/services/toast.service';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';

@Component({
  selector: 'app-treaty-type',
  templateUrl: './layer-treaty-type.component.html',
  styleUrls: ['./layer-treaty-type.component.css']
})
export class LayerTreatyTypeComponent implements OnInit {
  gridApi: any;
  public columnDefs;
  public defaultColDef;
  public getRowHeight;
  public context;
  public frameworkComponents;
  quickSearchValue: string = '';
  showEntriesOptionSelected = 5;
  showEntriesOptions = [5, 10, 20, 50, 100];

  agTypeDataList: any = [];
  ttyBasisVal: any;
  ttyAllocVal: any;
  ttyAccFreqVal: any;
  ttyform: UntypedFormGroup;
  treatyBasisList: any;
  CedingTypeList: any;
  CedingBasisList: any;
  AllocList: any;
  FreqList: any;
  showForm: boolean;

  @Input() refNo: string;
  @Input() amendNo: string;
  @Input() egnpiAmt: number;
  @Input() seqNo: number;
  @Input() contractType;
  @Input() basecurr;
  @Input() fullContractType: string;
  @Input() egnpiLabel: string;
  @Input() xolType;
  @Input() amndSrNo: any;
  @Output() layerEvent = new EventEmitter();
  @Output() sendLayerHeading = new EventEmitter();
  @Output() sendLayer = new EventEmitter();
  TreatyType: any[];
  treatyTypeList: any;
  layercount: string;
  currencyList: any;
  formDetails: any;
  layerAction: string;
  selectedLayerId: any;
  ActionBtn: boolean = true;

  percFlag: boolean = true;
  limitFlag: boolean = true;
  linesFlag: boolean = true;
  linesOnFlag: boolean = true;
  LinesOnList: any;
  BouqFreqList: any;
  basisTableKey: any;
  AllocTableKey: any;
  AccFreqTableKey: any;
  ttyBasisKey: any;
  ttyAllocKey: any;
  ttyAccFreqKey: any;
  selectedLayer: any;
  temp: any;
  @ViewChild('confirmModal') confirmModal: ElementRef;
<<<<<<< HEAD
  @ViewChild('confirmContent') confirmation: ElementRef;
  closeResult: string;
  productlilst: any;
  isCedingBasis: boolean = false;
  constructor(
    private router: Router,
    private session: SessionStorageService,
    public builder: UntypedFormBuilder,
    private treatyService: TreatyService,
=======
  @ViewChild('confirmcontent') confirmation: ElementRef;
  closeResult: string;

  constructor(
    public builder: UntypedFormBuilder,
    private treatyService: TreatyService,
    private session: SessionStorageService,
    private cpipe: MycurrencyPipe,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private toastService: ToastService,
    private wizardHelper: TreatyWizardHelperService,
    private loaderService: LoaderService,
    private modalService: BsModalService,
    @Inject(DOCUMENT) private document: Document,
<<<<<<< HEAD
=======
    private router: Router,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) { }

  ngOnInit() {
    this.typeDropdown();
    this.treatyForm();
    this.columnDefs = [
      {
        headerName: "Select",
        field: 'tlPriority',
        cellStyle: { textAlign: 'center' },
        cellRenderer: "radioButtonRenderer",
        filter: false,
        sortable: false,
        enableRowGroup: false,
      },
      {
        headerName: "Treaty Type",
        field: "ttyLayerPK.tlLayer",
        sortable: true,
      },
      {
        headerName: "Treaty Basis",
        field: "extradata.ttyBasisValData",
        sortable: true,
      },
      {
        headerName: "Open Years",
        field: "tlOpenYears",
<<<<<<< HEAD
      },
      {
        headerName: "Ceding Basis",
        field: "tlCedingBasisDesc",
      },
      {
        headerName: "Adjust Broker Perc",
        field: "tlAdjBrkPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
=======
      },
      {
        headerName: "Ceding Basis",
        field: "tlCedingBasisDesc",
      },
      {
        headerName: "Ceding Type",
        field: "tlCedingTypeDesc",
      },
      {
        headerName: "Limits",
        field: "tlLimit",
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if(params.data && params.data.tlLimit) {            
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.tlLimit));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        }
      },
      {
        headerName: "Percentage",
        field: "tlPerc",
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if(params.data && params.data.tlPerc) {            
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.tlPerc));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },

      {
<<<<<<< HEAD
        headerName: "Ceding Type",
        field: "tlCedingTypeDesc",
      },
      {
        headerName: "Premium Limit",
        field: "tlLimit",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter,
      },
      {
        headerName: "Percentage",
        field: "tlPerc",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter4,
=======
        headerName: "Alloc On",
        field: "extradata.ttyAllocVal",
        cellStyle: { textAlign: 'left' }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },
      {
<<<<<<< HEAD
        headerName: "Alloc On",
        field: "extradata.ttyAllocVal",
        cellStyle: { textAlign: 'left' }
      },
      {
        headerName: "Cession Limit",
        field: "tlCessionLimit",
        cellStyle: { textAlign: 'right' },
        valueFormatter: currencyFormatter
      },
      {
        headerName: "Acnt Freq",
        field: "tlAcntFreqDesc",
=======
        headerName: "Cession Limit",
        field: "tlCessionLimit",
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if(params.data && params.data.tlCessionLimit) {            
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.tlCessionLimit));
          } else {
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
          }
        }
      },
      {
        headerName: "Acnt Freq",
        field: "extradata.ttyAccFreqVal",
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        cellStyle: { textAlign: 'left' }
      },
      {
        headerName: "Action",
        template:
          `<a>
<<<<<<< HEAD
          <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
=======
          <i class="fa fa-file-pen fa-icon fa-blue"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
         </a>&nbsp;
         <a>
          <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
         </a>`,
        cellStyle: { textAlign: 'center' },
        filter: false,
        sortable: false,
      }
    ];
    this.defaultColDef = {
      resizable: true,
<<<<<<< HEAD
      enableRowGroup: true,
      sortable: true,
      filter: true
=======
      sortable: true,
      filter: true,
      enableRowGroup: true
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    };
    this.agGridOptions();
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
  }

  treatyForm() {
    this.ttyform = this.builder.group({
      tlPriority: ['', Validators.required],
      tlLayer: ['', Validators.required],
      tlDesc: '',
      tlTtyBasis: ['', Validators.required],
      tlLinesOn: '',
<<<<<<< HEAD
      tlAllocOn: [''],
      tlOpenYears: ['', Validators.required],
      tlLimitCurr: '',
      tlLimit: ['', Validators.required],
      tlPerc: ['', Validators.required],
      tlLines: '',
      tlCedingBasis: ['', Validators.required],
      tlCedingType: ['', Validators.required],
      tlAdjBrkPerc: [''],
      tlCessionLimit: '',
      tlPlaLimit: undefined,
      tlClaLimit: undefined,
=======
      tlAllocOn: ['', Validators.required],
      tlOpenYears: '',
      tlLimitCurr: '',
      tlLimit: '',
      tlPerc: '',
      tlLines: '',
      tlCedingBasis: ['', Validators.required],
      tlCedingType: ['', Validators.required],
      tlCessionLimit: '',
      tlPlaLimit: '',
      tlClaLimit: '',
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      tlNoticeCanDays: '',
      tlNoticeRenDays: '',
      tlAcntFreq: ['', Validators.required],
      tlBordFreq: '',
      ttyLayerPK: '',
      tlPremCurr: '',
      tlRateType: 'Treaty Type',
      tlDeductible: '0',
      tlPrem: '0',
      tlPremRol: '0',
      tlStatus: 'P',
      tlCrUid: this.session.get('userId'),
      tlCrDt: new Date(),
    });
  }
  typeDropdown() {
    this.treatyService.appCodesList('TTY_BASIS').subscribe(resp => {
      this.treatyBasisList = resp.appcodeList;
    }, error => { });
    this.treatyService.appCodesList('CEDING_TYPE').subscribe(resp => {
      this.CedingTypeList = resp.appcodeList;
    }, error => { });
    this.treatyService.appCodesList('CEDING_BASIS').subscribe(resp => {
      this.CedingBasisList = resp.appcodeList;
    }, error => { });
    this.treatyService.appCodesList('ALLOC_MODE').subscribe(resp => {
      this.AllocList = resp.appcodeList;
    }, error => { });
    this.treatyService.appCodesList('TTY_ACNT_FRQ').subscribe(resp => {
      this.BouqFreqList = resp.appcodeList;
    }, error => { });
    this.treatyService.appCodesAccFreq('TTY_ACNT_FRQ', 'ACNT').subscribe(resp => {
      this.FreqList = resp;
    }, error => { });
    this.treatyService.appCodesList('LINES_ON').subscribe(resp => {
      this.LinesOnList = resp.appcodeList;
    }, error => { });

    this.treatyService.retrievecurrencyList().subscribe(resp => {
      this.currencyList = resp.currencyList;
    });
    this.onTreatyTermsGridReady();
<<<<<<< HEAD
  }
  appTreatyTypeList() {
    this.treatyService.appTreatyTypeList('TTY_TYPE', this.refNo).subscribe((resp: any) => {
      this.treatyTypeList = resp.appcodeList;
      if (this.treatyTypeList.length > 0) {
        this.ttyform.get('tlLayer').enable();
      }
    }, error => { });
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  addTreatyType() {
    this.ttyform.reset();
    this.ActionBtn = true;
<<<<<<< HEAD
    this.showForm = true;
    this.appTreatyTypeList();
    let obj = {
      'refNo': this.refNo,
      'amendNo': this.amendNo,
      'seqNo': this.seqNo
    }
    this.treatyService.retrieveLayerListById(obj).subscribe(resp => {
      let layerLength = resp.layerList.length;
      this.layercount = layerLength + 1;
      this.ttyform.get('tlPriority').setValue(this.layercount);
    })
=======
    this.showForm = true
    this.ttyform.get('tlPriority').setValue(this.layercount);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.ttyform.get('tlPriority').disable();
  }
  back() {
    this.showForm = false;
    this.isCedingBasis = false;
  }

  scriptcall(id) {
    // $('#'+id).DataTable().destroy();
    // setTimeout(() => {
    //   $('#'+id).DataTable().draw();
    //   $('#'+ id).DataTable().$('tr:first').find('td input:radio').prop('checked', true).trigger('click');  
    // }, 600);
  }

  saveType() {
    this.loaderService.isBusy = true;
<<<<<<< HEAD
    this.ttyform.get('tlOpenYears').enable();
=======
    this.ttyform.get('tlPriority').enable();
    this.ttyform.get('tlOpenYears').enable()
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

    if (this.ttyform.valid) {
      this.ttyform.get('tlPriority').enable();
      let param = {
        tlRefNo: this.refNo,
        tlSeqNo: this.seqNo,
        tlAmendNo: this.amendNo,
        tlLayer: this.ttyform.get('tlLayer').value
      }
      var tlCessionLimit = this.ttyform.get("tlCessionLimit").value;
      var tlClaLimit = this.ttyform.get("tlClaLimit").value;
<<<<<<< HEAD
      var tlLimit = this.ttyform.get("tlLimit").value;
      tlLimit = (tlLimit == null) ? 0 : parseFloat(tlLimit);
      var tlPlaLimit = this.ttyform.get("tlPlaLimit").value;
=======
      var tlLimit = this.ttyform.get("tlLimit").value ? this.ttyform.get("tlLimit").value.replace(/,/g, '') : 0;
      var tlPlaLimit = this.ttyform.get("tlPlaLimit").value;
      // var tlPriority = this.ttyform.get("tlPriority").value ? this.ttyform.get("tlPriority").value.replace(/,/g, '') : 0;
      tlPlaLimit = parseFloat(tlPlaLimit);
      tlClaLimit = parseFloat(tlClaLimit);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.ttyform.patchValue({
        tlCessionLimit: tlCessionLimit,
        tlClaLimit: tlClaLimit,
        tlLimit: tlLimit,
        tlPlaLimit: tlPlaLimit,
        tlPremCurr: this.ttyform.get('tlLimitCurr').value,
        tlRateType: 'Treaty Type',
        tlDeductible: '0',
        tlPrem: '0',
        tlPremRol: '0',
        tlStatus: 'P',
        tlCrUid: this.session.get('userId'),
        tlCrDt: new Date(),
        ttyLayerPK: param,
      });
<<<<<<< HEAD
      if (!this.isCedingBasis) {
        this.ttyform.get("tlAdjBrkPerc").setValue(null);
      }
      let formData = this.ttyform.value;
      if (this.contractType === 'TP') {
        formData.tlLimitCurr = this.basecurr;
        formData.tlPremCurr = this.basecurr;
      }
      // tlPlaLimit = tlPlaLimit == null ? 0 : parseFloat(tlPlaLimit);
      // tlClaLimit = tlClaLimit == null ? 0 : parseFloat(tlClaLimit);
      if (this.limitsValidations(tlClaLimit, tlPlaLimit)) {
        this.toastService.warning("CLA Limit must be greater than PLA Limit ");
        this.loaderService.isBusy = false;
      } else {
        delete formData.tlPriority;
        this.treatyService.saveLayerInfo(formData, this.amndSrNo).subscribe((resp: any) => {
          if (resp.messageType == 'W') {
            this.toastService.warning(resp.message);
          } else {
            this.toastService.success("Saved Successfully");
            this.onTreatyTermsGridReady();
            this.showForm = false;
            this.ttyform.reset();
          }
=======
      let TypeData = this.ttyform.value;
      if (this.contractType === 'TP') {
        TypeData.tlLimitCurr = this.basecurr;
        TypeData.tlPremCurr = this.basecurr;
      }
      console.log("Treaty Type Param", param, "Form Value", TypeData)

      if (tlClaLimit <= tlPlaLimit) {
        this.treatyService.saveLayerInfo(TypeData, this.amndSrNo).subscribe(resp => {
          console.log("Treaty Type Save Response", resp);
          this.callCurrProcedure(this.layercount)
          this.toastService.success("Successfully Saved");
          this.onTreatyTermsGridReady();
          this.showForm = false;
          this.ttyform.reset();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          this.loaderService.isBusy = false;
        }, error => {
          this.toastService.error("Error in Saving data  " + error.error.message);
          this.loaderService.isBusy = false;
        });
<<<<<<< HEAD
=======
      } else {
        this.toastService.warning('CLA Limit should be less than PLA Limit');
        this.loaderService.isBusy = false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    } else {
      this.validateAllFormFields(this.ttyform);
      this.layerEvent.emit("error");
      this.loaderService.isBusy = false;
    }
  }
  editType(detail) {
    this.loaderService.isBusy = true;
    this.document.body.scrollTop = 8;
    this.ActionBtn = false;
    this.selectedLayerId = detail.ttyLayerPK.tlLayer;
    this.layerAction = "edit";
    this.formDetails = detail;
    this.ttyform.reset();
    this.showForm = true;
    var value = this.formDetails.tlCedingType;
    this.treatyService.appCodesList('TTY_TYPE').subscribe((resp: any) => {
      this.treatyTypeList = resp.appcodeList;
    }, error => { });
    this.ttyform.get('tlPriority').disable();
    this.ttyform.get('tlLayer').disable();
    if (this.formDetails.tlOpenYears == 1) {
      this.ttyform.get('tlOpenYears').disable();
    }
    if (value == '01') {
      this.percFlag = false;
      this.limitFlag = false;
      this.linesFlag = true;
      this.linesOnFlag = true;
    } else if (value == '02') {
      this.linesFlag = false;
      this.linesOnFlag = false;
      this.limitFlag = false;
      this.percFlag = true;
    } else if (value == '03') {
      this.linesFlag = false;
      this.linesOnFlag = false;
      this.percFlag = false;
      this.limitFlag = true;
    } else if (value == '04') {
      this.limitFlag = true;
      this.linesFlag = true;
      this.linesOnFlag = true;
      this.percFlag = false;
    } else if (value == '05') {
      this.linesFlag = false;
      this.linesOnFlag = false;
      this.percFlag = true;
      this.limitFlag = true;
    }
    this.ttyform.patchValue({
      tlPriority: this.formDetails.tlPriority,
      tlLayer: this.formDetails.ttyLayerPK.tlLayer,
      tlTtyBasis: this.formDetails.tlTtyBasis,
      tlCedingType: this.formDetails.tlCedingType,
      tlLinesOn: this.formDetails.tlLinesOn,
      tlAllocOn: this.formDetails.tlAllocOn,
      tlOpenYears: this.formDetails.tlOpenYears,
      tlLimitCurr: this.formDetails.tlLimitCurr,
<<<<<<< HEAD
      tlLimit: this.formDetails.tlLimit,
      tlPerc: this.formDetails.tlPerc,
      tlLines: this.formDetails.tlLines,
      tlCedingBasis: this.formDetails.tlCedingBasis,
      tlAdjBrkPerc: this.formDetails.tlAdjBrkPerc,
      tlCessionLimit: this.formDetails.tlCessionLimit,
      tlPlaLimit: this.formDetails.tlPlaLimit,
      tlClaLimit: this.formDetails.tlClaLimit,
=======
      tlLimit: this.cpipe.transform(this.formDetails.tlLimit),
      tlPerc: this.formDetails.tlPerc,
      tlLines: this.formDetails.tlLines,
      tlCedingBasis: this.formDetails.tlCedingBasis,
      tlCessionLimit: this.cpipe.transform(this.formDetails.tlCessionLimit),
      tlPlaLimit: this.cpipe.transform(this.formDetails.tlPlaLimit),
      tlClaLimit: this.cpipe.transform(this.formDetails.tlClaLimit),
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      tlNoticeCanDays: this.formDetails.tlNoticeCanDays,
      tlNoticeRenDays: this.formDetails.tlNoticeRenDays,
      tlAcntFreq: this.formDetails.tlAcntFreq,
      tlBordFreq: this.formDetails.tlBordFreq,
      ttyLayerPK: this.formDetails.ttyLayerPK,
      tlPremCurr: this.formDetails.tlPremCurr,
      tlRateType: 'Treaty Type',
      tlDeductible: '0',
      tlPrem: '0',
      tlPremRol: '0',
      tlStatus: 'P',
      tlDesc: this.formDetails.tlDesc,
      tlCrUid: this.session.get('userId'),
      tlCrDt: new Date(),
    })
<<<<<<< HEAD
    var cedingBasis = this.formDetails.tlCedingBasis;

    if (cedingBasis == '03') {
      this.isCedingBasis = true;
    } else {
      this.isCedingBasis = false;
    }
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.loaderService.isBusy = false;
  }

  updateType() {
    this.loaderService.isBusy = true;
<<<<<<< HEAD
=======

    this.ttyform.get('tlPriority').enable();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.ttyform.get('tlOpenYears').enable()
    if (this.ttyform.valid) {
<<<<<<< HEAD
      this.ttyform.get('tlPriority').enable();
      this.ttyform.get('tlLayer').enable();
      var tlCessionLimit = this.ttyform.get("tlCessionLimit").value;
      var tlLimit = this.ttyform.get("tlLimit").value;
      var tlPlaLimit = this.ttyform.get("tlPlaLimit").value;
      var tlClaLimit = this.ttyform.get("tlClaLimit").value;
      if (!this.isCedingBasis) {
        this.ttyform.get("tlAdjBrkPerc").setValue(null);
      }
      this.ttyform.patchValue({
        tlCessionLimit: (tlCessionLimit == null) ? null : parseFloat(tlCessionLimit),
        tlLimit: (tlLimit == null) ? null : parseFloat(tlLimit),
        tlPlaLimit: (tlPlaLimit == null) ? null : parseFloat(tlPlaLimit),
        tlClaLimit: (tlClaLimit == null) ? null : parseFloat(tlClaLimit),
      })

      let formData = this.ttyform.value;
      // tlPlaLimit = tlPlaLimit == null ? 0 : parseFloat(tlPlaLimit);
      // tlClaLimit = tlClaLimit == null ? 0 : parseFloat(tlClaLimit);
      if (this.limitsValidations(tlClaLimit, tlPlaLimit)) {
        this.toastService.warning("CLA Limit must be greater than PLA Limit ");
        this.loaderService.isBusy = false;
      } else {
        // delete formData.tlPriority;
        this.treatyService.updateLayerInfo(formData.ttyLayerPK.tlLayer, formData, this.amndSrNo).subscribe(resp => {
          this.toastService.success("Updated Successfully");
          this.onTreatyTermsGridReady();
          this.showForm = false;
          this.ttyform.reset();
          this.loaderService.isBusy = false;
        }, error => {
          this.toastService.error(error.error.message);
          this.loaderService.isBusy = false;
        });
      }

    } else {
      this.validateAllFormFields(this.ttyform);
      this.layerEvent.emit("error");
      this.loaderService.isBusy = false;
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
=======
      var tlCessionLimit = this.ttyform.get("tlCessionLimit").value;
      var tlClaLimit = this.ttyform.get("tlClaLimit").value;
      var tlLimit = this.ttyform.get("tlLimit").value;
      var tlPlaLimit = this.ttyform.get("tlPlaLimit").value;
      this.ttyform.patchValue({
        tlCessionLimit: parseFloat(tlCessionLimit),
        tlClaLimit: parseFloat(tlClaLimit),
        tlLimit: parseFloat(tlLimit),
        tlPlaLimit: parseFloat(tlPlaLimit),
      })

      this.formvalues = this.ttyform.value;
      console.log("Treaty Type update form", this.formvalues);
      this.treatyService.updateLayerInfo(this.formvalues.ttyLayerPK.tlLayer, this.formvalues, this.amndSrNo).subscribe(resp => {
        console.log("Treaty Type update", resp);
        this.toastService.success("Updated Successfully");
        this.onTreatyTermsGridReady();
        this.showForm = false;
        this.ttyform.reset();
        this.callCurrProcedure(this.formvalues.ttyLayerPK.tlLayer);
        this.loaderService.isBusy = false;
      }, error => {
        this.toastService.error(error.error.message);
        this.loaderService.isBusy = false;
      });
    } else {
      this.validateAllFormFields(this.ttyform);
      this.layerEvent.emit("error");
    }
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      console.log(field + ":" + control.status);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  setSelectedValue(details) {
    this.selectedLayerId = details.ttyLayerPK.tlLayer;
    this.sendLayerHeading.emit(this.selectedLayerId);
    this.selectedLayer = details;
    this.sendLayer.emit(this.selectedLayer);
<<<<<<< HEAD
  }
  confirmationBlock() {
    this.open(this.confirmation, 'modal-sm');
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
=======
  }
  confirmationBlock() {
    this.open(this.confirmation, 'modal-sm');    
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  closeModal() {
    this.modalService.hide();
  }
  previousStep() {
    this.wizardHelper.goPrevious();
  }

  callCurrProcedure(layerId) {
    let obj = {
      tlRefNo: this.refNo,
      tlSeqNo: this.seqNo,
      tlAmendNo: this.amendNo,
      tlLayer: layerId,
      userId: this.session.get('userId'),
      company: this.session.get("companyCode"),
      division: this.session.get("userDivnCode"),
      status: "INS"

    }
    this.treatyService.storedProcedure(obj).subscribe(resp => {
    }, error => {
    });
  }

<<<<<<< HEAD
  fieldControls(event, type) {
    event = event.value;
=======
  fieldControls(value, type) {
    value = value.key;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    if (type == "ttybasis") {
      if (event == '01') {
        this.ttyform.get('tlOpenYears').setValue('1');
        this.ttyform.get('tlOpenYears').disable();
      } else {
        this.ttyform.get('tlOpenYears').reset();
        this.ttyform.get('tlOpenYears').enable();
      }
    }
    if (type == "ceding") {
      this.ttyform.get('tlLinesOn').clearValidators();
      this.ttyform.get('tlLimit').clearValidators();
      this.ttyform.get('tlPerc').clearValidators();
      this.ttyform.get('tlLines').clearValidators();
      this.ttyform.updateValueAndValidity();

      if (event == '01') {
        this.percFlag = false;
        this.limitFlag = false;
        this.linesFlag = true;
        this.linesOnFlag = true;
        this.ttyform.get('tlPerc').reset();
        this.ttyform.get('tlLimit').reset();
        this.ttyform.get('tlLines').reset();
        this.ttyform.get('tlLines').setValidators(Validators.required);
        this.ttyform.get('tlLinesOn').reset();
        this.ttyform.get('tlLinesOn').setValidators(Validators.required);
        this.ttyform.get('tlLines').updateValueAndValidity();
        this.ttyform.get('tlLinesOn').updateValueAndValidity();

      } else if (event == '02') {
        this.linesFlag = false;
        this.linesOnFlag = false;
        this.limitFlag = false;
        this.percFlag = true;
        this.ttyform.get('tlPerc').reset();
        this.ttyform.get('tlPerc').setValidators(Validators.required);
        this.ttyform.get('tlLimit').reset();
        this.ttyform.get('tlLines').reset();
        this.ttyform.get('tlLinesOn').reset();
        this.ttyform.get('tlPerc').updateValueAndValidity();

      } else if (event == '03') {
        this.linesFlag = false;
        this.linesOnFlag = false;
        this.percFlag = false;
        this.limitFlag = true;
        this.ttyform.get('tlPerc').reset();
        this.ttyform.get('tlLimit').reset();
        this.ttyform.get('tlLimit').setValidators(Validators.required);
        this.ttyform.get('tlLines').reset();
        this.ttyform.get('tlLinesOn').reset();
<<<<<<< HEAD
        this.ttyform.get('tlLimit').updateValueAndValidity();

      } else if (event == '04') {
=======
        this.ttyform.get('tlLimit').reset();
      } else if (value == '04') {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.limitFlag = true;
        this.linesFlag = true;
        this.linesOnFlag = true;
        this.percFlag = false;
        this.ttyform.get('tlPerc').reset();
        this.ttyform.get('tlLines').reset();
        this.ttyform.get('tlLines').setValidators(Validators.required);
        this.ttyform.get('tlLinesOn').reset();
        this.ttyform.get('tlLinesOn').setValidators(Validators.required);
        this.ttyform.get('tlLimit').reset();
        this.ttyform.get('tlLimit').setValidators(Validators.required);
        this.ttyform.get('tlLines').updateValueAndValidity();
        this.ttyform.get('tlLinesOn').updateValueAndValidity();
        this.ttyform.get('tlLimit').updateValueAndValidity();

      } else if (event == '05') {
        this.linesFlag = false;
        this.linesOnFlag = false;
        this.percFlag = true;
        this.limitFlag = true;
        this.ttyform.get('tlPerc').reset();
        this.ttyform.get('tlPerc').setValidators(Validators.required);
        this.ttyform.get('tlLines').reset();
        this.ttyform.get('tlLinesOn').reset();
        this.ttyform.get('tlLimit').reset();
        this.ttyform.get('tlLimit').setValidators(Validators.required);
        this.ttyform.get('tlPerc').updateValueAndValidity();
        this.ttyform.get('tlLimit').updateValueAndValidity();

      }
    }
    if (type == "percentage") {
      if (parseFloat(event) <= 100) {
      } else {
<<<<<<< HEAD
        this.toastService.warning("Percentage must be lesser than or equal to 100");
      }
    }
    if (type == "ceding_basis") {
      if (event == '03') {
        this.ttyform.get('tlAdjBrkPerc').setValidators(Validators.required);
        this.ttyform.get('tlAdjBrkPerc').updateValueAndValidity();
        this.isCedingBasis = true;
      } else {
        this.ttyform.get('tlAdjBrkPerc').clearValidators();
        this.ttyform.get('tlAdjBrkPerc').updateValueAndValidity();
        this.isCedingBasis = false;
=======
        this.toastService.warning("Percentage must be lesser than or equal to 100 ");
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    }
  }

<<<<<<< HEAD
  limitsValidations(claLimit, plaLimit) {
    if (claLimit == null && plaLimit == null) {
      return false;
    } else if (claLimit == null && typeof plaLimit !== 'object') {
      return true;
    } else if (typeof claLimit !== 'object' && plaLimit == null) {
      return true;
    } else {
      if (plaLimit >= claLimit) {
        return true;
      } else {
        return false;
=======
  LimitsValidations() {
    var plaLimit = parseFloat(this.ttyform.get('tlPlaLimit').value ? this.ttyform.get("tlPlaLimit").value.replace(/,/g, '') : 0);
    var claLimit = parseFloat(this.ttyform.get('tlClaLimit').value ? this.ttyform.get("tlClaLimit").value.replace(/,/g, '') : 0);

    if (claLimit != null && plaLimit != null) {
      if (claLimit == 0) {
        // this.toastService.add({ severity: 'error', summary: "CLA Limit should not be 0 "  });
      }
      else {
        if (plaLimit >= claLimit) { } else {
          this.toastService.warning("PLA Limit  must be equal or greater than CLA Limit ");
        }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }
    }
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("treaty_Grid").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    this.onTreatyTermsGridReady();
  }
  onBtExport(gridApi: any) {
    if (gridApi) {
<<<<<<< HEAD
      let columnKeys = [
        'extradata.ttyPriority',
        'ttyLayerPK.tlLayer',
        'extradata.ttyBasisValData',
        'tlOpenYears',
        'tlCedingBasisDesc',
        'tlCedingTypeDesc',
        'tlLimit',
        'tlPerc',
        'extradata.ttyAllocVal',
        'tlCessionLimit',
        'tlAcntFreqDesc'];
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'tratytype.xlsx',
        skipHeader: false,
        sheetName: 'Treaty Type',
        columnKeys: columnKeys,
        processCellCallback: (params) => {
          if (params.column.colId == "tlCessionLimit") {
            if (params.value == null || params.value == undefined) {
              return '0.00';
            } else {
              return params.value;
            }
          } else {
            return params.value;
          }
        },
      });
    }

=======
      gridApi.exportDataAsExcel({
        columnKeys:['tlPriority','ttyLayerPK.tlLayer','extradata.ttyBasisValData','tlOpenYears','tlCedingBasisDesc','tlCedingTypeDesc',
      'tlLimit','tlPerc','extradata.ttyAllocVal','tlCessionLimit','extradata.ttyAccFreqVal'],
        processCellCallback: (params) => {
          if (params.column.colId == "tlLimit" || params.column.colId == "tlPerc" 
              || params.column.colId == "tlCessionLimit"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }
        }
      });
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }
  onTreatyTermsGridReady() {
    this.loaderService.isBusy = true;
    let obj = {
      'refNo': this.refNo,
      'amendNo': this.amendNo,
      'seqNo': this.seqNo
    }
    this.treatyService.retrieveLayerListById(obj).subscribe(resp => {
      this.agTypeDataList = resp.layerList;
      let layerLength = this.agTypeDataList.length;
      if (layerLength == 0) {
<<<<<<< HEAD
        this.ttyform.reset();
        this.layercount = layerLength + 1;
        this.selectedLayer = undefined;
        this.sendLayer.emit(this.selectedLayer);
        this.ActionBtn = true;
        this.showForm = true;
        this.ttyform.get('tlPriority').setValue(this.layercount);
        this.ttyform.get('tlPriority').disable();

=======
        this.layercount = layerLength + 1;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      } else {
        let length = this.agTypeDataList[this.agTypeDataList.length - 1].tlPriority;
        this.layercount = (length + 1);
      }
<<<<<<< HEAD
      this.loaderService.isBusy = false;
=======
      console.log(layerLength, ' <----Treaty Type layercount --->', this.layercount);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.layerEvent.emit(this.agTypeDataList);
      this.sendLayerHeading.emit(layerLength ? 'Layer ' + layerLength : "0");
      if (this.agTypeDataList.length > 0) {
        this.context.componentParent.selectedRowId = this.agTypeDataList[0].tlPriority;
        this.selectedRowData({ data: this.agTypeDataList[0] });
      }
      for (var i = 0; i < this.agTypeDataList.length; i++) {
        console.log(this.agTypeDataList[i].tlCessionLimit);
        this.agTypeDataList[i].tlCessionLimit = (this.agTypeDataList[i].tlCessionLimit == null) ? 0 : this.agTypeDataList[i].tlCessionLimit; // ag-grid filter search was showing blanks instead of zero if null.
        for (var j = 0; j < this.treatyBasisList.length; j++) {
          for (var k = 0; k < this.AllocList.length; k++) {
            for (var l = 0; l < this.FreqList.length; l++) {
              var basisTableKey = this.agTypeDataList[i].tlTtyBasis;
              var AllocTableKey = this.agTypeDataList[i].tlAllocOn;
              var AccFreqTableKey = this.agTypeDataList[i].tlAcntFreq;
              var ttyBasisKey = this.treatyBasisList[j].key;
              var ttyAllocKey = this.AllocList[k].key;
              var ttyAccFreqKey = this.FreqList[l].key;
              if (basisTableKey == ttyBasisKey) {
                this.ttyBasisVal = this.treatyBasisList[j].item_text;
              }
              if (ttyAllocKey == AllocTableKey) {
                this.ttyAllocVal = this.AllocList[k].item_text;
              }
              if (AccFreqTableKey == ttyAccFreqKey) {
                this.ttyAccFreqVal = this.FreqList[l].item_text;
              }
            }
          }
        }
        let dataObj = { "ttyBasisValData": this.ttyBasisVal, "ttyAllocVal": this.ttyAllocVal, "ttyAccFreqVal": this.ttyAccFreqVal, "ttyPriority": this.agTypeDataList[i].tlPriority };
        this.agTypeDataList[i].extradata = dataObj;
      }
    });
    this.appTreatyTypeList();
  }
  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }
  selectedRowData(cell) {

    this.selectedLayerId = cell.data.ttyLayerPK.tlLayer;
    this.sendLayerHeading.emit(this.selectedLayerId);
    this.selectedLayer = cell.data;
    this.sendLayer.emit(this.selectedLayer);
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Edit":
          return this.editType(data);
        case "Delete":
          return this.showDialogbox(data);
      }
    }
  }
  showDialogbox(data: any) {
    this.temp = data;
    this.open(this.confirmModal, 'modal-sm');
  }
<<<<<<< HEAD
=======
  open(content, val) {
    this.modalService.show(content, { class: val });    
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  deleteRow() {
    if (this.temp && this.temp.ttyLayerPK.tlRefNo) {
      this.loaderService.isBusy = true;
      let obj = this.temp.ttyLayerPK;
      obj.tlPriority = this.temp.tlPriority;
<<<<<<< HEAD
=======
      console.log(obj);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

      this.treatyService.deleteLayer(obj).subscribe(() => {
        let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
        element.click();
        this.toastService.success('Deleted Succcessfully.');
<<<<<<< HEAD
        this.onTreatyTermsGridReady();
        this.showForm = false;
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.showForm = false;
=======
        // this.getAllBinderLOBByRefId();
        this.onTreatyTermsGridReady();
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.toastService.error(error.message);
      })
    } else {
      this.toastService.error('Error in Deleting Data');
    }
  }
  approve() {
    this.loaderService.isBusy = true;
<<<<<<< HEAD
    this.treatyService.getProductGridInfo().subscribe(info => {
      this.productlilst = info;
    })
    if (this.selectedLayer == undefined) {
      this.toastService.warning("Need to Add one treaty type to Approve.");
      this.loaderService.isBusy = false;
    } else if (this.productlilst.length == 0) {
      this.toastService.warning("Need to Add one Product to Approve.");
      this.loaderService.isBusy = false;
    } else {
      let obj = {
        tlStatus: 'A',
        tlPriority: this.selectedLayer.tlPriority,
        thApprDt: new Date(),
        thApprSts: "A",
        thApprUid: this.session.get('userId'),
        ttyLayerPK: {
          tlAmendNo: this.amendNo,
          tlRefNo: this.refNo,
          tlSeqNo: Number(this.seqNo),
          tlLayer: this.selectedLayer.ttyLayerPK.tlLayer,
        }
      };
      this.loaderService.isBusy = false;
      this.treatyService.approvalTreaty(obj).subscribe((resp: any) => {
        if (resp.messageType == 'W') {
          this.toastService.warning(resp.message);
        } else {
          this.toastService.success("Approved Successfully");
          this.modalService.hide();
          this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
        }
        this.loaderService.isBusy = false;
      }, error => {
        this.toastService.error(error.error.message);
        this.loaderService.isBusy = false;
      })
    }
=======

    let obj = {
      tlStatus: 'A',
      tlPriority: this.selectedLayer.tlPriority,
      ttyLayerPK: {
        tlAmendNo: this.amendNo,
        tlRefNo: this.refNo,
        tlSeqNo: Number(this.seqNo),
        tlLayer: this.selectedLayer.ttyLayerPK.tlLayer,
      }
    };
    this.treatyService.approvalTreaty(obj).subscribe((res) => {
      this.toastService.success("Approved Successfully");
      this.modalService.hide();
      this.loaderService.isBusy = false;
      this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
    }, error => {
      this.toastService.error("Error in Saving data  " + error.error.message);
      this.loaderService.isBusy = false;
    })
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
}
function currencyFormatter(params) {
  if (params != null && params.value !== undefined) {
    return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT,
      {
        minimumFractionDigits: 2,
      }
    ).format((params.value));
  } else { return '0.00' }
}
<<<<<<< HEAD
function currencyFormatter4(params) {
  if (params && params.value != null && params.value != undefined) {
    let vl = parseFloat(params.value);
    return vl.toFixed(4);
  } else {
    return '';
  }
}
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
