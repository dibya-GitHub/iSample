import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReinsurersComponent } from './reinsurers.component';

describe('ReinsurersComponent', () => {
  let component: ReinsurersComponent;
  let fixture: ComponentFixture<ReinsurersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReinsurersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReinsurersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
