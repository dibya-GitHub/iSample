import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
<<<<<<< HEAD
import { RadiorenderComponent } from '../radiorender/radiorender.component';
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

declare var $: any;
@Component({
  selector: 'app-reinsurers',
  templateUrl: './reinsurers.component.html',
  styleUrls: ['./reinsurers.component.css'],
  providers: [MycurrencyPipe]
})
export class ReinsurersComponent implements OnInit {
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  quickSearchValue: any;
  hideAddFlag: boolean = true;
  private gridApiRins;
  private gridColumnApi;
  public summaryColumns;
  public columnDefs;
  defaultColDef: any;
  private defaultColGroupDef;
  private columnTypes;
  public rowData = [];
  bottomData: any[];
  private statusBar
  trReins: any;
  trLayer: any;
  trAmendNo: any;
  trRefNo: any;
  sharePerc: number;
  totShare: number;
  btnName: string = 'Save';
  totalPremium: number = 0;
  totalDepPremium: number = 0;
  showForm: boolean = false;
  @Input()
  details: any;
  cols: any[];
  isShowGrid: boolean;
  _layer: string;
  reinsurerList: any;
  sharePrem: number;
  share: number;
  totalShareFlag: boolean = false;
  DepFlag: boolean = true;
  AdjFlag: boolean = true;
  Val_Dep_Prem: boolean;
  Val_Adj_Rate: boolean;
  totalSharePerc: number = 0;
  pinnedBottomRowData: any[];
  getRowStyle: (params: any) => { 'font-weight': string; };
  broker: any;

  set layer(value: string) {

    if (this._layer == value)
      return;
    this._layer = value;
  }
  @Input()
  get layer(): string {
    return this._layer;
  }
  @Input() action: any;
  @Input() amendNo: any;
  @Input() refNo: any;
  @Input() seqNo: number;
  @Input() amndSrNo: any;
  reBrkList: any;
  reInsList: any;
  accntList = [];
  reInsFrm: UntypedFormGroup;
  display: boolean = false;
  collapsed: boolean = true;
  headerTittle: string;
  private _minPremium: string;
  @Input() minPremium: string;

  @Input() depPremium;
  @Input() adjustRate;
  @Input() prem: any;
  @Input() depPremPerc;
  @Input() egnpiAmt;
  @Input() contractType;
  @Input() RateType;
  @Input() tlDesc: string;
  @Input() LayerData;
  @ViewChild('trigger') tr: ElementRef;

  @ViewChild('content') content: ElementRef;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;

  prem_label: string;
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private modalService: BsModalService,
<<<<<<< HEAD
    private session: SessionStorageService,
    private cpipe: MycurrencyPipe,
    @Inject(DOCUMENT) private document: Document
  ) {
=======
    private session: SessionStorageService, private cpipe: MycurrencyPipe,
    @Inject(DOCUMENT) private document: Document) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.defaultColDef = {
      resizable: true,
      enableRowGroup: false,
      sortable: true,
      editable: false
    };
    this.getRowStyle = function (params) {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold' };
      }
    };
    this.retrieveAccntToList();
  }

  ngOnInit() {
    this.document.body.scrollTop = 5;
    this.depPremium = (this.depPremium == null || this.depPremium == "") ? 0 : this.depPremium;
    this.isShowGrid = true;
    if ('TP' == this.contractType) {
      this.columnDefs = [
<<<<<<< HEAD
        { field: 'trReinsDesc', headerName: 'Reinsurer', sortable: true, tooltipField: "reinsDesc", filter: true, },
        { field: 'trBrokerDesc', headerName: 'Broker', sortable: true, tooltipField: "brokerDesc", filter: true },
        { field: 'trBrkRefNo', headerName: 'Reference', sortable: true, filter: true },
        { field: 'trAcntDesc', headerName: 'Accounting To', sortable: true, filter: true },
        {
          field: 'trSharePerc', headerName: 'Share', sortable: true, cellStyle: { textAlign: 'right' }, filter: true,
=======
        {
          field: 'trReins',
          headerName: 'Reinsurer',
          sortable: true,
          //tooltipField: "reinsDesc",
          filter: true,
          valueGetter: function (params) {
            if (params.data && params.data.reinsDesc && params.data.trReins) {
              return params.data.trReins + " - " + params.data.reinsDesc;
            } else {
              return params.data.trReins;
            }
          },
        },
        {
          field: 'brokerDesc',
          headerName: 'Broker',
          sortable: true,
          //tooltipField: "brokerDesc",
          filter: true,
          valueGetter: function (params) {
            if (params.data && params.data.trBroker && params.data.brokerDesc) {
              return params.data.trBroker + " - " + params.data.brokerDesc;
            } else {
              return params.data.brokerDesc;
            }
          },
        },
        {
          field: 'trAcntDesc',
          headerName: 'Accounting To',
          sortable: true,
          filter: true
        },
        {
          field: 'trBrkRefNo',
          headerName: 'Broker Ref#',
          sortable: true,
          filter: true
        },
        {
          field: 'trSharePerc',
          headerName: 'Share %',
          sortable: true,
          cellStyle: { textAlign: 'right' },
          filter: true,
          valueFormatter: '',
          valueGetter: function (params) {
            if (params.data && params.data.trSharePerc) {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.trSharePerc));
            } else {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
            }
          },
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        },
        {
          headerName: 'Action',
          field: 'trReins',
          cellStyle: { textAlign: 'center' },
          sortable: false,
          filter: false,
          enableRowGroup: false,
          cellRenderer: function (params) {
            if (params.value) {
<<<<<<< HEAD
              return `<a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
             </a>&nbsp;
             <a>
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
             </a>`
=======
              return ` <a>
                        <i class="fa fa-file-pen fa-icon"  data-action-type="Edit"  title="Edit" aria-hidden="true"></i>&nbsp;
                        <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete"  title="Delete" aria-hidden="true"></i>
                      </a>`
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
            } else {
              return ``;
            }
          }
        },
      ];

    } else {
      this.columnDefs = [
        {
          field: 'trReins',
          headerName: 'Reinsurer',
          sortable: true,
          //tooltipField: "reinsDesc",
          filter: true,
          valueGetter: function (params) {
            if (params.data && params.data.reinsDesc && params.data.trReins) {
              return params.data.trReins + " - " + params.data.reinsDesc;
            } else {
              return params.data.trReins;
            }
          },
        },
        {
          field: 'brokerDesc',
          headerName: 'Broker',
          sortable: true,
          //tooltipField: "brokerDesc",
          filter: true,
          valueGetter: function (params) {
            if (params.data && params.data.trBroker && params.data.brokerDesc) {
              return params.data.trBroker + " - " + params.data.brokerDesc;
            } else {
              return params.data.brokerDesc;
            }
          },
        },
        {
          field: 'trAcntDesc',
          headerName: 'Accounting To',
        },
        {
          field: 'trAdjustRate',
          headerName: 'Adjustment Rate',
          cellStyle: { textAlign: 'right' },
          filter: true,
          valueFormatter: '',
          //tooltipField: "trAdjustRate",
          valueGetter: function (params) {
            if (params.data && params.data.trAdjustRate) {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.trAdjustRate));
            } else {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
            }
          }
        },
        {
          field: 'trSharePerc',
          headerName: 'Share %',
          cellStyle: { textAlign: 'right' },
          filter: true,
          valueFormatter: '',
          //tooltipField: "trSharePerc",
          valueGetter: function (params) {
            if (params.data && params.data.trSharePerc) {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.trSharePerc));
            } else {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
            }
          }
        },
        {
          field: 'trPrem',
          headerName: '100% Premium',
          cellStyle: { textAlign: 'right' },
          filter: true,
          //valueFormatter: currencyFormatter,
          valueGetter: function (params) {
            if (params.data && params.data.trPrem) {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.trPrem));
            } else {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
            }
          },
          //tooltipField: "trPrem",
        },
        {
          field: 'trDepPrem',
          headerName: 'Dep Premium',
          cellStyle: { textAlign: 'right' },
          filter: true,
          valueGetter: function (params) {
            if (params.data && params.data.trDepPrem) {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((params.data.trDepPrem));
            } else {
              return Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format((0));
            }
          }
          //valueFormatter: currencyFormatter,
          //tooltipField: "trDepPrem",
        },
        {
          headerName: 'Action',
          field: 'trReins',
          cellStyle: { textAlign: 'center' },
          sortable: false,
          filter: false,
          enableRowGroup: false,
          cellRenderer: function (params) {
            if (params.value) {
              return ` <a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="Edit"  title="Edit" aria-hidden="true"></i>
              &nbsp;
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete"  title="Delete" aria-hidden="true"></i>
              </a>`
            } else {
              return ``;
            }
          }
        },
      ];

      this.summaryColumns = [
        {
          field: 'reinsDesc',
          headerName: 'Reinsurer'
        },
        {
          field: 'brokerDesc',
          headerName: 'Broker'
        },
        {
          field: 'trAcntDesc',
          headerName: 'Accounting To',
        },
        {
          field: 'trAdjustRate',
          headerName: 'Adjustment Rate'
        },
        {
          field: 'trSharePerc',
          headerName: 'Share %'
        },
        {
          field: 'trPrem',
          headerName: '100% Premium',
          cellStyle: { textAlign: 'right' },
          valueFormatter: currencyFormatter
        },
        {
          field: 'trDepPrem',
          headerName: 'Dep Premium',
          cellStyle: { textAlign: 'right' },
          valueFormatter: currencyFormatter
        },
        {
          headerName: 'Action',
          field: 'action'
        },
      ];
    }

    this.statusBar = {
      statusPanels: [
        {
          statusPanel: "agTotalRowCountComponent",
          align: "right"
        },
        { statusPanel: "agFilteredRowCountComponent" },
        { statusPanel: "agSelectedRowCountComponent" },
        { statusPanel: "agAggregationComponent" }
      ]
    };
    this.createReInsForm();
    this.loadGrid();
    this.retrieveAccntTo();
    this.FieldRestrictions();
    if (this.contractType == 'TP') {
      this.Val_Dep_Prem = false
      this.Val_Adj_Rate = false;
    } else if (this.contractType == 'FX') {
      this.Val_Dep_Prem = false
    } else {
      this.Val_Dep_Prem = true
      this.Val_Adj_Rate = true;
    }
  }

  loadGrid() {
<<<<<<< HEAD
    // alert(this.adjustRate+"  "+ this.depPremium);
    // this.minPremium=this.minPremium  ? "0": this.minPremium.replace(',','');
    // this.depPremium=  this.depPremium ?"0" :  this.depPremium.replace(',','');
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.showForm = false;
    this.details = [];
    if ("view" == this.action) {
      this.showForm = false;
    }
<<<<<<< HEAD

    //this.open(this.content,'modal-lg');
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.reterieveReInsGrid();
  }

  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  createReInsForm() {
    this.reInsFrm = this.fb.group({
      trRefNo: '',
      trAmendNo: '',
      trLayer: '',
      trSeqNo: '',
      trReins: ['', Validators.required],
      trBroker: '',
      trAcntTo: ['', Validators.required],
      trSharePerc: [, Validators.required],
      trAdjustRate: [, 'TP' == this.contractType ? '' : Validators.required],
      trPrem: '',
      trBrkRefNo: '',
      trDepPrem: '',
      trDepPremPerc: [, this.Val_Dep_Prem ? Validators.required : ''],
      trNcbPerc: '',
      trStatus: 'S',
      trCrUid: this.session.get('userId'),
      trCrDt: new Date(),
      //ttyReinsPK: '',
      trUpdUid: '',
      trUpdDt: ''

    })
    if (this.RateType == 'FR') {
      this.reInsFrm.get('trAdjustRate').disable();
    }
  }

  reterieveReInsList() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveReInsList(ApiUrls.REINS_MGMT_PATH, ApiUrls.REINS_CML_ID).subscribe(resp => {
      this.reInsList = resp.reInsList;
      this.reBrkList = resp.reInsList;
      this.loaderService.isBusy = false;

    }, error => { this.loaderService.isBusy = false; })
  }


  retrieveAccntTo() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveAccntTo().subscribe(resp => {
      this.accntList = resp.appcodeList;
      this.loaderService.isBusy = false;
    }, err => {
      this.toastService.error('Error');
      this.loaderService.isBusy = false;
    })
  }

  save(buttonName) {
    this.reInsFrm.get('trReins').enable();
    this.reInsFrm.get('trBroker').enable();
    if (this.reInsFrm.valid) {
      this.loaderService.isBusy = true;
      let objPk = {
        trRefNo: this.refNo,
        trAmendNo: this.amendNo,
        trLayer: this.layer,
        trSeqNo: this.seqNo
      }
      var share = parseFloat(this.reInsFrm.get('trSharePerc').value);
      if (this.action == 'edit') {

        if (this.sharePerc == undefined) {
          this.sharePerc = 0;
        }

        var totSharPerc = this.sharePerc + share;

        if (totSharPerc > 100 && share != 0) {
          this.loaderService.isBusy = false;
          this.toastService.warning('Total share percentage cant greater than 100 %');
          return false;
        } else {
          this.reInsFrm.patchValue({
            trRefNo: this.refNo,
            trAmendNo: this.amendNo,
            trLayer: this.layer,
            trSeqNo: this.seqNo,
            trStatus: 'S',
            trUpdUid: this.session.get('userId'),
            trUpdDt: new Date(),
            //ttyReinsPK: objPk,
            trReins: this.reInsFrm.get('trReins').value,
          })
          const reinsData = this.reInsFrm.value;
          if (typeof reinsData.trPrem === 'string') {
            reinsData.trPrem = (reinsData.trPrem) ? reinsData.trPrem.replace(/,/g, '') : 0;
          } else {
            reinsData.trPrem = (reinsData.trPrem) ? reinsData.trPrem : 0;
          }
          reinsData.trDepPrem = (reinsData.trDepPrem) ? reinsData.trDepPrem : 0;
          var depPremPerc = reinsData.trDepPremPerc;
          if (depPremPerc > 100) {
            this.loaderService.isBusy = false;
            this.toastService.warning('Deposit Premium value should not greater than 100 ');
          } else {
            this.treatyService.updateReInsById(reinsData, this.amndSrNo).subscribe(resp => {
              //this.collapsed = !this.collapsed;
              //this.toastService.success('Updated Successfully');
              if (resp["messageType"] && resp["messageType"] == 'E') {
                this.toastService.error(resp["message"]);
              } else if (resp["messageType"] && resp["messageType"] == 'S') {
                this.toastService.success(resp["message"]);
                this.reInsFrm.reset();
                if (buttonName == 'save') {
                  this.showForm = false;
                  this.hideAddFlag = true;
                } else {
                  this.showForm = true;
                  this.hideAddFlag = false;
                  this.addReinsurer();
                  this.reInsFrm.patchValue({
                    trPrem: '',
                    trDepPrem: '',
                  })
                }
                this.totShare = 0;
                this.reterieveReInsGrid();
              } else if (resp["messageType"] && resp["messageType"] == 'W') {
                this.toastService.warning(resp["message"]);
              }

              this.loaderService.isBusy = false;
            }, error => {
              this.reInsFrm.get('trReins').disable();
              this.reInsFrm.get('trBroker').disable();
              this.loaderService.isBusy = false;
              this.toastService.error(error.error.message);
            })
          }
        }

      } else {
        if (this.totShare == undefined) {
          this.totShare = 0;
        }
        let totSharPerc = this.totShare + share;
        if (totSharPerc > 100 && share != 0) {
          this.loaderService.isBusy = false;
<<<<<<< HEAD
          this.toastService.warning('Total share percentage cant greater than 100 %');
=======
          this.toastService.warning(' Total share percentage cant be greater than 100 %');
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          return false;
        } else {
          this.reInsFrm.patchValue({
            trRefNo: this.refNo,
            trAmendNo: this.amendNo,
            trLayer: this.layer,
            trSeqNo: this.seqNo,
            trStatus: 'S',
            trCrUid: this.session.get('userId'),
            trCrDt: new Date(),
            //ttyReinsPK: objPk,
            trReins: this.reInsFrm.get('trReins').value,
          })
          const reinsData = this.reInsFrm.value;
          if (typeof reinsData.trPrem === 'string') {
            reinsData.trPrem = (reinsData.trPrem) ? reinsData.trPrem.replace(/,/g, '') : 0;
          } else {
            reinsData.trPrem = (reinsData.trPrem) ? reinsData.trPrem : 0;
          }
          reinsData.trDepPrem = (reinsData.trDepPrem) ? reinsData.trDepPrem : 0;
          var depPremPerc = reinsData.trDepPremPerc;
          if (depPremPerc > 100) {
            this.loaderService.isBusy = false;
<<<<<<< HEAD
            this.toastService.warning('Deposit Premium value should not greater than 100 ');
=======
            this.toastService.warning('Deposit Premium value should not be greater than 100 ');
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          } else {
            this.treatyService.insertReinsrer(reinsData, this.amndSrNo).subscribe(resp => {
              //this.collapsed = !this.collapsed;
              if (resp["messageType"] && resp["messageType"] == 'E') {
                this.toastService.error(resp["message"]);
              } else if (resp["messageType"] && resp["messageType"] == 'S') {
                this.toastService.success(resp["message"]);
                this.reInsFrm.reset();
                if (buttonName == 'save') {
                  this.showForm = false;
                  this.hideAddFlag = true;
                } else {
                  this.showForm = true;
                  this.hideAddFlag = false;
                  this.addReinsurer();
                  this.reInsFrm.patchValue({
                    trPrem: '',
                    trDepPrem: '',
                  })
                }
                this.totShare = 0;
                this.reterieveReInsGrid();
              } else if (resp["messageType"] && resp["messageType"] == 'W') {
                this.toastService.warning(resp["message"]);
              }
              this.loaderService.isBusy = false;
              //this.toastService.success('Successfully Saved');              
            }, error => {
              this.loaderService.isBusy = false;
              this.toastService.error(error.error.message);
              this.reInsFrm.get('trReins').disable();
              this.reInsFrm.get('trBroker').enable();
            });
          }
        }

      }
    } else {
      this.validateAllFormFields(this.reInsFrm);
<<<<<<< HEAD
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }

  reterieveReInsGrid() {
    this.loaderService.isBusy = true;

    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: this.layer,
      seqNo: this.seqNo,
      treatyType: this.contractType
    }
    this.treatyService.retrieveReInsByLayer(obj).subscribe((resp: any) => {
      // alert(1);
      this.loaderService.isBusy = false;
      let share: number = 0;

<<<<<<< HEAD
      this.rowData = resp;
      if (this.rowData.length > 0) {
        // alert(2);
        for (var i = 0; i < this.rowData.length; i++) {

          let mimpre = (parseFloat(this.rowData[i].trSharePerc) * (parseFloat(this.minPremium))) / 100;
          let deppre = (parseFloat(this.rowData[i].trSharePerc) * (parseFloat(this.depPremium))) / 100;
          share = share + parseFloat(this.rowData[i].trSharePerc);
          this.totShare = share;
          this.rowData[i].minPremium = mimpre;
          this.rowData[i].depPremium = deppre;
          this.totalSharePerc = this.totalSharePerc + this.rowData[i].trSharePerc;
          this.totalPremium = this.totalPremium + this.rowData[i].trPrem;
          this.totalDepPremium = this.totalDepPremium + this.rowData[i].trDepPrem;
=======
      if (resp.length > 0) {
        // alert(2);
        for (var i = 0; i < resp.length; i++) {

          let mimpre = (parseFloat(resp[i].trSharePerc) * (parseFloat(this.minPremium))) / 100;
          let deppre = (parseFloat(resp[i].trSharePerc) * (parseFloat(this.depPremium))) / 100;
          share = share + parseFloat(resp[i].trSharePerc);
          this.totShare = share;
          resp[i].minPremium = mimpre;
          resp[i].depPremium = deppre;
          this.totalSharePerc = this.totalSharePerc + resp[i].trSharePerc;
          this.totalPremium = this.totalPremium + resp[i].trPrem;
          this.totalDepPremium = this.totalDepPremium + resp[i].trDepPrem;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

        }
        if (this.totShare != 0) { this.totalShareFlag = true }
      } else {
        // alert(3);
        //this.details = [];
        this.totShare = 0;
        if (this.totShare != 0) { this.totalShareFlag = true }

      }
<<<<<<< HEAD
=======
      //this.details = resp.reinsurerArray;
      this.rowData = resp;
      console.log("23 this.details", this.details);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (this.rowData) {
        this.pinnedBottomRowData = createData(1, this.rowData, "Bottom");
      }
      this.loaderService.isBusy = false;
      //  this.scriptcall('reinsurer');
      this.reinstSummaryDetails();
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  reinstSummaryDetails() {
    this.bottomData = [
      {
        reinsDesc: 'Total',
        brokerDesc: '',
        trAcntDesc: '',
        trAdjustRate: '',
        trSharePerc: this.totalSharePerc,
        trPrem: this.totalPremium,
        trDepPrem: this.totalDepPremium,
        action: '',
      }
    ];
  }

  addReinsurer() {
    this.hideAddFlag = false;
    this.reInsFrm.get('trReins').enable();
    this.reInsFrm.get('trBroker').enable();
<<<<<<< HEAD
    // if (!this.layer) {
    //   this.toastService.error('Please Select the layer');
    //   return false;
    // }
=======
    if (!this.layer) {
      this.toastService.warning('Please Select the layer');
      return false;
    }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.reterieveReInsList();
    this.action = 'add'
    this.btnName = 'Save';
    this.showForm = true;
    if (this.reInsFrm.value != null) {
      this.reInsFrm.reset();
    }

    this.reInsFrm.patchValue({
      trAdjustRate: this.adjustRate,
      trDepPremPerc: this.depPremPerc.toFixed(7),
    })
  }

<<<<<<< HEAD
  // calculatePrem(type,val){
  //   var calculateValue;
  //   // alert(this.reInsFrm.get('trSharePerc').value);
  //  if('rate'==type){
  //    this.share=parseFloat(this.reInsFrm.get('trSharePerc').value == null ? 0 : this.reInsFrm.get('trSharePerc').value );
  //   //  calculateValue=((this.egnpiAmt*val)/100)*share;
  //   if(this.reInsFrm.get('trSharePerc').value ==''|| this.reInsFrm.get('trSharePerc').value==null ){
  //     this.toastService.add({ severity: 'success', detail: 'Enter share percentage' });
  //   }else{
  //   calculateValue=(this.egnpiAmt*(val/100)*(this.share/100));
  //   this.sharePrem = calculateValue;
  //   // alert(calculateValue);
  // }
  //  }else if('share'==type){
  //   let rate=parseFloat(this.reInsFrm.get('trAdjustRate').value);
  //   var premium100perc= this.egnpiAmt*(val/100)*(this.share/100)
  //   calculateValue=((this.egnpiAmt*rate)/100)*val;
  //   this.sharePrem= calculateValue;
  //  }

  //  this.reInsFrm.get('trPrem').setValue(this.cpipe.transform(this.sharePrem.toString()));
  // ;
  //  if( this.reInsFrm.get('trDepPremPerc').value){
  //   var percent=parseFloat(this.reInsFrm.get('trDepPremPerc').value);
  //  let depPremium = (calculateValue * percent) / 100;
  //  this.reInsFrm.get('trDepPrem').setValue(this.cpipe.transform(depPremium.toString()));
  //  }
  // }

  calculateDepositPremium(percent) {
    let premium = parseFloat(this.reInsFrm.get('trPrem').value);
    let depPremium = (premium * percent) / 100;
    this.reInsFrm.get('trDepPrem').setValue(this.cpipe.transform(depPremium.toString()));
=======
  calculateDepositPremium(percent) {
    let premium = parseFloat(this.reInsFrm.get('trPrem').value);
    let depPremium = (premium * percent) / 100;
    console.log("depPremium2", depPremium);
    this.reInsFrm.get('trDepPrem').setValue(depPremium);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  back() {
    this.showForm = false;
    this.hideAddFlag = true;
  }

  edit(data: any) {
    this.action = 'edit'
    this.showForm = true;
    this.hideAddFlag = false;
    this.btnName = 'Update';
    if (this.totShare > 0) {
      this.sharePerc = this.totShare - parseFloat(data.trSharePerc);
    } else {
      this.sharePerc = 0;
    }


    this.reterieveReInsList();
    let object = {
      trRefNo: data.trRefNo,
      trAmendNo: data.trAmendNo,
      trLayer: data.trLayer,
      trReins: data.trReins,
      trSeqNo: this.seqNo,
    }
    this.reinsurerList = data
    var resp = data;
    if (resp.trBroker != null) {
      this.retrieveAccntTo();
    }
    this.reInsFrm.patchValue(data);
    this.reInsFrm.get('trReins').disable();
    this.reInsFrm.get('trBroker').disable();
<<<<<<< HEAD

    // }, error => {
    // })

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  fetchAddInfo(insCode) {
    this.treatyService.retrieveReInsAddlInfo(insCode).subscribe(resp => {
      this.retrieveAccntToList();
    })
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
      if (control instanceof UntypedFormControl) {
=======
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  loadAccTo() {
    //alert("ACC_TO");
    this.reInsFrm.get("trAcntTo").reset();
    this.retrieveAccntTo();
  }

  deleteReIns() {
    this.loaderService.isBusy = true;
    let obj = {
      trRefNo: this.trRefNo,
      trAmendNo: this.trAmendNo,
      trLayer: this.trLayer,
      trReins: this.trReins,
      trSeqNo: this.seqNo,
      broker: this.broker
    }
    this.treatyService.deleteReInsById(obj, this.amndSrNo).subscribe(resp => {
      this.toastService.success('Deleted Succcessfully');
      this.modalService.hide();
      this.reterieveReInsGrid();
      this.showForm = false;
      this.hideAddFlag = true;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  retrieveAccntToList() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveAccntToList(ApiUrls.APP_CODES_MGMT_PATH).subscribe(resp => {
      this.accntList = resp.appcodeList;
      this.loaderService.isBusy = false;
    }, err => {
      this.toastService.error("Error in fetching Accounting To");
    })
  }

  showDialogbox(reInsInfo: any) {
<<<<<<< HEAD
    this.trRefNo = reInsInfo.ttyReinsPK.trRefNo,
      this.trAmendNo = reInsInfo.ttyReinsPK.trAmendNo,
      this.trLayer = reInsInfo.ttyReinsPK.trLayer,
=======
    console.log(reInsInfo)
    this.trRefNo = reInsInfo.trRefNo,
      this.trAmendNo = reInsInfo.trAmendNo,
      this.trLayer = reInsInfo.trLayer,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.trReins = reInsInfo.trReins,

      this.open(this.confirmcontent, 'modal-sm');
  }

  calculatePremium() {
    var adjVal = this.reInsFrm.get('trAdjustRate').value?parseFloat(this.reInsFrm.get('trAdjustRate').value):null;
    var adjRate = this.adjustRate?this.adjustRate:null;
    var shareVal = parseFloat(this.reInsFrm.get('trSharePerc').value);
    var depPremVal = parseFloat(this.reInsFrm.get('trDepPremPerc').value);
    if (adjVal == adjRate) {
      var reinsDep = (parseFloat(this.LayerData.prem) / 100);
      reinsDep = reinsDep * shareVal;
<<<<<<< HEAD
      this.reInsFrm.get('trPrem').setValue(this.cpipe.transform(reinsDep.toString()));
=======
      console.log("Reinsurer Value ", reinsDep)
      this.reInsFrm.get('trPrem').setValue(reinsDep);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    } else {
      if (shareVal == 0 || shareVal == null) {
        this.toastService.warning('Share value should not be 0  ');
      } else if (shareVal > 100) {
        this.toastService.warning('Share value should not greater than 100 ');
      } else {
        var calculateValue = (this.egnpiAmt * (adjVal / 100) * (shareVal / 100));
        this.reInsFrm.get('trPrem').setValue(calculateValue);

        if (depPremVal == 0 || depPremVal == null) {
          this.toastService.warning('Deposit Premium value should not Empty or Zero ');
        } else {
          var calculateDepPrem = calculateValue * (depPremVal / 100);
          this.reInsFrm.get('trDepPrem').setValue(calculateDepPrem);
          this.calculateDepPrem();
        }
      }
    }
  }
  calculateAdjRate() {
    var premVal = parseFloat(this.reInsFrm.get('trPrem').value ? this.reInsFrm.get('trPrem').value : 0);
    var shareVal = this.reInsFrm.get('trSharePerc').value;
    if (shareVal) {
      if (typeof shareVal === 'string') {
        shareVal = parseFloat(this.reInsFrm.get('trSharePerc').value ? this.reInsFrm.get('trSharePerc').value : 0);
      }
    } else {
      shareVal = 0;
    }

    if (this.RateType == 'AR') {
      if ((shareVal != 0 || shareVal != null) && premVal != 0 || premVal != null) {
        if (premVal != 0 || premVal != null) {
          // var share = (shareVal/100 );
          // var egnpiAmt = parseFloat(this.egnpiAmt);
          var prem = premVal / (shareVal / 100);
          var calAdjRate = ((prem / this.egnpiAmt) * 100).toFixed(7);
          // this.reInsFrm.get('trAdjustRate').setValue(calAdjRate);
        }
      }
    }
  }
  calculateDepPrem() {
    var adjVal
    if (this.DepFlag) {
      adjVal = this.reInsFrm.get('trAdjustRate').value;
    } else {
      adjVal = 1;
    }
    var shareVal = this.reInsFrm.get('trSharePerc').value;
    var depPremVal = this.reInsFrm.get('trDepPremPerc').value;
    if (depPremVal == 0 || depPremVal == null) {
      this.toastService.warning('Deposit Premium value should not Empty or Zero ');
    } else if (depPremVal > 100) {
      this.reInsFrm.get('trDepPremPerc').invalid
      this.toastService.warning('Deposit Premium value should not greater than 100 ');
    } else {
      var calculateValue = (this.egnpiAmt * (adjVal / 100) * (shareVal / 100));
      var calculateDepPrem = calculateValue * (depPremVal / 100);
      this.reInsFrm.get('trDepPrem').setValue(calculateDepPrem);
    }
  }
  calculateFlatRate() {
    var shareVal = this.reInsFrm.get('trSharePerc').value;
    var layerFlatPrem = parseFloat(this.depPremium);
    var calcFlatPrem = layerFlatPrem * (shareVal / 100);
    this.reInsFrm.get('trPrem').setValue(calcFlatPrem);
    // var prem = parseFloat(this.reInsFrm.get('trPrem').value);
    // var calFlatDepPrem = (shareVal / 100) * calcFlatPrem
    // this.reInsFrm.get('trDepPrem').setValue(calFlatDepPrem);
    this.calculateDepPrem();
  }

  FieldRestrictions() {
    if (this.contractType == 'FX') {
      this.DepFlag = false;
    } else {
      this.DepFlag = true;
    }
    if (this.contractType == 'TP') {
      this.DepFlag = false;
      this.AdjFlag = false;
    } else {
      this.DepFlag = true;
    }
    if ('FR' == this.RateType) {
      this.AdjFlag = false;
      this.DepFlag = false;
      this.prem_label = 'Flat Premium';
    } else {
      this.prem_label = '100% Premium';
    }
  }

  onGridReady(params) {
    this.gridApiRins = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiRins.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApiRins) {
      return this.gridApiRins.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("reinsurersTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");

      switch (actionType) {
        case "Edit":
          return this.edit(data);
        case "Delete":
          this.broker = data.trBroker
          return this.showDialogbox(data);

      }
    }

  }

  onQuickFilterChanged() {
    this.gridApiRins.setQuickFilter(this.quickSearchValue);
  }
  onBtExport() {
    if (this.gridApiRins) {
      if ('TP' == this.contractType) {
        this.gridApiRins.exportDataAsExcel({
          columnKeys: ['reinsDesc', 'brokerDesc', 'trAcntDesc', 'trBrkRefNo', 'trSharePerc'],
          processCellCallback: (params) => {
            if (params.column.colId == "trSharePerc") {
              if (params.value) {
                return parseFloat((params.value).replace(/,/g, ''));
              } else {
                return "";
              }
            }
            else {
              return params.value;
            }

          }
        });
      } else {
        this.gridApiRins.exportDataAsExcel({
          columnKeys: ['reinsDesc', 'brokerDesc', 'trAcntDesc', 'trAdjustRate', 'trSharePerc', 'trPrem', 'trDepPrem'],
          processCellCallback: (params) => {
            if (params.column.colId == "trAdjustRate" || params.column.colId == "trSharePerc" || params.column.colId == "trPrem"
              || params.column.colId == "trDepPrem") {
              if (params.value) {
                return parseFloat((params.value).replace(/,/g, ''));
              } else {
                return "";
              }
            }
            else {
              return params.value;
            }

          }
        });
      }

    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApiRins.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
<<<<<<< HEAD
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
    this.gridApi.sizeColumnsToFit();
=======
    this.gridApiRins.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApiRins.paginationGoToPage(0);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  recalcDepPerc() {
    var DepPrem = parseFloat(this.reInsFrm.get('trDepPrem').value != null ? this.reInsFrm.get('trDepPrem').value : 0);
    var prem = parseFloat(this.reInsFrm.get('trPrem').value);
    var calc = ((DepPrem / prem) * 100).toFixed(7);
    this.reInsFrm.get('trDepPremPerc').setValue(calc);

  }
  calculateFlatPrem() {
    var sharePerc = parseFloat(this.reInsFrm.get('trSharePerc').value);
    var layerFlatPrem = parseFloat(this.depPremium);
    var calcFlatPrem = layerFlatPrem * (sharePerc / 100);
    this.reInsFrm.get('trPrem').setValue(calcFlatPrem);
  }

  closeModal() {
    this.modalService.hide();
  }
}

function currencyFormatter(params) {
  return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
}

function formatNumber(number) {
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

function createData(count, data, prefix) {
  var result = [];
  var sumtrPrem = 0;
  var sumtrDepPrem = 0;
  var sumtrSharePerc = 0;
  var sumtrAdjustRate = 0;
  for (var i = 0; i < data.length; i++) {
    sumtrPrem = sumtrPrem + data[i].trPrem;
    sumtrDepPrem = sumtrDepPrem + data[i].trDepPrem;
    sumtrSharePerc = sumtrSharePerc + data[i].trSharePerc;
    sumtrAdjustRate = sumtrAdjustRate + data[i].trAdjustRate;
  }
  for (var i = 0; i < count; i++) {
    result.push({
      brokerDesc: 'Total',
      trAdjustRate: sumtrAdjustRate,
      trPrem: sumtrPrem,
      trDepPrem: sumtrDepPrem,
      trSharePerc: sumtrSharePerc
    });
  }
  return result;
}
