import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmendmentHistoryComponent } from './amendment-history.component';

describe('AmendmentHistoryComponent', () => {
  let component: AmendmentHistoryComponent;
  let fixture: ComponentFixture<AmendmentHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmendmentHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmendmentHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
