import { Component, OnInit } from '@angular/core';
<<<<<<< HEAD
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
=======
import { UntypedFormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { LoaderService } from 'src/app/services/loader.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { LoaderService } from './../../../services/loader.service';

declare var $: any;

@Component({
  selector: 'app-amendment-history',
  templateUrl: './amendment-history.component.html',
  styleUrls: ['./amendment-history.component.scss']
})
export class AmendmentHistoryComponent implements OnInit {

  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  quickSearchValue = '';
  public gridOptions;
  columnDefs: any;
  defaultColDef: any;
  historyData: any;
  domLayout: string;
  gridApi: any;
  gridColumnApi: any;
  private rowGroupPanelShow;
  refNo: any;
  seqNo: any;
  amendNo: any;
  amendHistAllData: any;
  amendHistGridApi: any;
  amendHistSearchValue: any = '';
  amendHistCols: any;
  rowSelection: string;
  showAmendOptionSelected = 10;
<<<<<<< HEAD
  showAmendOptions = [10, 20, 50, 100];
=======
  showAmendOptions = [5, 10, 20, 50, 100];
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  contractDesc: any;
  amendSrNo: any;
  amendRef: any;
  amendDesc: any;
  rowClassRules: any;

  constructor(
<<<<<<< HEAD
    private treatyService: TreatyService,
    private router: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
=======
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private router: Router,
    private toastService: ToastService,
    private session: SessionStorageService,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private activeRoute: ActivatedRoute,
    private loaderService: LoaderService,
  ) {

    this.defaultColDef = {
      resizable: true,
      enableRowGroup: true,
      filter: true,
      sortable: true,
    };
    this.rowGroupPanelShow = 'always';
    this.domLayout = 'autoHeight';
    this.setGridConfig();
  }
  setGridConfig() {
    this.rowSelection = 'single';
    this.columnDefs = [
      {
        headerName: 'Page',
        field: 'tcaPage',
        headerTooltip: 'Page',
        width: 120
      },
      {
        headerName: 'Section',
        field: 'tcaSection',
        headerTooltip: 'Section',
        width: 120
      },

      {
        headerName: 'Field',
        field: 'tcaField',
        headerTooltip: 'Field',
        width: 120
      },
      {
        headerName: 'Log Type',
        field: 'tcaLogType',
        headerTooltip: 'Log Type',
        width: 120,
<<<<<<< HEAD
        valueGetter: function (params) {
          if (params && params.data && params.data.tcaLogType) {
            if (params.data.tcaLogType === 'I') {
              return 'Insert';
            } else if (params.data.tcaLogType === 'U') {
              return 'Update';
            } else if (params.data.tcaLogType === 'D') {
              return 'Delete';
            } else {
              return '';
            }
=======
        // cellClassRules: {
        //   'ag-light-green-outer': function (params) {
        //     if (params.value == 'I') {
        //       return params.value == 'I';
        //     }
        //   },
        //   'ag-light-yellow-outer': function (params) {
        //     if (params.value == 'U') {
        //       return params.value == 'U';
        //     }
        //   },
        //   'ag-red-outer': function (params) {
        //     if (params.value == 'D') {
        //       return params.value == 'D';
        //     }
        //   },
        // },
        // cellRenderer: function (params) {
        //   if (params.value === undefined || params.value === null) {
        //     return '';
        //   } else if (params.value === 'I') {
        //     return '<span class="ag-element"> Insert </span>';
        //   } else if (params.value === 'U') {
        //     return '<span class="ag-element"> Update </span>';
        //   } else if (params.value === 'D') {
        //     return '<span class="ag-element"> Delete </span>';
        //   }
        // },
        valueGetter: function (params) {
          if (params.data && params.data.tcaLogType === 'I') {
            return 'Insert';
          } else if (params.data && params.data.tcaLogType === 'U') {
            return 'Update';
          } else if (params.data && params.data.tcaLogType === 'D') {
            return 'Delete';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          } else {
            return '';
          }
        },
      },
      {
        headerName: 'Old Value',
        field: 'tcaOldValue',
        headerTooltip: 'Old Value',
        width: 120,
        enableRowGroup: false,
        cellClassRules: {
          'ag-dark-red-outer': function (params) {
            if (params && params.data && params.data.tcaLogType == 'D') {
              if (params && params.data && params.data.tcaOldValue) {
                return params.data.tcaOldValue;
              } else {
                return '';
              }
            } else {
              return '';
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params && params.data && params.data.tcaLogType) {
            if (params && params.data && params.data.tcaOldValue) {
              let num = params.data.tcaOldValue;
              if (isNumeric(num)) {
                num = Number(num);
                return '<span class="ag-element"> ' + num.toFixed(2) + ' </span>';
              } else {
                return '<span class="ag-element"> ' + num + ' </span>';
              }
            } else {
              return '';
            }
          } else {
            if (params && params.data && params.data.tcaOldValue) {
              return params.data.tcaOldValue;
            } else {
              return '';
            }
          }
        },
      },
      {
        headerName: 'New Value',
        field: 'tcaNewValue',
        headerTooltip: 'New Value',
        width: 120,
        enableRowGroup: false,
        cellClassRules: {
          'ag-light-green-outer': function (params) {
            if (params && params.data && params.data.tcaNewValue && params.data.tcaLogType == 'I') {
              return params.data.tcaNewValue;
            }
          },
          'ag-light-yellow-outer': function (params) {
            if (params && params.data && params.data.tcaNewValue && params.data.tcaLogType == 'U') {
              if (params && params.data && params.data.tcaNewValue) {
                let num = params.data.tcaNewValue;
                if (isNumeric(num)) {
                  num = Number(num);
                  return num.toFixed(2);
                } else {
                  return num;
                }
              } else {
                return '';
              }
            } else {
              if (params && params.data && params.data.tcaNewValue) {
                return params.data.tcaNewValue;
              } else {
                return '';
              }
            }
          },
        },
        cellRenderer: function (params) {
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params && params.data && params.data.tcaNewValue && params.data.tcaLogType == 'I') {
            if (params && params.data && params.data.tcaNewValue) {
              let num = params.data.tcaNewValue;
              if (isNumeric(num)) {
                num = Number(num);
                return '<span class="ag-element"> ' + num.toFixed(2) + ' </span>';
              } else {
                return '<span class="ag-element"> ' + num + ' </span>';
              }
            } else {
              return '';
            }
          } else if (params && params.data && params.data.tcaNewValue && params.data.tcaLogType == 'U') {
            if (params && params.data && params.data.tcaNewValue) {
              let num = params.data.tcaNewValue;
              if (isNumeric(num)) {
                num = Number(num);
                return '<span class="ag-element"> ' + num.toFixed(2) + ' </span>';
              } else {
                return '<span class="ag-element"> ' + num + ' </span>';
              }
            } else {
              return '';
            }

          } else {
            if (params && params.data && params.data.tcaNewValue) {
              return params.data.tcaNewValue;
            } else {
              return '';
            }
          }
        },
      },
      {
        headerName: 'Changed On',
        field: 'tcaLogDate',
        headerTooltip: 'Changed On',
        width: 120,
        valueGetter: function (data) {
          if (data.data && data.data.tcaLogDate) {
            return moment(data.data.tcaLogDate).format('DD/MM/YYYY HH:mm');
          }
        },
      },
      {
        headerName: 'Log User',
        field: 'tcaLogUid',
        headerTooltip: 'Log User',
        width: 120
      }
    ];
    this.amendHistCols = [

<<<<<<< HEAD
      {
        headerName: 'Amend Sr No',
        field: 'id.tcaiAmendSrNo',
        sort: 'asc'
      },
      {
        headerName: 'Amend Reference',
        field: 'tcaiAmendRef'
      },
      {
        headerName: 'Amend Description',
        field: 'tcaiAmendDesc'
      },
      {
        headerName: 'Amend Start Date',
        field: 'tcaiAmendStartDate',
        valueGetter: function (params) {
          if (params && params.data && params.data.tcaiAmendStartDate) {
            return moment(params.data.tcaiAmendStartDate).format('DD/MM/YYYY HH:mm');
          }
        },
=======
      { headerName: 'Amend Sr No', field: 'id.tcaiAmendSrNo',
      filter: true, sortable: true, enableRowGroup: true,},
      { headerName: 'Amend Reference', field: 'tcaiAmendRef',filter: true, sortable: true, enableRowGroup: true, },
      { headerName: 'Amend Description', field: 'tcaiAmendDesc',filter: true, sortable: true, enableRowGroup: true, },
      {
        headerName: 'Amend Start Date', field: 'tcaiAmendStartDate',
        cellRenderer: AmendStDtCellRenderer,
        valueGetter: function (params) {
          if (params && params.data && params.data.tcaiAmendStartDate) {
            return moment(params.data.tcaiAmendStartDate).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
        filter: true, sortable: true, enableRowGroup: true,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },
      {
        headerName: 'Action',
        field: 'id.tcaiAmendSrNo',
<<<<<<< HEAD
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        width: 100,
        filter: false,
        sortable: false,
=======
        cellRenderer: actionRenderAmdHist,       
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        enableRowGroup: false,
      }
    ];

    // this.rowClassRules = {
    //   'ag-grid-row-update': function (params) {
    //     if (params.data.tcaLogType == 'U') {
    //       var tcaLogType = params.data.tcaLogType;
    //       return tcaLogType;
    //     }
    //   },
    //   'ag-grid-row-insert': function (params) {
    //     if (params.data.tcaLogType == 'I') {
    //       var tcaLogType = params.data.tcaLogType;
    //       return tcaLogType;
    //     }
    //   },
    // };

  }
  ngOnInit() {
<<<<<<< HEAD
    this.loaderService.isBusy = true;
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    this.activeRoute.queryParams.subscribe((params: any) => {
      if (params) {
        this.refNo = params.refNo;
        this.seqNo = params.seqNo;
        this.amendNo = params.amendNo;
        this.contractDesc = params.contDesc
        this.fetchAllAmendHistory(params);
      } else {
        this.toastService.error('Error in fetching Amendment History');
      }
    });
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: null,
      enableFilter: true
    };

  }
  fetchAllAmendHistory(data) {
    this.loaderService.isBusy = true;
    this.treatyService.fetchAllAmendHistory(data).subscribe(
      res => {
        this.loaderService.isBusy = false;
        this.amendHistAllData = res;
        // this.contractDesc = this.amendHistAllData[0].contDesc
        let data = {
          refNo: this.amendHistAllData[0].id.tcaiRefNo,
          seqNo: this.amendHistAllData[0].id.tcaiSeqNo,
          amendNo: this.amendHistAllData[0].id.tcaiAmendNo,
          amendSrNo: this.amendHistAllData[0].id.tcaiAmendSrNo,
          amendDesc: this.amendHistAllData[0].tcaiAmendDesc,
          amendRef: this.amendHistAllData[0].tcaiAmendRef,
        }
        this.retriveHistoryDetails(data);
<<<<<<< HEAD
        this.loaderService.isBusy = false;
      }, err => {
        this.loaderService.isBusy = false;
=======
      }, err => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.toastService.error('Error in Fetching');
        this.loaderService.isBusy = false;
      });
  }
  retriveHistoryDetails(data) {
    this.loaderService.isBusy = true;
    this.treatyService.retriveAmendmendHistory(data).subscribe(
      res => {
        this.loaderService.isBusy = false;
        this.historyData = res;
        this.amendRef = data.amendRef;
        this.amendSrNo = data.amendSrNo;
        this.amendDesc = data.amendDesc
<<<<<<< HEAD
        this.loaderService.isBusy = false;
      },
      err => {
        this.loaderService.isBusy = false;
=======
      },
      err => {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.toastService.error('Error in Fetching');
        this.loaderService.isBusy = false;
      }
    );
  }
<<<<<<< HEAD

  // onGridReady(gridApi, table) {
  //   gridApi = gridApi.api;
  //   gridApi.sizeColumnsToFit();
  //   if (table === 'amendHistAll') {
  //     this.amendHistGridApi = gridApi;
  //   } else {
  //     this.gridApi = gridApi;
  //   }
  // }

  onGridReady(params, gridName) {
    if (gridName === 'amendHistAll') {
      this.amendHistGridApi = params.api;
    } else if (gridName === '') {
      this.gridApi = params.api;
=======
  onGridSizeChanged(params) {
    console.log(params)
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(gridApi, table) {
    gridApi = gridApi.api;
    gridApi.sizeColumnsToFit();
    if (table === 'amendHistAll') {
      this.amendHistGridApi = gridApi;
    } else {
      this.gridApi = gridApi;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
    params.api.sizeColumnsToFit();
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }
  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    gridApi.setQuickFilter(qickSearch);
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('allTreatyLayerTable').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  loadInitialData(response) {
    let data = response;
    let selectedData = {
      refNo: data.id.tcaiRefNo,
      seqNo: data.id.tcaiSeqNo,
      amendNo: data.id.tcaiAmendNo,
      amendSrNo: data.id.tcaiAmendSrNo,
      amendDesc: data.tcaiAmendDesc,
      amendRef: data.tcaiAmendRef,
    }
    return this.retriveHistoryDetails(selectedData);
  }
  onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "View":
          let selectedData = {
            refNo: data.id.tcaiRefNo,
            seqNo: data.id.tcaiSeqNo,
            amendNo: data.id.tcaiAmendNo,
            amendSrNo: data.id.tcaiAmendSrNo,
            amendDesc: data.tcaiAmendDesc,
            amendRef: data.tcaiAmendRef,
          }
          return this.retriveHistoryDetails(selectedData);
      }
    }
  }
  back() {
    this.router.navigate(['treaty/contract-grid'], { queryParams: { title: 'home' } });
  }
  displayRowCount(gridApi) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
}

function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-eye fa-icon" data-action-type="View" title="View Amend history serial" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;
    </a>`;
  }
}
<<<<<<< HEAD
=======
function actionRenderAmdHist(params) {
  if (params.value === undefined || params.value === null) {
     return '';
  } else {
     return ` <a>
     <i class="fa fa-eye fa-icon" data-action-type="View" title="View Amend history serial" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;
     </a>`;
  }
}
function AmendStDtCellRenderer(params) {
  if (params.data && params.data.tcaiAmendStartDate) {
    return moment(params.data.tcaiAmendStartDate).format('DD/MM/YYYY');
  } else {
    return '';
  }
}
var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
function isNumeric(value) {
  return /^-?\d+$/.test(value);
}