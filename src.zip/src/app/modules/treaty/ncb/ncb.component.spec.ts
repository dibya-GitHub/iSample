import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NCBComponent } from './ncb.component';

describe('NCBComponent', () => {
  let component: NCBComponent;
  let fixture: ComponentFixture<NCBComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NCBComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NCBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
