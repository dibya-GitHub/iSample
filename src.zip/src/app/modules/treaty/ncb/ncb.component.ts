import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
<<<<<<< HEAD
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
=======
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { DatePipe } from '@angular/common'; import * as moment from 'moment';
import { ToastService } from 'src/app/services/toast.service';
import { EditviewrenderComponent } from '../editviewrender/editviewrender.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { EditviewrenderComponent } from '../editviewrender/editviewrender.component';


@Component({
  selector: 'app-ncb',
  templateUrl: './ncb.component.html',
  styleUrls: ['./ncb.component.scss']
})
export class NCBComponent implements OnInit {
  @ViewChild('confirmcontent') confirmation: ElementRef;
  reinsurerDetails: any[];
  layerDetails: any;
  reinsurerColumn: any[];
  layerColumn: any[];
  ContractCoumn: any[];
  contractDetails: any[];
  amendNo: string = '0';
  type: any;
  dashBoard: any;
  mode: any;
  transId: any;
  seqNo: any;
  referenceNo: any;

  private defaultColDef;
  private getRowHeight;
  private frameworkComponents;
  private context;
  contractGridApi: any;
  gridColumnApi: any;
  showContractEntriesOptionSelected = 5;
  showAdjEntriesOptionSelected = 5;
  showReinstEntriesOptionSelected = 5;
  showSumryEntriesOptionSelected = 5;
  showRecEntriesOptionSelected = 5;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionsReins = [5, 10, 20, 50, 100];
  showEntriesOptionsSumry = [5, 10, 20, 50, 100];
  gridApiReinsurer: any;
  gridApiAdjust: any;
  gridApiContract: any;
  gridApiRecovery: any;
  recoverySearchValue: any;
  initSearchValue: string = '';
  contractSearchValue: string = '';
  adjustSearchValue: string = '';
  reinsurerSearchValue: string = '';
  reinsSummarySearchValue: string = '';
  rowSelection: string;
  adjGridApi: any;
  reinstGridApi: any;
  reinSummaryGridApi: any;
  layerName: any;
  calcFlag: boolean = false;
  calcBtn: boolean;
  showPrintBtn: boolean;
  reInsSummaryColumn: any[];
  reinsSummaryDetails: any;
  pinnedBottomReinsurerData: any[];
  pinnedBottomSummaryData: any[];
  pinnedBottomLayerData: any[];
  constructor(
    private router: Router,
    private treatyService: TreatyService,
<<<<<<< HEAD
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private modalService: BsModalService,
=======
    private route: Router,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
    private router: Router, private modalService: BsModalService, private datePipe: DatePipe,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) { }

  ngOnInit() {
    this.showPrintBtn = false;
    this.rowSelection = 'single'
    this.referenceNo = this.treatyService.getParamValue('refNo');
    this.seqNo = this.treatyService.getParamValue('seqNo');
    this.transId = this.treatyService.getParamValue('processId');
    this.mode = this.treatyService.getParamValue('mode');
    this.dashBoard = this.session.get("userDashboard")
    this.type = this.treatyService.getParamValue('type');
    this.amendNo = this.treatyService.getParamValue('amendNo');
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: false,      
    };
    this.ContractCoumn = [
      { field: 'txaTransId', headerName: 'Process Id', sortable: true, tooltipField: 'txaTransId', enableRowGroup: true, filter: true},
      {
        field: 'txaTtyRefNo', headerName: 'Reference No', sortable: true, tooltipField: 'txaTtyRefNo', enableRowGroup: true, valueGetter: function (params) {
          return params.data.txaTtyRefNo + ' - ' + params.data.txaTtySeqNo;
        },
        filter: true
      },
      {
        field: 'txaCrDt',
        headerName: 'Processed Date',
        cellRenderer: prDateCellRenderer,
        valueGetter: function (params) {
          if (params && params.data && params.data.txaCrDt) {
            return moment(params.data.txaCrDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        sortable: true,          
        enableRowGroup: true,
        filter:true,
        filterParams: filterParamsPrDt,
      },
      //{ field: 'txaCrDt', headerName: 'Processed Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaCrDt', enableRowGroup: true ,filter: true},
      { field: 'txaCrUid', headerName: 'Processed By', sortable: true, tooltipField: 'txaCrUid', enableRowGroup: true, filter: true },
      {
        field: 'txaApprDt',
        headerName: 'Approved Date',
        cellRenderer: ApprDateCellRenderer,
        valueGetter: function (params) {
          if (params && params.data && params.data.txaApprDt) {
            return moment(params.data.txaApprDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        sortable: true,          
        enableRowGroup: true,
        filter:true,
        filterParams: filterParamsPrDt,
      },
      //{ field: 'txaApprDt', headerName: 'Approved Date', valueFormatter: this.dateFormatter, sortable: true, tooltipField: 'txaApprDt', enableRowGroup: true ,filter: true},
      { field: 'txaApprUid', headerName: 'Approved By', sortable: true, tooltipField: 'ApprovedBy', enableRowGroup: true ,filter: true},
      { field: 'txaApprSts', headerName: 'Status', sortable: true, tooltipField: 'txaApprSts' ,filter: true},
      {
        headerName: 'Action',
        cellRendererFramework: EditviewrenderComponent, cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
    ];
    this.layerColumn = [
      { field: 'talTtySeqNo', headerName: 'Sequence No', sortable: true, tooltipField: 'talTtySeqNo',filter: true},
      { field: 'txlAdjLayerPK.talLayer', headerName: 'Layer', sortable: true, tooltipField: 'txlAdjLayerPK.talLayer' ,filter: true},
      { field: 'talLimitCurr', headerName: 'Currency', sortable: true, tooltipField: 'talLimitCurr' ,filter: true},
      { field: 'talLimit', headerName: 'Limit', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true,
      valueGetter: function (params) {
        if (params && params.data && params.data.talLimit) {
          return Number(params.data.talLimit).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      },filter: true},
      { field: 'talDeductible', headerName: 'Excess', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, 
      valueGetter: function (params) {
        if (params && params.data && params.data.talDeductible) {
          return Number(params.data.talDeductible).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      } ,filter: true},
      { field: 'talRecoverd', headerName: 'XL Recovered', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, 
      valueGetter: function (params) {
        if (params && params.data && params.data.talRecoverd) {
          return Number(params.data.talRecoverd).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      }, filter: true},
      { field: 'talFinalPrem', headerName: 'Final Prem', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, 
      valueGetter: function (params) {
        if (params && params.data && params.data.talFinalPrem) {
          return Number(params.data.talFinalPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      }, filter: true},

    ];
    this.reinsurerColumn = [
      { field: 'txlAdjReinsPK.tarReins', headerName: 'Reinsurer', sortable: true, tooltipField: 'txlAdjReinsPK.tarReins' ,filter: true},
      { field: 'tarBroker', headerName: 'Broker', sortable: true, tooltipField: 'tarBroker' ,filter: true},
      { field: 'tarAcntTo', headerName: 'Account To', sortable: true, tooltipField: 'tarAcntTo' ,filter: true},
      { field: 'tarAdjRate', headerName: 'Adjust Rate', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, 
      valueGetter: function (params) {
        if (params && params.data && params.data.tarAdjRate) {
          return Number(params.data.tarAdjRate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      },filter: true },
      { field: 'tarSharePerc', headerName: 'Share %', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true,
      valueGetter: function (params) {
        if (params && params.data && params.data.tarSharePerc) {
          return Number(params.data.tarSharePerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      }, filter: true},
      { field: 'tarFinalPrem', headerName: 'Share Premium', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, 
      valueGetter: function (params) {
        if (params && params.data && params.data.tarFinalPrem) {
          return Number(params.data.tarFinalPrem).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      },filter: true },
      { field: 'tarNcbPerc', headerName: 'NCB %', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, 
      valueGetter: function (params) {
        if (params && params.data && params.data.tarNcbPerc) {
          return Number(params.data.tarNcbPerc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      },filter: true },
      { field: 'tarNcbAmt', headerName: 'NCB Amount', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, 
      valueGetter: function (params) {
        if (params && params.data && params.data.tarNcbAmt) {
          return Number(params.data.tarNcbAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      },filter: true },
    ];
    this.reInsSummaryColumn = [
      { field: 'tarBroker', headerName: 'Broker', tooltipField: 'tarBroker',filter: true},
      { field: 'tarPremCurr', headerName: 'Prem CCY', tooltipField: 'tarPremCurr',filter: true },
      { field: 'tarReinstActl', headerName: 'Accounting Premium', tooltipField: 'tarReinstActl', cellStyle: { textAlign: 'right' }, 
      valueGetter: function (params) {
        if (params && params.data && params.data.tarReinstActl) {
          return Number(params.data.tarReinstActl).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      },filter: true },
      { field: 'tarDepPaid', headerName: 'Deposit Premium', tooltipField: 'tarDepPaid', cellStyle: { textAlign: 'right' }, 
      valueGetter: function (params) {
        if (params && params.data && params.data.tarDepPaid) {
          return Number(params.data.tarDepPaid).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      },filter: true },
      { field: 'tarReinstBal', headerName: 'Balance Due', tooltipField: 'tarReinstBal', cellStyle: { textAlign: 'right' }, 
      valueGetter: function (params) {
        if (params && params.data && params.data.tarReinstBal) {
          return Number(params.data.tarReinstBal).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        } else {
          return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');;
        }
      } , filter: true},
    ];
    this.fetchProcedure();
    // this.retrieveLayerDetail();

  }

  fetchProcedure() {
    this.treatyService.callAdjustmentProcedure(this.referenceNo, this.seqNo, this.type, this.session.get("userId")).subscribe(resp => {
      this.transId = resp.transId;
      this.retrieveContractDetails();
      this.retriveReinsSummary(this.transId,this.type);
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    });
  }

  retriveReinsSummary(transId,type) {
    // transId = this.treatyService.getParamValue('transId');
    this.treatyService.retriveReinsSummaryDetails(transId,type).subscribe(resp => {
      this.reinsSummaryDetails = resp;
      if (this.reinsSummaryDetails) {
        this.pinnedBottomSummaryData = ReinsurerData(1, this.reinsSummaryDetails, "Bottom");
      }
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
      this.reinsSummaryDetails = [];
    });
  }

  retrieveContractDetails() {
    this.loaderService.isBusy = true;
    let obj = {
      type: this.type,
      refNo: this.referenceNo,
      seqNo: this.seqNo
    }
    this.treatyService.NCBContractDetails(obj).subscribe(resp => {
      this.contractDetails = resp.contractList;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })
  }

  calculateNCB() {
    var data = {
      transId: this.transId,
      company: this.session.get('companyCode'),
      division: this.session.get('userDivnCode'),
      dept: this.session.get('userDeptCode'),
      userId: this.session.get('userId')
    }
    this.treatyService.NCBcalcProcedure(data).subscribe(res => {
      this.calcFlag = true;
      this.retrieveLayerDetail();
    }, error => {
      this.toastService.error("NCB Calculation ERROR " + error.error.message);
    });
  }

  retrieveLayerDetail() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveAdjLayer(this.transId).subscribe(resp => {
      this.layerDetails = resp.layerList;
      if (this.layerDetails) {
        this.pinnedBottomLayerData = LayerData(1, this.layerDetails, "Bottom");
      }
      this.layerName = this.layerDetails[0].tlDesc != null ? this.layerDetails[0].txlAdjLayerPK.talLayer + '-' + this.layerDetails[0].tlDesc : this.layerDetails[0].txlAdjLayerPK.talLayer;
      this.retrieveReinsurerAdj(this.layerDetails[0]);
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }


  retrieveReinsurerAdj(details) {
    if (details == null || details == '') { this.reinsurerDetails = []; } else {
      this.loaderService.isBusy = true;
      let obj = {
        transId: details.txlAdjLayerPK.talTransId,
        layer: details.txlAdjLayerPK.talLayer,
        tarRefNo: details.talTtyRefNo,
        tarSeqNo: details.talTtySeqNo,
        tarAmendNo: details.talTtyAmendNo
      }
      // this.layerNo=obj.layer;
      this.treatyService.ncbReinsurerAdj(obj).subscribe(resp => {
        this.reinsurerDetails = resp;
        this.layerName = this.layerDetails[0].talDesc != null ? this.layerDetails[0].txlAdjLayerPK.talLayer + '-' + this.layerDetails[0].talDesc : this.layerDetails[0].txlAdjLayerPK.talLayer;
        this.loaderService.isBusy = false;
        if (this.reinsurerDetails) {
          this.pinnedBottomReinsurerData = ReinsurerData(1, this.reinsurerDetails, "Bottom");
        }
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
        this.reinsurerDetails = [];
      });
    }
  }

  approveNCB() {
    var data = {
      transId: this.transId,
      company: this.session.get('companyCode'),
      division: this.session.get('userDivnCode'),
      dept: this.session.get('userDeptCode'),
      userId: this.session.get('userId')
    }
    this.treatyService.NCBapprProcedure(data).subscribe(resp => {
      this.showPrintBtn = true;
      this.modalService.hide();
      this.retrieveContractDetails();
      this.toastService.success("Approved Successfully");
    }, error => {
      this.showPrintBtn = false;
      this.toastService.error("Error in Approval " + error.error.message)
    })
  }


  close() {
    this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
  }

  confirmationBlock() {
    this.open(this.confirmation, 'modal-sm');
<<<<<<< HEAD
=======
    // this.modalService.open(this.confirmation, { size: 'modal-sm' }).result.then((result) => {
    // }, (reason) => {
    // });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }

  onQuickFilterChanged(mode) {
    if (mode == 'contract') {
      this.contractGridApi.setQuickFilter(this.contractSearchValue);
    } else if (mode == 'adjustment') {
      this.adjGridApi.setQuickFilter(this.adjustSearchValue);
    } else if (mode == 'reinsurer') {
      this.reinstGridApi.setQuickFilter(this.reinsurerSearchValue);
    } else if (mode == 'reinsSummary') {
      this.reinSummaryGridApi.setQuickFilter(this.reinsSummarySearchValue);
    }

  }

  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
  }

  onGridReady(params, gridName: any) {
    if (gridName === 'contract') {
      this.contractGridApi = params.api;
    } else if (gridName === 'adjustment') {
      this.adjGridApi = params.api;
    } else if (gridName === 'reinsurer') {
      this.reinstGridApi = params.api;
    } else if (gridName === 'reinsSummary') {
      this.reinSummaryGridApi = params.api;
    }
    params.api.sizeColumnsToFit();
  }

  displayedRowCount() {
    // if (this.gridApi) {
    //   return this.gridApi.getDisplayedRowCount();
    // } else {
    //   return;
    // }
  }
  onGridContractReady(params) {
    this.gridApiContract = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiContract.sizeColumnsToFit();
  }
  displayedContractRowCount() {
    if (this.gridApiContract) {
      return this.gridApiContract.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridAdjustmentReady(params) {
    this.gridApiAdjust = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiAdjust.sizeColumnsToFit();
  }
  displayedAdjustmentRowCount() {
    if (this.gridApiAdjust) {
      return this.gridApiAdjust.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridReinsurerReady(params) {
    this.gridApiReinsurer = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiReinsurer.sizeColumnsToFit();
  }
  displayedReinsurerRowCount() {
    if (this.gridApiReinsurer) {
      return this.gridApiReinsurer.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onGridRecoveryReady(params) {
    this.gridApiRecovery = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiRecovery.sizeColumnsToFit();
  }
  displayedRecoveryRowCount() {
    if (this.gridApiRecovery) {
      return this.gridApiRecovery.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onRowClicked(e, title) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.transId = data.txaTransId;
      if (actionType == 'View') {
        this.calcBtn = false;
        this.showPrintBtn = true
        this.retrieveLayerDetail();
      } else if (actionType == 'Edit') {
        this.calcBtn = true;
        this.showPrintBtn = false
      }

      switch (title) {
        case 'layer':
          return this.retrieveReinsurerAdj(data);
      }
    }
  }
  onGridSizeChanged(params) {
    console.log(params)
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  rowHeight() {
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
  }


  dateFormatter(params) {
    if (params.value != null) {
      return moment(params.value).format('DD/MM/YYYY');
    } else { return }
  }
<<<<<<< HEAD
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  viewAccounting() {
    this.router.navigate(['/treaty/treaty-view-accounting'], { queryParams: { 'refNo': this.referenceNo, 'docType': 'NCB', 'seqNo': this.seqNo, 'amendNo': this.amendNo } });
  }
  closeModal() {
    this.modalService.hide();
  }
<<<<<<< HEAD
=======

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
}

function numberFormatter(params) {
  if (params.value != null) {
    var currencyVal = Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value).toFixed(2));
  } else {
    var currencyVal = Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  }

  return currencyVal;
}
function ReinsurerData(count, data, prefix) {
  var result = [];
  var tarReinstPaid = 0;
  var sumtarFinalPrem = 0;
  var sumtarSharePerc = 0;
  var tarReinstActl = 0;
  var tarReinstBal = 0;
  var tarDepPaid = 0;
  var tarPremBal = 0;
  var tarNcbPerc = 0;
  var tarNcbAmt = 0;
  for (var i = 0; i < data.length; i++) {
    tarReinstActl = tarReinstActl + data[i].tarReinstActl;
    tarReinstPaid = tarReinstPaid + data[i].tarReinstPaid;
    sumtarFinalPrem = sumtarFinalPrem + data[i].tarFinalPrem;
    sumtarSharePerc = sumtarSharePerc + data[i].tarSharePerc;
    tarReinstBal = tarReinstBal + data[i].tarReinstBal;
    tarDepPaid = tarDepPaid + data[i].tarDepPaid;
    tarPremBal = tarPremBal + data[i].tarPremBal;
    tarNcbPerc = tarNcbPerc + data[i].tarNcbPerc;
    tarNcbAmt = tarNcbAmt + data[i].tarNcbAmt
  }
  for (var i = 0; i < count; i++) {
    result.push({
      tarBroker: 'Total',
      tarReinstPaid: tarReinstPaid,
      tarFinalPrem: sumtarFinalPrem,
      tarSharePerc: sumtarSharePerc,
      tarReinstActl: tarReinstActl,
      tarReinstBal: tarReinstBal,
      tarDepPaid: tarDepPaid,
      tarPremBal: tarPremBal,
      tarNcbPerc: tarNcbPerc,
      tarNcbAmt: tarNcbAmt
    });
  }
  return result;
}
function LayerData(count, data, prefix) {
  var result = [];
  var talLimit = 0;
  var talDeductible = 0;
  var talRecoverd = 0;
  var talAdjRate = 0;
  var talPrem = 0;
  var talDepPaid = 0;
  var talFinalPrem = 0;
  var talPremBal = 0;
  var talReinstPaid = 0;
  var talReinstActl = 0;
  var talReinstBal = 0;
  for (var i = 0; i < data.length; i++) {
    talLimit = talLimit + data[i].talLimit;
    talDeductible = talDeductible + data[i].talDeductible;
    talRecoverd = talRecoverd + data[i].talRecoverd;
    talAdjRate = talAdjRate + data[i].talAdjRate;
    talPrem = talPrem + data[i].talPrem;
    talDepPaid = talDepPaid + data[i].talDepPaid;
    talFinalPrem = talFinalPrem + data[i].talFinalPrem;
    talPremBal = talPremBal + data[i].talPremBal;
    talReinstPaid = talReinstPaid + data[i].talReinstPaid
    talReinstActl = talReinstActl + data[i].talReinstActl
    talReinstBal = talReinstBal + data[i].talReinstBal
  }
  for (var i = 0; i < count; i++) {
    result.push({
      talTtySeqNo: 'Total',
      talLimit: talLimit,
      talDeductible: talDeductible,
      talRecoverd: talRecoverd,
      talAdjRate: talAdjRate,
      talPrem: talPrem,
      talDepPaid: talDepPaid,
      talFinalPrem: talFinalPrem,
      talPremBal: talPremBal,
      talReinstPaid: talReinstPaid,
      talReinstActl: talReinstActl,
      talReinstBal: talReinstBal
    });
  }
  return result;
}
function prDateCellRenderer(params) {
  if (params.data && params.data.txaCrDt) {
    return moment(params.data.txaCrDt).format('DD/MM/YYYY');
  } else {
    return '';
  }
}
function ApprDateCellRenderer(params) {
  if (params.data && params.data.txaApprDt) {
    return moment(params.data.txaApprDt).format('DD/MM/YYYY');
  } else {
    return '';
  }
}
var filterParamsPrDt = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};

function  curruncyFormatter(params) {
  if (params && params.value) {
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else {return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); }
}