import { DatePipe } from '@angular/common';
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { TreatyWizardHelperService } from '../services/treaty-wizard-helper.service';
import { TreatyLayerFormComponent } from '../treaty-layer-form/treaty-layer-form.component';
<<<<<<< HEAD

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
;
declare var $: any;

@Component({
  selector: 'app-treaty-wizard',
  templateUrl: './treaty-wizard.component.html',
  styleUrls: ['./treaty-wizard.component.css'],
  providers: [DatePipe, MycurrencyPipe]
  //encapsulation : ViewEncapsulation.ShadowDom
})
export class TreatyWizardComponent implements OnInit {
  deletePeril: any;
  tlDesc: any;
  perilData: any;
  tlMaxRec: any;
  showEntriesOptionsPerils = [5, 10, 20, 50, 100];
  showEntriesOptionSelectedPerils = 5;
  quickSearchValue: any;
  gridColumnApi: any;
  gridApiPerils: any;
  rowData = [];
  riskLlyods: any;
  enableTermsModal: boolean = false;
  showTrustFund: boolean = false;
  trustFund = [];
  // contrctType: any;

  treatyType: any = [];
  showAproveBtn: boolean = true;
  perilKey: any;
  showReinsurer: boolean = false;
  perilCols = [];
  perilDetails = [];
  currency: boolean = false;
  Perildiv: boolean = false;
  reinsure: boolean = false;
  //layerNum: string;
  perilItem = [];
  selectForm: UntypedFormGroup;
  dropdownList: any;
  showPerilFrm: boolean = false;
  //action: string;
  showForm: boolean = false;
  showPerilEgnp: boolean = false;
  showReinsurerPremium: boolean;
  stepTitle: any;
  layerNo: string;
  showPrintBtn = false;
  // basecurr:string;
  @ViewChild('layercomponent') layercomponent: TreatyLayerFormComponent;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  selectedItems = [];
  layerId: string = "";
  typexol: any;
  contractTypeList: any[];
  typecontract: any;
  type: any;
  @Input('label') label: string;
  seqNo: any;
  basecurr: any;
  currencyPremium: boolean;
  CurrType: string;
  layerLimitCurr: any;
  layerPremCurr: any;
  xolTypeId: any;
  egnpiLabel = 'EGNPI';
  contType: any;
  tlRateType: any;
  showLayerType: boolean = false;
  wizardLabel: string;
  tlAad: any;
  tlDeductible: any;
  tlLimit: any;
  wizards: any[];
  currentWizard: any;
  documents: any[];
  isDocumentNeedsToBeUpdated: boolean;
  contractData: any;
  facGnpiData: any;
  contractFormType: any;
  ApplPolicyData: any;
  amndSrNo: any;
  LayerData: any;
<<<<<<< HEAD
  tlPriority: any;
  layerPriority: any;
=======
  public defaultColDef;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private modalService: BsModalService,
    private session: SessionStorageService,
    private wizardHelper: TreatyWizardHelperService,
  ) {
    this.defaultColDef = {
      resizable: true,
      enableRowGroup: true,
      sortable: true,
      filter: true
    };
  }

  //public canEnterStep1 = true;

  public canEnterStep2Backwards = true;
  public canEnterStep2Forwards = true;

  public canEnterStep1Forwards = true;
  public canEnterStep1BackWard = true;

  public canEnterStep3Forwards = false;
  public canEnterStep3Backwards = true;

  public canEnterStep4Forwards = false;
  public canEnterStep4Backwards = true;

  egnpiAmt: number;
  contractRefNo: string;
  versionNo: string;
  description: string;
  protectionYear: string;
  contractType: string;
  xolType: string;
  showContractForm = true;
  layerAction: string;

  minPremium: number = 0;
  depPrem: number = 0;
  action;
  showLayerForm = false;
  themeColor: any;
  adjustRate: number;
  prem: number;
  depPremPerc: number;

  ngOnInit() {
    if (this.session.get("themeColor")) {
      this.themeColor = this.session.get("themeColor").split('-');
      this.themeColor = this.themeColor[0];
    }
    this.action = this.treatyService.getParamValue('action');
    this.contractRefNo = this.treatyService.getParamValue('refNo');
    this.versionNo = this.treatyService.getParamValue('amendNo');
    this.seqNo = this.treatyService.getParamValue('seqNo');
    // this.contrctType =this.treatyService.getParamValue('contractType');
    this.contType = this.treatyService.getParamValue('type');
    this.wizards = [
      { displayText: 'Contract Info', displayValue: 'Step1' }
    ];
    this.amndSrNo = this.treatyService.getParamValue('amendSrNo');
    this.amndSrNo = (this.amndSrNo == undefined) ? 0 : this.amndSrNo;

    if ('FX' === this.contType) {
      // this.egnpiLabel="GNPI";
      this.wizards.push({ displayText: 'GNPI', displayValue: 'Step2' });
      this.wizards.push({ displayText: 'Layer', displayValue: 'Step3' });
      this.wizards.push({ displayText: 'Summary', displayValue: 'Step4' });
    } else if ('TP' === this.contType) {
      // this.wizards.push({ displayText: 'EPI', displayValue: 'Step2' });
      this.wizards.push({ displayText: 'Applicable Companies', displayValue: 'Step2' });
      this.wizards.push({ displayText: 'Treaty Type & Reinsurer', displayValue: 'Step3' });
    } else {
      this.wizards.push({ displayText: 'EGNPI', displayValue: 'Step2' });
      this.wizards.push({ displayText: 'Limit & Reinsurer', displayValue: 'Step3' });
      this.wizards.push({ displayText: 'Summary', displayValue: 'Step4' });
    }
    this.currentWizard = 'Step1';
    this.wizardHelper.context = this;
    this.wizardHelper.next = this.onNext;
    this.wizardHelper.previous = this.onPrevious;
    this.wizardHelper.finish = this.onFinish;

    if ('TP' == this.contType) {
      this.reteriveTrustFundList();
      this.enableTermsModal = true;
    }
    this.selectForm = this.fb.group({
      selectperil: [this.selectedItems],
      peril: "",
      tpLimit: "",
      tpDeductible: "",
      tpMaxRec: ""
    });
    this.perilCols = [
      {
        headerName: "Perils",
        field: "perilDesc",
        tooltipField: 'perilDesc', sortable: true,
        // valueFormatter: function (params) {
        //   let paramStrings1 = params.data.tpPeril + "-" + params.data.perilDesc;
        //   return paramStrings1;
        // },
      },
      {
        field: 'tpLimit',
        headerName: 'Limit',
        valueFormatter: currencyFormatter,
        sortable: true,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tpDeductible',
        headerName: 'Excess',
        valueFormatter: currencyFormatter,
        sortable: true,
        cellStyle: { textAlign: 'right' }
      },
      {
        field: 'tpMaxRec',
        headerName: 'Maximum Recoverable',
        valueFormatter: currencyFormatter,
        sortable: true,
        cellStyle: { textAlign: 'right' }
      },
      {
        headerName: 'Action',
<<<<<<< HEAD
        field: 'actions',
        template:
          ` <a>
          <i class="fa fa-file-pen fa-icon"  data-action-type="Edit"  title="Edit" aria-hidden="true"></i>
          &nbsp;
         <i class="fa fa-trash fa-icon"  data-action-type="Delete" style="font-size: 1.55em" title="Delete" aria-hidden="true"></i>
         </a>`,
        cellStyle: { textAlign: 'center' }
=======
        field: "tpPeril",
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },
    ]

  }

  onNext(): void {
    const currentIndex = this.wizards.findIndex(wizard => wizard.displayValue === this.currentWizard);
    if ((currentIndex >= 0) && (currentIndex < (this.wizards.length - 1))) {
      this.currentWizard = this.wizards[currentIndex + 1].displayValue;
      this.canEnterStep(currentIndex + 2, 'Forward');
    }
  }
  onPrevious(): void {
    const currentIndex = this.wizards.findIndex(wizard => wizard.displayValue === this.currentWizard);
    if ((currentIndex > 0) && (currentIndex < (this.wizards.length))) {
      this.currentWizard = this.wizards[currentIndex - 1].displayValue;
      this.canEnterStep(currentIndex, 'Backward');
    }
  }
  onFinish(): void {
    this.approve();
  }

  enterReinsInstl() {
    let obj = {
      refno: this.contractRefNo,
      amendNo: this.versionNo,
      userId: this.session.get('userId'),
      seqNo: this.seqNo
    }
    this.treatyService.retrieveReinstPro(obj).subscribe(resp => {
      this.showReinsurerPremium = false;
      setTimeout(() => {
        this.showReinsurerPremium = true;
      }, 300);
    }, error => {
      this.toastService.error(error.error.message);
    });
  }

  wizardSelectionChange(event) {
    this.currentWizard = event;
  }

  loadContractType(event) {
    this.treatyService.appCodesList(ApiUrls.CONTRACT_TYPE).subscribe(resp => {
      this.contractTypeList = resp.appcodeList;
      // this.selectScript();
      for (var i = 0; i < this.contractTypeList.length; i++) {
        this.type = this.contractTypeList[i].item_id
        if (this.type == event.thContractType) {
          this.typecontract = this.type;
          this.contractType = this.contractTypeList[i].item_text;
        }
      }
    })
  }

  loadXolType(event) {
    this.treatyService.appCodesList(ApiUrls.NON_PROPORTIONAL_TREATY_TYPE).subscribe(resp => {
      this.treatyType = resp.appcodeList;
      //  this.selectScript();
      for (var i = 0; i < this.treatyType.length; i++) {
        this.typexol = this.treatyType[i].item_id
        if (this.typexol == event.thXlType) {
          this.xolType = this.treatyType[i].item_text;
          this.xolTypeId = this.treatyType[i].item_id;
        }
      }
    });
  }

  retrieveSavedData(event) {
    this.contractData = event
    this.contractFormType = event.thContractType;
    if (event == "error") {
      this.canEnterStep2Backwards = false;
      this.canEnterStep2Forwards = false;
      this.showContractForm = true;
      this.showPerilEgnp = false;
    } else {
      this.canEnterStep2Forwards = true;
      this.canEnterStep2Backwards = true;
      this.contractRefNo = event.ttyHdrPK.thRefNo;
      this.versionNo = event.ttyHdrPK.thAmendNo;
      this.description = event.thTtyDesc;
      this.protectionYear = event.thUwYear;
      this.basecurr = event.thCurr;
      this.xolTypeId = event.thXlType
      this.showPerilEgnp = true;
      this.loadContractType(event);
      this.loadXolType(event);

    }
  }

  layerEvent(event) {
    console.log(event);
    
    if (event == "error") {
      this.canEnterStep4Backwards = false;
      this.canEnterStep4Forwards = false;
    } else {
      this.layerAction = 'edit';
      this.canEnterStep4Backwards = true;
      this.canEnterStep4Forwards = true;
      this.minPremium = event.minPremium;
      this.depPrem = event.depPrem;
      this.adjustRate = event.adjustRate;
      this.prem = event.prem;
      this.depPremPerc = event.depPremPerc
      this.layerLimitCurr = event.tlLimitCurr;
      this.layerPremCurr = event.tlPremCurr;
      this.tlRateType = event.tlRateType;
      this.tlDesc = event.tlDesc;
      this.tlDeductible = event.tlDeductible;
      this.tlAad = event.tlAad;
      this.tlMaxRec = event.tlMaxRec;
      this.reinsure = true;
      this.tlLimit = event.tlLimit;
      this.tlPriority = event.tlPriority;
      this.LayerData = event;
      this.selectForm.patchValue({
        tpLimit: this.tlLimit,
        tpDeductible: this.tlDeductible,
        tpMaxRec: this.tlMaxRec,
      });
<<<<<<< HEAD
      console.log("Rate Type" + this.tlRateType);
=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }
  tabswitch(e) {
    if (!e || !e.heading) {
      return;
    }
    if (e.heading === 'Currencies') {
      this.showReinsurer = true;
      this.currency = true;
      this.Perildiv = false;
      this.reinsure = false;
      this.showPerilFrm = false;
      this.selectForm.reset();
    } else if (e.heading === 'Perils') {
      this.showReinsurer = true;
      this.Perildiv = true;
      this.currency = false;
      this.reinsure = false;
      if (this.contType !== 'TP') {
        this.getPerilDetails(this.layerId);
      }
    } else {
      this.showReinsurer = true;
      this.reinsure = true;
      this.Perildiv = false;
      this.currency = false;
      this.showPerilFrm = false;
      this.selectForm.reset();
    }
  }
  sendLayerHeading(event) {
    if (event && "0" != event) {
      this.layerId = event;
      this.showReinsurer = false;
      setTimeout(() => {
        this.showReinsurer = true;
        if (this.contType == 'TP') {
          this.showLayerType = true;
          this.enableTermsModal = true;
          this.showTrustFund = false;
          this.reteriveTrustFundList()
        } else if (this.contType == 'TX') {
          this.getPerilDetails(this.layerId);
        }
      }, 300);
    } else {
      this.showReinsurer = false;
    }
  }
  sendLayer(event) {
    this.layerPriority = event;
  }
  approve() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.contractRefNo,
      amendNo: this.versionNo,
      userId: this.session.get('userId'),
      divn: this.session.get('userDivnCode'),
      dept: this.session.get('userDeptCode'),
      company: this.session.get('companyCode'),
      seqNo: this.seqNo
    }
    this.treatyService.approveContract(obj, this.amndSrNo).subscribe(resp => {
      this.toastService.success(obj.refNo + "Approved Successfully");
      this.modalService.hide();
      this.showPrintBtn = true;
      this.action = 'view';
      this.showAproveBtn = false
      this.loaderService.isBusy = false;

    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
    })
  }


  canEnterStep(step: any, direction: string) {
    switch (step.toString()) {
      case '1': {
        if (direction === 'Forward') {
          this.showPerilEgnp = true;
        } else {
          this.action = "edit";
          this.showContractForm = true;
        }
        break;
      }
      case '2': {
        if (direction === 'Forward') {
          if (this.canEnterStep2Forwards) {
            this.showContractForm = false;
          }
          if (this.contType === 'TP') {
            this.showLayerForm = false;
            this.showLayerType = true;
            this.showReinsurer = true;
          } else {
            this.showLayerForm = true;
            this.showLayerType = false;
          }
        } else {
          this.showContractForm = true;
          this.showPerilEgnp = true;
          this.showReinsurer = false;
          this.reinsure = false;
          // this.showLayerForm=false;
          if (this.contType === 'TP') {
            this.showLayerForm = false;
            this.showLayerType = true;
          } else {
            this.showLayerForm = true;
            this.showLayerType = false;
          }
        }
        break;
      }
      case '3': {
        if (direction === 'Forward') {
          this.layerAction = 'add';
          if (this.contType === 'TP') {
            this.showLayerForm = false;
            this.showLayerType = true;
          } else {
            this.showLayerForm = true;
            this.showLayerType = false;
          }
          this.showPerilEgnp = false;
        } else {
          // this.showLayerForm = true;
          // this.action="edit";
          if (this.contType === 'TP') {
            this.showLayerForm = false;
            this.showLayerType = true;
          } else {
            this.showLayerForm = true;
            this.showLayerType = false;
          }
          this.showReinsurer = true;
          this.reinsure = true;
          this.layerAction = 'edit';
          return this.canEnterStep3Backwards;
        }
        break;
      }
      case '4': {
        if (direction === 'Forward') {
          if (this.canEnterStep4Forwards) {
            this.enterReinsInstl();
            this.showReinsurerPremium = true;
            this.showReinsurer = false;
            this.reinsure = false;
          }
        } else {
          this.showLayerForm = true;
          return this.canEnterStep4Backwards;
        }
      }
    }
  }

  getEgnpiAmt(event) {
    //alert("egnpi"+event);
    this.egnpiAmt = event //this.cpipe.transform(event);   
    if (this.egnpiAmt > 0) {
      this.canEnterStep3Forwards = true;
    } else {
      this.canEnterStep3Forwards = false;
    }
  }

  printDocument() {

    var params = {
      refNo: this.contractRefNo,
      amendNo: this.versionNo,
      compCode: this.session.get("companyCode"),
      repId: 'RI_SCH_001',
      docType: 'DEP_PREM',
      seqNo: this.seqNo
    }
    this.treatyService.fetchReportUrl(params)
      .subscribe(result => {
        var url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
         width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(url, 'Reports', param);

      });

  }
  addPeril() {
    // alert(this.contractType + this.contType)
    this.loaderService.isBusy = true;
    this.selectForm.patchValue({
      tpLimit: this.LayerData.tlLimit,
      tpDeductible: this.tlDeductible,
      tpMaxRec: this.tlMaxRec
    });
    if (!this.layerId) {
<<<<<<< HEAD
=======
      this.loaderService.isBusy = false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.toastService.warning('Please Select the layer');
      return false;
    }
    this.action = 'Add';
    this.showPerilFrm = true;
    if (this.contType == 'FX') {
      this.treatyService.facXolPerilDropdown(this.contractRefNo).subscribe(resp => {
        this.loaderService.isBusy = false;
        this.dropdownList = resp.riskList;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.warning("Error in Retrieving Peril " + error);
      })
    } else {
      this.dropdown();
    }
  }
  dropdown() {
    this.treatyService.perilCodesList(ApiUrls.APP_PERIL_TYPE, this.contractRefNo, this.layerId, this.versionNo, this.seqNo).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.dropdownList = resp.appcodeList;
<<<<<<< HEAD
      //this.selectScript();
    });
  }
  // selectScript() {

  //   $('.selectpicker').selectpicker();
  //   setTimeout(()  =>  {
  //     $('.selectpicker').selectpicker('refresh');
  //   },  500);
  // }
  onItemSelect(item: any) {

    this.perilItem.push(item);
  }
  onSelectAll(items: any) {
    for (var i = 0; i < items.length; i++) {
      //  this.perilItem.push(items[i].item_id)
      this.perilItem.push(items[i]);
    }
  }

  onDeSelect(items: any) {
    for (var i = 0; i < this.perilItem.length; i++) {
      if (this.perilItem[i].item_id === items.item_id) {
        this.perilItem.splice(i, 1);
      }
=======
    });
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  savePerils(layerNo) {
    this.loaderService.isBusy = true;
    var limit = this.selectForm.get('tpLimit').value ? this.selectForm.get('tpLimit').value.toString().replace(/,/g, '') : 0;
    var deductible = this.selectForm.get('tpDeductible').value ? this.selectForm.get('tpDeductible').value.toString().replace(/,/g, '') : 0;
    var maxRec = this.selectForm.get('tpMaxRec').value ? this.selectForm.get('tpMaxRec').value.toString().replace(/,/g, '') : 0;
    let param = {
      tpRefNo: this.contractRefNo,
      tpSeqNo: this.seqNo,
      tpAmendNo: this.versionNo,
      tpLayer: layerNo,
      tpPeril: ""
    }
    let obj = {
      perilList: this.perilItem,
      tpStatus: "A",
      tpCrUid: this.session.get('userId'),
      tpCrDt: new Date(),
      tpLimit: limit,
      tpDeductible: deductible,
      tpMaxRec: maxRec,
      mttyPerilPK: param

    }
    if (this.perilItem && this.perilItem.length == 0) {
      this.toastService.warning("Select atleast one Peril");
      this.loaderService.isBusy = false;
    } else {
      this.treatyService.savePerilDetails(obj, this.amndSrNo).subscribe(resp => {
        if (resp["messageType"] && resp["messageType"] == 'E') {
          this.toastService.error(resp["message"]);
        } else if (resp["messageType"] && resp["messageType"] == 'S') {
          this.toastService.success(resp["message"]);
          this.showPerilFrm = false;
          this.getPerilDetails(layerNo);
          this.perilItem = [];
        }
        this.loaderService.isBusy = false;
        //this.toastService.success("Successfully Saved");     
        // this.selectForm.get('peril-select').setValue([]);
        //this.toastService.success("Saved in saving Peril");
      }, error => {
        this.toastService.error("Error in saving Peril");
        this.loaderService.isBusy = false;
      })
    }
  }

  deletePerilDetails() {
    this.loaderService.isBusy = true;
    this.treatyService.deletePerilById(this.deletePeril.tpRefNo, this.deletePeril.tpPeril, this.deletePeril.tpAmendNo, this.deletePeril.tpLayer, this.deletePeril.tpSeqNo, this.amndSrNo).subscribe(resp => {
<<<<<<< HEAD
      // let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
      // element.click();
      this.getPerilDetails(this.layerId);
      this.loaderService.isBusy = false;
      this.modalService.hide();
=======
      this.getPerilDetails(this.layerId);
      this.loaderService.isBusy = false;
      this.modalService.hide();
      this.back();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.toastService.success("Deleted Peril");
    }, error => {
      this.toastService.error(error.error.message);
      this.loaderService.isBusy = false;
      this.modalService.hide();
    })
  }
  getPerilDetails(layerNo) {
    this.loaderService.isBusy = true;
    this.treatyService.getSelectedPerilList(layerNo, this.contractRefNo, this.versionNo, this.seqNo).subscribe(resp => {
<<<<<<< HEAD
      this.perilDetails = resp.perilList;
      this.rowData = resp.perilList
=======
      this.perilDetails = resp;
      this.rowData = resp;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }

  editPeril(data) {
    this.perilData = data;
    this.action = "Edit";
    this.showPerilFrm = true;
    this.selectForm.patchValue({
      peril: data.tpPeril + "-" + data.perilDesc,
      tpLimit: data.tpLimit,
      tpDeductible: data.tpDeductible,
      tpMaxRec: data.tpMaxRec
    });
  }

  updatePeril(layerId) {
    // this.perilData.tpLimit = this.selectForm.get('tpLimit').value ? this.selectForm.get('tpLimit').value.toString().replace(/,/g, '') : 0;
    // this.perilData.tpDeductible = this.selectForm.get('tpDeductible').value ? this.selectForm.get('tpDeductible').value.toString().replace(/,/g, '') : 0;
    // this.perilData.tpMaxRec = this.selectForm.get('tpMaxRec').value ? this.selectForm.get('tpMaxRec').value.toString().replace(/,/g, '') : 0;
    var limit = this.selectForm.get('tpLimit').value ? this.selectForm.get('tpLimit').value.toString().replace(/,/g, '') : 0;
    var deductible = this.selectForm.get('tpDeductible').value ? this.selectForm.get('tpDeductible').value.toString().replace(/,/g, '') : 0;
    var maxRec = this.selectForm.get('tpMaxRec').value ? this.selectForm.get('tpMaxRec').value.toString().replace(/,/g, '') : 0;
    this.perilData.tpUpdUid = this.session.get('userId');
    let param = {
      tpRefNo: this.contractRefNo,
      tpSeqNo: this.seqNo,
      tpAmendNo: this.versionNo,
      tpLayer: layerId,
      tpPeril: this.perilData.tpPeril
    }
    let obj = {
      perilList: this.perilItem,
      tpStatus: "A",
      tpUpdUid: this.session.get('userId'),
      //tpUpdDt: new Date(),
      tpCrUid: this.session.get('userId'),
      tpCrDt: new Date(),
      tpLimit: limit,
      tpDeductible: deductible,
      tpMaxRec: maxRec,
      perilDesc: this.perilData.perilDesc,
      mttyPerilPK: param

    }
    this.treatyService.updatedPeril(this.perilData.tpPeril, obj, this.amndSrNo).subscribe(resp => {
      this.toastService.success("Peril Updated Sucessfully");
      this.selectForm.reset();
      this.showPerilFrm = false;
      this.getPerilDetails(layerId);
    }, error => {
      this.toastService.error(error.error.message);
    });
  }

  back() {
    this.showPerilFrm = false;
    this.selectForm.reset();
  }
  showDialogbox() {
    this.open(this.confirmcontent, 'modal-sm');
<<<<<<< HEAD
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
=======
    this.showPerilFrm = false;
  }
  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  reteriveTrustFundList() {
    this.treatyService.appCodesList(ApiUrls.FUND_CODE).subscribe(resp => {
      this.trustFund = resp.appcodeList;
    })
  }

  reteriveRiskLlyods() {
    this.treatyService.appCodesList(ApiUrls.RISK_LLY).subscribe(resp => {
      this.riskLlyods = resp.appcodeList;
      this.showTrustFund = true;
    })
  }

  onPerilGridReady(params) {
    this.gridApiPerils = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApiPerils.sizeColumnsToFit();
  }

  displayedRowCount() {
    if (this.gridApiPerils) {
      return this.gridApiPerils.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTablePerils").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Delete":
<<<<<<< HEAD
          this.deletePeril = data.mttyPerilPK;
=======
          this.deletePeril = data;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          return this.showDialogbox();
        case "Edit":
          return this.editPeril(data);
      }
    }

  }
  onQuickFilterChanged() {
    this.gridApiPerils.setQuickFilter(this.quickSearchValue);
  }
  onBtExport() {
    if (this.gridApiPerils) {
      this.gridApiPerils.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApiPerils.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApiPerils.paginationSetPageSize(this.showEntriesOptionSelectedPerils);
    this.gridApiPerils.paginationGoToPage(0);
  }

  nextStep() {
    this.wizardHelper.goNext();
  }
  previousStep() {
    this.wizardHelper.goPrevious();
  }

  getGnpiData(event) {
    this.facGnpiData = event;
  }

  contractApplPolicy(data) {
    this.ApplPolicyData = data;
  }
  closeModal() {
    this.modalService.hide();
  }
}
function currencyFormatter(params) {
  if (params.value) {
    return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');//Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  } else {
    return Number(0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-file-pen fa-icon" data-action-type="Edit" title="Edit" aria-hidden="true"></i>
    &nbsp;
   <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
   </a>`;
  }
}
