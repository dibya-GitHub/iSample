<<<<<<< HEAD
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
=======
import { Component, OnInit } from '@angular/core';
import { ElementRef } from '@angular/core';
import { ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { SessionStorageService } from 'angular-web-storage';
import { Inject } from '@angular/core';
import { ToastService } from 'src/app/services/toast.service';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';


@Component({
  selector: 'app-view-doc',
  templateUrl: './treaty-view-doc.component.html',
  styleUrls: ['./treaty-view-doc.component.css']
})
export class TreatyViewDocComponent implements OnInit {
  tableFlag: boolean;
  type: any;
  refNo: any;
  isImageLoading: boolean;
  cols: any[];
  docList: any;

  amndNo: any;
  imageToShow: any;

  filename = [];

  @ViewChild('content') content: ElementRef;

  constructor(
    private modalService: BsModalService,
    private treatyService: TreatyService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private session: SessionStorageService,
  ) { }

  ngOnInit() {

    this.cols = [
      // { field: 'tdiDocType', header: 'Doc-Type'},
      { field: 'tdiDocName', header: 'Doc-Name' },
      { field: 'tdiFileExtn', header: 'File Extsn' },
      { field: 'Action', header: 'Action' }
    ];

  }
  toggleModal(refNo, amndNo, type) {
    this.refNo = refNo;
    this.amndNo = amndNo;
    this.type = type;
    this.open(this.content);
    this.viewDoc(this.refNo, this.amndNo, this.type);
    // this.viewDoc();
  }

  open(content) {
<<<<<<< HEAD
    this.modalService.show(content, { class: 'modal-lg' });
=======
    this.modalService.show(content, { class: 'modal-lg' });    
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  viewDoc(refNo, amndNo, type) {
    this.loaderService.isBusy = true;
    this.treatyService.fetchDocument(this.refNo, this.amndNo, type).subscribe(resp => {
      this.docList = resp.documentList;
      this.scriptcall('view-doc');
      this.loaderService.isBusy = false;
    }, error => { this.loaderService.isBusy = false; });
  }

  scriptcall(id) {
    // $('#'+id).DataTable().destroy();
    // setTimeout(() => {
    //   $('#'+id).DataTable().draw();
    // }, 500);
  }
  openDoc(detail) {
    this.treatyService.openDocument(detail);
    // this.toastService.add({ severity: 'success', summary: "Uploaded Successfully.", detail: '' });
  }


  deletedoc(detail) {
    this.loaderService.isBusy = true;
    this.treatyService.fetchDocument(this.refNo, this.amndNo, this.type).subscribe(resp => {
      this.docList = resp.documentList;
      this.scriptcall('view-doc');
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    });
  }



  readUrl(refNo, amndNo, type, event) {
    this.tableFlag = true;

    this.refNo = refNo;
    this.amndNo = amndNo;
    if (type == 'contract') {
      this.type = "XL-CON";
    } else if (type == 'adjustment') {
      this.type = "XL-ADJ";
    } else if (type == 'recovery') {
      this.type = "XL-REC";
    }

    this.loaderService.isBusy = true;
    // let file: File =e.dataTransfer ? e.dataTransfer.files[0] :e.target.files[0]; 
    let formData: FormData = new FormData();
    for (var i = 0; i < event.target.files.length; i++) {
      this.filename.push(event.target.files[i]);
      if (parseInt(this.filename[i].size) >= 1048576) {
        this.toastService.warning("File should be within 1mb");
        return false;
      }
    }

    for (var i = 0; i < this.filename.length; i++) {
      formData.append("files", this.filename[i], this.filename[i].name);
    }

    // formData.append('file', file, file.name);
    formData.append('tdiRefNo', this.refNo);
    // formData.append('tdiAmendNo','0');
    formData.append('doctype', this.type);
    formData.append('userId', this.session.get("userId"));
    var uploadDocumentReponse = this.treatyService.uploadDoc(formData);
    // this.upload = uploadDocumentReponse._isScalar ;


    this.treatyService.fetchDocument(this.refNo, this.amndNo, type).subscribe(resp => {
      this.docList = resp.documentList;
      this.scriptcall('view-doc');

    }, error => { });


    this.loaderService.isBusy = false;

  }

  file(event) {
    for (var i = 0; i < event.target.files.length; i++) {
      this.filename.push(event.target.files[i]);
    }
  }

}

