import { ICellRendererAngularComp } from '@ag-grid-community/angular';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { TreatyService } from 'src/app/shared/services/treaty.service';

@Component({
  selector: 'app-ag-dropdwon',
  template: `<div >
  <select (change)="myFunction(ref.value)" [ngModel]="selectedValue" #ref>
  <option value="" selected>Select</option>
  <option *ngFor='let k of llyRegionList' value={{k.key}}>{{k.value}}</option>
</select>

</div>`,
  styleUrls: ['./ag-dropdwon.component.css']
})
export class AgDropdwonComponent implements ICellRendererAngularComp {
  llyRegionList: any[];
  @Input()
  selectedValue: any;
  @Output()
  selectedValueChanged = new EventEmitter<any>();
  data: any;
  public params: any;
  bindingProp: string;
  constructor(private treatyservice: TreatyService) {

  }
  agInit(params: any): void {
    this.params = params;
    this.llyRegionList = params.colDef.val;
    this.data = params.data;
    this.selectedValue = (this.data.mttyTrustFundPK) ? this.data.mttyTrustFundPK.tfFundCode : undefined;
    //this.reteriveSrpRegionList();
  }

  public invokeParentMethod() {
    this.params.context.componentParent.loadvalue(this.params)
  }

  /*reteriveSrpRegionList(){
    this.treatyservice.appCodesList(ApiUrls.FUND_CODE).subscribe(resp=>{
    this.llyRegionList=resp.appcodeList;
  //this.ngAfterViewInit();
    })
  }*/



  refresh(): boolean {
    return false;
  }
  public myFunction(val: any) {
    // this.params.context.componentParent.selectedRowData(val)
    // this.selectedValue = val;
    //this.data = 
    this.selectedValueChanged.emit(this.data)
  }
}
