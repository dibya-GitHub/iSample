import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgDropdwonComponent } from './ag-dropdwon.component';

describe('AgDropdwonComponent', () => {
  let component: AgDropdwonComponent;
  let fixture: ComponentFixture<AgDropdwonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgDropdwonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgDropdwonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
