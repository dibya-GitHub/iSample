import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyViewAccountingComponent } from './treaty-view-accounting.component';

describe('TreatyViewAccountingComponent', () => {
  let component: TreatyViewAccountingComponent;
  let fixture: ComponentFixture<TreatyViewAccountingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyViewAccountingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyViewAccountingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
