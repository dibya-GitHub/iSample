<<<<<<< HEAD
import { Component, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Utils } from 'src/app/modules/premium-bordereaux/utils';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
// import { AngularEditorConfig } from '@kolkov/angular-editor';
=======
import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, AbstractControl, UntypedFormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { SessionStorageService } from 'angular-web-storage';
import { ToastService } from 'src/app/services/toast.service';
import { LoaderService } from 'src/app/services/loader.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import * as moment from 'moment';
import { Utils } from 'src/app/utils';

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@Component({
  selector: 'inward-treaty-view-accounting',
  templateUrl: './treaty-view-accounting.component.html',
  styleUrls: ['./treaty-view-accounting.component.scss']
})
export class TreatyViewAccountingComponent implements OnInit {
  private gridApi;
  quickSearchValue: string = '';
  showEntriesOptions = [10, 20, 50, 100];
  showEntriesOptionSelected = 10;
  public gridOptions;
  public defaultColDef;
  private gridColumnApi;
  columnDefs = [];
  public components;
  public context;
  public frameworkComponents;
  public getRowHeight;
  public getRowStyle;
  baseCurrency
  accEntryList: any = [];
  headerData: any;
  docNo;
  refNo;
  tranNo;
  docType;
  selectedArray = [];
  seqNo: string;
  mailReplyForm: UntypedFormGroup;
  appStatus;
  summaryHeaderForm: UntypedFormGroup
  reportParam: any[];
<<<<<<< HEAD
  amendNo;
  transId;
  // editorConfig: AngularEditorConfig;
  urls = [];
  showTranID: boolean = false;
  tranSrNo;
=======
  amendNo:any;
  transId;
  urls = [];
  showTranID: boolean = false;
  tranSrNo;
  batchId;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  hideQSColumn: any = false;
  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private loaderService: LoaderService,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private session: SessionStorageService,
    private toastService: ToastService,
    private treatyService: TreatyService,
  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.baseCurrency = sessionStorage.getItem('baseCurrency');
    this.baseCurrency = this.baseCurrency.slice(1, -1);
    this.activatedRoute.queryParams.subscribe(params => {
      this.refNo = params['refNo'];
      this.transId = params['transId'];
      this.tranSrNo = params['tranSrNo']
      this.seqNo = params['seqNo'];
      this.docType = params['docType'];
<<<<<<< HEAD
      this.amendNo = params['amendNo']
=======
      this.amendNo = params['amendNo'];
      this.batchId = params['batchId']
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    });
    this.createSummaryHeaderForm();
  }

<<<<<<< HEAD
  ngOnInit() {
    this.loaderService.isBusy = true;
    this.columnDefsFn();
    this.getAllData();
    this.createMailReplyModal();
=======
  ngOnInit() {        
    this.columnDefsFn();
    this.getAllData();
    this.createMailReplyModal();    
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  transactionType: any
  showTrantypeDropdown: boolean = true;
  tranType: '';
  createdBy: any;
  getAllData() {
    if (this.docType === "DEP_PREM") {
      this.loaderService.isBusy = true;
      this.transactionType = "Deposit Premium"
      this.showTranID = false;
      this.treatyService.viewXOLAccoutingHeader(this.refNo, this.seqNo, this.amendNo, this.docType).subscribe(res => {
        //this.loaderService.isBusy = false;
        this.headerData = res;
        if (this.headerData.created_by && this.headerData.created_by != "null") {
          this.createdBy = this.headerData.created_by;
        } else {
          this.createdBy = '';
        }

        if (this.headerData && this.headerData.created_date) {
          this.headerData.created_date = moment(this.headerData.created_date).format('DD/MM/YYYY');
        } else if (this.headerData) {
          this.headerData.created_date = undefined;
        }
        //this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
      this.treatyService.viewXOLAccoutingDetails(this.refNo, this.seqNo, this.docType).subscribe(res => {
        this.accEntryList = res;
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    } else if (this.docType === "XL_REC") { //viewRecAccoutingHeader
      this.loaderService.isBusy = true;
      this.showTranID = true;
      this.docTypeDropdown(this.transId, this.tranSrNo)
      this.summaryHeaderForm.patchValue({ transType: 'All' })
      this.showTrantypeDropdown = false;
      this.treatyService.viewRecAccoutingHeader(this.transId, this.tranSrNo).subscribe(res => {
<<<<<<< HEAD
        //this.loaderService.isBusy = true;
=======
        //this.loaderService.isBusy = false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.headerData = res;
        if (this.headerData.created_by && this.headerData.created_by != "null") {
          this.createdBy = this.headerData.created_by;
        } else {
          this.createdBy = '';
        }
        if (this.headerData && this.headerData.created_date) {
          this.headerData.created_date = moment(this.headerData.created_date).format('DD/MM/YYYY');
        } else if (this.headerData) {
          this.headerData.created_date = undefined;
        }
        //this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
      this.treatyService.viewRecAccoutingDetails(this.transId, this.tranSrNo, 'All').subscribe(res => {
        this.loaderService.isBusy = false;
        this.accEntryList = res;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
<<<<<<< HEAD
=======
    } else if (this.docType == 'QS_ACNT') { 
      this.loaderService.isBusy = true;
      this.showTranID = false;
      this.treatyService.viewXOLAccoutingHeader(this.refNo, this.seqNo, this.amendNo, this.docType).subscribe(res => {
        //this.loaderService.isBusy = false;
        this.headerData = res;
        if (this.headerData.created_by && this.headerData.created_by != "null") {
          this.createdBy = this.headerData.created_by;
        } else {
          this.createdBy = '';
        }
        if (this.headerData && this.headerData.created_date) {
          this.headerData.created_date = moment(this.headerData.created_date).format('DD/MM/YYYY');
        } else if (this.headerData) {
          this.headerData.created_date = undefined;
        }
        //this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
      this.treatyService.viewAdjAccoutingDetailsByBatchId(this.docType,this.batchId).subscribe(res => {
        this.loaderService.isBusy = false;
        this.accEntryList = res;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    } else {
      this.loaderService.isBusy = true;
      this.showTranID = false;
      this.treatyService.viewXOLAccoutingHeader(this.refNo, this.seqNo, this.amendNo, this.docType).subscribe(res => {
<<<<<<< HEAD
        //this.loaderService.isBusy = true;
=======
        //this.loaderService.isBusy = false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        this.headerData = res;
        if (this.headerData.created_by && this.headerData.created_by != "null") {
          this.createdBy = this.headerData.created_by;
        } else {
          this.createdBy = '';
        }
        if (this.headerData && this.headerData.created_date) {
          this.headerData.created_date = moment(this.headerData.created_date).format('DD/MM/YYYY');
        } else if (this.headerData) {
          this.headerData.created_date = undefined;
        }
        //this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
      this.treatyService.viewAdjAccoutingDetails(this.refNo, this.docType).subscribe(res => {
        this.loaderService.isBusy = false;
        this.accEntryList = res;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    }
    /*  if (this.docType === "DEP_PREM_ADJ") {
       this.transactionType = "Adjustment of Deposit Premium" 
     } else if (this.docType === "REINST_ADJ"){
       this.transactionType = "Adjustment of Reinstatement Premium"
     }else if (this.docType === "NCB"){
       this.transactionType = "NCB"
     } */
  }

  columnDefsFn() {
    this.columnDefs = [
      {
        headerName: "Contract Ref No",
        headerTooltip: 'Contract Ref No',
        field: "adTtyRefNo",
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.adTtyRefNo && params.data.adTtySeqNo && params.data.adTtyAmendNo != null) {
            return params.data.adTtyRefNo + ' / ' + params.data.adTtySeqNo + ' / ' + params.data.adTtyAmendNo;
          } else if (params.data && params.data.adTtyRefNo && params.data.adTtySeqNo == null && params.data.adTtyAmendNo != null) {
            return params.data.adTtyRefNo + ' / ' + params.data.adTtyAmendNo;
          } else {
            return "";
          }
        },
      },
      {
        headerName: "Trans ID",
        headerTooltip: 'Trans ID',
        field: "adTransId",
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.adTransId && params.data.adTranSrNo != null) {
            return params.data.adTransId + ' / ' + params.data.adTranSrNo;
          } else if (params.data && params.data.adTransId && params.data.adTranSrNo == null) {
            return params.data.adTransId;
          } else if (params.data && params.data.adTransId && params.data.adTransId != null && params.data.adTranSrNo != null) {
            return params.data.adTransId;
          } else {
            return '';
          }
        },
      },
      {
        headerName: "Customer",
        headerTooltip: "Customer",
        field: "adCustCodeDesc",
        tooltipField: 'adCustCodeDesc',
        cellRenderer: tooltipRenderer,
      },
      {
        headerName: "Doc Date",
        headerTooltip: "Doc Date",
        field: "adDocDt",
        // valueFormatter: Utils.dateFormatter,
        valueGetter: function (params) {
          if (params.data && params.data.adDocDt) {
<<<<<<< HEAD
            return Utils.formatMilliSecToDate(parseInt(params.data.adDocDt));
=======
            return moment(params.data.adDocDt).format('DD/MM/YYYY');//Utils.formatMilliSecToDate(parseInt(params.data.adDocDt));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          } else {
            return '' ;
          }
        },
        cellRenderer: tooltipRenderer,
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },
      {
        headerName: "Doc No",
        headerTooltip: "Doc No",
        field: "adDocNo",
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.adTranCode && params.data.adDocNo) {
            return params.data.adTranCode + ' - ' + params.data.adDocNo;
          } else {
            return "";
          }
        },
      },
      {
        field: "adDivnCode",
        headerName: "Division",
        headerTooltip: "Division",
        tooltipField: 'adDivnCode',
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.adDivnCode && params.data.adDivnCodeDesc) {
            return params.data.adDivnCode + ' - ' + params.data.adDivnCodeDesc;
          } else if (params.data && params.data.adDivnCode && params.data.adDivnCodeDesc == null) {
            return params.data.adDivnCode;
          } else {
            return "";
          }
        },
      },
      // {
      //   headerName: "Lob",
      //   headerTooltip: "Lob",
      //   field: "adlobCode",
      //   tooltipField: 'adlobCode',
      //   valueGetter: function (params) {
      //     if (params.data && params.data.adlobCode && params.data.adLobCodeDesc) {
      //       return params.data.adlobCode + ' - ' + params.data.adLobCodeDesc;
      //     } else if (params.data && params.data.adlobCode && params.data.adLobCodeDesc == null) {
      //       return params.data.adlobCode;
      //     } else {
      //       return "";
      //     }
      //   },
      // },
      
      {
        headerName: "Dr/Cr",
        headerTooltip: "Dr Cr",
        field: "adDrcrFlag",
        valueGetter: function (params) {
          if (params.data && params.data.adDrcrFlag && params.data.adDrcrFlag == 'D') {
            return 'Dr';
          } else if (params.data && params.data.adDrcrFlag && params.data.adDrcrFlag == 'C') {
            return 'Cr';
          } else {
            return '';
          }
        },
        cellRenderer: tooltipRenderer,
      },
      {
        headerName: "Currency",
        headerTooltip: "Currency",
        field: "adCurrCode",
        cellRenderer: tooltipRenderer,      
      },
      {
        headerName: "Amount (FC)",
        headerTooltip: "Amount (FC)",
        field: "adAmtFc",
        cellStyle: { textAlign: 'right' },
        cellRenderer: tooltipRenderer,
        //valueFormatter: Utils.currencyDecimalFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.adAmtFc) {            
<<<<<<< HEAD
            return Number(params.data.adAmtFc).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
=======
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.adAmtFc));
          } else {
            return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          }
        },
        filter: true,
      },
      {
        headerName: "Amount (LC)",
        headerTooltip: "Amount (LC)",
        field: "adAmtLc1",
        cellStyle: { textAlign: 'right' },
        cellRenderer: tooltipRenderer,
        //valueFormatter: Utils.currencyDecimalFormatter,
        valueGetter: function (params) {
          if(params.data && params.data.adAmtLc1) {            
<<<<<<< HEAD
            return Number(params.data.adAmtLc1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          } else {
            return '';
=======
            return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((params.data.adAmtLc1));
          } else {
            return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          }
        },
      },
      {
        headerName: "Main Account",
        headerTooltip: "Main Account",
        field: "adMainAcntCodeDesc",
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.adMainAcntCodeDesc && params.data.adMainAcntCodeDesc) {
            return params.data.adMainAcntCodeDesc;
          } else {
            return "";
          }
        },
      },
      {
        field: "adSubAcntCodeDesc",
        headerName: "Sub Account",
        headerTooltip: "Sub Account",
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params.data && params.data.adSubAcntCodeDesc && params.data.adSubAcntCodeDesc !== "null") {
            return params.data.adSubAcntCodeDesc;
          } else {
            return "";
          }
        },
        cellStyle: { textAlign: 'right' },
      },
      {
        headerName: "Narration",
        headerTooltip: "Narration",
        field: "adNarration",
        cellRenderer: tooltipRenderer,
        //tooltipField: 'adNarration'
      },
      {
        headerName: "Posted YN",
        headerTooltip: "Posted YN",
        field: "adPostYn",
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
<<<<<<< HEAD
          if (params.value === undefined || params.value === null) {
            return '';
          } else if (params.value && (params.value == "0" || params.value == "N")) {
            return 'No';
          } else if (params.value && (params.value == "1" || params.value == "Y")) {
            return 'Yes';
          } else {
            return params.value;
=======
          if (params.data && (params.data.adPostYn == "0" || params.data.adPostYn == "N")) {
            return 'No';
          } else if (params.data && (params.data.adPostYn == "1" || params.data.adPostYn == "Y")) {
            return 'Yes';
          } else {
            return '';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          }
        },
      },
      {
        headerName: "Due Date",
        headerTooltip: "Due Date",
        field: "adInstDueDt",
        cellRenderer: tooltipRenderer,
        valueGetter: function (params) {
          if (params && params.data && params.data.adInstDueDt) {
            return moment(params.data.adInstDueDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },
    ];
  }

  onGridSizeChanged(params) {
<<<<<<< HEAD
    var gridWidth = document.getElementById("accEntryListTable").offsetWidth;
=======
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
    if (this.docType == 'QS_ACNT') {
      this.hideQSColumn = true;
      params.columnApi.setColumnsVisible(['adInstDueDt'], false);
      params.columnApi.setColumnsVisible(['adPostYn'], false);
      params.api.sizeColumnsToFit();
    }
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onBtExport() {
    if (this.gridApi) {
<<<<<<< HEAD
      let columnKeys = ['adTtyRefNo', 'adTransId', 'adCustCodeDesc', 'adDocDt', 'adDocNo', 'adDivnCode', 'adlobCode', 'adCurrCode', 'adNarration', 'adDrcrFlag', 'adAmtFc', 'adAmtLc1', 'adMainAcntCodeDesc', 'adSubAcntCodeDesc', 'adPostYn', 'adInstDueDt'];
=======
      let columnKeys = ['adTtyRefNo', 'adTransId', 'adCustCodeDesc', 'adDocDt', 'adDocNo', 'adDivnCode', 'adlobCode', 'adDrcrFlag' , 'adCurrCode', 'adAmtFc', 'adAmtLc1', 'adMainAcntCodeDesc', 'adSubAcntCodeDesc', 'adNarration', 'adPostYn', 'adInstDueDt'];
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (this.hideQSColumn) {
        let index1 = columnKeys.indexOf('adPostYn');
        let index2 = columnKeys.indexOf('adInstDueDt');
        if (index1 > -1 || index2 > -1) {
          columnKeys.splice(index1, 1);
<<<<<<< HEAD
          columnKeys.splice(index2, 1);
=======
          columnKeys.splice(index2-1, 1);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        }
      }
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'viewAccounting.xlsx',
        skipHeader: false,
        sheetName: 'View Accounting',
        columnKeys: columnKeys,
        processCellCallback: (params) => {
<<<<<<< HEAD
          if (params.column.colId == "adDocDt") {
            return moment(params.value).format("DD/MM/YYYY");
          } else {
            return params.value;
          }
=======
         if (params.column.colId == "adAmtFc" || params.column.colId == "adAmtLc1"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }    
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
<<<<<<< HEAD
    this.gridApi.sizeColumnsToFit();

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  agGridOptions() {
    this.context = { componentParent: this };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }
  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }

  back() {
    if (this.docType === "DEP_PREM") {
      this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'home' } });
<<<<<<< HEAD
    } else if (this.docType === "QS_ACNT") {
      this.router.navigate(['/accounting/accounting-dashboard']);
    } else if (this.docType === "DEP_PREM_ADJ") {
      this.router.navigate(['/treaty/adjust-premium'], { queryParams: { 'refNo': this.refNo, 'transId': this.transId, 'seqNo': this.seqNo, 'amendNo': this.amendNo, docType: this.docType, title: 'viewAccounting' } });
    } else if (this.docType === "REINST_ADJ") {
      this.router.navigate(['/treaty/adjust-premium'], { queryParams: { 'refNo': this.refNo, 'transId': this.transId, 'seqNo': this.seqNo, 'amendNo': this.amendNo, docType: this.docType, title: 'viewAccountingReins' } });
=======
      return false;
    } else if (this.docType === "DEP_PREM_ADJ") {
      this.router.navigate(['/treaty/adjust-premium'], { queryParams: { 'refNo': this.refNo, 'transId': this.transId, 'seqNo': this.seqNo, 'amendNo': this.amendNo, docType: this.docType, title: 'viewAccounting' } });
      return false;
    } else if (this.docType === "REINST_ADJ") {
      this.router.navigate(['/treaty/adjust-premium'], { queryParams: { 'refNo': this.refNo, 'transId': this.transId, 'seqNo': this.seqNo, 'amendNo': this.amendNo, docType: this.docType, title: 'viewAccountingReins' } });
      return false;
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    } else if (this.docType === "NCB") {
      let title = 'No Claim Bonus';
      this.router.navigate(['/treaty/adjust-ncb'], { queryParams: { 'refNo': this.refNo, 'seqNo': this.seqNo, 'type': this.docType, 'title': title }, skipLocationChange: true });
      //this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'Home' } });
<<<<<<< HEAD
    } else {
      this.router.navigate(['/treaty/recovery'], { queryParams: { "action": 'view', 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'seqNo': this.seqNo }, skipLocationChange: false });
    }
=======
      return false;
    } if (this.docType === "CASH_ADV") {
      this.router.navigate(['/treaty/contract-grid'], { queryParams: { title: 'home' } });
      return false;
    } if (this.docType === "QS_ACNT") {
      this.router.navigate(['/accounting/accounting-dashboard']);
    } else {
      this.router.navigate(['/treaty/recovery'], { queryParams: { "action": 'view', 'transId': this.transId, 'tranSrNo': this.tranSrNo, 'seqNo': this.seqNo }, skipLocationChange: false });
    }


>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }
  processID: any;
  refId: any;
  //rmType:any;
  printDoc(content) {
    this.openMailTemp = false;
    /*  if (this.refNo == null || this.refNo == '') {
       this.toastService.error('Please Select and Proceed');
       return false;
     } */
    /*  if (this.docType === "XL_REC"){
        this.processID = this.refNo
        this.refId = ''
     } else {
       this.processID = ''
       this.refId = this.refNo
     } */

    let obj = {
      compCode: this.session.get('companyCode'),
      instId: this.session.get('instanceId'),
      divn: this.session.get('userDivnCode'),
      tranType: 'TTY_XOL',
      rmType: (this.docType === "XL_REC" || this.docType === "XL_REINST") ? 'XL_REC,XL_REINST' : this.docType

      /*  processId: this.transId?this.transId:'',
       refId: this.refNo?this.refNo:''--  */
    }
    this.treatyService.fetchReportParamList(obj).subscribe(resp => {
      this.reportParam = resp.reportParamList;
    })
<<<<<<< HEAD
    this.modalService.show(content, { class: 'modal-lg' });
=======
    this.modalService.show(content, { class: 'modal-lg' });    
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  }

  docTypeList: any;
  docTypeDropdown(tranID, tranSrNo) {
    this.treatyService.transactionTypeDropdown(tranID, tranSrNo).subscribe(res => {
      this.docTypeList = res["tranTypeDropDown"];
      this.docTypeList.unshift({ key: 'All', value: "All" });
    })

  }
  createSummaryHeaderForm() {
    this.summaryHeaderForm = this.fb.group({
      transType: undefined
    })
  }

  recAccViewGridLoad(event) {
    this.loaderService.isBusy = true;
    this.treatyService.viewRecAccoutingDetails(this.transId, this.tranSrNo, event.target.value).subscribe(res => {
      this.accEntryList = res;
      this.headerData = res[0];
      if (this.headerData && this.headerData.adCrDt) {
        this.headerData.adCrDt = moment(this.headerData.adCrDt).format('DD/MM/YYYY');
      } else if (this.headerData) {
        this.headerData.adCrDt = undefined;
      }
      this.loaderService.isBusy = false;
    })
  }

  //Send Email 
  createMailReplyModal() {
    this.mailReplyForm = this.fb.group({
      fromEmail: '',
      toEmail: ['', [Validators.required, Validators.email, this.commaSepEmail]],
      ccEmail: ['', [this.commaSepCCEmail, Validators.email]],
      subject: ['', Validators.required],
<<<<<<< HEAD
      emailBody: [undefined, Validators.required],
=======
      emailBody: ['', Validators.required],
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      jasperUrlPath: '',
      reportFileName: '',
      jasperUrlAllPaths: ''
    });
  }

  commaSepEmail = (control: AbstractControl): { [key: string]: any } | null => {
    if (control.value != null) {
      const emails = control.value.split(',').map(e => e.trim());
      const forbidden = emails.some(email => Validators.email(new UntypedFormControl(email)));
      return forbidden ? { 'toEmail': { value: control.value } } : null;
    }
  };
  commaSepCCEmail = (control: AbstractControl): { [key: string]: any } | null => {
    if (control.value != null) {
      const emails = control.value.split(',').map(e => e.trim());
      const forbidden = emails.some(email => Validators.email(new UntypedFormControl(email)));
      return forbidden ? { 'ccEmail': { value: control.value } } : null;
    }
  };
  pushSelectedDocs(event, value) {
    if (event.target.checked == true) {
      if (this.selectedArray.indexOf(value) === -1) {
        this.selectedArray.push(value);
      }
    } else {
      var index = this.selectedArray.indexOf(value);
      this.selectedArray.splice(index, 1)
    }
  }
  paramList: any
  params: any
  printDocument() {
    this.openMailTemp = false;
<<<<<<< HEAD
    // if (this.selectedArray.length == 0) {
    //   this.toastService.error('Please Select atleast one checkBox');
    //   return false;
    // }

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    if (this.docType == 'DEP_PREM_ADJ') {
      this.params = {
        refNo: this.transId,
        amendNo: "",
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_004',
        docType: this.docType
      }
    } else if (this.docType == 'REINST_ADJ') {
      this.params = {
        refNo: this.transId,
        amendNo: "",
        compCode: this.session.get("companyCode"),
        repId: 'RI_SCH_005',
        docType: this.docType
      }

    } else {
      this.params = {
        refNo: (this.docType === "XL_REC" || this.docType === "XL_REINST") ? this.transId : this.refNo,
        amendNo: (this.docType === "XL_REC" || this.docType === "XL_REINST") ? this.tranSrNo : this.amendNo,
        compCode: this.session.get('companyCode'),
        repId: 'RI_SCH_001',
        seqNo: this.seqNo ? this.seqNo : '',
        docType: this.docType
      }
    }
    this.treatyService.fetchReportUrl(this.params)
      .subscribe(result => {
        var url = result.resultUrl;
        var param = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,
          width=0,height=0,left=-1000,top=-1000`;
        var winRef = window.open(url, 'Reports', param);

      });
  }

  openMailTemp: boolean = false;
  attachedFileName: any;
  openReplyModal() {
    this.loaderService.isBusy = true;
    this.mailReplyForm.reset();
    let fromEmail = "anoudadmin@qicgroup.com.qa";
    let subject = "Accounting";
    let message = "Dear ,<br/><br/>Please find attached document<br/><br/>Regards,<br/><br/><br/><br/>";
    if (this.docType === "DEP_PREM") {
      subject = "Deposit Premium Accounting";
    } else if (this.docType === "DEP_PREM_ADJ") {
      subject = "Adjustment of Deposit Premium Accounting";
    } else if (this.docType == 'REINST_ADJ') {
      subject = "Adjustment of Reinstatement Premium Accounting";
    } else if (this.docType === "XL_REC" || this.docType === "XL_REINST") {
      subject = "XL Recovery & XL Reinstatement Premium";
    } else {
      subject = "NCB";
    }
    this.mailReplyForm.patchValue({ fromEmail: fromEmail, emailBody: message, subject: subject });
    if (this.selectedArray.length == 0) {
      this.toastService.warning('Please Select atleast one checkBox');
      this.loaderService.isBusy = false;
      return false;
    } else {
      this.openMailTemp = true;
    }
    //let urls =[];
    for (var i = 0; i < this.selectedArray.length; i++) {
      for (var j = 0; j < this.reportParam.length; j++) {
        if (this.reportParam[j].rmRepId == this.selectedArray[i]) {
          let selectedRmtype = this.reportParam[j].rmType;
          //let amendNo = this.tranNo +'-'+this.docNo;
          /*   var params = {
              refNo: this.refNo,
              amendNo: this.amendNo,
              compCode: this.session.get('companyCode'),
              repId: this.selectedArray[i],
              seqNo: this.seqNo,
              docType: selectedRmtype
            } */
          if (this.docType == 'DEP_PREM_ADJ') {
            this.params = {
              refNo: this.transId,
              amendNo: "",
              compCode: this.session.get("companyCode"),
              repId: 'RI_SCH_004',
              docType: this.docType
            }
          } else if (this.docType == 'REINST_ADJ') {
            this.params = {
              refNo: this.transId,
              amendNo: "",
              compCode: this.session.get("companyCode"),
              repId: 'RI_SCH_005',
              docType: this.docType
            }

          } else {
            this.params = {
              refNo: (this.docType === "XL_REC" || this.docType === "XL_REINST") ? this.transId : this.refNo,
              amendNo: (this.docType === "XL_REC" || this.docType === "XL_REINST") ? this.tranSrNo : this.amendNo,
              compCode: this.session.get('companyCode'),
              repId: this.selectedArray[i],
              seqNo: this.seqNo ? this.seqNo : '',
              docType: selectedRmtype
            }
          }
          this.treatyService.fetchReportUrl(this.params)
            .subscribe(result => {
              this.urls.push(result.resultUrl);
            });
          let id = (this.docType === "XL_REC" || this.docType === "XL_REINST") ? this.transId : this.refNo;
          this.mailReplyForm.patchValue({
            jasperUrlAllPaths: this.urls,
            reportFileName: subject + " (Batch ID - " + id + ")",
            fromEmail: fromEmail, emailBody: message, subject: subject + " Batch ID - " + id + ""
          });
          this.loaderService.isBusy = false;
          this.attachedFileName = subject + " (Batch ID - " + id + ").pdf"
        }

      }
    }
  }

  sendEmail() {
    this.loaderService.isBusy = true;
    if (this.mailReplyForm.valid) {
      let data = this.mailReplyForm.getRawValue();
      this.treatyService.sendXOLEmail(data).subscribe((resp) => {
        if (resp["messageType"] && resp["messageType"] == 'S') {
          document.getElementById('btnClose').click();
          this.toastService.success(resp["message"]);
          this.urls = [];
        } else {
          this.toastService.error(resp["message"]);
        }
        //this.toastService.success('Email sent Successfully');    
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.message);
      })
    } else {
      Utils.validateAllFormFields(this.mailReplyForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }

  }
}
function tooltipRenderer(params) {
  if(params && params.value) {
    return '<span title="' + params.value + '">' + params.value + '</span>';
  } else {
    return '';
  }
<<<<<<< HEAD

}
=======
}
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
