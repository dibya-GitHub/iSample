import { AgRendererComponent } from '@ag-grid-community/angular';
import { IAfterGuiAttachedParams } from '@ag-grid-community/core';
import { Component } from '@angular/core';

@Component({
  selector: 'app-ag-grid-checkbox',
  templateUrl: './ag-grid-checkbox.component.html',
  styleUrls: ['./ag-grid-checkbox.component.css']
})
export class AgGridCheckboxComponent implements AgRendererComponent {
  isDisable: any;

  public params: any;

  agInit(params: any): void {

    this.params = params;
    // if (params && params.colDef.cellRendererParams) {
    //   this.isDisable = params.colDef.cellRendererParams.isDisable;
    // }
    if (params && params.data && params.data.txcStatus === 'A') {
      this.isDisable = true;
    } else {
      this.isDisable = false;
    }
    // this.isDisable = params.getValue();
  }


  afterGuiAttached(params?: IAfterGuiAttachedParams): void {
  }

  refresh(params: any): boolean {
    params.data.amount++;
    params.data.cbox = params.value
    params.api.refreshCells(params);
    return false;
  }

  public processCheckBox(e) {
    this.params.context.componentParent.processCheckBoxGrid(e, this.params)
  }


}