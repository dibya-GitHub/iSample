import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AGNPIComponent } from './agnpi.component';

describe('AGNPIComponent', () => {
  let component: AGNPIComponent;
  let fixture: ComponentFixture<AGNPIComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AGNPIComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AGNPIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
