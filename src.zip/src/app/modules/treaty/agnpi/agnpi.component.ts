import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { RadiorenderComponent } from '../radiorender/radiorender.component';

declare var $: any;

@Component({
  selector: 'app-agnpi',
  templateUrl: './agnpi.component.html',
  styleUrls: ['./agnpi.component.css'],
  providers: [DatePipe,]
})
export class AGNPIComponent implements OnInit {
  egnpi: any;

  agnpiForm: UntypedFormGroup;
  cols: any[];
  processId: string;
  baseCurrency: string;
  @Input() action: string;
  transId: any;
  amendNo: any;
  seqNo: string;
  @Output() countChange = new EventEmitter();
  @ViewChild('content') content: ElementRef;
  @ViewChild('edit') actionIcon: ElementRef;
  lobList: any;
  divnList: any;
  compList: any;
  details: any = [];
  showForm: boolean = false;
  btmName: string = 'Save';
  refNo: any;
  gridApi: any;
  gridColumnApi: any;
  private defaultColDef;
  private getRowHeight;
  private frameworkComponents;
  private context;
  AddFlag: boolean = true;
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;

  constructor(private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private router: Router,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,
<<<<<<< HEAD
    private modalService: BsModalService,
    private datePipe: DatePipe
  ) { }
=======
     private datePipe: DatePipe,
     private modalService: BsModalService,
     ) { }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  ngOnInit() {

    this.cols = [
      { field: 'companyName', headerName: 'Company Name', sortable: true },
      { field: 'branch', headerName: 'Branch', sortable: true },
      { field: 'lobDesc', headerName: 'Class', sortable: true },
      { field: 'taaOrgPrem', headerName: 'EGNPI', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter, },
      { field: 'taaPrem', headerName: 'AGNPI', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter, },
      {
        headerName: "Action",
        field: 'companyName',
        cellStyle: { textAlign: 'center' },
<<<<<<< HEAD
        template:
          `<a>
     <i class="fa fa-file-pen fa-icon" #edit style="color:#009ca6" data-action-type="Edit"  title="Edit" aria-hidden="true"></i>&nbsp;&nbsp;
 </a>`
=======
        cellRenderer: function (params) {
          if (params.value) {
            return `<a>
            <i class="fa fa-file-pen fa-icon" #edit style="color:#009ca6" data-action-type="Edit"  title="Edit" aria-hidden="true"></i>&nbsp;&nbsp;
        </a>`
          } else {
            return ``;
          }
        },
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      }

    ];


    this.agnpiForm = this.fb.group({
      taaTransId: '',
      taaTtyRefNo: '',
      taaTtyAmendNo: '',
      taaTtySeqNo: '',
      taaOrgPrem: '',
      taaPrem: ['', Validators.required],
      taaCrUid: this.session.get('userId'),
      taaCrDt: new Date(),
      taaUpdUid: "",
      taaUpdDt: "",
      taaCompany: ['', Validators.required],
      taaDivision: ['', Validators.required],
      taaLob: ['', Validators.required],
      adjApiPK: ''
    })
  }

  public toggleModal(agnpi) {
    this.action = agnpi.action
    this.transId = agnpi.transId;
    this.baseCurrency = agnpi.currency;
    this.egnpi = agnpi.epi;
    this.seqNo = agnpi.seqNo;
    this.refNo = agnpi.refNo;
    this.amendNo = agnpi.amendNo;
    if (this.transId == null || this.transId == "") {
      this.toastService.warning('Please Enter Process Id ');
    } else if (this.baseCurrency == null || this.baseCurrency == "") {
      this.toastService.warning('Please Select Currency ');
    } else {
      if (this.action == 'View') {
        this.cols = [
          { field: 'companyName', headerName: 'Company', sortable: true },
          { field: 'branch', headerName: 'Branch', sortable: true },
          { field: 'lobDesc', headerName: 'Class', sortable: true },
          { field: 'taaOrgPrem', headerName: 'EGNPI', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter, },
          { field: 'taaPrem', headerName: 'AGNPI', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter, },
        ];
      } else if (this.action == 'Edit') {
        this.cols = [
          { field: 'companyName', headerName: 'Company', sortable: true },
          { field: 'branch', headerName: 'Branch', sortable: true },
          { field: 'lobDesc', headerName: 'Class', sortable: true },
          { field: 'taaOrgPrem', headerName: 'EGNPI', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter, },
          { field: 'taaPrem', headerName: 'AGNPI', type: 'number', headerClass: 'right-align-class', cellStyle: { textAlign: 'right' }, sortable: true, valueFormatter: numberFormatter, },
          {
<<<<<<< HEAD
            headerName: "Action", template:
              `<a>
     <i class="fa fa-file-pen fa-icon" #edit style="color:#009ca6" data-action-type="Edit"  title="Edit" aria-hidden="true"></i>&nbsp;&nbsp;
 </a>`
=======
            field: 'companyName',
            headerName: "Action",
            cellStyle: { textAlign: 'center' },
            cellRenderer: function (params) {
              if (params.value) {
                return `<a>
                <i class="fa fa-file-pen fa-icon" #edit style="color:#009ca6" data-action-type="Edit"  title="Edit" aria-hidden="true"></i>&nbsp;&nbsp;
            </a>`
              } else {
                return ``;
              }
            },
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
          }
        ];
      }
      this.retrieveAgnpiDetails('');
      this.open(this.content, 'modal-lg');
    }
  }

<<<<<<< HEAD
  open(content, val) {
    this.modalService.show(content, { class: val });
=======
  open(content,val) {
    this.modalService.show(content, { class: val });    
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  }

  retrieveAgnpiDetails(flag) {
    this.loaderService.isBusy = true;
    this.treatyService.fetchAgnpiDetails(this.transId, this.seqNo, this.refNo, this.amendNo).subscribe(resp => {
      this.details = resp.preIncomeList;
      // this.scriptcall('agnpi');
      let totalAgnpi: number = 0;
      this.loaderService.isBusy = false;
      for (var i = 0; i < resp.preIncomeList.length; i++) {
        totalAgnpi = totalAgnpi + resp.preIncomeList[i].taaPrem;
      }
      let obj = { transId: this.transId, seqNo: this.seqNo, refNo: this.refNo, amendNo: this.amendNo, amount: totalAgnpi }
      if ('emit' == flag)
        this.countChange.emit(obj);
    })
  }

  add() {
    this.agnpiForm.reset()
    this.showForm = true;
    this.AddFlag = false;
    //this.collapsed = !this.collapsed;

    this.action = 'add';
    this.btmName = 'Save';
    this.retrieveCompDetails();
    //this.retrieveDivnetails();
    this.retrieveLobDetails();
    this.agnpiForm.get('taaCompany').enable();
    this.agnpiForm.get('taaDivision').enable();
    this.agnpiForm.get('taaLob').enable();
    this.agnpiForm.get('taaOrgPrem').setValue(this.egnpi);
    //this.agnpiForm.reset();
  }

  retrieveCompDetails() {
    this.loaderService.isBusy = true;
    this.treatyService.retrieveCompDetails().subscribe(resp => {
      this.compList = resp.companyList;
      this.loaderService.isBusy = false;

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  retrieveDivnetails(event) {
    this.loaderService.isBusy = true;
    var compcode = event.value;
    this.treatyService.retrieveDivnDetails(compcode).subscribe(resp => {
      this.divnList = resp.divisionList;
      // this.applySelect();
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }
  retrieveLobDetails() {
    this.treatyService.retrieveLobDetails().subscribe(resp => {
      this.lobList = resp.lobList;
      // this.applySelect();
    })
  }

  save() {
    if (this.agnpiForm.valid) {
      this.loaderService.isBusy = true;


      var agnpi = this.agnpiForm.get('taaPrem').value;
      if (agnpi) { if (typeof agnpi === 'string') { agnpi.replace(/,/g, '') } else { } } else { agnpi = 0 }
      if (this.action == 'edit') {
        var objPk = {
          taaTransId: this.transId,
          taaTtyRefNo: this.agnpiForm.get('taaTtyRefNo').value,
          taaTtyAmendNo: this.agnpiForm.get('taaTtyAmendNo').value,
          taaCompany: this.agnpiForm.get('taaCompany').value,
          taaDivision: this.agnpiForm.get('taaDivision').value,
          taaLob: this.agnpiForm.get('taaLob').value,
          taaTtySeqNo: this.seqNo
        }
        this.agnpiForm.patchValue({
          adjApiPK: objPk,
          taaPrem: agnpi
        })
        this.agnpiForm.get('taaCompany').enable();
        this.agnpiForm.get('taaDivision').enable();
        this.agnpiForm.get('taaLob').enable();
        this.treatyService.updateAgnpById(this.agnpiForm.value).subscribe(resp => {
          this.toastService.success("Successfully Updated");
          // this.countChange.emit(resp.messageType);
          this.retrieveAgnpiDetails('emit');
          this.loaderService.isBusy = false;
          this.showForm = false;
          this.AddFlag = true;
          //  this.retrieveEpiDetails();
        }, error => {
          this.toastService.error(error.error.message);
          this.loaderService.isBusy = false;
        })

      } else {

        var objPk = {
          taaTransId: this.transId,
          taaTtyRefNo: this.refNo,
          taaTtyAmendNo: this.amendNo,
          taaCompany: this.agnpiForm.get('taaCompany').value,
          taaDivision: this.agnpiForm.get('taaDivision').value,
          taaLob: this.agnpiForm.get('taaLob').value,
          taaTtySeqNo: this.seqNo
        }
        this.agnpiForm.patchValue({
          adjApiPK: objPk,
          taaPrem: agnpi,
          taaCrUid: this.session.get('userId'),
          taaCrDt: new Date(),

        })

        this.treatyService.insertAgnp(this.agnpiForm.value).subscribe(resp => {
          this.toastService.success("Successfully Saved");
          //this.countChange.emit(resp.messageType);
          this.loaderService.isBusy = false;
          this.retrieveAgnpiDetails('emit');
          this.showForm = false;
          this.AddFlag = true;

        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })

      }

    } else {
      this.validateAllFormFields(this.agnpiForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  editApi(detail) {
    this.showForm = true;
    this.action = 'edit';
    this.btmName = 'Update';
    this.treatyService.retrieveCompDetails().subscribe(resp => {
      this.compList = resp.companyList;
      this.treatyService.retrieveDivnDetails(detail.adjApiPK.taaCompany).subscribe(resp => {
        // this.applySelect();
        this.divnList = resp.divisionList;
      })
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
    this.retrieveLobDetails();

    this.transId = detail.adjApiPK.taaTransId;
    this.agnpiForm.patchValue({
      taaTransId: detail.adjApiPK.taaTransId,
      taaTtyRefNo: detail.adjApiPK.taaTtyRefNo,
      taaTtyAmendNo: detail.adjApiPK.taaTtyAmendNo,
      taaTtySeqNo: detail.adjApiPK.taaTtySeqNo,
      taaPrem: detail.taaPrem,
      taaOrgPrem: detail.taaOrgPrem,
      taaCrUid: detail.taaCrUid,
      taaCrDt: detail.taaCrDt,
      taaUpdUid: this.session.get('userId'),
      taaUpdDt: this.datePipe.transform(new Date(), ApiUrls.DATE_FORMAT),
      taaCompany: detail.adjApiPK.taaCompany,
      taaDivision: detail.adjApiPK.taaDivision,
      taaLob: detail.adjApiPK.taaLob
    })
    this.agnpiForm.get('taaCompany').disable();
    this.agnpiForm.get('taaDivision').disable();
    this.agnpiForm.get('taaLob').disable();
  }

  deleteApi(detail) {
    let obj = {
      taaTransId: detail.adjApiPK.taaTransId,
      taaTtyRefNo: detail.adjApiPK.taaTtyRefNo,
      taaTtyAmendNo: detail.adjApiPK.taaTtyAmendNo,
      taaCompany: detail.adjApiPK.taaCompany,
      taaDivision: detail.adjApiPK.taaDivision,
      taaLob: detail.adjApiPK.taaLob,
      taaTtySeqNo: detail.adjApiPK.taaTtySeqNo,
    }
    this.treatyService.deleteAgnpi(obj).subscribe(resp => {
      this.toastService.success("Successfully Deleted");
      this.retrieveAgnpiDetails('emit');
    })
  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  back() {
    this.showForm = false;
    this.AddFlag = true;
    this.agnpiForm.reset();
  }


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onRowClicked(e, title) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.transId = data.txaTransId;
      switch (actionType) {
        case "Edit":
          //  this.addAdjustmentPremium('edit');
          return this.editApi(data);
        case "View":
        //  return this.addAdjustmentPremium('view');


      }
    }

  }
  onGridSizeChanged(params) {
    console.log(params)
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  rowHeight() {
    this.getRowHeight = function (params) {
      var isBodyRow = params.node.rowPinned === undefined;
      var isFullWidth = params.node.data.fullWidth;
      if (isBodyRow && isFullWidth) {
        return 55;
      } else {
        return 40;
      }
    };
  }

  agGridOptions() {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadiorenderComponent
    };
  }
  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  dateFormatter(params) {
    if (params.value) {
      return moment(params.value).format('DD/MM/YYYY');
    }
  }
  closeModal() {
    this.modalService.hide();
  }
}
function numberFormatter(params) {
  if (params.value != null) {
    var currencyVal = Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    //var currencyVal = Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value).toFixed(2));
  } else {
    var currencyVal = Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  }
  return currencyVal;
}
