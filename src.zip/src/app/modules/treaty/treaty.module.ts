<<<<<<< HEAD
import { AgGridModule } from '@ag-grid-community/angular';
import { CommonModule, DatePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { DropdownModule } from 'primeng/dropdown';
import { InputNumberModule } from 'primeng/inputnumber';
import { MultiSelectModule } from 'primeng/multiselect';
import { TabViewModule } from 'primeng/tabview';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { AadTotalComponent } from './aad-total/aad-total.component';
import { CustomPinnedRowRenderer } from './aad-total/custom-pinned-row-renderer.component';
=======

import { CommonModule, DatePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { AdjustmentPremiumComponent } from './adjustment-premium/adjustment-premium.component';
import { AgDropdwonComponent } from './ag-dropdwon/ag-dropdwon.component';
import { AgGridCheckboxComponent } from './ag-grid-checkbox/ag-grid-checkbox.component';
import { AGNPIComponent } from './agnpi/agnpi.component';
<<<<<<< HEAD
import { AmendmentHistoryComponent } from './amendment-history/amendment-history.component';
import { ApplContractComponent } from './appl-contract/appl-contract.component';
import { ApprovedContractComponent } from './approved-contract/approved-contract.component';
import { ClaimRecoveryComponent } from './claim-recovery/claim-recovery.component';
import { ContractFormComponent } from './contract-form/contract-form.component';
import { EditAdjustPremiumComponent } from './edit-adjust-premium/edit-adjust-premium.component';
import { EditviewrenderComponent } from './editviewrender/editviewrender.component';
=======
import { ApprovedContractComponent } from './approved-contract/approved-contract.component';
import { ContractFormComponent } from './contract-form/contract-form.component';
import { EditAdjustPremiumComponent } from './edit-adjust-premium/edit-adjust-premium.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
import { EgnpContractComponent } from './egnp-contract/egnp-contract.component';
import { EGNPComponent } from './egnp/egnp.component';
import { FacRiskPerilComponent } from './fac-risk-peril/fac-risk-peril.component';
import { LayerTreatyTypeComponent } from './layer-treaty-type/layer-treaty-type.component';
<<<<<<< HEAD
import { NCBComponent } from './ncb/ncb.component';
import { OutwardLlyodsComponent } from './outward-llyods/outward-llyods.component';
import { PlaNotificationComponent } from './pla-notification/pla-notification.component';
import { RadiorenderComponent } from './radiorender/radiorender.component';
import { RadiorenderComponent2 } from './radiorender/radiorender2.component';
import { HiperLinkComponent } from './recovery-enquiry-form/ag-hiperlink.component';
import { RecoveryEnquiryFormComponent } from './recovery-enquiry-form/recovery-enquiry-form.component';
import { RecoveryEnquiryComponent } from './recovery-enquiry/recovery-enquiry.component';
import { ReinsurePremiumComponent } from './reinsure-premium/reinsure-premium.component';
import { ReinsurersComponent } from './reinsurers/reinsurers.component';
import { RiskLlyodsComponent } from './risk-llyods/risk-llyods.component';
import { TransactionQueryComponent } from './transaction-query/transaction-query.component';
import { TreatyApprContractComponent } from './treaty-appr-contract/treaty-appr-contract.component';
import { TreatyContractComponent } from './treaty-contract/treaty-contract.component';
import { TreatyCurrLimitComponent } from './treaty-curr-limit/treaty-curr-limit.component';
import { TreatyCurrencyComponent } from './treaty-currency/treaty-currency.component';
import { TreatyLayerFormComponent } from './treaty-layer-form/treaty-layer-form.component';
import { TreatyLayerComponent } from './treaty-layer/treaty-layer.component';
import { TreatyPerilsComponent } from './treaty-perils/treaty-perils.component';
import { TreatyReinstComponent } from './treaty-reinst/treaty-reinst.component';
import { TreatyReinsurerComponent } from './treaty-reinsurer/treaty-reinsurer.component';
import { TreatyRoutingModule } from './treaty-routing.module';
import { NumericEditorComponent } from './treaty-terms/numeric-editor.component';
import { TreatyTermsComponent } from './treaty-terms/treaty-terms.component';
import { TreatyViewAccountingComponent } from './treaty-view-accounting/treaty-view-accounting.component';
import { TreatyViewDocComponent } from './treaty-view-doc/treaty-view-doc.component';
import { TreatyWizardComponent } from './treaty-wizard/treaty-wizard.component';
import { TrustFundComponent } from './trust-fund/trust-fund.component';
import { ApplicableCompanyComponent } from './applicable-company/applicable-company.component';

=======
import { OutwardLlyodsComponent } from './outward-llyods/outward-llyods.component';
import { RecoveryEnquiryFormComponent } from './recovery-enquiry-form/recovery-enquiry-form.component';
import { RecoveryEnquiryComponent } from './recovery-enquiry/recovery-enquiry.component';
import { ReinsurePremiumComponent } from './reinsure-premium/reinsure-premium.component';
import { ReinsurersComponent } from './reinsurers/reinsurers.component';
import { TreatyContractComponent } from './treaty-contract/treaty-contract.component';
import { TreatyCurrLimitComponent } from './treaty-curr-limit/treaty-curr-limit.component';
import { TreatyCurrencyComponent } from './treaty-currency/treaty-currency.component';
import { TreatyLayerComponent } from './treaty-layer/treaty-layer.component';
import { TreatyReinstComponent } from './treaty-reinst/treaty-reinst.component';
import { TreatyViewDocComponent } from './treaty-view-doc/treaty-view-doc.component';
import { TreatyWizardComponent } from './treaty-wizard/treaty-wizard.component';
import { AgGridModule } from '@ag-grid-community/angular';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { CommonAppModule } from 'src/app/shared/common-app.module';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { AadTotalComponent } from './aad-total/aad-total.component';
import { CustomPinnedRowRenderer } from './aad-total/custom-pinned-row-renderer.component';
import { AgDropdwonComponent } from './ag-dropdwon/ag-dropdwon.component';
import { AgGridCheckboxComponent } from './ag-grid-checkbox/ag-grid-checkbox.component';
import { ApplContractComponent } from './appl-contract/appl-contract.component';
import { ClaimRecoveryComponent } from './claim-recovery/claim-recovery.component';
import { EditviewrenderComponent } from './editviewrender/editviewrender.component';
import { NCBComponent } from './ncb/ncb.component';
import { RadiorenderComponent } from './radiorender/radiorender.component';
import { HiperLinkComponent } from './recovery-enquiry-form/ag-hiperlink.component';
import { RiskLlyodsComponent } from './risk-llyods/risk-llyods.component';
import { TreatyLayerFormComponent } from './treaty-layer-form/treaty-layer-form.component';
import { TreatyRoutingModule } from './treaty-routing.module';
import { TreatyTermsComponent } from './treaty-terms/treaty-terms.component';
import { TrustFundComponent } from './trust-fund/trust-fund.component';
//import { CurrencyMaskModule } from "ng2-currency-mask";
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { AmendmentHistoryComponent } from './amendment-history/amendment-history.component';
import { PlaNotificationComponent } from './pla-notification/pla-notification.component';
import { TreatyViewAccountingComponent } from './treaty-view-accounting/treaty-view-accounting.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { InputNumberModule } from 'primeng/inputnumber';
import { TreatyCashadvanceComponent } from './treaty-cashadvance/treaty-cashadvance.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
@NgModule({
  declarations: [
    TreatyContractComponent,
    ContractFormComponent,
    TreatyLayerComponent,
    EGNPComponent,
    TreatyCurrencyComponent,
    ReinsurersComponent,
    ReinsurePremiumComponent,
    RecoveryEnquiryComponent,
    RecoveryEnquiryFormComponent,
    AdjustmentPremiumComponent,
    AGNPIComponent,
    TreatyViewDocComponent,
    EgnpContractComponent,
    TreatyLayerFormComponent,
    TreatyWizardComponent,
    ApprovedContractComponent,
    TreatyReinstComponent,
    EditAdjustPremiumComponent,
    TreatyCurrLimitComponent,
    FacRiskPerilComponent,
    LayerTreatyTypeComponent,
    OutwardLlyodsComponent,
    AgDropdwonComponent,
    TreatyTermsComponent,
    TreatyPerilsComponent,
    ApplContractComponent,
    TrustFundComponent,
    RiskLlyodsComponent,
    RadiorenderComponent,
    RadiorenderComponent2,
    AgGridCheckboxComponent,
    EditviewrenderComponent,
    NCBComponent,
    ClaimRecoveryComponent,
    AadTotalComponent,
    CustomPinnedRowRenderer,
    HiperLinkComponent,
    AmendmentHistoryComponent,
    PlaNotificationComponent,
    TreatyViewAccountingComponent,
<<<<<<< HEAD
    TreatyReinsurerComponent,
    TreatyApprContractComponent,
    TransactionQueryComponent,
    NumericEditorComponent,
    ApplicableCompanyComponent
=======
    TreatyCashadvanceComponent
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgMultiSelectDropDownModule,
    InputNumberModule,
    FormsModule,
    CommonAppModule,
<<<<<<< HEAD
    AgGridModule.withComponents([RadiorenderComponent,RadiorenderComponent2, AgGridCheckboxComponent, EditviewrenderComponent, CustomPinnedRowRenderer, HiperLinkComponent,NumericEditorComponent]),
    TreatyRoutingModule,
    MultiSelectModule,
    DropdownModule,
    TabViewModule
=======
    AgGridModule.withComponents([RadiorenderComponent, AgGridCheckboxComponent, EditviewrenderComponent, CustomPinnedRowRenderer, HiperLinkComponent]),
    TreatyRoutingModule,
    DropdownModule,
    MultiSelectModule,
    AutoCompleteModule,
    InputNumberModule,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ],
  providers: [DatePipe, MycurrencyPipe],
  schemas: [
    NO_ERRORS_SCHEMA,
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class TreatyModule { }
