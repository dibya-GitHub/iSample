import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { MycurrencyPipe } from 'src/app/shared/pipes/mycurrency.pipe';
import { TreatyService } from 'src/app/shared/services/treaty.service';
<<<<<<< HEAD

=======
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

declare var $: any;

@Component({
  selector: 'app-treaty-currency',
  templateUrl: './treaty-currency.component.html',
  styleUrls: ['./treaty-currency.component.css'],
  providers: [MycurrencyPipe]
})
export class TreatyCurrencyComponent implements OnInit {
  addFlag: boolean = true;
  showEntriesOptions = [5, 10, 20, 50, 100];
  limitShowEntriesOptionSelected = 5;
  premiumShowEntriesOptionSelected = 5;
  limitQuickSearchValue: string = '';
  premiumQuickSearchValue: string = '';
  public limitGridApi;
  public premiumGridApi;
  private gridColumnApi;
  public limitDefs;
  private defaultColDef;
  public premiumDefs;
  private defaultColGroupDef;
  private columnTypes;
  public rowData = [];
  public rowInfo = [];
  tcLayer: any;
  tcCurr: any;
  tcAmendNo: any;
  tcRefNo: any;
  showForm: boolean = false;
  ttyCurrFrm: UntypedFormGroup;
  code4: any;
  code3: any;
  code2: any;
  code1: any;
  code: any;
  collapsed: boolean = true;
  cols: any[];
  details: any[];
  PremiumFlag: boolean;
  LimitFlag: boolean;
  Curr_List: any;
  Curr_type: any;
  del_seqNo: any;

  @Input() layer: any;
  @Input() action: any;
  @Input() amendNo: any;
  @Input() refNo: any;
  @Input() seqNo: any;
  @Input() CurrType: any;
  @Input() LimitCurr: any;
  @Input() tlDeductible: string;
  @Input() tlAad: string;
  @Input() tlLimit: string;
  @Input() tlDesc: string;
  @Input() amndSrNo: any;
  currList: any;
  display: boolean = false;
  count: number = 123;
  @ViewChild('content') content: ElementRef;
  @ViewChild('confirmcontent') confirmcontent: ElementRef;
  @ViewChild('confirmcontentPrem') confirmcontentPrem: ElementRef;
  headerTittle: string;
  disabled: boolean = false;
  premium: any[];
  premCurrFrm: any;
  PremCurrdetails: any;
  bsCurr: string;
  Premium_Action: string;
  Limt_Action: string;


  constructor(
    private treatyService: TreatyService,
    private fb: UntypedFormBuilder,
    private toastService: ToastService,
    private modalService: BsModalService,
    private session: SessionStorageService,
    private loaderService: LoaderService,
    private cpipe: MycurrencyPipe
  ) { }



  ngOnInit() {
    this.Premium_Action = "Save";
    this.bsCurr = this.session.get('baseCurrency');
    this.limitDefs = [
      // { field: 'tcCurrDesc', header: 'Currency' },
      { field: 'mttyCurrPK.tcCurr', headerName: 'Currency' },
      { field: 'tcFixedRate', headerName: 'ROE',valueFormatter: currencyFormatter },
      {
        field: 'tcLimit', headerName: 'Limit', cellStyle: { textAlign: 'right' }, filter: true,
        valueFormatter: currencyFormatter
      },
      {
        field: 'tcDeductible', headerName: 'Excess', cellStyle: { textAlign: 'right' }, filter: true,
        valueFormatter: currencyFormatter
      },
      {
        field: 'tcAad', headerName: 'Aggregate Deductible', cellStyle: { textAlign: 'right' }, filter: true,
        valueFormatter: currencyFormatter
      },
      {
        headerName: 'Action',
<<<<<<< HEAD
        field: 'actions',
        template:
          ` <a>
    <i class="fa fa-file-pen fa-icon"  data-action-type="EditLimit"  title="Edit" aria-hidden="true"></i>
    &nbsp;
    <i class="fa fa-trash fa-icon"  data-action-type="DeleteLimit"  title="Delete" aria-hidden="true"></i>
    </a>`,
        cellStyle: { textAlign: 'center' }
=======
        field: 'mttyCurrPK.tcCurr',
        cellRenderer: actionRender1,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },

    ];
    this.premiumDefs = [
      // { field: 'tcCurrDesc', header: 'Currency' },
      { field: 'mttyCurrPK.tcCurr', headerName: 'Currency' },
      { field: 'tcFixedRate', headerName: 'ROE' },
      {
        field: 'tcMinPrem', headerName: 'Minimum', cellStyle: { textAlign: 'right' }, filter: true,
        valueFormatter: currencyFormatter
      },
      {
        field: 'tcDepPrem', headerName: 'Deposit', cellStyle: { textAlign: 'right' }, filter: true,
        valueFormatter: currencyFormatter
      },
      {
        field: 'tcMinPremLc1', headerName: 'Minimum (' + this.bsCurr + ')', cellStyle: { textAlign: 'right' }, filter: true,
        valueFormatter: currencyFormatter
      },
      {
        field: 'tcDepPremLc1', headerName: 'Deposit (' + this.bsCurr + ')', cellStyle: { textAlign: 'right' }, filter: true,
        valueFormatter: currencyFormatter
      },
      {
        headerName: 'Action',
<<<<<<< HEAD
        field: 'actions',
        template:
          ` <a>
        <i class="fa fa-file-pen fa-icon"  data-action-type="EditPrem"  title="Edit" aria-hidden="true"></i>
        &nbsp;
        <i class="fa fa-trash fa-icon"  data-action-type="DeletePrem"  title="Delete" aria-hidden="true"></i>
        </a>`,
        cellStyle: { textAlign: 'center' }
=======
        field: 'mttyCurrPK.tcCurr',
        cellRenderer: actionRender2,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      },

    ];
    // this.refNo=this.treatyService.getParamValue('refNo');
    // this.amendNo=this.treatyService.getParamValue('amendNo');
    // this.action=this.treatyService.getParamValue('action');
    // this.layer=this.treatyService.getParamValue('layer');
    this.details = [];
    this.PremiumForm();
    this.createForm();
    this.toggleModal();
    this.retrieveCurrPremiumList();
    this.retrieveTreatyCurrList();
    this.retrieveCurrency();
  }
  toggleModal() {


    if ("view" == this.action) {
      this.showForm = false;
    }
    // this.retrieveTreatyCurrList();

  }
  createForm() {
    this.ttyCurrFrm = this.fb.group({
      tcRefNo: '',
      tcAmendNo: '',
      tcSeqNo: '',
      tcLayer: '',
      tcCurr: '',
      tcFixedRate: '',
      tcStatus: 'P',
      tcAad: '',
      tcDeductible: '',
      tcLimit: '',
      tcType: 'LI',
      tcCrUid: this.session.get('userId'),
      tcCrDt: new Date(),
      mttyCurrPK: ''
    })
  }

  PremiumForm() {
    this.premCurrFrm = this.fb.group({
      tcRefNo: '',
      tcAmendNo: '',
      tcSeqNo: '',
      tcLayer: '',
      tcCurr: '',
      tcFixedRate: '',
      tcStatus: 'P',
      tcMinPrem: '',
      tcDepPrem: '',
      tcMinPremLc1: '',
      tcDepPremLc1: '',
      tcType: 'PR',
      tcCrUid: this.session.get('userId'),
      tcCrDt: new Date(),
      mttyCurrPK: ''
    })
  }
  retrieveTreatyCurrList() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: this.layer,
      seqNo: this.seqNo,
      type: 'LI'
    }
    this.treatyService.retrieveCurrencyById(obj).subscribe(resp => {
      // for(var i=0;i<resp.length;i++){
      this.details = resp;
      this.rowData = resp;
      // }
      this.scriptcall('treaty-currency');
      this.loaderService.isBusy = false;
    }, error => {
      this.scriptcall('treaty-currency');
      this.loaderService.isBusy = false;
    })
  }
  retrieveCurrPremiumList() {
    this.loaderService.isBusy = true;
    let obj = {
      refNo: this.refNo,
      amdNo: this.amendNo,
      layer: this.layer,
      seqNo: this.seqNo,
      type: 'PR'
    }
    this.treatyService.retrieveCurrencyPremById(obj).subscribe(resp => {
      //  for(var i=0;i<resp.length;i++){
      //   this.details=resp[i];
      //  }
      this.PremCurrdetails = resp;
      this.rowInfo = resp;
      this.scriptcall('currency-premium');
      this.loaderService.isBusy = false;
    }, error => {
      this.scriptcall('currency-premium');
      this.loaderService.isBusy = false;
    })
  }
  retrieveCurrency() {
    this.loaderService.isBusy = true;
    this.treatyService.retrievecurrencyList().subscribe(resp => {
      this.currList = resp.currencyList;
      this.ngAfterViewInit();
      this.loaderService.isBusy = false;
    }, error => { this.loaderService.isBusy = false; }
    );
  }

  open(content, val) {
    this.modalService.show(content, { class: val });
  }
  closeModal() {
    this.modalService.hide();
  }
  save() {
    this.premCurrFrm.controls['tcCurr'].enable();
    this.premCurrFrm.controls['tcMinPrem'].enable();
    this.premCurrFrm.controls['tcDepPrem'].enable();
    this.premCurrFrm.controls['tcMinPremLc1'].enable();
    this.premCurrFrm.controls['tcDepPremLc1'].enable();
    this.premCurrFrm.controls['tcFixedRate'].disable();
    this.ttyCurrFrm.controls['tcLimit'].enable();
    this.ttyCurrFrm.controls['tcDeductible'].enable();
    this.ttyCurrFrm.controls['tcAad'].enable();
    if (this.ttyCurrFrm.valid) {
      let data = {
        tcRefNo: this.refNo,
        tcAmendNo: this.amendNo,
        tcLayer: this.layer,
        tcCurr: this.ttyCurrFrm.get('tcCurr').value,
        tcSeqNo: this.seqNo,
        tcType: 'LI'
      }
      var tcDeductible = this.ttyCurrFrm.get('tcDeductible').value ? this.ttyCurrFrm.get('tcDeductible').value.replace(/,/g, '') : '0';
      var tcLimit = this.ttyCurrFrm.get('tcLimit').value ? this.ttyCurrFrm.get('tcLimit').value.replace(/,/g, '') : '0';
      var tcAad = this.ttyCurrFrm.get('tcAad').value ? this.ttyCurrFrm.get('tcAad').value.replace(/,/g, '') : '0';
      if(tcDeductible == 0){
        this.toastService.warning('ROE cannot be zero');
        return false;
      }
      if (this.action == 'edit') {
        this.ttyCurrFrm.patchValue({
          mttyCurrPK: data,
          tcDeductible: tcDeductible,
          tcLimit: tcLimit,
          tcAad: tcAad,
          tcStatus: 'A',
          tcCrUid: this.session.get('userId'),
          tcCrDt: new Date(),
        })
        this.treatyService.updateTreatycurr(this.ttyCurrFrm.value, this.amndSrNo).subscribe(resp => {
          // this.collapsed = !this.collapsed;
          this.ttyCurrFrm.reset();
          this.showForm = false;
          this.addFlag = true;
          this.toastService.success('Updated Successfully');
          //this.ttyCurrFrm.reset();
          this.retrieveTreatyCurrList();
        })
      } else {

        this.ttyCurrFrm.patchValue({
          mttyCurrPK: data,
          tcDeductible: tcDeductible,
          tcLimit: tcLimit,
          tcAad: tcAad,
          tcStatus: 'A',
          tcCrUid: this.session.get('userId'),
          tcCrDt: new Date(),
        })
        this.treatyService.insertTreatyCurr(ApiUrls.APP_CURRENCY_MGMT_PATH, this.ttyCurrFrm.value, this.amndSrNo).subscribe(resp => {
          //this.collapsed = !this.collapsed;
          this.ttyCurrFrm.reset();
          this.showForm = false;
          this.addFlag = true;
          this.toastService.success('Successfully Saved');
          this.ttyCurrFrm.reset();
          this.retrieveTreatyCurrList();
          this.retrieveCurrPremiumList();
        })
      }
    } else {
      this.validateAllFormFields(this.ttyCurrFrm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  addCurrency(name: any) {
    if ('limit' === name) {
      this.showForm = true;
    } else if ('Premium' === name) {
      this.PremiumFlag = true;
    }
    this.addFlag = false;
    if (!this.layer) {
      this.toastService.success('Please Select the layer');
      return false;
    }
    this.retrieveCurrency();
    this.action = 'add';
    this.ttyCurrFrm.reset();
    //this.collapsed = !this.collapsed;

    this.ttyCurrFrm.controls['tcCurr'].enable();
    this.ttyCurrFrm.controls['tcFixedRate'].enable();
    this.ttyCurrFrm.controls['tcLimit'].enable();
    this.ttyCurrFrm.controls['tcDeductible'].enable();
    this.ttyCurrFrm.controls['tcAad'].enable();
    this.Limt_Action = "Save";
  }

  editMaster(data: any) {
    this.PremiumFlag = false;
    this.showForm = true;
    this.addFlag = false;
    this.retrieveCurrency();
    this.ttyCurrFrm.controls['tcCurr'].disable();
    this.ttyCurrFrm.controls['tcLimit'].disable();
    this.ttyCurrFrm.controls['tcDeductible'].disable();
    this.ttyCurrFrm.controls['tcAad'].disable();
    this.Limt_Action = "Update";
    this.action = 'edit';
    this.code = data.mttyCurrPK.tcRefNo
    this.code1 = data.mttyCurrPK.tcAmendNo
    this.code2 = data.mttyCurrPK.tcLayer
    this.code3 = data.mttyCurrPK.tcCurr
    let objPk = {
      tcRefNo: data.mttyCurrPK.tcRefNo,
      tcAmendNo: data.mttyCurrPK.tcAmendNo,
      tcLayer: data.mttyCurrPK.tcLayer,
      tcSeqNo: data.mttyCurrPK.tcSeqNo,
      tcCurr: data.mttyCurrPK.tcCurr,
      tcType: data.mttyCurrPK.tcType
    }

    this.treatyService.retrieveTrCurrById(objPk).subscribe(resp => {
      this.Curr_List = resp.currencyList;
      this.showForm = true;
      // for(var i=0;i<resp.length;i++){
      //   this.Curr_List = resp[i];
      // }
      if (this.Curr_List.mttyCurrPK.tcCurr == this.bsCurr) {
        this.ttyCurrFrm.controls['tcFixedRate'].disable();
      }
      this.ttyCurrFrm.patchValue({
        tcCurr: this.Curr_List.mttyCurrPK.tcCurr,
        tcFixedRate: this.Curr_List.tcFixedRate,
        tcLimit: this.cpipe.transform(this.Curr_List.tcLimit),
        tcDeductible: this.cpipe.transform(this.Curr_List.tcDeductible),
        tcAad: this.cpipe.transform(this.Curr_List.tcAad)
      })
    })
  }

  editPremiumData(data) {
    this.showForm = false;
    this.PremiumFlag = true;
    this.addFlag = false;
    this.premCurrFrm.controls['tcCurr'].disable();
    // this.premCurrFrm.controls['tcMinPrem'].disable();
    // this.premCurrFrm.controls['tcDepPrem'].disable();
    this.premCurrFrm.get('tcMinPremLc1').disable();
    this.premCurrFrm.get('tcDepPremLc1').disable();
    this.Premium_Action = "Update"
    let objPk = {
      tcRefNo: data.mttyCurrPK.tcRefNo,
      tcAmendNo: data.mttyCurrPK.tcAmendNo,
      tcLayer: data.mttyCurrPK.tcLayer,
      tcCurr: data.mttyCurrPK.tcCurr,
      tcSeqNo: data.mttyCurrPK.tcSeqNo,
      tcType: data.mttyCurrPK.tcType
    }
    if (data.mttyCurrPK.tcCurr == this.bsCurr) {
      this.premCurrFrm.controls['tcFixedRate'].disable();
    }
    this.treatyService.retrieveTrCurrById(objPk).subscribe(resp => {
      // this.showForm=true;
      this.Curr_List = resp.currencyList;
      // for(var i=0;i<resp.length;i++){
      //   this.Curr_List = resp[i];
      // }
      this.premCurrFrm.patchValue({
        tcCurr: this.Curr_List.mttyCurrPK.tcCurr,
        tcFixedRate: this.Curr_List.tcFixedRate,
        tcMinPremLc1: this.cpipe.transform(this.Curr_List.tcMinPremLc1),
        tcMinPrem: this.cpipe.transform(this.Curr_List.tcMinPrem),
        tcDepPremLc1: this.cpipe.transform(this.Curr_List.tcDepPremLc1),
        tcDepPrem: this.cpipe.transform(this.Curr_List.tcDepPremLc1)
      })
    }, error => {
    })
  }

  deleteCurr(currInfo: any) {
    let obj = {
      tcRefNo: this.tcRefNo,
      tcAmendNo: this.tcAmendNo,
      tcLayer: this.tcLayer,
      tcCurr: this.tcCurr,
      tcSeqNo: this.seqNo,
      tcType: 'LI'
    }
    this.loaderService.isBusy = true;
    this.treatyService.deleteTrCurrById(obj, this.amndSrNo).subscribe(resp => {
<<<<<<< HEAD
      this.loaderService.isBusy = true;
      let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
      element.click();
      this.toastService.success('Deleted Succcessfully.');
      this.retrieveTreatyCurrList();
=======
      console.log(currInfo)      
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      this.loaderService.isBusy = false;
      this.modalService.hide();
      // let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
      // element.click();
      this.toastService.success('Deleted Succcessfully.');
      this.retrieveTreatyCurrList();     
      this.back();
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error('Error while Deleting.');
    })

  }
  deletePremiumData(currInfo: any) {
    let obj = {
      tcRefNo: this.tcRefNo,
      tcAmendNo: this.tcAmendNo,
      tcLayer: this.tcLayer,
      tcCurr: this.tcCurr,
      tcSeqNo: this.seqNo,
      tcType: 'PR'
    }
    this.treatyService.deleteTrCurrById(obj, this.amndSrNo).subscribe(resp => {
      this.loaderService.isBusy = true;
      let element: HTMLElement = document.getElementById("modalclose") as HTMLElement;
      element.click();
      this.toastService.success('Deleted Succcessfully.');
      this.retrieveTreatyCurrList();
      this.retrieveCurrPremiumList();
      this.back();
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
    })

  }

  savePremiumData() {
    let param = {
      tcRefNo: this.refNo,
      tcAmendNo: this.amendNo,
      tcLayer: this.layer,
      tcCurr: this.premCurrFrm.get('tcCurr').value,
      tcSeqNo: this.seqNo,
      tcType: 'LI',

    }
    this.premCurrFrm.controls['tcCurr'].enable();
    this.premCurrFrm.controls['tcMinPrem'].enable();
    this.premCurrFrm.controls['tcDepPrem'].enable();
    this.premCurrFrm.controls['tcMinPremLc1'].enable();
    this.premCurrFrm.controls['tcDepPremLc1'].enable();
    this.premCurrFrm.controls['tcFixedRate'].disable();
    if (this.Premium_Action == "Update") {
      this.premCurrFrm.patchValue({
        mttyCurrPK: param,
        // tcCurr:this.ttyCurrFrm.get('tcCurr'),
        tcFixedRate: this.premCurrFrm.get('tcFixedRate').value,
        tcMinPrem: this.premCurrFrm.get('tcMinPrem').value ? this.premCurrFrm.get('tcMinPrem').value.replace(/,/g, '') : '0',
        tcDepPrem: this.premCurrFrm.get('tcDepPrem').value ? this.premCurrFrm.get('tcDepPrem').value.replace(/,/g, '') : '0',
        tcMinPremLc1: this.premCurrFrm.get('tcMinPremLc1').value ? this.premCurrFrm.get('tcMinPremLc1').value.replace(/,/g, '') : '0',
        tcDepPremLc1: this.premCurrFrm.get('tcDepPremLc1').value ? this.premCurrFrm.get('tcDepPremLc1').value.replace(/,/g, '') : '0',
        tcStatus: 'P',
      })
      this.treatyService.updateTreatycurr(this.premCurrFrm.value, this.amndSrNo).subscribe(resp => {
        this.ttyCurrFrm.reset();
        this.PremiumFlag = false;
        this.addFlag = true;
        this.toastService.success('Updated Successfully.');
        //this.ttyCurrFrm.reset();
        this.retrieveCurrPremiumList();
      })
    } else {

    }
  }


  back() {
    this.showForm = false;
    this.PremiumFlag = false;
    this.addFlag = true;
  }

  scriptcall(id) {
    // $('#' + id).DataTable().destroy();
    // setTimeout(() => {
    //   $('#' + id).DataTable().draw();
    // }, 300);
  }

  ngAfterViewInit() {

    // $('.selectpicker').selectpicker();
    // setTimeout(()  =>  {
    //   $('.selectpicker').selectpicker('refresh');
    // },  500);
  }


  showDialogbox(currInfo: any, type) {
    this.tcRefNo = currInfo.mttyCurrPK.tcRefNo,
      this.tcAmendNo = currInfo.mttyCurrPK.tcAmendNo,
      this.tcLayer = currInfo.mttyCurrPK.tcLayer,
      this.tcCurr = currInfo.mttyCurrPK.tcCurr
    this.Curr_type = currInfo.mttyCurrPK.tcType;
    this.showForm = false;
    // this.del_seqNo = currInfo.mttyCurrPK.tcSeqNo

    if (type == "Limit") {
      this.open(this.confirmcontent, 'modal-sm');
    } else if (type == "Premium") {
      this.open(this.confirmcontentPrem, 'modal-sm');
    }

  }

  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
=======
      console.log(field + ":" + control.status);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
      if (control instanceof UntypedFormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  onGridReady(params, gridName) {
    if (gridName === 'limit') {
      this.limitGridApi = params.api;
    } else if (gridName === 'premium') {
      this.premiumGridApi = params.api;
    }
    //params.api.sizeColumnsToFit();
  }

  displayedLimitRowCount() {
    if (this.limitGridApi) {
      return this.limitGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  displayedPremiumRowCount() {
    if (this.premiumGridApi) {
      return this.premiumGridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onQuickFilterChanged(gridApi: any, qickSearch: any) {
    // alert(gridApi);
    gridApi.setQuickFilter(qickSearch);
  }
  onBtExport(gridApi: any) {
    if (gridApi) {
      gridApi.exportDataAsExcel();
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any, gridApi: any, showEntriesOptionSelected: any) {
    gridApi.paginationSetPageSize(showEntriesOptionSelected);
    gridApi.paginationGoToPage(0);
    gridApi.sizeColumnsToFit();
  }

  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");

      switch (actionType) {
        case "EditLimit":
          return this.editMaster(data);
        case "DeleteLimit":
          return this.showDialogbox(data, 'Limit');
        case "EditPrem":
          return this.editPremiumData(data);
        case "DeletePrem":
          return this.showDialogbox(data, 'Premium');
      }
    }
  }
  retrieveRoE(val) {
    this.treatyService.getRateOnExchange(val).subscribe(success => {
      var ROE = success.exchange;
      if (ROE == null) {
        this.ttyCurrFrm.get('tcFixedRate').reset();
        this.ttyCurrFrm.get('tcLimit').reset();
        this.ttyCurrFrm.get('tcAad').reset();
        this.ttyCurrFrm.get('tcDeductible').reset();
        this.toastService.warning('ROE Value is Not Available');
      } else {
        this.ttyCurrFrm.get('tcFixedRate').setValue(ROE);
        this.calcROE(ROE, val)
      }
    }, error => { })
  }

  calcROE(roe, currency) {
    if (roe && currency) {
      var ROE = parseFloat(roe);
      var layerLimit = parseFloat(this.tlLimit) * ROE;
      var layerAad = parseFloat(this.tlAad) * ROE;
      var layerExcess = parseFloat(this.tlDeductible) * ROE;
      this.ttyCurrFrm.get('tcLimit').reset();
      this.ttyCurrFrm.get('tcAad').reset();
      this.ttyCurrFrm.get('tcDeductible').reset();
      this.ttyCurrFrm.get('tcLimit').setValue(this.cpipe.premiumTransform(layerLimit.toString()));
      this.ttyCurrFrm.get('tcAad').setValue(this.cpipe.premiumTransform(layerAad.toString()));
      this.ttyCurrFrm.get('tcDeductible').setValue(this.cpipe.premiumTransform(layerExcess.toString()));
    } else if (!roe && currency)  {
      this.ttyCurrFrm.get('tcLimit').reset();
      this.ttyCurrFrm.get('tcAad').reset();
      this.ttyCurrFrm.get('tcDeductible').reset();
      this.ttyCurrFrm.get('tcFixedRate').reset();
      this.toastService.warning('Please enter ROE');
    }



  }

}
function currencyFormatter(params) {
  //return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
  return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

// function numberFormatter(params) {
//   return  params.value.toFixed(2);
<<<<<<< HEAD
// }
=======
// }
function actionRender1(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="EditLimit"  title="Edit" aria-hidden="true"></i>&nbsp;
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="DeleteLimit"  title="Delete" aria-hidden="true"></i>
            </a>`;
  }
}
function actionRender2(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="EditLimit"  title="Edit" aria-hidden="true"></i>&nbsp;
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="DeleteLimit"  title="Delete" aria-hidden="true"></i>
            </a>`;
  }
}
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
