import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatyCurrencyComponent } from './treaty-currency.component';

describe('TreatyCurrencyComponent', () => {
  let component: TreatyCurrencyComponent;
  let fixture: ComponentFixture<TreatyCurrencyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreatyCurrencyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatyCurrencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
