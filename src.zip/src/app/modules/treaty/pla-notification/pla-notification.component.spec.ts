import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaNotificationComponent } from './pla-notification.component';

describe('PlaNotificationComponent', () => {
  let component: PlaNotificationComponent;
  let fixture: ComponentFixture<PlaNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
