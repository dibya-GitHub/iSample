<<<<<<< HEAD
import { Component, OnInit } from '@angular/core';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';
=======
import { Component, OnInit, Inject } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
import { UntypedFormBuilder } from '@angular/forms';
import { TreatyService } from 'src/app/shared/services/treaty.service';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/services/toast.service';
import { LoaderService } from 'src/app/services/loader.service';
import * as moment from 'moment';
import { ReportEnquiryComponent } from '../../templates-setup/components/report-enquiry/report-enquiry.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

@Component({
  selector: 'outward-pla-notification',
  templateUrl: './pla-notification.component.html',
  styleUrls: ['./pla-notification.component.scss']
})
export class PlaNotificationComponent implements OnInit {
  plaNotificationColumn: any[];
  gridApiPla: any;
  quickSearchValuePla: string = '';
  plaDetails: any = [];
  showEntriesOptionsPla = [5, 10, 20, 50, 100];
  showEntriesOptionSelectedPla = 10;
  public components;
  constructor(
<<<<<<< HEAD
=======
    private fb: UntypedFormBuilder,
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    private treatyService: TreatyService,
    private loaderService: LoaderService,
<<<<<<< HEAD
    private toastService: ToastService
=======
    private session: SessionStorageService,
    private toasterservice: ToastService
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  ) { }

  ngOnInit() {
    this.plaNotificationColumn = [
      { field: 'wxpClmNo', headerName: 'Claim No', sortable: true, tooltipField: 'wxpClmNo', enableRowGroup: true, filter: true, resizable: true, },
      {
        headerName: 'Event',field: 'wxpEvent', sortable: true, tooltipField: 'wxpEvent', enableRowGroup: true, filter: true, resizable: true,
        valueGetter: function (params) {
          if (params.data != undefined) {
            if (params.data.wxpEvent !== null || params.data.wxpEventDesc !== null) {
              return params.data.wxpEvent + '-' + params.data.wxpEventDesc;
            }
          }
        },
      },
      {
        field: 'wxpLossDt',
        headerName: 'Loss Date',
        cellRenderer: 'lossDateCellRenderer',
        valueGetter: function (params) {
          if (params && params.data && params.data.wxpLossDt) {
            return moment(params.data.wxpLossDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        },
        filterParams: filterParams,
        enableRowGroup: true, filter: true, resizable: true, sortable: true,
      },
      // { field: 'wxpEventDesc', headerName: 'Event Desc', sortable: true, tooltipField: 'wxpEventDesc', enableRowGroup: true, filter: true, resizable: true, },
      //{ field: 'wxpLossDt', headerName: 'Loss Date', valueFormatter: dateFormatter, sortable: true, tooltipField: 'wxpLossDt', enableRowGroup: true, filter: true, resizable: true,filterParams: filterParams1, },
      { field: 'wxpLossDesc', headerName: 'Loss Desc', sortable: true, tooltipField: 'wxpLossDesc', enableRowGroup: true, filter: true, resizable: true, },
      { field: 'wxpCurr', headerName: 'Curr', sortable: true, tooltipField: 'wxpCurr', enableRowGroup: true, filter: true, resizable: true, },
      { field: 'wxpPaidRetn', headerName: 'Paid Retn', sortable: true, tooltipField: 'wxpPaidRetn', enableRowGroup: true, filter: true, resizable: true,
      valueGetter: function (param){
        if(param && param.data && param.data.wxpPaidRetn) {
          return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((param.data.wxpPaidRetn));
        } else if (param.data && !param.data.wxpPaidRetn) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
        } else {
          return ;
        }
      }, cellStyle: { textAlign: 'right' } },
      { field: 'wxpRecovered', headerName: 'Recovered', sortable: true, tooltipField: 'wxpRecovered', filter: true, resizable: true, valueFormatter: currencyFormatter,
      valueGetter: function (param){
        if(param && param.data && param.data.wxpRecovered) {
          return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((param.data.wxpRecovered));
        } else if (param.data && !param.data.wxpRecovered) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
        } else {
          return ;
        }
      },
       cellStyle: { textAlign: 'right' } },
      {
        field: 'wxpTtyRefNo', headerName: 'Contract Ref', sortable: true, tooltipField: 'wxpTtyRefNo', filter: true, resizable: true, valueGetter: function (params) {
          if (params.data != undefined)
            return params.data.wxpTtyRefNo + '-' + params.data.wxpTtySeqNo;
        }
      },
      { field: 'wxpPlaLimit', headerName: 'PLA Limit', sortable: true, tooltipField: 'wxpPlaLimit', filter: true, resizable: true, cellStyle: { textAlign: 'right' },
      valueGetter: function (param){
        if(param && param.data && param.data.wxpPlaLimit) {
          return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((param.data.wxpPlaLimit));
        } else if (param.data && !param.data.wxpPlaLimit) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
        } else {
          return ;
        }
      }, },
      { field: 'wxpDeductible', headerName: 'Excess', sortable: true, tooltipField: 'wxpDeductible', filter: true, resizable: true, cellStyle: { textAlign: 'right' },
      valueGetter: function (param){
        if(param && param.data && param.data.wxpDeductible) {
          return  Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((param.data.wxpDeductible));
        } else if (param.data && !param.data.wxpDeductible) {
          return Intl.NumberFormat('en-US',{ minimumFractionDigits: 2 }).format((0));
        } else {
          return ;
        }
      }, },
      { field: 'wxpInsName', headerName: 'Insured Name', sortable: true, tooltipField: 'wxpInsName', filter: true, resizable: true, },
      {
        field: 'wxpClmNo', headerName: 'Action',
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      }
    ];
    this.plaNotification();
    this.components = {
      lossDateCellRenderer: lossDateCellRenderer,

    };
  }

  plaNotification() {
    this.loaderService.isBusy = true;
    this.treatyService.plaNotificationDetails().subscribe(resp => {
      this.plaDetails = resp;
      this.loaderService.isBusy = false;
    }, err => {
      this.loaderService.isBusy = false;
    })
  }
<<<<<<< HEAD
  onBtExport() {
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel();
=======
  onBtExportPla() {
    console.log(this.gridApiPla);
    if (this.gridApiPla) {
      this.gridApiPla.exportDataAsExcel({
        columnKeys:['wxpClmNo','wxpEvent','wxpLossDt','wxpLossDesc','wxpCurr','wxpPaidRetn','wxpRecovered',
        'wxpTtyRefNo','wxpPlaLimit','wxpDeductible','wxpInsName'],
        processCellCallback: (params) => {
          if (params.column.colId == "wxpPaidRetn" || params.column.colId == "wxpRecovered"
              ||params.column.colId == "wxpPlaLimit" || params.column.colId == "wxpDeductible"){
            if(params && params.value){   
              let cost = parseFloat((params.value).replace(/,/g, ''))
              return cost;
            } else {
              return ''
            }
          }  else {
            return params.value;
          }
        }
      });
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
    }
  }

  onGridReadyPla(params) {
    this.gridApiPla = params.api;
    // this.gridColumnApi = params.columnApi;
    this.gridApiPla.sizeColumnsToFit();
  }
  onPaginationCountChangePla(event: any) {
    this.gridApiPla.paginationSetPageSize(this.showEntriesOptionSelectedPla);
    this.gridApiPla.paginationGoToPage(0);
  }
  pageChangedPla(event: any): void {
    this.gridApiPla.paginationGoToPage(event.page - 1);
  }

  displayRowCountPla() {
    if (this.gridApiPla) {
      return this.gridApiPla.getDisplayedRowCount();
    } else {
      return;
    }
  }

  onRowClickedPla(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      // window.open();
    }

  }

  onQuickFilterChangedPla() {
    this.gridApiPla.setQuickFilter(this.quickSearchValuePla);
  }

  refresh() {
    this.loaderService.isBusy = true;
    this.treatyService.refreshPLA().subscribe(resp => {
      if (resp == 'Success') {
        this.plaNotification();
        this.toastService.success("ReCollected");
      }
      this.loaderService.isBusy = false;
    }, err => {
      if (err.status == 200 && err.statusText == "OK") {
        this.plaNotification();
        this.toastService.success("ReCollected");
      } else {
        this.toastService.error("Error in ReCollecting");
      }
      this.loaderService.isBusy = false;
    })
  }
  onGridSizeChangedPla(params) {
    var gridWidth = document.getElementById("plaTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  groupChangedPla(params) {
    params.api.sizeColumnsToFit();
  }
}
function dateFormatter(params) {
  if (params && params.value) {
    return params.value ? (new Date(params.value)).toLocaleDateString('en-GB') : '';
  } else { return '' }

}
function currencyFormatter(params) {
  if (params && params.value) {
    // return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
    return  Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  } else { return '' }
}
function valueGet (params){
  if (params && params.value) {
    // return Intl.NumberFormat(ApiUrls.CURRENCY_FORMAT).format((params.value));
    return  Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  } else { return '' }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-print fa-icon" data-action-type="Print" title="Print" aria-hidden="true"></i>
    </a>`;
  }
}
function lossDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.data.wxpLossDt).format('DD/MM/YYYY');
  }
}

var filterParams = {
  comparator: function (a: any, b: any) {
    var valA = moment(a, 'DD-MM-YYYY');
    var valB = moment(b, 'DD-MM-YYYY');
    if (valA === valB) return 0;
    return valA > valB ? 1 : -1;
  },
};