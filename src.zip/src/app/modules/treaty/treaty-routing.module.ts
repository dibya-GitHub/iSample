import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdjustmentPremiumComponent } from './adjustment-premium/adjustment-premium.component';
import { AmendmentHistoryComponent } from './amendment-history/amendment-history.component';
import { ApprovedContractComponent } from './approved-contract/approved-contract.component';
import { ClaimRecoveryComponent } from './claim-recovery/claim-recovery.component';
import { ContractFormComponent } from './contract-form/contract-form.component';
import { EditAdjustPremiumComponent } from './edit-adjust-premium/edit-adjust-premium.component';
import { EGNPComponent } from './egnp/egnp.component';
import { LayerTreatyTypeComponent } from './layer-treaty-type/layer-treaty-type.component';
import { NCBComponent } from './ncb/ncb.component';
import { OutwardLlyodsComponent } from './outward-llyods/outward-llyods.component';
import { RecoveryEnquiryFormComponent } from './recovery-enquiry-form/recovery-enquiry-form.component';
import { RecoveryEnquiryComponent } from './recovery-enquiry/recovery-enquiry.component';
import { ReinsurePremiumComponent } from './reinsure-premium/reinsure-premium.component';
import { ReinsurersComponent } from './reinsurers/reinsurers.component';
import { TransactionQueryComponent } from './transaction-query/transaction-query.component';
import { TreatyApprContractComponent } from './treaty-appr-contract/treaty-appr-contract.component';
import { TreatyContractComponent } from './treaty-contract/treaty-contract.component';
import { TreatyCurrencyComponent } from './treaty-currency/treaty-currency.component';
import { TreatyLayerFormComponent } from './treaty-layer-form/treaty-layer-form.component';
import { TreatyTermsComponent } from './treaty-terms/treaty-terms.component';
<<<<<<< HEAD
import { TreatyViewAccountingComponent } from './treaty-view-accounting/treaty-view-accounting.component';
import { TreatyWizardComponent } from './treaty-wizard/treaty-wizard.component';
=======
import { NCBComponent } from './ncb/ncb.component';
import { TreatyViewAccountingComponent } from './treaty-view-accounting/treaty-view-accounting.component';
import { TreatyCashadvanceComponent } from './treaty-cashadvance/treaty-cashadvance.component';
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

const routes: Routes = [
  {
    path: '',
    pathMatch:'prefix',
    redirectTo: 'contract-grid'
  },
  {
    path: 'contract-grid',
    component: TreatyContractComponent
  },
  {
    path: 'contract-form',
    component: ContractFormComponent
  },

  {
    path: 'treaty-currency',
    component: TreatyCurrencyComponent
  },
  {
    path: 'reinsurers',
    component: ReinsurersComponent
  },
  {
    path: 'egnp',
    component: EGNPComponent
  },
  {
    path: 'premium',
    component: ReinsurePremiumComponent
  },
  {
    path: 'recovery-enquiry',
    component: RecoveryEnquiryComponent,
    data: {
      breadcrumb: 'Recovery-enquiry'
    }
  },
  {
    path: 'recovery-enquiry-reload',
    component: RecoveryEnquiryComponent,
    data: {
      breadcrumb: 'Recovery-enquiry'
    }
  },
  {
    path: 'recovery',
    component: RecoveryEnquiryFormComponent
  },
  {
    path: 'adjust-premium',
    component: AdjustmentPremiumComponent
  },
  {
    path: 'outward-treaty',
    pathMatch: 'prefix',
    component: TreatyWizardComponent,

  },
  {
    path: 'layer-form',
    component: TreatyLayerFormComponent
  },
  {
    path: 'edit-adjust-prem',
    component: EditAdjustPremiumComponent
  },
  {
    path: 'approved-contract',
    component: ApprovedContractComponent
  },
  {
    path: 'treaty-type',
    component: LayerTreatyTypeComponent
  },
  {
    path: 'outward-lloyd',
    component: OutwardLlyodsComponent
  },
  {
    path: 'treaty-terms',
    component: TreatyTermsComponent
  },
<<<<<<< HEAD

=======
  {
    path: '',
    pathMatch: 'prefix',
    redirectTo: 'contract-grid'
  },
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  {
    path: 'adjust-ncb',
    component: NCBComponent
  },
  {
    path: 'claim-recovery',
    component: ClaimRecoveryComponent
  },
  {
    path: 'amend-history',
    component: AmendmentHistoryComponent
  },
  {
    path: 'treaty-view-accounting',
    component: TreatyViewAccountingComponent,
    data: {
      breadcrumb: 'View-Accounting'
    }
<<<<<<< HEAD
  },
  {
    path: 'treaty-appr-contract',
    component: TreatyApprContractComponent,
    data: {
      breadcrumb: 'View Contract'
    }
  },
  {
    path: 'transaction-query',
    component: TransactionQueryComponent,
    data: {
      breadcrumb: 'Transaction Query'
    }
=======
    
  },
  {
    path: 'cash-advance',
    component: TreatyCashadvanceComponent
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TreatyRoutingModule { }
