import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { SessionStorageService } from 'angular-web-storage';
import { ApiUrls } from 'src/app/api-urls';
import { LoaderService } from 'src/app/services/loader.service';
import { ToastService } from 'src/app/services/toast.service';
import { TreatyService } from 'src/app/shared/services/treaty.service';

@Component({
  selector: 'app-appl-contract',
  templateUrl: './appl-contract.component.html',
  styleUrls: ['./appl-contract.component.css']
})
export class ApplContractComponent implements OnInit {

  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = 5;
  quickSearchValue: any;
  gridColumnApi: any;
  gridApi: any;
  filteredContractRefNoList: any;
  changeaction: string;
  details: any;
  cols: any[];
  action: string;
  showForm: boolean;
  contRefNo; String;
  @Input() amendNo: string;
  @Input() refNo: string;
  @Input() seqNo: string;
  @Input() basecurr: string;
  @Input() contractType: string;
  @Input() egnpiLabel: string;
  @Input() egnpiAmt: string;
  applContactForm: UntypedFormGroup;
  @Output() applEgnpiData = new EventEmitter;
  rowData = [];
  columnDefs = [];
  AddFlag: boolean = true;
<<<<<<< HEAD
=======
  public defaultColDef;

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
  constructor(
    private fb: UntypedFormBuilder,
    private treatyService: TreatyService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private session: SessionStorageService,
<<<<<<< HEAD
    private datePipe: DatePipe
  ) { }
=======
    private datePipe: DatePipe) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true
    };
  }
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032

  ngOnInit() {
    this.columnDefs = [
      { field: 'mttyApplContractPK.tacContRefNo', subFields: 'tacRefNo', headerName: 'Contract Ref' },
      { field: 'mttyApplContractPK.tacContSeqNo', subFields: 'tacSeqNo', headerName: 'Seq No' },
      { field: 'tacContDesc', headerName: 'Description' },
      {
        headerName: 'Action',
        field: 'mttyApplContractPK.tacContRefNo',
        cellRenderer: actionRender,
        cellStyle: { textAlign: 'center' },
        sortable: false,
        filter: false,
        enableRowGroup: false,
      },

    ];
    this.applContactForm = this.fb.group({
      tacRefNo: '',
      tacSeqNo: '',
      tacAmendNo: '',
      tacContRefNo: [undefined, Validators.required],
      tacContSeqNo: '',
      tacContDesc: '',
      tacStartDt: '',
      tacEndDt: '',
      tacDeductible: '',
      tacStatus: 'A',
      tacCrUid: this.session.get('userId'),
      tacCrDt: this.datePipe.transform(new Date(), ApiUrls.DATE_FORMAT),
      tacUpdUid: '',
      tacUpdDt: '',
      mttyApplContractPK: ''
    })
    this.changeaction = "save"
    this.retrieveContractDetails();

  }

  addApplContracts() {
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'add';
    this.filteredList();
  }
  retrieveContractDetails() {

    this.loaderService.isBusy = true;
    this.treatyService.retrieveAplContractDetailsByRefNo(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      this.rowData = resp.contractList;
      this.details = resp.contractList;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    });
  }

  save() {
    if (this.applContactForm.valid) {

      let objpk = {
        tacRefNo: this.refNo,
        tacSeqNo: this.seqNo,
        tacAmendNo: this.amendNo,
        tacContRefNo: this.contRefNo,
        tacContSeqNo: this.applContactForm.get('tacContSeqNo').value
      }
      this.applContactForm.patchValue({
        mttyApplContractPK: objpk
      })
      if (this.action == 'edit') {

        this.loaderService.isBusy = true;
        this.treatyService.updateApplContracts(this.applContactForm.value).subscribe(resp => {
          this.loaderService.isBusy = false;
          this.toastService.success("Successfully Updated");
          this.emitToEgnp();
          this.back();
          this.retrieveContractDetails();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        });

      } else {
        this.loaderService.isBusy = true;
        this.treatyService.insertApplContracts(this.applContactForm.value).subscribe(resp => {
          this.loaderService.isBusy = false;
          this.applContactForm.reset();
          this.toastService.success("Successfully Updated");
          this.emitToEgnp();
          this.back();
          this.retrieveContractDetails();

        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        });
      }
    } else {
      this.validateAllFormFields(this.applContactForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }
  emitToEgnp() {
    this.treatyService.retrieveEpiDetailsById(this.refNo, this.amendNo, this.seqNo).subscribe(resp => {
      this.applEgnpiData.emit(resp.egnpList);
    });
  }
  editApplContracts(data: any) {
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'edit';
    this.changeaction = "update"
    this.loaderService.isBusy = true;
    this.treatyService.retrieveApplContractsById(data.mttyApplContractPK).subscribe(resp => {
      this.applContactForm.patchValue({
        tacRefNo: resp.contractList.ttyHdrPK.tacRefNo,
        tacSeqNo: resp.contractList.ttyHdrPK.tacSeqNo,
        tacAmendNo: resp.contractList.mttyApplContractPK.tacAmendNo,
        tacContRefNo: resp.contractList.mttyApplContractPK.tacContRefNo,
        tacContSeqNo: resp.contractList.mttyApplContractPK.tacContSeqNo,
        tacContDesc: resp.contractList.tacContDesc,
        tacStartDt: this.datePipe.transform(resp.contractList.tacStartDt, ApiUrls.DATE_FORMAT),
        tacEndDt: this.datePipe.transform(resp.contractList.tacEndDt, ApiUrls.DATE_FORMAT),
        tacDeductible: resp.contractList.tacDeductible,
        tacStatus: resp.contractList.tacStatus,
        tacCrUid: resp.contractList.tacCrUid,
        tacCrDt: resp.contractList.tacCrDt
        // tacUpdUid:this.session.get('userId'),
        //tacUpdDt:new Date(),
      })
      this.applContactForm.get('tacContRefNo').disable();
      this.applContactForm.get('tacContSeqNo').disable();
      this.loaderService.isBusy = false;


    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    });
  }

  deleteApplContracts(data: any) {
    this.loaderService.isBusy = true;
    this.treatyService.deleteApplContractsById(data.mttyApplContractPK).subscribe(resp => {
      this.loaderService.isBusy = false;
      this.retrieveContractDetails();
      this.emitToEgnp();
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    });
  }

  filteredList() {
    let refNo = '123';
    this.treatyService.searchContractList(refNo).subscribe(resp => {
      this.filteredContractRefNoList = resp.contractList;
    });
  }

  getcontractdetails(event) {
    this.loaderService.isBusy = true;
    this.contRefNo = event.value;
    this.treatyService.getContractDetails(this.contRefNo).subscribe(resp => {

      let contract = resp.contractList;
      if (resp.contractList.length > 0) {
        contract = contract[0];
        this.applContactForm.patchValue({
          tacContSeqNo: contract.ttyHdrPK.thSeqNo,
          tacContDesc: contract.thTtyDesc,
          tacStartDt: contract.thStartDt,
          tacEndDt: contract.thEndDt,
          tacDeductible: contract.thExcess,
          tacStatus: contract.thApprSts,
          tacCrUid: this.session.get('userId'),
          tacCrDt: new Date()
        })
        this.loaderService.isBusy = false;
      } else {
        this.loaderService.isBusy = false;
      }
    });
  }
  validateAllFormFields(formGroup: UntypedFormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
<<<<<<< HEAD
      console.log(field + ":" + control.status);
      if (control instanceof UntypedFormControl) {
        console.log(formGroup.get(field));
=======
      if (control instanceof UntypedFormControl) {
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof UntypedFormGroup) {
        this.validateAllFormFields(control);
      }
    });


  }
  back() {
    this.showForm = false;
    this.AddFlag = true;
    this.applContactForm.reset();
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById("allTreatyLayerTable").offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }

  public onRowClicked(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      switch (actionType) {
        case "Delete":
          return this.deleteApplContracts(data);
      }
    }
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
  }
  displayedRowCount() {
    if (this.gridApi) {
      return this.gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any): void {
    this.gridApi.paginationGoToPage(event.page - 1);
  }

  onPaginationCountChange(event: any) {
    this.gridApi.paginationSetPageSize(this.showEntriesOptionSelected);
    this.gridApi.paginationGoToPage(0);
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
}
function actionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
    <i class="fa fa-trash fa-icon fa-danger"  data-action-type="Delete" title="Delete" aria-hidden="true"></i>
   </a>`;
  }
}
