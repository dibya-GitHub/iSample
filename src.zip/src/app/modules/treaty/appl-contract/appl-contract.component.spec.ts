import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplContractComponent } from './appl-contract.component';

describe('ApplContractComponent', () => {
  let component: ApplContractComponent;
  let fixture: ComponentFixture<ApplContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplContractComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplContractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
