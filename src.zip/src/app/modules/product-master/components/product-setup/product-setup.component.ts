import { BsModalService } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit, ElementRef, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStorageService } from 'angular-web-storage';
import * as moment from 'moment';
import { ToastService } from 'src/app/services/toast.service';
import { ApiUrls } from 'src/app/api-urls';
import { MgaUtils } from 'src/app/modules/mga-contract/components/mga-utils';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { RadioRenderProductComponent } from '../../radio-render-product/radio-render-product.component';
import { RadioRenderSubproductComponent } from '../../radio-render-subproduct/radio-render-subproduct.component';
import { ProductMasterService } from '../../services/product-master.service';
@Component({
  selector: 'inward-product-setup',
  templateUrl: './product-setup.component.html',
  styleUrls: ['./product-setup.component.scss'],
  providers: [DatePipe]
})
export class ProductSetupComponent implements OnInit {

  public gridOptions;
  public gridOptionsProduct;
  public defaultColDef;
  public components;
  public context;
  public frameworkComponents;
  public frameworkComponents1;
  gridApi: any;
  companyCode
  lobList: any;
  applDeptList: any;
  productList: any;
  schemaList: any
  userList: any;
  lobForm;
  quickSearchValue: string = '';
  showEntriesOptions = [5, 10, 20, 50, 100];
  showEntriesOptionSelected = {
    "lob": 10,
    "applDept": 10,
    "product": 10,
    "subproduct": 10
  };
  showEntriesOptionsProduct = [5, 10, 20, 50, 100];
  showEntriesOptionsSubProduct = [5, 10, 20, 50, 100];
  columnDefs = [];
  paginationPageSize: number;
  rowGroupPanelShow: string;
  showAppDeptFlag: boolean = false;
  showProdFlag: boolean = false;
  showAppDeptTable = false;
  showProductTable = false;
  showForm;
  AddFlag;
  action;
  contractData: any;
  selectedLobCode: any;
  selectedLobDesc: any;
  diviList = [];
  deptList = [];
  companyList = [];
  // applicable dept
  showApplDeptForm = false;
  columnDefsApplDept = [];
  actionApplDept;
  applDeptForm: UntypedFormGroup;
  currentApplDept: any;
  applDeptGridApi: any;
  // product
  productGridApi: any;
  columnDefsProduct = [];
  showProductForm = false;
  actionProduct;
  productForm;
  currentProduct: any;

  // subproduct
  subproductGridApi: any;
  subproductList;
  showSubProductTable = false;
  columnDefsSubproduct = []
  showSubProductForm;
  actionSubProduct;
  subProductForm
  selectedProductCode;
  currentSubProduct
  @ViewChild('applDeptDeleteModal1') applDeptDeleteModal1: ElementRef;
  @ViewChild('productDeleteModal2') productDeleteModal2: ElementRef;
  @ViewChild('subproductDeleteModal3') subproductDeleteModal3: ElementRef;

  constructor(
    private fb: UntypedFormBuilder,
    private router: Router,
    private productMasterService: ProductMasterService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private commonService: CommonService,
    private session: SessionStorageService,
    private datePipe: DatePipe,
    private modalService: BsModalService,

  ) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      filter: true,
      enableRowGroup: true,
    };
    this.companyCode = JSON.parse(this.session.get('companyCode'));
  }
  ngOnInit() {
    this.components = {
      strtDateCellRenderer: strtDateCellRenderer,
      endDateCellRenderer: endDateCellRenderer,
    };
    this.loaderService.isBusy = true;
    this.columnDefs = [
      {
        field: 'productSetupLobPK.lobCode',
        headerName: 'Select',
        sortable: false,
        width: 75,
        checkboxSelection: false,
        cellRenderer: 'radioButtonRenderer',
        cellStyle: { textAlign: 'center' },
        headerTooltip: 'Select',
        enableRowGroup: false,

      },
      {
        field: 'lobCodeDesc',
        headerName: 'Line of business'
      },
      {
        field: 'lobEffFmDt',
        headerName: 'Effective From',
        // cellRenderer: 'strtDateCellRenderer',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.lobEffFmDt) {
            let startDate = moment(params.data.lobEffFmDt).format('DD/MM/YYYY');
            return startDate;
          } else {
            return '';
          }
        },
      },
      {
        field: 'lobEffToDt',
        headerName: 'Effective To',
        // cellRenderer: 'endDateCellRenderer',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.lobEffToDt) {
            let startDate = moment(params.data.lobEffToDt).format('DD/MM/YYYY');
            return startDate;
          } else {
            return '';
          }
        },
      },
      {
        headerName: 'Action',
        field: 'productSetupLobPK.lobCode',
        width: 100,
        filter: false,
        sortable: false,
        enableRowGroup: false,
        cellStyle: { textAlign: 'center' },
        cellRenderer: columnDefsActionRender,
      },
    ];

    this.columnDefsApplDept = [
      {
        field: 'lacdLobCode',
        headerName: 'Line of business'
      },
      {
        field: 'lacdDivnCodeDesc',
        headerName: 'Division',
      },
      {
        field: 'lacdDeptCodeDesc',
        headerName: 'Department',
      },
      {
        field: 'lacdCompCodeDesc',
        headerName: 'Company',
      },
      {
        field: 'lacdLobCode',
        headerName: 'Action',
        filter: false,
        sortable: false,
        enableRowGroup: false,
        cellStyle: { textAlign: 'center' },
        cellRenderer: columnDefsApplDeptActionRender,
      },
    ];

    this.columnDefsProduct = [
      {
        field: 'productSetupLobProductPK.prodCode',
        headerName: 'Select',
        sortable: false,
        width: 100,
        checkboxSelection: false,
        cellRenderer: 'radioButtonRenderer1',
        cellStyle: { textAlign: 'center' },
        headerTooltip: 'Select',
      },
      {
        field: 'prodDesc',
        headerName: 'Product',
      },
      {
        field: 'prodShortDesc',
        headerName: 'Short Name'
      },
      {
        field: 'prodEffFmDt',
        headerName: 'Effective From',
        // cellRenderer: 'strtDateCellRenderer',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.prodEffFmDt) {
            return moment(params.data.prodEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        field: 'prodEffToDt',
        headerName: 'Effective To',
        // cellRenderer: 'endDateCellRenderer',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.prodEffToDt) {
            return moment(params.data.prodEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        headerName: 'Action',
        field: 'productSetupLobProductPK.prodCode',
        filter: false,
        sortable: false,
        enableRowGroup: false,
        cellStyle: { textAlign: 'center' },
        cellRenderer: columnDefsProductActionRender
      },
    ]

    this.columnDefsSubproduct = [
      {
        field: 'pschSchemeName',
        headerName: 'Subproduct Code & Desc'
      },
      {
        field: 'pschEffFmDt',
        headerName: 'Effective From',
        // cellRenderer: 'strtDateCellRenderer',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.pschEffFmDt) {
            return moment(params.data.pschEffFmDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        field: 'pschEffToDt',
        headerName: 'Effective To',
        // cellRenderer: 'endDateCellRenderer',
        cellStyle: { textAlign: 'right' },
        valueGetter: function (params) {
          if (params && params.data && params.data.pschEffToDt) {
            return moment(params.data.pschEffToDt).format('DD/MM/YYYY');
          } else {
            return '';
          }
        }
      },
      {
        headerName: 'Action',
        field: 'pschSchemeName',
        filter: false,
        sortable: false,
        enableRowGroup: false,
        cellStyle: { textAlign: 'center' },
        cellRenderer: columnDefsSubproductActionRender
      },
    ]
    this.context = { componentParent: this };
    this.createForm();
    this.reterieveUWriterList();
    this.frameworkComponents = {
      radioButtonRenderer: RadioRenderProductComponent
    };
    this.frameworkComponents1 = {
      radioButtonRenderer1: RadioRenderSubproductComponent
    }
    this.agGridOptions();
    this.agGridOptionsProduct();
    this.getLobData();
    this.getDropdownValues();
  }

  getLobData() {
    this.productMasterService.getlobData().subscribe(res => {
      this.lobList = res;
      this.loaderService.isBusy = false
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }

  getDropdownValues() {
    this.productMasterService.getDivision().subscribe(res => {
      this.diviList = res
    });
    this.productMasterService.getDepartment().subscribe(res => {
      this.deptList = res
    })
    this.productMasterService.getComapny().subscribe(res => {
      this.companyList = res
    })
  }


  createForm() {
    this.lobForm = this.fb.group({
      lobCodeDesc: [''],
      lobCrDt: [''],
      lobCrUid: [''],
      lobDesc: ['', Validators.required],
      lobDescBl: [''],
      lobEffFmDt: ['', Validators.required],
      lobEffToDt: ['', Validators.required],
      lobShortDesc: ['', Validators.required],
      lobUpdUid: [''],
      lobUpddt: [''],
      lobUrl: [''],
      lobCode: ['', Validators.required]
    });

    this.applDeptForm = this.fb.group({
      lacdCrDt: [''],
      lacdCrUid: [''],
      lacdDeptCode: [undefined, Validators.required],
      lacdUpdDt: [''],
      lacdUpdUid: [''],
      // productSetupLobApplDeptPK: [''],
      lacdCompCode: [undefined, Validators.required],
      lacdDivnCode: [undefined, Validators.required],
      lacdLobCode: [''],
    });

    this.productForm = this.fb.group({

      prodCode: ['', Validators.required],
      prodEffFmDt: ['', Validators.required],
      prodEffToDt: ['', Validators.required],
      prodDesc: ['', Validators.required],
      prodShortDesc: ['', Validators.required],
      prodAnnualYn: [''],
      prodClmCloseProxDays: [''],
      prodClmIntmDays: [''],
      prodClmLossdtValidYn: [''],
      prodClmReinstValYn: [''],
      prodClmSiValidYn: [''],
      prodCrDt: [''],
      prodCrUid: [''],
      prodDescBl: [''],
      prodFacAutoApprYn: [''],
      prodInstYn: [''],
      prodLobCode: [''],
      prodMaxDiscPerc: [''],
      prodNlPeriodApplYn: [''],
      prodRiAllocType: [''],
      prodRiCedingBasis: [''],
      prodRiEndAllocBasis: [''],
      prodRiTtyBasis: [''],
      prodShortDescBl: [''],
      prodUpdDt: [''],
      prodUpdUid: [''],
      productSetupLobApplDeptPK: [''],
    });

    this.subProductForm = this.fb.group({
      pschCompCode: [''],
      pschProdCode: [''],
      pschSchemeCode: ['', Validators.required],
      pschCrDt: [''],
      pschCrUid: [''],
      pschDfltFacPool: [''],
      pschEffFmDt: ['', Validators.required],
      pschEffToDt: ['', Validators.required],
      pschLongDesc: [''],
      pschRiskUrl: [''],
      pschSchemeName: ['', Validators.required],
      pschSchemeNameBl: [''],
      pschSepDiscEntryYn: [''],
      pschSepFeesEntryYn: [''],
      pschSepLoadEntryYn: [''],
      pschSepPremEntryYn: [''],
      pschSepTaxEntryYn: [''],
      pschUpdDt: [''],
      pschUpdUid: [''],
      productSetupLobProductSchemesPK: undefined
    })
  }


  selectedRowData(val: any) {
    this.showProdFlag = true;
    this.showAppDeptFlag = true;
    this.showAppDeptTable = false;
    this.showProductTable = false;
    this.showSubProductTable = false;
    this.selectedLobCode = val.value
    this.selectedLobDesc = val.data.lobCodeDesc
  }

  selectedProductData(val: any) {
    this.showSubProductTable = true;
    this.selectedProductCode = val.value;
    this.getSubProduct();
  }

  onQuickFilterChanged() {
    this.gridApi.setQuickFilter(this.quickSearchValue);
  }
  displayedRowCount(gridApi) {
    if (gridApi) {
      return gridApi.getDisplayedRowCount();
    } else {
      return;
    }
  }
  public onRowClicked(e) {

    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'Edit':
          return this.editLob(data);
        case 'Delete':
          return this.deleteLob(data);
      }
    }
  }


  addLob() {
    // this.lobForm.reset();
    this.showForm = true;
    this.AddFlag = false;
    this.action = 'add';
  }
  saveLobForm() {
    if (this.lobForm.valid) {
      this.loaderService.isBusy = true;
      let lobData = this.lobForm.value;
      lobData.lobEffFmDt = moment(this.lobForm.get('lobEffFmDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      lobData.lobEffToDt = moment(this.lobForm.get('lobEffToDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      // lobData.lobUpddt = moment(this.lobForm.get('lobUpddt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      // lobData.lobCrDt = moment(this.lobForm.get('lobCrDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      lobData.productSetupLobPK = {
        lobCode: this.lobForm.get('lobCode').value
      }
      if ('edit' === this.action) {
        this.productMasterService.updateLobData(lobData).subscribe(res => {
          this.toastService.success('Updated Successfully');
          this.showForm = false;
          this.getLobData();
          this.loaderService.isBusy = false;
          this.lobForm.reset();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        this.productMasterService.addLobData(lobData).subscribe(res => {
          this.toastService.success('Added Successfully');
          this.showForm = false;
          this.getLobData();
          this.lobForm.reset();
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      }

    } else {
      MgaUtils.validateAllFormFields(this.lobForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }


  editLob(data) {
    this.action = 'edit'
    this.showForm = true;
    this.lobForm.patchValue({
      lobCodeDesc: data.lobCodeDesc,
      lobDesc: data.lobDesc,
      lobCode: data.productSetupLobPK.lobCode,
      lobUrl: data.lobUrl,
      lobShortDesc: data.lobShortDesc,
      lobUpdUid: data.lobUpdUid,
      lobDescBl: data.lobDescBl,
      // lobCrDt: this.datePipe.transform(data.lobCrDt, ApiUrls.DATE_FORMAT),
      lobCrUid: data.lobCrUid,
      lobEffFmDt: this.datePipe.transform(data.lobEffFmDt, ApiUrls.DATE_FORMAT),
      lobEffToDt: this.datePipe.transform(data.lobEffToDt, ApiUrls.DATE_FORMAT),
      // lobUpddt: this.datePipe.transform(data.lobUpddt, ApiUrls.DATE_FORMAT),
    });
  }

  deleteLob(data) {
    alert('delete')
  }
  onBtExport() {
    // if (this.gridApi) {
    //   this.gridApi.exportDataAsExcel();
    // } else {
    //   this.gridOptions.api.exportDataAsExcel();
    // }
    if (this.gridApi) {
      this.gridApi.exportDataAsExcel({
        allColumns: true,
        fileName: 'MGAcontracts.xlsx',
        skipHeader: false,
        sheetName: 'MGA Contracts',

        processCellCallback: (params) => {

          if (params.column.colId == "biStartDt" || params.column.colId == "biEndDt") {
            return moment(params.value).format("DD-MM-YYYY");
          } else {
            return params.value;
          }

        },
      });
    }
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  pageChanged(event: any, gridApi: any): void {
    gridApi.paginationGoToPage(event.page - 1);
  }
  onPaginationCountChange(gridApi: any, page, gridName) {
    if (gridName == 'lobGridApi') {
      this.showEntriesOptionSelected.lob = page;
      gridApi.paginationSetPageSize(this.showEntriesOptionSelected.lob);
    } else if (gridName == 'applDeptGridApi') {
      this.showEntriesOptionSelected.applDept = page;
      gridApi.paginationSetPageSize(this.showEntriesOptionSelected.applDept);
    } else if (gridName == 'productGridApi') {
      this.showEntriesOptionSelected.product = page;
      gridApi.paginationSetPageSize(this.showEntriesOptionSelected.product);
    } else if (gridName == 'subproductGridApi') {
      this.showEntriesOptionSelected.subproduct = page;
      gridApi.paginationSetPageSize(this.showEntriesOptionSelected.subproduct);
    }
    gridApi.paginationGoToPage(0);
  }
  onGridSizeChanged(params) {
    var gridWidth = document.getElementById('mgadashboard').offsetWidth;
    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;
    var allColumns = params.columnApi.getAllColumns();
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      totalColsWidth += column.getMinWidth();
      if (totalColsWidth > gridWidth) {
        columnsToHide.push(column.colId);
      } else {
        columnsToShow.push(column.colId);
      }
    }
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);
    params.api.sizeColumnsToFit();
  }
  onGridReady(gridApi, table) {
    gridApi = gridApi.api;
    gridApi.sizeColumnsToFit();
    if (table === 'lob') {
      this.gridApi = gridApi;
    } else if (table === 'applDept') {
      this.applDeptGridApi = gridApi;
    } else if (table === 'product') {
      this.productGridApi = gridApi;
    } else if (table === 'subproduct') {
      this.subproductGridApi = gridApi;
    }
  }
  agGridOptions() {
    this.gridOptions = {
      columnDefs: this.columnDefs,
      rowData: null,
      enableFilter: true
    };

    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
    this.frameworkComponents = {
      radioButtonRenderer: RadioRenderProductComponent
    };

  }

  agGridOptionsProduct() {
    this.gridOptionsProduct = {
      columnDefs: this.columnDefs,
      rowData: null,
      enableFilter: true
    };
    this.rowGroupPanelShow = 'always';
    this.paginationPageSize = 5;
    this.context = { componentParent: this };
    this.frameworkComponents1 = {
      radioButtonRenderer1: RadioRenderSubproductComponent
    }
  }

  reterieveUWriterList() {
    let roleId = this.session.get('roleId');
    this.commonService.getUserByRole(roleId).subscribe((users: any) => {
      this.userList = users;
      // this.userList.unshift({ userId: '', userName: 'All' });
    })
  }

  clickApplDept() {
    this.loaderService.isBusy = true;
    this.productMasterService.getApplicableDeptById(this.selectedLobCode).subscribe(res => {
      this.applDeptList = res;
      this.applDeptForm.patchValue({
        lacdLobCode: this.selectedLobDesc,
      })
      this.loaderService.isBusy = false
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
    this.showAppDeptTable = true
    this.showProductTable = false
    this.showSubProductTable = false
  }

  clickProduct() {
    this.loaderService.isBusy = true;
    this.productMasterService.getProductById(this.selectedLobCode).subscribe(res => {
      this.productList = res;
      this.loaderService.isBusy = false;
      this.productForm.patchValue({
        prodLobCode: this.selectedLobDesc
      })
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error('Error');
    })
    this.showProductTable = true
    this.showAppDeptTable = false
  }

  getSubProduct() {
    this.loaderService.isBusy = true;
    this.productMasterService.getSubProduct(this.selectedProductCode).subscribe(res => {
      this.subproductList = res;
      this.loaderService.isBusy = false;
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error('Error');
    })
    // this.showSubProductTable = false;
    // this.showProductTable = false;
  }

  addProduct() {
    this.showProductForm = true
    this.actionProduct = "add";
  }

  addSubProduct() {
    this.showSubProductForm = true;
    this.actionSubProduct = "add";
  }

  addApplDept() {
    this.showApplDeptForm = true;
    this.actionApplDept = "add";
  }

  onRowClickedProduct(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          this.editProduct(data);
          break;
        case 'delete':
          this.currentProduct = data;
          this.open(this.productDeleteModal2, 2, 'modal-sm');

      }
    }
  }

  onRowClickedSubProduct(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          this.editSubProduct(data);
          break;
        case 'delete':
          this.currentSubProduct = data;
          this.open(this.subproductDeleteModal3, 2, 'modal-sm');

      }
    }
  }

  onRowClickedAppDept(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'delete':
          this.currentApplDept = data;
          this.open(this.applDeptDeleteModal1, 2, 'modal-sm');
      }
    }
  }

  editProduct(data) {
    this.actionProduct = 'edit'
    this.showProductForm = true;
    this.productForm.patchValue({
      prodDesc: data.prodDesc,
      prodCode: data.productSetupLobProductPK.prodCode,
      prodLobCode: data.prodLobCode,
      prodShortDesc: data.prodShortDesc,
      lobUpdUid: data.lobUpdUid,
      // prodCrDt: this.datePipe.transform(data.prodCrDt, ApiUrls.DATE_FORMAT),
      prodUpdUid: data.prodUpdUid,
      prodEffFmDt: this.datePipe.transform(data.prodEffFmDt, ApiUrls.DATE_FORMAT),
      prodEffToDt: this.datePipe.transform(data.prodEffToDt, ApiUrls.DATE_FORMAT),
      // prodUpdDt: this.datePipe.transform(data.prodUpdDt, ApiUrls.DATE_FORMAT),
    })
  }

  editSubProduct(data) {
    this.actionSubProduct = "edit";
    this.showSubProductForm = true;
    this.subProductForm.patchValue({
      pschSchemeCode: data.productSetupLobProductSchemesPK.pschSchemeCode,
      pschEffFmDt: this.datePipe.transform(data.pschEffFmDt, ApiUrls.DATE_FORMAT),
      pschEffToDt: this.datePipe.transform(data.pschEffToDt, ApiUrls.DATE_FORMAT),
      pschSchemeName: data.pschSchemeName,
      productSetupLobProductSchemesPK: {
        pschCompCode: data.productSetupLobProductSchemesPK.pschCompCode,
      }
    })

  }

  deleteProduct() {
    this.loaderService.isBusy = true;
    this.productMasterService.deleteProduct(this.currentProduct.productSetupLobProductPK.prodCode).subscribe(res => {
      this.clickProduct();
      this.loaderService.isBusy = false;
      this.closeModal();

    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }

  deleteApplDept() {
    this.loaderService.isBusy = true;
    this.productMasterService.deleteApplDept(this.currentApplDept).subscribe(res => {
      this.clickApplDept();
      this.loaderService.isBusy = false;
      this.closeModal();
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }

  deleteSubProduct() {
    this.loaderService.isBusy = true;
    this.productMasterService.deleteSubProduct(this.currentSubProduct.productSetupLobProductSchemesPK).subscribe(res => {
      this.getSubProduct();
      this.loaderService.isBusy = false;
      this.closeModal();
    }, error => {
      this.loaderService.isBusy = false;
      this.toastService.error(error.error.message);
    })
  }

  saveProduct() {
    if (this.productForm.valid) {
      this.loaderService.isBusy = true;
      this.productForm.patchValue({
        prodLobCode: this.selectedLobCode
      })
      let productData = this.productForm.value;
      productData.prodEffFmDt = moment(this.productForm.get('prodEffFmDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      productData.prodEffToDt = moment(this.productForm.get('prodEffToDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      // productData.prodUpdDt = moment(this.productForm.get('prodUpdDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      // productData.prodCrDt = moment(this.productForm.get('prodCrDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      productData.productSetupLobProductPK = {
        prodCode: this.productForm.get('prodCode').value,
      }
      if ('edit' === this.actionProduct) {
        this.productMasterService.updateProduct(productData).subscribe(res => {
          this.toastService.success('Updated Successfully');
          this.showProductForm = false;
          this.clickProduct();
          this.loaderService.isBusy = false;
          this.productForm.reset();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        this.productMasterService.addProduct(productData).subscribe(res => {
          this.toastService.success('Added Successfully');
          this.showProductForm = false;
          this.clickProduct();
          this.productForm.reset();
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      }

    } else {
      MgaUtils.validateAllFormFields(this.productForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  saveApplDept() {
    if (this.applDeptForm.valid) {
      this.loaderService.isBusy = true;
      // let applData = this.applDeptForm.value;
      this.applDeptForm.patchValue({
        lacdLobCode: this.selectedLobCode,
      })
      this.productMasterService.addApplicableDept(this.applDeptForm.value).subscribe(res => {
        this.toastService.success('Added Successfully');
        this.showApplDeptForm = false;
        this.clickApplDept();
        this.applDeptForm.reset();
        this.loaderService.isBusy = false;
      }, error => {
        this.loaderService.isBusy = false;
        this.toastService.error(error.error.message);
      })

    } else {
      MgaUtils.validateAllFormFields(this.applDeptForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  saveSubProduct() {
    if (this.subProductForm.valid) {
      this.loaderService.isBusy = true;
      this.subProductForm.patchValue({
        productSetupLobProductSchemesPK: {
          pschSchemeCode: this.subProductForm.get('pschSchemeCode').value,
          pschProdCode: this.selectedProductCode,
          pschCompCode: this.companyCode
        }
      })
      let subproductData = this.subProductForm.value;
      subproductData.pschEffFmDt = moment(this.subProductForm.get('pschEffFmDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      subproductData.pschEffToDt = moment(this.subProductForm.get('pschEffToDt').value, 'DD/MM/YYYY').format('YYYY-MM-DD');
      // subproductData.productSetupLobProductSchemesPK = {
      //   pschSchemeCode: this.subProductForm.get('pschSchemeCode').value,
      // }
      if ('edit' === this.actionSubProduct) {
        this.productMasterService.updateSubProduct(subproductData).subscribe(res => {
          this.toastService.success('Updated Successfully');
          this.showSubProductForm = false;
          this.getSubProduct();
          this.loaderService.isBusy = false;
          this.subProductForm.reset();
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      } else {
        this.productMasterService.addSubProduct(subproductData).subscribe(res => {
          this.toastService.success('Added Successfully');
          this.showSubProductForm = false;
          this.getSubProduct();
          this.showSubProductForm.reset();
          this.loaderService.isBusy = false;
        }, error => {
          this.loaderService.isBusy = false;
          this.toastService.error(error.error.message);
        })
      }

    } else {
      MgaUtils.validateAllFormFields(this.productForm);
      this.toastService.warning('Enter mandatory fields');
      this.loaderService.isBusy = false;
    }
  }

  cancelProduct() {
    this.showProductForm = false;
    this.productForm.reset();
  }

  cancelSubProduct() {
    this.showSubProductForm = false;
    this.subProductForm.reset();
  }
  cancelApplDept() {
    this.showApplDeptForm = false;
    this.applDeptForm.reset();
  }
  cancel() {
    this.showForm = false;
    this.AddFlag = true;
    this.lobForm.reset();
  }

  back() {
    this.router.navigate(['master/admindashboard'], { queryParams: { title: 'home' } });
  }
  open(content, id, val) {
    this.modalService.show(content, { id: id, class: val });
  }
  closeModal() {
    this.modalService.hide();
  }
}

function strtDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.value).format('DD/MM/YYYY');
  }
}

function endDateCellRenderer(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return moment(params.value).format('DD/MM/YYYY')
  }
}

function columnDefsActionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="Edit" title="Edit" aria-hidden="true"></i>
            </a>`;
  }
}
function columnDefsApplDeptActionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="delete" title="delete" aria-hidden="true"></i>
            </a>`;
  }
}
function columnDefsProductActionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="edit" title="Edit" aria-hidden="true"></i>
            </a>&nbsp;
            <a>
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="delete" title="delete" aria-hidden="true"></i>
            </a>`;
  }
}
function columnDefsSubproductActionRender(params) {
  if (params.value === undefined || params.value === null) {
    return '';
  } else {
    return `<a>
              <i class="fa fa-file-pen fa-icon"  data-action-type="edit" title="Edit" aria-hidden="true"></i>
            </a>&nbsp;
            <a>
              <i class="fa fa-trash fa-icon fa-danger"  data-action-type="delete" title="delete" aria-hidden="true"></i>
            </a>`;
  }
}