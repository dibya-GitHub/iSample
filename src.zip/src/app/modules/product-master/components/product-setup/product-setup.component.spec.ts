import { async, ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<< HEAD:src/app/modules/product-master/components/product-setup/product-setup.component.spec.ts
import { ProductSetupComponent } from './product-setup.component';

describe('ProductSetupComponent', () => {
  let component: ProductSetupComponent;
  let fixture: ComponentFixture<ProductSetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductSetupComponent ]
=======
import { ContractFormComponent } from './contract-form.component';

describe('ContractFormComponent', () => {
  let component: ContractFormComponent;
  let fixture: ComponentFixture<ContractFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContractFormComponent ]
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/contract-form/contract-form.component.spec.ts
    })
    .compileComponents();
  }));

  beforeEach(() => {
<<<<<<< HEAD:src/app/modules/product-master/components/product-setup/product-setup.component.spec.ts
    fixture = TestBed.createComponent(ProductSetupComponent);
=======
    fixture = TestBed.createComponent(ContractFormComponent);
>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032:src/app/modules/treaty-qs/contract-form/contract-form.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
