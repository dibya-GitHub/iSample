import { AgGridModule } from '@ag-grid-community/angular';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/shared/shared.module';
import { ProductSetupComponent } from './components/product-setup/product-setup.component';
import { ProductMasterRoutingModule } from './product-master-routing.module';
import { RadioRenderProductComponent } from './radio-render-product/radio-render-product.component';
import { RadioRenderSubproductComponent } from './radio-render-subproduct/radio-render-subproduct.component';
import { DropdownModule } from 'primeng/dropdown';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ProductMasterRoutingModule,
    DropdownModule,
    AgGridModule.withComponents([RadioRenderProductComponent, RadioRenderSubproductComponent]),

  ],
  declarations: [ProductSetupComponent, RadioRenderProductComponent, RadioRenderSubproductComponent]
})
export class ProductMasterModule { }
