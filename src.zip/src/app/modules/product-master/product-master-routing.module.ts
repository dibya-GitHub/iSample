import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductSetupComponent } from './components/product-setup/product-setup.component';

const routes: Routes = [
    {
        path: 'product-setup',
        component: ProductSetupComponent
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ProductMasterRoutingModule { }
