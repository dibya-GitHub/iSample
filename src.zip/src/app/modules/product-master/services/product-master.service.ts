import { SessionStorageService } from 'angular-web-storage';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductMasterService {
  mgaUrl: any = environment.mgaUrl;
  commonUrl = environment.mgaCommonUrl;
  baseUrl: any = environment.commonBaseUrl;
  divisionCode: any;
  companyCode: any;
  constructor(
    private httpService: HttpClient,
    private session: SessionStorageService
  ) {
    this.divisionCode = this.session.get('userDivnCode');
    this.companyCode = this.session.get('companyCode');
  }

  getlobData() {
    return this.httpService.get<any>(this.mgaUrl + 'productsetup/lob');
  }

  addLobData(data) {
    return this.httpService.post<any>(this.mgaUrl + 'productsetup/lob/save', data);
  }

  updateLobData(data) {
    return this.httpService.put<any>(this.mgaUrl + 'productsetup/lob/update', data);
  }

  getDivision() {

    return this.httpService.get<any>(this.mgaUrl + 'bc-master/divn-dd/' + this.companyCode);
  }

  getComapny() {
    return this.httpService.get<any>(this.mgaUrl + 'bc-master/company-dd');
  }

  getDepartment() {
    return this.httpService.get<any>(this.mgaUrl + 'bc-master/dept-dd/' + this.divisionCode);
  }



  // PRODUCT

  getProductById(id) {
    return this.httpService.get<any>(this.mgaUrl + 'productsetup/product/' + id);
  }

  addProduct(data) {
    return this.httpService.post<any>(this.mgaUrl + 'productsetup/product/save', data);
  }

  updateProduct(data) {
    return this.httpService.put<any>(this.mgaUrl + 'productsetup/product/update', data);
  }

  deleteProduct(prodCode) {
    return this.httpService.delete<any>(this.mgaUrl + 'productsetup/product/delete/' + prodCode);
  }

  //Applicable Department

  getApplicableDeptById(id) {
    return this.httpService.get<any>(this.mgaUrl + 'productsetup/lobApplDept/' + id + '/' + this.divisionCode + '/' + this.companyCode);
  }

  addApplicableDept(data) {
    return this.httpService.post<any>(this.mgaUrl + 'productsetup/lobApplDept/save', data);

  }

  updateApplDept(data) {
    return this.httpService.put<any>(this.mgaUrl + 'productsetup/lobApplDept/update', data);
  }

  deleteApplDept(data) {
    return this.httpService.delete<any>(this.mgaUrl + 'productsetup/lobApplDept/delete/' + data.lacdLobCode + '/' + data.lacdCompCode + '/' + data.lacdDivnCode + '/' + data.lacdDeptCode)
  }

  // SUB PRODUCT

  getSubProduct(id) {
    return this.httpService.get<any>(this.mgaUrl + 'productsetup/prodscheme/' + id);
  }

  addSubProduct(data) {
    return this.httpService.post<any>(this.mgaUrl + 'productsetup/prodscheme/save', data);
  }

  updateSubProduct(data) {
    return this.httpService.put<any>(this.mgaUrl + 'productsetup/prodscheme/update', data);
  }

  deleteSubProduct(data) {
    return this.httpService.delete<any>(this.mgaUrl + 'productsetup/prodscheme/delete/' + data.pschProdCode + '/' + data.pschCompCode + '/' + data.pschSchemeCode)
  }

}
