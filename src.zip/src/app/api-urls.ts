export class ApiUrls {
    public static INS_CMP_DETAILS = 'create';
    public static GET_ALL_DETAILS = 'retrieve';
    public static GET_SELECTED_CMP_DETAILS = 'retrievebyid';
    public static GET_COMPANY_LIST = 'companylist';
    public static GET_CURRENCY_LIST = 'currencylist';
    public static GET_DIVN_LIST = 'divnlist';
    public static GET_DIVN_LIST_BY_CMP_CODE = 'appldivn';
    public static GET_APP_PARAM_LIST = 'parameterlist';
    public static GET_USER_ROLE_LIST = 'roles';
    public static GET_DEPT_LIST_BY_CMP_CODE = 'appldept';
    public static GET_COST_CENTER_LIST = 'getCostCenterList';
    public static GET_COST_CENTER_LIST_BY_CMP_CODE = 'applcostcenter';
    public static ADD_CMP_DETAILS = 'create';
    public static UPD_DETAILS = 'update';
    public static VERIFY_USER_LOGIN = 'login';
    //public static VERIFY_USER_LOGIN = 'userMasterLogin';
    public static SAVE_DIVN_LIST = 'saveDivnList';
    public static SAVE_COST_CENTER_LIST = 'saveCostCenterList';
    public static SAVE_DEPT_LIST = 'saveDeptList';
    public static DELETE_MASTER_RECORD = 'decontaminate';
    public static GET_COLUMN_LIST = 'getColumnList';
    public static SAVE_DELEGATION = 'delegation';

    public static GET_CURRCODE = 'curr_code';
    public static SAVE_REPORT_HEADING_ID = 'repId';


    public static LOAD_REPORT_VIEWS = 'viewreport';
    public static SAVE_REPORT_ENQ = 'save-report-enquiry';
    public static LOAD_REPORT_LIST = 'loadUserReportsList';
    public static RUN_SAVED_REPORT = 'run-saved-report';
    public static EXCEL_EXPORT = 'download/excel';

    public static GET_USER_APPL_COMPANIES = 'applcompany';
    public static USER_LOGIN_DETAILS = 'login-history'
    public static GET_REP_AUTH_LIST = 'authoritylist';
    //------------MtranDocNo Gen-----------------//

    public static GET_DOC_TYPE_LIST = 'getDocTypetList';
    public static GET_DEPT_LIST = 'getDeptList';
    public static GET_AC_YEAR_LIST = 'getAcYearList';
    public static GET_TRAN_DOC_LIST = "/getTranDocList";

    public static VALIDATE_TOKEN = "validateToken";

    //------------MtranDocNo Gen-----------------//
    //------------MExchangeRate-----------------//
    public static GET_CHK_TWO_FACT_VALUE = 'chkTwoFactorAuth';
    public static RESET_PAEEWORD = 'resetPassword';
    public static FORGET_PASSWORD = 'forgotPassword';
    public static UPD_FIRST_LOGIN_FLAG = 'updateFirstLoginFlag';

    public static GET_EXC_RATE_LIST = 'getExcRatetList';
    public static GET_CURR_LIST = 'getCurrList';
    public static LOAD_EXCH_RATE_GRID = 'getExchRateInfo';
    public static GET_EXCH_DATE_LIST = 'getExchDateList';
    //public static GET_EXCH_LIST='getExchRateById';
    //------------MtranDocNo Gen-----------------//

    public static DOCTYPE_DETAILS = 'doctype';
    public static STATE_CODE = 'statecode';
    public static CUST_CATEGORY = 'customers';
    public static COMPANY_LIST = 'companylist';
    public static CURR_LIST = 'currencylist';
    public static COST_CENTER_LIST = 'costcenterList';


    //----------------PATH NAME--------------------//
    public static SMART_REPORT_PATH = 'smartreports'

    public static LOAD_USER_REPORTS_PATH = 'load-user-reports'

    public static BANK_PATH = 'banks';
    public static CURRENCY_PATH = 'currency';
    public static INSTANCE = 'instance';

    public static REPORT_HEADINGS_PATH = 'repheadings';

    public static APP_CONFIG_PATH = 'appconfig-mgmt/instance/{instanceId}/appconfig';
    public static APP_CODES_PATH = 'appcodes';
    public static SMS_EMAIL_PATH = 'smsemail';
    public static APP_PARAMS_PATH = 'app-param-mgmt/app-params';
    public static COMP_PATH = 'companies';
    public static DIVN_PATH = 'divisions';
    public static COST_CENT_PATH = 'costcentre';
    public static USER_COM_DIVN_PATH = 'usercompdivn';
    public static STANDARD_LETTER_PATH = 'standardletters';
    public static USER_ID = 'userId';


    public static COMPANY_PATH = 'companies';


    public static COUNTRY = 'COUNTRY';
    public static LOCATION = 'LOCATION';

    public static DOCPRINT_LOG = 'docprintlog';

    public static COMP_LOGO = 'companylogo';
    public static LOG_OUT = 'logout';
    public static MENU_LIST = 'menulist';
    public static MENU = 'menu';


    public static COUNTRY_CODE = 'countrycode';

    public static CUSTOMER_PATH = 'category';
    public static CUSTOMER_GROUP_PATH = 'category_group';
    public static CUSTOM_TYPE = 'type';

    public static CODE_MAP_PATH = 'codemapping';
    public static PSWD_PLCY_PATH = 'pswdplcy';
    public static INSURED = 'insured';

    // Technical Accounting
    public static Tech_ACCOUNTING_PATH = 'tech-accnt-mgmt/dashboard';

    public static TA__TRANSACTION_BOOKING_PATH = 'transanction-booking-mgmt';
    public static TA__INSTALLMENT_BOOKING_PATH = 'installment-mgmt';

    //----------------CONTROLLER-PATH------------------//
    public static SMS_EMAIL_TEMPLATE_PATH = 'smsemail-mgmt';
    public static APPCODE_CONTROLLER_PATH = 'appcodes-mgmt';
    public static APP_PARAM_CONTROLLER_PATH = 'app-param-mgmt';
    public static USER_COMP_DIVN_CONTROLLER_PATH = 'usercompdivn-mgmt';
    public static USER_CONTROLLER_PATH = 'users-mgmt';
    public static TEAM_CONTROLLER_PATH = 'team-mgmt';
    public static ORG_CONT_PATH = 'company-mgmt';
    public static SMART_REPORT_CONTROLLER_PATH = 'smartreport-mgmt';
    public static MENU_USER_ROLE_CONTROLLER_PATH = 'menurole-mgmt';
    public static CUST_CONTROLLER_PATH = 'customer-mgmt';
    public static MENU_CONTROLLER_PATH = 'menus-mgmt';
    public static USER_ROLE_CONTROLLER_PATH = 'userrole-mgmt';
    public static DEPT_CONTROLLER_PATH = "department-mgmt";
    public static DIVISION_CONTROLLER_PATH = "division-mgmt";
    public static COSTCENTER_CONTROLLER_PATH = "cost-center-mgmt";
    public static NCB_CONTROLLER_MAPPING_NAME = "ncb-mgmt";
    public static STANDARD_LETTER_CONTROLLER_PATH = "standardletters-mgmt";
    public static AAD_TOTAL_CONTROLLER_PATH = 'aad-mgmt';
    //----------------TITLE----------------------------//

    public static COMP_TITLE = 'Company';
    public static ORCHART_TITLE = 'orchart';
    public static SRAND_LETTER_TITLE = 'Standared Report';
    public static TRANS_DOC_TITLE = 'Trans doc';
    public static EXC_RATE_TITLE = 'Exchange Rate';
    public static REPT_LOG = 'Report Log';
    public static CUST_TITLE = 'Customer';
    public static ROLE_TITLE = 'Roles';
    public static USER_TITLE = 'User';
    public static SMS_EMAIL_TITLE = 'SMS/Email';
    public static TEAM_TITLE = 'Team';
    public static DIVN_TITLE = 'Division';
    public static DEPT_TITLE = 'Department';
    public static COST_CENT_TITLE = 'Cost Centre';
    public static PASS_POL_TITLE = 'Password Policy';
    public static APP_CONF_TITLE = 'App Config';

    public static APP_PARAM_TITLE = 'App Param';
    public static SMT_REPT_TITLE = 'Smart Report';
    public static CURRENCY_TITLE = 'Currency';
    public static REPT_TITLE = 'Report';
    public static BANK_TITLE = 'Bank';
    public static REPT_HEAD_TITLE = 'Report Headings';
    public static USER_MENU_TITLE = 'User Menu';
    public static REPT_TEMP_TITLE = 'Report Template';
    public static CUST_GROUP_TITLE = 'Customer Group';
    public static APP_CODE_TITLE = 'App Code';
    public static CUST_CATE_TITLE = 'Customer Category';
    public static ORG_SETUP_TITLE = 'Org Setup';
    public static SMS_TITLE = 'SMS';
    public static EMAIL_TITLE = 'Email';
    public static TREATY_TITLE = 'Treaty Contract';
    public static TREATY_RECOVERY_ENQUIRY_TITLE = 'Recovery Enquiry';

    /*...... User Master.........*/

    public static USERS_PATH = 'users';
    public static TEAM_PATH = 'team';


    public static HISTORY_LOG_TITLE = 'Login History Archive';

    public static DOCUMENT_PRINT_TITLE = 'Document Print';

    public static LOGIN_HISTORY_TITLE = "Login History";


    public static EMAIL_LOG_PATH = "email-logs";
    public static SMS_LOG_PATH = "sms-logs";

    public static RUN_DATE_PATH = "runDate";

    public static SEARCH_DATE_PATH = "srchDate";


    public static TREATY_MGMT_PATH = 'header-mgmt';
    public static TREATY_MAPPING_PATH = 'header';
    public static TREATY_APPROVE_MAPPING_PATH = 'treatyapproval';
    public static NON_PROPORTIONAL_TREATY_TYPE = 'XOL_TYPE';
    public static ATTACHMENT_BASIS_TYPE = 'ATTACH_BASIS';
    public static CONTRACT_TYPE = 'CONTRACT_TYP';
    public static APP_EVENT_TYPE = 'EVENT_CODE'
    // public static INSTANCE='instance';
    public static APP_CODES_MGMT_PATH = 'appcodes-mgmt';
    public static APP_CODES_MAPPING_PATH = 'appcodes';
    public static APP_CURRENCY_MGMT_PATH = 'currency-mgmt';
    public static APP_CURRENCY_PATH = 'currency';
    public static APP_PERIL_TYPE = 'PERIL';
    public static APP_RATE_TYPE = 'XL_RATE_TYPE';
    public static APP_COVERAGE_BASIS_TYPE = 'COVG_BASIS';

    public static PERI_MGMT_PATH = 'peril-mgmt';
    public static PERIL_MAPPING_PATH = 'perils';
    public static EPI_MGMT_PATH = 'premiumincome-mgmt';
    public static EPI_MAPPING_PATH = 'premiunincome';
    public static EPI_LIST_MAPPING_PATH = 'egnp-premium';
    public static REINS_MGMT_PATH = 'reinsurer-mgmt';
    public static REINS_LIST_PATH = 'reinsurers';
    public static REINS_CML_ID = 'TTY_CUST';
    public static REINS_ACC_TYPE = 'ACCOUNT_TO';
    public static REINS_MAPPING_PATH = 'reinsurer';
    public static TREATY_RE_INST_MGMT_PATH = 'reinst-mgmt';
    public static TREATY_RE_INST_MAPPING_PATH = 'reinst';
    public static CUST_MGMT_PATH = 'customer-mgmt';
    public static CUST_MAPPING_PATH = 'customer';
    public static UNI_MGMT_PATH = 'universal-mgmt';
    public static UNI_MAPPING_PATH = 'universal';
    public static PREM_MGMT_PATH = 'reinspremium-mgmt';
    public static RECOVERY_CLAIM_MAPPING_PATH = 'claimtranspro';
    public static PREM_MAPPING_PATH = 'reinspremium';
    public static TREATY_REINSURER_MGMT_PATH = 'reinst-mgmt';
    public static TREATY_REINSURER_MAPPING_PATH = 'reinst';
    public static LAYER_MGMT_PATH = 'layer-mgmt';
    public static LAYER_MAPPING_PATH = 'layer';
    public static PREMIUM_INCOME_PATH = 'premiumincome-mgmt';
    public static PREMIUM_MAPPING_PATH = 'totalpremium';
    public static PREM_PROC_PATH = 'instpro';
    public static INSTL_MGMT_PATH = 'installment-mgmt';
    public static INSTL_MAPPING_PATH = 'installment';
    public static REPORT_PARAM_MGMT_PATH = 'report-param-mgmt';
    public static REPORT_MAPPING_PATH = 'reports';
    public static REPORT_URL_MAPPING_PATH = 'reports-url';
    public static CONTRACT_AMEND_MGMT = 'contract-amend-mgmt';
    public static AUDIT_MGMT = 'audit-mgmt';
    public static CUST_APPLICABLE_COMP_PATH = 'appcompanies';
    public static CUST_DIVN_FROM_CODE_PATH = 'divnfrom';
    public static CUST_COMP_CODE_PATH = 'compcode';
    /*............................................................*/

    // public static USER_CONTROLLER_PATH='users-mgmt';
    // public static LOG_OUT='logout'; 
    // public static MENU_LIST='menulist'; 
    // public static COMP_LOGO='companylogo';

    public static RECOVERY_MGMT_PATH = 'recovery-mgmt';
    public static RECOVERY_MAPPING_PATH = 'recovery';
    public static PROCESS_RECOVERY_PROC = 'process';
    public static APPROVE_XOL_RECOVERY_CLAIM = 'apprxolrec';

    public static CLAIM_MGMT_PATH = 'claim-mgmt';
    public static CLAIM_MAPPING_PATH = 'claim';
    public static CURR_CONVERT_PROC = 'courency_conversion_pro';

    public static XOL_LAYER_MGMT_PATH = 'xllayer-mgmt';
    public static XOL_LAYER_MAPPING_PATH = 'xllayer';
    public static CUST_APPL_COMP_DELETE = 'app_comp_delete';
    public static TREATY_REF_NO = 'refno';

    public static TREATY_COMP_CODE_PATH = 'compcode'
    public static ADJUSTMENT_PROCEDURE_MGMT_PATH = 'adjustment-premium-mgmt';
    public static ADJUSTMENT_PROCEDURE_MAPPING_PATH = 'adjust-premium';
    public static ADJUSTMENT_PROCEDURE = 'fetchadjproc';
    public static ADJUSTMENT_CONTRACT_DETAILS = 'contract';
    public static ADJUSTMENT_RECOVERY_MGMT_PATH = 'adjustment-recovery-mgmt';
    public static ADJUSTMENT_RECOVERY_MAPPING_PATH = 'adjust-recovery';
    public static ADJUSTMENT_LAYER_MGMT_PATH = 'adjustment-layer-mgmt';
    public static ADJUSTMENT_LAYER_MAPPING_PATH = 'adjust-layer';
    public static ADJUSTMENT_PREMIUM_MGMT = 'adjustment-premium-income-mgmt';
    public static ADJUSTMENT_PREMIUM_MAPPING_PATH = 'adjust-Premium-income';
    public static ADJUSTMENT_REINSURER_MGMT_PATH = 'adjustment-reinsurer-mgmt';
    public static ADJUSTMENT_REINSURER_MAPPING_PATH = 'adj-reinsurer';
    public static ADJUSTMENT_REINS_SUMMARY = 'reins-summary';
    public static ADJUSTMENT_XL_TREATY_MGMT = 'adjustment-xl-treaty-mgmt';
    public static ADJUSTMENT_XL_TREATY_MAPPING_PATH = 'adjust-xl-treaty';
    public static ADJUSTMENT_DEP_REINSURER_MAPPING_PATH = 'adj-dep-reinsurer';
    public static ADJUSTMENT_REINST_REINSURER_MAPPING_PATH = 'adj-reinst-reinsurer';



    public static TEAM_MAPPING_PATH = 'team';
    public static COMPANY_MAPPING_PATH = 'company';

    public static TREATY_RENEWAL = 'treatyRenewal';

    public static EXISTS_BY_ID = 'existById';
    public static TREATY_FETCH_DOC = 'fetchdocument';
    public static TREATY_VIEW_DOC = 'viewdoc';

    public static TREATY_DELETE_DOC = 'deletedoc'

    public static DATE_FORMAT = 'dd/MM/yyyy';
    public static Contract_Form_Date = 'dd/MM/yyyy'

    public static ADJUST_TYPE_DEP = 'DEP_PREM';
    public static ADJUST_TYPE_REINST = 'REINST_PREM';
    public static STORED_PROCEDURE = 'stored-procedure';
    public static APP_CURRENCY_PREM_PATH = "currency-prem";
    public static RISK_PERIL_MGMT_PATH = "risk-mgmt";
    public static RISK_PATH = "risk";
    public static FLAT_RATE = 'FR';
    public static LLY_REGION = 'LLY_REGION';
    public static LLY_CLASS = 'LLY_CLASS';
    public static FUND_CODE = 'LLY_US_TF';
    public static TRUST_FUND_MGMT_PATH = "trust-fund-mgmt";
    public static TRUST_FUND_MAPPING_PATH = 'trust-fund';
    public static TREATY_TERMS = 'TTY_COMM';
    public static TREATY_TERMS_PERCENTAGE_ON = 'CEDING_BASIS';
    public static TREATY_TERMS_PATH_NAME = 'comm-mgmt';
    public static TERMS_PATH = 'commission';
    public static APP_CODES_MAP_PATH = 'appcode';
    public static TREATY_APPL_CONTRACT_PATH_NAME = 'contract-mgmt';
    public static APPL_CONTRACT_PATH = 'contract';
    public static RISK_LLY = 'LLY_RISK';
    public static TREATY_RISK_LLOYDS_CODE = 'LLY_RISK';
    public static TREATY_RISK_LLOYDS_PERC = 'TY_RISK_PERC'
    public static TREATY_RISK_LLOYDS_MAPPING_NAME = 'risk-lloyds-mgmt';
    public static TREATY_RISK_LLOYDS_PATH_NAME = 'risk-lloyds';
    public static TREATY_ROE_PATH = 'exchange-rate';

    public static CURRENCY_FORMAT = 'en-US';

    public static CLAIM_RECOVERY_MAPPING_NAME = "claim-rec-mgmt";

    public static CLAIM_RECOVERY = "claim-recovery";

    public static REC_DROPDOWN = "reference-dropdown";
    public static POLICY_DROPDOWN = "policy-dropdown";
    public static CLAIM_DROPDOWN = "claim-dropdown";
    public static REP_SR_NO = 'repSrNo';
    public static TRANSANCTION_MGMT = 'transaction-mgmt'
    public static NCB_REINSURER = 'ncb-reinsurer';
    public static CONTRACT_INFO = 'contract-info';
    static UPDATE_REBATE = 'update-rebate';
<<<<<<< HEAD

    // MGA Url PATH
    public static MGA_MGMT_PATH = 'header-mgmt';
    public static MGA_MAPPING_PATH = "header";
    public static MGA_BINDER_CONTRACTS = "contracts";
    public static MGA_LOB_CONTRACTS = "lob";
    public static MGA_LOB_EPI = "lobepi";
    public static MGA_BUSINESS_RULES = 'lob-busrules';
    public static MGA_COINSURANCE = 'lobcoins';
    public static MGA_LOB_TERMS = 'lobterms';
    public static MGA_VIEW = 'view';
    public static MGA_AMEND = 'bc-amend';
    public static MGA_RENEW = 'bc-renew';
    public static MGA_OUTWARD = "outward";
    public static BORDERX_BATCH_INFO = 'batchinfo';
    public static BORDERX_PREM_SUMMARY = 'premSummBdx';
    public static MGA_COINSURANCE_EXPENSES = 'lobcoinsterms';

    public static QS_ACNT_MGMT = 'qs_acnt-mgmt';
=======
    
    //nagico-mgmt
    static NAGICO_REBATE = 'nagico-mgmt';
    public static QS_ACNT_MGMT = 'qs_acnt-mgmt';
    public static MGA_MGMT_PATH = 'header-mgmt';

>>>>>>> 38b4a38116650f64069a4c1f5ae293771f102032
}
